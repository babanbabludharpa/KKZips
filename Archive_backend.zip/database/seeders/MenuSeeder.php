<?php

namespace Database\Seeders;

use App\Models\Menu;
use Illuminate\Database\Seeder;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        Menu::truncate();

        $parentIds = $this->seedParents();

        $this->seedMastersChildren($parentIds);
        $this->seedStockChildren($parentIds);
        $this->seedSettingsChildren($parentIds);
        $this->seedAppSettingsChildren($parentIds);
        $this->seedAdministrationChildren($parentIds);
        $this->seedReportsChildren($parentIds);
        $this->seedOrdersChildren($parentIds);
        $this->seedSubscriptionsChildren($parentIds);
    }

    /**
     * @return array<string, int> Map of parent name => created menu id.
     */
    private function seedParents(): array
    {
        $parentIds = [];

        foreach ($this->parentDefinitions() as $menu) {
            $created = Menu::create($menu);
            $parentIds[$menu['name']] = $created->id;
        }

        return $parentIds;
    }

    private function seedMastersChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Masters'], $this->mastersChildren());
    }

    private function seedStockChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Stock'], $this->stockChildren());
    }

    private function seedSettingsChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Settings'], $this->settingsChildren());
    }

    private function seedAppSettingsChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['App Settings'], $this->appSettingsChildren());
    }

    private function seedAdministrationChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Administration'], $this->administrationChildren());
    }

    private function seedReportsChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Reports'], $this->reportsChildren());
    }

    private function seedOrdersChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Orders'], $this->ordersChildren());
    }

    private function seedSubscriptionsChildren(array $parentIds): void
    {
        $this->createChildren($parentIds['Subscriptions'], $this->subscriptionsChildren());
    }

    /**
     * Strips the 'parent_id' key from each child definition and injects the
     * resolved parent id, then persists them in order.
     */
    private function createChildren(int $parentId, array $children): void
    {
        foreach ($children as $child) {
            $child['parent_id'] = $parentId;
            Menu::create($child);
        }
    }

    private function parentDefinitions(): array
    {
        return [
            [
                'name' => 'Dashboard',
                'icon' => 'cil-speedometer',
                'route' => '/dashboard',
                'permission' => null,
                'parent_id' => null,
                'sort_order' => 1,
                'is_active' => true,
            ],
            [
                'name' => 'Masters',
                'icon' => 'cil-layers',
                'route' => null,
                'permission' => 'category.view',
                'parent_id' => null,
                'sort_order' => 2,
                'is_active' => true,
            ],
            [
                'name' => 'Stock',
                'icon' => 'cil-storage',
                'route' => null,
                'permission' => null,
                'parent_id' => null,
                'sort_order' => 3,
                'is_active' => true,
            ],
            [
                'name' => 'Orders',
                'icon' => 'cil-list-rich',
                'route' => null,
                'permission' => null,
                'parent_id' => null,
                'sort_order' => 4,
                'is_active' => true,
            ],
            [
                'name' => 'Subscriptions',
                'icon' => 'cil-loop-circular',
                'route' => null,
                'permission' => null,
                'parent_id' => null,
                'sort_order' => 5,
                'is_active' => true,
            ],
            [
                'name' => 'Reports',
                'icon' => 'cil-chart-pie',
                'route' => null,
                'permission' => 'report.view',
                'parent_id' => null,
                'sort_order' => 6,
                'is_active' => true,
            ],
            [
                'name' => 'Settings',
                'icon' => 'cil-settings',
                'route' => null,
                'permission' => null,
                'parent_id' => null,
                'sort_order' => 7,
                'is_active' => true,
            ],
            [
                'name' => 'App Settings',
                'icon' => 'cil-cog',
                'route' => 'null',
                'permission' => 'appsettings.view',
                'parent_id' => null,
                'sort_order' => 8,
                'is_active' => true,
            ],
            [
                'name' => 'Administration',
                'icon' => 'cil-shield-alt',
                'route' => null,
                'permission' => 'user.view',
                'parent_id' => null,
                'sort_order' => 9,
                'is_active' => true,
            ],
        ];
    }

    private function mastersChildren(): array
    {
        return [
            ['name' => 'Categories', 'icon' => 'cil-tag', 'route' => '/masters/categories', 'permission' => 'category.view', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Units', 'icon' => 'cil-balance-scale', 'route' => '/masters/units', 'permission' => 'unit.view', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Suppliers', 'icon' => 'cil-truck', 'route' => '/masters/suppliers', 'permission' => 'supplier.view', 'sort_order' => 3, 'is_active' => true],
            ['name' => 'Tax Rates', 'icon' => 'cil-calculator', 'route' => '/masters/tax-rates', 'permission' => 'taxrate.view', 'sort_order' => 4, 'is_active' => true],
            ['name' => 'Attributes', 'icon' => 'cil-list', 'route' => '/masters/attributes', 'permission' => 'attribute.view', 'sort_order' => 5, 'is_active' => true],
            ['name' => 'Products', 'icon' => 'cil-basket', 'route' => '/masters/products', 'permission' => 'product.view', 'sort_order' => 6, 'is_active' => true],
            ['name' => 'Cities', 'icon' => 'cil-location-pin', 'route' => '/masters/cities', 'permission' => 'city.view', 'sort_order' => 7, 'is_active' => true],
            ['name' => 'Coupons', 'icon' => 'cil-tags', 'route' => '/masters/coupons', 'permission' => 'coupon.view', 'sort_order' => 8, 'is_active' => true],
            ['name' => 'Delivery Charges', 'icon' => 'cil-truck', 'route' => '/masters/delivery-charges', 'permission' => 'delivery.view', 'sort_order' => 9, 'is_active' => true],
            ['name' => 'Customers', 'icon' => 'cil-people', 'route' => '/masters/customers', 'permission' => 'customer.view', 'sort_order' => 10, 'is_active' => true],
            ['name' => 'Free Gifts', 'icon' => 'cil-gift', 'route' => '/masters/gifts', 'permission' => 'gift.view', 'sort_order' => 11, 'is_active' => true],
        ];
    }

    private function stockChildren(): array
    {
        return [
            ['name' => 'Inward Stock', 'icon' => 'cil-arrow-thick-bottom', 'route' => '/stock/inward', 'permission' => 'stock.inward', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Stock Requests', 'icon' => 'cil-swap-horizontal', 'route' => '/stock/requests', 'permission' => 'stock.request', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Accept Stock Requests', 'icon' => 'cil-check-circle', 'route' => '/stock/requests/approve', 'permission' => 'stock.approve', 'sort_order' => 3, 'is_active' => true],
        ];
    }

    private function settingsChildren(): array
    {
        return [
            ['name' => 'Tenant Profile', 'icon' => 'cil-building', 'route' => '/settings/profile', 'permission' => 'profile.view', 'sort_order' => 1, 'is_active' => true],            
            ['name' => 'Leaves', 'icon' => 'cil-calendar', 'route' => '/settings/leaves', 'permission' => 'profile.leaves_edit', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Branches', 'icon' => 'cil-location-pin', 'route' => '/settings/branches', 'permission' => 'branch.view', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'FAQ Management', 'icon' => 'cil-list', 'route' => '/settings/faq', 'permission' => 'faq.manage', 'sort_order' => 3, 'is_active' => true],
            ['name' => 'Delivery Boys', 'icon' => 'cil-bike', 'route' => '/settings/delivery-boys', 'permission' => 'branch.view', 'sort_order' => 4, 'is_active' => true],
        ];
    }

    private function appSettingsChildren(): array
    {
        return [
            ['name' => 'Mobile Layout Builder', 'icon' => 'cil-window-restore', 'route' => '/appsettings/layout', 'permission' => 'appsettings.edit', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Web Builder', 'icon' => 'cil-window-restore', 'route' => '/appsettings/web-builder', 'permission' => 'appsettings.edit', 'sort_order' => 2, 'is_active' => true],
        ];
    }

    private function administrationChildren(): array
    {
        return [
            ['name' => 'Users', 'icon' => 'cil-user', 'route' => '/superadmin/users', 'permission' => 'user.view', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Roles', 'icon' => 'cil-lock-locked', 'route' => '/superadmin/roles', 'permission' => 'role.view', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Permissions', 'icon' => 'cil-check-circle', 'route' => '/superadmin/permissions', 'permission' => 'permission.assign', 'sort_order' => 3, 'is_active' => true],
            ['name' => 'Menus', 'icon' => 'cil-menu', 'route' => '/superadmin/menus', 'permission' => 'system.settings', 'sort_order' => 4, 'is_active' => true],
        ];
    }

    private function reportsChildren(): array
    {
        return [
            ['name' => 'Stock Levels', 'icon' => 'cil-storage', 'route' => '/reports/stock-levels', 'permission' => 'report.stock_levels', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Stock Movements', 'icon' => 'cil-transfer', 'route' => '/reports/stock-movements', 'permission' => 'report.stock_movements', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Stock Requests', 'icon' => 'cil-swap-horizontal', 'route' => '/reports/stock-requests', 'permission' => 'report.stock_requests', 'sort_order' => 3, 'is_active' => true],
            ['name' => 'Request Detail', 'icon' => 'cil-description', 'route' => '/reports/stock-request-detail', 'permission' => 'report.stock_request_detail', 'sort_order' => 4, 'is_active' => true],
            ['name' => 'Price History', 'icon' => 'cil-dollar', 'route' => '/reports/price-history', 'permission' => 'report.price_history', 'sort_order' => 5, 'is_active' => true],
            ['name' => 'Discount History', 'icon' => 'cil-tag', 'route' => '/reports/discount-history', 'permission' => 'report.discount_history', 'sort_order' => 6, 'is_active' => true],
            ['name' => 'Delivered Orders', 'icon' => 'cil-check-circle', 'route' => '/reports/delivered-orders', 'permission' => 'report.delivered_orders', 'sort_order' => 7, 'is_active' => true],
            ['name' => 'Delivered Orders (Product-Wise)', 'icon' => 'cil-check-circle', 'route' => '/reports/delivered-orders-product-wise', 'permission' => 'report.delivered_orders_product_wise', 'sort_order' => 8, 'is_active' => true],
            ['name' => 'Coupon Consumption', 'icon' => 'cil-check-circle', 'route' => '/reports/coupon-consumption', 'permission' => 'report.coupon_consumption', 'sort_order' => 9, 'is_active' => true],
            ['name' => 'Subscription Delivery Report', 'icon' => 'cil-list', 'route' => '/reports/subscription-delivery', 'permission' => 'report.subscription_delivery', 'sort_order' => 10, 'is_active' => true],
            ['name' => 'Subscription Demand Report', 'icon' => 'cil-chart-line', 'route' => '/reports/subscription-demand', 'permission' => 'report.subscription_demand', 'sort_order' => 11, 'is_active' => true],
            ['name' => 'Pause & Qty Change Report', 'icon' => 'cil-history', 'route' => '/reports/subscription-activity', 'permission' => 'report.subscription_activity', 'sort_order' => 12, 'is_active' => true],
            ['name' => 'Customer Address Report', 'icon' => 'cil-location-pin', 'route' => '/reports/customer-addresses', 'permission' => 'report.customer_addresses', 'sort_order' => 13, 'is_active' => true],
            ['name' => 'Customer Wallet Balance Report', 'icon' => 'cil-wallet', 'route' => '/reports/wallet-balances', 'permission' => 'report.wallet_balances', 'sort_order' => 14, 'is_active' => true],
            ['name' => 'Wallet Transaction Report', 'icon' => 'cil-list-numbered', 'route' => '/reports/wallet-transactions', 'permission' => 'report.wallet_transactions', 'sort_order' => 15, 'is_active' => true],
            ['name' => 'Support Conversations', 'icon' => 'cil-comment-bubble', 'route' => '/reports/support', 'permission' => 'report.support', 'sort_order' => 16, 'is_active' => true],
        ];
    }

    private function ordersChildren(): array
    {
        return [
            ['name' => 'All Orders', 'icon' => 'cil-list', 'route' => '/orders', 'permission' => 'order.view', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Delivery Assignment', 'icon' => 'cil-truck', 'route' => '/orders/delivery-queue', 'permission' => 'order.assign_delivery', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Cancelled / Failed Orders', 'icon' => 'cil-x-circle', 'route' => '/orders/cancelled', 'permission' => 'order.view_cancelled', 'sort_order' => 3, 'is_active' => true],
        ];
    }

    private function subscriptionsChildren(): array
    {
        return [
            ['name' => 'All Subscriptions', 'icon' => 'cil-list', 'route' => '/subscriptions', 'permission' => 'subscription.view', 'sort_order' => 1, 'is_active' => true],
            ['name' => 'Delivery Assignment', 'icon' => 'cil-truck', 'route' => '/subscriptions/delivery-assignment', 'permission' => 'subscription.assign_delivery', 'sort_order' => 2, 'is_active' => true],
            ['name' => 'Invoices', 'icon' => 'cil-description', 'route' => '/subscriptions/invoices', 'permission' => 'invoice.view', 'sort_order' => 3, 'is_active' => true],
        ];
    }
}
