<?php

namespace Database\Seeders;

use App\Models\FaqCollection;
use App\Models\FaqItem;
use App\Models\TenantProfile;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;

class FaqSeeder extends Seeder
{
    /**
     * Seeds the base FAQ knowledge base for a tenant.
     *
     * Reads the shared JSON template at database/seeders/data/faq_seed.json,
     * substitutes tenant-specific placeholders ({{support_phone}}, etc.)
     * from the tenant's TenantProfile, then creates collections and items.
     *
     * Idempotent: re-running updates existing rows instead of duplicating.
     * Uses collection_slug + language + question as the natural key, so
     * editing the JSON and re-seeding updates the answer in place.
     */
    public function run(): void
    {
        $path = database_path('seeders/data/faq_seed.json');

        if (! File::exists($path)) {
            $this->command->error("FAQ seed file not found at: {$path}");

            return;
        }

        $data = json_decode(File::get($path), true);

        if (! is_array($data) || empty($data['collections'])) {
            $this->command->error('FAQ seed file is empty or malformed.');

            return;
        }

        // ★ Fetch the tenant profile ONCE — every placeholder lookup
        //   reads from here. If no profile exists yet (fresh tenant),
        //   we use sensible fallbacks so seed text stays readable
        //   instead of showing literal "{{support_phone}}".
        $profile = TenantProfile::first();
        $placeholders = $this->buildPlaceholders($profile);

        $collectionCount = 0;
        $itemCount = 0;

        foreach ($data['collections'] as $collectionData) {
            $collection = FaqCollection::updateOrCreate(
                ['slug' => $collectionData['slug']],
                [
                    'name' => $collectionData['name'],
                    'description' => $collectionData['description'] ?? null,
                    'icon' => $collectionData['icon'] ?? null,
                    'sort_order' => $collectionData['sort_order'] ?? 0,
                    'is_active' => true,
                ]
            );
            $collectionCount++;

            foreach ($collectionData['items'] as $index => $itemData) {
                $answer = $this->substitutePlaceholders(
                    $itemData['answer'],
                    $placeholders
                );

                // ★ Respect tenant customizations. If an admin has edited this FAQ
                //   (customized_at is set), skip it entirely — don't overwrite
                //   their changes on re-seed.
                $existing = FaqItem::where('collection_id', $collection->id)
                    ->where('language', 'en')
                    ->where('question', $itemData['question'])
                    ->first();

                if ($existing && $existing->customized_at !== null) {
                    $itemCount++;

                    continue;
                }

                FaqItem::updateOrCreate(
                    [
                        'collection_id' => $collection->id,
                        'language' => 'en',
                        'question' => $itemData['question'],
                    ],
                    [
                        'answer' => $answer,
                        'alternative_questions' => $itemData['alternative_questions'] ?? [],
                        'keywords' => $itemData['keywords'] ?? [],
                        'sort_order' => $index,
                        'is_active' => true,
                    ]
                );
                $itemCount++;
            }
        }

        $this->command->info(
            "FAQ seed complete: {$collectionCount} collections, {$itemCount} items."
        );
    }

    /**
     * Build the placeholder → value map from the tenant profile.
     * Fallbacks are written so that a fresh tenant with no support
     * details configured still gets readable FAQ text (the admin can
     * fill in the real values from the tenant profile page later).
     */
    private function buildPlaceholders(?TenantProfile $profile): array
    {
        $companyName = $profile?->company_name ?: 'our team';

        return [
            '{{support_phone}}' => $profile?->support_phone ?: 'our support number (not set yet)',
            '{{support_email}}' => $profile?->support_email ?: 'our support email (not set yet)',
            '{{support_hours}}' => $profile?->support_hours ?: 'during business hours',
            '{{company_name}}' => $companyName,
            '{{pan_no}}' => $profile?->pan_no ?: '—',
        ];
    }

    /**
     * Replace every {{placeholder}} in the given text.
     * Unknown placeholders are left as-is (visible during testing
     * rather than silently disappearing).
     */
    private function substitutePlaceholders(string $text, array $placeholders): string
    {
        return strtr($text, $placeholders);
    }
}// need to re-run the seeder after adding seeder in yaml file
