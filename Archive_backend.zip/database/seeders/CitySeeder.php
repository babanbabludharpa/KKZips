<?php

namespace Database\Seeders;

use App\Models\City;
use App\Models\State;
use Illuminate\Database\Seeder;

class CitySeeder extends Seeder
{
    public function run(): void
    {
        $cities = [
            'AP' => ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Tirupati', 'Rajahmundry', 'Kakinada', 'Kadapa', 'Anantapur'],
            'AR' => ['Itanagar', 'Naharlagun', 'Pasighat', 'Tawang', 'Ziro'],
            'AS' => ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon', 'Tinsukia', 'Tezpur', 'Bongaigaon'],
            'BR' => ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia', 'Darbhanga', 'Bihar Sharif', 'Arrah', 'Begusarai', 'Katihar'],
            'CG' => ['Raipur', 'Bhilai', 'Korba', 'Bilaspur', 'Durg', 'Rajnandgaon', 'Jagdalpur', 'Raigarh', 'Ambikapur'],
            'GA' => ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda', 'Bicholim'],
            'GJ' => ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Anand', 'Nadiad', 'Morbi', 'Mehsana', 'Bharuch', 'Navsari', 'Valsad'],
            'HR' => ['Faridabad', 'Gurgaon', 'Panipat', 'Ambala', 'Yamunanagar', 'Rohtak', 'Hisar', 'Karnal', 'Sonipat', 'Panchkula'],
            'HP' => ['Shimla', 'Dharamshala', 'Solan', 'Mandi', 'Palampur', 'Baddi', 'Nahan', 'Kullu', 'Manali'],
            'JH' => ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Deoghar', 'Hazaribagh', 'Giridih', 'Ramgarh', 'Phusro'],
            'KA' => ['Bengaluru', 'Mysuru', 'Hubli', 'Mangaluru', 'Belagavi', 'Davangere', 'Ballari', 'Vijayapura', 'Shivamogga', 'Tumakuru', 'Udupi', 'Hassan', 'Dharwad', 'Kalaburagi'],
            'KL' => ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Palakkad', 'Alappuzha', 'Malappuram', 'Kannur', 'Kasaragod'],
            'MP' => ['Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa', 'Murwara', 'Singrauli', 'Burhanpur'],
            'MH' => ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Thane', 'Aurangabad', 'Solapur', 'Amravati', 'Kolhapur', 'Nanded', 'Sangli', 'Malegaon', 'Jalgaon', 'Akola', 'Latur', 'Dhule', 'Ahmednagar', 'Chandrapur', 'Parbhani', 'Ichalkaranji', 'Jalna', 'Ambarnath', 'Bhiwandi', 'Panvel', 'Navi Mumbai'],
            'MN' => ['Imphal', 'Thoubal', 'Bishnupur', 'Churachandpur', 'Senapati'],
            'ML' => ['Shillong', 'Tura', 'Jowai', 'Nongstoin'],
            'MZ' => ['Aizawl', 'Lunglei', 'Saiha', 'Champhai'],
            'NL' => ['Kohima', 'Dimapur', 'Mokokchung', 'Wokha', 'Tuensang'],
            'OD' => ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Brahmapur', 'Sambalpur', 'Puri', 'Balasore', 'Bhadrak', 'Baripada', 'Jharsuguda'],
            'PB' => ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali', 'Hoshiarpur', 'Batala', 'Pathankot', 'Moga', 'Firozpur'],
            'RJ' => ['Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar', 'Bharatpur', 'Sikar', 'Pali', 'Sri Ganganagar', 'Barmer', 'Tonk'],
            'SK' => ['Gangtok', 'Namchi', 'Gyalshing', 'Mangan'],
            'TN' => ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur', 'Vellore', 'Erode', 'Thoothukudi', 'Dindigul', 'Thanjavur', 'Ranipet', 'Sivakasi', 'Karur', 'Hosur', 'Nagercoil', 'Kanchipuram', 'Cuddalore'],
            'TS' => ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar', 'Ramagundam', 'Khammam', 'Mahbubnagar', 'Nalgonda', 'Adilabad', 'Siddipet'],
            'TR' => ['Agartala', 'Dharmanagar', 'Udaipur', 'Kailashahar', 'Belonia'],
            'UP' => ['Lucknow', 'Kanpur', 'Agra', 'Varanasi', 'Meerut', 'Allahabad', 'Ghaziabad', 'Noida', 'Bareilly', 'Aligarh', 'Moradabad', 'Saharanpur', 'Gorakhpur', 'Faizabad', 'Jhansi', 'Mathura', 'Muzaffarnagar', 'Rampur', 'Shahjahanpur', 'Firozabad', 'Hapur', 'Etawah', 'Mirzapur', 'Bulandshahr', 'Loni', 'Jhansi', 'Unnao'],
            'UK' => ['Dehradun', 'Haridwar', 'Roorkee', 'Haldwani', 'Rudrapur', 'Kashipur', 'Rishikesh', 'Pithoragarh', 'Nainital'],
            'WB' => ['Kolkata', 'Howrah', 'Asansol', 'Siliguri', 'Durgapur', 'Bardhaman', 'Malda', 'Barasat', 'Krishnanagar', 'Haldia', 'Kharagpur', 'Cooch Behar', 'Jalpaiguri'],
            // UTs
            'AN' => ['Port Blair', 'Diglipur', 'Rangat'],
            'CH' => ['Chandigarh'],
            'DH' => ['Daman', 'Diu', 'Silvassa'],
            'DL' => ['New Delhi', 'Delhi', 'Dwarka', 'Rohini', 'Saket', 'Lajpat Nagar', 'Janakpuri', 'Pitampura', 'Shahdara', 'Faridabad'],
            'JK' => ['Jammu', 'Srinagar', 'Anantnag', 'Baramulla', 'Sopore', 'Udhampur', 'Kathua'],
            'LA' => ['Leh', 'Kargil'],
            'LD' => ['Kavaratti', 'Agatti', 'Amini'],
            'PY' => ['Puducherry', 'Karaikal', 'Mahe', 'Yanam'],
        ];

        foreach ($cities as $stateCode => $cityNames) {
            $state = State::where('code', $stateCode)->first();
            if (! $state) {
                continue;
            }

            foreach ($cityNames as $cityName) {
                City::firstOrCreate(
                    ['state_id' => $state->id, 'name' => $cityName],
                    ['is_active' => true]
                );
            }
        }
    }
}
