<?php

use App\Http\Middleware\ApplyTenantBroadcastConfig;
use App\Http\Middleware\InitializeMobileTenancy;
use App\Http\Middleware\InitializeTenancyBySubdomainMiddleware;
use App\Http\Middleware\MobileCustomerAuth;
use App\Http\Middleware\MobileRiderAuth;
use App\Http\Middleware\PlatformAdminMiddleware;
use App\Providers\TenancyServiceProvider;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Spatie\Permission\Middleware\PermissionMiddleware;
use Spatie\Permission\Middleware\RoleMiddleware;
use Spatie\Permission\Middleware\RoleOrPermissionMiddleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        channels: __DIR__.'/../routes/channels.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // ── Web tenancy (subdomain) stays as global prepend ────────────
        $middleware->prepend(InitializeTenancyBySubdomainMiddleware::class);

        $middleware->alias([
            'role' => RoleMiddleware::class,
            'permission' => PermissionMiddleware::class,
            'role_or_permission' => RoleOrPermissionMiddleware::class,
            'platform.admin' => PlatformAdminMiddleware::class,
            'tenant.init' => InitializeTenancyBySubdomainMiddleware::class,
            // ── Mobile specific ────────────────────────────────────────
            'tenant.mobile' => InitializeMobileTenancy::class,
            'mobile.customer' => MobileCustomerAuth::class,
            'tenant.broadcast' => ApplyTenantBroadcastConfig::class,
            //  ADDED: Rider auth middleware
            'mobile.rider' => MobileRiderAuth::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(function ($request, $throwable) {
            return $request->is('api/*') || $request->expectsJson();
        });
    })
    ->withProviders([
        TenancyServiceProvider::class,
    ])
    ->create();
