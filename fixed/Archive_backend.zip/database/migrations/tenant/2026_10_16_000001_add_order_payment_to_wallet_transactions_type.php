<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::connection('tenant')->statement("
            ALTER TABLE wallet_transactions
            MODIFY COLUMN type ENUM(
                'deposit',
                'invoice_payment',
                'refund',
                'manual_adjustment',
                'order_payment'
            ) NOT NULL
        ");
    }

    public function down(): void
    {
        // Convert any order_payment rows to manual_adjustment before shrinking the enum,
        // so existing data isn't truncated silently on rollback.
        DB::connection('tenant')
            ->table('wallet_transactions')
            ->where('type', 'order_payment')
            ->update(['type' => 'manual_adjustment']);

        DB::connection('tenant')->statement("
            ALTER TABLE wallet_transactions
            MODIFY COLUMN type ENUM(
                'deposit',
                'invoice_payment',
                'refund',
                'manual_adjustment'
            ) NOT NULL
        ");
    }
};
