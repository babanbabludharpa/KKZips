<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_number_sequences', function (Blueprint $table) {
            $table->unsignedBigInteger('branch_id');
            $table->char('financial_year', 4); // e.g. "2627"
            $table->unsignedInteger('last_number')->default(0);
            $table->timestamps();

            $table->primary(['branch_id', 'financial_year']);
        });

        Schema::table('orders', function (Blueprint $table) {
            // nullable initially so existing rows don't break; backfill separately if needed
            $table->string('order_number', 20)->nullable()->unique()->after('id');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn('order_number');
        });

        Schema::dropIfExists('order_number_sequences');
    }
};
