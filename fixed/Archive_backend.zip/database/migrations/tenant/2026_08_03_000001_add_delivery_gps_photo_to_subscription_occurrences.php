<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Run this migration inside each tenant DB (tenant-specific migration path
// per your tenancy.php: database/migrations/tenant). Since every tenant has
// a separate database, this needs to run per-tenant, not once centrally --
// use `php artisan tenants:migrate` (stancl/tenancy's command) rather than
// the plain `migrate` command.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            // Placed after existing delivery_note column (confirmed present
            // in the described schema) -- delivery_note already exists and
            // is reused for the one-by-one flow's optional note, no new
            // note column needed.
            $table->decimal('delivery_lat', 10, 7)->nullable()->after('delivery_note');
            $table->decimal('delivery_lng', 10, 7)->nullable()->after('delivery_lat');
            $table->string('delivery_photo_path')->nullable()->after('delivery_lng');
        });
    }

    public function down(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            $table->dropColumn(['delivery_lat', 'delivery_lng', 'delivery_photo_path']);
        });
    }
};
