<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ─────────────────────────────────────────────────────────────────────────
// FREE GIFTS — flags.
//  product_variants.is_gift → gift variants are invisible to every
//      customer-facing catalog and can NEVER be ordered manually.
//  order_items.is_gift + gift_tier_id → gift lines are born server-side
//      only (GiftService), at ₹0, and are traceable to the granting tier.
// ─────────────────────────────────────────────────────────────────────────

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->boolean('is_gift')->default(false)->after('is_active');
            $table->index('is_gift');
        });

        Schema::table('order_items', function (Blueprint $table) {
            $table->boolean('is_gift')->default(false)->after('line_total');
            $table->foreignId('gift_tier_id')
                ->nullable()
                ->after('is_gift')
                ->constrained('gift_tiers')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->dropConstrainedForeignId('gift_tier_id');
            $table->dropColumn('is_gift');
        });

        Schema::table('product_variants', function (Blueprint $table) {
            $table->dropIndex(['is_gift']);
            $table->dropColumn('is_gift');
        });
    }
};
