<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Creates the app_layouts table inside the TENANT database, including the
 * theme_config JSON column from the start (previously added by a separate
 * follow-up migration — merged here since app_layouts is the only table
 * this touches and there's no reason to keep them split).
 *
 * Run via: php artisan tenants:migrate
 *
 * `tenant_id` is intentionally NOT stored here — each tenant DB is isolated,
 * so the tenant is implicit. The broadcast channel name uses tenant('id')
 * resolved at runtime by the controller/event, NOT a stored column.
 *
 * theme_config stores per-tenant mobile theme: primary_color, accent_color,
 * logo_url, brand_name, font_family. Completely separate from the web theme
 * config (which lives in web_layouts.theme_config).
 *
 * If you previously created an `app_layouts` table without these columns,
 * the upgrade branch below fills in whatever's missing, theme_config
 * included.
 */
return new class extends Migration
{
    /** Columns this migration adds when upgrading an existing app_layouts table. */
    private const ADDED_COLUMNS = [
        'theme_config',
        'is_draft',
        'scheduled_at',
        'expires_at',
        'created_by',
        'published_at',
    ];

    public function up(): void
    {
        if (Schema::hasTable('app_layouts')) {
            $this->addMissingColumns();

            return;
        }

        $this->createAppLayoutsTable();
    }

    public function down(): void
    {
        if (! Schema::hasTable('app_layouts')) {
            return;
        }

        Schema::table('app_layouts', function (Blueprint $table) {
            foreach (self::ADDED_COLUMNS as $column) {
                if (Schema::hasColumn('app_layouts', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }

    private function addMissingColumns(): void
    {
        Schema::table('app_layouts', function (Blueprint $table) {
            $this->addThemeConfigColumn($table);
            $this->addDraftColumns($table);
            $this->addPublishingColumns($table);
        });
    }

    private function addThemeConfigColumn(Blueprint $table): void
    {
        if (! Schema::hasColumn('app_layouts', 'theme_config')) {
            $table->json('theme_config')->nullable()->after('components');
        }
    }

    private function addDraftColumns(Blueprint $table): void
    {
        if (! Schema::hasColumn('app_layouts', 'is_draft')) {
            $table->boolean('is_draft')->default(false)->after('is_active');
        }
        if (! Schema::hasColumn('app_layouts', 'scheduled_at')) {
            $table->timestamp('scheduled_at')->nullable()->after('is_draft');
        }
        if (! Schema::hasColumn('app_layouts', 'expires_at')) {
            $table->timestamp('expires_at')->nullable()->after('scheduled_at');
        }
    }

    private function addPublishingColumns(Blueprint $table): void
    {
        if (! Schema::hasColumn('app_layouts', 'created_by')) {
            $table->unsignedBigInteger('created_by')->nullable()->after('expires_at');
        }
        if (! Schema::hasColumn('app_layouts', 'published_at')) {
            $table->timestamp('published_at')->nullable()->after('created_by');
        }
    }

    private function createAppLayoutsTable(): void
    {
        Schema::create('app_layouts', function (Blueprint $table) {
            $table->id();
            $table->string('version_name');
            $table->json('components');
            $table->json('theme_config')->nullable();
            $table->boolean('is_active')->default(false);
            $table->boolean('is_draft')->default(false);
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();

            $table->index('is_active');
            $table->index('created_at');
        });
    }
};
