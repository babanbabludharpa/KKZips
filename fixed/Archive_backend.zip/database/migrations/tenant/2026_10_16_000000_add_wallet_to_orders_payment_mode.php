<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            ALTER TABLE orders
            MODIFY payment_mode ENUM('cod','online','wallet') NOT NULL
        ");
    }

    public function down(): void
    {
        // Before reverting the enum, move any wallet orders to online so no data is lost
        DB::table('orders')->where('payment_mode', 'wallet')->update(['payment_mode' => 'online']);

        DB::statement("
            ALTER TABLE orders
            MODIFY payment_mode ENUM('cod','online') NOT NULL
        ");
    }
};