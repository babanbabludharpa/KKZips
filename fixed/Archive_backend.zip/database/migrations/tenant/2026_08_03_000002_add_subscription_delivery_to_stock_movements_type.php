<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

// DeliveryConfirmationService::markDelivered() writes
// type = 'subscription_delivery', but the enum only defines
// ('inward','outward','transfer','return','order'). This value has never
// successfully been written -- every prior request crashed earlier, on
// the inventory.quantity underflow, before reaching this insert. Fixing
// that bug without this migration just moves the failure here.
//
// ASSUMPTION: 'subscription_delivery' is the correct, permanent label for
// this movement type (distinct from 'outward', which is presumably used
// elsewhere for non-subscription stock-out). If subscription deliveries
// should actually just be recorded as 'outward' for reporting
// consistency, don't run this migration -- instead change the string in
// DeliveryConfirmationService to 'outward' and skip the schema change
// entirely. I don't know which one matches your reporting expectations.
//
// Laravel's Schema Blueprint doesn't reliably alter MySQL enums through
// doctrine/dbal (it doesn't model enum as a first-class type), so this
// uses a raw ALTER TABLE instead.
return new class extends Migration
{
    public function up(): void
    {
        DB::statement(
            'ALTER TABLE stock_movements MODIFY COLUMN type '.
            "ENUM('inward','outward','transfer','return','order','subscription_delivery') NOT NULL"
        );
    }

    public function down(): void
    {
        // Fails if any row already has type = 'subscription_delivery' --
        // reassign those rows to another type before rolling back.
        DB::statement(
            'ALTER TABLE stock_movements MODIFY COLUMN type '.
            "ENUM('inward','outward','transfer','return','order') NOT NULL"
        );
    }
};
