<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            // nullable initially -- backfill below, then tighten to NOT NULL
            // in a follow-up migration once backfill is verified.
            $table->unsignedBigInteger('branch_id')->nullable()->after('customer_id');
            $table->string('invoice_number', 40)->nullable()->unique()->after('branch_id');
            $table->index(['branch_id', 'status']);
        });

        Schema::table('subscription_occurrences', function (Blueprint $table) {
            $table->unsignedBigInteger('branch_id')->nullable()->after('subscription_item_id');
            $table->index(['branch_id', 'occurrence_date']);
            $table->index(['branch_id', 'status']);
        });

        // Backfill from current subscriptions.branch_id. NOTE: this trusts
        // that branch has never changed on a subscription after creation.
        // If subscription branch transfer is/was possible, this backfill
        // will misattribute historical rows for any transferred subscription
        // -- confirm that before relying on this backfill for anything
        // audit-facing (e.g. reprinting old invoices' branch/GSTIN).

        // occurrences: occurrence -> subscription_item -> subscription.branch_id
        DB::statement('
            UPDATE subscription_occurrences so
            JOIN subscription_items si ON si.id = so.subscription_item_id
            JOIN subscriptions s ON s.id = si.subscription_id
            SET so.branch_id = s.branch_id
        ');

        // invoices: no direct subscription link, so go through any one of its
        // own occurrences (all occurrences on a given invoice already share
        // one branch under the new branch-only generation rule -- pre-existing
        // invoices generated before that rule are the one case this could be
        // ambiguous for; verify none of those mix branches before trusting this).
        DB::statement('
            UPDATE invoices i
            JOIN subscription_occurrences so ON so.invoice_id = i.id
            JOIN subscription_items si ON si.id = so.subscription_item_id
            JOIN subscriptions s ON s.id = si.subscription_id
            SET i.branch_id = s.branch_id
        ');
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropIndex(['branch_id', 'status']);
            $table->dropColumn(['branch_id', 'invoice_number']);
        });

        Schema::table('subscription_occurrences', function (Blueprint $table) {
            $table->dropIndex(['branch_id', 'occurrence_date']);
            $table->dropIndex(['branch_id', 'status']);
            $table->dropColumn('branch_id');
        });
    }
};
