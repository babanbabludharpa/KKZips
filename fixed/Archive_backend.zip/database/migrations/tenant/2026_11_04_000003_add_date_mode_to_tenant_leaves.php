<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_leaves', function (Blueprint $table) {
            if (! Schema::hasColumn('tenant_leaves', 'date_mode')) {
                $table->enum('date_mode', ['single', 'range', 'recurring'])
                    ->default('single')
                    ->after('end_date');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_leaves', function (Blueprint $table) {
            if (Schema::hasColumn('tenant_leaves', 'date_mode')) {
                $table->dropColumn('date_mode');
            }
        });
    }
};
