<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_qty_overrides', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_item_id')->constrained('subscription_items')->cascadeOnDelete();
            $table->date('date_from');
            $table->date('date_to'); // single-day override: date_from == date_to
            $table->unsignedInteger('qty'); // replaces default_qty / qty_by_day for the covered range
            $table->enum('initiated_by', ['customer', 'admin']);
            $table->string('reason')->nullable();
            $table->timestamps();

            $table->index(['subscription_item_id', 'date_from', 'date_to'], 'sub_qty_ovr_item_range_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_qty_overrides');
    }
};
