<?php

/**
 * ─────────────────────────────────────────────────────────────────────────
 * Migration: add delivery confirmation fields to orders table
 *
 * Path: database/migrations/tenant/2025_01_01_000005_add_delivery_confirmation_to_orders.php
 *
 * Adds 3 columns for delivery proof:
 *   - delivery_photo_path (varchar) — path to the delivery confirmation photo
 *   - delivery_lat (decimal)        — rider's GPS latitude at delivery
 *   - delivery_lng (decimal)        — rider's GPS longitude at delivery
 *
 * Run: php artisan tenants:migrate --path=database/migrations/tenant
 *   OR (if you run tenant migrations differently):
 *      php artisan migrate --path=database/migrations/tenant
 * ─────────────────────────────────────────────────────────────────────────
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        $connection = $this->getConnectionName();
        $schema = Schema::connection($connection);

        if (! $schema->hasTable('orders')) {
            return;
        }

        $schema->table('orders', function (Blueprint $table) use ($schema) {
            if (! $schema->hasColumn('orders', 'delivery_photo_path')) {
                $table->string('delivery_photo_path')->nullable()->after('delivered_at');
            }
            if (! $schema->hasColumn('orders', 'delivery_lat')) {
                $table->decimal('delivery_lat', 10, 8)->nullable()->after('delivery_photo_path');
            }
            if (! $schema->hasColumn('orders', 'delivery_lng')) {
                $table->decimal('delivery_lng', 11, 8)->nullable()->after('delivery_lat');
            }
        });
    }

    public function down(): void
    {
        $connection = $this->getConnectionName();
        $schema = Schema::connection($connection);

        if (! $schema->hasTable('orders')) {
            return;
        }

        $schema->table('orders', function (Blueprint $table) use ($schema) {
            foreach (['delivery_photo_path', 'delivery_lat', 'delivery_lng'] as $col) {
                if ($schema->hasColumn('orders', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }

    private function getConnectionName(): string
    {
        $connections = config('database.connections', []);

        return isset($connections['tenant'])
            ? 'tenant'
            : config('database.default', 'mysql');
    }
};
