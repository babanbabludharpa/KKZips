<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->enum('subscription_start_policy', ['next_day_only', 'same_day_slot_wise'])
                  ->default('next_day_only')
                  ->after('subscription_cutoff_restrict_admin');

            $table->integer('same_day_lead_time_minutes')
                  ->default(120)
                  ->after('subscription_start_policy');

            $table->time('rider_assignment_time')
                  ->default('21:00:00')
                  ->after('same_day_lead_time_minutes');

            $table->date('last_assignment_run')
                  ->nullable()
                  ->after('rider_assignment_time');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'subscription_start_policy',
                'same_day_lead_time_minutes',
                'rider_assignment_time',
                'last_assignment_run',
            ]);
        });
    }
};
