<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('change_masters', function ($table) {
            $table->dropIndex(['flag']);
        });

        DB::statement("
            ALTER TABLE `change_masters`
            MODIFY `flag` ENUM('1', '2') NOT NULL
        ");

        Schema::table('change_masters', function ($table) {
            $table->index('flag');
        });
    }

    public function down(): void
    {
        Schema::table('change_masters', function ($table) {
            $table->dropIndex(['flag']);
        });

        DB::statement('
            ALTER TABLE `change_masters`
            MODIFY `flag` TINYINT(3) UNSIGNED NOT NULL
        ');

        Schema::table('change_masters', function ($table) {
            $table->index('flag');
        });
    }
};
