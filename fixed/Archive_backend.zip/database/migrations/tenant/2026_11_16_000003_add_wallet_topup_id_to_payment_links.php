<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payment_links', function (Blueprint $table) {
            if (! Schema::hasColumn('payment_links', 'wallet_topup_id')) {
                $table->unsignedBigInteger('wallet_topup_id')->nullable()->after('customer_id')->index();
            }
        });
    }

    public function down(): void
    {
        Schema::table('payment_links', function (Blueprint $table) {
            if (Schema::hasColumn('payment_links', 'wallet_topup_id')) {
                $table->dropColumn('wallet_topup_id');
            }
        });
    }
};
