<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->boolean('available_for_order')
                ->default(true)
                ->after('is_coupon_eligible');

            $table->boolean('available_for_subscription')
                ->default(false)
                ->after('available_for_order');

            $table->index(['available_for_order', 'is_active'], 'pv_order_active_idx');
            $table->index(['available_for_subscription', 'is_active'], 'pv_sub_active_idx');
        });
    }

    public function down(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->dropIndex('pv_order_active_idx');
            $table->dropIndex('pv_sub_active_idx');
            $table->dropColumn(['available_for_order', 'available_for_subscription']);
        });
    }
};
