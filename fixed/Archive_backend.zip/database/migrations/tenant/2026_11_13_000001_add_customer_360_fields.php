<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->boolean('dnd')->default(false)->after('status');
            $table->decimal('warning_limit', 10, 2)->nullable()->after('dnd');
            $table->decimal('suspension_limit', 10, 2)->nullable()->after('warning_limit');
        });

        Schema::create('customer_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('added_by')->constrained('users');
            $table->text('note');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_notes');
        Schema::table('customers', function (Blueprint $table) {
            $table->dropColumn(['dnd', 'warning_limit', 'suspension_limit']);
        });
    }
};
