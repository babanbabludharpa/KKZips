<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Creates the web_layouts table inside the TENANT database, including all
 * customization columns and soft-delete support from the start (previously
 * split across a create-table migration and a separate add-columns
 * migration — merged here since web_layouts is the only table either
 * touches, and there's no reason to keep them split).
 *
 * Run via: php artisan tenants:migrate
 */
return new class extends Migration
{
    /** Columns this migration adds when upgrading an existing web_layouts table. */
    private const ADDED_COLUMNS = [
        'navigation_config',
        'footer_config',
        'product_display_config',
        'custom_pages',
        'deleted_at',
    ];

    public function up(): void
    {
        if (Schema::hasTable('web_layouts')) {
            $this->addMissingColumns();

            return;
        }

        $this->createWebLayoutsTable();
    }

    public function down(): void
    {
        if (! Schema::hasTable('web_layouts')) {
            return;
        }

        Schema::table('web_layouts', function (Blueprint $table) {
            foreach (self::ADDED_COLUMNS as $column) {
                if (Schema::hasColumn('web_layouts', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }

    private function addMissingColumns(): void
    {
        Schema::table('web_layouts', function (Blueprint $table) {
            $this->addNavigationAndFooterColumns($table);
            $this->addProductDisplayColumn($table);
            $this->addCustomPagesColumn($table);
            $this->addSoftDeletesColumn($table);
        });
    }

    private function addNavigationAndFooterColumns(Blueprint $table): void
    {
        if (! Schema::hasColumn('web_layouts', 'navigation_config')) {
            $table->json('navigation_config')->nullable()->after('theme_config');
        }
        if (! Schema::hasColumn('web_layouts', 'footer_config')) {
            $table->json('footer_config')->nullable()->after('navigation_config');
        }
    }

    private function addProductDisplayColumn(Blueprint $table): void
    {
        if (! Schema::hasColumn('web_layouts', 'product_display_config')) {
            $table->json('product_display_config')->nullable()->after('footer_config');
        }
    }

    private function addCustomPagesColumn(Blueprint $table): void
    {
        if (! Schema::hasColumn('web_layouts', 'custom_pages')) {
            $table->json('custom_pages')->nullable()->after('layout_components');
        }
    }

    private function addSoftDeletesColumn(Blueprint $table): void
    {
        if (! Schema::hasColumn('web_layouts', 'deleted_at')) {
            $table->softDeletes()->after('updated_at');
        }
    }

    private function createWebLayoutsTable(): void
    {
        Schema::create('web_layouts', function (Blueprint $table) {
            $table->id();
            $table->string('version_name');
            $table->json('theme_config');
            $table->json('navigation_config')->nullable();
            $table->json('footer_config')->nullable();
            $table->json('product_display_config')->nullable();
            $table->json('layout_components');
            $table->json('custom_pages')->nullable();
            $table->boolean('is_active')->default(false);
            $table->boolean('is_draft')->default(false);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
};
