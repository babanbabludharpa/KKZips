<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('warehouses', function (Blueprint $table) {
            $table->unsignedBigInteger('state_id')->nullable()->after('state');
            $table->unsignedBigInteger('city_id')->nullable()->after('city');
        });

        // Populate IDs from existing string values (they were stored as numeric strings)
        DB::statement('UPDATE warehouses SET state_id = CAST(state AS UNSIGNED) WHERE state REGEXP "^[0-9]+$"');
        DB::statement('UPDATE warehouses SET city_id = CAST(city AS UNSIGNED) WHERE city REGEXP "^[0-9]+$"');

        // Populate display names from related tables
        DB::statement('UPDATE warehouses w JOIN states s ON s.id = w.state_id SET w.state = s.name WHERE w.state_id IS NOT NULL');
        DB::statement('UPDATE warehouses w JOIN cities c ON c.id = w.city_id SET w.city = c.name WHERE w.city_id IS NOT NULL');

        // Now add FK constraints
        Schema::table('warehouses', function (Blueprint $table) {
            $table->foreign('state_id')->references('id')->on('states')->nullOnDelete();
            $table->foreign('city_id')->references('id')->on('cities')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('warehouses', function (Blueprint $table) {
            $table->dropForeign(['state_id']);
            $table->dropForeign(['city_id']);
            $table->dropColumn(['state_id', 'city_id']);
        });
    }
};
