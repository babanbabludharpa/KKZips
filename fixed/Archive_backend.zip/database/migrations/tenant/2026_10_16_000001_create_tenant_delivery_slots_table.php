<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenant_delivery_slots', function (Blueprint $table) {
            $table->id();
            // No tenant_id foreign key here because we are already INSIDE the tenant database
            $table->string('name', 50); 
            $table->time('start_time');
            $table->time('end_time');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_delivery_slots');
    }
};
