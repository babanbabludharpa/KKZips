<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customer_addresses', function (Blueprint $table) {
            $table->unsignedBigInteger('zone_id')->nullable()->after('branch_id');
            $table->foreign('zone_id')
                  ->references('id')
                  ->on('branch_service_zones')
                  ->nullOnDelete();
            $table->index('zone_id');
        });
    }

    public function down(): void
    {
        Schema::table('customer_addresses', function (Blueprint $table) {
            $table->dropForeign(['zone_id']);
            $table->dropIndex(['zone_id']);
            $table->dropColumn('zone_id');
        });
    }
};
