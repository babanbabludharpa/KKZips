
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('warehouses', function (Blueprint $table) {
            $table->dropColumn(['city', 'state']);
        });

        Schema::table('branches', function (Blueprint $table) {
            $table->dropColumn(['city', 'state']);
        });
    }

    public function down(): void
    {
        Schema::table('warehouses', function (Blueprint $table) {
            $table->string('city', 100)->nullable()->after('city_id');
            $table->string('state', 100)->nullable()->after('state_id');
        });

        Schema::table('branches', function (Blueprint $table) {
            $table->string('city', 100)->nullable()->after('city_id');
            $table->string('state', 100)->nullable()->after('state_id');
        });
    }
};
