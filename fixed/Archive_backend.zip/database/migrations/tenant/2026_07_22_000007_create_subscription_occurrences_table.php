<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_occurrences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_item_id')->constrained('subscription_items');
            $table->date('occurrence_date');
            $table->unsignedInteger('qty');
            $table->decimal('unit_price_snapshot', 10, 2); // frozen at generation time, never a live reference

            $table->enum('status', [
                'scheduled', 'customer_paused', 'admin_paused', 'holiday_skipped',
                'out_for_delivery', 'delivered', 'not_delivered', 'billed',
            ])->default('scheduled');

            $table->enum('skip_source', ['customer', 'admin', 'weekly_off', 'holiday'])->nullable();

            $table->enum('not_delivered_reason', [
                'customer_unavailable', 'customer_refused', 'stockout',
                'vehicle_breakdown', 'address_not_found', 'other',
            ])->nullable();
            $table->text('not_delivered_note')->nullable(); // mainly used when reason = other

            $table->foreignId('delivery_boy_id')->nullable()->constrained('users');
            $table->timestamp('delivered_at')->nullable();
            $table->text('delivery_note')->nullable();

            $table->foreignId('invoice_id')->nullable()->constrained('invoices');
            $table->timestamps();

            // Idempotency guard for the generation job: one row per item per date, ever.
            $table->unique(['subscription_item_id', 'occurrence_date'], 'sub_occ_item_date_unique');
            $table->index(['occurrence_date', 'status']);
            $table->index(['invoice_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_occurrences');
    }
};
