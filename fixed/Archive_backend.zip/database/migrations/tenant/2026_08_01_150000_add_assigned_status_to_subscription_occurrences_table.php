<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Adds 'assigned' between 'scheduled' and 'out_for_delivery'.
     * 'assigned'        = a rider has been designated responsible (set by
     *                      DeliveryAssignmentService::assign()).
     * 'out_for_delivery' = the rider has actually picked it up (set by the
     *                      new DeliveryAssignmentService::pickup()).
     */
    public function up(): void
    {
        DB::statement("ALTER TABLE subscription_occurrences MODIFY status
            ENUM('scheduled','assigned','customer_paused','admin_paused','holiday_skipped','out_for_delivery','delivered','not_delivered','billed')
            NOT NULL DEFAULT 'scheduled'");
    }

    /**
     * NOTE: this rollback will fail with a truncation/constraint error if
     * any row currently has status = 'assigned' -- MySQL can't downgrade
     * an enum value that's still in use. Resolve those rows (move them to
     * 'scheduled' or 'out_for_delivery' as appropriate) before rolling
     * back, e.g.:
     *   UPDATE subscription_occurrences SET status = 'scheduled' WHERE status = 'assigned';
     */
    public function down(): void
    {
        DB::statement("ALTER TABLE subscription_occurrences MODIFY status
            ENUM('scheduled','customer_paused','admin_paused','holiday_skipped','out_for_delivery','delivered','not_delivered','billed')
            NOT NULL DEFAULT 'scheduled'");
    }
};
