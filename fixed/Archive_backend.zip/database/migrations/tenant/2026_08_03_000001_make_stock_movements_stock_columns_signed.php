<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// opening_stock/closing_stock mirror inventory.quantity and are written
// from the same DeliveryConfirmationService::markDelivered() call. Once
// quantity can go negative (see the inventory migration), these need to
// accept negative values too, or the insert crashes exactly like the
// original inventory.quantity bug did, just in this table instead.
//
// `in` and `out` are intentionally left unsigned int -- they represent
// movement counts (always >= 0), not stock levels, and have no reason to
// go negative.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('stock_movements', function (Blueprint $table) {
            $table->integer('opening_stock')->change();
            $table->integer('closing_stock')->change();
        });
    }

    public function down(): void
    {
        // Will fail if any existing row already has a negative value in
        // either column -- clean those up before rolling back.
        Schema::table('stock_movements', function (Blueprint $table) {
            $table->unsignedInteger('opening_stock')->change();
            $table->unsignedInteger('closing_stock')->change();
        });
    }
};
