<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Adds the two columns manual wallet adjustments need that topup-driven
// credits don't: a human-entered reason (cash/cheque handed over, refund
// note, correction, etc.) and who entered it. Existing rows (Razorpay
// topups, invoice payments) will have both NULL -- that's correct, not a
// gap to backfill: those already have an audit trail via
// reference_type/reference_id + razorpay_payment_id on wallet_topups, so
// forcing a remark/actor onto rows that were never manually keyed in would
// just be noise.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('wallet_transactions', function (Blueprint $table) {
            $table->string('remark')->nullable()->after('reference_id');
            // References the admin `users` table (central or tenant --
            // whichever connection `wallet_transactions` itself lives on;
            // confirm this matches, same class of mistake as the
            // tenants-vs-tenant_profiles mixup earlier in this thread).
            // No FK constraint added deliberately: admin users and
            // customers may live in different tables/guards in this app,
            // and the migration for the actual `users` table isn't in
            // front of me to confirm the right target -- add the FK
            // yourself once you've verified it, don't skip it silently.
            $table->unsignedBigInteger('added_by')->nullable()->after('remark');
        });
    }

    public function down(): void
    {
        Schema::table('wallet_transactions', function (Blueprint $table) {
            $table->dropColumn(['remark', 'added_by']);
        });
    }
};
