<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ASSUMPTION: sms_username / sms_password / sms_sender_id already live on
// the CENTRAL `tenants` table (see AuthController::formatTenantUser() and
// the central-cache-store precedent for tenant-level config). If those
// three columns actually live somewhere else -- a separate
// `tenant_profiles` table, or a tenant-connection migration -- this
// migration targets the wrong schema and must be moved before running.
//
// Placement matters with stancl/tenancy: this file must sit in a path
// that runs against the CENTRAL connection (typically
// database/migrations/, run via `php artisan migrate`), NOT
// database/migrations/tenant/ (which runs per-tenant via
// `php artisan tenants:migrate`). Putting it in the tenant path would
// try to add this column inside every tenant's own database instead.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // Defaults to true so existing tenant_profiles with working SMS
            // credentials aren't silently switched off the moment this
            // column starts being read. Placed after sms_sender_id purely
            // for readability when inspecting the schema -- adjust the
            // ->after() target if that column has a different name on
            // your actual table.
            $table->boolean('sms_enabled')
                ->default(true)
                ->after('sms_sender_id');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn('sms_enabled');
        });
    }
};
