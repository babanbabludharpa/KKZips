<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Laravel's schema builder can't modify an ENUM's value list directly
        // on MySQL/MariaDB - raw SQL is required. Existing rows are untouched
        // since we're only appending a new allowed value, not reordering or
        // removing any.
        DB::statement("
            ALTER TABLE subscription_items
            MODIFY COLUMN schedule_type
            ENUM('daily','alternate','custom_days','custom_dates','weekly')
            NOT NULL
        ");
    }

    public function down(): void
    {
        // Reverting requires no rows currently using 'weekly', or this will
        // fail / silently truncate depending on SQL mode. Caller is
        // responsible for migrating any 'weekly' rows back to 'custom_days'
        // before rolling back, if that's ever needed.
        DB::statement("
            ALTER TABLE subscription_items
            MODIFY COLUMN schedule_type
            ENUM('daily','alternate','custom_days','custom_dates')
            NOT NULL
        ");
    }
};
