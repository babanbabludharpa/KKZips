<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_delivery_slots', function (Blueprint $table) {
            if (! Schema::hasColumn('tenant_delivery_slots', 'cutoff_time')) {
                $table->time('cutoff_time')->nullable()->after('end_time');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_delivery_slots', function (Blueprint $table) {
            if (Schema::hasColumn('tenant_delivery_slots', 'cutoff_time')) {
                $table->dropColumn('cutoff_time');
            }
        });
    }
};
