<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            $table->enum('assignment_type', ['preferred', 'substitute', 'manual_override'])
                  ->nullable()
                  ->after('delivery_boy_id');

            $table->enum('assigned_by', ['system', 'admin'])
                  ->nullable()
                  ->after('assignment_type');

            $table->timestamp('assigned_at')
                  ->nullable()
                  ->after('assigned_by');
        });
    }

    public function down(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            $table->dropColumn(['assignment_type', 'assigned_by', 'assigned_at']);
        });
    }
};
