<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenant_holidays', function (Blueprint $table) {
            $table->id();
            $table->date('date');
            $table->string('description')->nullable();
            $table->foreignId('product_category_id')->nullable()->constrained('categories'); // null = all products
            $table->timestamps();

            $table->unique(['date', 'product_category_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_holidays');
    }
};
