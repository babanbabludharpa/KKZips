<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            if (! Schema::hasColumn('subscription_occurrences', 'leave_id')) {
                $table->unsignedBigInteger('leave_id')->nullable()->after('id')->index();
            }
            if (! Schema::hasColumn('subscription_occurrences', 'leave_previous_status')) {
                $table->string('leave_previous_status', 30)->nullable()->after('leave_id');
            }
            if (! Schema::hasColumn('subscription_occurrences', 'leave_cancellation_reason')) {
                $table->text('leave_cancellation_reason')->nullable()->after('leave_previous_status');
            }
        });
    }

    public function down(): void
    {
        Schema::table('subscription_occurrences', function (Blueprint $table) {
            foreach (['leave_id', 'leave_previous_status', 'leave_cancellation_reason'] as $c) {
                if (Schema::hasColumn('subscription_occurrences', $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};
