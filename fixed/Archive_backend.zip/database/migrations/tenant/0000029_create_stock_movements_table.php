<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();
            $table->foreignId('branch_id')->constrained('branches')->cascadeOnDelete();

            // what triggered this row
            // inward, outward, transfer, return, order
            $table->enum('type', ['inward', 'outward', 'transfer', 'return', 'order']);

            // running balance, finalized as true day-end only on the last row of the day
            $table->unsignedInteger('opening_stock');
            $table->unsignedInteger('in')->default(0);
            $table->unsignedInteger('out')->default(0);
            $table->unsignedInteger('closing_stock');

            $table->date('transaction_date');

            // links the two rows of a transfer (outward@source + inward@destination),
            // or links back to the stock_request / order that triggered this row
            $table->string('reference_id', 64)->nullable();

            // only meaningful when type = inward
            $table->date('expiry_date')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['product_variant_id', 'branch_id', 'transaction_date'], 'stock_movements_variant_branch_date_idx');
            $table->index('reference_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_movements');
    }
};
