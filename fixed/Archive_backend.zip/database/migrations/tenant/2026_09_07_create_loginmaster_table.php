<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('login_masters', function (Blueprint $table) {
            $table->id();
            $table->string('username', 30);            // was lm_memberid
            $table->string('ip_address', 50);           // was lm_ipaddress
            $table->dateTime('logged_in_at');            // was lm_date + lm_time combined
            $table->dateTime('logged_out_at')->nullable(); // was lm_logouttime (NOT NULL time-only sentinel)
            // NOTE: nullable datetime replaces the legacy NOT NULL time-only
            // sentinel ('00:00:00' = "still logged in"). A currently-active
            // session is now simply WHERE logged_out_at IS NULL -- no
            // sentinel value to remember or special-case, and no midnight
            // rollover bug from a bare `time` column.

            $table->index('username');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('login_masters');
    }
};
