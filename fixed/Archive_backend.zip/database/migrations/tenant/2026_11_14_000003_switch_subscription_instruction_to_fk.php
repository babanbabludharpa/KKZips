
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            if (Schema::hasColumn('subscriptions', 'delivery_instruction')) {
                $table->dropColumn('delivery_instruction');
            }

            if (!Schema::hasColumn('subscriptions', 'delivery_instruction_id')) {
                $table->foreignId('delivery_instruction_id')
                    ->nullable()
                    ->constrained('delivery_instructions')
                    ->nullOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            if (Schema::hasColumn('subscriptions', 'delivery_instruction_id')) {
                $table->dropForeign(['delivery_instruction_id']);
                $table->dropColumn('delivery_instruction_id');
            }

            if (!Schema::hasColumn('subscriptions', 'delivery_instruction')) {
                $table->string('delivery_instruction', 255)->nullable();
            }
        });
    }
};
