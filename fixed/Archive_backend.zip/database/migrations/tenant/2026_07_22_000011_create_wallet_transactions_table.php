<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallet_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('customers');
            $table->enum('type', ['deposit', 'invoice_payment', 'refund', 'manual_adjustment']);
            $table->decimal('amount', 10, 2); // negative for debits
            $table->decimal('balance_after', 10, 2);
            $table->string('reference_type')->nullable(); // e.g. 'invoice'
            $table->unsignedBigInteger('reference_id')->nullable(); // e.g. invoices.id
            $table->timestamps();

            $table->index(['customer_id', 'created_at']);
            $table->index(['reference_type', 'reference_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wallet_transactions');
    }
};
