<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_variant_media', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();

            $table->string('type', 10);                      // 'image' | 'video'
            $table->string('path');                          // FILENAME ONLY — full public URL is
                                                                 // rebuilt by ProductVariantMedia::getUrlAttribute(),
                                                                 // same convention as the legacy `image` column
            $table->string('original_name')->nullable();     // user's filename, for display
            $table->string('mime_type', 100)->nullable();
            $table->unsignedBigInteger('size')->default(0);  // bytes
            $table->unsignedInteger('sort_order')->default(0);

            $table->timestamps();

            // Gallery queries: all media of a variant, grouped by type, in order.
            $table->index(['product_variant_id', 'type', 'sort_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_variant_media');
    }
};
