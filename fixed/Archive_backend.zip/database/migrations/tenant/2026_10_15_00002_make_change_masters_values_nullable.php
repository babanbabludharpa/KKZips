<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE `change_masters` MODIFY `previous_value` TEXT NULL');
        DB::statement('ALTER TABLE `change_masters` MODIFY `new_value`      TEXT NULL');
    }

    public function down(): void
    {
        // Reverting requires knowing the original type; adjust if it wasn't TEXT.
        DB::statement('ALTER TABLE `change_masters` MODIFY `previous_value` TEXT NOT NULL');
        DB::statement('ALTER TABLE `change_masters` MODIFY `new_value`      TEXT NOT NULL');
    }
};
