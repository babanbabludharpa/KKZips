<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
            $table->foreignId('subscription_occurrence_id')->constrained('subscription_occurrences');

            $table->string('description');
            $table->unsignedInteger('qty');
            $table->decimal('unit_price', 10, 2);
            $table->decimal('discount_percent', 5, 2)->default(0);
            $table->decimal('final_price', 10, 2);

            // Mirrors order_items tax pattern exactly - final field list pending
            // confirmation of the existing CGST/SGST vs IGST decision logic (Design V2 Open Item 3)
            $table->decimal('tax_rate_percent', 5, 2)->default(0);
            $table->decimal('taxable_value', 10, 2)->default(0);
            $table->enum('tax_type', ['cgst_sgst', 'igst'])->nullable();
            $table->decimal('cgst_amount', 10, 2)->default(0);
            $table->decimal('sgst_amount', 10, 2)->default(0);
            $table->decimal('igst_amount', 10, 2)->default(0);
            $table->decimal('tax_amount', 10, 2)->default(0);

            $table->decimal('line_total', 10, 2);
            $table->timestamps();

            $table->index('invoice_id');
            $table->unique('subscription_occurrence_id'); // an occurrence can only ever be billed once
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
    }
};
