<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->string('sms_username')->nullable()->after('razorpay_is_live');
            $table->string('sms_password')->nullable()->after('sms_username');
            $table->string('sms_sender_id', 10)->nullable()->after('sms_password');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn(['sms_username', 'sms_password', 'sms_sender_id']);
        });
    }
};
