<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->boolean('cod_enabled')->default(false)->after('id');
            $table->boolean('online_payment_enabled')->default(true)->after('cod_enabled');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn(['cod_enabled', 'online_payment_enabled']);
        });
    }
};
