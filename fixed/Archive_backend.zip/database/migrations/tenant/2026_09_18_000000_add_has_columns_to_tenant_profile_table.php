<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->boolean('has_orders')->default(true)->after('company_name');
            $table->boolean('has_subscriptions')->default(true)->after('has_orders');
            $table->boolean('has_wallet')->default(true)->after('has_subscriptions');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn(['has_orders', 'has_subscriptions', 'has_wallet']);
        });
    }
};
