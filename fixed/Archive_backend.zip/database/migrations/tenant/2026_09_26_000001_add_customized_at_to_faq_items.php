<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('faq_items', function (Blueprint $table) {
            // ★ Set when an admin manually edits this FAQ. The seeder
            //   skips rows where this is non-null, so tenant
            //   customizations aren't clobbered on the next re-seed.
            $table->timestamp('customized_at')->nullable()->after('metadata');
        });
    }

    public function down(): void
    {
        Schema::table('faq_items', function (Blueprint $table) {
            $table->dropColumn('customized_at');
        });
    }
};
