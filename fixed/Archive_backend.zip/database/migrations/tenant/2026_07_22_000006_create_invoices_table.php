<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('customers');
            $table->date('period_start');
            $table->date('period_end'); // admin-chosen end date at generation time

            $table->decimal('subtotal', 10, 2)->default(0);
            $table->decimal('cgst_total', 10, 2)->default(0);
            $table->decimal('sgst_total', 10, 2)->default(0);
            $table->decimal('igst_total', 10, 2)->default(0);
            $table->decimal('tax_total', 10, 2)->default(0);

            $table->decimal('manual_adjustment_amount', 10, 2)->default(0);
            $table->string('manual_adjustment_reason')->nullable();
            $table->foreignId('adjusted_by')->nullable()->constrained('users');

            $table->decimal('total', 10, 2)->default(0);
            $table->decimal('amount_paid', 10, 2)->default(0);
            $table->decimal('amount_due', 10, 2)->default(0);

            $table->enum('status', ['draft', 'generated', 'partially_paid', 'paid', 'overdue', 'cancelled'])
                ->default('draft');

            $table->timestamp('generated_at')->nullable();
            $table->foreignId('generated_by')->nullable()->constrained('users');

            $table->timestamp('cancelled_at')->nullable();
            $table->foreignId('cancelled_by')->nullable()->constrained('users');
            $table->string('cancellation_reason')->nullable();

            $table->timestamps();

            $table->index(['customer_id', 'status']);
            $table->index(['period_start', 'period_end']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoices');
    }
};
