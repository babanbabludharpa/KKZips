<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_pauses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_item_id')->constrained('subscription_items')->cascadeOnDelete();
            $table->date('date_from');
            $table->date('date_to'); // single-day pause: date_from == date_to
            $table->enum('initiated_by', ['customer', 'admin']);
            $table->string('reason')->nullable();
            $table->timestamps();

            $table->index(['subscription_item_id', 'date_from', 'date_to']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_pauses');
    }
};
