<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('support_messages', function (Blueprint $table) {
            // Report queries filter by conversation + order by created_at.
            $table->index(['conversation_id', 'created_at'], 'idx_support_msgs_conv_created');

            // Unmatched report filters by layer via JSON path.
            // MySQL 8 supports functional indexes on JSON.
            $table->index('matched_faq_id', 'idx_support_msgs_matched_faq');
        });

        Schema::table('support_conversations', function (Blueprint $table) {
            $table->index(['customer_id', 'status'], 'idx_support_conv_customer_status');
            $table->index('last_message_at', 'idx_support_conv_last_msg');
            $table->index('created_at', 'idx_support_conv_created');
        });
    }

    public function down(): void
    {
        Schema::table('support_messages', function (Blueprint $table) {
            $table->dropIndex('idx_support_msgs_conv_created');
            $table->dropIndex('idx_support_msgs_matched_faq');
        });

        Schema::table('support_conversations', function (Blueprint $table) {
            $table->dropIndex('idx_support_conv_customer_status');
            $table->dropIndex('idx_support_conv_last_msg');
            $table->dropIndex('idx_support_conv_created');
        });
    }
};
