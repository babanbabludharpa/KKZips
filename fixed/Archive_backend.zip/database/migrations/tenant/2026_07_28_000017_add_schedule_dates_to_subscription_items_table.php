<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_items', function (Blueprint $table) {
            // Distinct from schedule_days (which holds weekday ints 0-6 for
            // the recurring custom_days pattern). This holds literal ISO
            // date strings for schedule_type = 'custom_dates' - a genuinely
            // non-repeating, one-off set of deliveries, not a weekly rule.
            $table->json('schedule_dates')->nullable()->after('schedule_days');
        });

        // Widen the enum to add the new type alongside the existing ones.
        DB::statement("ALTER TABLE subscription_items MODIFY schedule_type ENUM('daily','alternate','custom_days','custom_dates') NOT NULL");
    }

    public function down(): void
    {
        Schema::table('subscription_items', function (Blueprint $table) {
            $table->dropColumn('schedule_dates');
        });

        DB::statement("ALTER TABLE subscription_items MODIFY schedule_type ENUM('daily','alternate','custom_days') NOT NULL");
    }
};
