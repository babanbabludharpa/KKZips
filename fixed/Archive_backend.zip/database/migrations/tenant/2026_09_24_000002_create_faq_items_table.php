<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('faq_items', function (Blueprint $table) {
            $table->id();

            // Groups translations of the same logical FAQ together.
            // A single English FAQ + its Hindi + Marathi translations
            // all share the same faq_group_id. NULL means standalone
            // (English-only) — do not treat NULL as "group of one"
            // in code, since that would break the uniqueness semantics.
            $table->unsignedBigInteger('faq_group_id')->nullable();

            $table->foreignId('collection_id')
                ->constrained('faq_collections')
                ->cascadeOnDelete();

            $table->char('language', 2)->default('en');

            $table->string('question', 500);
            $table->text('answer');

            // JSON arrays — MySQL 8 stores these natively as JSON,
            // so we can do JSON_CONTAINS / JSON_LENGTH queries later
            // without a separate table.
            $table->json('alternative_questions')->nullable();
            $table->json('keywords')->nullable();

            $table->integer('sort_order')->default(0);
            $table->boolean('is_active')->default(true);

            // Analytics — cheap to maintain, very useful signal.
            $table->unsignedInteger('view_count')->default(0);
            $table->unsignedInteger('helpful_count')->default(0);
            $table->unsignedInteger('not_helpful_count')->default(0);

            // Catch-all for future extensions without a migration:
            // {"source": "manual", "author_id": 5,
            //  "converted_from_unmatched_id": 12,
            //  "related_faq_ids": [3, 7]}
            $table->json('metadata')->nullable();

            $table->timestamps();

            $table->index(['collection_id', 'is_active', 'sort_order']);
            $table->index(['faq_group_id', 'language']);
            $table->index('language');
        });

        // Fulltext index — added separately because Blueprint's
        // fullText() is not supported on all engines/versions in the
        // same statement as column creation. Wrapped in try/catch so
        // a database that doesn't support fulltext (unlikely for
        // MySQL/Postgres, but possible on some MariaDB configs) does
        // not break the migration.
        try {
            Schema::table('faq_items', function (Blueprint $table) {
                $table->fullText(['question', 'answer'], 'faq_items_fulltext');
            });
        } catch (Throwable $e) {
            // Fulltext is an optimization, not a requirement. The
            // matcher falls back to LIKE + semantic search if absent.
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('faq_items');
    }
};
