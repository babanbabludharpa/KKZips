<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenant_leaves', function (Blueprint $table) {
            $table->id();
            $table->string('title', 120);
            $table->date('start_date');
            $table->date('end_date');
            $table->json('branch_ids')->nullable();    // null = all branches
            $table->json('slot_ids')->nullable();      // null = all slots (full-day)
            $table->text('reason');
            $table->string('recurrence_rule', 120)->nullable();
            $table->enum('status', ['active', 'cancelled'])->default('active');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('cancelled_by')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamps();

            $table->index(['start_date', 'end_date']);
            $table->index('status');
        });

        Schema::create('tenant_leave_occurrences', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('leave_id')->index();
            $table->unsignedBigInteger('occurrence_id')->nullable()->index();
            $table->enum('action', ['cancelled', 'reactivated', 'skipped_status']);
            $table->string('previous_status', 30)->nullable();
            $table->timestamps();
        });

        Schema::create('tenant_leave_audit_log', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('leave_id')->index();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->enum('action', ['created', 'updated', 'cancelled', 'reconciled']);
            $table->json('payload')->nullable();
            $table->json('counts')->nullable();
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_leave_audit_log');
        Schema::dropIfExists('tenant_leave_occurrences');
        Schema::dropIfExists('tenant_leaves');
    }
};
