<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            // Auto Renew toggle (Screenshot 8)
            $table->boolean('auto_renew')->default(true)->after('status');
            
            // Delivery instructions (Screenshot 8)
            $table->string('delivery_instruction', 255)->nullable()->after('auto_renew');
        });
    }

    public function down(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            $table->dropColumn(['auto_renew', 'delivery_instruction']);
        });
    }
};
