<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('delivery_assignments', function (Blueprint $table) {
            $table->id();
            $table->date('occurrence_date');
            $table->foreignId('delivery_boy_id')->constrained('users');
            $table->foreignId('subscription_occurrence_id')->constrained('subscription_occurrences');
            $table->unsignedInteger('sequence')->nullable(); // route order for the day
            $table->enum('status', ['pending', 'delivered', 'not_delivered', 'skipped'])->default('pending');
            $table->timestamps();

            $table->unique('subscription_occurrence_id'); // one assignment per occurrence
            $table->index(['occurrence_date', 'delivery_boy_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('delivery_assignments');
    }
};
