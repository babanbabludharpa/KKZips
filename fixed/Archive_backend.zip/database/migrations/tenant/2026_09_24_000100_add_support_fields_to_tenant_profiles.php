<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // ★ Support contact — single source of truth for the FAQ
            //   answers that reference it. Answer templates pull from
            //   these values at render time, so a tenant changing their
            //   phone number updates every FAQ that mentions it.
            $table->string('support_phone', 20)->nullable()->after('company_name');
            $table->string('support_email', 120)->nullable()->after('support_phone');
            $table->string('support_hours', 100)->nullable()->after('support_email');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn(['support_phone', 'support_email', 'support_hours']);
        });
    }
};
