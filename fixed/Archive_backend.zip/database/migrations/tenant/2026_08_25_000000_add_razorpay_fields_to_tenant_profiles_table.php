<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // Mirrors the pusher_* group: nullable, all-or-nothing at the
            // application layer (see TenantProfileController's planned
            // assertRazorpayConfigComplete(), same shape as
            // assertPusherConfigComplete()).
            $table->string('razorpay_key_id')->nullable()->after('online_payment_enabled');

            // TEXT, not string(255) -- encrypted casts produce ciphertext
            // that's meaningfully longer than the plaintext secret
            // (~24 chars plaintext can exceed 255 chars once encrypted).
            // pusher_secret in the original schema may already have hit
            // this same ceiling; don't copy string(255) for either
            // encrypted column going forward.
            $table->text('razorpay_key_secret')->nullable()->after('razorpay_key_id');
            $table->text('razorpay_webhook_secret')->nullable()->after('razorpay_key_secret');

            // Explicit test/live flag per tenant -- lets a tenant sit in
            // test mode with real test credentials before their KYC/live
            // keys are ready, without needing a separate boolean bolted on
            // later. Defaults to true (test) so a tenant with no Razorpay
            // config yet, and no explicit choice made, never accidentally
            // reads as "live."
            $table->boolean('razorpay_is_live')->default(false)->after('razorpay_webhook_secret');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'razorpay_key_id',
                'razorpay_key_secret',
                'razorpay_webhook_secret',
                'razorpay_is_live',
            ]);
        });
    }
};
