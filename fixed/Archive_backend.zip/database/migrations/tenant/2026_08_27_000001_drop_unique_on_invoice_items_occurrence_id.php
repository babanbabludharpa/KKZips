<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoice_items', function (Blueprint $table) {
            // Add the replacement plain index FIRST — MySQL won't allow
            // dropping the unique index while the subscription_occurrence_id
            // foreign key still depends on it for lookup support. Once this
            // index exists, the FK can fall back to it, and the unique
            // index becomes safe to drop.
            $table->index('subscription_occurrence_id', 'invoice_items_subscription_occurrence_id_idx');
        });

        Schema::table('invoice_items', function (Blueprint $table) {
            // Was meant to prevent double-billing, but that's already
            // enforced by subscription_occurrences.invoice_id IS NULL in
            // InvoiceGenerationService's query. This constraint instead
            // blocks the legitimate cancel-then-rebill flow: cancelling an
            // invoice frees the occurrence (invoice_id = NULL) but keeps
            // the old invoice_items row for audit, so regenerating hits a
            // duplicate-key error on the second row for the same
            // occurrence, even though it's a different invoice.
            $table->dropUnique('invoice_items_subscription_occurrence_id_unique');
        });
    }

    public function down(): void
    {
        Schema::table('invoice_items', function (Blueprint $table) {
            $table->unique('subscription_occurrence_id', 'invoice_items_subscription_occurrence_id_unique');
        });

        Schema::table('invoice_items', function (Blueprint $table) {
            $table->dropIndex('invoice_items_subscription_occurrence_id_idx');
        });
    }
};
