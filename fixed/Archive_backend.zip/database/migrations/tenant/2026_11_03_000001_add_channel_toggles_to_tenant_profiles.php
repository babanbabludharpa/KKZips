<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // a. SMS channel master switch. NOTE: sms_enabled already exists
            // (credential-level "sending paused"). This is the *channel*
            // master — off means "do not route SMS through any provider".
            if (! Schema::hasColumn('tenant_profiles', 'sms_channel_enabled')) {
                $table->boolean('sms_channel_enabled')->default(false)->after('sms_enabled');
            }

            // b. In-app push notifications (Pusher-based).
            if (! Schema::hasColumn('tenant_profiles', 'notification_channel_enabled')) {
                $table->boolean('notification_channel_enabled')->default(true)->after('sms_channel_enabled');
            }

            // c. WhatsApp channel + minimal credentials (mirrors SMS pattern).
            if (! Schema::hasColumn('tenant_profiles', 'whatsapp_channel_enabled')) {
                $table->boolean('whatsapp_channel_enabled')->default(false)->after('notification_channel_enabled');
            }
            if (! Schema::hasColumn('tenant_profiles', 'whatsapp_api_key')) {
                $table->string('whatsapp_api_key', 255)->nullable()->after('whatsapp_channel_enabled');
            }
            if (! Schema::hasColumn('tenant_profiles', 'whatsapp_phone_number')) {
                $table->string('whatsapp_phone_number', 20)->nullable()->after('whatsapp_api_key');
            }

            // d. Email channel. Reuses support_email as the "from" address,
            //    so no extra credential column here.
            if (! Schema::hasColumn('tenant_profiles', 'email_channel_enabled')) {
                $table->boolean('email_channel_enabled')->default(true)->after('whatsapp_phone_number');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            foreach ([
                'sms_channel_enabled',
                'notification_channel_enabled',
                'whatsapp_channel_enabled',
                'whatsapp_api_key',
                'whatsapp_phone_number',
                'email_channel_enabled',
            ] as $c) {
                if (Schema::hasColumn('tenant_profiles', $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};
