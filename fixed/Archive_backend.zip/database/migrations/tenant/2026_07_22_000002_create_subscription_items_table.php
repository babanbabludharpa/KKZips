<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_id')->constrained('subscriptions')->cascadeOnDelete();
            $table->foreignId('product_variant_id')->constrained('product_variants');
            $table->unsignedInteger('default_qty');
            $table->enum('delivery_slot', ['morning', 'lunch', 'dinner', 'evening']);
            $table->enum('schedule_type', ['daily', 'alternate', 'custom_days']);
            $table->json('schedule_days')->nullable(); // e.g. [1,2,3,4,5] Mon-Fri, or interval config for 'alternate'
            $table->enum('status', ['active', 'paused', 'cancelled'])->default('active');
            $table->json('qty_by_day')->nullable(); // NOT YET WIRED TO SERVICE LOGIC - scope unconfirmed, see Design V2 Open Item 2
            $table->timestamps();

            $table->index(['subscription_id', 'status']);
            $table->index('product_variant_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_items');
    }
};
