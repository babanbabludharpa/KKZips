<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('branches', function (Blueprint $table) {
            $table->decimal('latitude', 10, 8)->nullable()->after('address');
            $table->decimal('longitude', 11, 8)->nullable()->after('latitude');
            $table->time('opens_at')->nullable()->after('longitude');
            $table->time('closes_at')->nullable()->after('opens_at');
            $table->boolean('is_accepting_orders')->default(true)->after('closes_at');
        });
    }

    public function down(): void
    {
        Schema::table('branches', function (Blueprint $table) {
            $table->dropColumn(['latitude', 'longitude', 'opens_at', 'closes_at', 'is_accepting_orders']);
        });
    }
};
