<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * ★ STOPGAP, not a fix. This only stops the SQLSTATE[22003] crash when
     * quantity_reserved goes negative. It does NOT explain why a reserved
     * count would ever go below zero -- unlike `quantity` (which can
     * legitimately go negative when subscription_stock_check_enabled is
     * off, representing real overselling), a negative reservation count
     * means a reservation was released that was never actually taken --
     * i.e. a double-decrement or mismatched branch/variant bug somewhere
     * outside DeliveryConfirmationService (that class already clamps with
     * min() on every decrement it performs).
     *
     * Before relying on this migration alone: grep the codebase for
     * `decrement('quantity_reserved'` and `decrementEach` and check every
     * call site for a missing min()/clamp guard. This migration should be
     * paired with fixing that call site, not a replacement for it.
     */
    public function up(): void
    {
        DB::statement('ALTER TABLE `inventory` MODIFY `quantity_reserved` BIGINT NOT NULL DEFAULT 0');
    }

    public function down(): void
    {
        // Reverting will fail if any row already holds a negative value --
        // that's intentional. Clean up negative rows first (or accept data
        // loss/clamping) before rolling back.
        DB::statement('ALTER TABLE `inventory` MODIFY `quantity_reserved` BIGINT UNSIGNED NOT NULL DEFAULT 0');
    }
};
