<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallet_topups', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('customer_id');

            $table->decimal('amount', 10, 2);

            // Razorpay side — populated in stages as the payment progresses.
            // order id set at initiate time; payment_id/signature set only
            // on confirmed success (verify-payment call or webhook).
            $table->string('razorpay_order_id')->nullable()->unique();
            $table->string('razorpay_payment_id')->nullable()->unique();
            $table->string('razorpay_signature')->nullable();

            // pending -> paid            (normal success path)
            // pending -> failed          (payment.failed event / bad signature)
            // pending -> expired         (watchdog confirmed no payment exists after timeout)
            // paid    -> refunded        (manual admin action, see WalletService::refundTopup)
            $table->enum('status', ['pending', 'paid', 'failed', 'expired', 'refunded'])
                ->default('pending');

            $table->timestamp('initiated_at')->useCurrent();
            $table->timestamp('paid_at')->nullable();

            $table->timestamps();

            $table->index('customer_id');
            $table->index(['customer_id', 'status']);

            $table->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wallet_topups');
    }
};
