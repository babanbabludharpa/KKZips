<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('delivery_charge_rules', function (Blueprint $table) {
            $table->id();
            $table->string('name')->default('Standard');
            $table->decimal('min_order_amount', 10, 2)->default(0);
            $table->decimal('free_delivery_above', 10, 2)->nullable();
            $table->decimal('base_charge', 10, 2)->default(0);
            $table->decimal('per_km_charge', 10, 2)->default(0);
            $table->decimal('max_charge', 10, 2)->nullable();
            $table->decimal('max_delivery_km', 8, 2)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('delivery_charge_rules');
    }
};
