<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->string('registration_no', 100)->nullable()->after('gst_no');
            $table->string('pan_no', 20)->nullable()->after('registration_no');
            $table->string('fssai_no', 30)->nullable()->after('pan_no');
            $table->string('adhar_no', 20)->nullable()->after('fssai_no');
            $table->string('shopact_no', 50)->nullable()->after('adhar_no');

            $table->string('registration_doc', 255)->nullable()->after('shopact_no');
            $table->string('gst_doc', 255)->nullable()->after('registration_doc');
            $table->string('pan_doc', 255)->nullable()->after('gst_doc');
            $table->string('fssai_doc', 255)->nullable()->after('pan_doc');
            $table->string('adhar_doc', 255)->nullable()->after('fssai_doc');
            $table->string('shopact_doc', 255)->nullable()->after('adhar_doc');

            $table->foreignId('created_by')->nullable()->after('is_active')->constrained('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->dropForeign(['created_by']);
            $table->dropColumn([
                'registration_no', 'pan_no', 'fssai_no', 'adhar_no', 'shopact_no',
                'registration_doc', 'gst_doc', 'pan_doc', 'fssai_doc', 'adhar_doc', 'shopact_doc',
                'created_by',
            ]);
        });
    }
};
