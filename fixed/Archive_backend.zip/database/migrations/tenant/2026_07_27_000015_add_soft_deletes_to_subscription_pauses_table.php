<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_pauses', function (Blueprint $table) {
            // Resuming a pause used to hard-delete this row, destroying the
            // audit trail. Now it's soft-deleted: active-pause lookups
            // (covering() scope, generation logic) still only see
            // non-deleted rows automatically, but history/report queries
            // can withTrashed() to show "this was paused then resumed."
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::table('subscription_pauses', function (Blueprint $table) {
            $table->dropSoftDeletes();
        });
    }
};
