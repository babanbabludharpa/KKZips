<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // i. Delivery estimate text ("Delivered in 3–7 days").
            if (! Schema::hasColumn('tenant_profiles', 'delivery_note_min_days')) {
                $table->unsignedTinyInteger('delivery_note_min_days')->default(3)->after('support_hours');
            }
            if (! Schema::hasColumn('tenant_profiles', 'delivery_note_max_days')) {
                $table->unsignedTinyInteger('delivery_note_max_days')->default(7)->after('delivery_note_min_days');
            }
            if (! Schema::hasColumn('tenant_profiles', 'delivery_note_text')) {
                $table->string('delivery_note_text', 255)->nullable()->after('delivery_note_max_days');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            foreach (['delivery_note_min_days', 'delivery_note_max_days', 'delivery_note_text'] as $c) {
                if (Schema::hasColumn('tenant_profiles', $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};
