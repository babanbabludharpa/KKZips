<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('variant_price_history', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();
            $table->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->enum('source', ['manual', 'schedule']);
            $table->foreignId('schedule_id')->nullable()->constrained('price_schedules')->nullOnDelete();
            $table->decimal('prev_mrp', 10, 2)->nullable();
            $table->decimal('prev_selling_price', 10, 2)->nullable();
            $table->decimal('prev_purchase_price', 10, 2)->nullable();
            $table->decimal('new_mrp', 10, 2)->nullable();
            $table->decimal('new_selling_price', 10, 2)->nullable();
            $table->decimal('new_purchase_price', 10, 2)->nullable();
            $table->timestamp('changed_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('variant_price_history');
    }
};
