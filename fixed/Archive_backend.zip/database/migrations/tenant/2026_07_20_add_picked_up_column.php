<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM(
            'pending_payment','confirmed','preparing','out_for_delivery','picked_up','delivered','payment_failed','expired','cancelled'
        ) NOT NULL DEFAULT 'pending_payment'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM(
            'pending_payment','confirmed','preparing','out_for_delivery','delivered','payment_failed','expired','cancelled'
        ) NOT NULL DEFAULT 'pending_payment'");
    }
};
