<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_variants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('sku', 60)->unique();      // tenant-defined code
            $table->foreignId('unit_id')->constrained('units')->restrictOnDelete();
            $table->string('hsn_code', 20)->nullable();
            $table->string('image')->nullable();

            $table->decimal('mrp', 10, 2);
            $table->decimal('purchase_price', 10, 2)->nullable();
            $table->decimal('selling_price', 10, 2);

            $table->boolean('is_discount_active')->default(false); // cron-managed only

            $table->foreignId('tax_rate_id')->nullable()->constrained('tax_rates')->nullOnDelete();
            $table->unsignedInteger('min_order_qty')->default(1);

            $table->boolean('is_active')->default(true);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_variants');
    }
};
