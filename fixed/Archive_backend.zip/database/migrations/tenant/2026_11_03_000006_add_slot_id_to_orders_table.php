<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const SLOTS_TABLE = 'tenant_delivery_slots';
    private const ORDERS_TABLE = 'orders';
    private const FK_NAME = 'orders_delivery_slot_id_foreign';
    private const INDEX_NAME = 'orders_delivery_slot_date_idx';

    public function up(): void
    {
        // ── Pre-flight ─────────────────────────────────────────────
        if (! Schema::hasTable(self::SLOTS_TABLE)) {
            throw new RuntimeException(
                'Migration cannot run: table `'.self::SLOTS_TABLE.'` does not exist in this tenant DB.'
            );
        }
        if (! Schema::hasTable(self::ORDERS_TABLE)) {
            throw new RuntimeException('Migration cannot run: table `orders` does not exist.');
        }

        // Verify id-type compatibility up front so we fail with a clear
        // message instead of errno 150.
        $slotId = DB::selectOne(
            "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME   = ?
               AND COLUMN_NAME  = 'id'",
            [self::SLOTS_TABLE]
        );
        if (! $slotId || stripos($slotId->COLUMN_TYPE, 'bigint') === false) {
            throw new RuntimeException(
                self::SLOTS_TABLE.'.id is '.
                ($slotId->COLUMN_TYPE ?? 'missing').
                ', must be BIGINT UNSIGNED.'
            );
        }

        $engine = DB::selectOne(
            "SELECT ENGINE FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
            [self::ORDERS_TABLE]
        );
        if ($engine && strcasecmp($engine->ENGINE, 'InnoDB') !== 0) {
            throw new RuntimeException(
                'orders engine is '.$engine->ENGINE.', must be InnoDB for foreign keys.'
            );
        }

        // ── Step 1: columns (idempotent — your failing run already added
        //    delivery_slot_id; the others are still missing) ──────────
        Schema::table(self::ORDERS_TABLE, function (Blueprint $table) {
            if (! Schema::hasColumn(self::ORDERS_TABLE, 'delivery_slot_id')) {
                $table->unsignedBigInteger('delivery_slot_id')->nullable()->after('id');
            }
            if (! Schema::hasColumn(self::ORDERS_TABLE, 'delivery_date')) {
                $table->date('delivery_date')->nullable()->after('delivery_slot_id');
            }
            if (! Schema::hasColumn(self::ORDERS_TABLE, 'uses_slot_at_checkout')) {
                $table->boolean('uses_slot_at_checkout')->default(false)->after('delivery_date');
            }
        });

        // ── Step 2: FK — pointing at the correct table ─────────────
        $hasFk = DB::selectOne(
            "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME   = ?
               AND CONSTRAINT_TYPE = 'FOREIGN KEY'
               AND CONSTRAINT_NAME = ?",
            [self::ORDERS_TABLE, self::FK_NAME]
        );

        if (! $hasFk) {
            DB::statement(
                'ALTER TABLE `'.self::ORDERS_TABLE.'`
                 ADD CONSTRAINT `'.self::FK_NAME.'`
                 FOREIGN KEY (`delivery_slot_id`)
                 REFERENCES `'.self::SLOTS_TABLE.'` (`id`)
                 ON DELETE SET NULL
                 ON UPDATE CASCADE'
            );
        }

        // ── Step 3: helpful composite index ────────────────────────
        $hasIndex = DB::selectOne(
            "SELECT INDEX_NAME FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME   = ?
               AND INDEX_NAME   = ?
             LIMIT 1",
            [self::ORDERS_TABLE, self::INDEX_NAME]
        );
        if (! $hasIndex) {
            DB::statement(
                'CREATE INDEX `'.self::INDEX_NAME.'`
                 ON `'.self::ORDERS_TABLE.'` (`delivery_date`, `delivery_slot_id`)'
            );
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable(self::ORDERS_TABLE)) {
            return;
        }

        $hasFk = DB::selectOne(
            "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME   = ?
               AND CONSTRAINT_TYPE = 'FOREIGN KEY'
               AND CONSTRAINT_NAME = ?",
            [self::ORDERS_TABLE, self::FK_NAME]
        );
        if ($hasFk) {
            DB::statement('ALTER TABLE `'.self::ORDERS_TABLE.'` DROP FOREIGN KEY `'.self::FK_NAME.'`');
        }

        $hasIndex = DB::selectOne(
            "SELECT INDEX_NAME FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME   = ?
               AND INDEX_NAME   = ?
             LIMIT 1",
            [self::ORDERS_TABLE, self::INDEX_NAME]
        );
        if ($hasIndex) {
            DB::statement('ALTER TABLE `'.self::ORDERS_TABLE.'` DROP INDEX `'.self::INDEX_NAME.'`');
        }

        Schema::table(self::ORDERS_TABLE, function (Blueprint $table) {
            foreach (['delivery_slot_id', 'delivery_date', 'uses_slot_at_checkout'] as $c) {
                if (Schema::hasColumn(self::ORDERS_TABLE, $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};