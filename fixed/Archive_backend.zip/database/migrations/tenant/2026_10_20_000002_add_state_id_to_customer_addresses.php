<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('customer_addresses', 'state_id')) {
            Schema::table('customer_addresses', function (Blueprint $table) {
                $table->unsignedBigInteger('state_id')->nullable()->after('state');
            });
        }

        $hasForeignKey = collect(Schema::getForeignKeys('customer_addresses'))
            ->contains(fn ($fk) => $fk['columns'] === ['state_id']);

        if (! $hasForeignKey) {
            Schema::table('customer_addresses', function (Blueprint $table) {
                $table->foreign('state_id')->references('id')->on('states')->nullOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::table('customer_addresses', function (Blueprint $table) {
            $table->dropForeign(['state_id']);
            $table->dropColumn('state_id');
        });
    }
};