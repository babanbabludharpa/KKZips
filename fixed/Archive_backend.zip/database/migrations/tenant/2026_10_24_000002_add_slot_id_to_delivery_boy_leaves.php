<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_boy_leaves', function (Blueprint $table) {
            $table->unsignedBigInteger('slot_id')->nullable()->after('delivery_boy_id');
            $table->foreign('slot_id')
                  ->references('id')
                  ->on('tenant_delivery_slots')
                  ->restrictOnDelete();
            $table->index(['delivery_boy_id', 'slot_id', 'start_date', 'end_date'], 'dbl_rider_slot_dates_idx');
        });
    }

    public function down(): void
    {
        Schema::table('delivery_boy_leaves', function (Blueprint $table) {
            $table->dropForeign(['slot_id']);
            $table->dropIndex('dbl_rider_slot_dates_idx');
            $table->dropColumn('slot_id');
        });
    }
};
//not run at dev, so need to run it manually on dev to avoid errors when running the next migration1
