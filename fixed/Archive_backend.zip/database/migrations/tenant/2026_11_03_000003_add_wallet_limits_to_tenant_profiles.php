<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // h. Wallet limits, stored in *paise*, signed integers.
            //    -50000 paise = -₹500.00 ; -500000 paise = -₹5000.00
            if (! Schema::hasColumn('tenant_profiles', 'wallet_warning_limit')) {
                $table->integer('wallet_warning_limit')->default(-50000)->after('has_wallet');
            }
            if (! Schema::hasColumn('tenant_profiles', 'wallet_suspension_limit')) {
                $table->integer('wallet_suspension_limit')->default(-500000)->after('wallet_warning_limit');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            foreach (['wallet_warning_limit', 'wallet_suspension_limit'] as $c) {
                if (Schema::hasColumn('tenant_profiles', $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};
