<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_id')->constrained('subscriptions');
            $table->foreignId('subscription_item_id')->nullable()->constrained('subscription_items');
            $table->foreignId('customer_id')->constrained('customers');

            $table->enum('event_type', [
                'created', 'cancelled', 'item_added', 'item_cancelled',
                'paused', 'resumed', 'qty_changed',
                'invoice_generated', 'invoice_cancelled', 'payment_recorded',
            ]);
            $table->enum('actor_type', ['customer', 'admin', 'system']);
            $table->unsignedBigInteger('actor_id')->nullable(); // customers.id or users.id depending on actor_type

            $table->date('occurrence_date')->nullable(); // the specific delivery date this event affects, if any
            $table->string('description'); // human-readable, e.g. "Paused delivery for 2026-08-03"
            $table->json('metadata')->nullable(); // structured detail: old_qty/new_qty, reason, invoice_id, etc.

            $table->timestamps();

            $table->index(['subscription_id', 'created_at']);
            $table->index(['customer_id', 'created_at']);
            $table->index('event_type');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_activity_logs');
    }
};
