<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            if (! Schema::hasColumn('order_items', 'tax_rate_percent')) {
                $table->decimal('tax_rate_percent', 5, 2)->default(0)->after('final_price');
            }
            if (! Schema::hasColumn('order_items', 'tax_amount')) {
                $table->decimal('tax_amount', 10, 2)->default(0)->after('tax_rate_percent');
            }
            if (! Schema::hasColumn('order_items', 'taxable_value')) {
                $table->decimal('taxable_value', 10, 2)->default(0)->after('tax_amount');
            }
            if (! Schema::hasColumn('order_items', 'tax_type')) {
                $table->enum('tax_type', ['cgst_sgst', 'igst'])->nullable()->after('taxable_value');
            }
            if (! Schema::hasColumn('order_items', 'cgst_amount')) {
                $table->decimal('cgst_amount', 10, 2)->default(0)->after('tax_type');
            }
            if (! Schema::hasColumn('order_items', 'sgst_amount')) {
                $table->decimal('sgst_amount', 10, 2)->default(0)->after('cgst_amount');
            }
            if (! Schema::hasColumn('order_items', 'igst_amount')) {
                $table->decimal('igst_amount', 10, 2)->default(0)->after('sgst_amount');
            }
        });
    }

    public function down(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->dropColumn([
                'tax_rate_percent', 'tax_amount', 'taxable_value',
                'tax_type', 'cgst_amount', 'sgst_amount', 'igst_amount',
            ]);
        });
    }
};
