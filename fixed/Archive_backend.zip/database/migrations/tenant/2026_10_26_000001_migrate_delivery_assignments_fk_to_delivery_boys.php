<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Wipe the old rows. They reference users.id via the old FK and
        // cannot be re-pointed at delivery_boys.id. This is a deliberate
        // clean-slate migration.
        DB::table('delivery_assignments')->delete();

        Schema::table('delivery_assignments', function (Blueprint $table) {
            $table->dropForeign(['delivery_boy_id']);
        });

        Schema::table('delivery_assignments', function (Blueprint $table) {
            $table->foreign('delivery_boy_id')
                  ->references('id')
                  ->on('delivery_boys')
                  ->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('delivery_assignments', function (Blueprint $table) {
            $table->dropForeign(['delivery_boy_id']);
        });

        Schema::table('delivery_assignments', function (Blueprint $table) {
            $table->foreign('delivery_boy_id')
                  ->references('id')
                  ->on('users')
                  ->restrictOnDelete();
        });
    }
};
//not run at dev, so need to run it manually on dev to avoid errors when running the next migration1
