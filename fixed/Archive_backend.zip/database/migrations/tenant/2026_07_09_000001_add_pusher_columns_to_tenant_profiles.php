<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->string('pusher_app_id')->nullable()->after('online_payment_enabled');
            $table->string('pusher_key')->nullable()->after('pusher_app_id');
            // text, not string -- encrypted Laravel casts produce a long
            // ciphertext string that will not reliably fit a varchar(255).
            $table->text('pusher_secret')->nullable()->after('pusher_key');
            $table->string('pusher_cluster')->nullable()->after('pusher_secret');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn(['pusher_app_id', 'pusher_key', 'pusher_secret', 'pusher_cluster']);
        });
    }
};
