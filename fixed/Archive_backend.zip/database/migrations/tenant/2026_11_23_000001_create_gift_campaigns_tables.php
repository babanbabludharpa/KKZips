<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ─────────────────────────────────────────────────────────────────────────
// FREE GIFTS — campaign / tier / tier-item / usage tables.
// A campaign holds threshold tiers (₹300, ₹600, ₹1000 …). Each tier lists
// which gift variants (is_gift = 1 on product_variants) are granted when
// the order value crosses that tier's threshold. Every granted order gets
// one gift_usages row (audit + per-customer capping, coupon-style).
// ─────────────────────────────────────────────────────────────────────────

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('gift_campaigns', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);

            // exact      → only the highest achieved tier's gifts are granted
            //              (admin manually composes every tier: "₹1000 → X+Y+Z")
            // cumulative → highest tier + all lower tiers' gifts (merged per variant)
            $table->enum('tier_mode', ['exact', 'cumulative'])->default('exact');

            // Which cart value counts towards the thresholds:
            // after_coupon  → subtotal minus coupon discount (excl. delivery charge)
            // before_coupon → plain item subtotal
            $table->enum('threshold_basis', ['after_coupon', 'before_coupon'])->default('after_coupon');

            $table->unsignedInteger('usage_limit_total')->nullable();
            $table->unsignedInteger('usage_limit_per_customer')->nullable();
            $table->unsignedInteger('used_count')->default(0);
            $table->date('valid_from');
            $table->date('valid_until')->nullable();

            // Campaigns start INACTIVE — activating one is an explicit action
            // (and only one campaign may be active at a time).
            $table->boolean('is_active')->default(false);

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('gift_tiers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gift_campaign_id')->constrained('gift_campaigns')->cascadeOnDelete();
            $table->decimal('threshold_amount', 10, 2);

            // all       → every listed gift in the tier is granted (v1)
            // choose_one → customer picks 1 of N (reserved for v1.1 UI)
            $table->enum('selection_mode', ['all', 'choose_one'])->default('all');

            $table->timestamps();

            $table->unique(['gift_campaign_id', 'threshold_amount']);
        });

        Schema::create('gift_tier_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gift_tier_id')->constrained('gift_tiers')->cascadeOnDelete();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();
            $table->unsignedInteger('quantity')->default(1);
            $table->timestamps();

            $table->unique(['gift_tier_id', 'product_variant_id']);
        });

        Schema::create('gift_usages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gift_campaign_id')->constrained('gift_campaigns')->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained('customers')->cascadeOnDelete();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->json('items'); // snapshot: [{variant_id, sku, name, quantity, tier_id}]
            $table->timestamp('used_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('gift_usages');
        Schema::dropIfExists('gift_tier_items');
        Schema::dropIfExists('gift_tiers');
        Schema::dropIfExists('gift_campaigns');
    }
};
