<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('customer_addresses', 'branch_id')) {
            Schema::table('customer_addresses', function (Blueprint $table) {
                $table->unsignedBigInteger('branch_id')->nullable()->after('is_default');
            });
        }

        if (! Schema::hasColumn('customer_addresses', 'is_serviceable')) {
            Schema::table('customer_addresses', function (Blueprint $table) {
                $table->boolean('is_serviceable')->default(false)->after('branch_id');
            });
        }

        $hasForeignKey = collect(Schema::getForeignKeys('customer_addresses'))
            ->contains(fn ($fk) => $fk['columns'] === ['branch_id']);

        if (! $hasForeignKey) {
            Schema::table('customer_addresses', function (Blueprint $table) {
                $table->foreign('branch_id')->references('id')->on('branches')->nullOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::table('customer_addresses', function (Blueprint $table) {
            $table->dropForeign(['branch_id']);
            $table->dropColumn(['branch_id', 'is_serviceable']);
        });
    }
};