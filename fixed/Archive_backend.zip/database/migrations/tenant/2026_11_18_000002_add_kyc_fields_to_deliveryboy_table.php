<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Goes in database/migrations/tenant (delivery_boys lives in the tenant DB).
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_boys', function (Blueprint $table) {
            // text, not string: these three are encrypted at rest and the
            // ciphertext is far longer than the raw value.
            $table->text('adhar_no')->nullable();
            $table->text('pan_no')->nullable();
            $table->text('bank_account_no')->nullable();

            $table->string('emergency_contact_no', 15)->nullable();
            $table->string('bank_account_holder', 100)->nullable();
            $table->string('bank_name', 100)->nullable();
            $table->string('bank_ifsc', 11)->nullable();
            $table->string('upi_id', 100)->nullable();

            // Paths on the private disk, never URLs.
            $table->string('adhar_doc')->nullable();
            $table->string('pan_doc')->nullable();
            $table->string('driving_licence_doc')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('delivery_boys', function (Blueprint $table) {
            $table->dropColumn([
                'adhar_no', 'pan_no', 'bank_account_no',
                'emergency_contact_no', 'bank_account_holder', 'bank_name',
                'bank_ifsc', 'upi_id',
                'adhar_doc', 'pan_doc', 'driving_licence_doc',
            ]);
        });
    }
};
