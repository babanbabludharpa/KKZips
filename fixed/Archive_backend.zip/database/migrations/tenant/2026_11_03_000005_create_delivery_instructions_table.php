<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('delivery_instructions', function (Blueprint $table) {
            $table->id();
            $table->string('tenant_id')->index();
            $table->string('label', 120);
            $table->string('code', 60);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->unique(['tenant_id', 'code']);
        });

        // Seed the default catalog for every existing tenant.
        $defaults = [
            ['code' => 'dont_ring_bell',        'label' => "Don't ring the bell",         'sort_order' => 10],
            ['code' => 'leave_at_door',         'label' => 'Leave at the door',           'sort_order' => 20],
            ['code' => 'call_on_arrival',       'label' => 'Call on arrival',             'sort_order' => 30],
            ['code' => 'hand_to_me',            'label' => 'Hand it to me personally',    'sort_order' => 40],
            ['code' => 'leave_with_security',   'label' => 'Leave with security',         'sort_order' => 50],
            ['code' => 'avoid_plastic',         'label' => 'Avoid plastic packaging',     'sort_order' => 60],
            ['code' => 'deliver_fresh',         'label' => 'Deliver as fresh as possible','sort_order' => 70],
            ['code' => 'evening_only',          'label' => 'Evening delivery only',       'sort_order' => 80],
            ['code' => 'morning_only',          'label' => 'Morning delivery only',       'sort_order' => 90],
            ['code' => 'pet_at_home',           'label' => 'Pet at home — call first',    'sort_order' => 100],
        ];

        if (Schema::hasTable('tenants')) {
            $now = now();
            foreach (DB::table('tenants')->pluck('id') as $tenantId) {
                foreach ($defaults as $row) {
                    DB::table('delivery_instructions')->insert([
                        'tenant_id'  => $tenantId,
                        'label'      => $row['label'],
                        'code'       => $row['code'],
                        'sort_order' => $row['sort_order'],
                        'is_active'  => true,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);
                }
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('delivery_instructions');
    }
};
