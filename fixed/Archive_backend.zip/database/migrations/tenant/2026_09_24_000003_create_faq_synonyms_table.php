<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('faq_synonyms', function (Blueprint $table) {
            $table->id();
            $table->string('word', 100);
            $table->json('synonyms');
            $table->char('language', 2)->default('en');
            $table->timestamps();

            $table->unique(['word', 'language']);
            $table->index('language');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('faq_synonyms');
    }
};
