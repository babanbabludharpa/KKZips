<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_boy_leaves', function (Blueprint $table) {
            $table->softDeletes();           // adds deleted_at nullable timestamp
            $table->unsignedBigInteger('deleted_by')->nullable()->after('deleted_at');
            $table->foreign('deleted_by')
                  ->references('id')
                  ->on('users')
                  ->nullOnDelete();
            $table->index('deleted_at');
        });
    }

    public function down(): void
    {
        Schema::table('delivery_boy_leaves', function (Blueprint $table) {
            $table->dropForeign(['deleted_by']);
            $table->dropIndex(['deleted_at']);
            $table->dropColumn(['deleted_at', 'deleted_by']);
        });
    }
};
//not run at dev, so need to run it manually on dev to avoid errors when running the next migration1
