<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // e. Order slot master switch
            if (! Schema::hasColumn('tenant_profiles', 'use_order_slots')) {
                $table->boolean('use_order_slots')->default(false)->after('has_orders');
            }
            if (! Schema::hasColumn('tenant_profiles', 'order_start_policy')) {
                $table->enum('order_start_policy', ['next_day_only', 'same_day_slot_wise'])
                      ->default('next_day_only')
                      ->after('use_order_slots');
            }
            if (! Schema::hasColumn('tenant_profiles', 'order_same_day_lead_time_minutes')) {
                $table->integer('order_same_day_lead_time_minutes')
                      ->default(120)
                      ->after('order_start_policy');
            }

            // f. Per-slot cutoff — replaces global cutoff + breathing time.
            if (! Schema::hasColumn('tenant_profiles', 'slot_wise_cutoff_enabled')) {
                $table->boolean('slot_wise_cutoff_enabled')->default(false)
                      ->after('order_same_day_lead_time_minutes');
            }
            if (! Schema::hasColumn('tenant_profiles', 'slot_cutoff_offset_minutes')) {
                $table->integer('slot_cutoff_offset_minutes')->default(120)
                      ->after('slot_wise_cutoff_enabled');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            foreach ([
                'use_order_slots',
                'order_start_policy',
                'order_same_day_lead_time_minutes',
                'slot_wise_cutoff_enabled',
                'slot_cutoff_offset_minutes',
            ] as $c) {
                if (Schema::hasColumn('tenant_profiles', $c)) {
                    $table->dropColumn($c);
                }
            }
        });
    }
};
