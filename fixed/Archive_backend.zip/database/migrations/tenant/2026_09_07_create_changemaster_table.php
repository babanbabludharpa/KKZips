<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('change_masters', function (Blueprint $table) {
            $table->id();
            $table->string('username', 30);      // was cm_memberid — the account the change applies to
            $table->string('added_by', 30);       // was cm_addedby — who performed it (self, for forgot-password; the acting admin, for CRUD edits)
            $table->string('ip_address', 40);     // was cm_ipaddress
            $table->unsignedTinyInteger('flag');  // was cm_flag — see ChangeMaster::FLAG_* constants
            $table->unsignedTinyInteger('panel'); // was cm_panel — see ChangeMaster::PANEL_* constants
            $table->string('remark', 150);        // was cm_remark
            $table->longText('previous_value');   // was cm_prevfield
            $table->longText('new_value');        // was cm_newfield
            $table->timestamps();                 // was cm_date — created_at now covers this, matching every other table in this app

            $table->index('username');
            $table->index('flag');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('change_masters');
    }
};
