<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('recurring_unavailable_days', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_category_id')->nullable()->constrained('categories'); // null = all products
            $table->unsignedTinyInteger('day_of_week'); // 0=Sun ... 6=Sat (match your existing convention if different)
            $table->enum('delivery_slot', ['morning', 'lunch', 'dinner', 'evening'])->nullable(); // null = whole day
            $table->string('description')->nullable();
            $table->timestamps();

            $table->index(['day_of_week', 'delivery_slot']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('recurring_unavailable_days');
    }
};
