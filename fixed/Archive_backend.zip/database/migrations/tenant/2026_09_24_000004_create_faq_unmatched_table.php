<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('faq_unmatched', function (Blueprint $table) {
            $table->id();
            $table->text('question');
            $table->char('language_guess', 2)->nullable();
            $table->unsignedBigInteger('customer_id')->nullable();

            // Aggregated: if 20 customers ask the same thing, this
            // row's hit_count goes to 20 rather than creating 20 rows.
            // The matcher uses a normalized-hash comparison to decide
            // whether two questions are "the same" for aggregation.
            $table->unsignedInteger('hit_count')->default(1);
            $table->timestamp('last_asked_at')->nullable();

            // Set when an admin converts this to a real FAQ. Kept as
            // a plain unsignedBigInteger (not a foreign key) so that
            // deleting the FAQ later does not cascade-delete the
            // historical record of what was asked.
            $table->unsignedBigInteger('converted_faq_id')->nullable();

            $table->timestamps();

            $table->index(['hit_count', 'last_asked_at']);
            $table->index('converted_faq_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('faq_unmatched');
    }
};
