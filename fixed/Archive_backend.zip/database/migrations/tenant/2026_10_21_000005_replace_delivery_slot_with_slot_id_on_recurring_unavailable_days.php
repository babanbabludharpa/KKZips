<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Table is empty at migration time (verified before writing this).
        // No backfill needed. Straight column swap.

        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->dropIndex(['day_of_week', 'delivery_slot']);
        });

        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->unsignedBigInteger('slot_id')->nullable()->after('day_of_week');
        });

        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->dropColumn('delivery_slot');
        });

        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->unsignedBigInteger('slot_id')->nullable(false)->change();
            $table->foreign('slot_id')
                  ->references('id')
                  ->on('tenant_delivery_slots')
                  ->cascadeOnDelete();
            $table->index(['day_of_week', 'slot_id']);
        });
    }

    public function down(): void
    {
        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->dropIndex(['day_of_week', 'slot_id']);
            $table->dropForeign(['slot_id']);
            $table->dropColumn('slot_id');
        });

        Schema::table('recurring_unavailable_days', function (Blueprint $table) {
            $table->enum('delivery_slot', ['morning', 'lunch', 'dinner', 'evening'])
                  ->nullable()
                  ->after('day_of_week');
            $table->index(['day_of_week', 'delivery_slot']);
        });
    }
};
//not run at dev, so need to run it manually on dev to avoid errors when running the next migration1
