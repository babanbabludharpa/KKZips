<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ASSUMPTION: `quantity` on `inventory` is currently `unsignedBigInteger`,
// not nullable, default 0 -- inferred from the code (unconditional
// ->decrement('quantity', ...), no null checks, firstOrFail()). If the
// actual column differs from that (nullable, different default, different
// width), correct the ->change() call below to match the real definition,
// or this migration will silently diverge from what's actually in prod.
//
// NOT covered here: `stock_movements.closing_stock` (and `opening_stock`)
// mirror `inventory.quantity` and are written from the same code path.
// If that column is also unsigned, negative stock will crash there
// instead, just later. Confirm and add a matching migration for that
// table if so -- I don't have that migration file to verify against.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('inventory', function (Blueprint $table) {
            $table->bigInteger('quantity')->default(0)->change();
        });
    }

    public function down(): void
    {
        // Reverting to unsigned will fail outright if any row is
        // currently negative -- clean up negative values before rolling
        // back, or this down() migration will throw.
        Schema::table('inventory', function (Blueprint $table) {
            $table->unsignedBigInteger('quantity')->default(0)->change();
        });
    }
};
