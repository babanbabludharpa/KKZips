<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Step 1: Add slot_id nullable so existing rows don't block
        if (!Schema::hasColumn('subscription_items', 'slot_id')) {
            Schema::table('subscription_items', function (Blueprint $table) {
                $table->unsignedBigInteger('slot_id')->nullable()->after('product_variant_id');
            });
        }

        // Step 2: Backfill from the old enum, per-tenant. But this is a tenant
        // DB, so there is only one tenant per migration run. Determine the
        // tenant's slots that match each enum value.

        $enumToHourRange = [
            'morning' => ['05:00:00', '11:59:59'],
            'lunch'   => ['12:00:00', '14:59:59'],
            'evening' => ['15:00:00', '18:59:59'],
            'dinner'  => ['19:00:00', '22:59:59'],
        ];

        // Distinct enum values that actually exist in this tenant's items.
        $usedEnums = DB::table('subscription_items')
            ->select('delivery_slot')
            ->distinct()
            ->pluck('delivery_slot')
            ->filter()
            ->values();

        foreach ($usedEnums as $enumValue) {
            if (!isset($enumToHourRange[$enumValue])) {
                throw new RuntimeException(
                    "Unknown delivery_slot enum value '{$enumValue}'. Aborting migration."
                );
            }
            [$start, $end] = $enumToHourRange[$enumValue];

            // Find the first active slot for this enum's time range.
            $slot = DB::table('tenant_delivery_slots')
                ->where('is_active', 1)
                ->where('start_time', '>=', $start)
                ->where('start_time', '<=', $end)
                ->orderBy('start_time')
                ->first();

            if (!$slot) {
                throw new RuntimeException(
                    "Tenant has subscription_items with delivery_slot='{$enumValue}' "
                    . "but no active tenant_delivery_slots whose start_time is within "
                    . "[{$start}, {$end}]. Create a slot for this window before migrating. "
                    . "Aborting to prevent data corruption."
                );
            }

            DB::table('subscription_items')
                ->where('delivery_slot', $enumValue)
                ->update(['slot_id' => $slot->id]);
        }

        // Step 3: Verify backfill. Every row must have slot_id now.
        $orphans = DB::table('subscription_items')->whereNull('slot_id')->count();
        if ($orphans > 0) {
            throw new RuntimeException(
                "Backfill incomplete: {$orphans} subscription_items rows still have slot_id = NULL. "
                . "This should not happen. Aborting without dropping the enum."
            );
        }

        // Step 4: Make slot_id NOT NULL, add FK.
        Schema::table('subscription_items', function (Blueprint $table) {
            $table->unsignedBigInteger('slot_id')->nullable(false)->change();
            $table->foreign('slot_id')
                  ->references('id')
                  ->on('tenant_delivery_slots')
                  ->restrictOnDelete();
            $table->index('slot_id');
        });

        // Step 5: Drop the old enum column.
        Schema::table('subscription_items', function (Blueprint $table) {
            $table->dropColumn('delivery_slot');
        });
    }

    public function down(): void
    {
        // Restore the enum column (empty), drop FK+slot_id.
        Schema::table('subscription_items', function (Blueprint $table) {
            $table->enum('delivery_slot', ['morning', 'lunch', 'dinner', 'evening'])
                  ->nullable()
                  ->after('product_variant_id');
        });

        // Best-effort backfill of enum from slot start_time.
        DB::statement("
            UPDATE subscription_items si
            JOIN tenant_delivery_slots tds ON tds.id = si.slot_id
            SET si.delivery_slot = CASE
                WHEN TIME(tds.start_time) BETWEEN '05:00:00' AND '11:59:59' THEN 'morning'
                WHEN TIME(tds.start_time) BETWEEN '12:00:00' AND '14:59:59' THEN 'lunch'
                WHEN TIME(tds.start_time) BETWEEN '15:00:00' AND '18:59:59' THEN 'evening'
                WHEN TIME(tds.start_time) BETWEEN '19:00:00' AND '22:59:59' THEN 'dinner'
                ELSE NULL
            END
        ");

        Schema::table('subscription_items', function (Blueprint $table) {
            $table->dropForeign(['slot_id']);
            $table->dropIndex(['slot_id']);
            $table->dropColumn('slot_id');
        });
    }
};
//not run at dev, so need to run it manually on dev to avoid errors when running the next migration1
