<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            // Tracks the last time `status` changed (active/inactive/suspended).
            // Deliberately separate from updated_at, which gets bumped by any
            // field edit (phone, profile_photo, OTP refresh, etc.) and so can't
            // be trusted to answer "when did this customer go inactive?".
            $table->timestamp('status_changed_at')->nullable()->after('status');
        });

        // Backfill: for existing rows we have no real history, so the best
        // available guess is updated_at. This will be wrong for any customer
        // whose most recent update was unrelated to status, but it's a one-time
        // backfill starting point, not a claim of accuracy — new changes going
        // forward are recorded correctly by CustomerService::updateStatus().
        DB::table('customers')
            ->whereNull('status_changed_at')
            ->update(['status_changed_at' => DB::raw('updated_at')]);
    }

    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->dropColumn('status_changed_at');
        });
    }
};
