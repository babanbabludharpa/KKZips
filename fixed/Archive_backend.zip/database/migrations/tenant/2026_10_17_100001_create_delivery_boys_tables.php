<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('delivery_boys', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('username', 50)->unique();
            $table->string('mobile_number', 15)->unique();
            $table->string('email', 150)->nullable()->unique();
            $table->string('password');
            $table->foreignId('branch_id')->constrained('branches')->cascadeOnDelete();
            $table->enum('vehicle_type', ['bike', 'cycle', 'ev', 'van'])->default('bike');
            $table->integer('max_daily_deliveries')->default(30);
            $table->boolean('is_online')->default(false);
            $table->boolean('is_active')->default(true);
            $table->decimal('current_lat', 10, 8)->nullable();
            $table->decimal('current_lng', 11, 8)->nullable();
            $table->string('fcm_token', 255)->nullable();
            $table->timestamp('last_login_at')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('delivery_boy_zones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('delivery_boy_id')->constrained('delivery_boys')->cascadeOnDelete();
            $table->foreignId('zone_id')->constrained('branch_service_zones')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['delivery_boy_id', 'zone_id']);
        });

        Schema::create('delivery_boy_slots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('delivery_boy_id')->constrained('delivery_boys')->cascadeOnDelete();
            $table->foreignId('slot_id')->constrained('tenant_delivery_slots')->cascadeOnDelete();
            $table->tinyInteger('day_of_week'); // 0=Sun ... 6=Sat
            $table->boolean('is_available')->default(true);
            $table->unique(['delivery_boy_id', 'slot_id', 'day_of_week']);
        });

        Schema::create('delivery_boy_leaves', function (Blueprint $table) {
            $table->id();
            $table->foreignId('delivery_boy_id')->constrained('delivery_boys')->cascadeOnDelete();
            $table->date('start_date');
            $table->date('end_date');
            $table->string('reason', 255)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('delivery_boy_leaves');
        Schema::dropIfExists('delivery_boy_slots');
        Schema::dropIfExists('delivery_boy_zones');
        Schema::dropIfExists('delivery_boys');
    }
};