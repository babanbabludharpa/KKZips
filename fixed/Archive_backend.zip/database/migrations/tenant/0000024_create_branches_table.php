<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code', 50)->nullable();
            $table->text('address')->nullable();
            $table->string('city')->nullable();           // denormalized display name
            $table->unsignedBigInteger('city_id')->nullable();
            $table->string('state')->nullable();          // denormalized display name
            $table->unsignedBigInteger('state_id')->nullable();
            $table->string('pincode', 10)->nullable();
            $table->string('gst_no', 15)->nullable();
            $table->string('fssai_no')->nullable();
            $table->string('phone', 15)->nullable();
            $table->string('business_email')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('state_id')->references('id')->on('states')->nullOnDelete();
            $table->foreign('city_id')->references('id')->on('cities')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('branches');
    }
};
