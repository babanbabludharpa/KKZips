<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            ALTER TABLE subscription_occurrences
            MODIFY COLUMN status ENUM(
                'scheduled',
                'assigned',
                'customer_paused',
                'admin_paused',
                'holiday_skipped',
                'cancelled',
                'out_for_delivery',
                'delivered',
                'not_delivered',
                'billed'
            ) NOT NULL DEFAULT 'scheduled'
        ");
    }

    public function down(): void
    {
        // Before reverting, any 'cancelled' rows must be moved back — or
        // the ENUM change will fail. Force them to 'holiday_skipped' so
        // the data survives (though semantically lost).
        DB::statement("
            UPDATE subscription_occurrences
            SET status = 'holiday_skipped'
            WHERE status = 'cancelled'
        ");

        DB::statement("
            ALTER TABLE subscription_occurrences
            MODIFY COLUMN status ENUM(
                'scheduled',
                'assigned',
                'customer_paused',
                'admin_paused',
                'holiday_skipped',
                'out_for_delivery',
                'delivered',
                'not_delivered',
                'billed'
            ) NOT NULL DEFAULT 'scheduled'
        ");
    }
};