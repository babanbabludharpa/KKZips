<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices');
            $table->decimal('amount', 10, 2); // negative for reversal rows
            $table->enum('payment_mode', ['cash', 'wallet', 'online', 'upi']);
            $table->foreignId('received_by')->nullable()->constrained('users');
            $table->timestamp('received_at');
            $table->string('note')->nullable();
            $table->boolean('is_reversal')->default(false);
            $table->timestamps();

            $table->index(['invoice_id', 'is_reversal']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_payments');
    }
};
