<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Put this in your TENANT migrations folder.
return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            // Encrypted values are long ciphertext -> text, not string(12).
            $t->text('adhar_no')->nullable();
            // HMAC of the Aadhaar number, used only for duplicate detection.
            $t->char('adhar_hash', 64)->nullable()->unique();
            $t->text('pan_no')->nullable();

            $t->string('emergency_contact_no', 10)->nullable();

            $t->string('bank_account_holder', 100)->nullable();
            $t->string('bank_name', 100)->nullable();
            $t->text('bank_account_no')->nullable();
            $t->string('bank_ifsc', 11)->nullable();
            $t->string('upi_id', 100)->nullable();

            // Paths on the PRIVATE disk.
            $t->string('adhar_doc')->nullable();
            $t->string('pan_doc')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->dropUnique(['adhar_hash']);
            $t->dropColumn([
                'adhar_no', 'adhar_hash', 'pan_no', 'emergency_contact_no',
                'bank_account_holder', 'bank_name', 'bank_account_no', 'bank_ifsc',
                'upi_id', 'adhar_doc', 'pan_doc',
            ]);
        });
    }
};
