<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('faq_embeddings', function (Blueprint $table) {
            $table->id();

            $table->foreignId('faq_item_id')
                ->constrained('faq_items')
                ->cascadeOnDelete();

            // Which embedding model produced this vector.
            // "hinvec" handles Romanized Hindi/Marathi.
            // "e5-large" handles standard three-language + cross-lingual.
            $table->string('model_name', 50);

            // The embedding vector itself. Stored as JSON for portability;
            // on MySQL 8.4+ this could be a native VECTOR column instead,
            // but JSON is more portable across DB engines (Stancl Tenancy
            // tenants could theoretically be on different engines).
            $table->json('vector');

            // The exact string that was embedded — crucial for debugging
            // "why did this question not match" — without it, you have
            // to re-derive it from question + alternatives + keywords
            // and guess which one the model actually saw.
            $table->text('source_text');

            $table->timestamps();

            // One vector per FAQ per model. Re-embedding replaces,
            // never duplicates.
            $table->unique(['faq_item_id', 'model_name']);
            $table->index('model_name');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('faq_embeddings');
    }
};
