<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            // Set once at subscription creation - a single customer can run
            // subscriptions from two different addresses, so this must be
            // explicit per-subscription, not resolved from is_default at invoice time.
            $table->foreignId('delivery_address_id')
                ->nullable()
                ->after('branch_id')
                ->constrained('customer_addresses');
        });
    }

    public function down(): void
    {
        Schema::table('subscriptions', function (Blueprint $table) {
            $table->dropConstrainedForeignId('delivery_address_id');
        });
    }
};
