<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            ALTER TABLE subscription_activity_logs
            MODIFY COLUMN event_type ENUM(
                'created',
                'cancelled',
                'item_added',
                'item_cancelled',
                'paused',
                'resumed',
                'qty_changed',
                'invoice_generated',
                'invoice_cancelled',
                'payment_recorded',
                'rider_assigned',
                'rider_substituted',
                'rider_unassigned',
                'rider_reverted'
            ) NOT NULL
        ");
    }

    public function down(): void
    {
        DB::statement("
            ALTER TABLE subscription_activity_logs
            MODIFY COLUMN event_type ENUM(
                'created',
                'cancelled',
                'item_added',
                'item_cancelled',
                'paused',
                'resumed',
                'qty_changed',
                'invoice_generated',
                'invoice_cancelled',
                'payment_recorded'
            ) NOT NULL
        ");
    }
};
