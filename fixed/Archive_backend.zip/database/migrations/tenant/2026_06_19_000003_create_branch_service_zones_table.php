<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('branch_service_zones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained('branches')->cascadeOnDelete();
            $table->string('name', 100);
            $table->boolean('is_active')->default(true);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        // Add spatial column separately — Laravel Blueprint doesn't support POLYGON with spatial index cleanly
        DB::statement('ALTER TABLE branch_service_zones ADD COLUMN coordinates POLYGON NOT NULL');
        DB::statement('CREATE SPATIAL INDEX branch_service_zones_coordinates_spatidx ON branch_service_zones (coordinates)');
    }

    public function down(): void
    {
        Schema::dropIfExists('branch_service_zones');
    }
};
