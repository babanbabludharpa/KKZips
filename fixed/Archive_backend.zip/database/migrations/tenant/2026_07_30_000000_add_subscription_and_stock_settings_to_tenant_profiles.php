<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // Half-hour slot, 7:00 PM-11:30 PM - validated against that
            // exact set server-side in TenantProfileController::update().
            // Tenant-editable (and platform-overridable through the same
            // endpoint) - unlike the stock flags, this genuinely belongs in
            // the per-tenant database since it's ordinary tenant settings
            // data, not a platform-controlled guardrail.
            $table->time('subscription_cutoff_time')
                ->default('20:00:00')
                ->after('online_payment_enabled');

            // Platform-superadmin-only. Lives in this per-tenant table
            // because the code that consumes it (order/subscription
            // creation) already runs inside tenant DB context - no reason
            // to add a central-DB round trip to a hot path. Writable ONLY
            // through TenantStockSettingsController::updateByPlatformAdmin,
            // which switches into this tenant's DB via Tenant::run()
            // rather than a normal authenticated tenant request - never
            // added to TenantProfileController::update()'s validated
            // fields, so a tenant admin has no path to touch these at all,
            // not even a hidden-in-UI one.
            $table->boolean('order_stock_check_enabled')
                ->default(true)
                ->after('subscription_cutoff_time');

            // Defaults to false, unlike orders - per the stated business
            // reality, most tenants run subscriptions against a
            // requirement/procurement report rather than live stock.
            $table->boolean('subscription_stock_check_enabled')
                ->default(false)
                ->after('order_stock_check_enabled');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'subscription_cutoff_time',
                'order_stock_check_enabled',
                'subscription_stock_check_enabled',
            ]);
        });
    }
};
