<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('support_conversations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('customer_id');
            $table->enum('status', ['open', 'resolved', 'escalated'])->default('open');
            $table->timestamp('last_message_at')->nullable();
            $table->timestamps();

            $table->index(['customer_id', 'status']);
            $table->index('last_message_at');
        });

        Schema::create('support_messages', function (Blueprint $table) {
            $table->id();

            $table->foreignId('conversation_id')
                ->constrained('support_conversations')
                ->cascadeOnDelete();

            $table->enum('sender_type', ['customer', 'bot', 'agent']);
            $table->unsignedBigInteger('sender_user_id')->nullable();

            $table->text('message');

            // Which FAQ answered this message (null for customer
            // messages, null for bot fallbacks, null for human replies).
            $table->unsignedBigInteger('matched_faq_id')->nullable();

            // Matcher confidence, 0.0000 to 1.0000. Null for
            // customer and human messages.
            $table->decimal('confidence', 5, 4)->nullable();

            // Per-message metadata — which matcher layer won
            // ("exact" | "semantic" | "fallback"), which model,
            // similarity scores, etc. Invaluable for tuning.
            $table->json('metadata')->nullable();

            $table->timestamps();

            $table->index(['conversation_id', 'created_at']);
            $table->index('matched_faq_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('support_messages');
        Schema::dropIfExists('support_conversations');
    }
};
