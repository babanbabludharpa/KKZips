<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            // Default false = admin panel is NOT restricted by
            // subscription_cutoff_time (matches current behavior, where
            // the cutoff only applies to the mobile app). Setting this to
            // true is an opt-in for tenants who want the same cutoff
            // enforced on admin-initiated subscription actions too.
            // Defaulting true here would silently change behavior for
            // every existing tenant on deploy -- don't flip this.
            $table->boolean('subscription_cutoff_restrict_admin')
                ->default(false)
                ->after('subscription_cutoff_time');
        });
    }

    public function down(): void
    {
        Schema::table('tenant_profiles', function (Blueprint $table) {
            $table->dropColumn('subscription_cutoff_restrict_admin');
        });
    }
};
