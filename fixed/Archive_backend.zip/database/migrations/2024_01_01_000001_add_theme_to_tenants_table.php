<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Change 'central' to 'mysql' (or whatever your main connection is named)
    protected $connection = 'mysql';

    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('theme_key', 32)->default('crimson')->after('id');
        });

        DB::table('tenants')
            ->whereNull('theme_key')
            ->orWhere('theme_key', '')
            ->update(['theme_key' => 'crimson']);
    }

    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn('theme_key');
        });
    }
};
