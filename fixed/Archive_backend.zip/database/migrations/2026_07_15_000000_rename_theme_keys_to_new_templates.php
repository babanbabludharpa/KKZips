<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    protected $connection = 'mysql';

    public function up(): void
    {
        // Old keys → new keys (one-shot rename)
        $map = [
            'navyCrimson' => 'crimson',
            'pearlCrimson' => 'crimson',
            'slateViolet' => 'violet',
            'charcoalEmerald' => 'emerald',
            'midnightAmber' => 'amber',
            'steelSky' => 'ocean',
        ];

        foreach ($map as $old => $new) {
            DB::table('tenants')
                ->where('theme_key', $old)
                ->update(['theme_key' => $new]);
        }

        // Any leftover unknown value → default
        DB::table('tenants')
            ->whereNotIn('theme_key', [
                'crimson', 'ocean', 'violet', 'rose',
                'emerald', 'amber', 'graphite',
            ])
            ->update(['theme_key' => 'crimson']);

        // Change default
        DB::statement("ALTER TABLE tenants MODIFY theme_key VARCHAR(32) NOT NULL DEFAULT 'crimson'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE tenants MODIFY theme_key VARCHAR(32) NOT NULL DEFAULT 'navyCrimson'");
    }
};
