<?php

namespace Database\Seeders;

use App\Models\Branch;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        $this->seedPermissions();
        $this->seedRoles();
        $this->seedSuperAdminUser();
        $this->seedHeadOfficeBranch();
        $this->seedAdminUser();
    }

    private function seedPermissions(): void
    {
        foreach ($this->allPermissions() as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'sanctum',
            ]);
        }
    }

    private function seedRoles(): void
    {
        $this->seedSuperadminRole();
        $this->seedAdminRole();
        $this->seedStaffHeadOfficeRole();
        $this->seedStaffStateOfficeRole();
        $this->seedStaffBranchRole();
        $this->seedDeliveryBoyRole();
    }

    private function seedSuperadminRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'superadmin', 'guard_name' => 'sanctum']);
        $role->syncPermissions($this->allPermissions());
    }

    private function seedAdminRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'sanctum']);
        $role->syncPermissions($this->adminPermissions());
    }

    private function seedStaffHeadOfficeRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'staff_headoffice', 'guard_name' => 'sanctum']);
        $role->syncPermissions($this->staffHeadOfficePermissions());
    }

    private function seedStaffStateOfficeRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'staff_stateoffice', 'guard_name' => 'sanctum']);
        $role->syncPermissions($this->staffStateOfficePermissions());
    }

    private function seedStaffBranchRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'staff_branch', 'guard_name' => 'sanctum']);
        $role->syncPermissions($this->staffBranchPermissions());
    }

    private function seedDeliveryBoyRole(): void
    {
        $role = Role::firstOrCreate(['name' => 'delivery_boy', 'guard_name' => 'sanctum']);
        $role->syncPermissions(['subscription.confirm_delivery']);
    }

    private function seedSuperAdminUser(): void
    {
        $user = User::firstOrCreate(
            ['email' => 'superadmin@inventory.com'],
            [
                'name' => 'Super Admin',
                'username' => 'superadmin',
                'password' => Hash::make('superpassword123'),
                'branch_id' => null,
            ]
        );

        $user->assignRole(Role::findByName('superadmin', 'sanctum'));
    }

    private function seedHeadOfficeBranch(): void
    {
        Branch::firstOrCreate(
            ['type' => 'head_office'],
            [
                'name' => 'Head Office',
                'code' => 'HO-001',
                'type' => 'head_office',
                'parent_id' => null,
                'address' => null,
                'city_id' => null,
                'state_id' => null,
                'pincode' => null,
                'phone' => null,
                'contact_email' => null,
                'gst_no' => null,
                'fssai_no' => null,
                'latitude' => null,
                'longitude' => null,
                'opens_at' => '09:00:00',
                'closes_at' => '18:00:00',
                'is_accepting_orders' => true,
                'is_active' => true,
            ]
        );
    }

    private function seedAdminUser(): void
    {
        $headOffice = Branch::where('type', 'head_office')->firstOrFail();

        $user = User::firstOrCreate(
            ['email' => 'admin@inventory.com'],
            [
                'name' => 'Admin',
                'username' => 'admin',
                'password' => Hash::make('adminpassword123'),
                'branch_id' => $headOffice->id,
            ]
        );

        $user->assignRole(Role::findByName('admin', 'sanctum'));
    }

    private function allPermissions(): array
    {
        return [
            // Masters
            'category.view', 'category.create', 'category.edit', 'category.delete',
            'unit.view', 'unit.create', 'unit.edit', 'unit.delete',
            'supplier.view', 'supplier.create', 'supplier.edit', 'supplier.delete',
            'customer.view', 'customer.create', 'customer.edit', 'customer.delete', 'customer.reset_password',
            'product.view', 'product.create', 'product.edit', 'product.delete',
            'attribute.view', 'attribute.create', 'attribute.edit', 'attribute.delete',
            'taxrate.view', 'taxrate.create', 'taxrate.edit', 'taxrate.delete',
            'city.view', 'city.create', 'city.edit', 'city.delete',
            'coupon.view', 'coupon.create', 'coupon.edit', 'coupon.delete',
            'delivery.view', 'delivery.create', 'delivery.edit', 'delivery.delete',
            'gift.view', 'gift.create', 'gift.edit', 'gift.delete',

            // Stock
            'stock.inward',
            'stock.request',
            'stock.approve',

            // Orders
            'order.view', 'order.manage', 'order.assign_delivery', 'order.view_cancelled',

            // Subscriptions
            'subscription.view', 'subscription.create', 'subscription.edit',
            'subscription.pause', 'subscription.assign_delivery', 'subscription.confirm_delivery',
            'invoice.view', 'invoice.generate', 'invoice.cancel', 'invoice.collect_payment',
            'report.subscription_delivery', 'report.subscription_demand', 'report.subscription_activity',

            // Reports
            'report.view',
            'report.stock_levels',
            'report.stock_movements',
            'report.stock_requests',
            'report.price_history',
            'report.discount_history',
            'report.stock_request_detail',
            'report.delivered_orders',
            'report.delivered_orders_product_wise',
            'report.customer_addresses',
            'report.wallet_balances',
            'report.wallet_transactions',
            'customer.wallet_adjust',
            'report.coupon_consumption',
            'report.support',

            // Settings
            'profile.view', 'profile.edit', 'profile.pusher_edit', 'profile.razorpay_edit', 'profile.stock_check_edit', 'profile.cutoff_edit', 'faq.manage',
            'warehouse.view', 'warehouse.create', 'warehouse.edit', 'warehouse.delete',
            'branch.view', 'branch.create', 'branch.edit', 'branch.delete', 'profile.sms_edit', 'profile.modules_edit', 'profile.order_slots_edit', 'profile.leaves_edit',
            'delivery_boy.view', 'delivery_boy.create', 'delivery_boy.edit', 'delivery_boy.delete',

            // App Settings
            'appsettings.view', 'appsettings.edit',

            // Administration
            'user.view', 'user.create', 'user.edit', 'user.delete',
            'role.view', 'role.create', 'role.edit', 'role.delete',
            'permission.assign',
            'system.settings',
            'audit.view',
        ];
    }

    private function adminPermissions(): array
    {
        return [
            'category.view', 'category.create', 'category.edit', 'category.delete',
            'unit.view', 'unit.create', 'unit.edit', 'unit.delete',
            'supplier.view', 'supplier.create', 'supplier.edit', 'supplier.delete',
            'product.view', 'product.create', 'product.edit', 'product.delete',
            'customer.view', 'customer.create', 'customer.edit', 'customer.delete', 'customer.reset_password',
            'attribute.view', 'attribute.create', 'attribute.edit', 'attribute.delete',
            'taxrate.view', 'taxrate.create', 'taxrate.edit', 'taxrate.delete',
            'city.view', 'city.create', 'city.edit', 'city.delete',
            'coupon.view', 'coupon.create', 'coupon.edit', 'coupon.delete',
            'delivery.view', 'delivery.create', 'delivery.edit', 'delivery.delete',
            'gift.view', 'gift.create', 'gift.edit', 'gift.delete',
            'stock.inward',
            'stock.approve',
            'report.view',
            'report.stock_levels',
            'report.stock_movements',
            'report.stock_requests',
            'report.stock_request_detail',
            'report.delivered_orders',
            'report.delivered_orders_product_wise',
            'report.customer_addresses',
            'report.wallet_balances',
            'report.wallet_transactions',
            'report.coupon_consumption',
            'profile.view', 'profile.edit',
            'branch.view', 'branch.create', 'branch.edit',
            'user.view', 'user.create', 'user.edit',
            'role.view',
            'appsettings.view', 'appsettings.edit',

            'order.view', 'order.manage', 'order.assign_delivery', 'order.view_cancelled',

            'delivery_boy.view', 'delivery_boy.create', 'delivery_boy.edit', 'delivery_boy.delete',

            'subscription.view', 'subscription.create', 'subscription.edit', 'subscription.pause',
            'subscription.assign_delivery',
            'invoice.view', 'invoice.generate', 'invoice.cancel', 'invoice.collect_payment',
            'report.subscription_delivery', 'report.subscription_demand', 'report.subscription_activity',

            'customer.wallet_adjust',
        ];
    }

    private function staffHeadOfficePermissions(): array
    {
        return [
            'stock.inward',
            'stock.approve',
            'report.view',
            'report.stock_levels',
            'report.stock_movements',
            'report.stock_requests',
            'report.stock_request_detail',
            'report.delivered_orders',
            'report.delivered_orders_product_wise',
            'report.customer_addresses',
            'report.wallet_balances',
            'report.wallet_transactions',
            'report.coupon_consumption',
            'customer.view',
            'product.view',

            'order.view', 'order.manage', 'order.assign_delivery', 'order.view_cancelled',

            'delivery_boy.view', 'delivery_boy.create', 'delivery_boy.edit', 'delivery_boy.delete',

            'subscription.view', 'subscription.create', 'subscription.edit', 'subscription.pause',
            'subscription.assign_delivery',
            'invoice.view', 'invoice.generate', 'invoice.cancel', 'invoice.collect_payment',
            'report.subscription_delivery', 'report.subscription_demand', 'report.subscription_activity',

            'customer.wallet_adjust',
        ];
    }

    private function staffStateOfficePermissions(): array
    {
        return [
            'stock.request',
            'stock.approve',
            'report.view',
            'report.stock_levels',
            'report.stock_movements',
            'report.stock_requests',
            'report.stock_request_detail',
            'report.delivered_orders',
            'report.delivered_orders_product_wise',
            'report.customer_addresses',
            'report.wallet_balances',
            'report.wallet_transactions',
            'report.coupon_consumption',
            'customer.view',
            'product.view',

            'order.view', 'order.manage', 'order.assign_delivery', 'order.view_cancelled',

            'delivery_boy.view', 'delivery_boy.create', 'delivery_boy.edit', 'delivery_boy.delete',

            'subscription.view', 'subscription.create', 'subscription.edit', 'subscription.pause',
            'subscription.assign_delivery',
            'invoice.view', 'invoice.generate', 'invoice.cancel', 'invoice.collect_payment',
            'report.subscription_delivery', 'report.subscription_demand', 'report.subscription_activity',

            'customer.wallet_adjust',
        ];
    }

    private function staffBranchPermissions(): array
    {
        return [
            'stock.request',
            'report.view',
            'report.stock_levels',
            'report.stock_movements',
            'report.stock_requests',
            'report.stock_request_detail',
            'report.delivered_orders',
            'report.delivered_orders_product_wise',
            'report.customer_addresses',
            'report.wallet_balances',
            'report.wallet_transactions',
            'report.coupon_consumption',
            'customer.view',
            'product.view',

            'order.view', 'order.manage', 'order.assign_delivery', 'order.view_cancelled',

            'delivery_boy.view', 'delivery_boy.create', 'delivery_boy.edit', 'delivery_boy.delete',

            'subscription.view', 'subscription.create', 'subscription.edit', 'subscription.pause',
            'subscription.assign_delivery',
            'invoice.view', 'invoice.generate', 'invoice.cancel', 'invoice.collect_payment',
            'report.subscription_delivery', 'report.subscription_demand', 'report.subscription_activity',

            'customer.wallet_adjust',
        ];
    }
}
