<?php

namespace Database\Seeders;

use App\Models\Country;
use App\Models\State;
use Illuminate\Database\Seeder;

class CountryStateSeeder extends Seeder
{
    public function run(): void
    {
        $india = Country::firstOrCreate(
            ['code' => 'IN'],
            ['name' => 'India', 'is_active' => true]
        );

        $states = [
            // States
            ['name' => 'Andhra Pradesh',      'code' => 'AP'],
            ['name' => 'Arunachal Pradesh',   'code' => 'AR'],
            ['name' => 'Assam',               'code' => 'AS'],
            ['name' => 'Bihar',               'code' => 'BR'],
            ['name' => 'Chhattisgarh',        'code' => 'CG'],
            ['name' => 'Goa',                 'code' => 'GA'],
            ['name' => 'Gujarat',             'code' => 'GJ'],
            ['name' => 'Haryana',             'code' => 'HR'],
            ['name' => 'Himachal Pradesh',    'code' => 'HP'],
            ['name' => 'Jharkhand',           'code' => 'JH'],
            ['name' => 'Karnataka',           'code' => 'KA'],
            ['name' => 'Kerala',              'code' => 'KL'],
            ['name' => 'Madhya Pradesh',      'code' => 'MP'],
            ['name' => 'Maharashtra',         'code' => 'MH'],
            ['name' => 'Manipur',             'code' => 'MN'],
            ['name' => 'Meghalaya',           'code' => 'ML'],
            ['name' => 'Mizoram',             'code' => 'MZ'],
            ['name' => 'Nagaland',            'code' => 'NL'],
            ['name' => 'Odisha',              'code' => 'OD'],
            ['name' => 'Punjab',              'code' => 'PB'],
            ['name' => 'Rajasthan',           'code' => 'RJ'],
            ['name' => 'Sikkim',              'code' => 'SK'],
            ['name' => 'Tamil Nadu',          'code' => 'TN'],
            ['name' => 'Telangana',           'code' => 'TS'],
            ['name' => 'Tripura',             'code' => 'TR'],
            ['name' => 'Uttar Pradesh',       'code' => 'UP'],
            ['name' => 'Uttarakhand',         'code' => 'UK'],
            ['name' => 'West Bengal',         'code' => 'WB'],
            // Union Territories
            ['name' => 'Andaman and Nicobar Islands',    'code' => 'AN'],
            ['name' => 'Chandigarh',                     'code' => 'CH'],
            ['name' => 'Dadra and Nagar Haveli and Daman and Diu', 'code' => 'DH'],
            ['name' => 'Delhi',                          'code' => 'DL'],
            ['name' => 'Jammu and Kashmir',              'code' => 'JK'],
            ['name' => 'Ladakh',                         'code' => 'LA'],
            ['name' => 'Lakshadweep',                    'code' => 'LD'],
            ['name' => 'Puducherry',                     'code' => 'PY'],
        ];

        foreach ($states as $state) {
            State::firstOrCreate(
                ['country_id' => $india->id, 'code' => $state['code']],
                ['name' => $state['name'], 'is_active' => true]
            );
        }
    }
}
