<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class TenantDatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolesAndPermissionsSeeder::class,
            MenuSeeder::class,
            TenantProfileSeeder::class,
            CountryStateSeeder::class,
            CitySeeder::class,
            FaqSeeder::class,   // ★ FAQ knowledge base — must run after TenantProfileSeeder so placeholders can be substituted
        ]);
    }
}
