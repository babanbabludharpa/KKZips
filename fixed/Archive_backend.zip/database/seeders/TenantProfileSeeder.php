<?php

namespace Database\Seeders;

use App\Models\TenantProfile;
use Illuminate\Database\Seeder;

class TenantProfileSeeder extends Seeder
{
    public function run(): void
    {
        // One empty row always exists — no null-check branching needed anywhere
        TenantProfile::firstOrCreate(['id' => 1], [
            'company_name' => null,
            'logo' => null,
            'pan_no' => null,
        ]);
    }
}
