<?php

return [
    'admin_email' => env('PLATFORM_ADMIN_EMAIL'),
    'admin_password_hash' => env('PLATFORM_ADMIN_PASSWORD_HASH'),
    'admin_name' => env('PLATFORM_ADMIN_NAME'),
    'secret_key' => env('PLATFORM_SECRET_KEY'),
];
