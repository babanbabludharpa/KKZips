<?php

declare(strict_types=1);

use Stancl\Tenancy\Database\Models\Tenant;
use Stancl\Tenancy\Database\Models\Domain;
use Stancl\Tenancy\Bootstrappers\DatabaseTenancyBootstrapper;
use Stancl\Tenancy\Events;
use Stancl\Tenancy\Jobs;
use Stancl\Tenancy\Listeners;
use Stancl\JobPipeline\JobPipeline;

return [

    'tenant_model' => \App\Models\Tenant::class,

    'id_generator' => Stancl\Tenancy\Database\Concerns\HasAutoIncrementGetKey::class,

    'domain_model' => Domain::class,

    /*
     * The list of domains hosting your central app.
     * Only relevant if you're using the domain identification driver.
     */
    'central_domains' => [
        'inventory.test',
    ],

    /*
     * Tenancy bootstrappers are run when tenancy is initialized.
     * Their responsibility is to make the application behave like a tenant app.
     */
    'bootstrappers' => [
        DatabaseTenancyBootstrapper::class,
    ],

    /*
     * Database tenancy config. Used by DatabaseTenancyBootstrapper.
     */
    /*
     * Database tenancy config. Used by DatabaseTenancyBootstrapper.
     */
    /*
     * Database tenancy config. Used by DatabaseTenancyBootstrapper.
     */
    /*
     * Database tenancy config. Used by DatabaseTenancyBootstrapper.
     */
    /*
     * Database tenancy config. Used by DatabaseTenancyBootstrapper.
     */
    'database' => [
        // ADD THIS LINE: It tells the package your main application connection is 'mysql'
        'central_connection' => env('DB_CONNECTION', 'mysql'),

        'template_tenant_connection' => 'tenant_template',

        'prefix' => 'tenant_',

        'suffix' => '',

        'managers' => [
            'mysql' => Stancl\Tenancy\TenantDatabaseManagers\MySQLDatabaseManager::class,
        ],
    ],

    /*
     * Filesystem tenancy config.
     */
    'filesystem' => [
        'suffix_base' => 'tenant',
        'disks' => [],
        'root_override' => [],
        'suffix_storage_path' => true,
        'asset_helper_tenancy' => false,
    ],

    /*
     * Redis tenancy config.
     */
    'redis' => [
        'prefix_base' => 'tenant',
        'prefixed_connections' => [],
    ],

    /*
     * Cache tenancy config.
     */
    'cache' => [
        'tag_base' => 'tenant',
    ],

    /*
     * Tenant route middleware.
     */
    'middleware' => [
        'auth' => [
            'allowed_callback_domains' => [],
        ],
    ],

    'features' => [],

    'migration_parameters' => [
        '--force'  => true,
        '--path'   => ['database/migrations/tenant'],
        '--realpath' => false,
    ],

    'seeder_parameters' => [
        '--class' => 'TenantDatabaseSeeder',
        '--force' => true,
    ],

    'events' => [
        Events\TenantCreated::class => [
            JobPipeline::make([
                Jobs\CreateDatabase::class,
                Jobs\MigrateDatabase::class,
                // Jobs\SeedDatabase::class,
            ])->send(function (Events\TenantCreated $event) {
                return $event->tenant;
            })->shouldBeQueued(false),
        ],
    ],
];
