<?php

// Platform-level branding, used on the login page when there is no
// tenant context (i.e. inventory.test / kutumbkart.in apex domains --
// see TenantProfileService::getBranding()).
//
// Only brand_name lives here. Platform logo and login-bg image are
// NOT read from backend storage at all -- both are frontend-bundled
// assets (frontend/src/assets/images/kutumbkart_logo.png and
// kutumbkart_login_bg.png), resolved client-side in Login.jsx. This
// config exists only because brand_name is plain text with nowhere
// else to live for the no-tenant case (tenants get theirs from the
// company_name DB column instead).

return [
    'platform' => [
        'brand_name' => 'Kutumbkart',
    ],
];
