<?php

return [

    // ── Warm ────────────────────────────────────────────────
    'crimson' => [
        'label' => 'Crimson',
        'description' => 'Pure red — bold, high-contrast.',
        'preview' => '#dc2626',
        'sort' => 10,
    ],
    'amber' => [
        'label' => 'Amber',
        'description' => 'Warm orange — food, retail.',
        'preview' => '#ea580c',   // was #d97706
        'sort' => 20,
    ],
    'gold' => [
        'label' => 'Gold',
        'description' => 'Luxury executive — warm gold on bronze-black.',
        'preview' => '#b8860b',
        'sort' => 30,
    ],

    // ── Fresh ───────────────────────────────────────────────
    'lime' => [
        'label' => 'Lime',
        'description' => 'Electric chartreuse — fresh, tech-forward.',
        'preview' => '#84cc16',
        'sort' => 40,
    ],
    'emerald' => [
        'label' => 'Emerald',
        'description' => 'Green — organic, groceries, wellness.',
        'preview' => '#059669',
        'sort' => 50,
    ],

    // ── Cool ────────────────────────────────────────────────
    'ocean' => [
        'label' => 'Ocean',
        'description' => 'Bright fresh blue — corporate, modern.',
        'preview' => '#2563eb',
        'sort' => 60,
    ],
    'sky' => [
        'label' => 'Sky',
        'description' => 'Pastel airy blue — light, calm.',
        'preview' => '#0ea5e9',
        'sort' => 70,
    ],
    'royal' => [
        'label' => 'Royal',
        'description' => 'Deep navy — enterprise premium.',
        'preview' => '#1e3a8a',
        'sort' => 80,
    ],
    'violet' => [
        'label' => 'Violet',
        'description' => 'Cosmic purple — modern SaaS glow.',
        'preview' => '#7c3aed',
        'sort' => 90,
    ],

    // ── Vivid ───────────────────────────────────────────────
    'magenta' => [
        'label' => 'Magenta',
        'description' => 'Bold fuchsia — creative, beauty.',
        'preview' => '#c026d3',
        'sort' => 100,
    ],
    'rose' => [
        'label' => 'Rose',
        'description' => 'Pink — lifestyle, retail brands.',
        'preview' => '#e11d48',
        'sort' => 110,
    ],

    // ── Neutral ─────────────────────────────────────────────
    'graphite' => [
        'label' => 'Graphite',
        'description' => 'Neutral slate — no color bias.',
        'preview' => '#475569',
        'sort' => 120,
    ],
];
