<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may configure your settings for cross-origin resource sharing
    | or "CORS". This determines what cross-origin operations may execute
    | in web browsers. You are free to adjust these settings as needed.
    |
    | To learn more: https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS
    |
    */

    'paths' => ['api/*', 'api/v1/*', 'sanctum/csrf-cookie'],
    'allowed_methods' => ['*'],
    #'allowed_origins' => ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://inventory.test:5173',],
    #'allowed_origins_patterns' => [],
    //'allowed_origins' => ['http://inventory.test:5173'],
    //'allowed_origins' => ['https://kutumbkart.in', 'https://directsellingnewsindia.com', 'https://directsellingnews.in'],
    'allowed_origins' => ['*'],
    #'allowed_origins_patterns' => [],
    'allowed_origins_patterns' => ['#^http://.*\.inventory\.test:5173$#'],
    'allowed_headers' => ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin'],
    'exposed_headers' => [],
    'max_age' => 0,
    'supports_credentials' => true,

];
