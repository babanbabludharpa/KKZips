<?php

use App\Models\Tenant\Customer;
use App\Models\User;
use App\Models\DeliveryBoy;

return [

    'defaults' => [
        'guard' => 'web',
        'passwords' => 'users',
    ],

    'guards' => [
        'sanctum' => [
            'driver' => 'sanctum',
            'provider' => 'users',
        ],
        'customer' => [
            'driver' => 'sanctum',
            'provider' => 'customers',
        ],
        'rider' => [
            'driver' => 'sanctum',
            'provider' => 'delivery_boys',
        ],
    ],

    'providers' => [
        'users' => [
            'driver' => 'eloquent',
            'model' => env('AUTH_MODEL', User::class),
        ],
        'customers' => [
            'driver' => 'eloquent',
            'model' => Customer::class,
        ],
        'delivery_boys' => [
            'driver' => 'eloquent',
            'model' => DeliveryBoy::class,
        ],
    ],

    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table' => env('AUTH_PASSWORD_RESET_TOKEN_TABLE', 'password_reset_tokens'),
            'expire' => 60,
            'throttle' => 60,
        ],
    ],

    'password_timeout' => env('AUTH_PASSWORD_TIMEOUT', 10800),

];
