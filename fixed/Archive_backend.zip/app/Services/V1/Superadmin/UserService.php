<?php

namespace App\Services\V1\Superadmin;

use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Models\Role;
use Symfony\Component\HttpFoundation\StreamedResponse;

class UserService
{
    // Public disk (storage/app/public), served via the storage symlink like delivery-boy documents.
    public const DISK = 'public';

    public const DOCS = ['adhar_doc', 'pan_doc'];

    /** Roles that carry KYC / bank data. Superadmin is deliberately excluded. */
    public const KYC_ROLES = ['admin', 'staff_headoffice', 'staff_stateoffice', 'staff_branch'];

    private const KYC_PLAIN = [
        'emergency_contact_no', 'bank_account_holder', 'bank_name', 'bank_ifsc', 'upi_id',
    ];

    // Blank means "keep the stored value" (the API never returns these in full).
    private const KYC_SENSITIVE = ['adhar_no', 'pan_no', 'bank_account_no'];

    private const SORTABLE = [
        'name',
        'username',
        'email',
        'mobile_number',
        'created_at',
    ];

    public static function adharHash(string $adhar): string
    {
        return hash_hmac('sha256', $adhar, config('app.key'));
    }

    /** Filters + sort shared by the list and the CSV export. */
    private function buildQuery(array $filters = []): Builder
    {
        $query = User::with('roles', 'branch');

        // ── Search ──
        if (! empty($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('name', 'like', '%'.$filters['search'].'%')
                    ->orWhere('email', 'like', '%'.$filters['search'].'%')
                    ->orWhere('username', 'like', '%'.$filters['search'].'%')
                    ->orWhere('mobile_number', 'like', '%'.$filters['search'].'%');
            });
        }

        // ── Role filter ──
        if (! empty($filters['role'])) {
            $query->whereHas('roles', fn ($q) => $q->where('name', $filters['role']));
        }

        // ── Branch filter ──
        $authUser = auth()->user();
        $isHeadoffice = $authUser && $authUser->hasRole('staff_headoffice');

        if ($isHeadoffice && ! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        // ── Sorting ──
        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

        if ($sortKey && in_array($sortKey, self::SORTABLE, true)) {
            $query->orderBy($sortKey, $sortDir);
        } else {
            $query->orderBy('created_at', 'desc');
        }

        // Tie-breaker: without it, offset paging / chunking can repeat or skip rows
        // when the sort column has duplicates (name, created_at...).
        return $query->orderBy('id');
    }

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        return $this->buildQuery($filters)->paginate($filters['per_page'] ?? 25);
    }

    public function exportCsv(array $filters = []): StreamedResponse
    {
        $query = $this->buildQuery($filters);
        $filename = 'users_'.now()->format('Y-m-d').'.csv';

        return response()->streamDownload(function () use ($query) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel reads it correctly

            fputcsv($out, [
                'Sr. No', 'Name', 'Username', 'Mobile', 'Emergency Contact', 'Email', 'Role', 'Branch',
                'Aadhaar No', 'PAN No', 'Aadhaar Copy', 'PAN Copy',
                'Account Holder', 'Bank', 'Account No', 'IFSC', 'UPI ID', 'Created At',
            ]);

            $i = 0;
            foreach ($query->lazy(500) as $u) {
                $row = [
                    ++$i,
                    $u->name,
                    $u->username,
                    $u->mobile_number,
                    $u->emergency_contact_no,
                    $u->email,
                    $u->roles->first()?->name,
                    $u->branch?->name,
                    self::maskValue($u->adhar_no),
                    self::maskValue($u->pan_no),
                    $u->adhar_doc ? asset('storage/'.$u->adhar_doc) : null,
                    $u->pan_doc ? asset('storage/'.$u->pan_doc) : null,
                    $u->bank_account_holder,
                    $u->bank_name,
                    self::maskValue($u->bank_account_no),
                    $u->bank_ifsc,
                    $u->upi_id,
                    optional($u->created_at)->toDateTimeString(),
                ];

                fputcsv($out, array_map([self::class, 'csvSafe'], $row));
            }

            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function findById(int $id): User
    {
        return User::with('roles', 'permissions', 'branch')->findOrFail($id);
    }

    public function create(array $data): User
    {
        $this->guardRoleAssignment($data['role'] ?? null, $data['branch_id'] ?? null);

        $new = [];

        try {
            // One transaction: a missing role no longer leaves a role-less user behind.
            $user = DB::transaction(function () use ($data, &$new) {
                $old = [];

                $user = User::create(array_merge([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'username' => $data['username'],
                    'mobile_number' => $data['mobile_number'],
                    'password' => Hash::make($data['password']),
                    'branch_id' => $data['branch_id'] ?? null,
                ], $this->kycAttributes(null, $data, $data['role'] ?? null, $new, $old)));

                if (! empty($data['role'])) {
                    $role = Role::where('guard_name', 'sanctum')
                        ->where('name', $data['role'])
                        ->firstOrFail();
                    $user->assignRole($role);
                }

                return $user;
            });
        } catch (\Throwable $e) {
            $this->deleteFiles($new); // DB rolled back, don't orphan the uploads
            throw $e;
        }

        return $user->load('roles', 'branch');
    }

    public function update(User $user, array $data): User
    {
        $this->guardSuperadmin($user);

        if (! empty($data['role'])) {
            $this->guardRoleAssignment($data['role'], $data['branch_id'] ?? $user->branch_id);
        }

        $new = [];
        $old = [];

        try {
            DB::transaction(function () use ($user, $data, &$new, &$old) {
                $updateData = array_filter([
                    'name' => $data['name'] ?? null,
                    'email' => $data['email'] ?? null,
                    'username' => $data['username'] ?? null,
                    'mobile_number' => $data['mobile_number'] ?? null,
                ]);

                if (array_key_exists('branch_id', $data)) {
                    $updateData['branch_id'] = $data['branch_id'];
                }

                if (! empty($data['password'])) {
                    $updateData['password'] = Hash::make($data['password']);
                }

                $role = $data['role'] ?? $user->getRoleNames()->first();
                $updateData = array_merge($updateData, $this->kycAttributes($user, $data, $role, $new, $old));

                $user->update($updateData);

                if (! empty($data['role'])) {
                    $roleModel = Role::where('guard_name', 'sanctum')
                        ->where('name', $data['role'])
                        ->firstOrFail();
                    $user->syncRoles([$roleModel]);
                }
            });
        } catch (\Throwable $e) {
            $this->deleteFiles($new);
            throw $e;
        }

        $this->deleteFiles($old); // only after commit

        return $user->fresh(['roles', 'branch']);
    }

    public function delete(User $user): void
    {
        $this->guardSuperadmin($user);

        if ($user->id === auth()->id()) {
            abort(422, 'You cannot delete your own account.');
        }

        $paths = array_filter(array_map(fn ($f) => $user->{$f}, self::DOCS));

        $user->delete();

        $this->deleteFiles($paths);
    }

    public function assignRole(User $user, string $roleName): User
    {
        $this->guardSuperadmin($user);
        $this->guardRoleAssignment($roleName, $user->branch_id);

        $role = Role::where('guard_name', 'sanctum')
            ->where('name', $roleName)
            ->firstOrFail();

        $user->syncRoles([$role]);

        return $user->fresh(['roles', 'branch']);
    }

    /**
     * Columns to write for the KYC / bank block. Empty for roles that don't carry it
     * (e.g. superadmin), so those values are never written for them.
     *
     * @param  array  $new  paths stored by this call (cleanup on rollback)
     * @param  array  $old  paths replaced by this call (delete after commit)
     */
    private function kycAttributes(?User $user, array $data, ?string $role, array &$new, array &$old): array
    {
        if (! in_array($role, self::KYC_ROLES, true)) {
            return [];
        }

        $attrs = [];

        foreach (self::KYC_PLAIN as $f) {
            if (array_key_exists($f, $data)) {
                $attrs[$f] = $data[$f];
            }
        }

        foreach (self::KYC_SENSITIVE as $f) {
            if (! empty($data[$f])) {
                $attrs[$f] = $data[$f];
            }
        }

        if (! empty($data['adhar_no'])) {
            $attrs['adhar_hash'] = self::adharHash($data['adhar_no']);
        }

        foreach (self::DOCS as $f) {
            $file = $data[$f] ?? null;
            if ($file instanceof UploadedFile) {
                if ($user?->{$f}) {
                    $old[] = $user->{$f};
                }
                $attrs[$f] = $file->store($this->storageDir(), self::DISK);
                $new[] = $attrs[$f];
            }
        }

        return $attrs;
    }

    private function storageDir(): string
    {
        $tenantId = tenant('id');

        if (! $tenantId) {
            throw new \RuntimeException('Tenant context required for document upload.');
        }

        return "tenants/{$tenantId}/users/documents";
    }

    private function deleteFiles(array $paths): void
    {
        foreach ($paths as $path) {
            Storage::disk(self::DISK)->delete($path);
        }
    }

    private function guardSuperadmin(User $user): void
    {
        if ($user->hasRole('superadmin')) {
            abort(403, 'Superadmin account cannot be modified.');
        }
    }

    private function guardRoleAssignment(?string $role, mixed $branchId): void
    {
        $authUser = auth()->user();

        if ($authUser->hasRole('superadmin')) {
            return;
        }

        if ($authUser->hasRole('admin')) {
            if ($role && in_array($role, ['superadmin', 'admin'])) {
                abort(403, 'You are not authorized to assign this role.');
            }

            if (empty($branchId)) {
                abort(422, 'Branch assignment is required.');
            }
        }
    }

    private static function maskValue(?string $value): ?string
    {
        if (! $value) {
            return null;
        }
        $len = strlen($value);

        return $len <= 4 ? $value : str_repeat('X', $len - 4).substr($value, -4);
    }

    /** Neutralise spreadsheet formula injection (=, +, -, @, tab, CR at cell start). */
    private static function csvSafe(mixed $v): mixed
    {
        return is_string($v) && $v !== '' && str_contains("=+-@\t\r", $v[0])
            ? "'".$v
            : $v;
    }
}
