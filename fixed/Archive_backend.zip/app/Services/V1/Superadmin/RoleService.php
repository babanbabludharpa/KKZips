<?php

namespace App\Services\V1\Superadmin;

use Illuminate\Pagination\LengthAwarePaginator;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleService
{
    protected array $protectedRoles = ['superadmin'];

    private const SORTABLE = [
        'name',
        'users_count',
        'created_at',
    ];

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $query = Role::where('guard_name', 'sanctum')
            ->withCount('users')
            ->with('permissions');

        if (! empty($filters['search'])) {
            $query->where('name', 'like', '%'.$filters['search'].'%');
        }

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

        if ($sortKey && in_array($sortKey, self::SORTABLE, true)) {
            $query->orderBy($sortKey, $sortDir);
        } else {
            $query->orderBy('name', 'asc');
        }

        return $query->paginate($filters['per_page'] ?? 25);
    }

    public function findById(int $id): Role
    {
        return Role::where('guard_name', 'sanctum')
            ->with('permissions')
            ->findOrFail($id);
    }

    public function create(array $data): Role
    {
        $role = Role::create([
            'name' => strtolower(trim($data['name'])),
            'guard_name' => 'sanctum',
        ]);

        if (! empty($data['permissions'])) {
            $permissions = Permission::where('guard_name', 'sanctum')
                ->whereIn('name', $data['permissions'])
                ->get();
            $role->syncPermissions($permissions);
        }

        return $role->load('permissions');
    }

    public function update(Role $role, array $data): Role
    {
        $this->guardProtectedRole($role->name);

        if (isset($data['name'])) {
            $role->update(['name' => strtolower(trim($data['name']))]);
        }

        if (isset($data['permissions'])) {
            $permissions = Permission::where('guard_name', 'sanctum')
                ->whereIn('name', $data['permissions'])
                ->get();
            $role->syncPermissions($permissions);
        }

        return $role->fresh('permissions');
    }

    public function delete(Role $role): void
    {
        $this->guardProtectedRole($role->name);

        if ($role->users()->count() > 0) {
            abort(422, 'Cannot delete a role that is assigned to users.');
        }

        $role->delete();
    }

    public function syncPermissions(Role $role, array $permissionNames): Role
    {
        $this->guardProtectedRole($role->name);

        $permissions = Permission::where('guard_name', 'sanctum')
            ->whereIn('name', $permissionNames)
            ->get();

        $role->syncPermissions($permissions);

        return $role->fresh('permissions');
    }

    private function guardProtectedRole(string $name): void
    {
        if (in_array($name, $this->protectedRoles)) {
            abort(403, 'This role cannot be modified or deleted.');
        }
    }
}
