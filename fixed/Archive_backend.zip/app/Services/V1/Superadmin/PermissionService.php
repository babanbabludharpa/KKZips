<?php

namespace App\Services\V1\Superadmin;

use Illuminate\Database\Eloquent\Collection;
use Spatie\Permission\Models\Permission;

class PermissionService
{
    public function getAll(): Collection
    {
        return Permission::where('guard_name', 'sanctum')
            ->orderBy('name')
            ->get();
    }

    public function getGrouped(): array
    {
        $permissions = $this->getAll();

        return $permissions->groupBy(function ($permission) {
            return explode('.', $permission->name)[0] ?? 'general';
        })->toArray();
    }

    public function create(array $data): Permission
    {
        return Permission::create([
            'name' => strtolower(trim($data['name'])),
            'guard_name' => 'sanctum',
        ]);
    }

    public function update(Permission $permission, array $data): Permission
    {
        // Prevent editing system-critical permissions
        $this->guardSystemPermission($permission->name);

        $permission->update([
            'name' => strtolower(trim($data['name'])),
        ]);

        return $permission->fresh();
    }

    public function delete(Permission $permission): void
    {
        $this->guardSystemPermission($permission->name);

        $permission->delete();
    }

    public function findById(int $id): Permission
    {
        return Permission::where('guard_name', 'sanctum')->findOrFail($id);
    }

    // Prevent deletion/editing of core system permissions
    private function guardSystemPermission(string $name): void
    {
        $protected = [
            'user.manage', 'role.view', 'role.create', 'role.edit',
            'role.delete', 'permission.assign', 'system.settings', 'audit.view',
        ];

        if (in_array($name, $protected)) {
            abort(403, 'System permissions cannot be modified.');
        }
    }
}
