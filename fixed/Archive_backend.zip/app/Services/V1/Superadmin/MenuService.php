<?php

namespace App\Services\V1\Superadmin;

use App\Models\Menu;
use Illuminate\Support\Collection;

class MenuService
{
    // For sidebar — filtered by user permissions, active only
    public function getFilteredTree(array $userPermissions): Collection
    {
        $menus = Menu::with('children')
            ->topLevel()
            ->active()
            ->orderBy('sort_order')
            ->get();

        return $menus->filter(function ($menu) use ($userPermissions) {
            $menu->setRelation('children',
                $menu->children->filter(function ($child) use ($userPermissions) {
                    return $this->userCanSee($child, $userPermissions);
                })->values()
            );

            return $this->userCanSee($menu, $userPermissions) || $menu->children->isNotEmpty();
        })->values();
    }

    // For superadmin management UI — all menus including inactive
    public function getFullTree(): Collection
    {
        return Menu::with('children')       // ← was allChildren, must match resource
            ->topLevel()
            ->orderBy('sort_order')
            ->get();
    }

    public function getAll(): Collection
    {
        return Menu::orderBy('parent_id')->orderBy('sort_order')->get();
    }

    public function findById(int $id): Menu
    {
        return Menu::findOrFail($id);
    }

    public function create(array $data): Menu
    {
        if (! isset($data['sort_order'])) {
            $data['sort_order'] = Menu::where('parent_id', $data['parent_id'] ?? null)->max('sort_order') + 1;
        }

        return Menu::create($data);
    }

    public function update(Menu $menu, array $data): Menu
    {
        $menu->update($data);

        return $menu->fresh();
    }

    public function delete(Menu $menu): void
    {
        Menu::where('parent_id', $menu->id)->update(['parent_id' => null]);
        $menu->delete();
    }

    public function reorder(array $items): void
    {
        foreach ($items as $item) {
            Menu::where('id', $item['id'])->update([
                'sort_order' => $item['sort_order'],
                'parent_id' => $item['parent_id'] ?? null,
            ]);
        }
    }

    private function userCanSee(Menu $menu, array $userPermissions): bool
    {
        if (! $menu->permission) {
            return true;
        }

        return in_array($menu->permission, $userPermissions);
    }
}
