<?php

namespace App\Services\V1\Notifications;

use App\Models\Tenant\Order;
use Illuminate\Support\Facades\Log;
use Kreait\Firebase\Contract\Messaging;
use Kreait\Firebase\Exception\Messaging\InvalidArgument;
use Kreait\Firebase\Exception\Messaging\NotFound;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification as FcmNotification;

class PushNotificationService
{
    public function __construct(protected Messaging $messaging) {}

    private const STATUS_MESSAGES = [
        'confirmed' => 'Your order has been confirmed!',
        'preparing' => 'Your order is being prepared.',
        'out_for_delivery' => 'Your order is out for delivery!',
        'picked_up' => 'Your order has been picked up.',
        'delivered' => 'Your order has been delivered. Enjoy!',
        'cancelled' => 'Your order was cancelled.',
        'payment_failed' => 'Payment failed for your order.',
    ];

    public function sendOrderStatusUpdate(Order $order, string $status): void
    {
        $body = self::STATUS_MESSAGES[$status] ?? "Order status updated to {$status}";
        $tokens = $order->customer->deviceTokens()->pluck('token')->all();

        if (empty($tokens)) {
            return; // no registered devices, nothing to send
        }

        $orderLabel = $order->order_number ?? (string) $order->id;

        $message = CloudMessage::new()
            ->withNotification(FcmNotification::create("Order {$orderLabel}", $body))
            ->withData([
                'type' => 'order_status',
                'order_id' => (string) $order->id,
                'status' => $status,
            ]);

        foreach ($tokens as $token) {
            try {
                $this->messaging->send($message->withChangedTarget('token', $token));
            } catch (NotFound|InvalidArgument $e) {
                // token is dead (uninstalled app, expired) -- clean it up
                $order->customer->deviceTokens()->where('token', $token)->delete();
            } catch (\Throwable $e) {
                Log::warning('FCM send failed', ['order_id' => $order->id, 'error' => $e->getMessage()]);
            }
        }
    }
}
