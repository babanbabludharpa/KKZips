<?php

namespace App\Services\V1\Dashboard;

use App\Models\TenantProfile;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardService
{
    private const TABLE_CUSTOMERS_ALIAS = 'customers as c';

    private const COL_CUSTOMER_ID = 'c.id';

    private const COL_CUSTOMER_NAME = 'c.name as customer_name';

    private const TABLE_BRANCHES_ALIAS = 'branches as b';

    private const COL_BRANCH_ID = 'b.id';

    private const COL_BRANCH_NAME = 'b.name as branch_name';

    private const TABLE_SUB_OCCURRENCES_ALIAS = 'subscription_occurrences as so';

    private const COL_SUB_OCCURRENCE_DATE = 'so.occurrence_date';

    private const TABLE_SUB_ITEMS_ALIAS = 'subscription_items as si';

    private const TABLE_SUBSCRIPTIONS_ALIAS = 'subscriptions as s';

    private const TABLE_WALLET_TX_ALIAS = 'wallet_transactions as wt';

    private const TABLE_CUSTOMER_ADDRESSES_ALIAS = 'customer_addresses as ca';

    private const LAG_SIGNED_DELTA_EXPR =
        'wt.balance_after - COALESCE('
        .'LAG(wt.balance_after) OVER (PARTITION BY wt.customer_id ORDER BY wt.created_at, wt.id)'
        .', 0) as signed_delta';

    public function build(?int $branchId, bool $isSuperadmin): array
    {
        $profile = TenantProfile::first();

        $modules = [
            'orders' => (bool) ($profile?->has_orders ?? true),
            'subscriptions' => (bool) ($profile?->has_subscriptions ?? true),
            'wallet' => (bool) ($profile?->has_wallet ?? true),
        ];

        $today = Carbon::today();
        $from7d = Carbon::today()->subDays(6);

        $payload = [
            'modules' => $modules,
            'role_scope' => $isSuperadmin ? 'superadmin' : 'branch',
            'branch_id' => $branchId,
        ];

        if ($modules['orders']) {
            $payload['orders'] = $this->ordersSection($branchId, $today, $from7d);
        }

        if ($modules['subscriptions']) {
            $payload['subscriptions'] = $this->subscriptionsSection($branchId, $isSuperadmin, $today, $from7d);
        }

        if ($modules['wallet']) {
            $payload['wallet'] = $this->walletSection($branchId, $today);
        }

        if ($modules['orders'] || $modules['subscriptions']) {
            $payload['shared'] = [
                'low_stock_items' => $this->lowStockItems($branchId),
                'pending_stock_requests' => $this->pendingStockRequests($branchId),
            ];
        }

        return $payload;
    }

    private function ordersSection(?int $branchId, Carbon $today, Carbon $from): array
    {
        return [
            'kpis' => [
                'placed_today' => $this->orderPlacedToday($branchId, $today),
                'revenue_today' => $this->orderRevenueToday($branchId, $today),
                'pending' => $this->orderPending($branchId, $today),
            ],
            'charts' => [
                'trend' => $this->orderTrend($branchId, $from, $today),
            ],
            'tables' => [
                'recent_orders' => $this->recentOrders($branchId),
            ],
        ];
    }

    private function orderPlacedToday(?int $branchId, Carbon $today): int
    {
        return (int) DB::table('orders')
            ->whereDate('created_at', $today)
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->count();
    }

    private function orderRevenueToday(?int $branchId, Carbon $today): float
    {
        $query = DB::table('orders')
            ->whereDate('created_at', $today->toDateString())
            ->where('payment_status', 'paid');

        if ($branchId !== null) {
            $query->where('branch_id', $branchId);
        }

        return (float) $query->sum('total');
    }

    private function orderPending(?int $branchId, Carbon $today): int
    {
        return (int) DB::table('orders')
            ->whereDate('created_at', $today)
            ->whereIn('status', [
                'pending_payment', 'confirmed', 'preparing',
                'out_for_delivery', 'picked_up',
            ])
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->count();
    }

    private function orderTrend(?int $branchId, Carbon $from, Carbon $to): array
    {
        $rows = DB::table('orders')
            ->whereBetween(DB::raw('DATE(created_at)'), [$from->toDateString(), $to->toDateString()])
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->select(
                DB::raw('DATE(created_at) as d'),
                DB::raw('COUNT(*) as placed'),
                DB::raw("SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered"),
                DB::raw("SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END) as revenue"),
            )
            ->groupBy('d')
            ->orderBy('d')
            ->get()
            ->keyBy('d');

        $out = [];
        for ($d = $from->copy(); $d->lte($to); $d->addDay()) {
            $key = $d->toDateString();
            $row = $rows[$key] ?? null;
            $out[] = [
                'date' => $key,
                'placed' => (int) ($row->placed ?? 0),
                'delivered' => (int) ($row->delivered ?? 0),
                'revenue' => (float) ($row->revenue ?? 0),
            ];
        }

        return $out;
    }

    private function recentOrders(?int $branchId): array
    {
        return DB::table('orders as o')
            ->leftJoin(self::TABLE_CUSTOMERS_ALIAS, self::COL_CUSTOMER_ID, '=', 'o.customer_id')
            ->leftJoin(self::TABLE_BRANCHES_ALIAS, self::COL_BRANCH_ID, '=', 'o.branch_id')
            ->when($branchId, fn ($q) => $q->where('o.branch_id', $branchId))
            ->orderByDesc('o.created_at')
            ->limit(10)
            ->select(
                'o.id',
                'o.order_number',
                'o.status',
                'o.payment_status',
                'o.payment_mode',
                'o.total',
                'o.created_at',
                self::COL_CUSTOMER_NAME,
                self::COL_BRANCH_NAME,
            )
            ->get()
            ->map(fn ($r) => [
                'id' => (int) $r->id,
                'order_number' => $r->order_number,
                'status' => $r->status,
                'payment_status' => $r->payment_status,
                'payment_mode' => $r->payment_mode,
                'total' => (float) $r->total,
                'created_at' => $r->created_at,
                'customer_name' => $r->customer_name,
                'branch_name' => $r->branch_name,
            ])
            ->all();
    }

    private function subscriptionsSection(?int $branchId, bool $isSuperadmin, Carbon $today, Carbon $from): array
    {
        $stats = $this->subscriptionStatsToday($branchId, $today);

        return [
            'kpis' => [
                'delivered' => $stats['delivered'],
                'missed' => $stats['missed'],
                'revenue_today' => $this->subscriptionRevenueToday($branchId, $today),
            ],
            'charts' => [
                'delivery_trend' => $this->subscriptionDeliveryTrend($branchId, $from, $today),
            ],
            'tables' => [
                'deliveries_by_branch' => $isSuperadmin
                    ? $this->subscriptionDeliveriesByBranch($today)
                    : [],
            ],
        ];
    }

    private function subscriptionStatsToday(?int $branchId, Carbon $today): array
    {
        $q = DB::table(self::TABLE_SUB_OCCURRENCES_ALIAS)
            ->whereDate(self::COL_SUB_OCCURRENCE_DATE, $today);

        if ($branchId) {
            $q->whereExists(function ($sub) use ($branchId) {
                $sub->select(DB::raw(1))
                    ->from(self::TABLE_SUB_ITEMS_ALIAS)
                    ->join(self::TABLE_SUBSCRIPTIONS_ALIAS, 's.id', '=', 'si.subscription_id')
                    ->whereColumn('si.id', 'so.subscription_item_id')
                    ->where('s.branch_id', $branchId);
            });
        }

        $rows = $q->select('so.status', DB::raw('COUNT(*) as cnt'))
            ->groupBy('so.status')
            ->pluck('cnt', 'status');

        return [
            'total' => (int) $rows->sum(),
            'delivered' => (int) ($rows['delivered'] ?? 0),
            'missed' => (int) ($rows['not_delivered'] ?? 0),
        ];
    }

    private function subscriptionRevenueToday(?int $branchId, Carbon $today): float
    {
        return (float) DB::table('invoices')
            ->whereDate('generated_at', $today)
            ->whereIn('status', ['generated', 'partially_paid', 'paid'])
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->sum('total');
    }

    private function subscriptionDeliveryTrend(?int $branchId, Carbon $from, Carbon $to): array
    {
        $q = DB::table(self::TABLE_SUB_OCCURRENCES_ALIAS)
            ->whereBetween(self::COL_SUB_OCCURRENCE_DATE, [$from->toDateString(), $to->toDateString()])
            ->select(
                'so.occurrence_date as d',
                DB::raw("SUM(CASE WHEN so.status = 'delivered' THEN 1 ELSE 0 END) as delivered"),
                DB::raw("SUM(CASE WHEN so.status = 'not_delivered' THEN 1 ELSE 0 END) as missed"),
            )
            ->groupBy('so.occurrence_date')
            ->orderBy('so.occurrence_date');

        if ($branchId) {
            $q->whereExists(function ($sub) use ($branchId) {
                $sub->select(DB::raw(1))
                    ->from(self::TABLE_SUB_ITEMS_ALIAS)
                    ->join(self::TABLE_SUBSCRIPTIONS_ALIAS, 's.id', '=', 'si.subscription_id')
                    ->whereColumn('si.id', 'so.subscription_item_id')
                    ->where('s.branch_id', $branchId);
            });
        }

        $rows = $q->get()->keyBy(fn ($r) => is_string($r->d) ? $r->d : Carbon::parse($r->d)->toDateString());

        $out = [];
        for ($d = $from->copy(); $d->lte($to); $d->addDay()) {
            $key = $d->toDateString();
            $row = $rows[$key] ?? null;
            $out[] = [
                'date' => $key,
                'delivered' => (int) ($row->delivered ?? 0),
                'missed' => (int) ($row->missed ?? 0),
            ];
        }

        return $out;
    }

    private function subscriptionDeliveriesByBranch(Carbon $today): array
    {
        return DB::table(self::TABLE_SUB_OCCURRENCES_ALIAS)
            ->join(self::TABLE_SUB_ITEMS_ALIAS, 'si.id', '=', 'so.subscription_item_id')
            ->join(self::TABLE_SUBSCRIPTIONS_ALIAS, 's.id', '=', 'si.subscription_id')
            ->join(self::TABLE_BRANCHES_ALIAS, self::COL_BRANCH_ID, '=', 's.branch_id')
            ->whereDate(self::COL_SUB_OCCURRENCE_DATE, $today)
            ->select(
                'b.id as branch_id',
                self::COL_BRANCH_NAME,
                DB::raw('COUNT(*) as total'),
                DB::raw("SUM(CASE WHEN so.status = 'delivered' THEN 1 ELSE 0 END) as delivered"),
                DB::raw("SUM(CASE WHEN so.status = 'not_delivered' THEN 1 ELSE 0 END) as missed"),
            )
            ->groupBy('b.id', 'b.name')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(fn ($r) => [
                'branch_id' => (int) $r->branch_id,
                'branch_name' => $r->branch_name,
                'total' => (int) $r->total,
                'delivered' => (int) $r->delivered,
                'missed' => (int) $r->missed,
                'pending' => max(0, (int) $r->total - (int) $r->delivered - (int) $r->missed),
            ])
            ->all();
    }

    private function walletSection(?int $branchId, Carbon $today): array
    {
        return [
            'kpis' => [
                'credits_today' => $this->walletCreditsToday($branchId, $today),
                'debits_today' => $this->walletDebitsToday($branchId, $today),
            ],
            'tables' => [
                'recent_activity' => $this->recentWalletActivity($branchId),
            ],
        ];
    }

    private function walletCreditsToday(?int $branchId, Carbon $today): float
    {
        $withDelta = DB::table(self::TABLE_WALLET_TX_ALIAS)
            ->select([
                'wt.id',
                'wt.customer_id',
                'wt.created_at',
                DB::raw(self::LAG_SIGNED_DELTA_EXPR),
            ]);

        $q = DB::query()->fromSub($withDelta, 'wt')
            ->join(self::TABLE_CUSTOMERS_ALIAS, self::COL_CUSTOMER_ID, '=', 'wt.customer_id')
            ->whereDate('wt.created_at', $today->toDateString())
            ->where('wt.signed_delta', '>', 0);

        if ($branchId) {
            $q->whereExists(function ($sub) use ($branchId) {
                $sub->select(DB::raw(1))
                    ->from(self::TABLE_CUSTOMER_ADDRESSES_ALIAS)
                    ->whereColumn('ca.customer_id', 'c.id')
                    ->where('ca.branch_id', $branchId);
            });
        }

        return (float) $q->sum('wt.signed_delta');
    }

    private function walletDebitsToday(?int $branchId, Carbon $today): float
    {
        $withDelta = DB::table(self::TABLE_WALLET_TX_ALIAS)
            ->select([
                'wt.id',
                'wt.customer_id',
                'wt.created_at',
                DB::raw(self::LAG_SIGNED_DELTA_EXPR),
            ]);

        $q = DB::query()->fromSub($withDelta, 'wt')
            ->join(self::TABLE_CUSTOMERS_ALIAS, self::COL_CUSTOMER_ID, '=', 'wt.customer_id')
            ->whereDate('wt.created_at', $today->toDateString())
            ->where('wt.signed_delta', '<', 0);

        if ($branchId) {
            $q->whereExists(function ($sub) use ($branchId) {
                $sub->select(DB::raw(1))
                    ->from(self::TABLE_CUSTOMER_ADDRESSES_ALIAS)
                    ->whereColumn('ca.customer_id', 'c.id')
                    ->where('ca.branch_id', $branchId);
            });
        }

        return (float) abs($q->sum('wt.signed_delta'));
    }

    private function recentWalletActivity(?int $branchId): array
    {
        $withDelta = DB::table(self::TABLE_WALLET_TX_ALIAS)
            ->select([
                'wt.*',
                DB::raw(self::LAG_SIGNED_DELTA_EXPR),
            ]);

        $q = DB::query()->fromSub($withDelta, 'wt')
            ->join(self::TABLE_CUSTOMERS_ALIAS, self::COL_CUSTOMER_ID, '=', 'wt.customer_id')
            ->select([
                'wt.id',
                'wt.customer_id',
                self::COL_CUSTOMER_NAME,
                'wt.type',
                'wt.amount',
                'wt.signed_delta',
                'wt.balance_after',
                'wt.reference_type',
                'wt.reference_id',
                'wt.remark',
                'wt.created_at',
            ])
            ->orderByDesc('wt.created_at')
            ->orderByDesc('wt.id')
            ->limit(10);

        if ($branchId) {
            $q->whereExists(function ($sub) use ($branchId) {
                $sub->select(DB::raw(1))
                    ->from(self::TABLE_CUSTOMER_ADDRESSES_ALIAS)
                    ->whereColumn('ca.customer_id', 'c.id')
                    ->where('ca.branch_id', $branchId);
            });
        }

        return $q->get()->map(fn ($r) => [
            'id' => (int) $r->id,
            'customer_name' => $r->customer_name,
            'type' => $r->type,
            'amount' => (float) $r->amount,
            'signed_delta' => (float) $r->signed_delta,
            'balance_after' => (float) $r->balance_after,
            'reference_type' => $r->reference_type,
            'reference_id' => $r->reference_id ? (int) $r->reference_id : null,
            'remark' => $r->remark,
            'created_at' => $r->created_at,
        ])->all();
    }

    private function lowStockItems(?int $branchId): array
    {
        $threshold = 50;

        $q = DB::table('inventory as i')
            ->join('product_variants as pv', 'pv.id', '=', 'i.product_variant_id')
            ->join('products as p', 'p.id', '=', 'pv.product_id')
            ->join(self::TABLE_BRANCHES_ALIAS, self::COL_BRANCH_ID, '=', 'i.branch_id')
            ->whereNull('pv.deleted_at')
            ->where('i.quantity', '<=', $threshold)
            ->select(
                'pv.sku',
                'p.name as product_name',
                self::COL_BRANCH_NAME,
                'i.quantity',
                'pv.min_order_qty',
            )
            ->orderBy('i.quantity', 'asc')
            ->limit(10);

        if ($branchId) {
            $q->where('i.branch_id', $branchId);
        }

        return $q->get()->map(fn ($r) => [
            'sku' => $r->sku,
            'product_name' => $r->product_name,
            'branch_name' => $r->branch_name,
            'quantity' => (int) $r->quantity,
            'min_order_qty' => (int) $r->min_order_qty,
        ])->all();
    }

    private function pendingStockRequests(?int $branchId): array
    {
        $q = DB::table('stock_requests as sr')
            ->join('branches as fb', 'fb.id', '=', 'sr.from_branch_id')
            ->join('branches as tb', 'tb.id', '=', 'sr.to_branch_id')
            ->where('sr.status', 'pending')
            ->select(
                'sr.id',
                'fb.name as from_branch',
                'tb.name as to_branch',
                'sr.created_at',
                DB::raw('(SELECT COUNT(*) FROM stock_request_items WHERE stock_request_id = sr.id) as item_count'),
            )
            ->orderByDesc('sr.created_at')
            ->limit(5);

        if ($branchId) {
            $q->where(function ($sub) use ($branchId) {
                $sub->where('sr.from_branch_id', $branchId)
                    ->orWhere('sr.to_branch_id', $branchId);
            });
        }

        return $q->get()->map(fn ($r) => [
            'id' => (int) $r->id,
            'from_branch' => $r->from_branch,
            'to_branch' => $r->to_branch,
            'item_count' => (int) $r->item_count,
            'created_at' => $r->created_at,
            'age_hours' => (int) round((time() - strtotime($r->created_at)) / 3600),
        ])->all();
    }
}
