<?php

namespace App\Services\V1\Faq\Support;

/**
 * Text normalization for the exact-match layer.
 *
 * Critical: this normalization is applied BOTH when seeding FAQs (to
 * precompute a normalized form of every question and alternative) AND
 * when a customer asks a question. If the two ever diverge, exact
 * matching silently breaks. Every change here requires re-running the
 * FAQ seeder.
 */
final class Normalizer
{
    /**
     * Common words that carry no matching signal. Deliberately small —
     * over-aggressive stopword removal hurts Hindi/Marathi worse than
     * English, since those languages have fewer words per sentence to
     * spare.
     */
    private const STOP_WORDS = [
        'the', 'is', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at',
        'to', 'for', 'of', 'with', 'by', 'my', 'me', 'you', 'your',
        'can', 'do', 'does', 'what', 'how', 'when', 'where', 'why',
        'i', 'am', 'are', 'was', 'were', 'be', 'been', 'have', 'has',
    ];

    /**
     * Produce the canonical form used for exact matching.
     *
     * - Lowercase
     * - Unicode-aware: preserves Devanagari, Marathi, and Roman letters
     * - Strips punctuation (keeps word boundaries)
     * - Collapses whitespace
     */
    public static function normalize(string $text): string
    {
        $text = mb_strtolower($text, 'UTF-8');

        // ★ Preserve letters AND combining marks.
        //   \p{L} = any letter (Devanagari base consonants, Roman letters)
        //   \p{M} = any combining mark (Devanagari matras like ि, ा, ी, ु, े, ो)
        //
        //   Without \p{M}, the matras — which are technically combining
        //   diacritical marks, not letters — get stripped. "डिलीवरी" becomes
        //   "ड ल वर " and no Devanagari query ever matches its FAQ.
        //
        //   \p{N} = any digit (kept).
        $text = preg_replace('/[^\p{L}\p{M}\p{N}\s]+/u', ' ', $text);

        $text = preg_replace('/\s+/u', ' ', $text);

        return trim($text);
    }

    /**
     * Tokenize into meaningful words. Used for keyword pre-filter and
     * for the keyword-match layer.
     *
     * @return string[]
     */
    public static function tokenize(string $text): array
    {
        $normalized = self::normalize($text);
        if ($normalized === '') {
            return [];
        }

        $words = explode(' ', $normalized);

        $filtered = array_filter($words, function ($w) {
            return mb_strlen($w, 'UTF-8') > 2
                && ! in_array($w, self::STOP_WORDS, true);
        });

        return array_values($filtered);
    }

    /**
     * Normalize for storage in faq_unmatched — same algorithm used for
     * exact matching, so "Where is my order?" and "where is my order??"
     * aggregate into one row.
     */
    public static function forAggregation(string $text): string
    {
        return self::normalize($text);
    }
}
