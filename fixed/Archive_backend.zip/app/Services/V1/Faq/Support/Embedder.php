<?php

namespace App\Services\V1\Faq\Support;

use App\Models\FaqItem;

/**
 * Centralizes two things:
 *   1. The model name constant (used by the matcher and the command).
 *   2. The "canonical text" for a FAQ — the string that gets embedded.
 *
 * The canonical text is: question + every alternative question, newline
 * joined. We deliberately do NOT include the answer — the answer is
 * what we want to *return*, not what we want to match against. Including
 * it dilutes the semantic signal.
 */
final class Embedder
{
    public const MODEL_NAME = 'intfloat/multilingual-e5-base';

    public static function buildEmbeddingText(FaqItem $faq): string
    {
        $parts = [$faq->question];

        foreach ($faq->alternative_questions ?? [] as $alt) {
            $alt = trim((string) $alt);
            if ($alt !== '') {
                $parts[] = $alt;
            }
        }

        // Deduplicate case-insensitively while preserving order.
        $seen = [];
        $unique = [];
        foreach ($parts as $p) {
            $key = mb_strtolower($p, 'UTF-8');
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = $p;
        }

        return implode("\n", $unique);
    }
}
