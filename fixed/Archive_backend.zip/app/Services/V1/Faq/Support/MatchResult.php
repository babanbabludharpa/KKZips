<?php

namespace App\Services\V1\Faq\Support;

use App\Models\FaqItem;

/**
 * Immutable result of a matcher run.
 *
 * The matcher never returns a bare FAQ — it always wraps the result so
 * callers can log "which layer won, at what confidence, using which
 * model." That diagnostic trail is what makes threshold tuning possible
 * after real usage data arrives.
 */
final class MatchResult
{
    public const LAYER_EXACT = 'exact';

    public const LAYER_KEYWORD = 'keyword';

    public const LAYER_SEMANTIC = 'semantic';

    public const LAYER_FALLBACK = 'fallback';

    public const CONFIDENCE_HIGH = 'high';

    public const CONFIDENCE_MEDIUM = 'medium';

    public const CONFIDENCE_LOW = 'low';

    /**
     * @param  FaqItem|null  $faq  The matched FAQ, or null for a miss.
     * @param  string  $layer  Which matcher layer produced this.
     * @param  float|null  $score  Similarity score (semantic layer only).
     * @param  string|null  $confidence  Bucketed confidence label.
     * @param  array  $suggestions  Top-N alternative FAQs (for low confidence).
     * @param  array  $metadata  Free-form diagnostics for logging.
     */
    public function __construct(
        public readonly ?FaqItem $faq,
        public readonly string $layer,
        public readonly ?float $score = null,
        public readonly ?string $confidence = null,
        public readonly array $suggestions = [],
        public readonly array $metadata = [],
    ) {}

    public function isMatched(): bool
    {
        return $this->faq !== null;
    }

    public function isMiss(): bool
    {
        return $this->faq === null;
    }

    /**
     * Did this result come in at high confidence (no hedging needed)?
     */
    public function isHighConfidence(): bool
    {
        return $this->confidence === self::CONFIDENCE_HIGH;
    }

    /**
     * Serialize for logging into support_messages.metadata.
     */
    public function toMetadata(): array
    {
        return array_merge([
            'layer' => $this->layer,
            'confidence' => $this->confidence,
            'score' => $this->score !== null ? round($this->score, 4) : null,
            'faq_id' => $this->faq?->id,
        ], $this->metadata);
    }

    public static function exact(FaqItem $faq, array $metadata = []): self
    {
        return new self(
            faq: $faq,
            layer: self::LAYER_EXACT,
            score: 1.0,
            confidence: self::CONFIDENCE_HIGH,
            metadata: $metadata,
        );
    }

    public static function semantic(FaqItem $faq, float $score, string $confidence, array $metadata = []): self
    {
        return new self(
            faq: $faq,
            layer: self::LAYER_SEMANTIC,
            score: $score,
            confidence: $confidence,
            metadata: $metadata,
        );
    }

    public static function miss(array $suggestions = [], array $metadata = []): self
    {
        return new self(
            faq: null,
            layer: self::LAYER_FALLBACK,
            score: null,
            confidence: self::CONFIDENCE_LOW,
            suggestions: $suggestions,
            metadata: $metadata,
        );
    }
}
