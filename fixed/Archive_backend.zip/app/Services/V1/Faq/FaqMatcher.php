<?php

namespace App\Services\V1\Faq;

use App\Models\FaqEmbedding;
use App\Models\FaqItem;
use App\Models\FaqUnmatched;
use App\Services\V1\Faq\Support\MatchResult;
use App\Services\V1\Faq\Support\Normalizer;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

class FaqMatcher
{
    private const THRESHOLD_HIGH = 0.88;
    private const THRESHOLD_MEDIUM = 0.80;
    private const THRESHOLD_LOW = 0.75;
    private const KEYWORD_CANDIDATE_LIMIT = 20;
    private const SUGGESTION_LIMIT = 3;
    private const EMBEDDING_MODEL = 'intfloat/multilingual-e5-base';

    public function __construct(
        protected EmbeddingClient $embedder,
    ) {}

    public function match(string $question, ?int $customerId = null): MatchResult
    {
        $trimmed = trim($question);

        if ($trimmed === '') {
            return MatchResult::miss();
        }

        $exact = $this->exactMatch($trimmed);
        if ($exact) {
            return MatchResult::exact($exact, ['matched_on' => 'exact']);
        }

        $candidates = $this->resolveCandidates($trimmed, $customerId);

        if ($candidates instanceof MatchResult) {
            return $candidates;
        }

        return $this->finalizeSemantic($trimmed, $candidates, $customerId);
    }

    private function finalizeSemantic(string $trimmed, Collection $candidates, ?int $customerId): MatchResult
    {
        $semantic = $this->semanticMatch($trimmed, $candidates);

        if ($semantic->isMatched()) {
            return $semantic;
        }

        $this->logUnmatched($trimmed, 'no_confident_semantic_match', $customerId);

        return MatchResult::miss(
            suggestions: $semantic->suggestions,
            metadata: ['candidate_count' => $candidates->count()],
        );
    }

    private function resolveCandidates(string $trimmed, ?int $customerId): Collection|MatchResult
    {
        $candidates = $this->keywordCandidates($trimmed);

        if (! $candidates->isEmpty()) {
            return $candidates;
        }

        return $this->resolveFallbackCandidates($trimmed, $customerId);
    }

    /**
     * Handles the "no keyword candidates" path: for non-Latin input, fall
     * back to the full active FAQ set; for Latin input, log and miss.
     */
    private function resolveFallbackCandidates(string $trimmed, ?int $customerId): Collection|MatchResult
    {
        $hasNonLatin = preg_match('/[^\p{Latin}\p{N}\s\p{P}]/u', $trimmed) === 1;

        if (! $hasNonLatin) {
            $this->logUnmatched($trimmed, 'no_keyword_candidates_latin', $customerId);

            return MatchResult::miss();
        }

        return $this->fetchAllActiveFaqsOrMiss($trimmed, $customerId);
    }

    private function fetchAllActiveFaqsOrMiss(string $trimmed, ?int $customerId): Collection|MatchResult
    {
        $candidates = FaqItem::query()
            ->active()
            ->limit(self::KEYWORD_CANDIDATE_LIMIT * 10)
            ->get();

        if (! $candidates->isEmpty()) {
            return $candidates;
        }

        $this->logUnmatched($trimmed, 'no_faqs_available', $customerId);

        return MatchResult::miss();
    }

    private function exactMatch(string $question): ?FaqItem
    {
        $normalized = Normalizer::normalize($question);

        $faqs = FaqItem::query()
            ->active()
            ->get(['id', 'question', 'answer', 'alternative_questions']);

        foreach ($faqs as $faq) {
            if (Normalizer::normalize($faq->question) === $normalized) {
                return $faq;
            }

            foreach ($faq->alternative_questions ?? [] as $alt) {
                if (Normalizer::normalize($alt) === $normalized) {
                    return $faq;
                }
            }
        }

        return null;
    }

    private function keywordCandidates(string $question): Collection
    {
        $tokens = Normalizer::tokenize($question);

        if (empty($tokens)) {
            return collect();
        }

        $faqs = FaqItem::query()->active()->get(['id', 'question', 'answer', 'keywords']);

        $scored = $faqs->map(function (FaqItem $faq) use ($tokens) {
            $keywords = array_map(
                fn ($k) => Normalizer::normalize((string) $k),
                $faq->keywords ?? []
            );

            $questionText = Normalizer::normalize($faq->question);

            $score = 0;
            foreach ($tokens as $token) {
                foreach ($keywords as $kw) {
                    if ($kw !== '' && str_contains($kw, $token)) {
                        $score += 3;
                        break;
                    }
                }
                if (str_contains($questionText, $token)) {
                    $score += 1;
                }
            }

            return ['faq' => $faq, 'score' => $score];
        });

        return $scored
            ->filter(fn ($row) => $row['score'] > 0)
            ->sortByDesc('score')
            ->take(self::KEYWORD_CANDIDATE_LIMIT)
            ->pluck('faq')
            ->values();
    }

    private function semanticMatch(string $question, Collection $candidates): MatchResult
    {
        $queryVector = $this->embedder->embedOneQuery($question);

        if ($queryVector === null) {
            Log::info('FaqMatcher: semantic layer skipped — embedder unavailable');

            return MatchResult::miss();
        }

        $scored = $this->scoreEmbeddings($queryVector, $candidates);

        if ($scored === null) {
            return MatchResult::miss();
        }

        return $this->buildSemanticResult($scored, $candidates);
    }

    private function buildSemanticResult(Collection $scored, Collection $candidates): MatchResult
    {
        $best = $scored->first();
        $confidence = $this->bucketConfidence($best['score']);

        if ($confidence === null) {
            return MatchResult::miss(
                suggestions: $this->buildSuggestions($scored, $candidates)
            );
        }

        return $this->matchOrMiss($candidates, $best, $confidence);
    }

    private function matchOrMiss(Collection $candidates, array $best, string $confidence): MatchResult
    {
        $faq = $candidates->firstWhere('id', $best['faq_id']);

        if (! $faq) {
            return MatchResult::miss();
        }

        return MatchResult::semantic($faq, $best['score'], $confidence, [
            'candidate_count' => $candidates->count(),
            'embedding_model' => self::EMBEDDING_MODEL,
        ]);
    }

    private function scoreEmbeddings(array $queryVector, Collection $candidates): ?Collection
    {
        $embeddings = FaqEmbedding::query()
            ->whereIn('faq_item_id', $candidates->pluck('id')->all())
            ->where('model_name', self::EMBEDDING_MODEL)
            ->get(['faq_item_id', 'vector']);

        if ($embeddings->isEmpty()) {
            return null;
        }

        return $embeddings->map(function (FaqEmbedding $emb) use ($queryVector) {
            return [
                'faq_id' => $emb->faq_item_id,
                'score' => FaqEmbedding::cosine($queryVector, $emb->vector),
            ];
        })->sortByDesc('score')->values();
    }

    private function buildSuggestions(Collection $scored, Collection $candidates): array
    {
        return $scored->take(self::SUGGESTION_LIMIT)
            ->map(function ($row) use ($candidates) {
                $item = $candidates->firstWhere('id', $row['faq_id']);

                return $item ? [
                    'id' => $item->id,
                    'question' => $item->question,
                    'score' => round($row['score'], 4),
                ] : null;
            })
            ->filter()
            ->values()
            ->all();
    }

    private function bucketConfidence(float $score): ?string
    {
        if ($score >= self::THRESHOLD_HIGH) {
            return MatchResult::CONFIDENCE_HIGH;
        }
        if ($score >= self::THRESHOLD_MEDIUM) {
            return MatchResult::CONFIDENCE_MEDIUM;
        }
        if ($score >= self::THRESHOLD_LOW) {
            return MatchResult::CONFIDENCE_LOW;
        }

        return null;
    }

    private function logUnmatched(string $question, string $reason, ?int $customerId = null): void
    {
        $normalized = Normalizer::forAggregation($question);
        if ($normalized === '') {
            return;
        }

        $existing = FaqUnmatched::query()
            ->pending()
            ->where('question', $normalized)
            ->first();

        if ($existing) {
            $this->incrementExistingUnmatched($existing, $customerId);

            return;
        }

        $this->createNewUnmatched($question, $normalized, $reason, $customerId);
    }

    private function incrementExistingUnmatched(FaqUnmatched $existing, ?int $customerId): void
    {
        $existing->increment('hit_count');
        $existing->update([
            'last_asked_at' => now(),
            'customer_id' => $existing->customer_id ?? $customerId,
        ]);
    }

    private function createNewUnmatched(string $question, string $normalized, string $reason, ?int $customerId): void
    {
        FaqUnmatched::create([
            'question' => $normalized,
            'language_guess' => $this->guessLanguage($question),
            'customer_id' => $customerId,
            'hit_count' => 1,
            'last_asked_at' => now(),
        ]);

        Log::info('FaqMatcher: unmatched question logged', [
            'question' => $question,
            'reason' => $reason,
            'customer_id' => $customerId,
        ]);
    }

    private function guessLanguage(string $text): string
    {
        if (preg_match('/[\p{Devanagari}]/u', $text)) {
            return 'dev';
        }
        if (preg_match('/[\p{Latin}]/u', $text)) {
            return 'latn';
        }

        return 'und';
    }
}
