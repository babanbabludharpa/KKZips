<?php

namespace App\Services\V1\Faq;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * HTTP client for the Python embedding microservice.
 *
 * The service runs at 127.0.0.1:8001 by default (configurable via
 * config('services.embedder.url')). It exposes:
 *   - GET  /health           → service status
 *   - POST /embed/passages   → embed stored FAQ texts (with "passage: " prefix)
 *   - POST /embed/queries    → embed user questions (with "query: " prefix)
 *
 * The prefix distinction is enforced by the Python service, not here.
 * This class never sees the prefixes — it just sends raw text.
 *
 * Every method is defensive: if the service is down or returns an error,
 * we return null rather than throwing. The matcher degrades gracefully —
 * it falls back to keyword matching instead of failing the whole request.
 */
class EmbeddingClient
{
    private function baseUrl(): string
    {
        return rtrim(config('services.embedder.url', 'http://127.0.0.1:8001'), '/');
    }

    private function timeout(): int
    {
        return (int) config('services.embedder.timeout', 30);
    }

    public function isHealthy(): bool
    {
        try {
            $response = Http::timeout(3)->get($this->baseUrl().'/health');

            return $response->ok()
                && $response->json('status') === 'ok'
                && $response->json('loaded') === true;
        } catch (\Throwable $e) {
            Log::warning('Embedder health check failed', ['error' => $e->getMessage()]);

            return false;
        }
    }

    /**
     * @param  string[]  $texts
     * @return array<int, array<int, float>>|null
     */
    public function embedPassages(array $texts): ?array
    {
        return $this->embed($texts, 'passages');
    }

    /**
     * @param  string[]  $texts
     * @return array<int, array<int, float>>|null
     */
    public function embedQueries(array $texts): ?array
    {
        return $this->embed($texts, 'queries');
    }

    /**
     * @return array<int, float>|null
     */
    public function embedOneQuery(string $text): ?array
    {
        $result = $this->embedQueries([$text]);

        return $result[0] ?? null;
    }

    public function embedOnePassage(string $text): ?array
    {
        $result = $this->embedPassages([$text]);

        return $result[0] ?? null;
    }

    /**
     * Shared embed call. Handles the HTTP round-trip, response
     * validation, and error logging.
     *
     * @param  string[]  $texts
     * @return array<int, array<int, float>>|null
     */
    private function embed(array $texts, string $kind): ?array
    {
        if (empty($texts)) {
            return [];
        }

        try {
            $response = Http::timeout($this->timeout())
                ->post("{$this->baseUrl()}/embed/{$kind}", [
                    'texts' => array_values($texts),
                ]);

            return $this->parseEmbedResponse($response, $texts, $kind);
        } catch (\Throwable $e) {
            Log::warning("Embedder /embed/{$kind} call failed", [
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Validates the embedder response and returns the vectors, or null
     * if the response was malformed or reported an error.
     *
     * @param  string[]  $texts
     * @return array<int, array<int, float>>|null
     */
    private function parseEmbedResponse($response, array $texts, string $kind): ?array
    {
        if (! $response->ok()) {
            Log::warning("Embedder /embed/{$kind} returned non-OK", [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);

            return null;
        }

        $vectors = $response->json('vectors');

        if (! is_array($vectors) || count($vectors) !== count($texts)) {
            Log::warning("Embedder /embed/{$kind} returned mismatched vector count", [
                'expected' => count($texts),
                'got' => is_array($vectors) ? count($vectors) : null,
            ]);

            return null;
        }

        return $vectors;
    }
}
