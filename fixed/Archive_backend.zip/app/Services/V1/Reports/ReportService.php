<?php

namespace App\Services\V1\Reports;

use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportService
{
    private const COL_PRODUCT_NAME = 'products.name as product_name';

    private const COL_BRANCH_NAME = 'branches.name as branch_name';

    private const COL_CUSTOMER_NAME = 'customers.name as customer_name';

    private const COL_ORDER_ID = 'orders.id as order_id';

    private const COL_DELIVERY_BOY_NAME = 'delivery_boys.name as delivery_boy_name';

    private const DATE_FROM_SUFFIX = ' 00:00:00';

    private const DATE_TO_SUFFIX = ' 23:59:59';

    private const CSV_HEADER_ORDER_NUMBER = 'Order #';

    private const CSV_HEADER_DELIVERED_ON = 'Delivered On';

    private const CSV_HEADER_BRANCH = 'Branch';

    private const CSV_HEADER_CUSTOMER = 'Customer';

    private const CSV_HEADER_DELIVERY_BOY = 'Delivery Boy';

    // ── Stock Levels ──────────────────────────────────────────────

    public function stockLevels(array $filters): array
    {
        $query = $this->stockLevelsQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function stockLevelsCsv(array $filters): StreamedResponse
    {
        $rows = $this->stockLevelsQuery($filters)->get();

        return $this->streamCsv('stock_levels', [
            'SKU', 'Product', 'Variant Attributes', self::CSV_HEADER_BRANCH, 'Quantity', 'Low Stock',
        ], $rows->map(fn ($r) => [
            $r->sku,
            $r->product_name,
            $r->variant_attributes ?? '—',
            $r->branch_name ?? '—',
            $r->quantity,
            $r->quantity <= ($r->min_order_qty ?? 0) ? 'Yes' : 'No',
        ])->toArray());
    }

    private const STOCK_LEVELS_SORTABLE = [
        'sku' => 'product_variants.sku',
        'product_name' => 'products.name',
        'branch_name' => 'branches.name',
        'quantity' => 'quantity',
        'min_order_qty' => 'product_variants.min_order_qty',
    ];

    private function stockLevelsQuery(array $filters)
    {
        $branchId = $filters['branch_id'] ?? null;

        $query = DB::table('product_variants')
            ->leftJoin('inventory', function ($join) use ($branchId) {
                $join->on('inventory.product_variant_id', '=', 'product_variants.id');
                if ($branchId) {
                    $join->where('inventory.branch_id', '=', $branchId);
                }
            })
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->leftJoin('branches', 'inventory.branch_id', '=', 'branches.id')
            ->leftJoin(
                DB::raw('(
                    SELECT
                        vav.variant_id,
                        GROUP_CONCAT(
                            CONCAT(a.name, \': \', av.value)
                            ORDER BY a.name
                            SEPARATOR \', \'
                        ) as attributes
                    FROM variant_attribute_values vav
                    JOIN attribute_values av ON vav.attribute_value_id = av.id
                    JOIN attributes a ON av.attribute_id = a.id
                    GROUP BY vav.variant_id
                ) as va'),
                'va.variant_id',
                '=',
                'product_variants.id'
            )
            ->select(
                'product_variants.id as variant_id',
                'product_variants.sku',
                self::COL_PRODUCT_NAME,
                'va.attributes as variant_attributes',
                self::COL_BRANCH_NAME,
                'inventory.branch_id',
                DB::raw('COALESCE(inventory.quantity, 0) as quantity'),
                'product_variants.min_order_qty',
            )
            ->when(! empty($filters['search']), function ($q) use ($filters) {
                $term = '%'.$filters['search'].'%';
                $q->where(function ($w) use ($term) {
                    $w->where('products.name', 'like', $term)
                        ->orWhere('product_variants.sku', 'like', $term);
                });
            })
            ->when(isset($filters['low_stock']) && $filters['low_stock'], fn ($q) => $q->whereRaw('COALESCE(inventory.quantity, 0) <= product_variants.min_order_qty')
            )
            ->whereNull('product_variants.deleted_at')
            ->where('product_variants.is_active', true);

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';
        $column = self::STOCK_LEVELS_SORTABLE[$sortKey] ?? null;

        if ($column) {
            if ($column === 'quantity') {
                $query->orderByRaw("COALESCE(inventory.quantity, 0) {$sortDir}");
            } else {
                $query->orderBy($column, $sortDir);
            }
            $query->orderBy('products.name', 'asc')
                ->orderBy('product_variants.sku', 'asc');
        } else {
            $query->orderBy('products.name')
                ->orderBy('product_variants.sku');
        }

        return $query;
    }

    // ── Stock Movements ───────────────────────────────────────────

    public function stockMovements(array $filters): array
    {
        $query = $this->stockMovementsQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function stockMovementsCsv(array $filters): StreamedResponse
    {
        $rows = $this->stockMovementsQuery($filters)->get();

        return $this->streamCsv('stock_movements', [
            'Date', 'SKU', 'Product', 'Type', 'In', 'Out', 'Opening Stock', 'Closing Stock', self::CSV_HEADER_BRANCH, 'Reference',
        ], $rows->map(fn ($r) => [
            $r->transaction_date,
            $r->sku,
            $r->product_name,
            $r->type,
            $r->in,
            $r->out,
            $r->opening_stock,
            $r->closing_stock,
            $r->branch_name,
            $r->reference_id,
        ])->toArray());
    }

    private const STOCK_MOVEMENTS_SORTABLE = [
        'transaction_date' => 'stock_movements.transaction_date',
        'sku' => 'product_variants.sku',
        'product_name' => 'products.name',
        'type' => 'stock_movements.type',
        'in' => 'stock_movements.in',
        'out' => 'stock_movements.out',
        'opening_stock' => 'stock_movements.opening_stock',
        'closing_stock' => 'stock_movements.closing_stock',
        'branch_name' => 'branches.name',
    ];

    private function stockMovementsQuery(array $filters)
    {
        $query = DB::table('stock_movements')
            ->join('product_variants', 'stock_movements.product_variant_id', '=', 'product_variants.id')
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->join('branches', 'stock_movements.branch_id', '=', 'branches.id')
            ->select(
                'stock_movements.transaction_date',
                'product_variants.sku',
                self::COL_PRODUCT_NAME,
                'stock_movements.type',
                'stock_movements.in',
                'stock_movements.out',
                'stock_movements.opening_stock',
                'stock_movements.closing_stock',
                self::COL_BRANCH_NAME,
                'stock_movements.reference_id',
            )
            ->whereBetween('stock_movements.transaction_date', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['branch_id']), fn ($q) => $q->where('stock_movements.branch_id', $filters['branch_id'])
            )
            ->when(isset($filters['variant_id']), fn ($q) => $q->where('stock_movements.product_variant_id', $filters['variant_id'])
            )
            ->when(isset($filters['type']), fn ($q) => $q->where('stock_movements.type', $filters['type'])
            )
            ->whereNull('product_variants.deleted_at');

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::STOCK_MOVEMENTS_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'stock_movements.transaction_date') {
                $query->orderByDesc('stock_movements.transaction_date');
            }
            $query->orderByDesc('stock_movements.id');
        } else {
            $query->orderByDesc('stock_movements.transaction_date')
                ->orderByDesc('stock_movements.id');
        }

        return $query;
    }

    // ── Stock Requests ────────────────────────────────────────────

    public function stockRequests(array $filters): array
    {
        $query = $this->stockRequestsQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function stockRequestsCsv(array $filters): StreamedResponse
    {
        $rows = $this->stockRequestsQuery($filters)->get();

        return $this->streamCsv('stock_requests', [
            'Date', 'From Branch', 'To Branch', 'Status', 'Items', 'Qty Requested', 'Qty Approved', 'Qty Fulfilled',
        ], $rows->map(fn ($r) => [
            $r->created_at,
            $r->from_branch,
            $r->to_branch,
            $r->status,
            $r->item_count,
            $r->total_requested,
            $r->total_approved,
            $r->total_fulfilled,
        ])->toArray());
    }

    private const STOCK_REQUESTS_SORTABLE = [
        'created_at' => 'stock_requests.created_at',
        'from_branch' => 'fb.name',
        'to_branch' => 'tb.name',
        'status' => 'stock_requests.status',
        'item_count' => 'item_count',
        'total_requested' => 'total_requested',
        'total_approved' => 'total_approved',
        'total_fulfilled' => 'total_fulfilled',
    ];

    private function stockRequestsQuery(array $filters)
    {
        $query = DB::table('stock_requests')
            ->join('branches as fb', 'stock_requests.from_branch_id', '=', 'fb.id')
            ->join('branches as tb', 'stock_requests.to_branch_id', '=', 'tb.id')
            ->leftJoin('stock_request_items', 'stock_requests.id', '=', 'stock_request_items.stock_request_id')
            ->select(
                'stock_requests.id',
                'stock_requests.created_at',
                'fb.name as from_branch',
                'tb.name as to_branch',
                'stock_requests.status',
                'stock_requests.notes',
                DB::raw('COUNT(stock_request_items.id) as item_count'),
                DB::raw('SUM(stock_request_items.quantity_requested) as total_requested'),
                DB::raw('SUM(stock_request_items.quantity_approved) as total_approved'),
                DB::raw('SUM(stock_request_items.quantity_fulfilled) as total_fulfilled'),
            )
            ->whereBetween('stock_requests.created_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['from_branch_id']), fn ($q) => $q->where('stock_requests.from_branch_id', $filters['from_branch_id'])
            )
            ->when(isset($filters['to_branch_id']), fn ($q) => $q->where('stock_requests.to_branch_id', $filters['to_branch_id'])
            )
            ->when(isset($filters['status']), fn ($q) => $q->where('stock_requests.status', $filters['status'])
            )
            ->groupBy(
                'stock_requests.id',
                'stock_requests.created_at',
                'fb.name',
                'tb.name',
                'stock_requests.status',
                'stock_requests.notes',
            );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::STOCK_REQUESTS_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $isAlias = in_array($column, [
                'item_count', 'total_requested', 'total_approved', 'total_fulfilled',
            ], true);

            if ($isAlias) {
                $query->orderByRaw("{$column} {$sortDir}");
            } else {
                $query->orderBy($column, $sortDir);
            }

            if ($column !== 'stock_requests.created_at') {
                $query->orderByDesc('stock_requests.created_at');
            }
        } else {
            $query->orderByDesc('stock_requests.created_at');
        }

        return $query;
    }

    // ── Stock Request Detail ──────────────────────────────────────

    public function stockRequestDetail(array $filters): array
    {
        $query = $this->stockRequestDetailQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function stockRequestDetailCsv(array $filters): StreamedResponse
    {
        $rows = $this->stockRequestDetailQuery($filters)->get();

        return $this->streamCsv('stock_request_detail', [
            'Date', 'From Branch', 'To Branch', 'Status',
            'Product', 'SKU', 'Variant',
            'Qty Requested', 'Qty Approved', 'Qty Fulfilled',
            'MRP', 'Selling Price', 'Purchase Price',
        ], $rows->map(fn ($r) => [
            $r->created_at ? substr($r->created_at, 0, 10) : '',
            $r->from_branch,
            $r->to_branch,
            $r->status,
            $r->product_name,
            $r->sku,
            $r->variant_attributes ?? '—',
            $r->quantity_requested,
            $r->quantity_approved ?? '—',
            $r->quantity_fulfilled ?? '—',
            $r->mrp ? '₹'.$r->mrp : '—',
            $r->selling_price ? '₹'.$r->selling_price : '—',
            $r->purchase_price ? '₹'.$r->purchase_price : '—',
        ])->toArray());
    }

    private const STOCK_REQUEST_DETAIL_SORTABLE = [
        'created_at' => 'stock_requests.created_at',
        'from_branch' => 'fb.name',
        'to_branch' => 'tb.name',
        'status' => 'stock_requests.status',
        'product_name' => 'products.name',
        'sku' => 'product_variants.sku',
        'quantity_requested' => 'stock_request_items.quantity_requested',
        'quantity_approved' => 'stock_request_items.quantity_approved',
        'quantity_fulfilled' => 'stock_request_items.quantity_fulfilled',
        'mrp' => 'product_variants.mrp',
        'selling_price' => 'product_variants.selling_price',
        'purchase_price' => 'product_variants.purchase_price',
    ];

    private function stockRequestDetailQuery(array $filters)
    {
        $query = DB::table('stock_request_items')
            ->join('stock_requests', 'stock_request_items.stock_request_id', '=', 'stock_requests.id')
            ->join('branches as fb', 'stock_requests.from_branch_id', '=', 'fb.id')
            ->join('branches as tb', 'stock_requests.to_branch_id', '=', 'tb.id')
            ->join('product_variants', 'stock_request_items.product_variant_id', '=', 'product_variants.id')
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->leftJoin(
                DB::raw('(
                    SELECT
                        vav.variant_id,
                        GROUP_CONCAT(
                            CONCAT(a.name, \': \', av.value)
                            ORDER BY a.name
                            SEPARATOR \', \'
                        ) as attributes
                    FROM variant_attribute_values vav
                    JOIN attribute_values av ON vav.attribute_value_id = av.id
                    JOIN attributes a ON av.attribute_id = a.id
                    GROUP BY vav.variant_id
                ) as va'),
                'va.variant_id', '=', 'product_variants.id'
            )
            ->select(
                'stock_requests.created_at',
                'fb.name as from_branch',
                'tb.name as to_branch',
                'stock_requests.status',
                self::COL_PRODUCT_NAME,
                'product_variants.sku',
                'va.attributes as variant_attributes',
                'stock_request_items.quantity_requested',
                'stock_request_items.quantity_approved',
                'stock_request_items.quantity_fulfilled',
                'product_variants.mrp',
                'product_variants.selling_price',
                'product_variants.purchase_price',
            )
            ->whereBetween('stock_requests.created_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['from_branch_id']), fn ($q) => $q->where('stock_requests.from_branch_id', $filters['from_branch_id'])
            )
            ->when(isset($filters['to_branch_id']), fn ($q) => $q->where('stock_requests.to_branch_id', $filters['to_branch_id'])
            )
            ->when(isset($filters['status']), fn ($q) => $q->where('stock_requests.status', $filters['status'])
            )
            ->when(isset($filters['product_id']), fn ($q) => $q->where('product_variants.product_id', $filters['product_id'])
            )
            ->when(isset($filters['variant_id']), fn ($q) => $q->where('stock_request_items.product_variant_id', $filters['variant_id'])
            )
            ->whereNull('product_variants.deleted_at');

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::STOCK_REQUEST_DETAIL_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'stock_requests.created_at') {
                $query->orderByDesc('stock_requests.created_at');
            }
            $query->orderBy('product_variants.sku', 'asc');
        } else {
            $query->orderByDesc('stock_requests.created_at');
        }

        return $query;
    }

    // ── Price History ─────────────────────────────────────────────

    public function priceHistory(array $filters): array
    {
        $query = $this->priceHistoryQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function priceHistoryCsv(array $filters): StreamedResponse
    {
        $rows = $this->priceHistoryQuery($filters)->get();

        return $this->streamCsv('price_history', [
            'Date', 'SKU', 'Product', 'Source',
            'Prev MRP', 'New MRP',
            'Prev Selling', 'New Selling',
            'Prev Purchase', 'New Purchase',
            'Changed By',
        ], $rows->map(fn ($r) => [
            $r->changed_at,
            $r->sku,
            $r->product_name,
            $r->source,
            $r->prev_mrp,
            $r->new_mrp,
            $r->prev_selling_price,
            $r->new_selling_price,
            $r->prev_purchase_price,
            $r->new_purchase_price,
            $r->changed_by_name ?? 'System',
        ])->toArray());
    }

    private const PRICE_HISTORY_SORTABLE = [
        'changed_at' => 'variant_price_history.changed_at',
        'sku' => 'product_variants.sku',
        'product_name' => 'products.name',
        'source' => 'variant_price_history.source',
        'prev_mrp' => 'variant_price_history.prev_mrp',
        'new_mrp' => 'variant_price_history.new_mrp',
        'prev_selling_price' => 'variant_price_history.prev_selling_price',
        'new_selling_price' => 'variant_price_history.new_selling_price',
        'prev_purchase_price' => 'variant_price_history.prev_purchase_price',
        'new_purchase_price' => 'variant_price_history.new_purchase_price',
        'changed_by_name' => 'users.name',
    ];

    private function priceHistoryQuery(array $filters)
    {
        $query = DB::table('variant_price_history')
            ->join('product_variants', 'variant_price_history.product_variant_id', '=', 'product_variants.id')
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->leftJoin('users', 'variant_price_history.changed_by', '=', 'users.id')
            ->select(
                'variant_price_history.changed_at',
                'product_variants.sku',
                self::COL_PRODUCT_NAME,
                'variant_price_history.source',
                'variant_price_history.prev_mrp',
                'variant_price_history.new_mrp',
                'variant_price_history.prev_selling_price',
                'variant_price_history.new_selling_price',
                'variant_price_history.prev_purchase_price',
                'variant_price_history.new_purchase_price',
                'users.name as changed_by_name',
            )
            ->whereBetween('variant_price_history.changed_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['variant_id']), fn ($q) => $q->where('variant_price_history.product_variant_id', $filters['variant_id'])
            )
            ->when(isset($filters['source']), fn ($q) => $q->where('variant_price_history.source', $filters['source'])
            )
            ->when(isset($filters['product_id']), fn ($q) => $q->where('product_variants.product_id', $filters['product_id'])
            )
            ->whereNull('product_variants.deleted_at');

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::PRICE_HISTORY_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'variant_price_history.changed_at') {
                $query->orderByDesc('variant_price_history.changed_at');
            }
            $query->orderBy('product_variants.sku', 'asc');
        } else {
            $query->orderByDesc('variant_price_history.changed_at');
        }

        return $query;
    }

    // ── Discount History ──────────────────────────────────────────

    public function discountHistory(array $filters): array
    {
        $query = $this->discountHistoryQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function discountHistoryCsv(array $filters): StreamedResponse
    {
        $rows = $this->discountHistoryQuery($filters)->get();

        return $this->streamCsv('discount_history', [
            'SKU', 'Product', 'Discount %',
            'Starts On', 'Ends On', 'Status', 'Created By',
        ], $rows->map(fn ($r) => [
            $r->sku,
            $r->product_name,
            $r->discount_percent,
            $r->starts_on,
            $r->ends_on ?? 'Open-ended',
            $r->status,
            $r->created_by_name ?? 'System',
        ])->toArray());
    }

    private const DISCOUNT_HISTORY_SORTABLE = [
        'sku' => 'product_variants.sku',
        'product_name' => 'products.name',
        'discount_percent' => 'discount_schedules.discount_percent',
        'starts_on' => 'discount_schedules.starts_on',
        'ends_on' => 'discount_schedules.ends_on',
        'status' => 'discount_schedules.status',
        'created_by_name' => 'users.name',
        'created_at' => 'discount_schedules.created_at',
    ];

    private function discountHistoryQuery(array $filters)
    {
        $query = DB::table('discount_schedules')
            ->join('product_variants', 'discount_schedules.product_variant_id', '=', 'product_variants.id')
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->leftJoin('users', 'discount_schedules.created_by', '=', 'users.id')
            ->select(
                'product_variants.sku',
                self::COL_PRODUCT_NAME,
                'discount_schedules.discount_percent',
                'discount_schedules.starts_on',
                'discount_schedules.ends_on',
                'discount_schedules.status',
                'users.name as created_by_name',
                'discount_schedules.created_at',
            )
            ->whereBetween('discount_schedules.created_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['variant_id']), fn ($q) => $q->where('discount_schedules.product_variant_id', $filters['variant_id'])
            )
            ->when(isset($filters['status']), fn ($q) => $q->where('discount_schedules.status', $filters['status'])
            )
            ->when(isset($filters['product_id']), fn ($q) => $q->where('product_variants.product_id', $filters['product_id'])
            )
            ->whereNull('product_variants.deleted_at');

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::DISCOUNT_HISTORY_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'discount_schedules.created_at') {
                $query->orderByDesc('discount_schedules.created_at');
            }
            $query->orderBy('product_variants.sku', 'asc');
        } else {
            $query->orderByDesc('discount_schedules.created_at');
        }

        return $query;
    }

    // ── Delivered Orders ────────────────────────────────────────────

    public function deliveredOrders(array $filters): array
    {
        $query = $this->deliveredOrdersQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        $items = collect($result->items())->map(function ($r) {
            $r->delivery_photo_url = $r->delivery_photo_path
                ? url('storage/'.$r->delivery_photo_path)
                : null;

            return $r;
        })->all();

        return [
            'data' => $items,
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function deliveredOrdersCsv(array $filters): StreamedResponse
    {
        $rows = $this->deliveredOrdersQuery($filters)->get();

        return $this->streamCsv('delivered_orders', [
            self::CSV_HEADER_ORDER_NUMBER, self::CSV_HEADER_DELIVERED_ON, 'Placed On', self::CSV_HEADER_CUSTOMER, self::CSV_HEADER_BRANCH,
            self::CSV_HEADER_DELIVERY_BOY, 'Payment Mode', 'Items', 'Total',
        ], $rows->map(fn ($r) => [
            $r->order_number,
            $r->delivered_at,
            $r->placed_at,
            $r->customer_name ?? '—',
            $r->branch_name,
            $r->delivery_boy_name ?? '—',
            $r->payment_mode === 'cod' ? 'COD' : 'Online',
            $r->item_count,
            $r->total,
        ])->toArray());
    }

    private const DELIVERED_ORDERS_SORTABLE = [
        'order_number' => 'orders.order_number',
        'delivered_at' => 'orders.delivered_at',
        'placed_at' => 'orders.created_at',
        'customer_name' => 'customers.name',
        'branch_name' => 'branches.name',
        'delivery_boy_name' => 'delivery_boys.name',
        'payment_mode' => 'orders.payment_mode',
        'item_count' => 'item_count',
        'total' => 'orders.total',
    ];

    private function deliveredOrdersQuery(array $filters)
    {
        $query = DB::table('orders')
            ->join('branches', 'orders.branch_id', '=', 'branches.id')
            ->leftJoin('users as delivery_boys', 'orders.delivery_boy_id', '=', 'delivery_boys.id')
            ->leftJoin('customers', 'orders.customer_id', '=', 'customers.id')
            ->leftJoin(
                DB::raw('(SELECT order_id, COUNT(*) as item_count FROM order_items GROUP BY order_id) as oi'),
                'oi.order_id',
                '=',
                'orders.id'
            )
            ->select(
                self::COL_ORDER_ID,
                'orders.order_number',
                'orders.delivered_at',
                'orders.created_at as placed_at',
                self::COL_CUSTOMER_NAME,
                self::COL_BRANCH_NAME,
                self::COL_DELIVERY_BOY_NAME,
                'orders.payment_mode',
                'orders.total',
                'orders.delivery_photo_path',
                DB::raw('COALESCE(oi.item_count, 0) as item_count'),
            )
            ->where('orders.status', 'delivered')
            ->whereBetween('orders.delivered_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['branch_id']), fn ($q) => $q->where('orders.branch_id', $filters['branch_id'])
            )
            ->when(isset($filters['delivery_boy_id']), fn ($q) => $q->where('orders.delivery_boy_id', $filters['delivery_boy_id'])
            );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::DELIVERED_ORDERS_SORTABLE[$sortKey] ?? null;

        if ($column) {
            if ($column === 'item_count') {
                $query->orderByRaw("COALESCE(oi.item_count, 0) {$sortDir}");
            } else {
                $query->orderBy($column, $sortDir);
            }
            if ($column !== 'orders.delivered_at') {
                $query->orderByDesc('orders.delivered_at');
            }
            $query->orderByDesc('orders.id');
        } else {
            $query->orderByDesc('orders.delivered_at');
        }

        return $query;
    }

    // ── Delivered Orders — Product Wise ─────────────────────────────

    public function deliveredOrderItems(array $filters): array
    {
        $query = $this->deliveredOrderItemsQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function deliveredOrderItemsCsv(array $filters): StreamedResponse
    {
        $rows = $this->deliveredOrderItemsQuery($filters)->get();

        return $this->streamCsv('delivered_orders_product_wise', [
            self::CSV_HEADER_ORDER_NUMBER, self::CSV_HEADER_DELIVERED_ON, self::CSV_HEADER_CUSTOMER, self::CSV_HEADER_BRANCH, self::CSV_HEADER_DELIVERY_BOY,
            'SKU', 'Product', 'Qty', 'MRP', 'Unit Price', 'Discount %',
            'Final Price', 'Tax Rate %', 'Tax Amount', 'CGST', 'SGST', 'IGST',
            'Line Total', 'Coupon Code', 'Coupon Discount (Order)',
        ], $rows->map(fn ($r) => [
            $r->order_number,
            $r->delivered_at,
            $r->customer_name,
            $r->branch_name,
            $r->delivery_boy_name ?? '—',
            $r->sku,
            $r->product_name,
            $r->quantity,
            $r->mrp,
            $r->unit_price,
            $r->discount_percent,
            $r->final_price,
            $r->tax_rate_percent,
            $r->tax_amount,
            $r->cgst_amount,
            $r->sgst_amount,
            $r->igst_amount,
            $r->line_total,
            $r->coupon_code ?? '—',
            $r->coupon_discount,
        ])->toArray());
    }

    private const DELIVERED_ORDER_ITEMS_SORTABLE = [
        'order_number' => 'orders.order_number',
        'delivered_at' => 'orders.delivered_at',
        'customer_name' => 'customers.name',
        'branch_name' => 'branches.name',
        'delivery_boy_name' => 'delivery_boys.name',
        'sku' => 'product_variants.sku',
        'product_name' => 'products.name',
        'quantity' => 'order_items.quantity',
        'mrp' => 'order_items.mrp',
        'unit_price' => 'order_items.unit_price',
        'discount_percent' => 'order_items.discount_percent',
        'final_price' => 'order_items.final_price',
        'tax_rate_percent' => 'order_items.tax_rate_percent',
        'tax_amount' => 'order_items.tax_amount',
        'cgst_amount' => 'order_items.cgst_amount',
        'sgst_amount' => 'order_items.sgst_amount',
        'igst_amount' => 'order_items.igst_amount',
        'line_total' => 'order_items.line_total',
        'coupon_discount' => 'orders.coupon_discount',
    ];

    private function deliveredOrderItemsQuery(array $filters)
    {
        $query = DB::table('order_items')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('product_variants', 'order_items.product_variant_id', '=', 'product_variants.id')
            ->join('products', 'product_variants.product_id', '=', 'products.id')
            ->join('branches', 'orders.branch_id', '=', 'branches.id')
            ->join('customers', 'orders.customer_id', '=', 'customers.id')
            ->leftJoin('users as delivery_boys', 'orders.delivery_boy_id', '=', 'delivery_boys.id')
            ->select(
                self::COL_ORDER_ID,
                'orders.order_number',
                'orders.delivered_at',
                self::COL_CUSTOMER_NAME,
                self::COL_BRANCH_NAME,
                self::COL_DELIVERY_BOY_NAME,
                'product_variants.sku',
                self::COL_PRODUCT_NAME,
                'order_items.quantity',
                'order_items.mrp',
                'order_items.unit_price',
                'order_items.discount_percent',
                'order_items.final_price',
                'order_items.tax_rate_percent',
                'order_items.tax_amount',
                'order_items.cgst_amount',
                'order_items.sgst_amount',
                'order_items.igst_amount',
                'order_items.line_total',
                'orders.coupon_code',
                'orders.coupon_discount',
            )
            ->where('orders.status', 'delivered')
            ->whereBetween('orders.delivered_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(isset($filters['branch_id']), fn ($q) => $q->where('orders.branch_id', $filters['branch_id'])
            )
            ->when(isset($filters['delivery_boy_id']), fn ($q) => $q->where('orders.delivery_boy_id', $filters['delivery_boy_id'])
            )
            ->when(isset($filters['product_id']), fn ($q) => $q->where('product_variants.product_id', $filters['product_id'])
            )
            ->when(isset($filters['variant_id']), fn ($q) => $q->where('order_items.product_variant_id', $filters['variant_id'])
            )
            ->whereNull('product_variants.deleted_at');

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::DELIVERED_ORDER_ITEMS_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'orders.delivered_at') {
                $query->orderByDesc('orders.delivered_at');
            }
            $query->orderBy('order_items.id', 'asc');
        } else {
            $query->orderByDesc('orders.delivered_at');
        }

        return $query;
    }

    // ── Customer Addresses ───────────────────────────────────────

    public function customerAddresses(array $filters): array
    {
        $query = $this->customerAddressesQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function customerAddressesCsv(array $filters): StreamedResponse
    {
        $rows = $this->customerAddressesQuery($filters)->get();

        return $this->streamCsv('customer_addresses', [
            self::CSV_HEADER_CUSTOMER, 'Email', 'Phone', 'Customer Status', 'Label',
            'Address Line 1', 'Address Line 2', 'City', 'State', 'Pincode',
            'Country', 'Default', self::CSV_HEADER_BRANCH, 'Serviceable',
        ], $rows->map(fn ($r) => [
            $r->customer_name,
            $r->email,
            $r->phone ?? '—',
            ucfirst($r->customer_status),
            $r->label,
            $r->address_line1,
            $r->address_line2 ?? '—',
            $r->city,
            $r->state,
            $r->pincode,
            $r->country,
            $r->is_default ? 'Yes' : 'No',
            $r->branch_name ?? '—',
            $r->is_serviceable ? 'Yes' : 'No',
        ])->toArray());
    }

    private function customerAddressesQuery(array $filters)
    {
        return DB::table('customer_addresses')
            ->join('customers', 'customer_addresses.customer_id', '=', 'customers.id')
            ->leftJoin('branches', 'customer_addresses.branch_id', '=', 'branches.id')
            ->select(
                'customer_addresses.id',
                'customers.id as customer_id',
                self::COL_CUSTOMER_NAME,
                'customers.email',
                'customers.phone',
                'customers.status as customer_status',
                'customer_addresses.label',
                'customer_addresses.address_line1',
                'customer_addresses.address_line2',
                'customer_addresses.city',
                'customer_addresses.state',
                'customer_addresses.pincode',
                'customer_addresses.country',
                'customer_addresses.is_default',
                'customer_addresses.is_serviceable',
                'customer_addresses.branch_id',
                self::COL_BRANCH_NAME,
            )
            ->whereNull('customers.deleted_at')
            ->when(! empty($filters['search']), function ($q) use ($filters) {
                $term = '%'.$filters['search'].'%';
                $q->where(function ($w) use ($term) {
                    $w->where('customers.name', 'like', $term)
                        ->orWhere('customers.phone', 'like', $term)
                        ->orWhere('customer_addresses.city', 'like', $term)
                        ->orWhere('customer_addresses.pincode', 'like', $term);
                });
            })
            ->when(! empty($filters['city']), fn ($q) => $q->where('customer_addresses.city', $filters['city'])
            )
            ->when(! empty($filters['state']), fn ($q) => $q->where('customer_addresses.state', $filters['state'])
            )
            ->when(isset($filters['is_serviceable']), fn ($q) => $q->where('customer_addresses.is_serviceable', $filters['is_serviceable'])
            )
            ->when(! empty($filters['branch_id']), fn ($q) => $q->where('customer_addresses.branch_id', $filters['branch_id'])
            )
            ->orderBy('customers.name')
            ->orderByDesc('customer_addresses.is_default');
    }

    // ── CSV Streamer ──────────────────────────────────────────────

    private function streamCsv(string $filename, array $headers, array $rows): StreamedResponse
    {
        return response()->streamDownload(function () use ($headers, $rows) {
            $handle = fopen('php://output', 'w');

            fprintf($handle, chr(0xEF).chr(0xBB).chr(0xBF));

            fputcsv($handle, $headers);
            foreach ($rows as $row) {
                fputcsv($handle, $row);
            }
            fclose($handle);
        }, $filename.'_'.now()->format('Y-m-d').'.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    // ── Coupon Consumption ────────────────────────────────────────

    public function couponConsumption(array $filters): array
    {
        $query = $this->couponConsumptionQuery($filters);
        $perPage = $filters['per_page'] ?? 25;
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'per_page' => $result->perPage(),
                'total' => $result->total(),
            ],
        ];
    }

    public function couponConsumptionCsv(array $filters): StreamedResponse
    {
        $rows = $this->couponConsumptionQuery($filters)->get();

        return $this->streamCsv('coupon_consumption', [
            self::CSV_HEADER_ORDER_NUMBER, 'Used At', self::CSV_HEADER_DELIVERED_ON, 'Coupon Code', 'Coupon Type',
            'Coupon Value', 'Discount Given', self::CSV_HEADER_CUSTOMER, self::CSV_HEADER_BRANCH, 'Order Total',
        ], $rows->map(fn ($r) => [
            $r->order_number,
            $r->used_at,
            $r->delivered_at,
            $r->coupon_code ?? '—',
            $r->coupon_type ?? '—',
            $r->coupon_value ?? '—',
            $r->discount_applied,
            $r->customer_name ?? '—',
            $r->branch_name,
            $r->order_total,
        ])->toArray());
    }

    private const COUPON_CONSUMPTION_SORTABLE = [
        'order_number' => 'orders.order_number',
        'used_at' => 'coupon_usages.used_at',
        'delivered_at' => 'orders.delivered_at',
        'coupon_code' => 'coupons.code',
        'discount_applied' => 'coupon_usages.discount_applied',
        'customer_name' => 'customers.name',
        'branch_name' => 'branches.name',
        'order_total' => 'orders.total',
    ];

    private function couponConsumptionQuery(array $filters)
    {
        $query = DB::table('coupon_usages')
            ->join('orders', 'coupon_usages.order_id', '=', 'orders.id')
            ->join('branches', 'orders.branch_id', '=', 'branches.id')
            ->leftJoin('customers', 'coupon_usages.customer_id', '=', 'customers.id')
            ->leftJoin('coupons', 'coupon_usages.coupon_id', '=', 'coupons.id')
            ->select(
                'coupon_usages.id',
                'coupon_usages.coupon_id',
                'coupon_usages.used_at',
                'coupon_usages.discount_applied',
                self::COL_ORDER_ID,
                'orders.order_number',
                'orders.delivered_at',
                'orders.total as order_total',
                'coupons.code as coupon_code',
                'coupons.type as coupon_type',
                'coupons.value as coupon_value',
                self::COL_CUSTOMER_NAME,
                self::COL_BRANCH_NAME,
                DB::raw('CASE WHEN coupons.id IS NULL THEN 1 ELSE 0 END as coupon_state'),
            )
            ->whereBetween('coupon_usages.used_at', [
                $filters['from_date'].self::DATE_FROM_SUFFIX,
                $filters['to_date'].self::DATE_TO_SUFFIX,
            ])
            ->when(! empty($filters['coupon_id']), fn ($q) => $q->where('coupon_usages.coupon_id', $filters['coupon_id'])
            )
            ->when(! empty($filters['branch_id']), fn ($q) => $q->where('orders.branch_id', $filters['branch_id'])
            );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::COUPON_CONSUMPTION_SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'coupon_usages.used_at') {
                $query->orderByDesc('coupon_usages.used_at');
            }
            $query->orderByDesc('coupon_usages.id');
        } else {
            $query->orderByDesc('coupon_usages.used_at')
                ->orderByDesc('coupon_usages.id');
        }

        return $query;
    }

    public function couponConsumptionCouponList(): array
    {
        return DB::table('coupon_usages')
            ->leftJoin('coupons', 'coupon_usages.coupon_id', '=', 'coupons.id')
            ->select(
                'coupon_usages.coupon_id as id',
                DB::raw('MAX(coupons.code) as code'),
                DB::raw('MAX(coupons.type) as type'),
                DB::raw('MAX(coupons.value) as value'),
                DB::raw('MAX(CASE WHEN coupons.id IS NULL THEN 1 ELSE 0 END) as state'),
            )
            ->groupBy('coupon_usages.coupon_id')
            ->orderByRaw('MAX(coupons.code) asc')
            ->get()
            ->map(fn ($r) => [
                'id' => (int) $r->id,
                'code' => $r->code ?? ('#'.$r->id),
                'type' => $r->type,
                'value' => $r->value,
                'state' => (int) $r->state,
                'deleted' => (int) $r->state === 1,
            ])
            ->toArray();
    }
}
