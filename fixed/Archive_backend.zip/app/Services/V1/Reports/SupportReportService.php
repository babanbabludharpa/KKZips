<?php

namespace App\Services\V1\Reports;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class SupportReportService
{
    private const DEFAULT_PAGE_SIZE = 25;

    private const MAX_PAGE_SIZE = 100;

    private const MIN_PAGE_SIZE = 10;

    private const TBL_SUPPORT_CONVERSATIONS = 'support_conversations as sc';

    private const TBL_CUSTOMERS = 'customers as c';

    private const COL_CUSTOMER_NAME = 'c.name as customer_name';

    private const COL_CUSTOMER_PHONE = 'c.phone as customer_phone';

    // ═══════════════════════════════════════════════════════════
    // 1. CONVERSATIONS
    // ═══════════════════════════════════════════════════════════

    public function conversations(array $filters): LengthAwarePaginator
    {
        $perPage = $this->perPage($filters);

        $query = DB::table(self::TBL_SUPPORT_CONVERSATIONS)
            ->leftJoin(self::TBL_CUSTOMERS, 'c.id', '=', 'sc.customer_id')
            ->select(
                'sc.id',
                'sc.customer_id',
                'sc.status',
                'sc.last_message_at',
                'sc.created_at',
                self::COL_CUSTOMER_NAME,
                self::COL_CUSTOMER_PHONE,
                DB::raw('(SELECT COUNT(*) FROM support_messages WHERE conversation_id = sc.id) as message_count'),
                DB::raw("(SELECT message FROM support_messages WHERE conversation_id = sc.id AND sender_type = 'customer' ORDER BY id ASC LIMIT 1) as first_question"),
                DB::raw("(SELECT COUNT(*) FROM support_messages WHERE conversation_id = sc.id AND sender_type = 'bot' AND JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.layer')) = 'fallback') as unmatched_count")
            )
            ->when($filters['from_date'] ?? null, fn ($q, $v) => $q->whereDate('sc.created_at', '>=', $v)
            )
            ->when($filters['to_date'] ?? null, fn ($q, $v) => $q->whereDate('sc.created_at', '<=', $v)
            )
            ->when($filters['status'] ?? null, fn ($q, $v) => $q->where('sc.status', $v)
            )
            ->when($filters['customer_id'] ?? null, fn ($q, $v) => $q->where('sc.customer_id', $v)
            )
            ->when($filters['search'] ?? null, function ($q, $v) {
                $term = '%'.$v.'%';
                $q->where(function ($w) use ($term) {
                    $w->where('c.name', 'like', $term)
                        ->orWhere('c.phone', 'like', $term);
                });
            });

        $this->applySort($query, $filters, [
            'last_message_at' => 'sc.last_message_at',
            'created_at' => 'sc.created_at',
            'message_count' => 'message_count',
            'customer_name' => 'c.name',
        ], 'sc.last_message_at', 'desc');

        return $query->paginate($perPage);
    }

    // ═══════════════════════════════════════════════════════════
    // 2. CUSTOMER ACTIVITY
    // ═══════════════════════════════════════════════════════════

    public function customerActivity(array $filters): LengthAwarePaginator
    {
        $perPage = $this->perPage($filters);

        $query = DB::table(self::TBL_SUPPORT_CONVERSATIONS)
            ->join(self::TBL_CUSTOMERS, 'c.id', '=', 'sc.customer_id')
            ->select(
                'c.id as customer_id',
                self::COL_CUSTOMER_NAME,
                self::COL_CUSTOMER_PHONE,
                DB::raw('COUNT(DISTINCT sc.id) as conversation_count'),
                DB::raw('(
                    SELECT COUNT(*) FROM support_messages sm
                    WHERE sm.conversation_id IN (
                        SELECT id FROM support_conversations WHERE customer_id = c.id
                    )
                ) as message_count'),
                DB::raw("(
                    SELECT COUNT(*) FROM support_messages sm
                    WHERE sm.conversation_id IN (
                        SELECT id FROM support_conversations WHERE customer_id = c.id
                    )
                    AND sm.sender_type = 'customer'
                ) as questions_asked"),
                DB::raw("(
                    SELECT COUNT(*) FROM support_messages sm
                    WHERE sm.conversation_id IN (
                        SELECT id FROM support_conversations WHERE customer_id = c.id
                    )
                    AND sm.sender_type = 'bot'
                    AND JSON_UNQUOTE(JSON_EXTRACT(sm.metadata, '$.layer')) = 'fallback'
                ) as unmatched_count"),
                DB::raw('MIN(sc.created_at) as first_contact'),
                DB::raw('MAX(sc.last_message_at) as last_contact')
            )
            ->when($filters['from_date'] ?? null, fn ($q, $v) => $q->whereDate('sc.created_at', '>=', $v)
            )
            ->when($filters['to_date'] ?? null, fn ($q, $v) => $q->whereDate('sc.created_at', '<=', $v)
            )
            ->when($filters['customer_id'] ?? null, fn ($q, $v) => $q->where('c.id', $v)
            )
            ->when($filters['search'] ?? null, function ($q, $v) {
                $term = '%'.$v.'%';
                $q->where(function ($w) use ($term) {
                    $w->where('c.name', 'like', $term)
                        ->orWhere('c.phone', 'like', $term);
                });
            })
            ->groupBy('c.id', 'c.name', 'c.phone');

        $this->applySort($query, $filters, [
            'conversation_count' => 'conversation_count',
            'message_count' => 'message_count',
            'unmatched_count' => 'unmatched_count',
            'last_contact' => 'last_contact',
            'customer_name' => 'c.name',
        ], 'last_contact', 'desc');

        return $query->paginate($perPage);
    }

    // ═══════════════════════════════════════════════════════════
    // 3. UNMATCHED MESSAGES
    // ═══════════════════════════════════════════════════════════

    public function unmatchedMessages(array $filters): LengthAwarePaginator
    {
        $perPage = $this->perPage($filters);

        $query = DB::table('support_messages as sm')
            ->join(self::TBL_SUPPORT_CONVERSATIONS, 'sc.id', '=', 'sm.conversation_id')
            ->leftJoin(self::TBL_CUSTOMERS, 'c.id', '=', 'sc.customer_id')
            ->select(
                'sm.id',
                'sm.conversation_id',
                'sm.message as bot_reply',
                'sm.created_at',
                'sc.customer_id',
                self::COL_CUSTOMER_NAME,
                self::COL_CUSTOMER_PHONE,
                DB::raw("(
                    SELECT message FROM support_messages prev
                    WHERE prev.conversation_id = sm.conversation_id
                    AND prev.sender_type = 'customer'
                    AND prev.id < sm.id
                    ORDER BY prev.id DESC LIMIT 1
                ) as customer_question")
            )
            ->where('sm.sender_type', 'bot')
            ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(sm.metadata, '$.layer')) = 'fallback'")
            ->when($filters['from_date'] ?? null, fn ($q, $v) => $q->whereDate('sm.created_at', '>=', $v)
            )
            ->when($filters['to_date'] ?? null, fn ($q, $v) => $q->whereDate('sm.created_at', '<=', $v)
            )
            ->when($filters['customer_id'] ?? null, fn ($q, $v) => $q->where('sc.customer_id', $v)
            )
            ->when($filters['search'] ?? null, function ($q, $v) {
                $term = '%'.$v.'%';
                $q->where(function ($w) use ($term) {
                    $w->where('c.name', 'like', $term)
                        ->orWhere('c.phone', 'like', $term)
                        ->orWhere('sm.message', 'like', $term);
                });
            });

        $this->applySort($query, $filters, [
            'created_at' => 'sm.created_at',
            'customer_name' => 'c.name',
        ], 'sm.created_at', 'desc');

        return $query->paginate($perPage);
    }

    // ═══════════════════════════════════════════════════════════
    // SHARED — sorting, paging
    // ═══════════════════════════════════════════════════════════

    private function perPage(array $filters): int
    {
        return min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );
    }

    private function applySort($query, array $filters, array $map, string $defaultCol, string $defaultDir): void
    {
        $key = $filters['sort_key'] ?? null;
        $dir = strtolower($filters['sort_dir'] ?? $defaultDir) === 'asc' ? 'asc' : 'desc';

        $column = $map[$key] ?? $defaultCol;

        $isAlias = in_array($column, [
            'message_count', 'conversation_count', 'unmatched_count', 'last_contact',
        ], true);

        if ($isAlias) {
            $query->orderByRaw("{$column} {$dir}");
        } else {
            $query->orderBy($column, $dir);
        }
    }
}
