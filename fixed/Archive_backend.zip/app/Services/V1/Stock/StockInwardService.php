<?php

namespace App\Services\V1\Stock;

use App\Models\Branch;
use App\Models\StockInward;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class StockInwardService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'received_date' => 'stock_inwards.received_date',
        'supplier' => 'suppliers.name',
        'branch' => 'branches.name',
        'created_by' => 'users.name',
        'created_at' => 'stock_inwards.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 10;

    private const MAX_PAGE_SIZE = 100;

    public function __construct(protected StockMovementHelper $movementHelper) {}

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = StockInward::query()
            ->with(['supplier', 'branch', 'createdBy', 'items.variant.product'])
            ->leftJoin('suppliers', 'suppliers.id', '=', 'stock_inwards.supplier_id')
            ->leftJoin('branches', 'branches.id', '=', 'stock_inwards.branch_id')
            ->leftJoin('users', 'users.id', '=', 'stock_inwards.created_by')
            ->select('stock_inwards.*')
            ->when($filters['supplier_id'] ?? null, fn ($q, $s) => $q->where('stock_inwards.supplier_id', $s)
            )
            ->when($filters['branch_id'] ?? null, fn ($q, $b) => $q->where('stock_inwards.branch_id', $b)
            );

        // ── Sorting ──
        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            // Stable secondary sort — prevents page-skips when dates tie
            if ($column !== 'stock_inwards.received_date') {
                $query->orderByDesc('stock_inwards.received_date');
            }
            $query->orderByDesc('stock_inwards.id');
        } else {
            // Default — newest received first (matches original ->latest('received_date'))
            $query->orderByDesc('stock_inwards.received_date')
                ->orderByDesc('stock_inwards.id');
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): StockInward
    {
        return StockInward::with(['supplier', 'branch', 'createdBy', 'items.variant.product'])
            ->findOrFail($id);
    }

    /**
     * Record a supplier delivery with multiple product line items.
     * Writes one stock_movements row per item (type=inward, direction=in)
     * and increments inventory for each, via the shared movement helper.
     */
    public function create(array $data, int $userId): StockInward
    {
        return DB::transaction(function () use ($data, $userId) {
            $headOffice = Branch::where('type', 'head_office')->firstOrFail();

            $inward = StockInward::create([
                'supplier_id' => $data['supplier_id'],
                'branch_id' => $headOffice->id,
                'received_date' => $data['received_date'],
                'notes' => $data['notes'] ?? null,
                'created_by' => $userId,
            ]);

            foreach ($data['items'] as $item) {
                $inward->items()->create([
                    'product_variant_id' => $item['product_variant_id'],
                    'quantity' => $item['quantity'],
                    'expiry_date' => $item['expiry_date'] ?? null,
                ]);

                $this->movementHelper->write(
                    variantId: $item['product_variant_id'],
                    branchId: $headOffice->id,
                    type: 'inward',
                    direction: 'in',
                    quantity: $item['quantity'],
                    referenceId: 'INW-'.$inward->id,
                    expiryDate: $item['expiry_date'] ?? null,
                    userId: $userId,
                );
            }

            return $inward->load('items.variant');
        });
    }
}
