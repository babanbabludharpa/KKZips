<?php

namespace App\Services\V1\Stock;

use App\Models\Inventory;
use App\Models\StockMovement;
use Illuminate\Validation\ValidationException;

/**
 * Shared helper for writing a single stock_movements row with a correct,
 * race-safe running balance, and keeping the inventory table in sync.
 *
 * Used by both StockRequestService (transfers) and StockInwardService
 * (supplier receipts) so the locking/balance logic lives in exactly one
 * place instead of being duplicated and risking drift between the two.
 */
class StockMovementHelper
{
    public function write(
        int $variantId,
        int $branchId,
        string $type,
        string $direction, // 'in' or 'out'
        int $quantity,
        ?string $referenceId = null,
        ?string $expiryDate = null,
        ?int $userId = null,
    ): StockMovement {
        $inventory = Inventory::where('product_variant_id', $variantId)
            ->where('branch_id', $branchId)
            ->lockForUpdate()
            ->first();

        if (! $inventory) {
            $inventory = Inventory::create([
                'product_variant_id' => $variantId,
                'branch_id' => $branchId,
                'quantity' => 0,
            ]);
            $inventory = Inventory::where('id', $inventory->id)->lockForUpdate()->first();
        }

        $openingStock = $inventory->quantity;

        if ($direction === 'out' && $openingStock < $quantity) {
            throw ValidationException::withMessages([
                'stock' => "Insufficient stock. Only {$openingStock} unit(s) available.",
            ]);
        }

        $closingStock = $direction === 'out'
            ? $openingStock - $quantity
            : $openingStock + $quantity;

        $movement = StockMovement::create([
            'product_variant_id' => $variantId,
            'branch_id' => $branchId,
            'type' => $type,
            'opening_stock' => $openingStock,
            'in' => $direction === 'in' ? $quantity : 0,
            'out' => $direction === 'out' ? $quantity : 0,
            'closing_stock' => $closingStock,
            'transaction_date' => now()->toDateString(),
            'reference_id' => $referenceId,
            'expiry_date' => $expiryDate,
            'created_by' => $userId,
        ]);

        $inventory->update(['quantity' => $closingStock]);

        return $movement;
    }
}
