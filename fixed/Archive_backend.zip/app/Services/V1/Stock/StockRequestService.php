<?php

namespace App\Services\V1\Stock;

use App\Models\Inventory;
use App\Models\StockRequest;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class StockRequestService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'from_branch' => 'from_branches.name',
        'to_branch' => 'to_branches.name',
        'status' => 'stock_requests.status',
        'requested_by' => 'users.name',
        'created_at' => 'stock_requests.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 1;

    private const MAX_PAGE_SIZE = 500;

    public function __construct(protected StockMovementHelper $movementHelper) {}

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = StockRequest::query()
            ->with(['fromBranch', 'toBranch', 'requestedBy', 'actionedBy', 'items.variant.product', 'items.variant.unit'])
            ->leftJoin('branches as from_branches', 'from_branches.id', '=', 'stock_requests.from_branch_id')
            ->leftJoin('branches as to_branches', 'to_branches.id', '=', 'stock_requests.to_branch_id')
            ->leftJoin('users', 'users.id', '=', 'stock_requests.requested_by')
            ->select('stock_requests.*')
            ->when($filters['status'] ?? null, fn ($q, $s) => $q->where('stock_requests.status', $s)
            )
            ->when($filters['from_branch_id'] ?? null, fn ($q, $b) => $q->where('stock_requests.from_branch_id', $b)
            )
            ->when($filters['to_branch_id'] ?? null, fn ($q, $b) => $q->where('stock_requests.to_branch_id', $b)
            );

        // ── Sorting ──
        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'stock_requests.created_at') {
                $query->orderByDesc('stock_requests.created_at');
            }
            $query->orderByDesc('stock_requests.id');
        } else {
            // Default — newest first (matches original ->latest())
            $query->orderByDesc('stock_requests.created_at')
                ->orderByDesc('stock_requests.id');
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): StockRequest
    {
        return StockRequest::with(['fromBranch', 'toBranch', 'requestedBy', 'actionedBy', 'items.variant.product', 'items.variant.unit'])
            ->findOrFail($id);
    }

    /**
     * Create a new stock request with line items.
     * from_branch_id is resolved from the logged-in user's branch in the controller.
     */
    public function create(array $data, int $userId): StockRequest
    {
        return DB::transaction(function () use ($data, $userId) {
            $request = StockRequest::create([
                'from_branch_id' => $data['from_branch_id'],
                'to_branch_id' => $data['to_branch_id'],
                'status' => 'pending',
                'requested_by' => $userId,
                'notes' => $data['notes'] ?? null,
            ]);

            foreach ($data['items'] as $item) {
                $request->items()->create([
                    'product_variant_id' => $item['product_variant_id'],
                    'quantity_requested' => $item['quantity_requested'],
                ]);
            }

            return $request->load('items.variant');
        });
    }

    /**
     * Approve a request. Each item gets a quantity_approved (can be partial).
     */
    public function approve(StockRequest $request, array $approvals, int $userId): StockRequest
    {
        $this->guardStatus($request, 'pending', 'approve');

        return DB::transaction(function () use ($request, $approvals, $userId) {
            foreach ($approvals as $approval) {
                $item = $request->items()->where('id', $approval['item_id'])->firstOrFail();

                $this->guardSufficientStock(
                    $request->to_branch_id,
                    $item->product_variant_id,
                    $approval['quantity_approved']
                );

                $item->update(['quantity_approved' => $approval['quantity_approved']]);
            }

            $request->update([
                'status' => 'approved',
                'actioned_by' => $userId,
                'approved_at' => now(),
            ]);

            return $request->fresh(['items.variant']);
        });
    }

    /**
     * Fulfill an approved request.
     */
    public function fulfill(StockRequest $request, int $userId): StockRequest
    {
        $this->guardStatus($request, 'approved', 'fulfill');

        return DB::transaction(function () use ($request, $userId) {
            $referenceId = 'SR-'.$request->id.'-'.Str::random(6);

            foreach ($request->items as $item) {
                $qty = $item->quantity_approved;

                if (! $qty || $qty <= 0) {
                    $item->update(['quantity_fulfilled' => 0]);

                    continue;
                }

                $this->guardSufficientStock($request->to_branch_id, $item->product_variant_id, $qty);

                $this->movementHelper->write(
                    variantId: $item->product_variant_id,
                    branchId: $request->to_branch_id,
                    type: 'transfer',
                    direction: 'out',
                    quantity: $qty,
                    referenceId: $referenceId,
                    userId: $userId,
                );

                $this->movementHelper->write(
                    variantId: $item->product_variant_id,
                    branchId: $request->from_branch_id,
                    type: 'transfer',
                    direction: 'in',
                    quantity: $qty,
                    referenceId: $referenceId,
                    userId: $userId,
                );

                $item->update(['quantity_fulfilled' => $qty]);
            }

            $request->update([
                'status' => 'fulfilled',
                'fulfilled_at' => now(),
            ]);

            return $request->fresh(['items.variant']);
        });
    }

    public function cancel(StockRequest $request): StockRequest
    {
        if (! in_array($request->status, ['pending', 'approved'])) {
            throw ValidationException::withMessages([
                'status' => 'Only pending or approved requests can be cancelled.',
            ]);
        }

        $request->update(['status' => 'cancelled']);

        return $request->fresh();
    }

    private function guardStatus(StockRequest $request, string $expected, string $action): void
    {
        if ($request->status !== $expected) {
            throw ValidationException::withMessages([
                'status' => "Cannot {$action} a request that is not {$expected}. Current status: {$request->status}.",
            ]);
        }
    }

    private function getAvailableStock(int $branchId, int $variantId): int
    {
        return Inventory::where('branch_id', $branchId)
            ->where('product_variant_id', $variantId)
            ->value('quantity') ?? 0;
    }

    private function guardSufficientStock(int $branchId, int $variantId, int $quantity): void
    {
        $available = $this->getAvailableStock($branchId, $variantId);

        if ($quantity > $available) {
            throw ValidationException::withMessages([
                'quantity_approved' => "Only {$available} unit(s) available. Please adjust quantity.",
            ]);
        }
    }
}
