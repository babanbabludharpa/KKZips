<?php

namespace App\Services\V1;

use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProfileService
{
    public function get(User $user): User
    {
        return $user->loadMissing('roles', 'branch');
    }

    public function uploadAvatar(User $user, UploadedFile $file): User
    {
        $tenantSlug = tenant()?->getTenantKey() ?? 'default';

        $ext = strtolower($file->getClientOriginalExtension() ?: 'jpg');
        if (! in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
            $ext = 'jpg';
        }

        $directory = "tenants/{$tenantSlug}/users/{$user->id}";
        $filename = "profile.{$ext}";
        $disk = Storage::disk('public');

        return DB::transaction(function () use ($user, $file, $disk, $directory, $filename) {
            // Delete any old profile.* in this folder (jpg/png/webp) so we never
            // accumulate stale files when a user switches formats.
            foreach ($disk->files($directory) as $existing) {
                if (Str::startsWith(basename($existing), 'profile.')) {
                    $disk->delete($existing);
                }
            }

            $path = $file->storeAs($directory, $filename, 'public');

            $user->update(['avatar' => $path]);

            return $user->fresh(['roles', 'branch']);
        });
    }

    public function removeAvatar(User $user): User
    {
        if (! empty($user->avatar)) {
            Storage::disk('public')->delete($user->avatar);
        }

        $user->update(['avatar' => null]);

        return $user->fresh(['roles', 'branch']);
    }
}
