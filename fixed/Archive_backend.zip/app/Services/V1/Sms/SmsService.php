<?php

namespace App\Services\V1\Sms;

use App\Services\V1\Sms\Contracts\SmsGatewayInterface;
use App\Services\V1\Sms\Gateways\LegacyHttpSmsGateway;
use App\Services\V1\Tenant\TenantProfileService;

// Single entry point for sending SMS anywhere in the app. Callers depend
// only on this class, never on a specific gateway -- swapping providers
// later means changing resolveGateway() here and nothing at any call site.
class SmsService
{
    public function __construct(private readonly TenantProfileService $profileService) {}

    public function send(string $mobile, string $message): bool
    {
        // isConfigured() is the single source of truth (see
        // TenantProfileService::smsIsConfigured()) and already includes
        // sms_enabled -- checking it here, not just credential presence in
        // resolveGateway() below, is what actually makes the tenant-facing
        // "pause SMS" toggle stop sends. Without this line, resolveGateway()
        // only verifies username/password/sender_id exist and would still
        // send while sms_enabled=false, silently ignoring the switch.
        if (! $this->isConfigured()) {
            return false;
        }

        $gateway = $this->resolveGateway();
        if (! $gateway) {
            return false;
        }

        return $gateway->send($mobile, $message);
    }

    public function isConfigured(): bool
    {
        return $this->profileService->smsIsConfigured();
    }

    private function resolveGateway(): ?SmsGatewayInterface
    {
        $profile = $this->profileService->getProfile();
        if (! $profile?->sms_username || ! $profile?->sms_password || ! $profile?->sms_sender_id) {
            return null;
        }

        return new LegacyHttpSmsGateway(
            $profile->sms_username,
            $profile->sms_password,
            $profile->sms_sender_id,
        );
    }
}
