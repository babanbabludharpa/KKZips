<?php

namespace App\Services\V1\Sms\Gateways;

use App\Services\V1\Sms\Contracts\SmsGatewayInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

// Wraps the legacy send.aspx HTTP API (converted from the raw curl call).
// NOTE: this endpoint is http://, not https:// -- credentials and message
// content travel in cleartext as GET query params. This is inherent to the
// gateway itself, not something fixable here. If the provider offers an
// HTTPS/POST variant, switch to it here and nothing else in the app needs
// to change.
class LegacyHttpSmsGateway implements SmsGatewayInterface
{
    public function __construct(
        private readonly string $username,
        private readonly string $password,
        private readonly string $senderId,
    ) {}

    private function gatewayUrl(): string
    {
        return (string) config('services.sms_gateway.url');
    }

    private function route(): string
    {
        return (string) config('services.sms_gateway.route');
    }

    public function send(string $mobile, string $message): bool
    {
        try {
            $queryString = http_build_query([
                'username' => $this->username,
                'pass' => $this->password,
                'route' => $this->route(),
                'senderid' => $this->senderId,
                'numbers' => $mobile,
                'message' => $message,
            ]);

            $fullUrl = $this->gatewayUrl().'?'.$queryString;

            // SECURITY: Never log $fullUrl — it contains credentials and message content.
            Log::info('SMS gateway request initiated', ['mobile' => $mobile]);

            $response = Http::timeout(10)->get($fullUrl);

            if (! $response->successful()) {
                // SECURITY: Response body may echo back the request — do not log it.
                Log::warning('SMS send failed', [
                    'mobile' => $mobile,
                    'status' => $response->status(),
                ]);

                return false;
            }

            Log::info('SMS send response received', [
                'mobile' => $mobile,
                'status' => $response->status(),
            ]);

            return true;
        } catch (\Throwable $e) {
            Log::error('SMS gateway request failed', [
                'mobile' => $mobile,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }
}
