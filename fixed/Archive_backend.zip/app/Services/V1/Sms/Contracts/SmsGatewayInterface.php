<?php

namespace App\Services\V1\Sms\Contracts;

interface SmsGatewayInterface
{
    public function send(string $mobile, string $message): bool;
}
