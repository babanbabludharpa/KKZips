<?php

namespace App\Services\V1\Tenant;

use App\Models\SubscriptionOccurrence;
use App\Models\SubscriptionItem;
use App\Models\TenantLeave;
use App\Models\TenantLeaveAuditLog;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class TenantLeaveService
{
    private const CANCELLABLE_STATUSES = ['scheduled', 'assigned'];

    /** Request-scoped cache — active leaves are loaded once and reused. */
    private ?Collection $activeLeavesCache = null;

    public function preview(array $shape): array
    {
        $leave = new TenantLeave($shape);
        return $this->evaluateImpact($leave);
    }

    public function create(array $data, int $userId): array
    {
        $this->activeLeavesCache = null;

        return DB::transaction(function () use ($data, $userId) {
            $data['created_by'] = $userId;
            $data['status'] = 'active';
            $leave = TenantLeave::create($data);
            $counts = $this->reconcile($leave, null);
            $this->audit($leave, 'created', $userId, $counts);
            return ['leave' => $leave->fresh(), 'counts' => $counts];
        });
    }

    public function update(TenantLeave $leave, array $data, int $userId): array
    {
        $this->activeLeavesCache = null;

        return DB::transaction(function () use ($leave, $data, $userId) {
            $previousShape = $leave->only([
                'start_date', 'end_date', 'branch_ids', 'slot_ids',
                'recurrence_rule', 'reason', 'status',
            ]);
            $leave->update($data);
            $this->activeLeavesCache = null;
            $counts = $this->reconcile($leave, $previousShape);
            $this->audit($leave, 'updated', $userId, $counts);
            return ['leave' => $leave->fresh(), 'counts' => $counts];
        });
    }

    public function cancel(TenantLeave $leave, int $userId): array
    {
        $this->activeLeavesCache = null;

        return DB::transaction(function () use ($leave, $userId) {
            $leave->update([
                'status'       => 'cancelled',
                'cancelled_by' => $userId,
                'cancelled_at' => now(),
            ]);
            $this->activeLeavesCache = null;
            $counts = $this->reconcile($leave, null);
            $this->audit($leave, 'cancelled', $userId, $counts);
            return ['leave' => $leave->fresh(), 'counts' => $counts];
        });
    }

    public function reconcile(TenantLeave $leave, ?array $previousShape): array
    {
        $counts = ['cancelled' => 0, 'reactivated' => 0, 'skipped_status' => 0];

        $dates = $leave->effectiveDates();
        if ($previousShape) {
            $tmp = new TenantLeave($previousShape);
            $dates = collect($dates)
                ->merge($tmp->effectiveDates())
                ->unique(fn ($d) => $d->toDateString())
                ->all();
        }
        if (empty($dates)) return $counts;

        $start = min(array_map(fn ($d) => $d->toDateString(), $dates));
        $end   = max(array_map(fn ($d) => $d->toDateString(), $dates));

        $branchIds = $this->unionBranches(
            $previousShape['branch_ids'] ?? null,
            $leave->branch_ids
        );

        $occurrences = SubscriptionOccurrence::query()
            ->whereBetween('occurrence_date', [$start, $end])
            ->when($branchIds !== null, fn ($q) => $q->whereIn('branch_id', $branchIds))
            ->get();

        foreach ($occurrences as $occ) {
            $slotId = $this->resolveSlotId($occ);
            $desiredLeave = $this->whichLeaveCovers($occ->branch_id, $occ->occurrence_date->toDateString(), $slotId);

            if ($desiredLeave) {
                // Case A — occurrence is cancelled-by-leave but the covering
                // leave changed. Re-point it without touching status.
                if ($occ->status === 'holiday_skipped'
                    && $occ->leave_id !== null
                    && $occ->leave_id !== $desiredLeave->id) {
                    $occ->update([
                        'leave_id'                  => $desiredLeave->id,
                        'leave_cancellation_reason' => $desiredLeave->reason,
                    ]);
                    $counts['reassigned'] = ($counts['reassigned'] ?? 0) + 1;
                    $this->logOccurrence($desiredLeave->id, $occ->id, 'reassigned', $occ->status);
                    continue;
                }

                // Case B — still active but the leave covers it.
                if (! in_array($occ->status, self::CANCELLABLE_STATUSES, true)) {
                    $counts['skipped_status']++;
                    $this->logOccurrence($desiredLeave->id, $occ->id, 'skipped_status', $occ->status);
                    continue;
                }

                // Case C — cancel.
                $occ->update([
                    'status'                    => 'holiday_skipped',
                    'skip_source'               => 'holiday',
                    'leave_id'                  => $desiredLeave->id,
                    'leave_previous_status'     => $occ->status,
                    'leave_cancellation_reason' => $desiredLeave->reason,
                ]);
                $counts['cancelled']++;
                $this->logOccurrence($desiredLeave->id, $occ->id, 'cancelled', $occ->leave_previous_status);
            } else if ($occ->leave_id !== null && $occ->status === 'holiday_skipped') {
                // Case D — no active leave covers this anymore → reactivate.
                $prev = $occ->leave_previous_status ?? 'scheduled';
                $occ->update([
                    'status'                    => $prev,
                    'skip_source'               => null,
                    'leave_id'                  => null,
                    'leave_previous_status'     => null,
                    'leave_cancellation_reason' => null,
                ]);
                $counts['reactivated']++;
                $this->logOccurrence($leave->id, $occ->id, 'reactivated', $prev);
            }
        }

        return $counts;
    }

    /**
     * Returns blocked dates for the next $horizonDays, filtered to a branch.
     * Merged per date: if any leaf is all-slot, all_slots = true; reasons
     * are concatenated (unique).
     *
     * @return array<int, array{date:string, all_slots:bool, slot_ids:int[], reason:string}>
     */
    public function blockedDatesFor(?int $branchId, int $horizonDays = 90): array
    {
        $start = \Carbon\CarbonImmutable::now()->startOfDay();
        $end   = $start->addDays($horizonDays);

        $byDate = [];

        foreach ($this->activeLeaves() as $leave) {
            if ($leave->branch_ids !== null && $branchId !== null && ! in_array($branchId, $leave->branch_ids)) {
                continue;
            }
            if ($leave->branch_ids !== null && $branchId === null) {
                continue;
            }

            foreach ($leave->effectiveDates() as $d) {
                if ($d->lt($start) || $d->gt($end)) continue;

                $key = $d->toDateString();
                if (! isset($byDate[$key])) {
                    $byDate[$key] = [
                        'date'      => $key,
                        'all_slots' => false,
                        'slot_ids'  => [],
                        'reason'    => [],
                    ];
                }

                if ($leave->slot_ids === null) {
                    $byDate[$key]['all_slots'] = true;
                } else {
                    $byDate[$key]['slot_ids'] = array_values(array_unique(
                        array_merge($byDate[$key]['slot_ids'], $leave->slot_ids)
                    ));
                }
                $byDate[$key]['reason'][] = $leave->reason;
            }
        }

        return collect($byDate)
            ->map(function ($row) {
                $row['reason'] = implode(' • ', array_unique($row['reason']));
                return $row;
            })
            ->sortBy('date')
            ->values()
            ->all();
    }

    /**
     * First active leave that covers this (branch, date, slot). Null if none.
     * Public — used by SubscriptionOccurrenceGenerationService.
     */
    public function whichLeaveCovers(int $branchId, string $date, ?int $slotId): ?TenantLeave
    {
        return $this->activeLeaves()
            ->first(function (TenantLeave $l) use ($branchId, $date, $slotId) {
                if ($l->branch_ids !== null && ! in_array($branchId, $l->branch_ids)) {
                    return false;
                }
                $dateObj = \Carbon\CarbonImmutable::parse($date);
                $matchesDate = false;
                foreach ($l->effectiveDates() as $d) {
                    if ($d->toDateString() === $dateObj->toDateString()) {
                        $matchesDate = true;
                        break;
                    }
                }
                if (! $matchesDate) return false;

                if ($l->slot_ids !== null && $slotId !== null && ! in_array($slotId, $l->slot_ids)) {
                    return false;
                }
                return true;
            });
    }

    private function activeLeaves(): Collection
    {
        return $this->activeLeavesCache ??= TenantLeave::query()
            ->where('status', 'active')
            ->get();
    }

    private function resolveSlotId(SubscriptionOccurrence $occ): ?int
    {
        static $cache = [];
        $itemId = $occ->subscription_item_id;
        if (! $itemId) return null;
        if (array_key_exists($itemId, $cache)) return $cache[$itemId];

        $item = SubscriptionItem::find($itemId);
        return $cache[$itemId] = $item?->slot_id;
    }

    private function unionBranches(?array $a, ?array $b): ?array
    {
        if ($a === null || $b === null) return null;
        return array_values(array_unique(array_merge($a, $b)));
    }

    private function logOccurrence(int $leaveId, ?int $occId, string $action, ?string $prevStatus): void
    {
        DB::table('tenant_leave_occurrences')->insert([
            'leave_id'        => $leaveId,
            'occurrence_id'   => $occId,
            'action'          => $action,
            'previous_status' => $prevStatus,
            'created_at'      => now(),
            'updated_at'      => now(),
        ]);
    }

    private function audit(TenantLeave $leave, string $action, int $userId, array $counts): void
    {
        TenantLeaveAuditLog::create([
            'leave_id'   => $leave->id,
            'user_id'    => $userId,
            'action'     => $action,
            'payload'    => $leave->fresh()->toArray(),
            'counts'     => $counts,
            'created_at' => now(),
        ]);
    }

    private function evaluateImpact(TenantLeave $leave): array
    {
        $dates = $leave->effectiveDates();
        if (empty($dates)) return ['occurrences' => 0, 'dates' => []];

        $start = $dates[0]->toDateString();
        $end   = end($dates)->toDateString();

        $q = SubscriptionOccurrence::query()->whereBetween('occurrence_date', [$start, $end]);
        if ($leave->branch_ids !== null) $q->whereIn('branch_id', $leave->branch_ids);

        return [
            'occurrences' => $q->count(),
            'dates'       => array_map(fn ($d) => $d->toDateString(), $dates),
        ];
    }
}
