<?php

namespace App\Services\V1\Tenant;

use App\Models\Tenant;
use App\Models\TenantProfile;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class TenantProfileService
{
    public function getProfile(): ?TenantProfile
    {
        return TenantProfile::first();
    }

    public function upsert(array $data): TenantProfile
    {
        $profile = TenantProfile::first();

        // Blank string / null means "don't touch this field" for secret
        // credentials only — the UI shows •••••••• and never re-sends the
        // real value. Support contact fields are NOT in this list.
        foreach ([
            'pusher_app_id', 'pusher_key', 'pusher_secret', 'pusher_cluster',
            'razorpay_key_id', 'razorpay_key_secret', 'razorpay_webhook_secret',
            'sms_username', 'sms_password', 'sms_sender_id',
            'whatsapp_api_key',
        ] as $field) {
            if (array_key_exists($field, $data) && ($data[$field] === '' || $data[$field] === null)) {
                unset($data[$field]);
            }
        }

        if ($profile) {
            $profile->update($data);
        } else {
            $profile = TenantProfile::create($data);
        }

        return $profile->fresh();
    }

    public function uploadLogo(UploadedFile $file): string
    {
        $tenantId = tenant('id');
        $path = "tenants/{$tenantId}/logo";

        $profile = TenantProfile::first();
        if ($profile?->logo) {
            Storage::disk('public')->delete("{$path}/{$profile->logo}");
        }

        $filename = 'logo_'.time().'.'.$file->getClientOriginalExtension();
        $file->storeAs($path, $filename, 'public');

        return $filename;
    }

    public function getLogoUrl(?string $filename): ?string
    {
        if (! $filename) return null;
        $tenantId = tenant('id');
        return Storage::disk('public')->url("tenants/{$tenantId}/logo/{$filename}");
    }

    public function razorpayIsConfigured(): bool
    {
        $p = $this->getProfile();
        return (bool) ($p?->razorpay_key_id && $p?->razorpay_key_secret && $p?->razorpay_webhook_secret);
    }

    public function smsIsConfigured(): bool
    {
        $p = $this->getProfile();
        return (bool) ($p?->sms_username && $p?->sms_password && $p?->sms_sender_id && $p?->sms_enabled);
    }

    public function getBranding(): array
    {
        if (tenant()) {
            $profile = $this->getProfile();
            $tenantModel = Tenant::find(tenant('id'));
            $themeKey = $tenantModel?->theme_key ?? 'crimson';

            return [
                'brand_name' => $profile?->company_name,
                'logo_url' => $this->getLogoUrl($profile?->logo),
                'tenant_slug' => tenant('id'),
                'theme_key' => $themeKey,
            ];
        }

        return [
            'brand_name' => config('branding.platform.brand_name'),
            'logo_url' => null,
            'tenant_slug' => null,
            'theme_key' => 'crimson',
        ];
    }
}
