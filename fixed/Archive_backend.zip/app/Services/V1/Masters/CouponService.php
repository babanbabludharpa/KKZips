<?php

namespace App\Services\V1\Masters;

use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Tenant\Customer;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CouponService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'code' => 'coupons.code',
        'type' => 'coupons.type',
        'value' => 'coupons.value',
        'valid_from' => 'coupons.valid_from',
        'valid_until' => 'coupons.valid_until',
        'used_count' => 'coupons.used_count',
        'is_active' => 'coupons.is_active',
        'created_at' => 'coupons.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 10;

    private const MAX_PAGE_SIZE = 100;

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = Coupon::query()
            ->when($filters['search'] ?? null, function ($q, $s) {
                // Wrapped in a closure so the OR doesn't leak out and
                // combine incorrectly with the is_active filter below.
                $q->where(function ($w) use ($s) {
                    $w->where('coupons.code', 'like', "%{$s}%")
                        ->orWhere('coupons.description', 'like', "%{$s}%");
                });
            })
            ->when(isset($filters['is_active']), fn ($q) => $q->where('coupons.is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            );

        // ── Sorting ──
        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'coupons.created_at') {
                $query->orderByDesc('coupons.created_at');
            }
            $query->orderByDesc('coupons.id');
        } else {
            // Default — newest first
            $query->orderByDesc('coupons.created_at');
        }

        return $query->paginate($perPage);
    }

    /**
     * Validates a coupon against a customer + cart context.
     * Throws ValidationException with a clear message on failure.
     * Does NOT lock/mutate — pure read-side check for /coupons/validate and order preview.
     */
    public function validate(Coupon $coupon, Customer $customer, float $subtotal): void
    {
        $today = Carbon::today()->toDateString();

        if (! $coupon->is_active) {
            throw ValidationException::withMessages(['coupon' => 'This coupon is no longer active.']);
        }

        if ($coupon->valid_from?->toDateString() > $today) {
            throw ValidationException::withMessages(['coupon' => 'This coupon is not yet valid.']);
        }

        if ($coupon->valid_until && $coupon->valid_until->toDateString() < $today) {
            throw ValidationException::withMessages(['coupon' => 'This coupon has expired.']);
        }

        if ($subtotal < $coupon->min_order_amount) {
            throw ValidationException::withMessages([
                'coupon' => "Minimum order amount of ₹{$coupon->min_order_amount} required.",
            ]);
        }

        if ($coupon->usage_limit_total && $coupon->used_count >= $coupon->usage_limit_total) {
            throw ValidationException::withMessages(['coupon' => 'This coupon has reached its usage limit.']);
        }

        if ($coupon->usage_limit_per_customer) {
            $customerUses = CouponUsage::where('coupon_id', $coupon->id)
                ->where('customer_id', $customer->id)
                ->count();

            if ($customerUses >= $coupon->usage_limit_per_customer) {
                throw ValidationException::withMessages(['coupon' => 'You have already used this coupon.']);
            }
        }

        if ($coupon->is_first_order_only) {
            $hasOrdered = DB::table('orders')
                ->where('customer_id', $customer->id)
                ->whereIn('status', ['confirmed', 'preparing', 'out_for_delivery', 'delivered'])
                ->exists();

            if ($hasOrdered) {
                throw ValidationException::withMessages(['coupon' => 'This coupon is valid for first orders only.']);
            }
        }
    }

    public function computeDiscount(Coupon $coupon, float $subtotal): float
    {
        $discount = $coupon->type === 'flat'
            ? (float) $coupon->value
            : round($subtotal * ((float) $coupon->value / 100), 2);

        if ($coupon->max_discount_amount) {
            $discount = min($discount, (float) $coupon->max_discount_amount);
        }

        return min($discount, $subtotal); // never discount more than the order value
    }

    /**
     * Atomically re-validates and redeems the coupon at order-commit time.
     * MUST be called inside the same DB transaction as order creation,
     * and MUST be the version that actually decrements availability —
     * the validate() above is advisory only (used for preview/UI), not authoritative.
     */
    public function redeem(int $couponId, int $customerId, int $orderId, float $subtotal): float
    {
        return DB::transaction(function () use ($couponId, $customerId, $orderId, $subtotal) {
            // lockForUpdate is the part that's missing everywhere else in this codebase
            $coupon = Coupon::where('id', $couponId)->lockForUpdate()->firstOrFail();

            $customer = Customer::findOrFail($customerId);
            $this->validate($coupon, $customer, $subtotal); // re-check under lock, not just at preview time

            $discount = $this->computeDiscount($coupon, $subtotal);

            $coupon->increment('used_count');

            CouponUsage::create([
                'coupon_id' => $coupon->id,
                'customer_id' => $customerId,
                'order_id' => $orderId,
                'discount_applied' => $discount,
                'used_at' => now(),
            ]);

            return $discount;
        });
    }
}
