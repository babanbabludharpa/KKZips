<?php

namespace App\Services\V1\Masters;

use App\Models\AttributeValue;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\VariantPriceHistory;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class ProductVariantService
{
    public function create(Product $product, array $data): ProductVariant
    {
        $this->guardDuplicateSku($data['sku']);
        $this->guardOneValuePerAttributeAxis($data['attribute_value_ids'] ?? []);
        $this->guardAtLeastOneChannel($data);

        return DB::transaction(function () use ($product, $data) {
            $variant = $product->variants()->create([
                'sku' => $data['sku'],
                'unit_id' => $data['unit_id'],
                'hsn_code' => $data['hsn_code'] ?? null,
                'image' => $data['image'] ?? null,
                'mrp' => $data['mrp'],
                'purchase_price' => $data['purchase_price'] ?? null,
                'selling_price' => $data['selling_price'],
                'is_coupon_eligible' => $data['is_coupon_eligible'] ?? true,
                'available_for_order' => $data['available_for_order'] ?? true,
                'available_for_subscription' => $data['available_for_subscription'] ?? false,
                'tax_rate_id' => $data['tax_rate_id'] ?? null,
                'min_order_qty' => $data['min_order_qty'] ?? 1,
                'is_active' => $data['is_active'] ?? true,
            ]);

            if (! empty($data['attribute_value_ids'])) {
                $variant->attributeValues()->sync($data['attribute_value_ids']);
            }

            return $variant->fresh(['unit', 'taxRate', 'attributeValues.attribute']);
        });
    }

    public function bulkCreate(Product $product, array $variantsData): Collection
    {
        $skus = array_column($variantsData, 'sku');
        if (count($skus) !== count(array_unique($skus))) {
            throw ValidationException::withMessages([
                'variants' => 'Duplicate SKUs found in the bulk create request.',
            ]);
        }

        foreach ($variantsData as $data) {
            $this->guardDuplicateSku($data['sku']);
            $this->guardOneValuePerAttributeAxis($data['attribute_value_ids'] ?? []);
            $this->guardAtLeastOneChannel($data);
        }

        $created = collect();

        DB::transaction(function () use ($product, $variantsData, &$created) {
            foreach ($variantsData as $data) {
                $variant = $product->variants()->create([
                    'sku' => $data['sku'],
                    'unit_id' => $data['unit_id'],
                    'hsn_code' => $data['hsn_code'] ?? null,
                    'mrp' => $data['mrp'],
                    'purchase_price' => $data['purchase_price'] ?? null,
                    'selling_price' => $data['selling_price'],
                    'is_coupon_eligible' => $data['is_coupon_eligible'] ?? true,
                    'available_for_order' => $data['available_for_order'] ?? true,
                    'available_for_subscription' => $data['available_for_subscription'] ?? false,
                    'tax_rate_id' => $data['tax_rate_id'] ?? null,
                    'min_order_qty' => $data['min_order_qty'] ?? 1,
                    'is_active' => $data['is_active'] ?? true,
                ]);

                if (! empty($data['attribute_value_ids'])) {
                    $variant->attributeValues()->sync($data['attribute_value_ids']);
                }

                $created->push($variant->fresh(['unit', 'taxRate', 'attributeValues.attribute']));
            }
        });

        return $created;
    }

    public function update(ProductVariant $variant, array $data): ProductVariant
    {
        if (isset($data['sku']) && $data['sku'] !== $variant->sku) {
            $this->guardDuplicateSku($data['sku'], $variant->id);
        }

        if (array_key_exists('attribute_value_ids', $data)) {
            $this->guardOneValuePerAttributeAxis($data['attribute_value_ids'] ?? []);
        }

        $this->guardAtLeastOneChannel($data, $variant);

        return DB::transaction(function () use ($variant, $data) {
            $this->recordPriceHistoryIfChanged($variant, $data);

            $updates = array_filter([
                'sku' => $data['sku'] ?? null,
                'unit_id' => $data['unit_id'] ?? null,
                'hsn_code' => $data['hsn_code'] ?? null,
                'image' => $data['image'] ?? null,
                'mrp' => $data['mrp'] ?? null,
                'purchase_price' => $data['purchase_price'] ?? null,
                'selling_price' => $data['selling_price'] ?? null,
                'tax_rate_id' => $data['tax_rate_id'] ?? null,
                'min_order_qty' => $data['min_order_qty'] ?? null,
            ], fn ($v) => $v !== null);

            if (! empty($updates)) {
                $variant->update($updates);
            }

            if (isset($data['is_active'])) {
                $variant->update(['is_active' => $data['is_active']]);
            }

            if (isset($data['is_coupon_eligible'])) {
                $variant->update(['is_coupon_eligible' => $data['is_coupon_eligible']]);
            }

            if (array_key_exists('available_for_order', $data)) {
                $variant->update(['available_for_order' => $data['available_for_order']]);
            }

            if (array_key_exists('available_for_subscription', $data)) {
                $variant->update(['available_for_subscription' => $data['available_for_subscription']]);
            }

            if (array_key_exists('attribute_value_ids', $data)) {
                $variant->attributeValues()->sync($data['attribute_value_ids'] ?? []);
            }

            return $variant->fresh(['unit', 'taxRate', 'attributeValues.attribute']);
        });
    }

    private function recordPriceHistoryIfChanged(ProductVariant $variant, array $data): void
    {
        $priceFields = ['mrp', 'selling_price', 'purchase_price'];
        $priceChanged = collect($priceFields)->contains(
            fn ($f) => isset($data[$f]) && (string) $data[$f] !== (string) $variant->$f
        );

        if (! $priceChanged) {
            return;
        }

        VariantPriceHistory::create([
            'product_variant_id' => $variant->id,
            'changed_by' => Auth::id(),
            'source' => 'manual',
            'schedule_id' => null,
            'prev_mrp' => $variant->mrp,
            'prev_selling_price' => $variant->selling_price,
            'prev_purchase_price' => $variant->purchase_price,
            'new_mrp' => $data['mrp'] ?? $variant->mrp,
            'new_selling_price' => $data['selling_price'] ?? $variant->selling_price,
            'new_purchase_price' => $data['purchase_price'] ?? $variant->purchase_price,
            'changed_at' => now(),
        ]);
    }

    public function uploadImage(ProductVariant $variant, UploadedFile $file): ProductVariant
    {
        $tenantId = tenant('id');
        $path = "tenants/{$tenantId}/variants";

        if ($variant->image) {
            Storage::disk('public')->delete("{$path}/{$variant->image}");
        }

        $filename = 'variant_'.$variant->id.'_'.time().'.'.$file->getClientOriginalExtension();
        $file->storeAs($path, $filename, 'public');

        $variant->update(['image' => $filename]);

        return $variant->fresh(['unit', 'taxRate', 'attributeValues.attribute']);
    }

    public function getImageUrl(?string $filename): ?string
    {
        if (! $filename) {
            return null;
        }
        $tenantId = tenant('id');

        return Storage::disk('public')->url("tenants/{$tenantId}/variants/{$filename}");
    }

    public function delete(ProductVariant $variant): void
    {
        if ($variant->inventory()->where('quantity', '>', 0)->exists()) {
            throw ValidationException::withMessages([
                'variant' => 'Cannot delete variant with existing stock. Clear stock first.',
            ]);
        }

        $tenantId = tenant('id');

        if ($variant->image) {
            Storage::disk('public')->delete("tenants/{$tenantId}/variants/{$variant->image}");
        }

        // ★ Media gallery — delete every media file + row so no orphans
        // remain when the variant is removed.
        $variant->media->each(function ($media) use ($tenantId) {
            Storage::disk('public')->delete("tenants/{$tenantId}/variants/{$media->path}");
        });
        $variant->media()->delete();

        $variant->delete();
    }

    public function toggleActive(ProductVariant $variant): ProductVariant
    {
        $variant->update(['is_active' => ! $variant->is_active]);

        return $variant->fresh();
    }

    private function guardDuplicateSku(string $sku, ?int $excludeId = null): void
    {
        $exists = ProductVariant::where('sku', $sku)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'sku' => "SKU '{$sku}' is already in use.",
            ]);
        }
    }

    private function guardOneValuePerAttributeAxis(array $valueIds): void
    {
        if (empty($valueIds)) {
            return;
        }

        $attributeIds = AttributeValue::whereIn('id', $valueIds)
            ->pluck('attribute_id');

        if ($attributeIds->count() !== $attributeIds->unique()->count()) {
            throw ValidationException::withMessages([
                'attribute_value_ids' => 'Only one value per attribute is allowed per variant.',
            ]);
        }
    }

    /**
     * Ensure a variant is available for at least one sales channel.
     */
    private function guardAtLeastOneChannel(array $data, ?ProductVariant $existing = null): void
    {
        $order = array_key_exists('available_for_order', $data)
            ? (bool) $data['available_for_order']
            : (bool) ($existing?->available_for_order ?? true);

        $subscription = array_key_exists('available_for_subscription', $data)
            ? (bool) $data['available_for_subscription']
            : (bool) ($existing?->available_for_subscription ?? false);

        if (! $order && ! $subscription) {
            throw ValidationException::withMessages([
                'available_for_order' => 'Variant must be available for at least one of: Order or Subscription.',
            ]);
        }
    }
}
