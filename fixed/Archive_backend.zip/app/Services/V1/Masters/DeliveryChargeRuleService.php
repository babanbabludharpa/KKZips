<?php

namespace App\Services\V1\Masters;

use App\Models\DeliveryChargeRule;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DeliveryChargeRuleService
{
    /**
     * Single source of truth for "activate this rule, deactivate all others."
     * Locks the rows being touched so two concurrent admin requests can't
     * both pass the deactivate-check before either commits — the bug in the
     * original controller where store/update/toggle each reimplemented this
     * with three different conditions and zero locking.
     */
    protected function activateExclusively(?int $exceptId = null): void
    {
        $query = DeliveryChargeRule::where('is_active', true)->lockForUpdate();

        if ($exceptId) {
            $query->where('id', '!=', $exceptId);
        }

        $query->update(['is_active' => false]);
    }

    public function create(array $data): DeliveryChargeRule
    {
        return DB::transaction(function () use ($data) {
            $wantsActive = $data['is_active'] ?? true;

            if ($wantsActive) {
                $this->activateExclusively();
            }

            return DeliveryChargeRule::create([
                ...$data,
                'min_order_amount' => $data['min_order_amount'] ?? 0,
                'per_km_charge' => $data['per_km_charge'] ?? 0,
                'is_active' => $wantsActive,
            ]);
        });
    }

    public function update(DeliveryChargeRule $rule, array $data): DeliveryChargeRule
    {
        return DB::transaction(function () use ($rule, $data) {
            $rule = DeliveryChargeRule::where('id', $rule->id)->lockForUpdate()->firstOrFail();

            $activating = isset($data['is_active']) && $data['is_active'] && ! $rule->is_active;
            $deactivatingLastOne = isset($data['is_active']) && ! $data['is_active'] && $rule->is_active;

            if ($deactivatingLastOne && ! $this->anotherActiveRuleExists($rule->id)) {
                throw ValidationException::withMessages([
                    'is_active' => 'Cannot deactivate the only active delivery rule. Activate another rule first — checkout requires exactly one active rule at all times.',
                ]);
            }

            if ($activating) {
                $this->activateExclusively($rule->id);
            }

            $rule->update($data);

            return $rule->fresh();
        });
    }

    public function toggle(DeliveryChargeRule $rule): DeliveryChargeRule
    {
        return DB::transaction(function () use ($rule) {
            $rule = DeliveryChargeRule::where('id', $rule->id)->lockForUpdate()->firstOrFail();

            if ($rule->is_active && ! $this->anotherActiveRuleExists($rule->id)) {
                throw ValidationException::withMessages([
                    'is_active' => 'Cannot deactivate the only active delivery rule. Activate another rule first.',
                ]);
            }

            if (! $rule->is_active) {
                $this->activateExclusively($rule->id);
            }

            $rule->update(['is_active' => ! $rule->is_active]);

            return $rule->fresh();
        });
    }

    public function delete(DeliveryChargeRule $rule): void
    {
        if ($rule->is_active) {
            throw ValidationException::withMessages([
                'is_active' => 'Cannot delete the active delivery rule. Deactivate or replace it first.',
            ]);
        }

        $rule->delete();
    }

    protected function anotherActiveRuleExists(int $exceptId): bool
    {
        return DeliveryChargeRule::where('id', '!=', $exceptId)
            ->where('is_active', true)
            ->exists();
    }
}
