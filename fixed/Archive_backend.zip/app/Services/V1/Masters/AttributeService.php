<?php

namespace App\Services\V1\Masters;

use App\Models\Attribute;
use App\Models\AttributeValue;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class AttributeService
{
    public function getAll(array $filters = []): LengthAwarePaginator
    {
        return Attribute::query()
            ->with('values')
            ->when($filters['search'] ?? null, fn ($q, $s) => $q->where('name', 'like', "%{$s}%")
            )
            ->when(isset($filters['is_active']), fn ($q) => $q->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            )
            ->latest()
            ->paginate($filters['per_page'] ?? 15);
    }

    public function create(array $data): Attribute
    {
        $this->guardDuplicateName($data['name']);

        return Attribute::create($data);
    }

    public function update(Attribute $attribute, array $data): Attribute
    {
        if (isset($data['name']) && $data['name'] !== $attribute->name) {
            $this->guardDuplicateName($data['name'], $attribute->id);
        }
        $attribute->update($data);

        return $attribute->fresh('values');
    }

    public function delete(Attribute $attribute): void
    {
        $variantCount = $attribute->values()
            ->withCount('variants')
            ->get()
            ->sum('variants_count');

        if ($variantCount > 0) {
            throw ValidationException::withMessages([
                'attribute' => 'Cannot delete attribute with values assigned to product variants.',
            ]);
        }

        $attribute->values()->delete();
        $attribute->delete();
    }

    public function toggleActive(Attribute $attribute): Attribute
    {
        $attribute->update(['is_active' => ! $attribute->is_active]);

        return $attribute->fresh('values');
    }

    // ── Attribute Values ──────────────────────────────────────────

    public function addValue(Attribute $attribute, array $data): AttributeValue
    {
        $this->guardDuplicateValue($attribute->id, $data['value']);

        return $attribute->values()->create($data);
    }

    public function updateValue(AttributeValue $value, array $data): AttributeValue
    {
        if (isset($data['value']) && $data['value'] !== $value->value) {
            $this->guardDuplicateValue($value->attribute_id, $data['value'], $value->id);
        }
        $value->update($data);

        return $value->fresh();
    }

    public function deleteValue(AttributeValue $value): void
    {
        if ($value->variants()->exists()) {
            throw ValidationException::withMessages([
                'attribute_value' => 'Cannot delete value assigned to product variants.',
            ]);
        }
        $value->delete();
    }

    private function guardDuplicateName(string $name, ?int $excludeId = null): void
    {
        $exists = Attribute::where('name', $name)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'name' => 'An attribute with this name already exists.',
            ]);
        }
    }

    private function guardDuplicateValue(int $attributeId, string $value, ?int $excludeId = null): void
    {
        $exists = AttributeValue::where('attribute_id', $attributeId)
            ->where('value', $value)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'value' => 'This value already exists for the selected attribute.',
            ]);
        }
    }
}
