<?php

namespace App\Services\V1\Masters;

use App\Models\DiscountSchedule;
use App\Models\ProductVariant;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DiscountScheduleService
{
    public function getAllForVariant(ProductVariant $variant, array $filters = []): LengthAwarePaginator
    {
        return $variant->discountSchedules()
            ->when($filters['status'] ?? null, fn ($q, $s) => $q->where('status', $s))
            ->latest('starts_on')
            ->paginate($filters['per_page'] ?? 15);
    }

    public function create(ProductVariant $variant, array $data, int $userId): DiscountSchedule
    {
        $this->guardDateRange($data['starts_on'], $data['ends_on'] ?? null);
        $this->guardNoOverlap($variant, $data['starts_on'], $data['ends_on'] ?? null);

        return $variant->discountSchedules()->create([
            'discount_percent' => $data['discount_percent'],
            'starts_on' => $data['starts_on'],
            'ends_on' => $data['ends_on'] ?? null,
            'status' => 'pending',
            'created_by' => $userId,
        ]);
    }

    public function update(DiscountSchedule $schedule, array $data): DiscountSchedule
    {
        $this->guardEditable($schedule);

        if (isset($data['starts_on']) || array_key_exists('ends_on', $data)) {
            $newStart = $data['starts_on'] ?? $schedule->starts_on->toDateString();
            $newEnd = $data['ends_on'] ?? $schedule->ends_on?->toDateString();

            $this->guardDateRange($newStart, $newEnd);
            $this->guardNoOverlap($schedule->variant, $newStart, $newEnd, $schedule->id);
        }

        $schedule->update(array_filter([
            'discount_percent' => $data['discount_percent'] ?? null,
            'starts_on' => $data['starts_on'] ?? null,
            'ends_on' => $data['ends_on'] ?? null,
        ], fn ($v) => $v !== null));

        return $schedule->fresh();
    }

    public function cancel(DiscountSchedule $schedule): DiscountSchedule
    {
        $this->guardEditable($schedule);
        $wasActive = $schedule->status === 'active';

        $schedule->update(['status' => 'cancelled']);

        // If this was the active discount, switch off the variant flag immediately
        if ($wasActive) {
            $schedule->variant->update(['is_discount_active' => false]);
        }

        return $schedule->fresh();
    }

    /**
     * Called by the daily cron command.
     * Order matters: expire first, then activate, so a same-day
     * end+start transition never leaves the variant flag stuck true
     * with no valid schedule, or skips a same-day new activation.
     *
     * With the overlap guard in place, a variant can never have two
     * active discounts at once — so the flag set here is unambiguous.
     */
    public function processDueSchedules(): array
    {
        $expiredCount = $this->expireDueSchedules();
        $activatedCount = $this->activateDueSchedules();

        return ['expired' => $expiredCount, 'activated' => $activatedCount];
    }

    private function expireDueSchedules(): int
    {
        $count = 0;

        $expiring = DiscountSchedule::where('status', 'active')
            ->whereNotNull('ends_on')
            ->whereDate('ends_on', '<', now()->toDateString())
            ->get();

        foreach ($expiring as $schedule) {
            DB::transaction(function () use ($schedule, &$count) {
                $schedule->update(['status' => 'expired']);

                $variant = ProductVariant::lockForUpdate()->find($schedule->product_variant_id);
                if ($variant && ! $variant->discountSchedules()->where('status', 'active')->exists()) {
                    $variant->update(['is_discount_active' => false]);
                }
                $count++;
            });
        }

        return $count;
    }

    private function activateDueSchedules(): int
    {
        $count = 0;

        $due = DiscountSchedule::where('status', 'pending')
            ->whereDate('starts_on', '<=', now()->toDateString())
            ->get();

        foreach ($due as $schedule) {
            DB::transaction(function () use ($schedule, &$count) {
                $schedule->update(['status' => 'active']);

                $variant = ProductVariant::lockForUpdate()->find($schedule->product_variant_id);
                if ($variant) {
                    $variant->update(['is_discount_active' => true]);
                }
                $count++;
            });
        }

        return $count;
    }

    /**
     * Rejects a new pending/active discount window that overlaps any
     * existing pending/active window for the same variant.
     *
     * Two overlapping windows would both activate during their common
     * days, and the pricing engine would either stack them (bad —
     * double-discount the product) or pick one arbitrarily (worse —
     * non-deterministic). Rejecting overlap keeps the outcome
     * predictable: at most one discount is ever active on any given day.
     */
    private function guardNoOverlap(
        ProductVariant $variant,
        string $startsOn,
        ?string $endsOn,
        ?int $excludeId = null
    ): void {
        // Normalize the requested window
        $newStart = $startsOn;
        $newEnd = $endsOn ?: '9999-12-31';   // open-ended treated as +infinity

        $query = $variant->discountSchedules()
            ->whereIn('status', ['pending', 'active'])
            ->where(function ($q) use ($newStart, $newEnd) {
                // Two ranges overlap iff: existing.start <= new.end
                //                    AND existing.end   >= new.start
                $q->whereDate('starts_on', '<=', $newEnd)
                    ->where(function ($q2) use ($newStart) {
                        $q2->whereNull('ends_on')
                            ->orWhereDate('ends_on', '>=', $newStart);
                    });
            });

        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        if ($query->exists()) {
            throw ValidationException::withMessages([
                'starts_on' => 'This discount window overlaps with an existing pending or active discount. Pick a different date range.',
            ]);
        }
    }

    private function guardDateRange(string $startsOn, ?string $endsOn): void
    {
        if (now()->toDateString() > $startsOn) {
            throw ValidationException::withMessages([
                'starts_on' => 'Start date cannot be in the past.',
            ]);
        }

        if ($endsOn !== null && $endsOn < $startsOn) {
            throw ValidationException::withMessages([
                'ends_on' => 'End date cannot be before start date.',
            ]);
        }
    }

    private function guardEditable(DiscountSchedule $schedule): void
    {
        if (! in_array($schedule->status, ['pending', 'active'])) {
            throw ValidationException::withMessages([
                'discount_schedule' => 'Only pending or active schedules can be edited or cancelled.',
            ]);
        }
    }
}
