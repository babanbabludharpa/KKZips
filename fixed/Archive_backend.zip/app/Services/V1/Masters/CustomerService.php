<?php

namespace App\Services\V1\Masters;

use App\Models\ChangeMaster;
use App\Models\Tenant\Customer;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\StreamedResponse;

class CustomerService
{
    public const STATUSES = ['active', 'inactive', 'suspended'];

    private const SORTABLE = [
        'name'              => 'customers.name',
        'email'             => 'customers.email',
        'phone'             => 'customers.phone',
        'status'            => 'customers.status',
        'status_changed_at' => 'customers.status_changed_at',
        'created_at'        => 'customers.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;
    private const MIN_PAGE_SIZE     = 10;
    private const MAX_PAGE_SIZE     = 100;

    public function customers(array $filters): array
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query  = $this->customersQuery($filters, $sortKey, $sortDir);
        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page'    => $result->lastPage(),
                'per_page'     => $result->perPage(),
                'total'        => $result->total(),
                'from'         => $result->firstItem(),
                'to'           => $result->lastItem(),
            ],
        ];
    }

    public function customersCsv(array $filters): StreamedResponse
    {
        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $rows = $this->customersQuery($filters, $sortKey, $sortDir)->get();

        return $this->streamCsv('customers', [
            'ID', 'Name', 'Email', 'Phone', 'Status', 'Status Changed On',
            'Registered On', 'Default Address', 'City', 'State', 'Pincode',
        ], $rows->map(fn ($r) => [
            $r->id,
            $r->name,
            $r->email,
            $r->phone ?? '—',
            ucfirst($r->status),
            $r->status_changed_at ?? '—',
            $r->created_at,
            $r->default_address_line1 ?? '—',
            $r->default_city ?? '—',
            $r->default_state ?? '—',
            $r->default_pincode ?? '—',
        ])->toArray());
    }

    private function customersQuery(array $filters, ?string $sortKey = null, string $sortDir = 'desc')
    {
        // Customers are tenant-wide identities. Branch is a property of the
        // address, not of the customer. No branch scoping is applied here.
        $query = DB::table('customers')
            ->leftJoin(
                DB::raw('(SELECT * FROM customer_addresses WHERE is_default = 1) as da'),
                'da.customer_id', '=', 'customers.id'
            )
            ->select(
                'customers.id',
                'customers.name',
                'customers.email',
                'customers.phone',
                'customers.status',
                'customers.status_changed_at',
                'customers.created_at',
                'da.address_line1 as default_address_line1',
                'da.city as default_city',
                'da.state as default_state',
                'da.pincode as default_pincode',
            )
            ->whereNull('customers.deleted_at')
            ->when(! empty($filters['search']), function ($q) use ($filters) {
                $term = '%'.$filters['search'].'%';
                $q->where(function ($w) use ($term) {
                    $w->where('customers.name', 'like', $term)
                      ->orWhere('customers.email', 'like', $term)
                      ->orWhere('customers.phone', 'like', $term);
                });
            })
            ->when(! empty($filters['status']), fn ($q) => $q->where('customers.status', $filters['status']))
            ->when(! empty($filters['from_date']) && ! empty($filters['to_date']), fn ($q) =>
                $q->whereBetween('customers.created_at', [
                    $filters['from_date'].' 00:00:00',
                    $filters['to_date'].' 23:59:59',
                ])
            );

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'customers.created_at') {
                $query->orderByDesc('customers.created_at');
            }
            $query->orderByDesc('customers.id');
        } else {
            $query->orderByDesc('customers.created_at');
        }

        return $query;
    }

    public function create(array $data): Customer
    {
        return DB::transaction(function () use ($data) {
            $email = strtolower(trim($data['email']));

            if (Customer::where('email', $email)->exists()) {
                throw ValidationException::withMessages([
                    'email' => 'A customer with this email already exists.',
                ]);
            }

            $customer = Customer::create([
                'name'              => $data['name'],
                'email'             => $email,
                'phone'             => $data['phone'] ?? null,
                'password'          => Hash::make($data['password']),
                'status'            => $data['status'] ?? 'active',
                'status_changed_at' => now(),
                'email_verified_at' => ! empty($data['email_verified']) ? now() : null,
                'phone_verified'    => ! empty($data['phone_verified']),
            ]);

            $this->logCustomerChange(
                $customer,
                'Customer created from admin panel',
                null,
                [
                    'name'   => $customer->name,
                    'email'  => $customer->email,
                    'phone'  => $customer->phone,
                    'status' => $customer->status,
                ]
            );

            return $customer;
        });
    }

    public function update(int $customerId, array $data): Customer
    {
        return DB::transaction(function () use ($customerId, $data) {
            $customer = Customer::findOrFail($customerId);

            if (array_key_exists('phone', $data)) {
                $incoming = $data['phone'];
                $current  = $customer->phone;
                $incomingNorm = is_string($incoming) ? trim($incoming) : $incoming;

                if ((string) $incomingNorm !== (string) $current) {
                    throw ValidationException::withMessages([
                        'phone' => 'Phone number cannot be changed because it is used as the login username.',
                    ]);
                }
            }

            $before = [
                'name'              => $customer->name,
                'email'             => $customer->email,
                'phone'             => $customer->phone,
                'status'            => $customer->status,
                'phone_verified'    => $customer->phone_verified,
                'email_verified_at' => optional($customer->email_verified_at)->toDateTimeString(),
            ];

            $emailChanged = false;

            if (isset($data['email'])) {
                $newEmail = strtolower(trim($data['email']));
                if ($newEmail !== $customer->email) {
                    $exists = Customer::where('email', $newEmail)
                        ->where('id', '!=', $customer->id)
                        ->exists();
                    if ($exists) {
                        throw ValidationException::withMessages([
                            'email' => 'A customer with this email already exists.',
                        ]);
                    }
                    $customer->email = $newEmail;
                    $emailChanged = true;
                }
            }

            if (isset($data['name'])) {
                $customer->name = $data['name'];
            }

            if (isset($data['status']) && $data['status'] !== $customer->status) {
                $customer->status            = $data['status'];
                $customer->status_changed_at = now();
            }

            if (array_key_exists('phone_verified', $data)) {
                $customer->phone_verified = (bool) $data['phone_verified'];
            }

            if (array_key_exists('email_verified', $data)) {
                if ($data['email_verified']) {
                    $customer->email_verified_at = $customer->email_verified_at ?? now();
                } else {
                    $customer->email_verified_at        = null;
                    $customer->email_verification_token = null;
                }
            }

            if ($emailChanged) {
                $customer->email_verified_at        = ! empty($data['email_verified']) ? now() : null;
                $customer->email_verification_token = null;
            }

            $customer->save();

            $after = [
                'name'              => $customer->name,
                'email'             => $customer->email,
                'phone'             => $customer->phone,
                'status'            => $customer->status,
                'phone_verified'    => $customer->phone_verified,
                'email_verified_at' => optional($customer->email_verified_at)->toDateTimeString(),
            ];

            $this->logCustomerChange(
                $customer,
                'Customer details updated from admin panel',
                $before,
                $after
            );

            return $customer;
        });
    }

    public function resetPassword(int $customerId, string $plainPassword): void
    {
        DB::transaction(function () use ($customerId, $plainPassword) {
            $customer = Customer::findOrFail($customerId);

            $customer->password       = Hash::make($plainPassword);
            $customer->remember_token = null;
            $customer->save();

            $this->logCustomerChange(
                $customer,
                'Password reset from admin panel',
                [
                    'id'    => $customer->id,
                    'email' => $customer->email,
                    'phone' => $customer->phone,
                ],
                ['password' => '***']
            );
        });
    }

    public function delete(int $customerId): void
    {
        DB::transaction(function () use ($customerId) {
            $customer = Customer::findOrFail($customerId);

            $this->logCustomerChange(
                $customer,
                'Customer soft-deleted from admin panel',
                ['id' => $customer->id, 'email' => $customer->email],
                ['deleted_at' => now()->toDateTimeString()]
            );

            $customer->delete();
        });
    }

    public function updateStatus(int $customerId, string $status): Customer
    {
        if (! in_array($status, self::STATUSES, true)) {
            throw ValidationException::withMessages([
                'status' => 'Status must be one of: '.implode(', ', self::STATUSES),
            ]);
        }

        return DB::transaction(function () use ($customerId, $status) {
            $customer = Customer::findOrFail($customerId);

            if ($customer->status === $status) {
                return $customer;
            }

            $previousStatus = $customer->status;

            $customer->status            = $status;
            $customer->status_changed_at = now();
            $customer->save();

            $this->logStatusChange($customer, $previousStatus, $status);

            return $customer;
        });
    }

    public function addressesForCustomer(int $customerId): Collection
    {
        return DB::table('customer_addresses')
            ->leftJoin('branches', 'customer_addresses.branch_id', '=', 'branches.id')
            ->where('customer_addresses.customer_id', $customerId)
            ->select(
                'customer_addresses.*',
                'branches.name as branch_name',
            )
            ->orderByDesc('customer_addresses.is_default')
            ->get();
    }

    private function logStatusChange(
        Customer $customer,
        string $previousStatus,
        string $newStatus
    ): void {
        $customerPhone = (string) ($customer->phone ?? '');

        $admin         = Auth::user();
        $adminUsername = (string) ($admin->username ?? $admin->mobile_number ?? '');

        ChangeMaster::create([
            'username'       => substr($customerPhone, 0, 30),
            'added_by'       => substr($adminUsername, 0, 30),
            'ip_address'     => (string) request()->ip(),
            'flag'           => ChangeMaster::FLAG_CUSTOMER_STATUS_CHANGE,
            'panel'          => ChangeMaster::PANEL_ADMIN,
            'remark'         => substr(
                "Customer #{$customer->id} status changed from {$previousStatus} to {$newStatus}",
                0,
                150
            ),
            'previous_value' => json_encode([
                'status'            => $previousStatus,
                'status_changed_at' => optional($customer->getOriginal('status_changed_at'))->toDateTimeString(),
            ]),
            'new_value'      => json_encode([
                'status'            => $newStatus,
                'status_changed_at' => optional($customer->status_changed_at)->toDateTimeString(),
            ]),
        ]);
    }

    private function logCustomerChange(
        Customer $customer,
        string $remark,
        ?array $before,
        ?array $after
    ): void {
        $admin         = Auth::user();
        $adminUsername = (string) ($admin->username ?? $admin->mobile_number ?? '');
        $customerPhone = (string) ($customer->phone ?? '');

        ChangeMaster::create([
            'username'       => substr($customerPhone, 0, 30),
            'added_by'       => substr($adminUsername, 0, 30),
            'ip_address'     => (string) request()->ip(),
            'flag'           => ChangeMaster::FLAG_CUSTOMER_STATUS_CHANGE,
            'panel'          => ChangeMaster::PANEL_ADMIN,
            'remark'         => substr("Customer #{$customer->id}: {$remark}", 0, 150),
            'previous_value' => json_encode($before ?? new \stdClass()),
            'new_value'      => json_encode($after  ?? new \stdClass()),
        ]);
    }

    private function streamCsv(string $filename, array $headers, array $rows): StreamedResponse
    {
        return response()->streamDownload(function () use ($headers, $rows) {
            $handle = fopen('php://output', 'w');
            fprintf($handle, chr(0xEF).chr(0xBB).chr(0xBF));
            fputcsv($handle, $headers);
            foreach ($rows as $row) {
                fputcsv($handle, $row);
            }
            fclose($handle);
        }, $filename.'_'.now()->format('Y-m-d').'.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function getProfile360(int $customerId): array
    {
        $customer = Customer::with([
            'addresses.branch',
            'addresses.zone',
            'notes.addedBy:id,name',
        ])->findOrFail($customerId);

        // Get wallet balance
        $balance = DB::table('customer_wallets')->where('customer_id', $customerId)->value('balance') ?? 0;

        // Get last delivery
        $lastDelivery = DB::table('subscription_occurrences')
            ->join('subscription_items', 'subscription_occurrences.subscription_item_id', '=', 'subscription_items.id')
            ->join('subscriptions', 'subscription_items.subscription_id', '=', 'subscriptions.id')
            ->where('subscriptions.customer_id', $customerId)
            ->where('subscription_occurrences.status', 'delivered')
            ->max('subscription_occurrences.occurrence_date');

        return [
            'customer' => $customer,
            'balance' => (float) $balance,
            'last_delivery_date' => $lastDelivery,
            'effective_warning_limit' => $customer->effectiveWarningLimit(),
            'effective_suspension_limit' => $customer->effectiveSuspensionLimit(),
        ];
    }

    public function customersList360(array $filters): array
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        // Start with the existing query from your service
        $query = $this->customersQuery($filters, $sortKey, $sortDir);

        // Add wallet balance
        $query->addSelect(DB::raw('COALESCE((SELECT balance FROM customer_wallets WHERE customer_id = customers.id), 0) as balance'));

        // Add last delivery date
        $query->addSelect(DB::raw('(
            SELECT MAX(so.occurrence_date) 
            FROM subscription_occurrences so
            JOIN subscription_items si ON si.id = so.subscription_item_id
            JOIN subscriptions s ON s.id = si.subscription_id
            WHERE s.customer_id = customers.id AND so.status = "delivered"
        ) as last_delivery_date'));

        $result = $query->paginate($perPage);

        return [
            'data' => $result->items(),
            'meta' => [
                'current_page' => $result->currentPage(),
                'last_page'    => $result->lastPage(),
                'per_page'     => $result->perPage(),
                'total'        => $result->total(),
                'from'         => $result->firstItem(),
                'to'           => $result->lastItem(),
            ],
        ];
    }
}
