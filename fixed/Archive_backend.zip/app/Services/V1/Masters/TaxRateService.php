<?php

namespace App\Services\V1\Masters;

use App\Models\TaxRate;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class TaxRateService
{
    public function getAll(array $filters = []): LengthAwarePaginator
    {
        return TaxRate::query()
            ->when($filters['search'] ?? null, fn ($q, $s) => $q->where('label', 'like', "%{$s}%")
            )
            ->when(isset($filters['is_active']), fn ($q) => $q->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            )
            ->orderBy('percentage')
            ->paginate($filters['per_page'] ?? 15);
    }

    public function create(array $data): TaxRate
    {
        $this->guardDuplicate($data['percentage']);

        return TaxRate::create($data);
    }

    public function update(TaxRate $taxRate, array $data): TaxRate
    {
        if (isset($data['percentage']) && (float) $data['percentage'] !== (float) $taxRate->percentage) {
            $this->guardDuplicate($data['percentage'], $taxRate->id);
        }
        $taxRate->update($data);

        return $taxRate->fresh();
    }

    public function delete(TaxRate $taxRate): void
    {
        if ($taxRate->variants()->exists()) {
            throw ValidationException::withMessages([
                'tax_rate' => 'Cannot delete tax rate assigned to product variants.',
            ]);
        }
        $taxRate->delete();
    }

    public function toggleActive(TaxRate $taxRate): TaxRate
    {
        $taxRate->update(['is_active' => ! $taxRate->is_active]);

        return $taxRate->fresh();
    }

    private function guardDuplicate(float $percentage, ?int $excludeId = null): void
    {
        $exists = TaxRate::where('percentage', $percentage)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'percentage' => 'A tax rate with this percentage already exists.',
            ]);
        }
    }
}
