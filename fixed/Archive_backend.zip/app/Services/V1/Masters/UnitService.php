<?php

namespace App\Services\V1\Masters;

use App\Models\Unit;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class UnitService
{
    public function getAll(array $filters = []): LengthAwarePaginator
    {
        return Unit::query()
            ->when($filters['search'] ?? null, fn ($q, $s) => $q->where('name', 'like', "%{$s}%")
                ->orWhere('abbreviation', 'like', "%{$s}%")
            )
            ->when(isset($filters['is_active']), fn ($q) => $q->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            )
            ->latest()
            ->paginate($filters['per_page'] ?? 15);
    }

    public function create(array $data): Unit
    {
        $this->guardDuplicate($data['abbreviation']);

        return Unit::create($data);
    }

    public function update(Unit $unit, array $data): Unit
    {
        if (isset($data['abbreviation']) && $data['abbreviation'] !== $unit->abbreviation) {
            $this->guardDuplicate($data['abbreviation'], $unit->id);
        }
        $unit->update($data);

        return $unit->fresh();
    }

    public function delete(Unit $unit): void
    {
        if ($unit->products()->exists()) {
            throw ValidationException::withMessages([
                'unit' => 'Cannot delete unit assigned to products.',
            ]);
        }
        $unit->delete();
    }

    public function toggleActive(Unit $unit): Unit
    {
        $unit->update(['is_active' => ! $unit->is_active]);

        return $unit->fresh();
    }

    private function guardDuplicate(string $abbreviation, ?int $excludeId = null): void
    {
        $exists = Unit::where('abbreviation', $abbreviation)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'abbreviation' => 'This abbreviation is already in use.',
            ]);
        }
    }
}
