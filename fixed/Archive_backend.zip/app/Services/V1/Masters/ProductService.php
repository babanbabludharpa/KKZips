<?php

namespace App\Services\V1\Masters;

use App\Models\Product;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class ProductService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'name' => 'products.name',
        'category' => 'categories.name',   // requires the conditional join below
        'is_active' => 'products.is_active',
        'created_at' => 'products.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 10;

    private const MAX_PAGE_SIZE = 500;

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = Product::query()
            ->with(['category', 'variants.unit', 'variants.taxRate'])
            // ★ FREE GIFTS — search matches the product name OR any variant
            // SKU, so a gift product can be found by its SKU (e.g.
            // "GIFT-001") in the stock-inward picker and products search.
            ->when($filters['search'] ?? null, function ($q, $s) {
                $q->where(function ($q) use ($s) {
                    $q->where('products.name', 'like', "%{$s}%")
                        ->orWhereHas('variants', fn ($v) => $v->where('sku', 'like', "%{$s}%"));
                });
            })
            ->when($filters['category_id'] ?? null, fn ($q, $c) => $q->where('products.category_id', $c)
            )
            ->when(isset($filters['is_active']), fn ($q) => $q->where('products.is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            );

        // ★ FREE GIFTS — gift products live in their own section. Default:
        // hide them from the main catalog. `is_gift=true` → only gifts
        // (the Free Gifts page uses this). `include_gifts=true` → mixed
        // listing with a GIFT tag (e.g. the stock-inward picker).
        $isGift = array_key_exists('is_gift', $filters)
            ? filter_var($filters['is_gift'], FILTER_VALIDATE_BOOLEAN)
            : null;
        $includeGifts = filter_var($filters['include_gifts'] ?? false, FILTER_VALIDATE_BOOLEAN);

        if ($isGift !== null) {
            $query->whereHas('variants', fn ($v) => $v->where('is_gift', $isGift));
        } elseif (! $includeGifts) {
            $query->where(function ($q) {
                $q->doesntHave('variants')
                    ->orWhereHas('variants', fn ($v) => $v->where('is_gift', false));
            });
        }

        // Category sort requires the categories table in scope — join only
        // when it's actually needed, so we don't pay for it on every request.
        if ($sortKey === 'category') {
            $query->leftJoin('categories', 'categories.id', '=', 'products.category_id')
                ->select('products.*');
        }

        // ── Sorting ──
        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'products.created_at') {
                $query->orderByDesc('products.created_at');
            }
            $query->orderByDesc('products.id');
        } else {
            // Default — newest first (matches original ->latest())
            $query->orderByDesc('products.created_at');
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): Product
    {
        return Product::with([
            'category',
            'variants.unit',
            'variants.taxRate',
            'variants.attributeValues.attribute',
            'variants.discountSchedules' => fn ($q) => $q->where('status', 'active'),
        ])->findOrFail($id);
    }

    public function create(array $data): Product
    {
        return Product::create($data);
    }

    public function update(Product $product, array $data): Product
    {
        $product->update($data);

        return $product->fresh(['category', 'variants']);
    }

    public function delete(Product $product): void
    {
        if ($product->variants()->exists()) {
            throw ValidationException::withMessages([
                'product' => 'Cannot delete product with existing variants. Delete all variants first.',
            ]);
        }
        $product->delete();
    }

    public function toggleActive(Product $product): Product
    {
        $product->update(['is_active' => ! $product->is_active]);

        return $product->fresh();
    }
}
