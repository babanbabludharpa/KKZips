<?php

namespace App\Services\V1\Masters;

use App\Models\Supplier;
use Illuminate\Http\UploadedFile;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class SupplierService
{
    private const SORTABLE = [
        'name' => 'suppliers.name',
        'phone' => 'suppliers.phone',
        'email' => 'suppliers.email',
        'gst_no' => 'suppliers.gst_no',
        'is_active' => 'suppliers.is_active',
        'created_at' => 'suppliers.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;
    private const MIN_PAGE_SIZE = 10;
    private const MAX_PAGE_SIZE = 500;

    private const DOCUMENT_FIELDS = [
        'registration_doc',
        'gst_doc',
        'pan_doc',
        'fssai_doc',
        'adhar_doc',
        'shopact_doc',
    ];

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = Supplier::query()
            ->with('creator:id,name')
            ->when($filters['search'] ?? null, function ($q, $s) {
                $q->where(function ($w) use ($s) {
                    $w->where('suppliers.name', 'like', "%{$s}%")
                        ->orWhere('suppliers.phone', 'like', "%{$s}%")
                        ->orWhere('suppliers.gst_no', 'like', "%{$s}%")
                        ->orWhere('suppliers.adhar_no', 'like', "%{$s}%");
                });
            })
            ->when(isset($filters['is_active']), fn ($q) => $q->where(
                'suppliers.is_active',
                filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN)
            ));

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'suppliers.created_at') {
                $query->orderByDesc('suppliers.created_at');
            }
            $query->orderByDesc('suppliers.id');
        } else {
            $query->orderByDesc('suppliers.created_at');
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): Supplier
    {
        return Supplier::with('creator:id,name')->findOrFail($id);
    }

    public function create(array $data): Supplier
    {
        return DB::transaction(function () use ($data) {
            $data = array_merge($data, $this->extractDocuments($data));
            $data['created_by'] = Auth::id();

            return Supplier::create($data);
        });
    }

    public function update(Supplier $supplier, array $data): Supplier
    {
        return DB::transaction(function () use ($supplier, $data) {
            $newDocs = $this->extractDocuments($data);

            $oldDocs = [];
            foreach (self::DOCUMENT_FIELDS as $field) {
                if (array_key_exists($field, $newDocs) && $supplier->{$field}) {
                    $oldDocs[] = $supplier->{$field};
                }
            }

            $supplier->update(array_merge($data, $newDocs));

            // Delete replaced files only after the DB write succeeds
            foreach ($oldDocs as $path) {
                $this->deleteFile($path);
            }

            return $supplier->fresh(['creator:id,name']);
        });
    }

    public function delete(Supplier $supplier): void
    {
        if ($supplier->stockInwards()->exists()) {
            throw ValidationException::withMessages([
                'supplier' => 'Cannot delete supplier with existing stock inward records.',
            ]);
        }

        DB::transaction(function () use ($supplier) {
            $docs = [];
            foreach (self::DOCUMENT_FIELDS as $field) {
                if ($supplier->{$field}) {
                    $docs[] = $supplier->{$field};
                }
            }

            $supplier->delete();

            foreach ($docs as $path) {
                $this->deleteFile($path);
            }
        });
    }

    public function toggleActive(Supplier $supplier): Supplier
    {
        $supplier->update(['is_active' => ! $supplier->is_active]);

        return $supplier->fresh();
    }

    /**
     * Extract uploaded files, store them on the tenant-scoped disk,
     * and return a [field => path] map. File keys are removed from $data
     * so the raw UploadedFile never reaches the DB layer.
     */
    private function extractDocuments(array $data): array
    {
        $paths = [];
        $dir = $this->storageDir();

        foreach (self::DOCUMENT_FIELDS as $field) {
            $value = $data[$field] ?? null;
            unset($data[$field]);

            if ($value instanceof UploadedFile) {
                $paths[$field] = $value->store($dir, 'public');
            }
        }

        return $paths;
    }

    /**
     * Tenant-scoped directory — keeps each tenant's supplier documents
     * isolated from every other tenant, matching CategoryService's
     * `tenants/{id}/...` convention.
     */
    private function storageDir(): string
    {
        $tenantId = tenant('id');

        if (! $tenantId) {
            throw new \RuntimeException('Tenant context required for supplier document upload.');
        }

        return "tenants/{$tenantId}/suppliers/documents";
    }

    private function deleteFile(string $path): void
    {
        Storage::disk('public')->delete($path);
    }
}
