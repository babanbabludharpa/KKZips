<?php

namespace App\Services\V1\Masters;

use App\Models\PriceSchedule;
use App\Models\ProductVariant;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PriceScheduleService
{
    public function getAllForVariant(ProductVariant $variant, array $filters = []): LengthAwarePaginator
    {
        return $variant->priceSchedules()
            ->when($filters['status'] ?? null, fn ($q, $s) => $q->where('status', $s))
            ->latest('effective_from')
            ->paginate($filters['per_page'] ?? 15);
    }

    public function create(ProductVariant $variant, array $data, int $userId): PriceSchedule
    {
        $this->guardFutureDate($data['effective_from']);
        $this->guardNoDuplicatePendingDate($variant, $data['effective_from']);

        return $variant->priceSchedules()->create([
            'mrp' => $data['mrp'] ?? null,
            'selling_price' => $data['selling_price'] ?? null,
            'purchase_price' => $data['purchase_price'] ?? null,
            'effective_from' => $data['effective_from'],
            'status' => 'pending',
            'created_by' => $userId,
        ]);
    }

    public function update(PriceSchedule $schedule, array $data): PriceSchedule
    {
        $this->guardEditable($schedule);

        if (isset($data['effective_from'])) {
            $this->guardFutureDate($data['effective_from']);
            $this->guardNoDuplicatePendingDate(
                $schedule->variant,
                $data['effective_from'],
                $schedule->id
            );
        }

        $schedule->update(array_filter([
            'mrp' => $data['mrp'] ?? null,
            'selling_price' => $data['selling_price'] ?? null,
            'purchase_price' => $data['purchase_price'] ?? null,
            'effective_from' => $data['effective_from'] ?? null,
        ], fn ($v) => $v !== null));

        return $schedule->fresh();
    }

    public function cancel(PriceSchedule $schedule): PriceSchedule
    {
        $this->guardEditable($schedule);
        $schedule->update(['status' => 'cancelled']);

        return $schedule->fresh();
    }

    /**
     * Called by the daily cron command. Applies all pending schedules
     * whose effective_from date has arrived, updating the variant's
     * live price columns and marking the schedule as applied.
     *
     * With the duplicate-date guard in place, no two pending schedules
     * for the same variant share an effective_from — so if the cron
     * runs on a date that matches multiple schedules across different
     * variants, each variant gets exactly one schedule applied per run.
     */
    public function applyDueSchedules(): int
    {
        $appliedCount = 0;

        $dueSchedules = PriceSchedule::where('status', 'pending')
            ->whereDate('effective_from', '<=', now()->toDateString())
            ->orderBy('effective_from')          // oldest first, deterministic
            ->orderBy('id')
            ->get();

        foreach ($dueSchedules as $schedule) {
            DB::transaction(function () use ($schedule, &$appliedCount) {
                $variant = ProductVariant::lockForUpdate()->find($schedule->product_variant_id);
                if (! $variant) {
                    return;
                }

                $variant->update(array_filter([
                    'mrp' => $schedule->mrp,
                    'selling_price' => $schedule->selling_price,
                    'purchase_price' => $schedule->purchase_price,
                ], fn ($v) => $v !== null));

                $schedule->update(['status' => 'applied']);
                $appliedCount++;
            });
        }

        return $appliedCount;
    }

    /**
     * Rejects a new pending schedule that shares its effective_from date
     * with another pending schedule for the same variant. Two schedules
     * on the same date would apply in arbitrary order during the cron run
     * and the last one would silently win — that's the exact ambiguity
     * this guard prevents.
     */
    private function guardNoDuplicatePendingDate(
        ProductVariant $variant,
        string $effectiveFrom,
        ?int $excludeId = null
    ): void {
        $query = $variant->priceSchedules()
            ->where('status', 'pending')
            ->whereDate('effective_from', $effectiveFrom);

        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        if ($query->exists()) {
            throw ValidationException::withMessages([
                'effective_from' => 'Another pending price change is already scheduled for this exact date. Pick a different effective date.',
            ]);
        }
    }

    private function guardFutureDate(string $date): void
    {
        if (now()->toDateString() > $date) {
            throw ValidationException::withMessages([
                'effective_from' => 'Effective date cannot be in the past.',
            ]);
        }
    }

    private function guardEditable(PriceSchedule $schedule): void
    {
        if ($schedule->status !== 'pending') {
            throw ValidationException::withMessages([
                'price_schedule' => 'Only pending schedules can be edited or cancelled.',
            ]);
        }
    }
}
