<?php

namespace App\Services\V1\Masters;

use App\Models\City;
use Illuminate\Pagination\LengthAwarePaginator;

class CityService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'name' => 'cities.name',
        'is_active' => 'cities.is_active',
        'created_at' => 'cities.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 10;

    private const MAX_PAGE_SIZE = 100;

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

        $query = City::with('state');

        if (! empty($filters['search'])) {
            $query->where('cities.name', 'like', '%'.$filters['search'].'%');
        }

        if (! empty($filters['state_id'])) {
            $query->where('cities.state_id', $filters['state_id']);
        }

        if (isset($filters['is_active'])) {
            $query->where('cities.is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        // ── Sorting ──
        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'cities.name') {
                $query->orderBy('cities.name', 'asc');
            }
            $query->orderByDesc('cities.id');
        } else {
            // Default — alphabetical by name (unchanged behavior)
            $query->orderBy('cities.name');
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): City
    {
        return City::with('state')->findOrFail($id);
    }

    public function create(array $data): City
    {
        $this->checkDuplicate($data['state_id'], $data['name']);

        return City::create([
            'state_id' => $data['state_id'],
            'name' => trim($data['name']),
            'is_active' => $data['is_active'] ?? true,
        ]);
    }

    public function update(City $city, array $data): City
    {
        if (isset($data['name']) || isset($data['state_id'])) {
            $stateId = $data['state_id'] ?? $city->state_id;
            $name = isset($data['name']) ? trim($data['name']) : $city->name;

            if ($name !== $city->name || $stateId !== $city->state_id) {
                $this->checkDuplicate($stateId, $name, $city->id);
            }
        }

        $city->update([
            'state_id' => $data['state_id'] ?? $city->state_id,
            'name' => isset($data['name']) ? trim($data['name']) : $city->name,
            'is_active' => $data['is_active'] ?? $city->is_active,
        ]);

        return $city->fresh('state');
    }

    public function delete(City $city): void
    {
        // Future: check if city is used in suppliers/customers before deleting
        $city->delete();
    }

    public function toggleActive(City $city): City
    {
        $city->update(['is_active' => ! $city->is_active]);

        return $city->fresh('state');
    }

    private function checkDuplicate(int $stateId, string $name, ?int $excludeId = null): void
    {
        $query = City::where('state_id', $stateId)
            ->whereRaw('LOWER(name) = ?', [strtolower(trim($name))]);

        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        if ($query->exists()) {
            abort(422, "City '{$name}' already exists in this state.");
        }
    }
}
