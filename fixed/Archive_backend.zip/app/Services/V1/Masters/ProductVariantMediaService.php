<?php

namespace App\Services\V1\Masters;

use App\Models\ProductVariant;
use App\Models\ProductVariantMedia;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Variant media gallery (multiple images + videos per variant).
 *
 * Storage follows the existing single-image convention
 * (ProductVariantService::uploadImage): files are stored in
 * tenants/{tenantId}/variants/ and ONLY the filename is kept in the
 * DB — ProductVariantMedia::getUrlAttribute() rebuilds the public URL.
 */
class ProductVariantMediaService
{
    /** Max images per variant — keep in sync with VariantMediaSection.jsx (IMAGE_LIMIT). */
    public const MAX_IMAGES = 4;

    /** Max videos per variant — keep in sync with VariantMediaSection.jsx (VIDEO_LIMIT). */
    public const MAX_VIDEOS = 2;

    /**
     * Media files get this prefix so the legacy `image` column bridge can
     * tell media-mirrored files apart from old `variant_{id}_{timestamp}`
     * uploads made through the legacy single-image endpoint.
     */
    private const FILE_PREFIX = 'vmedia_';

    public function list(ProductVariant $variant): Collection
    {
        return $variant->media()->get();
    }

    public function add(ProductVariant $variant, UploadedFile $file, string $type): ProductVariantMedia
    {
        $this->guardTypeLimit($variant, $type);

        $tenantId = tenant('id');
        $folder = "tenants/{$tenantId}/variants";

        $extension = strtolower($file->getClientOriginalExtension() ?: 'bin');
        $filename = self::FILE_PREFIX.$variant->id.'_'.time().'_'.strtoupper(Str::random(6)).'.'.$extension;

        $file->storeAs($folder, $filename, 'public');

        return DB::transaction(function () use ($variant, $file, $type, $filename) {
            // New media is appended to the END of its type's queue
            // (sort_order gaps of 10 keep manual reordering cheap).
            $nextOrder = ((int) $variant->media()->where('type', $type)->max('sort_order')) + 10;

            $media = ProductVariantMedia::create([
                'product_variant_id' => $variant->id,
                'type' => $type,
                'path' => $filename,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize(),
                'sort_order' => $nextOrder,
            ]);

            $this->syncLegacyImage($variant);

            return $media;
        });
    }

    /**
     * Apply an explicit id order. Ids that do not belong to this variant
     * are ignored; media rows not present in $ids keep their current
     * sort_order (the UI sends image ids only).
     */
    public function reorder(ProductVariant $variant, array $ids): void
    {
        DB::transaction(function () use ($variant, $ids) {
            $order = 10;

            foreach (array_values($ids) as $id) {
                $variant->media()
                    ->where('id', $id)
                    ->update(['sort_order' => $order]);

                $order += 10;
            }

            $this->syncLegacyImage($variant);
        });
    }

    public function remove(ProductVariantMedia $media): void
    {
        $variant = $media->variant;

        DB::transaction(function () use ($media, $variant) {
            $media->delete();

            $this->syncLegacyImage($variant);
        });

        // Delete the file only after the row is safely gone.
        $tenantId = tenant('id');
        Storage::disk('public')->delete("tenants/{$tenantId}/variants/{$media->path}");
    }

    /**
     * ★ Legacy bridge — keep the old `image` column (still consumed as
     * `image_url` by the mobile app and every existing UI) pointing at
     * the FIRST image in the gallery. Never touches files uploaded via
     * the legacy single-image flow unless media gallery images exist.
     */
    private function syncLegacyImage(ProductVariant $variant): void
    {
        $first = $variant->media()
            ->where('type', 'image')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->first();

        if ($first) {
            if ($variant->image !== $first->path) {
                $variant->update(['image' => $first->path]);
            }

            return;
        }

        // No gallery images left — clear the legacy column ONLY if it holds
        // a media-mirrored file; images uploaded the old way are untouched.
        if ($variant->image && str_starts_with($variant->image, self::FILE_PREFIX)) {
            $variant->update(['image' => null]);
        }
    }

    private function guardTypeLimit(ProductVariant $variant, string $type): void
    {
        $limit = $type === 'image' ? self::MAX_IMAGES : self::MAX_VIDEOS;
        $count = $variant->media()->where('type', $type)->count();

        if ($count >= $limit) {
            $kind = $type === 'image' ? 'images' : 'videos';

            throw ValidationException::withMessages([
                'type' => "A variant can have at most {$limit} {$kind}.",
            ]);
        }
    }
}
