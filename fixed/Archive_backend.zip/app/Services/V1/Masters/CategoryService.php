<?php

namespace App\Services\V1\Masters;

use App\Models\Category;
use Illuminate\Http\UploadedFile;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class CategoryService
{
    /**
     * Whitelist of sortable UI keys -> real DB columns.
     * Anything not in this map falls back to the default sort.
     */
    private const SORTABLE = [
        'name' => 'categories.name',
        'is_active' => 'categories.is_active',
        'created_at' => 'categories.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 15;

    private const MIN_PAGE_SIZE = 10;

    private const MAX_PAGE_SIZE = 500;

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $query = Category::query()
            ->when($filters['search'] ?? null, fn ($q, $s) => $q->where('name', 'like', "%{$s}%")
            )
            ->when(isset($filters['is_active']), fn ($q) => $q->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN))
            );

        // ── Sorting ──
        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'categories.created_at') {
                $query->orderByDesc('categories.created_at');
            }
            $query->orderByDesc('categories.id');
        } else {
            // Default — newest first (matches original ->latest() behavior)
            $query->orderByDesc('categories.created_at');
        }

        return $query->paginate($perPage);
    }

    public function create(array $data): Category
    {
        $this->guardDuplicateName($data['name']);

        if (isset($data['image']) && $data['image'] instanceof UploadedFile) {
            // Tenant-scoped path — matches the pattern used for product
            // variant images (ProductVariantResource) — so files from
            // different tenants never land in the same shared folder,
            // and it's obvious from the path alone which tenant a given
            // image file belongs to.
            $data['image'] = $data['image']->store('tenants/'.tenant('id').'/categories', 'public');
        } else {
            unset($data['image']); // no file sent — don't write a null/junk value over the column
        }

        return Category::create($data);
    }

    public function update(Category $category, array $data): Category
    {
        if (isset($data['name']) && $data['name'] !== $category->name) {
            $this->guardDuplicateName($data['name'], $category->id);
        }

        if (isset($data['image']) && $data['image'] instanceof UploadedFile) {
            // Delete the old file BEFORE storing the new one, or it's an
            // orphaned file in storage/app/public/tenants/{id}/categories forever.
            if ($category->image) {
                Storage::disk('public')->delete($category->image);
            }
            $data['image'] = $data['image']->store('tenants/'.tenant('id').'/categories', 'public');
        } else {
            // Editing name/description without re-uploading an image must
            // NOT wipe the existing image — drop the key entirely rather
            // than letting a null overwrite it.
            unset($data['image']);
        }

        $category->update($data);

        return $category->fresh();
    }

    public function delete(Category $category): void
    {
        // Guard: block if products exist under this category
        if ($category->products()->exists()) {
            throw ValidationException::withMessages([
                'category' => 'Cannot delete category with products assigned to it.',
            ]);
        }

        // Image file cleanup intentionally lives on the model's
        // forceDeleted hook, not here — this is a soft delete.
        $category->delete();
    }

    public function toggleActive(Category $category): Category
    {
        $category->update(['is_active' => ! $category->is_active]);

        return $category->fresh();
    }

    private function guardDuplicateName(string $name, ?int $excludeId = null): void
    {
        $exists = Category::where('name', $name)
            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'name' => 'A category with this name already exists.',
            ]);
        }
    }
}
