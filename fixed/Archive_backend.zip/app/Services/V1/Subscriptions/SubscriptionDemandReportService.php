<?php

namespace App\Services\V1\Subscriptions;

use App\Models\RecurringUnavailableDay;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Models\SubscriptionPause;
use App\Models\TenantHoliday;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class SubscriptionDemandReportService
{
    public function forDate(
        Carbon $date,
        ?int $branchId = null,
        ?int $zoneId = null,
        ?int $slotId = null,
        ?int $categoryId = null,
    ): array {
        $existingCount = SubscriptionOccurrence::whereDate('occurrence_date', $date)
            ->when($branchId, fn ($q, $v) => $q->where('branch_id', $v))
            ->count();

        return $existingCount > 0
            ? $this->fromExistingOccurrences($date, $branchId, $zoneId, $slotId, $categoryId)
            : $this->projected($date, $branchId, $zoneId, $slotId, $categoryId);
    }

    protected function fromExistingOccurrences(
        Carbon $date,
        ?int $branchId,
        ?int $zoneId,
        ?int $slotId,
        ?int $categoryId,
    ): array {
        $occurrences = SubscriptionOccurrence::whereDate('occurrence_date', $date)
            ->whereIn('status', ['scheduled', 'assigned', 'out_for_delivery', 'delivered'])
            ->with([
                'subscriptionItem.slot',
                'subscriptionItem.productVariant.product.category',
                'subscriptionItem.subscription.branch',
                'subscriptionItem.subscription.deliveryAddress.zone',
            ])
            ->when($branchId, fn ($q, $v) => $q->whereHas(
                'subscriptionItem.subscription',
                fn ($sq) => $sq->where('branch_id', $v)
            ))
            ->when($zoneId, fn ($q, $v) => $q->whereHas(
                'subscriptionItem.subscription.deliveryAddress',
                fn ($aq) => $aq->where('zone_id', $v)
            ))
            ->when($slotId, fn ($q, $v) => $q->whereHas(
                'subscriptionItem',
                fn ($iq) => $iq->where('slot_id', $v)
            ))
            ->when($categoryId, fn ($q, $v) => $q->whereHas(
                'subscriptionItem.productVariant.product',
                fn ($pq) => $pq->where('category_id', $v)
            ))
            ->get();

        return $this->aggregate($occurrences->map(fn ($occ) => [
            'variant' => $occ->subscriptionItem->productVariant,
            'branch' => $occ->subscriptionItem->subscription->branch,
            'zone' => $occ->subscriptionItem->subscription->deliveryAddress?->zone,
            'slot' => $occ->subscriptionItem->slot,
            'qty' => $occ->qty,
        ]), 'generated');
    }

    protected function projected(
        Carbon $date,
        ?int $branchId,
        ?int $zoneId,
        ?int $slotId,
        ?int $categoryId,
    ): array {
        $items = $this->projectableItems($branchId, $zoneId, $slotId, $categoryId);
        $context = $this->buildSkipContext($date);

        $rows = collect();

        foreach ($items as $item) {
            if ($this->shouldSkip($item, $date, $context)) {
                continue;
            }

            $rows->push([
                'variant' => $item->productVariant,
                'branch' => $item->subscription->branch,
                'zone' => $item->subscription->deliveryAddress?->zone,
                'slot' => $item->slot,
                'qty' => $item->resolveQtyForDate($date),
            ]);
        }

        return $this->aggregate($rows, 'projected');
    }

    private function projectableItems(
        ?int $branchId,
        ?int $zoneId,
        ?int $slotId,
        ?int $categoryId,
    ): Collection {
        return SubscriptionItem::where('status', 'active')
            ->with([
                'slot',
                'productVariant.product.category',
                'subscription.branch',
                'subscription.deliveryAddress.zone',
            ])
            ->whereHas('subscription', function ($q) use ($branchId) {
                $q->where('status', 'active');
                if ($branchId) {
                    $q->where('branch_id', $branchId);
                }
            })
            ->when($zoneId, fn ($q, $v) => $q->whereHas(
                'subscription.deliveryAddress',
                fn ($aq) => $aq->where('zone_id', $v)
            ))
            ->when($slotId, fn ($q, $v) => $q->where('slot_id', $v))
            ->when($categoryId, fn ($q, $v) => $q->whereHas(
                'productVariant.product',
                fn ($pq) => $pq->where('category_id', $v)
            ))
            ->get();
    }

    private function buildSkipContext(Carbon $date): array
    {
        return [
            'weekly_off' => RecurringUnavailableDay::where('day_of_week', $date->dayOfWeek)->get(),
            'holiday' => TenantHoliday::whereDate('date', $date)->exists(),
        ];
    }

    private function shouldSkip(SubscriptionItem $item, Carbon $date, array $context): bool
    {
        if ($this->outsideSubscriptionWindow($item, $date) || ! $item->runsOn($date)) {
            return true;
        }
        if ($context['holiday'] || $this->matchesWeeklyOff($item, $context['weekly_off'])) {
            return true;
        }
        return $this->isPaused($item, $date);
    }

    private function outsideSubscriptionWindow(SubscriptionItem $item, Carbon $date): bool
    {
        if ($item->subscription->start_date && $date->lt($item->subscription->start_date)) {
            return true;
        }
        return $item->subscription->end_date && $date->gt($item->subscription->end_date);
    }

    private function matchesWeeklyOff(SubscriptionItem $item, Collection $weeklyOff): bool
    {
        return $weeklyOff->contains(fn ($w) => $w->slot_id === $item->slot_id);
    }

    private function isPaused(SubscriptionItem $item, Carbon $date): bool
    {
        return SubscriptionPause::where('subscription_item_id', $item->id)
            ->covering($date)
            ->exists();
    }

    protected function aggregate(Collection $rows, string $source): array
    {
        // Grain: variant + branch + zone + slot. Two rows that differ in any
        // of these become separate lines so the kitchen can prep per
        // branch-zone-slot, not just per branch.
        $grouped = $rows->groupBy(function ($r) {
            $variantId = $r['variant']->id ?? 0;
            $branchId  = $r['branch']->id ?? 0;
            $zoneId    = $r['zone']->id ?? 0;
            $slotId    = $r['slot']->id ?? 0;
            return "{$variantId}|{$branchId}|{$zoneId}|{$slotId}";
        });

        $result = $grouped->map(function ($group) {
            $first = $group->first();

            return [
                'product_name' => $first['variant']->product->name ?? 'Unknown',
                'variant_sku' => $first['variant']->sku,
                'category_name' => $first['variant']->product?->category?->name,
                'branch_name' => $first['branch']->name ?? 'Unknown',
                'branch_id' => $first['branch']->id ?? null,
                'zone_name' => $first['zone']->name ?? null,
                'zone_id' => $first['zone']->id ?? null,
                'slot_name' => $first['slot']->name ?? null,
                'slot_id' => $first['slot']->id ?? null,
                'slot_start_time' => $first['slot'] ? substr($first['slot']->start_time, 0, 5) : null,
                'slot_end_time' => $first['slot'] ? substr($first['slot']->end_time, 0, 5) : null,
                'total_qty' => $group->sum('qty'),
                'delivery_count' => $group->count(),
            ];
        })->values();

        return [
            'source' => $source,
            'rows' => $result,
            'grand_total_qty' => $result->sum('total_qty'),
            'grand_total_deliveries' => $result->sum('delivery_count'),
        ];
    }
}
