<?php

namespace App\Services\V1\Subscriptions;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class InvoiceNumberService
{
    /**
     * Must be called from inside an existing DB::transaction() —
     * relies on the caller's transaction for atomicity, same pattern
     * as OrderNumberService::next().
     */
    public function next(int $branchId, string $branchCode): string
    {
        $fy = $this->currentFinancialYear();

        DB::table('invoice_number_sequences')->insertOrIgnore([
            'branch_id' => $branchId,
            'financial_year' => $fy,
            'last_number' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $row = DB::table('invoice_number_sequences')
            ->where('branch_id', $branchId)
            ->where('financial_year', $fy)
            ->lockForUpdate()
            ->first();

        $next = $row->last_number + 1;

        DB::table('invoice_number_sequences')
            ->where('branch_id', $branchId)
            ->where('financial_year', $fy)
            ->update(['last_number' => $next, 'updated_at' => now()]);

        $sequence = str_pad((string) $next, 6, '0', STR_PAD_LEFT);

        return "{$branchCode}-{$fy}-{$sequence}";
    }

    public function currentFinancialYear(): string
    {
        $now = Carbon::now();
        $year = $now->year;

        $startYear = $now->month >= 4 ? $year : $year - 1;
        $endYear = $startYear + 1;

        return substr((string) $startYear, -2).substr((string) $endYear, -2);
    }
}
