<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Models\SubscriptionPause;
use App\Models\SubscriptionQtyOverride;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SubscriptionQtyOverrideService
{
    private const MSG_ITEM_INACTIVE = 'This subscription item is not active, so its schedule cannot be changed.';
    private const MSG_OVERLAPPING_PAUSE = 'This date range is already paused. Resume it first, or choose different dates.';

    public function __construct(protected SubscriptionActivityLogService $activityLog) {}

    public function create(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo, int $qty, string $initiatedBy, ?int $actorId, ?string $reason = null): SubscriptionQtyOverride
    {
        $request = new SubscriptionQtyOverrideRequest(
            item: $item,
            dateFrom: $dateFrom,
            dateTo: $dateTo,
            qty: $qty,
            initiatedBy: $initiatedBy,
            actorId: $actorId,
            reason: $reason,
        );

        $this->assertCanCreate($request);

        $bypassesLock = SubscriptionOccurrence::actorBypassesCutoffLock($request->initiatedBy);

        if (! $bypassesLock) {
            $this->assertRangeNotLocked($request->dateFrom, $request->dateTo);
        }

        return DB::transaction(function () use ($request, $bypassesLock) {
            $override = $this->persistOverride($request);
            $oldQtySample = $this->applyQtyToOccurrences($request, $bypassesLock);
            $this->logQtyChange($request, $oldQtySample);

            return $override;
        });
    }

    private function assertCanCreate(SubscriptionQtyOverrideRequest $request): void
    {
        if ($request->item->status !== 'active') {
            throw ValidationException::withMessages(['item' => self::MSG_ITEM_INACTIVE]);
        }

        $hasOverlappingPause = SubscriptionPause::where('subscription_item_id', $request->item->id)
            ->where('date_from', '<=', $request->dateTo->toDateString())
            ->where('date_to', '>=', $request->dateFrom->toDateString())
            ->exists();

        if ($hasOverlappingPause) {
            throw ValidationException::withMessages(['date_from' => self::MSG_OVERLAPPING_PAUSE]);
        }
    }

    private function assertRangeNotLocked(Carbon $dateFrom, Carbon $dateTo): void
    {
        foreach (CarbonPeriod::create($dateFrom, $dateTo) as $date) {
            if (SubscriptionOccurrence::isDateLocked($date)) {
                throw ValidationException::withMessages([
                    'date_from' => "Cannot change quantity for {$date->toDateString()} - it's already locked (past the cutoff for tomorrow, or today/earlier).",
                ]);
            }
        }
    }

    private function persistOverride(SubscriptionQtyOverrideRequest $request): SubscriptionQtyOverride
    {
        return SubscriptionQtyOverride::create([
            'subscription_item_id' => $request->item->id,
            'date_from' => $request->dateFrom->toDateString(),
            'date_to' => $request->dateTo->toDateString(),
            'qty' => $request->qty,
            'initiated_by' => $request->initiatedBy,
            'reason' => $request->reason,
        ]);
    }

    private function applyQtyToOccurrences(SubscriptionQtyOverrideRequest $request, bool $bypassesLock): ?int
    {
        $oldQtySample = null;

        SubscriptionOccurrence::where('subscription_item_id', $request->item->id)
            ->whereBetween('occurrence_date', [$request->dateFrom->toDateString(), $request->dateTo->toDateString()])
            ->where('status', 'scheduled')
            ->get()
            ->each(function ($occurrence) use ($request, $bypassesLock, &$oldQtySample) {
                if ($bypassesLock || ! $occurrence->isLocked()) {
                    $oldQtySample ??= $occurrence->qty;
                    $occurrence->update(['qty' => $request->qty]);
                }
            });

        return $oldQtySample;
    }

    private function logQtyChange(SubscriptionQtyOverrideRequest $request, ?int $oldQtySample): void
    {
        $this->activityLog->logForItem(
            $request->item,
            'qty_changed',
            $request->initiatedBy === 'admin' ? 'admin' : 'customer',
            $request->actorId,
            "Changed quantity to {$request->qty} for ".$this->formatDateRange($request->dateFrom, $request->dateTo).($oldQtySample ? " (was {$oldQtySample})" : ''),
            $request->dateFrom->toDateString(),
            ['date_from' => $request->dateFrom->toDateString(), 'date_to' => $request->dateTo->toDateString(), 'new_qty' => $request->qty, 'old_qty' => $oldQtySample, 'reason' => $request->reason],
        );
    }

    private function formatDateRange(Carbon $from, Carbon $to): string
    {
        return $from->equalTo($to)
            ? $from->toDateString()
            : "{$from->toDateString()} to {$to->toDateString()}";
    }
}
