<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;

/**
 * Groups the parameters for DeliveryConfirmationService::submitOne().
 * Reduces submitOne() from 8 parameters to 1 (SonarQube php:S107).
 */
final class DeliveryConfirmationRequest
{
    public function __construct(
        public readonly DeliveryAssignment $assignment,
        public readonly bool $delivered,
        public readonly ?string $reason,
        public readonly ?string $note,
        public readonly float $lat,
        public readonly float $lng,
        public readonly ?string $photoPath,
        public readonly int $submittedBy,
    ) {}
}
