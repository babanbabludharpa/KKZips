<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;
use App\Models\Inventory;
use App\Models\StockMovement;
use App\Models\SubscriptionOccurrence;
use App\Models\TenantProfile;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DeliveryConfirmationService
{
    protected const VALID_REASONS = [
        'customer_unavailable', 'customer_refused', 'stockout',
        'vehicle_breakdown', 'address_not_found', 'other',
    ];

    public function __construct(
        protected DeliveryBoyAssignmentService $engine,
    ) {}

    public function submit(array $results, int $submittedBy, ?float $lat = null, ?float $lng = null): void
    {
        $stockCheckEnabled = (bool) (TenantProfile::first()?->subscription_stock_check_enabled ?? true);

        DB::transaction(function () use ($results, $submittedBy, $lat, $lng, $stockCheckEnabled) {
            foreach ($results as $assignmentId => $result) {
                $assignment = DeliveryAssignment::with('occurrence.subscriptionItem')
                    ->lockForUpdate()
                    ->findOrFail($assignmentId);

                $context = new DeliveryConfirmationContext(
                    assignment: $assignment,
                    occurrence: $assignment->occurrence,
                    variantId: $assignment->occurrence->subscriptionItem->product_variant_id,
                    branchId: $assignment->occurrence->subscriptionItem->subscription->branch_id,
                    submittedBy: $submittedBy,
                    stockCheckEnabled: $stockCheckEnabled,
                    lat: $lat,
                    lng: $lng,
                );

                if ($result['delivered']) {
                    $this->markDelivered($context, $result['note'] ?? null);
                } else {
                    $this->markNotDelivered($context, $result['reason'] ?? null, $result['note'] ?? null);
                }
            }
        });
    }

    public function submitOne(DeliveryConfirmationRequest $request): void
    {
        $stockCheckEnabled = (bool) (TenantProfile::first()?->subscription_stock_check_enabled ?? true);

        DB::transaction(function () use ($request, $stockCheckEnabled) {
            $locked = DeliveryAssignment::with('occurrence.subscriptionItem')
                ->lockForUpdate()
                ->findOrFail($request->assignment->id);

            $context = new DeliveryConfirmationContext(
                assignment: $locked,
                occurrence: $locked->occurrence,
                variantId: $locked->occurrence->subscriptionItem->product_variant_id,
                branchId: $locked->occurrence->subscriptionItem->subscription->branch_id,
                submittedBy: $request->submittedBy,
                stockCheckEnabled: $stockCheckEnabled,
                lat: $request->lat,
                lng: $request->lng,
            );

            if ($request->delivered) {
                $this->markDelivered($context, $request->note);

                if ($request->photoPath) {
                    $context->occurrence->update(['delivery_photo_path' => $request->photoPath]);
                }

                return;
            }

            if (! in_array($request->reason, self::VALID_REASONS, true)) {
                throw ValidationException::withMessages([
                    'reason' => 'A valid reason is required when marking a stop not delivered.',
                ]);
            }

            $this->markNotDelivered($context, $request->reason, $request->note);
        });
    }

    protected function markDelivered(DeliveryConfirmationContext $ctx, ?string $note = null): void
    {
        $qty = $ctx->occurrence->qty;

        $inventory = Inventory::where('product_variant_id', $ctx->variantId)
            ->where('branch_id', $ctx->branchId)
            ->lockForUpdate()
            ->firstOrFail();

        if ($ctx->stockCheckEnabled && $inventory->quantity < $qty) {
            throw ValidationException::withMessages([
                'quantity' => "Insufficient physical stock for this delivery (have {$inventory->quantity}, need {$qty}). Mark this stop as not delivered with reason 'stockout' instead.",
            ]);
        }

        $inventory->decrement('quantity', $qty);
        $inventory->decrement('quantity_reserved', min($qty, $inventory->quantity_reserved));

        StockMovement::create([
            'product_variant_id' => $ctx->variantId,
            'branch_id' => $ctx->branchId,
            'type' => 'subscription_delivery',
            'opening_stock' => $inventory->quantity + $qty,
            'in' => 0,
            'out' => $qty,
            'closing_stock' => $inventory->quantity,
            'transaction_date' => now()->toDateString(),
            'reference_id' => 'SUB-OCC-'.$ctx->occurrence->id,
            'created_by' => $ctx->submittedBy,
        ]);

        $ctx->occurrence->update([
            'status' => 'delivered',
            'delivered_at' => now(),
            'delivery_lat' => $ctx->lat,
            'delivery_lng' => $ctx->lng,
            'delivery_note' => $note,
        ]);

        $ctx->assignment->update(['status' => 'delivered']);

        // Best-effort: after the delivery transaction commits, assign the
        // next unassigned occurrence for the same subscription item. This
        // is what makes the engine "immediate after delivery", independent
        // of the hourly cron.
        $this->queueNextOccurrenceAssignment($ctx->occurrence);
    }

    protected function markNotDelivered(DeliveryConfirmationContext $ctx, ?string $reason, ?string $note = null): void
    {
        if (! in_array($reason, self::VALID_REASONS, true)) {
            throw ValidationException::withMessages([
                'reason' => 'A valid not_delivered_reason is required when deselecting a stop.',
            ]);
        }

        $inventory = Inventory::where('product_variant_id', $ctx->variantId)
            ->where('branch_id', $ctx->branchId)
            ->lockForUpdate()
            ->first();

        if ($inventory) {
            $inventory->decrementEach([
                'quantity_reserved' => min($ctx->occurrence->qty, $inventory->quantity_reserved),
            ]);
        }

        $ctx->occurrence->update([
            'status' => 'not_delivered',
            'not_delivered_reason' => $reason,
            'not_delivered_note' => $note,
            'delivery_lat' => $ctx->lat,
            'delivery_lng' => $ctx->lng,
        ]);

        $ctx->assignment->update(['status' => 'not_delivered']);
    }

    /**
     * After the delivery transaction commits, find the next unassigned
     * occurrence for the same subscription item and assign a rider.
     *
     * Runs outside the transaction because a failure to assign the next
     * occurrence must NOT roll back the successful delivery.
     *
     * If no next occurrence exists yet (the generator has not run), this
     * is a no-op. The hourly cron will catch it on the next pass.
     */
    private function queueNextOccurrenceAssignment(SubscriptionOccurrence $delivered): void
    {
        DB::afterCommit(function () use ($delivered) {
            $next = SubscriptionOccurrence::query()
                ->where('subscription_item_id', $delivered->subscription_item_id)
                ->whereDate('occurrence_date', '>', $delivered->occurrence_date->toDateString())
                ->where('status', 'scheduled')
                ->whereNull('delivery_boy_id')
                ->whereNull('invoice_id')
                ->with(['subscriptionItem.subscription.deliveryAddress'])
                ->orderBy('occurrence_date')
                ->first();

            if (! $next) {
                return;
            }

            try {
                $this->engine->assignOccurrence($next);
            } catch (\Throwable $e) {
                // Delivery is already committed. Do not fail it because of
                // the next-occurrence assignment. Log and move on; the
                // hourly cron will retry.
                \Log::error('Post-delivery next-occurrence assignment failed', [
                    'delivered_occurrence_id' => $delivered->id,
                    'next_occurrence_id' => $next->id,
                    'error' => $e->getMessage(),
                ]);
            }
        });
    }
}
