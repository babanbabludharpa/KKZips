<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionActivityLog;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class SubscriptionActivityReportService
{
    private const DEFAULT_PAGE_SIZE = 25;

    private const MAX_PAGE_SIZE = 100;

    private const MIN_PAGE_SIZE = 10;

    /**
     * Whitelist of sortable columns -> actual DB column.
     * Anything not in this map is ignored — prevents SQL injection via ?sort=
     */
    private const SORTABLE = [
        'created_at' => 'subscription_activity_logs.created_at',
        'occurrence_date' => 'subscription_activity_logs.occurrence_date',
        'event_type' => 'subscription_activity_logs.event_type',
        'actor_type' => 'subscription_activity_logs.actor_type',
        'customer_name' => 'customers.name',
        'branch_name' => 'branches.name',
        'product_name' => 'products.name',
    ];

    private const DEFAULT_SORT = 'created_at';

    private const DEFAULT_SORT_DIR = 'desc';

    public function getReport(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $query = $this->baseQuery($filters);
        $this->applySort($query, $filters);

        return $query->paginate($perPage);
    }

    public function getForCustomer(int $customerId, array $filters = []): LengthAwarePaginator
    {
        $filters['customer_id'] = $customerId;

        return $this->getReport($filters);
    }

    public function getForExport(array $filters = []): Collection
    {
        $query = $this->baseQuery($filters);
        $this->applySort($query, $filters);

        return $query->get();
    }

    protected function applySort($query, array $filters): void
    {
        $key = $filters['sort_key'] ?? self::DEFAULT_SORT;
        $dir = strtolower($filters['sort_dir'] ?? self::DEFAULT_SORT_DIR) === 'asc' ? 'asc' : 'desc';

        $column = self::SORTABLE[$key] ?? self::SORTABLE[self::DEFAULT_SORT];

        // Secondary stable sort — prevents rows jumping between pages when
        // the primary value is tied (e.g. two events at the same second).
        $query->orderBy($column, $dir);

        if ($column !== 'subscription_activity_logs.created_at') {
            $query->orderByDesc('subscription_activity_logs.created_at');
        }
        $query->orderByDesc('subscription_activity_logs.id');
    }

    protected function baseQuery(array $filters)
    {
        return SubscriptionActivityLog::query()
            ->with(['subscription.customer', 'subscription.branch', 'subscriptionItem.productVariant.product'])
            // Sortable columns come from related tables — need explicit joins
            // for `orderBy` to reference `customers.name`, `branches.name`, `products.name`.
            ->leftJoin('subscriptions', 'subscription_activity_logs.subscription_id', '=', 'subscriptions.id')
            ->leftJoin('customers', 'subscriptions.customer_id', '=', 'customers.id')
            ->leftJoin('branches', 'subscriptions.branch_id', '=', 'branches.id')
            ->leftJoin('subscription_items', 'subscription_activity_logs.subscription_item_id', '=', 'subscription_items.id')
            ->leftJoin('product_variants', 'subscription_items.product_variant_id', '=', 'product_variants.id')
            ->leftJoin('products', 'product_variants.product_id', '=', 'products.id')
            ->select('subscription_activity_logs.*')
            ->when($filters['customer_id'] ?? null, fn ($q, $v) => $q->where('subscription_activity_logs.customer_id', $v))
            ->when($filters['subscription_id'] ?? null, fn ($q, $v) => $q->where('subscription_activity_logs.subscription_id', $v))
            ->when($filters['event_type'] ?? null, fn ($q, $v) => $q->where('subscription_activity_logs.event_type', $v))
            ->when($filters['actor_type'] ?? null, fn ($q, $v) => $q->where('subscription_activity_logs.actor_type', $v))
            ->when($filters['date_from'] ?? null, fn ($q, $v) => $q->whereDate('subscription_activity_logs.created_at', '>=', $v))
            ->when($filters['date_to'] ?? null, fn ($q, $v) => $q->whereDate('subscription_activity_logs.created_at', '<=', $v))
            ->when($filters['branch_id'] ?? null, fn ($q, $v) => $q->whereHas(
                'subscription',
                fn ($sq) => $sq->where('branch_id', $v)
            ));
    }
}
