<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;
use App\Models\DeliveryBoy;
use App\Models\SubscriptionOccurrence;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DeliveryBoyAssignmentService
{
    public function assignOccurrence(
        SubscriptionOccurrence $occurrence,
        ?int $suggestedRiderId = null,
    ): AssignmentResult {
        if ($occurrence->delivery_boy_id !== null && $suggestedRiderId === null) {
            return AssignmentResult::alreadyAssigned((int) $occurrence->delivery_boy_id);
        }

        $item = $occurrence->subscriptionItem;
        if (! $item) {
            return $this->logUnassigned($occurrence, 'Occurrence has no subscription item.', 'system_error');
        }

        $subscription = $item->subscription;
        if (! $subscription) {
            return $this->logUnassigned($occurrence, 'Occurrence has no subscription.', 'system_error');
        }

        $address = $subscription->deliveryAddress;
        if (! $address || $address->zone_id === null) {
            return $this->logUnassigned(
                $occurrence,
                'Customer address has no zone_id — cannot match a rider.',
                'zone_unresolved'
            );
        }

        $branchId       = (int) $subscription->branch_id;
        $zoneId         = (int) $address->zone_id;
        $slotId         = (int) $item->slot_id;
        $occurrenceDate = Carbon::parse($occurrence->occurrence_date)->toDateString();
        $dayOfWeek      = Carbon::parse($occurrenceDate)->dayOfWeek;

        if ($suggestedRiderId !== null) {
            $rider = DeliveryBoy::find($suggestedRiderId);
            if (! $rider) {
                return $this->logUnassigned(
                    $occurrence,
                    "Rider #{$suggestedRiderId} does not exist.",
                    'manual_choice',
                    $suggestedRiderId
                );
            }

            $eligibility = $this->checkRiderEligibility(
                $rider, $branchId, $zoneId, $slotId, $dayOfWeek, $occurrenceDate
            );

            if (! $eligibility['eligible']) {
                return $this->logUnassigned(
                    $occurrence,
                    "Rider #{$rider->id} ({$rider->name}) is not eligible: {$eligibility['reason']}",
                    'manual_choice',
                    $suggestedRiderId
                );
            }

            return $this->writeAssignment($occurrence, $rider, 'preferred', 'admin', null);
        }

        $standingRiderId = $subscription->delivery_boy_id;

        if ($standingRiderId !== null) {
            $standing = DeliveryBoy::find($standingRiderId);
            if ($standing) {
                $eligibility = $this->checkRiderEligibility(
                    $standing, $branchId, $zoneId, $slotId, $dayOfWeek, $occurrenceDate
                );

                if ($eligibility['eligible']) {
                    return $this->writeAssignment($occurrence, $standing, 'preferred', 'system', null);
                }

                $substitute = $this->pickBestEligibleRider(
                    $branchId, $zoneId, $slotId, $dayOfWeek, $occurrenceDate, $standingRiderId
                );

                if ($substitute) {
                    return $this->writeAssignment(
                        $occurrence, $substitute, 'substitute', 'system',
                        "Standing rider #{$standing->id} ({$standing->name}) unavailable: {$eligibility['reason']}"
                    );
                }

                return $this->logUnassigned(
                    $occurrence,
                    "No eligible rider. Standing rider #{$standing->id} unavailable: {$eligibility['reason']}. No substitute available.",
                    'substitute'
                );
            }
        }

        $best = $this->pickBestEligibleRider(
            $branchId, $zoneId, $slotId, $dayOfWeek, $occurrenceDate, null
        );

        if ($best) {
            return $this->writeAssignment($occurrence, $best, 'preferred', 'system', null);
        }

        return $this->logUnassigned(
            $occurrence,
            'No eligible rider. No standing rider on subscription, and no substitute available.',
            'best_available'
        );
    }

    public function assignForDate(Carbon $date, ?int $branchId = null): array
    {
        $counts = ['assigned' => 0, 'unassigned' => 0, 'failed' => 0, 'already' => 0];

        $alreadyQuery = SubscriptionOccurrence::query()
            ->whereDate('occurrence_date', $date->toDateString())
            ->whereIn('status', ['scheduled', 'assigned'])
            ->whereNotNull('delivery_boy_id');
        if ($branchId !== null) {
            $alreadyQuery->where('branch_id', $branchId);
        }
        $counts['already'] = (int) $alreadyQuery->count();

        $query = SubscriptionOccurrence::query()
            ->whereDate('occurrence_date', $date->toDateString())
            ->whereIn('status', ['scheduled', 'assigned'])
            ->whereNull('delivery_boy_id')
            ->with(['subscriptionItem.subscription.deliveryAddress'])
            ->orderBy('id');

        if ($branchId !== null) {
            $query->where('branch_id', $branchId);
        }

        $query->chunkById(200, function ($occurrences) use (&$counts) {
            foreach ($occurrences as $occurrence) {
                $result = $this->assignOccurrence($occurrence);
                $this->incrementCount($counts, $result);
            }
        });

        return $counts;
    }

    public function rebalanceForRider(
        int $riderId,
        Carbon $from,
        Carbon $to,
        ?int $slotId = null,
    ): array {
        $counts = ['assigned' => 0, 'unassigned' => 0, 'failed' => 0, 'already' => 0];

        $query = SubscriptionOccurrence::query()
            ->where('delivery_boy_id', $riderId)
            ->whereBetween('occurrence_date', [$from->toDateString(), $to->toDateString()])
            ->whereIn('status', ['scheduled', 'assigned'])
            ->orderBy('id');

        if ($slotId !== null) {
            $query->whereHas('subscriptionItem', function ($q) use ($slotId) {
                $q->where('slot_id', $slotId);
            });
        }

        $query->chunkById(200, function ($occurrences) use (&$counts) {
            foreach ($occurrences as $occurrence) {
                $occurrence->delivery_boy_id  = null;
                $occurrence->assignment_type  = null;
                $occurrence->assigned_by      = null;
                $occurrence->assigned_at      = null;
                // Roll back to 'scheduled' so the row correctly reflects
                // "not yet assigned" while rebalance is running.
                if ($occurrence->status === 'assigned') {
                    $occurrence->status = 'scheduled';
                }
                $occurrence->save();

                $fresh = $occurrence->fresh([
                    'subscriptionItem.subscription.deliveryAddress',
                ]);

                $result = $this->assignOccurrence($fresh);
                $this->incrementCount($counts, $result);
            }
        });

        return $counts;
    }

    public function manualReassign(
        SubscriptionOccurrence $occurrence,
        int $newRiderId,
        string $scope,
        int $actorId,
    ): array {
        $result = [
            'current' => null,
            'future_count' => 0,
            'future_failed' => 0,
        ];

        $occurrence->delivery_boy_id  = null;
        $occurrence->assignment_type  = null;
        $occurrence->assigned_by      = null;
        $occurrence->assigned_at      = null;
        if ($occurrence->status === 'assigned') {
            $occurrence->status = 'scheduled';
        }
        $occurrence->save();

        $occurrence = $occurrence->fresh([
            'subscriptionItem.subscription.deliveryAddress',
        ]);

        $result['current'] = $this->assignOccurrence($occurrence, $newRiderId);

        if (! $result['current']->isAssigned()) {
            return $result;
        }

        if ($scope !== 'this_and_future') {
            return $result;
        }

        $item = $occurrence->subscriptionItem;
        $subscription = $item->subscription;

        $subscription->update(['delivery_boy_id' => $newRiderId]);

        $future = SubscriptionOccurrence::query()
            ->where('subscription_item_id', $item->id)
            ->whereDate('occurrence_date', '>', Carbon::parse($occurrence->occurrence_date)->toDateString())
            ->whereIn('status', ['scheduled', 'assigned'])
            ->whereNull('invoice_id')
            ->orderBy('occurrence_date')
            ->get();

        foreach ($future as $futureOccurrence) {
            $futureOccurrence->delivery_boy_id  = null;
            $futureOccurrence->assignment_type  = null;
            $futureOccurrence->assigned_by      = null;
            $futureOccurrence->assigned_at      = null;
            if ($futureOccurrence->status === 'assigned') {
                $futureOccurrence->status = 'scheduled';
            }
            $futureOccurrence->save();

            $fresh = $futureOccurrence->fresh([
                'subscriptionItem.subscription.deliveryAddress',
            ]);

            $res = $this->assignOccurrence($fresh, $newRiderId);

            if ($res->status === AssignmentResult::STATUS_ASSIGNED) {
                $result['future_count']++;
            } else {
                $result['future_failed']++;
            }
        }

        return $result;
    }

    private function checkRiderEligibility(
        DeliveryBoy $rider,
        int $branchId,
        int $zoneId,
        int $slotId,
        int $dayOfWeek,
        string $occurrenceDate,
    ): array {
        if (! $rider->is_active) {
            return ['eligible' => false, 'reason' => 'rider is inactive'];
        }

        if ((int) $rider->branch_id !== $branchId) {
            return ['eligible' => false, 'reason' => 'rider is in a different branch'];
        }

        $coversZone = DB::table('delivery_boy_zones')
            ->where('delivery_boy_id', $rider->id)
            ->where('zone_id', $zoneId)
            ->exists();

        if (! $coversZone) {
            return ['eligible' => false, 'reason' => "rider does not cover zone #{$zoneId}"];
        }

        $slotMatches = DB::table('delivery_boy_slots')
            ->where('delivery_boy_id', $rider->id)
            ->where('slot_id', $slotId)
            ->where('day_of_week', $dayOfWeek)
            ->where('is_available', 1)
            ->exists();

        if (! $slotMatches) {
            return ['eligible' => false, 'reason' => 'rider is not available for this slot on this day'];
        }

        $onLeave = DB::table('delivery_boy_leaves')
            ->where('delivery_boy_id', $rider->id)
            ->whereNull('deleted_at')
            ->where('start_date', '<=', $occurrenceDate)
            ->where('end_date', '>=', $occurrenceDate)
            ->where(function ($q) use ($slotId) {
                $q->whereNull('slot_id')->orWhere('slot_id', $slotId);
            })
            ->exists();

        if ($onLeave) {
            return ['eligible' => false, 'reason' => 'rider is on leave'];
        }

        $currentLoad = $this->currentLoad($rider->id, $occurrenceDate);
        if ($currentLoad >= $rider->max_daily_deliveries) {
            return [
                'eligible' => false,
                'reason'   => "rider is at daily capacity ({$currentLoad}/{$rider->max_daily_deliveries})",
            ];
        }

        return ['eligible' => true, 'reason' => null];
    }

    private function pickBestEligibleRider(
        int $branchId,
        int $zoneId,
        int $slotId,
        int $dayOfWeek,
        string $occurrenceDate,
        ?int $excludeRiderId,
    ): ?DeliveryBoy {
        $riders = DeliveryBoy::query()
            ->where('is_active', 1)
            ->where('branch_id', $branchId)
            ->whereHas('zones', fn ($q) => $q->where('zone_id', $zoneId))
            ->whereHas('slots', function ($q) use ($slotId, $dayOfWeek) {
                $q->where('slot_id', $slotId)
                  ->where('day_of_week', $dayOfWeek)
                  ->where('is_available', 1);
            })
            ->whereDoesntHave('leaves', function ($q) use ($occurrenceDate, $slotId) {
                $q->where('start_date', '<=', $occurrenceDate)
                  ->where('end_date', '>=', $occurrenceDate)
                  ->where(function ($q2) use ($slotId) {
                      $q2->whereNull('slot_id')->orWhere('slot_id', $slotId);
                  });
            })
            ->when($excludeRiderId, fn ($q) => $q->where('id', '!=', $excludeRiderId))
            ->get();

        if ($riders->isEmpty()) {
            return null;
        }

        $loads = DB::table('subscription_occurrences')
            ->whereIn('delivery_boy_id', $riders->pluck('id'))
            ->whereDate('occurrence_date', $occurrenceDate)
            ->whereIn('status', ['scheduled', 'assigned', 'out_for_delivery', 'delivered'])
            ->select('delivery_boy_id', DB::raw('COUNT(*) as `load`'))
            ->groupBy('delivery_boy_id')
            ->pluck('load', 'delivery_boy_id');

        return $riders
            ->filter(fn ($r) => ($loads[$r->id] ?? 0) < $r->max_daily_deliveries)
            ->sortBy(fn ($r) => $loads[$r->id] ?? 0)
            ->first();
    }

    private function currentLoad(int $riderId, string $occurrenceDate): int
    {
        return (int) DB::table('subscription_occurrences')
            ->where('delivery_boy_id', $riderId)
            ->whereDate('occurrence_date', $occurrenceDate)
            ->whereIn('status', ['scheduled', 'assigned', 'out_for_delivery', 'delivered'])
            ->count();
    }

    private function writeAssignment(
        SubscriptionOccurrence $occurrence,
        DeliveryBoy $rider,
        string $assignmentType,
        string $assignedBy,
        ?string $logReason,
    ): AssignmentResult {
        $occurrence->delivery_boy_id = $rider->id;
        $occurrence->assignment_type = $assignmentType;
        $occurrence->assigned_by     = $assignedBy;
        $occurrence->assigned_at     = now();

        // Advance status from 'scheduled' to 'assigned'. Do not roll back
        // if the occurrence is already past 'scheduled' (delivered, etc.).
        if ($occurrence->status === 'scheduled') {
            $occurrence->status = 'assigned';
        }

        $occurrence->save();

        $existingPivot = DeliveryAssignment::where('subscription_occurrence_id', $occurrence->id)->first();

        if ($existingPivot) {
            if ((int) $existingPivot->delivery_boy_id !== (int) $rider->id) {
                $nextSequence = (int) (DeliveryAssignment::where('delivery_boy_id', $rider->id)
                    ->whereDate('occurrence_date', $occurrence->occurrence_date->toDateString())
                    ->max('sequence') ?? -1) + 1;

                $existingPivot->update([
                    'delivery_boy_id' => $rider->id,
                    'sequence'        => $nextSequence,
                    'status'          => 'pending',
                ]);
            }
        } else {
            $nextSequence = (int) (DeliveryAssignment::where('delivery_boy_id', $rider->id)
                ->whereDate('occurrence_date', $occurrence->occurrence_date->toDateString())
                ->max('sequence') ?? -1) + 1;

            DeliveryAssignment::create([
                'occurrence_date'            => $occurrence->occurrence_date->toDateString(),
                'delivery_boy_id'            => $rider->id,
                'subscription_occurrence_id' => $occurrence->id,
                'status'                     => 'pending',
                'sequence'                   => $nextSequence,
            ]);
        }

        $eventType = $assignmentType === 'substitute'
            ? 'rider_substituted'
            : 'rider_assigned';

        $description = match ($assignmentType) {
            'preferred'  => $assignedBy === 'admin'
                                ? "Admin assigned preferred rider {$rider->name}."
                                : "Assigned preferred rider {$rider->name}.",
            'substitute' => "Assigned substitute rider {$rider->name}."
                            . ($logReason ? " Reason: {$logReason}" : ''),
            default      => "Assigned rider {$rider->name}.",
        };

        DB::table('subscription_activity_logs')->insert([
            'subscription_id'      => $occurrence->subscriptionItem->subscription_id,
            'subscription_item_id' => $occurrence->subscription_item_id,
            'customer_id'          => $occurrence->subscriptionItem->subscription->customer_id,
            'event_type'           => $eventType,
            'actor_type'           => $assignedBy === 'admin' ? 'admin' : 'system',
            'actor_id'             => $assignedBy === 'admin' ? auth()->id() : null,
            'occurrence_date'      => $occurrence->occurrence_date,
            'description'          => $description,
            'metadata'             => json_encode([
                'occurrence_id'    => $occurrence->id,
                'delivery_boy_id'  => $rider->id,
                'assignment_type'  => $assignmentType,
                'reason'           => $logReason,
            ]),
            'created_at'           => now(),
            'updated_at'           => now(),
        ]);

        Log::info('Rider assignment', [
            'occurrence_id' => $occurrence->id,
            'rider_id'      => $rider->id,
            'type'          => $assignmentType,
            'assigned_by'   => $assignedBy,
        ]);

        return AssignmentResult::assigned((int) $rider->id, $assignmentType);
    }

    private function logUnassigned(
        SubscriptionOccurrence $occurrence,
        string $reason,
        ?string $attemptedType = null,
        ?int $attemptedRiderId = null,
    ): AssignmentResult {
        $item = $occurrence->subscriptionItem;
        $subscription = $item?->subscription;

        if ($subscription) {
            DB::table('subscription_activity_logs')->insert([
                'subscription_id'      => $subscription->id,
                'subscription_item_id' => $occurrence->subscription_item_id,
                'customer_id'          => $subscription->customer_id,
                'event_type'           => 'rider_unassigned',
                'actor_type'           => 'system',
                'actor_id'             => null,
                'occurrence_date'      => $occurrence->occurrence_date,
                'description'          => $reason,
                'metadata'             => json_encode([
                    'occurrence_id'      => $occurrence->id,
                    'attempted_type'     => $attemptedType,
                    'attempted_rider_id' => $attemptedRiderId,
                ]),
                'created_at'           => now(),
                'updated_at'           => now(),
            ]);
        }

        Log::warning('Rider assignment failed', [
            'occurrence_id' => $occurrence->id,
            'reason'        => $reason,
        ]);

        return AssignmentResult::unassigned($reason);
    }

    private function incrementCount(array &$counts, AssignmentResult $result): void
    {
        match ($result->status) {
            AssignmentResult::STATUS_ASSIGNED   => $counts['assigned']++,
            AssignmentResult::STATUS_UNASSIGNED => $counts['unassigned']++,
            AssignmentResult::STATUS_FAILED     => $counts['failed']++,
            AssignmentResult::STATUS_ALREADY    => $counts['already']++,
            default                             => null,
        };
    }
}
