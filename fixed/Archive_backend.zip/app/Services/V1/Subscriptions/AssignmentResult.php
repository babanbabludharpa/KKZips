<?php

namespace App\Services\V1\Subscriptions;

/**
 * Value object returned by DeliveryBoyAssignmentService::assignOccurrence().
 * Immutable. Carries the decision and (for diagnostics) the reason when the
 * decision was "unassigned" or "failed".
 */
final class AssignmentResult
{
    public const STATUS_ASSIGNED   = 'assigned';
    public const STATUS_UNASSIGNED = 'unassigned';
    public const STATUS_FAILED     = 'failed';
    public const STATUS_ALREADY    = 'already_assigned';

    private function __construct(
        public readonly string $status,
        public readonly ?int $deliveryBoyId = null,
        public readonly ?string $assignmentType = null,
        public readonly ?string $reason = null,
    ) {}

    public static function assigned(int $riderId, string $assignmentType): self
    {
        return new self(self::STATUS_ASSIGNED, $riderId, $assignmentType, null);
    }

    public static function alreadyAssigned(int $riderId): self
    {
        return new self(self::STATUS_ALREADY, $riderId, null, null);
    }

    public static function unassigned(string $reason): self
    {
        return new self(self::STATUS_UNASSIGNED, null, null, $reason);
    }

    public static function failed(string $reason): self
    {
        return new self(self::STATUS_FAILED, null, null, $reason);
    }

    public function isAssigned(): bool
    {
        return $this->status === self::STATUS_ASSIGNED;
    }
}
