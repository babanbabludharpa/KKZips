<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;
use App\Models\SubscriptionOccurrence;

/**
 * Carries the request/assignment context through the delivery-confirmation
 * internal methods. Groups the parameters that were previously passed
 * individually to markDelivered() / markNotDelivered() — SonarQube's
 * php:S107 flagged those methods for having too many parameters.
 */
final class DeliveryConfirmationContext
{
    public function __construct(
        public readonly DeliveryAssignment $assignment,
        public readonly SubscriptionOccurrence $occurrence,
        public readonly int $variantId,
        public readonly int $branchId,
        public readonly int $submittedBy,
        public readonly bool $stockCheckEnabled,
        public readonly ?float $lat = null,
        public readonly ?float $lng = null,
    ) {}
}
