<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionActivityLog;
use App\Models\SubscriptionItem;

class SubscriptionActivityLogService
{
    public function log(SubscriptionActivityLogRequest $request): SubscriptionActivityLog
    {
        return SubscriptionActivityLog::create([
            'subscription_id' => $request->subscriptionId,
            'subscription_item_id' => $request->subscriptionItemId,
            'customer_id' => $request->customerId,
            'event_type' => $request->eventType,
            'actor_type' => $request->actorType,
            'actor_id' => $request->actorId,
            'occurrence_date' => $request->occurrenceDate,
            'description' => $request->description,
            'metadata' => $request->metadata,
        ]);
    }

    /** Convenience wrapper - resolves subscription_id/customer_id from the item, the common case. */
    public function logForItem(
        SubscriptionItem $item,
        string $eventType,
        string $actorType,
        ?int $actorId,
        string $description,
        ?string $occurrenceDate = null,
        ?array $metadata = null,
    ): SubscriptionActivityLog {
        return $this->log(new SubscriptionActivityLogRequest(
            subscriptionId: $item->subscription_id,
            customerId: $item->subscription->customer_id,
            eventType: $eventType,
            actorType: $actorType,
            actorId: $actorId,
            description: $description,
            subscriptionItemId: $item->id,
            occurrenceDate: $occurrenceDate,
            metadata: $metadata,
        ));
    }
}
