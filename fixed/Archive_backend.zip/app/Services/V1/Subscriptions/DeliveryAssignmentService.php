<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;
use App\Models\Inventory;
use App\Models\SubscriptionOccurrence;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Manual batch assignment — the admin UI's path.
 *
 * This service delegates the eligibility decision to
 * DeliveryBoyAssignmentService (the engine). Every assignment — cron,
 * admin UI, mobile, leave rebalance — follows the same six checks:
 * active, branch, zone, slot+day, leave, capacity. No bypasses.
 *
 * The split of responsibilities:
 *   - DeliveryBoyAssignmentService decides WHO gets the occurrence,
 *     writes the occurrence (delivery_boy_id, assignment_type,
 *     assigned_by, assigned_at) and writes the audit log.
 *   - DeliveryAssignmentService (this file) writes what the manual
 *     path uniquely needs on top: the delivery_assignments pivot row,
 *     the sequence number, and the inventory stock reservation.
 *
 * Both together, atomically, or neither.
 */
class DeliveryAssignmentService
{
    public function __construct(
        protected DeliveryBoyAssignmentService $engine,
    ) {}

    /**
     * Assign a batch of occurrences to a rider.
     *
     * Fail-loud: if ANY occurrence cannot be assigned (rider ineligible
     * for any reason — inactive, wrong branch, wrong zone, wrong slot,
     * on leave, over capacity), the WHOLE batch is rejected with the
     * reasons listed. No partial success.
     *
     * @return array{assigned_occurrence_ids: array<int>, }
     */
    public function assign(
        Carbon $date,
        int $deliveryBoyId,
        array $occurrenceIds,
        ?int $requiredBranchId = null,
    ): array {
        if (empty($occurrenceIds)) {
            throw ValidationException::withMessages([
                'occurrence_ids' => 'At least one occurrence must be selected.',
            ]);
        }

        return DB::transaction(function () use ($date, $deliveryBoyId, $occurrenceIds, $requiredBranchId) {
            $occurrences = SubscriptionOccurrence::query()
                ->whereIn('id', $occurrenceIds)
                ->whereDate('occurrence_date', $date->toDateString())
                ->where('status', 'scheduled')
                ->whereHas('subscriptionItem.subscription', function ($q) use ($requiredBranchId) {
                    $q->where('branch_id', $requiredBranchId);
                })
                ->with(['subscriptionItem.subscription.deliveryAddress'])
                ->get();

            // Fail-loud: any id that didn't match (wrong branch, wrong
            // date, already assigned, not scheduled) rejects the batch.
            $foundIds = $occurrences->pluck('id')->all();
            $requestedIds = array_map('intval', $occurrenceIds);
            $missingIds = array_values(array_diff($requestedIds, $foundIds));

            if (! empty($missingIds)) {
                throw ValidationException::withMessages([
                    'occurrence_ids' => 'One or more selected occurrences are not available for assignment '
                        .'in your branch (wrong branch, wrong date, already assigned, or no longer scheduled).',
                ]);
            }

            // ── Step 1: engine decides for every occurrence ────────
            // Run the engine first, without committing the pivot or stock.
            // If any occurrence fails eligibility, reject the whole batch.
            $failures = [];
            foreach ($occurrences as $occurrence) {
                $result = $this->engine->assignOccurrence($occurrence, $deliveryBoyId);

                if (! $result->isAssigned()) {
                    $failures[] = "Occurrence #{$occurrence->id}: ".($result->reason ?? 'unknown reason');
                }
            }

            if (! empty($failures)) {
                throw ValidationException::withMessages([
                    'occurrence_ids' => 'Cannot assign: '.implode(' | ', $failures),
                ]);
            }

            // ── Step 2: commit pivot, sequence, stock ──────────────
            // The engine has already written the occurrence's
            // delivery_boy_id / assignment_type / assigned_by / assigned_at
            // and the audit log. Here we write what is unique to the
            // manual path.
            $nextSequence = (int) (DeliveryAssignment::where('delivery_boy_id', $deliveryBoyId)
                ->whereDate('occurrence_date', $date->toDateString())
                ->max('sequence') ?? -1) + 1;

            $assignedIds = [];

            foreach ($occurrences as $occurrence) {
                $variantId = $occurrence->subscriptionItem->product_variant_id;
                $branchId = $occurrence->subscriptionItem->subscription->branch_id;

                // Stock reservation — only the manual path reserves.
                Inventory::where('product_variant_id', $variantId)
                    ->where('branch_id', $branchId)
                    ->incrementEach(['quantity_reserved' => $occurrence->qty]);

                DeliveryAssignment::create([
                    'occurrence_date'            => $date->toDateString(),
                    'delivery_boy_id'            => $deliveryBoyId,
                    'subscription_occurrence_id' => $occurrence->id,
                    'status'                     => 'pending',
                    'sequence'                   => $nextSequence++,
                ]);

                // The engine already set status to nothing; keep it as
                // 'scheduled' — pickup() will move it to 'out_for_delivery'
                // when the rider physically picks it up. This matches the
                // pre-existing behavior: 'assigned' is not set here; the
                // occurrence stays 'scheduled' until pickup.
                $occurrence->update(['status' => 'assigned']);

                $assignedIds[] = $occurrence->id;
            }

            return ['assigned_occurrence_ids' => $assignedIds];
        });
    }

    public function pickup(int $riderId, int $assignmentId): array
    {
        return DB::transaction(function () use ($riderId, $assignmentId) {
            $assignment = DeliveryAssignment::where('id', $assignmentId)
                ->where('delivery_boy_id', $riderId)
                ->with('occurrence')
                ->firstOrFail();

            abort_unless($assignment->occurrence->status === 'assigned', 422, 'This stop is not awaiting pickup.');

            $assignment->occurrence->update(['status' => 'out_for_delivery']);

            return [
                'occurrence_id' => $assignment->occurrence->id,
                'status' => 'out_for_delivery',
            ];
        });
    }
}
