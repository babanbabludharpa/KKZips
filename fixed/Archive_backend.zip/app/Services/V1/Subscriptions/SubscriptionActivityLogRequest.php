<?php

namespace App\Services\V1\Subscriptions;

/**
 * Groups the fields for SubscriptionActivityLogService::log().
 * Reduces log() from 9 parameters to 1 (SonarQube php:S107).
 */
final class SubscriptionActivityLogRequest
{
    public function __construct(
        public readonly int $subscriptionId,
        public readonly int $customerId,
        public readonly string $eventType,
        public readonly string $actorType,
        public readonly ?int $actorId,
        public readonly string $description,
        public readonly ?int $subscriptionItemId = null,
        public readonly ?string $occurrenceDate = null,
        public readonly ?array $metadata = null,
    ) {}
}
