<?php

namespace App\Services\V1\Subscriptions;

use App\Models\ProductVariant;
use App\Models\RecurringUnavailableDay;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Models\SubscriptionPause;
use App\Models\TenantHoliday;
use App\Services\V1\Tenant\TenantLeaveService;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SubscriptionOccurrenceGenerationService
{
    public function __construct(private TenantLeaveService $leaveService) {}

    public function generateUpTo(Carbon $upTo): array
    {
        $created = 0;
        $skipped = 0;

        SubscriptionItem::where('status', 'active')
            ->with('subscription')
            ->chunkById(200, function ($items) use ($upTo, &$created, &$skipped) {
                foreach ($items as $item) {
                    if ($item->subscription->status !== 'active') {
                        continue;
                    }

                    [$c, $s] = $this->generateForItem($item, $upTo);
                    $created += $c;
                    $skipped += $s;
                }
            });

        Log::info('Subscription occurrence generation run complete', [
            'up_to' => $upTo->toDateString(),
            'created' => $created,
            'skipped' => $skipped,
        ]);

        return ['created' => $created, 'skipped' => $skipped];
    }

    public function generateInitialOccurrence(SubscriptionItem $item): bool
    {
        $date = $this->findFirstMatchingDate($item);

        if ($date === null) {
            Log::warning('No matching delivery date found within 60-day search window for new subscription item', [
                'subscription_item_id' => $item->id,
            ]);

            return false;
        }

        return $this->generateSingleOccurrence($item, $date);
    }

    private function findFirstMatchingDate(SubscriptionItem $item): ?Carbon
    {
        $startFrom = Carbon::parse($item->subscription->start_date)->max(now()->startOfDay());
        $searchLimit = $startFrom->copy()->addDays(60);

        for ($date = $startFrom->copy(); $date->lte($searchLimit); $date->addDay()) {
            if (! $this->shouldGenerateFor($item, $date)) {
                break;
            }

            if ($item->runsOn($date)) {
                return $date;
            }
        }

        return null;
    }

    protected function generateForItem(SubscriptionItem $item, Carbon $upTo): array
    {
        $startFrom = $this->resolveStartDate($item);

        if ($startFrom->gt($upTo)) {
            return [0, 0];
        }

        $created = 0;
        $skipped = 0;

        foreach (CarbonPeriod::create($startFrom, $upTo) as $date) {
            if (! $this->shouldGenerateFor($item, $date)) {
                break;
            }

            if (! $item->runsOn($date)) {
                continue;
            }

            $result = $this->generateSingleOccurrence($item, $date);
            $result ? $created++ : $skipped++;
        }

        return [$created, $skipped];
    }

    private function shouldGenerateFor(SubscriptionItem $item, Carbon $date): bool
    {
        return ! ($item->subscription->end_date && $date->gt($item->subscription->end_date));
    }

    private function resolveStartDate(SubscriptionItem $item): Carbon
    {
        $lastDate = SubscriptionOccurrence::where('subscription_item_id', $item->id)
            ->max('occurrence_date');

        if ($lastDate) {
            return Carbon::parse($lastDate)->addDay();
        }

        return Carbon::parse($item->subscription->start_date)->max(now()->startOfDay());
    }

    protected function generateSingleOccurrence(SubscriptionItem $item, Carbon $date): bool
    {
        return DB::transaction(function () use ($item, $date) {
            $exists = SubscriptionOccurrence::where('subscription_item_id', $item->id)
                ->whereDate('occurrence_date', $date)
                ->exists();

            if ($exists) {
                return false;
            }

            [$status, $skipSource] = $this->resolveSkip($item, $date);

            // If the reason is a leave, capture its id + reason on the row
            // so the customer sees why it's skipped, and the reconciler
            // can reactivate it later if the leave is cancelled.
            $leaveId = null;
            $leaveReason = null;
            if ($status === 'holiday_skipped' && $skipSource === 'holiday') {
                $leave = $this->leaveService->whichLeaveCovers(
                    $item->subscription->branch_id,
                    $date->toDateString(),
                    $item->slot_id,
                );
                if ($leave) {
                    $leaveId = $leave->id;
                    $leaveReason = $leave->reason;
                }
            }

            $price = $this->resolveEffectivePrice($item->product_variant_id);

            SubscriptionOccurrence::create([
                'subscription_item_id'      => $item->id,
                'branch_id'                 => $item->subscription->branch_id,
                'occurrence_date'           => $date->toDateString(),
                'qty'                       => $item->resolveQtyForDate($date),
                'unit_price_snapshot'       => $price,
                'status'                    => $status,
                'skip_source'               => $skipSource,
                'leave_id'                  => $leaveId,
                'leave_cancellation_reason' => $leaveReason,
            ]);

            return true;
        });
    }

    protected function resolveSkip(SubscriptionItem $item, Carbon $date): array
    {
        $pause = SubscriptionPause::where('subscription_item_id', $item->id)
            ->covering($date)
            ->first();

        if ($pause) {
            return $this->pauseStatus($pause);
        }

        if ($this->isWeeklyOff($item, $date)) {
            return ['holiday_skipped', 'weekly_off'];
        }

        if (TenantHoliday::whereDate('date', $date)->exists()) {
            return ['holiday_skipped', 'holiday'];
        }

        // Tenant leave — a leave covering this (branch, date, slot) means
        // the delivery is skipped and the reason is stored on the occurrence.
        $leave = $this->leaveService->whichLeaveCovers(
            $item->subscription->branch_id,
            $date->toDateString(),
            $item->slot_id,
        );

        if ($leave) {
            return ['holiday_skipped', 'holiday'];
        }

        return ['scheduled', null];
    }

    private function pauseStatus(SubscriptionPause $pause): array
    {
        $isAdmin = $pause->initiated_by === 'admin';

        return [
            $isAdmin ? 'admin_paused' : 'customer_paused',
            $isAdmin ? 'admin' : 'customer',
        ];
    }

    private function isWeeklyOff(SubscriptionItem $item, Carbon $date): bool
    {
        return RecurringUnavailableDay::where('day_of_week', $date->dayOfWeek)
            ->where('slot_id', $item->slot_id)
            ->exists();
    }

    protected function resolveEffectivePrice(int $productVariantId): float
    {
        $variant = ProductVariant::with('discountSchedules')->findOrFail($productVariantId);
        $unitPrice = (float) $variant->selling_price;

        if (! $variant->is_discount_active) {
            return $unitPrice;
        }

        return $this->applyActiveDiscount($variant, $unitPrice);
    }

    private function applyActiveDiscount(ProductVariant $variant, float $unitPrice): float
    {
        $activeDiscount = $variant->discountSchedules()->where('status', 'active')->first();

        if (! $activeDiscount) {
            return $unitPrice;
        }

        $discountPct = (float) $activeDiscount->discount_percent;

        return round($unitPrice * (1 - $discountPct / 100), 2);
    }
}
