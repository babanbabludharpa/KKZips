<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Models\SubscriptionPause;
use App\Models\SubscriptionQtyOverride;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SubscriptionPauseService
{
    public function __construct(protected SubscriptionActivityLogService $activityLog) {}

    public function create(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo, string $initiatedBy, ?int $actorId, ?string $reason = null): SubscriptionPause
    {
        $this->assertItemIsActive($item, 'This subscription item is not active, so its schedule cannot be changed.');
        $this->assertNoOverlappingOverride($item, $dateFrom, $dateTo);

        $bypassesLock = SubscriptionOccurrence::actorBypassesCutoffLock($initiatedBy);

        if (! $bypassesLock) {
            $this->assertRangeNotLocked($dateFrom, $dateTo);
        }

        return DB::transaction(function () use ($item, $dateFrom, $dateTo, $initiatedBy, $actorId, $reason, $bypassesLock) {
            $pause = $this->persistPause($item, $dateFrom, $dateTo, $initiatedBy, $reason);
            $this->applyPauseToOccurrences($item, $dateFrom, $dateTo, $initiatedBy, $bypassesLock);
            $this->logPauseActivity($item, $dateFrom, $dateTo, $initiatedBy, $actorId, $reason);

            return $pause;
        });
    }

    public function resume(SubscriptionPause $pause, string $requestedBy, ?int $actorId = null): void
    {
        $item = $pause->subscriptionItem;

        $this->assertItemIsActive($item, 'This subscription item is not active, so its pause cannot be resumed.');

        if (! SubscriptionOccurrence::actorBypassesCutoffLock($requestedBy)
            && SubscriptionOccurrence::isDateLocked($pause->date_from)) {
            throw ValidationException::withMessages([
                'pause' => 'Cannot resume - the earliest paused date is already locked.',
            ]);
        }

        DB::transaction(function () use ($pause, $item, $requestedBy, $actorId) {
            $this->applyResumeToOccurrences($pause);
            $this->logResumeActivity($item, $pause, $requestedBy, $actorId);
            $pause->delete();
        });
    }

    // ════════════════════════════════════════════════════════════════
    // Guards
    // ════════════════════════════════════════════════════════════════

    private function assertItemIsActive(SubscriptionItem $item, string $message): void
    {
        if ($item->status !== 'active') {
            throw ValidationException::withMessages(['item' => $message]);
        }
    }

    private function assertNoOverlappingOverride(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo): void
    {
        $exists = SubscriptionQtyOverride::where('subscription_item_id', $item->id)
            ->where('date_from', '<=', $dateTo->toDateString())
            ->where('date_to', '>=', $dateFrom->toDateString())
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                'date_from' => 'This date range already has a quantity change on file. Remove it first, or choose different dates.',
            ]);
        }
    }

    private function assertRangeNotLocked(Carbon $dateFrom, Carbon $dateTo): void
    {
        foreach (CarbonPeriod::create($dateFrom, $dateTo) as $date) {
            if (SubscriptionOccurrence::isDateLocked($date)) {
                throw ValidationException::withMessages([
                    'date_from' => "Cannot pause {$date->toDateString()} - it's already locked (past the cutoff for tomorrow, or today/earlier).",
                ]);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Create helpers
    // ════════════════════════════════════════════════════════════════

    private function persistPause(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo, string $initiatedBy, ?string $reason): SubscriptionPause
    {
        return SubscriptionPause::create([
            'subscription_item_id' => $item->id,
            'date_from' => $dateFrom->toDateString(),
            'date_to' => $dateTo->toDateString(),
            'initiated_by' => $initiatedBy,
            'reason' => $reason,
        ]);
    }

    private function applyPauseToOccurrences(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo, string $initiatedBy, bool $bypassesLock): void
    {
        SubscriptionOccurrence::where('subscription_item_id', $item->id)
            ->whereBetween('occurrence_date', [$dateFrom->toDateString(), $dateTo->toDateString()])
            ->where('status', 'scheduled')
            ->get()
            ->each(function ($occurrence) use ($initiatedBy, $bypassesLock) {
                if ($bypassesLock || ! $occurrence->isLocked()) {
                    $occurrence->update([
                        'status' => $initiatedBy === 'admin' ? 'admin_paused' : 'customer_paused',
                        'skip_source' => $initiatedBy,
                    ]);
                }
            });
    }

    private function logPauseActivity(SubscriptionItem $item, Carbon $dateFrom, Carbon $dateTo, string $initiatedBy, ?int $actorId, ?string $reason): void
    {
        $this->activityLog->logForItem(
            $item,
            'paused',
            $initiatedBy === 'admin' ? 'admin' : 'customer',
            $actorId,
            'Paused delivery for '.$this->formatDateRange($dateFrom, $dateTo).($reason ? " ({$reason})" : ''),
            $dateFrom->toDateString(),
            ['date_from' => $dateFrom->toDateString(), 'date_to' => $dateTo->toDateString(), 'reason' => $reason],
        );
    }

    // ════════════════════════════════════════════════════════════════
    // Resume helpers
    // ════════════════════════════════════════════════════════════════

    private function applyResumeToOccurrences(SubscriptionPause $pause): void
    {
        SubscriptionOccurrence::where('subscription_item_id', $pause->subscription_item_id)
            ->whereBetween('occurrence_date', [$pause->date_from, $pause->date_to])
            ->whereIn('status', ['admin_paused', 'customer_paused'])
            ->get()
            ->each(function ($occurrence) {
                if (! $occurrence->isLocked()) {
                    $occurrence->update(['status' => 'scheduled', 'skip_source' => null]);
                }
            });
    }

    private function logResumeActivity(SubscriptionItem $item, SubscriptionPause $pause, string $requestedBy, ?int $actorId): void
    {
        $this->activityLog->logForItem(
            $item,
            'resumed',
            $requestedBy === 'admin' ? 'admin' : 'customer',
            $actorId,
            'Resumed delivery for '.$this->formatDateRange($pause->date_from, $pause->date_to),
            $pause->date_from->toDateString(),
            ['pause_id' => $pause->id],
        );
    }

    private function formatDateRange(Carbon $from, Carbon $to): string
    {
        return $from->equalTo($to)
            ? $from->toDateString()
            : "{$from->toDateString()} to {$to->toDateString()}";
    }
}
