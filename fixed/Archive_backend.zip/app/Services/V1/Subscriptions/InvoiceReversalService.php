<?php

namespace App\Services\V1\Subscriptions;

use App\Models\CustomerWallet;
use App\Models\Invoice;
use App\Models\InvoicePayment;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class InvoiceReversalService
{
    public function cancel(Invoice $invoice, int $cancelledBy, string $reason): Invoice
    {
        if ($invoice->status === 'cancelled') {
            throw ValidationException::withMessages([
                'invoice' => 'Invoice is already cancelled.',
            ]);
        }

        return DB::transaction(function () use ($invoice, $cancelledBy, $reason) {
            $invoice->occurrences()->update(['invoice_id' => null, 'status' => 'delivered']);

            $invoice->payments()->where('is_reversal', false)->each(function ($payment) use ($invoice, $cancelledBy) {
                InvoicePayment::create([
                    'invoice_id' => $invoice->id,
                    'amount' => -$payment->amount,
                    'payment_mode' => $payment->payment_mode,
                    'received_by' => $cancelledBy,
                    'received_at' => now(),
                    'note' => "Reversal of payment #{$payment->id} due to invoice cancellation",
                    'is_reversal' => true,
                ]);

                if ($payment->payment_mode === 'wallet') {
                    $this->refundToWallet($invoice, $payment->amount);
                }
            });

            $invoice->update([
                'status' => 'cancelled',
                'amount_paid' => 0,
                'amount_due' => 0,
                'cancelled_at' => now(),
                'cancelled_by' => $cancelledBy,
                'cancellation_reason' => $reason,
            ]);

            return $invoice->fresh(['items', 'payments']);
        });
    }

    protected function refundToWallet(Invoice $invoice, float $amount): void
    {
        $wallet = CustomerWallet::where('customer_id', $invoice->customer_id)->lockForUpdate()->first();

        if (! $wallet) {
            $wallet = CustomerWallet::create(['customer_id' => $invoice->customer_id, 'balance' => 0]);
        }

        $wallet->increment('balance', $amount);

        WalletTransaction::create([
            'customer_id' => $invoice->customer_id,
            'type' => 'refund',
            'amount' => $amount,
            'balance_after' => $wallet->fresh()->balance,
            'reference_type' => 'invoice',
            'reference_id' => $invoice->id,
        ]);
    }
}
