<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryBoy;
use App\Models\DeliveryBoyLeave;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Create and delete rider leave, with the corresponding rebalance.
 *
 * Two shapes:
 *   - Full day:  slot_id = NULL, start_date <= end_date. Blocks the
 *                rider for every slot across the date range.
 *   - Slot:      slot_id = X, start_date == end_date. Blocks the rider
 *                for that specific slot on that specific date.
 *
 * On create: rebalance occurrences in the affected date range.
 *   - Full-day leave → rebalance all slots (slotId = null).
 *   - Slot-specific leave → rebalance only that slot (slotId = X).
 *
 * On delete: soft-delete the leave, then rebalance only FUTURE
 * non-finalized occurrences in the (former) leave range. Past and
 * finalized occurrences are untouched.
 */
class DeliveryBoyLeaveService
{
    public function __construct(
        protected DeliveryBoyAssignmentService $engine,
    ) {}

    public function create(
        DeliveryBoy $rider,
        ?int $slotId,
        Carbon $startDate,
        Carbon $endDate,
        ?string $reason,
        int $actorId,
    ): DeliveryBoyLeave {
        if ($startDate->lt(Carbon::today())) {
            throw ValidationException::withMessages([
                'start_date' => 'A leave cannot start in the past.',
            ]);
        }

        if ($slotId !== null) {
            // Slot-specific leaves are always single-day.
            if (! $startDate->equalTo($endDate)) {
                throw ValidationException::withMessages([
                    'end_date' => 'A slot-specific leave is for a single day. Use a full-day leave for multi-day unavailability.',
                ]);
            }
        } else {
            if ($endDate->lt($startDate)) {
                throw ValidationException::withMessages([
                    'end_date' => 'End date must be on or after start date.',
                ]);
            }
        }

        $this->assertNoOverlappingLeave($rider, $slotId, $startDate, $endDate);

        return DB::transaction(function () use ($rider, $slotId, $startDate, $endDate, $reason) {
            $leave = DeliveryBoyLeave::create([
                'delivery_boy_id' => $rider->id,
                'slot_id'         => $slotId,
                'start_date'      => $startDate->toDateString(),
                'end_date'        => $endDate->toDateString(),
                'reason'          => $reason,
            ]);

            $this->engine->rebalanceForRider($rider->id, $startDate, $endDate, $slotId);

            return $leave;
        });
    }

    public function delete(DeliveryBoyLeave $leave, int $actorId): void
    {
        DB::transaction(function () use ($leave, $actorId) {
            $riderId = (int) $leave->delivery_boy_id;
            $slotId  = $leave->slot_id !== null ? (int) $leave->slot_id : null;
            $from    = $leave->start_date;
            $to      = $leave->end_date;

            $leave->deleted_by = $actorId;
            $leave->save();
            $leave->delete(); // soft-delete

            $today = Carbon::today()->toDateString();
            $effectiveFrom = $from->lt($today) ? Carbon::today() : $from;

            if ($effectiveFrom->gt($to)) {
                return;
            }

            // Step 1: re-assign occurrences that were assigned to this rider
            // during the leave (now that the leave is gone, they may revert
            // to the standing rider).
            $this->engine->rebalanceForRider($riderId, $effectiveFrom, $to, $slotId);

            // Step 2: assign occurrences in the leave range that were left
            // unassigned because no rider was eligible at the time (e.g.
            // the only eligible rider was on leave). Now that the leave is
            // lifted, they may become assignable.
            for ($date = $effectiveFrom->copy(); $date->lte($to); $date->addDay()) {
                $this->engine->assignForDate($date);
            }
        });
    }

    private function assertNoOverlappingLeave(
        DeliveryBoy $rider,
        ?int $slotId,
        Carbon $startDate,
        Carbon $endDate,
    ): void {
        // Overlap rule:
        //   - Full-day leave overlaps any leave (full or slot) whose date
        //     range intersects the request.
        //   - Slot leave overlaps only leaves whose slot_id matches OR is
        //     full-day (slot_id = NULL) on an intersecting date range.
        $query = DeliveryBoyLeave::where('delivery_boy_id', $rider->id)
            ->where('start_date', '<=', $endDate->toDateString())
            ->where('end_date', '>=', $startDate->toDateString());

        if ($slotId === null) {
            // New full-day leave overlaps ANY existing leave in the range.
        } else {
            // New slot leave overlaps full-day leaves OR leaves with the
            // same slot_id.
            $query->where(function ($q) use ($slotId) {
                $q->whereNull('slot_id')->orWhere('slot_id', $slotId);
            });
        }

        if ($query->exists()) {
            throw ValidationException::withMessages([
                'start_date' => $slotId === null
                    ? 'This rider already has a leave that overlaps these dates.'
                    : 'This rider already has a full-day leave or a leave for this slot overlapping these dates.',
            ]);
        }
    }
}
