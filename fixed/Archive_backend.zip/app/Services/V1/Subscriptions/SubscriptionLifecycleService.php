<?php

namespace App\Services\V1\Subscriptions;

use App\Models\DeliveryAssignment;
use App\Models\Inventory;
use App\Models\Subscription;
use App\Models\SubscriptionOccurrence;
use Illuminate\Support\Facades\DB;

class SubscriptionLifecycleService
{
    public function __construct(protected SubscriptionActivityLogService $activityLog) {}

    /**
     * Indefinite pause - no end date, distinct from the per-day
     * subscription_pauses mechanism which always has a known date_to.
     * Cascades to all currently-active items and flips any existing
     * non-locked scheduled occurrence so nothing already-generated slips
     * through while paused.
     */
    public function pause(Subscription $subscription, string $actorType, ?int $actorId, ?string $reason = null): Subscription
    {
        return DB::transaction(function () use ($subscription, $actorType, $actorId, $reason) {
            $subscription->update(['status' => 'paused']);

            $itemIds = $subscription->items()->where('status', 'active')->pluck('id');
            $subscription->items()->where('status', 'active')->update(['status' => 'paused']);

            SubscriptionOccurrence::whereIn('subscription_item_id', $itemIds)
                ->where('status', 'scheduled')
                ->get()
                ->each(function ($occurrence) use ($actorType) {
                    if (! $occurrence->isLocked()) {
                        $occurrence->update([
                            'status' => $actorType === 'admin' ? 'admin_paused' : 'customer_paused',
                            'skip_source' => $actorType,
                        ]);
                    }
                });

            $this->activityLog->log(
                $subscription->id,
                $subscription->customer_id,
                'paused',
                $actorType,
                $actorId,
                'Subscription paused indefinitely'.($reason ? " ({$reason})" : ''),
                null,
                null,
                ['scope' => 'subscription', 'reason' => $reason],
            );

            return $subscription->fresh();
        });
    }

    public function resume(Subscription $subscription, string $actorType, ?int $actorId): Subscription
    {
        return DB::transaction(function () use ($subscription, $actorType, $actorId) {
            $subscription->update(['status' => 'active']);

            $itemIds = $subscription->items()->where('status', 'paused')->pluck('id');
            $subscription->items()->where('status', 'paused')->update(['status' => 'active']);

            SubscriptionOccurrence::whereIn('subscription_item_id', $itemIds)
                ->whereIn('status', ['admin_paused', 'customer_paused'])
                ->get()
                ->each(function ($occurrence) {
                    if (! $occurrence->isLocked()) {
                        $occurrence->update(['status' => 'scheduled', 'skip_source' => null]);
                    }
                });

            $this->activityLog->log(
                $subscription->id,
                $subscription->customer_id,
                'resumed',
                $actorType,
                $actorId,
                'Subscription resumed',
                null,
                null,
                ['scope' => 'subscription'],
            );

            return $subscription->fresh();
        });
    }

    /**
     * Cancels the subscription and cleans up anything not yet final:
     * soft-deletes future (non-delivered/non-billed) occurrences and their
     * delivery assignments, releasing any reserved stock those assignments
     * were holding - the same release logic already used for not_delivered,
     * since a cancelled-before-delivery occurrence is the same inventory
     * situation.
     *
     * Deliberately excludes 'out_for_delivery' from the cleanup entirely -
     * that status means the item has physically left the branch with a
     * delivery boy, so it must run to its normal delivered/not_delivered
     * conclusion regardless of who cancels or when. It also excludes any
     * occurrence that's already locked (SubscriptionOccurrence::isLocked -
     * today, or tomorrow past cutoff), matching the same rule pause()/
     * resume() above already enforce: cancelling shouldn't retroactively
     * erase a delivery that's already committed. Only occurrences that are
     * both non-dispatched and unlocked get cleaned up; everything else is
     * left to complete on its own, and no new occurrences will be
     * generated once the item is marked cancelled.
     */
    public function cancel(Subscription $subscription, string $actorType, ?int $actorId, ?string $reason = null): Subscription
    {
        return DB::transaction(function () use ($subscription, $actorType, $actorId, $reason) {
            $subscription->update(['status' => 'cancelled']);
            $subscription->items()->update(['status' => 'cancelled']);

            $itemIds = $subscription->items()->pluck('id');

            $cleanableOccurrences = SubscriptionOccurrence::whereIn('subscription_item_id', $itemIds)
                ->whereIn('status', ['scheduled', 'admin_paused', 'customer_paused'])
                ->with('subscriptionItem')
                ->get()
                ->filter(fn ($occurrence) => ! $occurrence->isLocked());

            foreach ($cleanableOccurrences as $occurrence) {
                $assignment = DeliveryAssignment::where('subscription_occurrence_id', $occurrence->id)
                    ->where('status', 'pending')
                    ->first();

                if ($assignment) {
                    // Release the stock that assignment reserved - mirrors
                    // DeliveryConfirmationService's not_delivered release path.
                    $variantId = $occurrence->subscriptionItem->product_variant_id;
                    $branchId = $subscription->branch_id;

                    Inventory::where('product_variant_id', $variantId)
                        ->where('branch_id', $branchId)
                        ->decrementEach(['quantity_reserved' => $occurrence->qty]);

                    $assignment->delete(); // soft delete
                }

                $occurrence->delete(); // soft delete
            }

            $this->activityLog->log(
                $subscription->id,
                $subscription->customer_id,
                'cancelled',
                $actorType,
                $actorId,
                'Subscription cancelled'.($reason ? " ({$reason})" : ''),
                null,
                null,
                ['reason' => $reason, 'occurrences_cleaned' => $cleanableOccurrences->count()],
            );

            return $subscription->fresh();
        });
    }
}
