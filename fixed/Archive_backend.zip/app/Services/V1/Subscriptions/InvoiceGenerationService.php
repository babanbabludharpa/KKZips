<?php

namespace App\Services\V1\Subscriptions;

use App\Models\Branch;
use App\Models\CustomerWallet;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\InvoicePayment;
use App\Models\SubscriptionOccurrence;
use App\Models\WalletTransaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class InvoiceGenerationService
{
    public function __construct(
        protected InvoiceNumberService $invoiceNumberService,
    ) {}

    public function generate(
        int $customerId,
        int $branchId,
        Carbon $startDate,
        Carbon $endDate,
        int $generatedBy,
        ?float $manualAdjustmentAmount = null,
        ?string $manualAdjustmentReason = null,
    ): Invoice {
        return DB::transaction(function () use (
            $customerId, $branchId, $startDate, $endDate, $generatedBy, $manualAdjustmentAmount, $manualAdjustmentReason
        ) {
            $occurrences = SubscriptionOccurrence::query()
                ->where('status', 'delivered')
                ->whereNull('invoice_id')
                ->whereDate('occurrence_date', '>=', $startDate)
                ->whereDate('occurrence_date', '<=', $endDate)
                ->whereHas('subscriptionItem.subscription', function ($q) use ($customerId, $branchId) {
                    $q->where('customer_id', $customerId)->where('branch_id', $branchId);
                })
                ->with(['subscriptionItem.subscription.branch', 'subscriptionItem.subscription.deliveryAddress', 'subscriptionItem.productVariant.taxRate'])
                ->lockForUpdate()
                ->get();

            if ($occurrences->isEmpty()) {
                throw ValidationException::withMessages([
                    'occurrences' => 'No unbilled delivered occurrences found for this customer/branch in the selected date range.',
                ]);
            }

            $branch = Branch::findOrFail($branchId);

            $invoice = Invoice::create([
                'customer_id' => $customerId,
                'branch_id' => $branchId,
                'invoice_number' => $this->invoiceNumberService->next($branchId, $branch->code),
                'period_start' => $startDate->toDateString(),
                'period_end' => $endDate->toDateString(),
                'status' => 'draft',
                'generated_by' => $generatedBy,
                'generated_at' => now(),
            ]);

            $subtotal = 0;
            $cgstTotal = 0;
            $sgstTotal = 0;
            $igstTotal = 0;
            $taxTotal = 0;

            foreach ($occurrences as $occurrence) {
                $lineItem = $this->buildInvoiceItem($invoice, $occurrence);

                $subtotal += $lineItem['line_total'];
                $cgstTotal += $lineItem['cgst_amount'];
                $sgstTotal += $lineItem['sgst_amount'];
                $igstTotal += $lineItem['igst_amount'];
                $taxTotal += $lineItem['tax_amount'];

                $occurrence->update(['invoice_id' => $invoice->id, 'status' => 'billed']);
            }

            $adjustment = $manualAdjustmentAmount ?? 0;
            $total = max(0, round($subtotal - $adjustment, 2));

            $invoice->update([
                'subtotal' => round($subtotal, 2),
                'cgst_total' => round($cgstTotal, 2),
                'sgst_total' => round($sgstTotal, 2),
                'igst_total' => round($igstTotal, 2),
                'tax_total' => round($taxTotal, 2),
                'manual_adjustment_amount' => $adjustment,
                'manual_adjustment_reason' => $manualAdjustmentReason,
                'adjusted_by' => $adjustment > 0 ? $generatedBy : null,
                'total' => $total,
                'amount_due' => $total,
                'status' => 'generated',
            ]);

            if ($total > 0) {
                $this->debitWalletForInvoice($invoice, $generatedBy);
            } else {
                $this->recalculateInvoiceStatus($invoice);
            }

            return $invoice->fresh(['items', 'payments']);
        });
    }

    public function preview(int $customerId, int $branchId, Carbon $startDate, Carbon $endDate): array
    {
        $occurrences = SubscriptionOccurrence::query()
            ->where('status', 'delivered')
            ->whereNull('invoice_id')
            ->whereDate('occurrence_date', '>=', $startDate)
            ->whereDate('occurrence_date', '<=', $endDate)
            ->whereHas('subscriptionItem.subscription', function ($q) use ($customerId, $branchId) {
                $q->where('customer_id', $customerId)->where('branch_id', $branchId);
            })
            ->with(['subscriptionItem.subscription.branch', 'subscriptionItem.subscription.deliveryAddress', 'subscriptionItem.productVariant.taxRate'])
            ->get();

        $subtotal = $cgstTotal = $sgstTotal = $igstTotal = $taxTotal = 0;

        foreach ($occurrences as $occurrence) {
            $line = $this->computeLineItem($occurrence);
            $subtotal += $line['line_total'];
            $cgstTotal += $line['cgst_amount'];
            $sgstTotal += $line['sgst_amount'];
            $igstTotal += $line['igst_amount'];
            $taxTotal += $line['tax_amount'];
        }

        return [
            'occurrence_count' => $occurrences->count(),
            'subtotal' => round($subtotal, 2),
            'cgst_total' => round($cgstTotal, 2),
            'sgst_total' => round($sgstTotal, 2),
            'igst_total' => round($igstTotal, 2),
            'tax_total' => round($taxTotal, 2),
            'total' => round($subtotal, 2),
        ];
    }

    protected function computeLineItem(SubscriptionOccurrence $occurrence): array
    {
        $item = $occurrence->subscriptionItem;
        $subscription = $item->subscription;
        $variant = $item->productVariant;

        $finalPrice = (float) $occurrence->unit_price_snapshot;
        $qty = $occurrence->qty;

        $taxRatePercent = $variant->taxRate->percentage ?? 0;
        $taxableValuePerUnit = $taxRatePercent > 0
            ? round($finalPrice / (1 + $taxRatePercent / 100), 2)
            : $finalPrice;
        $taxAmountPerUnit = round($finalPrice - $taxableValuePerUnit, 2);
        $lineTaxAmount = round($taxAmountPerUnit * $qty, 2);
        $lineTaxableValue = round($taxableValuePerUnit * $qty, 2);
        $lineTotal = round($finalPrice * $qty, 2);

        $branchStateId = $subscription->branch->state_id ?? null;
        $deliveryStateId = $subscription->deliveryAddress->state_id ?? null;
        $isInterState = $branchStateId !== null && $deliveryStateId !== null && $branchStateId !== $deliveryStateId;

        if ($isInterState) {
            $taxType = 'igst';
            $cgstAmount = 0;
            $sgstAmount = 0;
            $igstAmount = $lineTaxAmount;
        } else {
            $taxType = 'cgst_sgst';
            $cgstAmount = round($lineTaxAmount / 2, 2);
            $sgstAmount = round($lineTaxAmount - $cgstAmount, 2);
            $igstAmount = 0;
        }

        return [
            'description' => $variant->product->name ?? $variant->sku ?? 'Subscription item',
            'qty' => $qty,
            'unit_price' => $finalPrice,
            'taxable_value' => $lineTaxableValue,
            'tax_rate_percent' => $taxRatePercent,
            'tax_type' => $taxType,
            'cgst_amount' => $cgstAmount,
            'sgst_amount' => $sgstAmount,
            'igst_amount' => $igstAmount,
            'tax_amount' => $lineTaxAmount,
            'line_total' => $lineTotal,
        ];
    }

    protected function buildInvoiceItem(Invoice $invoice, SubscriptionOccurrence $occurrence): array
    {
        $line = $this->computeLineItem($occurrence);

        InvoiceItem::create([
            'invoice_id' => $invoice->id,
            'subscription_occurrence_id' => $occurrence->id,
            'description' => $line['description'],
            'qty' => $line['qty'],
            'unit_price' => $line['unit_price'],
            'discount_percent' => 0,
            'final_price' => $line['unit_price'],
            'tax_rate_percent' => $line['tax_rate_percent'],
            'taxable_value' => $line['taxable_value'],
            'tax_type' => $line['tax_type'],
            'cgst_amount' => $line['cgst_amount'],
            'sgst_amount' => $line['sgst_amount'],
            'igst_amount' => $line['igst_amount'],
            'tax_amount' => $line['tax_amount'],
            'line_total' => $line['line_total'],
        ]);

        return $line;
    }

    protected function debitWalletForInvoice(Invoice $invoice, int $actorId): void
    {
        $wallet = CustomerWallet::where('customer_id', $invoice->customer_id)->lockForUpdate()->first();

        if (! $wallet) {
            $wallet = CustomerWallet::create(['customer_id' => $invoice->customer_id, 'balance' => 0]);
        }

        $amount = (float) $invoice->total;

        $wallet->decrement('balance', $amount);

        WalletTransaction::create([
            'customer_id' => $invoice->customer_id,
            'type' => 'invoice_payment',
            'amount' => $amount,
            'balance_after' => $wallet->fresh()->balance,
            'reference_type' => 'invoice',
            'reference_id' => $invoice->id,
        ]);

        InvoicePayment::create([
            'invoice_id' => $invoice->id,
            'amount' => $amount,
            'payment_mode' => 'wallet',
            'received_by' => $actorId,
            'received_at' => now(),
        ]);

        $this->recalculateInvoiceStatus($invoice);
    }

    public function recalculateInvoiceStatus(Invoice $invoice): void
    {
        $amountPaid = round($invoice->payments()->sum('amount'), 2);
        $amountDue = max(0, round($invoice->total - $amountPaid, 2));

        $status = match (true) {
            $amountDue <= 0 => 'paid',
            $amountPaid > 0 => 'partially_paid',
            default => 'generated',
        };

        $invoice->update([
            'amount_paid' => $amountPaid,
            'amount_due' => $amountDue,
            'status' => $status,
        ]);
    }
}
