<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionOccurrence;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class SubscriptionDeliveryReportService
{
    private const DEFAULT_PAGE_SIZE = 25;
    private const MAX_PAGE_SIZE = 100;
    private const MIN_PAGE_SIZE = 10;

    private const SORTABLE = [
        'occurrence_date' => 'occurrence_date',
        'qty' => 'qty',
        'status' => 'status',
        'not_delivered_reason' => 'not_delivered_reason',
    ];

    public function getReport(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $query = $this->baseQuery($filters);

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy("subscription_occurrences.{$column}", $sortDir);
            if ($column !== 'occurrence_date') {
                $query->orderByDesc('occurrence_date');
            }
            $query->orderByDesc('id');
        } else {
            $query->orderByDesc('occurrence_date')->orderByDesc('id');
        }

        return $query->paginate($perPage);
    }

    public function getSummary(array $filters = []): array
    {
        $rows = $this->baseQuery($filters)->get(['status', 'not_delivered_reason']);

        $byStatus = $rows->countBy('status');
        $byReason = $rows->where('status', 'not_delivered')->countBy('not_delivered_reason');

        return [
            'total' => $rows->count(),
            'by_status' => $byStatus,
            'not_delivered_by_reason' => $byReason,
        ];
    }

    protected function baseQuery(array $filters)
    {
        return SubscriptionOccurrence::query()
            ->with([
                'subscriptionItem.slot',
                'subscriptionItem.productVariant.product',
                'subscriptionItem.subscription.customer',
                'subscriptionItem.subscription.branch',
                'subscriptionItem.subscription.deliveryAddress.zone',
                'deliveryBoy',
            ])
            ->when($filters['date_from'] ?? null, fn ($q, $v) => $q->whereDate('occurrence_date', '>=', $v))
            ->when($filters['date_to'] ?? null, fn ($q, $v) => $q->whereDate('occurrence_date', '<=', $v))
            ->when($filters['status'] ?? null, fn ($q, $v) => $q->where('status', $v))
            ->when($filters['not_delivered_reason'] ?? null, fn ($q, $v) => $q->where('not_delivered_reason', $v))
            ->when($filters['branch_id'] ?? null, fn ($q, $v) => $q->whereHas(
                'subscriptionItem.subscription',
                fn ($sq) => $sq->where('branch_id', $v)
            ))
            ->when($filters['zone_id'] ?? null, fn ($q, $v) => $q->whereHas(
                'subscriptionItem.subscription.deliveryAddress',
                fn ($aq) => $aq->where('zone_id', $v)
            ))
            ->when($filters['delivery_boy_id'] ?? null, fn ($q, $v) => $q->where('delivery_boy_id', $v))
            ->when($filters['product_variant_id'] ?? null, fn ($q, $v) => $q->whereHas(
                'subscriptionItem',
                fn ($sq) => $sq->where('product_variant_id', $v)
            ));
    }

    public function getForExport(array $filters = []): Collection
    {
        return $this->baseQuery($filters)->orderByDesc('occurrence_date')->get();
    }
}
