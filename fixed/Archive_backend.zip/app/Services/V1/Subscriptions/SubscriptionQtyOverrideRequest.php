<?php

namespace App\Services\V1\Subscriptions;

use App\Models\SubscriptionItem;
use Carbon\Carbon;

/**
 * Groups the parameters for SubscriptionQtyOverrideService::create().
 * Reduces the parameter count on internal helper methods to satisfy
 * php:S107 without changing the public API.
 */
final class SubscriptionQtyOverrideRequest
{
    public function __construct(
        public readonly SubscriptionItem $item,
        public readonly Carbon $dateFrom,
        public readonly Carbon $dateTo,
        public readonly int $qty,
        public readonly string $initiatedBy,
        public readonly ?int $actorId = null,
        public readonly ?string $reason = null,
    ) {}
}
