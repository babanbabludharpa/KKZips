<?php

namespace App\Services\V1\Settings;

use App\Http\Resources\V1\DeliveryBoyResource;
use App\Models\DeliveryBoy;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DeliveryBoyService
{
    // Same disk as supplier documents, so files land under storage/app/public
    // and are covered by the existing storage symlink.
    public const DISK = 'public';

    public const DOCUMENT_FIELDS = ['adhar_doc', 'pan_doc', 'driving_licence_doc'];

    private const PROFILE_FIELDS = [
        'name', 'username', 'mobile_number', 'email', 'branch_id',
        'vehicle_type', 'max_daily_deliveries',
        'emergency_contact_no', 'bank_account_holder', 'bank_name', 'bank_ifsc', 'upi_id',
    ];

    // Blank means "keep the stored value" (the API never returns these in full).
    private const SENSITIVE_FIELDS = ['adhar_no', 'pan_no', 'bank_account_no'];

    public function getAll(array $filters = [])
    {
        $perPage = min(max((int) ($filters['per_page'] ?? 25), 10), 500);

        return $this->listQuery($filters)->paginate($perPage);
    }

    private function listQuery(array $filters)
    {
        $query = DeliveryBoy::with(['branch', 'zones', 'slots']);

        if (!empty($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('name', 'like', "%{$filters['search']}%")
                  ->orWhere('username', 'like', "%{$filters['search']}%")
                  ->orWhere('email', 'like', "%{$filters['search']}%")
                  ->orWhere('mobile_number', 'like', "%{$filters['search']}%");
            });
        }

        if (!empty($filters['branch_id'])) {
            $query->where('branch_id', $filters['branch_id']);
        }

        // id as tie-breaker: names are not unique, and without it rows can
        // repeat or vanish across pages.
        return $query->orderBy('name')->orderBy('id');
    }

    public function create(array $data): DeliveryBoy
    {
        $stored = [];

        try {
            return DB::transaction(function () use ($data, &$stored) {
                $docs = $this->storeDocuments($data);
                $stored = array_values($docs);

                $rider = DeliveryBoy::create(array_merge(
                    $this->attributes($data),
                    $docs,
                    ['password' => Hash::make($data['password'])]
                ));

                $this->syncZonesAndSlots($rider, $data);

                return $rider->fresh(['branch', 'zones', 'slots']);
            });
        } catch (\Throwable $e) {
            $this->deleteFiles($stored); // DB rolled back, don't orphan the uploads
            throw $e;
        }
    }

    public function update(int $id, array $data): DeliveryBoy
    {
        $stored = [];
        $replaced = [];

        try {
            $rider = DB::transaction(function () use ($id, $data, &$stored, &$replaced) {
                $rider = DeliveryBoy::findOrFail($id);

                $docs = $this->storeDocuments($data);
                $stored = array_values($docs);

                foreach ($docs as $field => $path) {
                    if ($rider->{$field}) {
                        $replaced[] = $rider->{$field};
                    }
                }

                $rider->update(array_merge($this->attributes($data), $docs));

                if (!empty($data['password'])) {
                    $rider->update(['password' => Hash::make($data['password'])]);
                }

                $this->syncZonesAndSlots($rider, $data);

                return $rider->fresh(['branch', 'zones', 'slots']);
            });
        } catch (\Throwable $e) {
            $this->deleteFiles($stored);
            throw $e;
        }

        // Only after the commit succeeded.
        $this->deleteFiles($replaced);

        return $rider;
    }

    public function delete(int $id): void
    {
        $rider = DeliveryBoy::findOrFail($id);
        $paths = array_filter(array_map(fn ($f) => $rider->{$f}, self::DOCUMENT_FIELDS));

        $rider->delete();

        $this->deleteFiles($paths);
    }

    public function documentResponse(int $id, string $field)
    {
        abort_unless(in_array($field, self::DOCUMENT_FIELDS, true), 404);

        $path = DeliveryBoy::findOrFail($id)->{$field};
        abort_unless($path && Storage::disk(self::DISK)->exists($path), 404);

        return Storage::disk(self::DISK)->response($path, null, [
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, no-store',
        ]);
    }

    /**
     * CSV of every rider matching the filters (not just one page).
     * Sensitive numbers are masked exactly as in the API; documents are
     * listed by type only, never exported.
     */
    public function exportCsv(array $filters): StreamedResponse
    {
        $query = $this->listQuery($filters);

        Log::info('Delivery boy CSV export', [
            'user_id' => Auth::id(),
            'filters' => $filters,
        ]);

        $filename = 'delivery_boys_' . now()->format('Y-m-d') . '.csv';

        return response()->streamDownload(function () use ($query) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel reads non-ASCII names correctly

            fputcsv($out, [
                'Sr. No.', 'Name', 'Username', 'Mobile', 'Emergency Contact', 'Email',
                'Branch', 'Vehicle', 'Max Daily Deliveries', 'Zones', 'Slots',
                'Aadhaar No', 'PAN No', 'Documents On File',
                'Account Holder', 'Bank', 'Account No', 'IFSC', 'UPI ID',
                'Online', 'Status', 'Created At',
            ]);

            $n = 0;
            // lazy() keeps eager loading and the ORDER BY, and holds one chunk in memory.
            foreach ($query->lazy(500) as $rider) {
                $r = (new DeliveryBoyResource($rider))->resolve();

                $docLabels = ['adhar_doc' => 'Aadhaar', 'pan_doc' => 'PAN', 'driving_licence_doc' => 'Licence'];
                $docs = [];
                foreach ($docLabels as $key => $label) {
                    if (!empty($r['documents'][$key])) {
                        $docs[] = $label;
                    }
                }

                fputcsv($out, array_map([$this, 'csvSafe'], [
                    ++$n,
                    $rider->name,
                    $rider->username,
                    $rider->mobile_number,
                    $rider->emergency_contact_no,
                    $rider->email,
                    $rider->branch?->name,
                    $rider->vehicle_type,
                    $rider->max_daily_deliveries,
                    $rider->zones->pluck('name')->implode('; '),
                    $this->slotSummary($rider),
                    $r['adhar_no_masked'],
                    $r['pan_no_masked'],
                    implode('; ', $docs),
                    $rider->bank_account_holder,
                    $rider->bank_name,
                    $r['bank_account_no_masked'],
                    $rider->bank_ifsc,
                    $rider->upi_id,
                    $rider->is_online ? 'Online' : 'Offline',
                    $rider->is_active ? 'Active' : 'Inactive',
                    $rider->created_at?->format('Y-m-d H:i'),
                ]));
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Cache-Control' => 'private, no-store',
        ]);
    }

    private function slotSummary(DeliveryBoy $rider): string
    {
        $days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        $order = [1, 2, 3, 4, 5, 6, 0];

        return $rider->slots
            ->groupBy('id')
            ->map(function ($rows) use ($days, $order) {
                $picked = $rows->pluck('pivot.day_of_week')->map(fn ($d) => (int) $d)->all();
                $labels = [];
                foreach ($order as $d) {
                    if (in_array($d, $picked, true)) {
                        $labels[] = $days[$d];
                    }
                }

                return $rows->first()->name . ': ' . implode(', ', $labels);
            })
            ->implode(' | ');
    }

    /** Neutralise spreadsheet formula injection (=, +, -, @ at the start of a cell). */
    private function csvSafe($value): string
    {
        $value = (string) ($value ?? '');

        return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
    }

    private function attributes(array $data): array
    {
        $attrs = Arr::only($data, self::PROFILE_FIELDS);

        foreach (self::SENSITIVE_FIELDS as $field) {
            if (!empty($data[$field])) {
                $attrs[$field] = $data[$field];
            }
        }

        return $attrs;
    }

    private function syncZonesAndSlots(DeliveryBoy $rider, array $data): void
    {
        $rider->zones()->sync($data['zone_ids']);

        $rider->slots()->detach();

        $slotRows = [];
        foreach ($data['slots'] as $slot) {
            $slotRows[] = [
                'delivery_boy_id' => $rider->id,
                'slot_id'         => $slot['slot_id'],
                'day_of_week'     => $slot['day_of_week'],
                'is_available'    => 1,
            ];
        }
        if (!empty($slotRows)) {
            DB::table('delivery_boy_slots')->insert($slotRows);
        }
    }

    /** @return array<string,string> field => stored path */
    private function storeDocuments(array $data): array
    {
        $paths = [];

        foreach (self::DOCUMENT_FIELDS as $field) {
            $file = $data[$field] ?? null;

            if ($file instanceof UploadedFile) {
                $paths[$field] = $file->store($this->storageDir(), self::DISK);
            }
        }

        return $paths;
    }

    private function storageDir(): string
    {
        $tenantId = tenant('id');

        if (! $tenantId) {
            throw new \RuntimeException('Tenant context required for rider document upload.');
        }

        return "tenants/{$tenantId}/delivery-boys/documents";
    }

    private function deleteFiles(array $paths): void
    {
        foreach ($paths as $path) {
            Storage::disk(self::DISK)->delete($path);
        }
    }
}
