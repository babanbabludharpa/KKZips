<?php

namespace App\Services\V1\Settings;

use App\Models\Branch;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BranchService
{
    private const SORTABLE = [
        'code' => 'branches.code',
        'name' => 'branches.name',
        'type' => 'branches.type',
        'city' => 'cities.name',
        'state' => 'states.name',
        'is_active' => 'branches.is_active',
        'created_at' => 'branches.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 1;

    private const MAX_PAGE_SIZE = 500;

    public function getAll(array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $filters['sort_key'] ?? null;
        $sortDir = strtolower($filters['sort_dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

        $query = Branch::query()
            ->with(['city', 'state', 'parent'])
            ->leftJoin('cities', 'cities.id', '=', 'branches.city_id')
            ->leftJoin('states', 'states.id', '=', 'branches.state_id')
            ->select('branches.*')
            ->when($filters['search'] ?? null, function ($q, $s) {
                $q->where(function ($w) use ($s) {
                    $w->where('branches.name', 'like', "%{$s}%")
                        ->orWhere('branches.code', 'like', "%{$s}%")
                        ->orWhere('branches.phone', 'like', "%{$s}%");
                });
            })
            ->when(! empty($filters['type']), fn ($q) => $q->where('branches.type', $filters['type'])
            );

        // Attach zone counts — one query, no N+1
        $zoneCounts = DB::table('branch_service_zones')
            ->select('branch_id', DB::raw('COUNT(*) as total'), DB::raw('SUM(is_active = 1) as active'))
            ->groupBy('branch_id')
            ->get()
            ->keyBy('branch_id');

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            $query->orderBy($column, $sortDir);
            if ($column !== 'branches.created_at') {
                $query->orderByDesc('branches.created_at');
            }
            $query->orderByDesc('branches.id');
        } else {
            $query->orderByDesc('branches.created_at')->orderByDesc('branches.id');
        }

        $paginated = $query->paginate($perPage);

        // Transform each row to include zone_count
        $paginated->getCollection()->transform(function ($branch) use ($zoneCounts) {
            $counts = $zoneCounts->get($branch->id);
            $branch->zone_count = [
                'total' => $counts->total ?? 0,
                'active' => (int) ($counts->active ?? 0),
            ];

            return $branch;
        });

        return $paginated;
    }

    public function create(array $data): Branch
    {
        $this->guardType($data['type'], $data['parent_id'] ?? null);
        $this->guardHeadOfficeUnique($data['type']);

        return Branch::create($data)->load(['city', 'state', 'parent']);
    }

    public function update(Branch $branch, array $data): Branch
    {
        if (isset($data['type'])) {
            $this->guardType($data['type'], $data['parent_id'] ?? $branch->parent_id);

            if ($data['type'] === 'head_office' && $branch->type !== 'head_office') {
                $this->guardHeadOfficeUnique($data['type']);
            }
        }

        $branch->update($data);

        return $branch->fresh(['city', 'state', 'parent']);
    }

    public function delete(Branch $branch): void
    {
        if ($branch->type === 'head_office') {
            throw ValidationException::withMessages([
                'type' => 'Cannot delete head office branch.',
            ]);
        }

        if ($branch->children()->count() > 0) {
            throw ValidationException::withMessages([
                'parent_id' => 'Cannot delete branch with child branches assigned to it.',
            ]);
        }

        $branch->delete();
    }

    private function guardHeadOfficeUnique(string $type): void
    {
        if ($type === 'head_office' && Branch::where('type', 'head_office')->exists()) {
            throw ValidationException::withMessages([
                'type' => 'A head office branch already exists for this tenant.',
            ]);
        }
    }

    private function guardType(string $type, mixed $parentId): void
    {
        if ($type === 'head_office' && $parentId) {
            throw ValidationException::withMessages([
                'parent_id' => 'Head office cannot have a parent.',
            ]);
        }

        if ($type === 'state_office') {
            if (! $parentId) {
                throw ValidationException::withMessages([
                    'parent_id' => 'State office must have a parent branch.',
                ]);
            }
            $parent = Branch::findOrFail($parentId);
            if ($parent->type !== 'head_office') {
                throw ValidationException::withMessages([
                    'parent_id' => 'State office parent must be head office.',
                ]);
            }
        }

        if ($type === 'branch') {
            if (! $parentId) {
                throw ValidationException::withMessages([
                    'parent_id' => 'Branch must have a parent (head office or state office).',
                ]);
            }
            $parent = Branch::findOrFail($parentId);
            if (! in_array($parent->type, ['head_office', 'state_office'])) {
                throw ValidationException::withMessages([
                    'parent_id' => 'Branch parent must be head office or state office.',
                ]);
            }
        }
    }
}
