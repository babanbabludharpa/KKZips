<?php

namespace App\Services\V1\Settings;

use App\Models\Branch;
use App\Models\BranchServiceZone;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BranchServiceZoneService
{
    /**
     * Convert a Leaflet polygon (array of [lat, lng] pairs) to MySQL WKT POLYGON string.
     * CRITICAL: MySQL spatial uses lng lat order (X=lng, Y=lat), opposite of Leaflet.
     */
    private function toWkt(array $coordinates): string
    {
        // Ensure polygon is closed (first point = last point)
        if ($coordinates[0] !== end($coordinates)) {
            $coordinates[] = $coordinates[0];
        }

        $points = array_map(
            fn ($c) => "{$c[1]} {$c[0]}", // flip: Leaflet [lat,lng] → MySQL lng lat
            $coordinates
        );

        return 'POLYGON(('.implode(', ', $points).'))';
    }

    /**
     * Convert MySQL WKT POLYGON back to Leaflet format [[lat, lng], ...]
     */
    private function fromWkt(string $wkt): array
    {
        // Extract coordinates from POLYGON((lng lat, lng lat, ...))
        preg_match('/POLYGON\(\((.+)\)\)/', $wkt, $matches);
        if (empty($matches[1])) {
            return [];
        }

        $pairs = explode(',', $matches[1]);
        $coords = [];
        foreach ($pairs as $pair) {
            [$lng, $lat] = explode(' ', trim($pair));
            $coords[] = [(float) $lat, (float) $lng]; // flip back to Leaflet [lat, lng]
        }

        // Remove closing duplicate point
        if (count($coords) > 1 && $coords[0] === end($coords)) {
            array_pop($coords);
        }

        return $coords;
    }

    public function getAllForBranch(Branch $branch): array
    {
        $rows = DB::select('
            SELECT id, branch_id, name, is_active, created_by, created_at, updated_at,
                   ST_AsText(coordinates) as coordinates_wkt
            FROM branch_service_zones
            WHERE branch_id = ?
            ORDER BY created_at ASC
        ', [$branch->id]);

        return array_map(function ($row) {
            return [
                'id' => $row->id,
                'branch_id' => $row->branch_id,
                'name' => $row->name,
                'is_active' => (bool) $row->is_active,
                'created_by' => $row->created_by,
                'created_at' => $row->created_at,
                'updated_at' => $row->updated_at,
                'coordinates' => $this->fromWkt($row->coordinates_wkt),
            ];
        }, $rows);
    }

    public function create(Branch $branch, array $data, int $userId): array
    {
        $this->validateCoordinates($data['coordinates']);
        $wkt = $this->toWkt($data['coordinates']);

        DB::statement('
            INSERT INTO branch_service_zones (branch_id, name, coordinates, is_active, created_by, created_at, updated_at)
            VALUES (?, ?, ST_GeomFromText(?, 4326), ?, ?, NOW(), NOW())
        ', [
            $branch->id,
            $data['name'],
            $wkt,
            $data['is_active'] ?? true,
            $userId,
        ]);

        $id = DB::getPdo()->lastInsertId();

        return $this->getById($id);
    }

    public function update(BranchServiceZone $zone, array $data): array
    {
        if (isset($data['coordinates'])) {
            $this->validateCoordinates($data['coordinates']);
            $wkt = $this->toWkt($data['coordinates']);

            DB::statement('
                UPDATE branch_service_zones
                SET name = ?, coordinates = ST_GeomFromText(?, 4326), is_active = ?, updated_at = NOW()
                WHERE id = ?
            ', [
                $data['name'] ?? $zone->name,
                $wkt,
                $data['is_active'] ?? $zone->is_active,
                $zone->id,
            ]);
        } else {
            DB::statement('
                UPDATE branch_service_zones
                SET name = ?, is_active = ?, updated_at = NOW()
                WHERE id = ?
            ', [
                $data['name'] ?? $zone->name,
                $data['is_active'] ?? $zone->is_active,
                $zone->id,
            ]);
        }

        return $this->getById($zone->id);
    }

    public function delete(BranchServiceZone $zone): void
    {
        DB::delete('DELETE FROM branch_service_zones WHERE id = ?', [$zone->id]);
    }

    public function toggleActive(BranchServiceZone $zone): array
    {
        DB::statement('
            UPDATE branch_service_zones SET is_active = NOT is_active, updated_at = NOW() WHERE id = ?
        ', [$zone->id]);

        return $this->getById($zone->id);
    }

    /**
     * Find all active branches that can serve a given point.
     * Returns branches with their matching zone name.
     * CRITICAL: MySQL ST_Contains uses lng lat order.
     */
    public function findServicingBranches(float $lat, float $lng): array
    {
        return DB::select('
            SELECT
                b.id, b.name, b.address, b.phone,
                b.opens_at, b.closes_at, b.is_accepting_orders,
                b.latitude, b.longitude,
                z.id as zone_id, z.name as zone_name,
                ST_Distance_Sphere(
                    POINT(b.longitude, b.latitude),
                    POINT(?, ?)
                ) / 1000 as distance_km
            FROM branch_service_zones z
            JOIN branches b ON b.id = z.branch_id
            WHERE z.is_active = 1
              AND b.is_active = 1
              AND ST_Contains(z.coordinates, ST_GeomFromText(?, 4326))
            ORDER BY distance_km ASC
        ', [$lng, $lat, "POINT($lng $lat)"]); // lng lat order for MySQL
    }

    public function getZoneCountForBranch(int $branchId): array
    {
        $row = DB::selectOne('
            SELECT
                COUNT(*) as total,
                SUM(is_active = 1) as active
            FROM branch_service_zones
            WHERE branch_id = ?
        ', [$branchId]);

        return [
            'total' => (int) $row->total,
            'active' => (int) $row->active,
        ];
    }

    private function getById(int $id): array
    {
        $row = DB::selectOne('
            SELECT id, branch_id, name, is_active, created_by, created_at, updated_at,
                   ST_AsText(coordinates) as coordinates_wkt
            FROM branch_service_zones WHERE id = ?
        ', [$id]);

        return [
            'id' => $row->id,
            'branch_id' => $row->branch_id,
            'name' => $row->name,
            'is_active' => (bool) $row->is_active,
            'created_by' => $row->created_by,
            'created_at' => $row->created_at,
            'updated_at' => $row->updated_at,
            'coordinates' => $this->fromWkt($row->coordinates_wkt),
        ];
    }

    private function validateCoordinates(array $coordinates): void
    {
        if (count($coordinates) < 3) {
            throw ValidationException::withMessages([
                'coordinates' => 'A polygon must have at least 3 points.',
            ]);
        }
    }
}
