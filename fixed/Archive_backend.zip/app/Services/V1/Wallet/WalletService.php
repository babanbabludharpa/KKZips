<?php

namespace App\Services\V1\Wallet;

use App\Exceptions\PaymentGatewayException;
use App\Exceptions\RazorpayNotConfiguredException;
use App\Exceptions\WalletTopupNotRefundableException;
use App\Models\Tenant\Customer;
use App\Models\Tenant\WalletTopup;
use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WalletService
{
    private string $baseUrl = 'https://api.razorpay.com/v1';

    public function __construct(protected TenantProfileService $tenantProfileService) {}

    private function credentials(): array
    {
        $profile = $this->tenantProfileService->getProfile();

        if (! $profile || ! $profile->razorpay_key_id || ! $profile->razorpay_key_secret) {
            throw new RazorpayNotConfiguredException('Razorpay is not configured for this tenant.');
        }

        return [
            'key_id' => $profile->razorpay_key_id,
            'key_secret' => $profile->razorpay_key_secret,
        ];
    }

    public function initiateTopup(Customer $customer, float $amount): array
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('Top-up amount must be greater than zero.');
        }

        $existing = WalletTopup::where('customer_id', $customer->id)
            ->where('amount', $amount)
            ->where('status', 'pending')
            ->where('initiated_at', '>=', now()->subMinutes(15))
            ->latest('id')
            ->first();

        if ($existing && $existing->razorpay_order_id) {
            $creds = $this->credentials();

            return [
                'wallet_topup_id' => $existing->id,
                'razorpay_order_id' => $existing->razorpay_order_id,
                'amount' => (int) round($existing->amount * 100),
                'currency' => 'INR',
                'key_id' => $creds['key_id'],
            ];
        }

        $topup = WalletTopup::create([
            'customer_id' => $customer->id,
            'amount' => $amount,
            'status' => 'pending',
            'initiated_at' => now(),
        ]);

        $creds = $this->credentials();

        $response = Http::withBasicAuth($creds['key_id'], $creds['key_secret'])
            ->post("{$this->baseUrl}/orders", [
                'amount' => (int) round($amount * 100),
                'currency' => 'INR',
                'receipt' => 'wallet_topup_'.$topup->id,
                'notes' => [
                    'type' => 'wallet_topup',
                    'wallet_topup_id' => $topup->id,
                    'customer_id' => $customer->id,
                ],
            ]);

        if (! $response->successful()) {
            Log::error('Razorpay wallet topup order creation failed', [
                'wallet_topup_id' => $topup->id,
                'response' => $response->json(),
            ]);
            $topup->update(['status' => 'failed']);
            throw new PaymentGatewayException('Payment gateway error. Please try again.');
        }

        $razorpayOrder = $response->json();
        $topup->update(['razorpay_order_id' => $razorpayOrder['id']]);

        return [
            'wallet_topup_id' => $topup->id,
            'razorpay_order_id' => $razorpayOrder['id'],
            'amount' => $razorpayOrder['amount'],
            'currency' => $razorpayOrder['currency'],
            'key_id' => $creds['key_id'],
        ];
    }

    public function verifyAndCredit(WalletTopup $topup, string $paymentId, string $signature): bool
    {
        $creds = $this->credentials();

        $payload = $topup->razorpay_order_id.'|'.$paymentId;
        $expectedSig = hash_hmac('sha256', $payload, $creds['key_secret']);

        if (! hash_equals($expectedSig, $signature)) {
            Log::warning('Wallet topup signature mismatch', [
                'wallet_topup_id' => $topup->id,
            ]);

            return false;
        }

        return $this->markPaidAndCredit($topup, $paymentId, $signature);
    }

    public function handleWebhookCaptured(string $razorpayOrderId, string $paymentId): void
    {
        $topup = WalletTopup::where('razorpay_order_id', $razorpayOrderId)->first();
        if (! $topup) {
            return;
        }

        $this->markPaidAndCredit($topup, $paymentId, null);
    }

    public function handleWebhookFailed(string $razorpayOrderId): void
    {
        $topup = WalletTopup::where('razorpay_order_id', $razorpayOrderId)
            ->where('status', 'pending')
            ->first();

        if (! $topup) {
            return;
        }

        $topup->update(['status' => 'failed']);
    }

    public function markPaidAndCredit(WalletTopup $topup, string $paymentId, ?string $signature): bool
    {
        return DB::transaction(function () use ($topup, $paymentId, $signature) {
            $affected = DB::table('wallet_topups')
                ->where('id', $topup->id)
                ->where('status', 'pending')
                ->update([
                    'status' => 'paid',
                    'razorpay_payment_id' => $paymentId,
                    'razorpay_signature' => $signature,
                    'paid_at' => now(),
                    'updated_at' => now(),
                ]);

            if ($affected === 0) {
                return false;
            }

            $this->credit(
                customerId: $topup->customer_id,
                amount: $topup->amount,
                type: 'deposit',
                referenceType: 'wallet_topup',
                referenceId: $topup->id
            );

            return true;
        });
    }

    public function adminAdjust(int $customerId, float $amount, string $direction, string $remark, int $addedBy): void
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('Amount must be greater than zero.');
        }

        if (! in_array($direction, ['credit', 'debit'], true)) {
            throw new \InvalidArgumentException('Direction must be "credit" or "debit".');
        }

        if (trim($remark) === '') {
            throw new \InvalidArgumentException('A remark is required for manual wallet adjustments.');
        }

        DB::transaction(function () use ($customerId, $amount, $direction, $remark, $addedBy) {
            $method = $direction === 'credit' ? 'credit' : 'debit';

            $this->{$method}(
                customerId: $customerId,
                amount: $amount,
                type: 'manual_adjustment',
                referenceType: null,
                referenceId: null,
                remark: $remark,
                addedBy: $addedBy,
            );
        });
    }

    public function credit(
        int $customerId,
        float $amount,
        string $type,
        ?string $referenceType = null,
        ?int $referenceId = null,
        ?string $remark = null,
        ?int $addedBy = null,
    ): void {
        $wallet = DB::table('customer_wallets')->where('customer_id', $customerId)->lockForUpdate()->first();

        if (! $wallet) {
            DB::table('customer_wallets')->insert([
                'customer_id' => $customerId,
                'balance' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $currentBalance = 0.0;
        } else {
            $currentBalance = (float) $wallet->balance;
        }

        $newBalance = $currentBalance + $amount;

        DB::table('customer_wallets')->where('customer_id', $customerId)->update([
            'balance' => $newBalance,
            'updated_at' => now(),
        ]);

        DB::table('wallet_transactions')->insert([
            'customer_id' => $customerId,
            'type' => $type,
            'amount' => $amount,
            'balance_after' => $newBalance,
            'reference_type' => $referenceType,
            'reference_id' => $referenceId,
            'remark' => $remark,
            'added_by' => $addedBy,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function debit(
        int $customerId,
        float $amount,
        string $type,
        ?string $referenceType = null,
        ?int $referenceId = null,
        ?string $remark = null,
        ?int $addedBy = null,
    ): void {
        $wallet = DB::table('customer_wallets')->where('customer_id', $customerId)->lockForUpdate()->first();
        $currentBalance = $wallet ? (float) $wallet->balance : 0.0;
        $newBalance = $currentBalance - $amount;

        DB::table('customer_wallets')->updateOrInsert(
            ['customer_id' => $customerId],
            ['balance' => $newBalance, 'updated_at' => now()]
        );

        DB::table('wallet_transactions')->insert([
            'customer_id' => $customerId,
            'type' => $type,
            'amount' => $amount,
            'balance_after' => $newBalance,
            'reference_type' => $referenceType,
            'reference_id' => $referenceId,
            'remark' => $remark,
            'added_by' => $addedBy,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function reconcileStalePending(): array
    {
        $creds = $this->credentials();
        $stale = WalletTopup::where('status', 'pending')
            ->where('initiated_at', '<=', now()->subMinutes(15))
            ->whereNotNull('razorpay_order_id')
            ->get();

        $results = ['recovered' => 0, 'expired' => 0, 'skipped' => 0];

        foreach ($stale as $topup) {
            try {
                $response = Http::withBasicAuth($creds['key_id'], $creds['key_secret'])
                    ->get("{$this->baseUrl}/orders/{$topup->razorpay_order_id}/payments");

                if (! $response->successful()) {
                    $results['skipped']++;

                    continue;
                }

                $payments = $response->json('items', []);
                $captured = collect($payments)->first(fn ($p) => $p['status'] === 'captured');

                if ($captured) {
                    $this->markPaidAndCredit($topup, $captured['id'], null);
                    $results['recovered']++;
                } else {
                    $topup->update(['status' => 'expired']);
                    $results['expired']++;
                }
            } catch (\Throwable $e) {
                Log::error('Wallet topup reconciliation failed', [
                    'wallet_topup_id' => $topup->id,
                    'error' => $e->getMessage(),
                ]);
                $results['skipped']++;
            }
        }

        return $results;
    }

    public function refundTopup(WalletTopup $topup, string $reason): void
    {
        if ($topup->status !== 'paid') {
            throw new WalletTopupNotRefundableException('Only a paid topup can be marked refunded.');
        }

        DB::transaction(function () use ($topup, $reason) {
            $topup->update(['status' => 'refunded']);

            $this->debit(
                customerId: $topup->customer_id,
                amount: $topup->amount,
                type: 'refund',
                referenceType: 'wallet_topup',
                referenceId: $topup->id,
                remark: $reason,
            );
        });
    }
}
