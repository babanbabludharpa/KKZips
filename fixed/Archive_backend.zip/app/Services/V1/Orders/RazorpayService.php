<?php

namespace App\Services\V1\Orders;

use App\Exceptions\PaymentGatewayException;
use App\Exceptions\RazorpayNotConfiguredException;
use App\Models\Tenant\Order;
use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class RazorpayService
{
    private string $baseUrl = 'https://api.razorpay.com/v1';

    private const MSG_NOT_CONFIGURED = 'Razorpay is not configured for this tenant.';

    private const MSG_GATEWAY_ERROR = 'Payment gateway error. Please try again.';

    public function __construct(protected TenantProfileService $tenantProfileService) {}

    private function credentials(): array
    {
        $profile = $this->tenantProfileService->getProfile();

        if (! $profile || ! $profile->razorpay_key_id || ! $profile->razorpay_key_secret) {
            throw new RazorpayNotConfiguredException(self::MSG_NOT_CONFIGURED);
        }

        return [
            'key_id' => $profile->razorpay_key_id,
            'key_secret' => $profile->razorpay_key_secret,
        ];
    }

    public function getKeyIdForDebug(): string
    {
        return $this->credentials()['key_id'];
    }

    public function createOrder(Order $order): array
    {
        $creds = $this->credentials();

        $response = Http::withBasicAuth($creds['key_id'], $creds['key_secret'])
            ->post("{$this->baseUrl}/orders", [
                'amount' => (int) ($order->total * 100),
                'currency' => 'INR',
                'receipt' => 'order_'.$order->id,
                'notes' => [
                    'order_id' => $order->id,
                    'customer_id' => $order->customer_id,
                ],
            ]);

        if (! $response->successful()) {
            Log::error('Razorpay order creation failed', [
                'order_id' => $order->id,
                'key_id_used' => $creds['key_id'],
                'response' => $response->json(),
            ]);
            throw new PaymentGatewayException(self::MSG_GATEWAY_ERROR);
        }

        $razorpayOrder = $response->json();

        $order->update(['razorpay_order_id' => $razorpayOrder['id']]);

        return [
            'razorpay_order_id' => $razorpayOrder['id'],
            'amount' => $razorpayOrder['amount'],
            'currency' => $razorpayOrder['currency'],
            'key_id' => $creds['key_id'],
        ];
    }

    public function verifySignature(string $orderId, string $paymentId, string $signature): bool
    {
        $creds = $this->credentials();

        $payload = $orderId.'|'.$paymentId;
        $expectedSig = hash_hmac('sha256', $payload, $creds['key_secret']);
        $valid = hash_equals($expectedSig, $signature);

        if (! $valid) {
            Log::warning('Razorpay signature computation', [
                'payload_used' => $payload,
                'key_id_used' => $creds['key_id'],
                'expected_sig_first8' => substr($expectedSig, 0, 8),
                'received_sig_first8' => substr($signature, 0, 8),
            ]);
        }

        return $valid;
    }

    public function handleWebhook(array $payload): void
    {
        $event = $payload['event'] ?? '';

        if ($event === 'payment.captured') {
            $this->handlePaymentCaptured($payload);

            return;
        }

        if ($event === 'payment.failed') {
            $this->handlePaymentFailed($payload);
        }
    }

    private function handlePaymentCaptured(array $payload): void
    {
        $paymentId = $payload['payload']['payment']['entity']['id'] ?? null;
        $razorpayOrderId = $payload['payload']['payment']['entity']['order_id'] ?? null;

        if (! $paymentId || ! $razorpayOrderId) {
            return;
        }

        $order = Order::where('razorpay_order_id', $razorpayOrderId)->first();

        if (! $order || $order->payment_status === 'paid') {
            return;
        }

        $order->update([
            'razorpay_payment_id' => $paymentId,
            'payment_status' => 'paid',
            'status' => 'confirmed',
        ]);

        app(OrderService::class)->confirmStock($order);
    }

    private function handlePaymentFailed(array $payload): void
    {
        $razorpayOrderId = $payload['payload']['payment']['entity']['order_id'] ?? null;

        if (! $razorpayOrderId) {
            return;
        }

        $order = Order::where('razorpay_order_id', $razorpayOrderId)->first();

        if (! $order) {
            return;
        }

        $order->update([
            'payment_status' => 'failed',
            'status' => 'payment_failed',
        ]);

        app(OrderService::class)->releaseStock($order);
    }
}
