<?php

namespace App\Services\V1\Orders;

use Illuminate\Support\Facades\DB;

class ZoneCheckService
{
    /**
     * Returns ['serviceable' => bool, 'branch_id' => ?int, 'branch_name' => ?string]
     * for a given point. No stock check here — that's order-time only,
     * with a cart in context. This is address-resolution-time.
     */
    public function checkPoint(float $lat, float $lng): array
    {
        $match = DB::table('branch_service_zones as bsz')
            ->join('branches as b', 'b.id', '=', 'bsz.branch_id')
            ->where('bsz.is_active', true)
            ->where('b.is_active', true)
            ->whereRaw(
                "ST_Contains(bsz.coordinates, ST_GeomFromText('".sprintf('POINT(%F %F)', $lng, $lat)."', 4326))"
            )
            // NOTE: inlined, not bound — this is a diagnostic step to confirm
            // whether PDO parameter binding was the actual cause. $lat/$lng
            // are type-hinted float, so injection risk here is effectively
            // zero, but do not copy this pattern for any raw-query value
            // that could ever originate from unvalidated string input.
            ->select('b.id', 'b.name')
            ->first();

        if ($match) {
            return [
                'serviceable' => true,
                'branch_id' => $match->id,
                'branch_name' => $match->name,
            ];
        }

        return [
            'serviceable' => false,
            'branch_id' => null,
            'branch_name' => null,
        ];
    }
}
