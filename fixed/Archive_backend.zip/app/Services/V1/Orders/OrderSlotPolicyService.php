<?php

namespace App\Services\V1\Orders;

use App\Models\TenantDeliverySlot;
use App\Models\TenantLeave;
use App\Models\TenantProfile;
use App\Services\V1\Tenant\TenantProfileService;
use Carbon\CarbonImmutable;

class OrderSlotPolicyService
{
    public function __construct(private TenantProfileService $profiles) {}

    public function orderSlotsRequired(): bool
    {
        $p = $this->profiles->getProfile();
        return $p && $p->has_orders && $p->use_order_slots;
    }

    public function availableOrderSlots(CarbonImmutable $now, int $horizonDays = 7): array
    {
        $p = $this->profiles->getProfile();
        if (! $p || ! $p->use_order_slots) return [];

        $days = $p->order_start_policy === 'same_day_slot_wise'
            ? $horizonDays
            : min($horizonDays, 1);

        $slots = TenantDeliverySlot::query()
            ->where('is_active', true)
            ->orderBy('start_time')
            ->get();

        $result = [];
        for ($offset = 0; $offset < $days; $offset++) {
            $date = $now->addDays($offset)->startOfDay();

            foreach ($slots as $slot) {
                if (! $this->isOrderSlotBookable($p, $slot, $date, $now)) continue;

                $result[] = [
                    'id'         => $slot->id,
                    'name'       => $slot->name,
                    'start_time' => $slot->start_time,
                    'end_time'   => $slot->end_time,
                    'cutoff_time'=> $slot->cutoff_time,
                    'date'       => $date->toDateString(),
                ];
            }
        }
        return $result;
    }

    /**
     * @param  int|null  $branchId  Optional branch context. When provided,
     *                              branch-scoped leaves are honored. When
     *                              null, only tenant-wide leaves apply.
     */
    public function isOrderSlotBookable(
        TenantProfile $p,
        TenantDeliverySlot $slot,
        CarbonImmutable $date,
        CarbonImmutable $now,
        ?int $branchId = null
    ): bool {
        $slotStart = $date->setTimeFromTimeString($slot->start_time);
        $slotEnd   = $date->setTimeFromTimeString($slot->end_time);

        if ($slotEnd->lt($now)) return false;

        // ── Leave check (highest priority) ─────────────────────
        // If an active leave covers this date (and branch, if known, and
        // slot, if slot-scoped), the slot is not bookable.
        if ($this->leaveBlocksSlot($date, $slot, $branchId)) {
            return false;
        }

        if ($p->order_start_policy === 'next_day_only' && $date->isSameDay($now)) return false;

        // Per-slot cutoff (exact clock time) takes priority.
        if ($slot->cutoff_time) {
            $cutoff = $date->setTimeFromTimeString($slot->cutoff_time);
            if ($cutoff->greaterThan($slotStart)) {
                $cutoff = $cutoff->subDay();
            }
            return $now->lt($cutoff);
        }

        // Fallback: profile-level offset (minutes before slot start).
        if ($p->slot_wise_cutoff_enabled) {
            $cutoff = $slotStart->subMinutes($p->slot_cutoff_offset_minutes ?? 120);
            return $now->lt($cutoff);
        }

        // Fallback: global subscription cutoff for same-day.
        if ($p->subscription_cutoff_time && $date->isSameDay($now)) {
            $globalCutoff = $date->setTimeFromTimeString($p->subscription_cutoff_time);
            if ($now->gte($globalCutoff)) return false;
        }

        if ($p->order_start_policy === 'same_day_slot_wise') {
            $lead = $p->order_same_day_lead_time_minutes ?? 120;
            return $now->addMinutes($lead)->lte($slotStart);
        }

        return true;
    }

    /**
     * True if an active leave covers this (date, slot, branch?).
     */
    private function leaveBlocksSlot(
        CarbonImmutable $date,
        TenantDeliverySlot $slot,
        ?int $branchId
    ): bool {
        $dateStr = $date->toDateString();

        // Cheap DB pre-filter — narrow before expanding recurrence.
        $candidates = TenantLeave::query()
            ->where('status', 'active')
            ->where('start_date', '<=', $dateStr)
            ->where('end_date',   '>=', $dateStr)
            ->get();

        if ($candidates->isEmpty()) return false;

        foreach ($candidates as $leave) {
            // Branch filter
            if ($leave->branch_ids !== null) {
                // Branch-scoped leave: only blocks when branch context is known
                // AND matches.
                if ($branchId === null) continue;
                if (! in_array($branchId, $leave->branch_ids, true)) continue;
            }

            // Date filter — must honor recurrence_rule.
            $matchesDate = false;
            foreach ($leave->effectiveDates() as $d) {
                if ($d->toDateString() === $dateStr) { $matchesDate = true; break; }
            }
            if (! $matchesDate) continue;

            // Slot filter
            if ($leave->slot_ids !== null && ! in_array($slot->id, $leave->slot_ids, true)) {
                continue;
            }

            return true;
        }

        return false;
    }
}
