<?php

namespace App\Services\V1\Orders;

use App\Models\DeliveryChargeRule;

class DeliveryChargeService
{
    public function distanceKm(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earthRadius = 6371;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2
           + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }

    public function calculate(float $subtotal, float $distanceKm): array
    {
        $rule = DeliveryChargeRule::where('is_active', true)->first();

        if (! $rule) {
            return $this->noRuleResponse();
        }

        $blocked = $this->checkBlockingConditions($rule, $subtotal, $distanceKm);

        if ($blocked !== null) {
            return $blocked;
        }

        return $this->qualifiesForFreeDelivery($rule, $subtotal)
            ? $this->freeDeliveryResponse($rule)
            : $this->calculateChargeResponse($rule, $subtotal, $distanceKm);
    }

    private function noRuleResponse(): array
    {
        return [
            'charge' => 0,
            'is_free' => true,
            'reason' => 'No delivery rule configured',
        ];
    }

    /**
     * Returns a blocked response array if the order violates a rule limit,
     * or null if the order passes both checks.
     */
    private function checkBlockingConditions(
        DeliveryChargeRule $rule,
        float $subtotal,
        float $distanceKm
    ): ?array {
        if ($subtotal < $rule->min_order_amount) {
            return [
                'charge' => null,
                'is_free' => false,
                'blocked' => true,
                'reason' => "Minimum order amount is ₹{$rule->min_order_amount}",
                'min_order_amount' => $rule->min_order_amount,
            ];
        }

        if ($rule->max_delivery_km && $distanceKm > $rule->max_delivery_km) {
            return [
                'charge' => null,
                'is_free' => false,
                'blocked' => true,
                'reason' => "Delivery not available beyond {$rule->max_delivery_km} km",
            ];
        }

        return null;
    }

    private function qualifiesForFreeDelivery(DeliveryChargeRule $rule, float $subtotal): bool
    {
        return $rule->free_delivery_above && $subtotal >= $rule->free_delivery_above;
    }

    private function freeDeliveryResponse(DeliveryChargeRule $rule): array
    {
        return [
            'charge' => 0,
            'is_free' => true,
            'reason' => "Free delivery on orders above ₹{$rule->free_delivery_above}",
            'free_above_amount' => $rule->free_delivery_above,
        ];
    }

    private function calculateChargeResponse(
        DeliveryChargeRule $rule,
        float $subtotal,
        float $distanceKm
    ): array {
        $charge = $rule->base_charge + ($distanceKm * $rule->per_km_charge);

        if ($rule->max_charge) {
            $charge = min($charge, $rule->max_charge);
        }

        return [
            'charge' => round($charge, 2),
            'is_free' => false,
            'reason' => null,
            'free_above_amount' => $rule->free_delivery_above,
            'amount_for_free' => $rule->free_delivery_above
                                    ? max(0, $rule->free_delivery_above - $subtotal)
                                    : null,
        ];
    }
}
