<?php

namespace App\Services\V1\Orders;

use App\Models\Coupon;
use App\Models\Tenant\Customer;
use Illuminate\Support\Carbon;
use Illuminate\Validation\ValidationException;

class CouponService
{
    public function validate(string $code, float $subtotal, Customer $customer): array
    {
        $coupon = Coupon::where('code', strtoupper($code))
            ->where('is_active', true)
            ->first();

        if (! $coupon) {
            throw ValidationException::withMessages(['coupon' => 'Invalid coupon code.']);
        }

        $today = Carbon::today();

        if ($today->lt($coupon->valid_from)) {
            throw ValidationException::withMessages(['coupon' => 'Coupon is not yet active.']);
        }

        if ($coupon->valid_until && $today->gt($coupon->valid_until)) {
            throw ValidationException::withMessages(['coupon' => 'Coupon has expired.']);
        }

        if ($coupon->usage_limit_total && $coupon->used_count >= $coupon->usage_limit_total) {
            throw ValidationException::withMessages(['coupon' => 'Coupon usage limit reached.']);
        }

        if ($subtotal < $coupon->min_order_amount) {
            throw ValidationException::withMessages([
                'coupon' => "Minimum order of ₹{$coupon->min_order_amount} required for this coupon.",
            ]);
        }

        if ($coupon->is_first_order_only) {
            $hasPreviousOrder = $customer->orders()
                ->whereIn('status', ['confirmed', 'preparing', 'out_for_delivery', 'delivered'])
                ->exists();
            if ($hasPreviousOrder) {
                throw ValidationException::withMessages(['coupon' => 'This coupon is for first orders only.']);
            }
        }

        if ($coupon->usage_limit_per_customer) {
            $customerUsage = $coupon->usages()->where('customer_id', $customer->id)->count();
            if ($customerUsage >= $coupon->usage_limit_per_customer) {
                throw ValidationException::withMessages(['coupon' => 'You have already used this coupon.']);
            }
        }

        $discount = $this->computeDiscount($coupon, $subtotal);

        return [
            'coupon_id' => $coupon->id,
            'code' => $coupon->code,
            'description' => $coupon->description,
            'discount' => $discount,
            'type' => $coupon->type,
            'value' => $coupon->value,
        ];
    }

    private function computeDiscount(Coupon $coupon, float $subtotal): float
    {
        if ($coupon->type === 'flat') {
            return min($coupon->value, $subtotal);
        }

        $discount = $subtotal * ($coupon->value / 100);

        if ($coupon->max_discount_amount) {
            $discount = min($discount, $coupon->max_discount_amount);
        }

        return round($discount, 2);
    }
}
