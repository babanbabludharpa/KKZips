<?php

namespace App\Services\V1\Orders;

use App\Models\Invoice;
use App\Models\Tenant\Order;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Collection;

class InvoicePdfService
{
    public function build(Order $order)
    {
        $items = $order->items->map(function ($item) {
            $taxRate = (float) $item->tax_rate_percent;
            $isIgst = $item->tax_type === 'igst';

            return [
                // ★ FREE GIFTS — gift lines are labelled so the customer
                // and the delivery staff can tell them apart on the invoice.
                'name' => ($item->variant?->product?->name ?? 'Item').($item->is_gift ? ' — FREE GIFT' : ''),
                'is_gift' => (bool) $item->is_gift,
                'hsn_code' => $item->variant?->hsn_code ?? '—',
                'quantity' => $item->quantity,
                'unit_price' => $item->unit_price,
                'mrp' => $item->mrp,
                'discount_pct' => $item->discount_percent,
                'taxable_value' => $item->taxable_value,
                'tax_rate' => $taxRate,
                'is_igst' => $isIgst,
                'half_rate' => $isIgst ? null : round($taxRate / 2, 2),
                'cgst_amount' => $item->cgst_amount,
                'sgst_amount' => $item->sgst_amount,
                'igst_amount' => $item->igst_amount,
                'line_total' => $item->line_total,
            ];
        });

        $totals = [
            'taxable_value' => $order->items->sum('taxable_value'),
            'cgst' => $order->items->sum('cgst_amount'),
            'sgst' => $order->items->sum('sgst_amount'),
            'igst' => $order->items->sum('igst_amount'),
            'subtotal' => $order->subtotal,
            'delivery' => $order->delivery_charge,
            'coupon' => $order->coupon_discount,
            'total' => $order->total,
        ];

        return Pdf::loadView('invoices.tax_invoice', [
            'order' => $order,
            'branch' => $order->branch,
            'customer' => $order->customer,
            'address' => $order->delivery_address ?? [],
            'items' => $items,
            'totals' => $totals,
            'isIgst' => $order->items->first()?->tax_type === 'igst',
        ])->setPaper('a4');
    }

    public function buildForSubscriptionInvoice(Invoice $invoice)
    {
        return Pdf::loadView(
            'invoices.subscription_tax_invoice',
            $this->buildInvoiceViewData($invoice)
        )->setPaper('a4');
    }

    public function buildMultipleSubscriptionInvoices(Collection $invoices)
    {
        $invoicesData = $invoices->map(fn ($invoice) => $this->buildInvoiceViewData($invoice));

        return Pdf::loadView('invoices.subscription_tax_invoice_bulk', [
            'invoicesData' => $invoicesData,
        ])->setPaper('a4');
    }

    protected function buildInvoiceViewData(Invoice $invoice): array
    {
        $invoice->loadMissing([
            'items.occurrence.subscriptionItem.productVariant',
            'items.occurrence.subscriptionItem.subscription.branch',
            'items.occurrence.subscriptionItem.subscription.deliveryAddress',
            'customer',
        ]);

        $firstOccurrence = $invoice->items->first()?->occurrence;
        $branch = $firstOccurrence?->subscriptionItem?->subscription?->branch;
        $deliveryAddress = $firstOccurrence?->subscriptionItem?->subscription?->deliveryAddress;

        $items = $invoice->items->map(function ($item) {
            $variant = $item->occurrence?->subscriptionItem?->productVariant;
            $isIgst = $item->tax_type === 'igst';

            return [
                'name' => $item->description,
                'hsn_code' => $variant?->hsn_code ?? '—',
                'quantity' => $item->qty,
                'unit_price' => $item->unit_price,
                'mrp' => null,
                'discount_pct' => $item->discount_percent,
                'taxable_value' => $item->taxable_value,
                'tax_rate' => (float) $item->tax_rate_percent,
                'is_igst' => $isIgst,
                'half_rate' => $isIgst ? null : round($item->tax_rate_percent / 2, 2),
                'cgst_amount' => $item->cgst_amount,
                'sgst_amount' => $item->sgst_amount,
                'igst_amount' => $item->igst_amount,
                'line_total' => $item->line_total,
            ];
        });

        $totals = [
            'taxable_value' => $invoice->items->sum('taxable_value'),
            'cgst' => $invoice->cgst_total,
            'sgst' => $invoice->sgst_total,
            'igst' => $invoice->igst_total,
            'subtotal' => $invoice->subtotal,
            'manual_adjustment' => $invoice->manual_adjustment_amount,
            'total' => $invoice->total,
        ];

        return [
            'invoice' => $invoice,
            'customer' => $invoice->customer,
            'branch' => $branch,
            'deliveryAddress' => $deliveryAddress,
            'items' => $items,
            'totals' => $totals,
            'isIgst' => $invoice->items->first()?->tax_type === 'igst',
        ];
    }
}
