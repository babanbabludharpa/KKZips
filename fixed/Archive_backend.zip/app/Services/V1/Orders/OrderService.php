<?php

namespace App\Services\V1\Orders;

use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Inventory;
use App\Models\ProductVariant;
use App\Models\StockMovement;
use App\Models\Tenant\Order;
use App\Models\Tenant\OrderItem;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderService
{
    public function __construct(
        protected BranchAssignmentService $branchAssignment,
        protected DeliveryChargeService $deliveryCharge,
        protected CouponService $couponService,
        protected OrderNumberService $orderNumber,
        protected GiftService $giftService,
    ) {}

    public function preview(array $data, $customer): array
    {
        $assignment = $this->branchAssignment->assign(
            $data['lat'], $data['lng'], $data['items']
        );

        if (! $assignment['branch']) {
            throw ValidationException::withMessages([
                'location' => $assignment['reason'],
            ]);
        }

        $branch = $assignment['branch'];
        $isInterState = $this->resolveInterState($branch, $data);
        $itemStock = collect($assignment['item_stock'])->keyBy('variant_id');

        [$lineItems, $subtotal] = $this->buildLineItems(
            $data['items'],
            $itemStock,
            $isInterState
        );

        if (empty($lineItems)) {
            throw ValidationException::withMessages([
                'stock' => 'No items are available at your location.',
            ]);
        }

        return $this->buildPreviewPayload(
            $branch,
            $assignment['distance_km'],
            $isInterState,
            $lineItems,
            $subtotal,
            $customer,
            $data
        );
    }

    private function resolveInterState($branch, array $data): bool
    {
        $branchStateId = $branch->state_id ?? null;
        $deliveryStateId = $data['delivery_address']['state_id'] ?? null;

        return $branchStateId !== null
            && $deliveryStateId !== null
            && $branchStateId !== $deliveryStateId;
    }

    /**
     * @return array{0: array, 1: float} [lineItems, subtotal]
     */
    private function buildLineItems(array $items, $itemStock, bool $isInterState): array
    {
        $lineItems = [];
        $subtotal = 0;

        foreach ($items as $item) {
            $line = $this->buildLineItem($item, $itemStock, $isInterState);

            if ($line === null) {
                continue;
            }

            $subtotal += $line['line_total'];
            $lineItems[] = $line;
        }

        return [$lineItems, $subtotal];
    }

    private function buildLineItem(array $item, $itemStock, bool $isInterState): ?array
    {
        $variant = ProductVariant::with(['discountSchedules', 'taxRate'])->findOrFail($item['variant_id']);

        // ★ FREE GIFTS — hard gate. Gift variants exist only to be granted
        // by GiftService when a threshold is crossed; they can never be
        // ordered manually, even by a crafted API request.
        if ($variant->is_gift) {
            throw ValidationException::withMessages([
                'items' => "Gift item ({$variant->sku}) cannot be added to the cart manually.",
            ]);
        }

        $stock = $itemStock[$item['variant_id']] ?? null;
        $available = $stock['available'] ?? 0;
        $qty = min($item['quantity'], $available);

        if ($qty === 0) {
            return null;
        }

        $unitPrice = (float) $variant->selling_price;
        $mrp = (float) $variant->mrp;
        [$discountPct, $finalPrice] = $this->resolveFinalPrice($variant, $unitPrice);

        $taxRatePercent = $variant->taxRate->percentage ?? 0;
        $taxableValue = $taxRatePercent > 0
            ? round($finalPrice / (1 + $taxRatePercent / 100), 2)
            : $finalPrice;
        $taxAmountPerUnit = round($finalPrice - $taxableValue, 2);
        $lineTaxAmount = round($taxAmountPerUnit * $qty, 2);

        $taxBreakdown = $this->splitTax($lineTaxAmount, $isInterState);

        $lineTotal = round($finalPrice * $qty, 2);

        return [
            'variant_id' => $variant->id,
            'variant_sku' => $variant->sku,
            'product_name' => $variant->product->name ?? '',
            'quantity' => $qty,
            'quantity_original' => $item['quantity'],
            'unit_price' => $unitPrice,
            'mrp' => $mrp,
            'discount_percent' => $discountPct,
            'final_price' => $finalPrice,
            'line_total' => $lineTotal,
            'available_stock' => $available,
            'is_low_stock' => $available <= 5,
            'adjusted_qty' => $qty < $item['quantity'],
            'tax_rate_percent' => $taxRatePercent,
            'tax_amount' => $lineTaxAmount,
            'taxable_value' => round($taxableValue * $qty, 2),
            'tax_type' => $taxBreakdown['tax_type'],
            'cgst_amount' => $taxBreakdown['cgst_amount'],
            'sgst_amount' => $taxBreakdown['sgst_amount'],
            'igst_amount' => $taxBreakdown['igst_amount'],
        ];
    }

    /**
     * @return array{0: float, 1: float} [discountPct, finalPrice]
     */
    private function resolveFinalPrice(ProductVariant $variant, float $unitPrice): array
    {
        if (! $variant->is_discount_active) {
            return [0, $unitPrice];
        }

        $activeDiscount = $variant->discountSchedules()
            ->where('status', 'active')->first();

        if (! $activeDiscount) {
            return [0, $unitPrice];
        }

        $discountPct = (float) $activeDiscount->discount_percent;

        return [$discountPct, round($unitPrice * (1 - $discountPct / 100), 2)];
    }

    /**
     * @return array{tax_type: string, cgst_amount: float, sgst_amount: float, igst_amount: float}
     */
    private function splitTax(float $lineTaxAmount, bool $isInterState): array
    {
        if ($isInterState) {
            return [
                'tax_type' => 'igst',
                'cgst_amount' => 0,
                'sgst_amount' => 0,
                'igst_amount' => $lineTaxAmount,
            ];
        }

        $cgstAmount = round($lineTaxAmount / 2, 2);

        return [
            'tax_type' => 'cgst_sgst',
            'cgst_amount' => $cgstAmount,
            'sgst_amount' => round($lineTaxAmount - $cgstAmount, 2),
            'igst_amount' => 0,
        ];
    }

    private function buildPreviewPayload(
        $branch,
        float $distanceKm,
        bool $isInterState,
        array $lineItems,
        float $subtotal,
        $customer,
        array $data
    ): array {
        $deliveryResult = $this->deliveryCharge->calculate($subtotal, $distanceKm);

        if ($deliveryResult['blocked'] ?? false) {
            throw ValidationException::withMessages([
                'delivery' => $deliveryResult['reason'],
            ]);
        }

        $deliveryChargeAmount = $deliveryResult['charge'] ?? 0;

        $couponData = null;
        $couponDiscount = 0;

        if (! empty($data['coupon_code'])) {
            $couponData = $this->couponService->validate($data['coupon_code'], $subtotal, $customer);
            $couponDiscount = $couponData['discount'];
        }

        $total = max(0, $subtotal + $deliveryChargeAmount - $couponDiscount);

        // ★ FREE GIFTS — resolve earned gifts for this cart (read-side;
        // the customer's coupon-adjusted subtotal decides the tier).
        $gifts = $this->giftService->resolveForCart(
            $subtotal,
            $couponDiscount,
            $branch->id,
            $customer
        );

        return [
            'branch_id' => $branch->id,
            'branch_code' => $branch->code,
            'branch_name' => $branch->name,
            'distance_km' => $distanceKm,
            'is_inter_state' => $isInterState,
            'items' => $lineItems,
            'subtotal' => round($subtotal, 2),
            'delivery_charge' => $deliveryChargeAmount,
            'delivery_info' => $deliveryResult,
            'coupon' => $couponData,
            'coupon_discount' => $couponDiscount,
            'gifts' => $gifts,
            'total' => round($total, 2),
        ];
    }

    public function place(array $data, $customer): Order
    {
        return DB::transaction(function () use ($data, $customer) {
            $preview = $this->preview($data, $customer);
            $orderNumberValue = $this->orderNumber->next($preview['branch_id'], $preview['branch_code']);

            $order = Order::create([
                'order_number' => $orderNumberValue,
                'customer_id' => $customer->id,
                'branch_id' => $preview['branch_id'],
                'status' => $data['payment_mode'] === 'cod' ? 'confirmed' : 'pending_payment',
                'payment_mode' => $data['payment_mode'],
                'payment_status' => 'pending',
                'delivery_address' => $data['delivery_address'],
                'customer_lat' => $data['lat'],
                'customer_lng' => $data['lng'],
                'subtotal' => $preview['subtotal'],
                'delivery_charge' => $preview['delivery_charge'],
                'coupon_code' => $preview['coupon']['code'] ?? null,
                'coupon_discount' => $preview['coupon_discount'],
                'total' => $preview['total'],
                'customer_remark' => $data['customer_remark'] ?? null,
                'delivery_slot_id'      => $data['delivery_slot_id'] ?? null,
                'delivery_date'         => $data['delivery_date'] ?? null,
                'uses_slot_at_checkout' => $data['uses_slot_at_checkout'] ?? false,
            ]);

            foreach ($preview['items'] as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_variant_id' => $item['variant_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'mrp' => $item['mrp'],
                    'discount_percent' => $item['discount_percent'],
                    'final_price' => $item['final_price'],
                    'line_total' => $item['line_total'],
                    'tax_rate_percent' => $item['tax_rate_percent'],
                    'tax_amount' => $item['tax_amount'],
                    'taxable_value' => $item['taxable_value'],
                    'tax_type' => $item['tax_type'],
                    'cgst_amount' => $item['cgst_amount'],
                    'sgst_amount' => $item['sgst_amount'],
                    'igst_amount' => $item['igst_amount'],
                ]);

                Inventory::where('product_variant_id', $item['variant_id'])
                    ->where('branch_id', $preview['branch_id'])
                    ->increment('quantity_reserved', $item['quantity']);
            }

            if ($preview['coupon']) {
                CouponUsage::create([
                    'coupon_id' => $preview['coupon']['coupon_id'],
                    'customer_id' => $customer->id,
                    'order_id' => $order->id,
                    'discount_applied' => $preview['coupon_discount'],
                    'used_at' => now(),
                ]);

                Coupon::where('id', $preview['coupon']['coupon_id'])->increment('used_count');
            }

            // ★ FREE GIFTS — authoritative attach (same transaction).
            // Re-validates caps + branch stock under lock; gift lines are
            // written as order_items at ₹0 and their stock is reserved.
            if (! empty($preview['gifts']['earned'])) {
                $this->giftService->attachToOrder($order, $preview['gifts'], $customer);
            }

            if ($data['payment_mode'] === 'cod') {
                $this->confirmStock($order);
            }

            return $order->load('items.variant.product');
        });
    }

    public function confirmStock(Order $order): void
    {
        foreach ($order->items as $item) {
            $inventory = Inventory::where('product_variant_id', $item->product_variant_id)
                ->where('branch_id', $order->branch_id)
                ->first();

            if ($inventory) {
                $inventory->decrement('quantity', $item->quantity);
                $inventory->decrement('quantity_reserved', $item->quantity);

                StockMovement::create([
                    'product_variant_id' => $item->product_variant_id,
                    'branch_id' => $order->branch_id,
                    'type' => 'order',
                    'opening_stock' => $inventory->quantity + $item->quantity,
                    'in' => 0,
                    'out' => $item->quantity,
                    'closing_stock' => $inventory->quantity,
                    'transaction_date' => now()->toDateString(),
                    'reference_id' => 'ORD-'.$order->id,
                    'created_by' => null,
                ]);
            }
        }
    }

    public function releaseStock(Order $order): void
    {
        foreach ($order->items as $item) {
            Inventory::where('product_variant_id', $item->product_variant_id)
                ->where('branch_id', $order->branch_id)
                ->decrement('quantity_reserved', $item->quantity);
        }
    }
}
