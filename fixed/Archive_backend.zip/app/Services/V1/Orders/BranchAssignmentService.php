<?php

namespace App\Services\V1\Orders;

use App\Models\Branch;
use App\Models\Inventory;

class BranchAssignmentService
{
    private const MSG_NO_DELIVERY = 'No delivery available at your location.';

    private const MSG_BRANCH_UNAVAILABLE = 'Assigned branch is currently unavailable.';

    private const MSG_BRANCH_NO_LOCATION = 'Assigned branch is missing location data.';

    private const EARTH_RADIUS_KM = 6371;

    public function __construct(private ZoneCheckService $zoneCheck) {}

    public function assign(float $lat, float $lng, array $items): array
    {
        $branch = $this->resolveBranch($lat, $lng);

        if (is_array($branch)) {
            return $branch;
        }

        return $this->buildAssignmentResult($branch, $lat, $lng, $items);
    }

    /**
     * Resolves the branch for the given point. Returns a Branch on success,
     * or an array of the shape ['branch' => null, 'reason' => '...'] on failure.
     */
    private function resolveBranch(float $lat, float $lng): Branch|array
    {
        $zoneResult = $this->zoneCheck->checkPoint($lat, $lng);

        if (! $zoneResult['serviceable'] || $zoneResult['branch_id'] === null) {
            return $this->branchFailure(self::MSG_NO_DELIVERY);
        }

        $branch = Branch::where('is_active', true)
            ->where('is_accepting_orders', true)
            ->find($zoneResult['branch_id']);

        return $this->validateBranch($branch);
    }

    /**
     * Returns the Branch if it is valid (exists and has location data), or
     * a failure array explaining why not.
     */
    private function validateBranch(?Branch $branch): Branch|array
    {
        if (! $branch) {
            return $this->branchFailure(self::MSG_BRANCH_UNAVAILABLE);
        }

        if ($branch->latitude === null || $branch->longitude === null) {
            return $this->branchFailure(self::MSG_BRANCH_NO_LOCATION);
        }

        return $branch;
    }

    private function branchFailure(string $reason): array
    {
        return ['branch' => null, 'reason' => $reason];
    }

    private function buildAssignmentResult(Branch $branch, float $lat, float $lng, array $items): array
    {
        $distance = $this->haversine($lat, $lng, $branch->latitude, $branch->longitude);
        $stockCheck = $this->checkStock($branch->id, $items);

        return [
            'branch' => $branch,
            'distance_km' => round($distance, 2),
            'item_stock' => $stockCheck['items'],
            'has_full_stock' => $stockCheck['has_full_stock'],
        ];
    }

    private function checkStock(int $branchId, array $items): array
    {
        $hasFullStock = true;
        $result = [];

        foreach ($items as $item) {
            $inventory = Inventory::where('product_variant_id', $item['variant_id'])
                ->where('branch_id', $branchId)
                ->first();

            $available = $inventory
                ? max(0, $inventory->quantity - $inventory->quantity_reserved)
                : 0;

            $requested = $item['quantity'];
            $canFulfill = $available >= $requested;

            if (! $canFulfill) {
                $hasFullStock = false;
            }

            $result[] = [
                'variant_id' => $item['variant_id'],
                'requested' => $requested,
                'available' => $available,
                'can_fulfill' => $canFulfill,
                'is_low_stock' => $available > 0 && $available <= 5,
            ];
        }

        return ['has_full_stock' => $hasFullStock, 'items' => $result];
    }

    private function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2
           + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return self::EARTH_RADIUS_KM * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }
}
