<?php

namespace App\Services\V1\Orders;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class OrderNumberService
{
    /**
     * Must be called from inside an existing DB::transaction().
     * This method does NOT open its own transaction -- it relies on the
     * caller's transaction for atomicity, and uses lockForUpdate() to
     * serialize concurrent requests on the same branch+FY row.
     */
    public function next(int $branchId, string $branchCode): string
    {
        $fy = $this->currentFinancialYear();

        // Row-level lock: if the branch+FY row doesn't exist yet, insertOrIgnore
        // creates it first so the subsequent lockForUpdate has something to lock.
        // insertOrIgnore avoids a duplicate-key exception if two requests race
        // to create the row simultaneously -- one wins, both proceed to lock+read.
        DB::table('order_number_sequences')->insertOrIgnore([
            'branch_id' => $branchId,
            'financial_year' => $fy,
            'last_number' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $row = DB::table('order_number_sequences')
            ->where('branch_id', $branchId)
            ->where('financial_year', $fy)
            ->lockForUpdate()
            ->first();

        $next = $row->last_number + 1;

        DB::table('order_number_sequences')
            ->where('branch_id', $branchId)
            ->where('financial_year', $fy)
            ->update(['last_number' => $next, 'updated_at' => now()]);

        $sequence = str_pad((string) $next, 6, '0', STR_PAD_LEFT);

        return "{$branchCode}-{$fy}-{$sequence}";
    }

    public function currentFinancialYear(): string
    {
        $now = Carbon::now();
        $year = $now->year;

        // FY runs Apr 1 -> Mar 31. Jan-Mar belongs to the FY that started
        // the previous calendar year.
        $startYear = $now->month >= 4 ? $year : $year - 1;
        $endYear = $startYear + 1;

        return substr((string) $startYear, -2).substr((string) $endYear, -2);
    }
}
