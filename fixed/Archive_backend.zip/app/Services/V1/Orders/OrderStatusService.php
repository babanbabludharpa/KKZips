<?php

namespace App\Services\V1\Orders;

use App\Events\OrderStatusUpdated;
use App\Models\Tenant\Order;
use App\Models\Tenant\OrderStatusHistory;
use App\Models\User;
use App\Services\V1\Notifications\PushNotificationService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class OrderStatusService
{
    // Forward-only sequence. No skipping, no going backwards. 'delivered'
    // has no further transitions from here.
    private const SEQUENCE = ['confirmed', 'preparing', 'out_for_delivery', 'picked_up', 'delivered'];

    public function transitionTo(Order $order, string $toStatus, User $actor, ?int $deliveryBoyId = null, ?string $notes = null): Order
    {
        $this->assertValidTransition($order->status, $toStatus);

        if ($deliveryBoyId !== null) {
            $this->assertDeliveryBoyValid($deliveryBoyId, $order->branch_id);
        }

        return DB::transaction(function () use ($order, $toStatus, $actor, $deliveryBoyId, $notes) {
            $fromStatus = $order->status;

            $updates = ['status' => $toStatus];
            if ($deliveryBoyId !== null) {
                $updates['delivery_boy_id'] = $deliveryBoyId;
            }
            if ($toStatus === 'out_for_delivery' && ! $order->assigned_at) {
                $updates['assigned_at'] = now();
            }
            if ($toStatus === 'delivered') {
                $updates['delivered_at'] = now();
            }

            $order->update($updates);

            OrderStatusHistory::create([
                'order_id' => $order->id,
                'from_status' => $fromStatus,
                'to_status' => $toStatus,
                'delivery_boy_id' => $order->delivery_boy_id,
                'changed_by' => $actor->id,
                'notes' => $notes,
            ]);

            $updatedOrder = $order->fresh();

            // Deferred until the transaction actually commits -- guarantees
            // any client that receives this event and immediately refetches
            // the order will read committed data, not a pre-commit snapshot
            // it can race ahead of. Previously event() fired mid-transaction
            // (ShouldBroadcastNow doesn't wait for commit), which raced
            // against slow post-event code (the FCM call) and caused clients
            // to fetch stale data.
            DB::afterCommit(function () use ($updatedOrder, $toStatus) {
                event(new OrderStatusUpdated($updatedOrder));

                try {
                    app(PushNotificationService::class)->sendOrderStatusUpdate($updatedOrder, $toStatus);
                } catch (\Throwable $e) {
                    Log::error('Push notification failed', [
                        'order_id' => $updatedOrder->id,
                        'error' => $e->getMessage(),
                    ]);
                }
            });

            return $updatedOrder;
        });
    }

    private function assertValidTransition(string $from, string $to): void
    {
        $fromIndex = array_search($from, self::SEQUENCE, true);
        $toIndex = array_search($to, self::SEQUENCE, true);

        if ($toIndex === false) {
            throw ValidationException::withMessages([
                'status' => "'{$to}' is not a valid order status.",
            ]);
        }

        if ($fromIndex === false) {
            // Current status isn't even in the forward sequence (e.g.
            // 'payment_failed', 'cancelled', 'pending_payment'). None of
            // those should ever be moved into 'preparing' etc through this
            // service -- that would need a distinct
            // reactivate/reconfirm path, not a status bump.
            throw ValidationException::withMessages([
                'status' => "Order is not in a state that can be progressed ({$from}).",
            ]);
        }

        if ($toIndex <= $fromIndex) {
            throw ValidationException::withMessages([
                'status' => "Cannot move from '{$from}' back to '{$to}'.",
            ]);
        }

        if ($toIndex > $fromIndex + 1) {
            throw ValidationException::withMessages([
                'status' => "Cannot skip from '{$from}' directly to '{$to}'.",
            ]);
        }
    }

    private function assertDeliveryBoyValid(int $deliveryBoyId, int $branchId): void
    {
        // Role slug and guard confirmed against RolesAndPermissionsSeeder:
        // Role::firstOrCreate(['name' => 'delivery_boy', 'guard_name' => 'sanctum']).
        // Guard passed explicitly rather than relying on implicit default
        // resolution, since every permission/role in that seeder is
        // created under 'sanctum', not Spatie's usual 'web' default.
        $valid = User::role('delivery_boy', 'sanctum')
            ->where('id', $deliveryBoyId)
            ->where('branch_id', $branchId)
            ->exists();

        if (! $valid) {
            throw ValidationException::withMessages([
                'delivery_boy_id' => 'Selected delivery boy is not valid for this branch.',
            ]);
        }
    }
}
