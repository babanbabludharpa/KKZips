<?php

namespace App\Exceptions;

use RuntimeException;

class WalletTopupNotRefundableException extends RuntimeException
{
}
