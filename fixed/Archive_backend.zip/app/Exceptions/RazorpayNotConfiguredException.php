<?php

namespace App\Exceptions;

use RuntimeException;

class RazorpayNotConfiguredException extends RuntimeException
{
}
