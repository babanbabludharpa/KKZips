<?php

namespace App\Exceptions;

use Exception;

class InsufficientWalletBalanceException extends Exception
{
    public function __construct(
        public readonly float $required,
        public readonly float $available,
        string $message = ''
    ) {
        parent::__construct($message ?: sprintf(
            'Insufficient wallet balance. You need ₹%s more.',
            number_format(max(0, $required - $available), 2)
        ));
    }
}