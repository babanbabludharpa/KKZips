<?php

namespace App\Http\Middleware;

use App\Models\TenantProfile;
use Closure;
use Illuminate\Http\Request;

class ApplyTenantBroadcastConfig
{
    /**
     * Must run AFTER tenancy()->initialize() so TenantProfile queries hit
     * the correct tenant DB connection. Wire this in immediately after
     * InitializeMobileTenancy / InitializeTenancyBySubdomainMiddleware in
     * the middleware stack -- order matters, this is not standalone.
     */
    public function handle(Request $request, Closure $next)
    {
        $profile = TenantProfile::first();

        if (
            $profile
            && $profile->pusher_app_id
            && $profile->pusher_key
            && $profile->pusher_secret
            && $profile->pusher_cluster
        ) {
            config([
                'broadcasting.connections.pusher.app_id' => $profile->pusher_app_id,
                'broadcasting.connections.pusher.key' => $profile->pusher_key,
                'broadcasting.connections.pusher.secret' => $profile->pusher_secret,
                'broadcasting.connections.pusher.options.cluster' => $profile->pusher_cluster,
            ]);
        } else {
            // Deliberately loud, not silent. A tenant with incomplete
            // Pusher config falling back to .env defaults would mean
            // events broadcast under the WRONG Pusher app -- worse than
            // failing outright, since it looks like it's working.
            report(new \RuntimeException(
                'Tenant Pusher config incomplete or missing -- broadcasting will use .env defaults for tenant: '
                .(tenant('id') ?? 'unknown')
            ));
        }

        return $next($request);
    }
}
