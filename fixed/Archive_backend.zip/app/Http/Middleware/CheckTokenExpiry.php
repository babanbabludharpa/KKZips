<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class CheckTokenExpiry
{
    /**
     * Handle an incoming request.
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();

        if ($user && method_exists($user, 'currentAccessToken')) {
            $token = $user->currentAccessToken();

            if ($token && $token->expires_at) {
                $expiresAt = Carbon::parse($token->expires_at);

                if (now()->greaterThan($expiresAt)) {
                    // revoke expired token
                    $token->delete();

                    return response()->json([
                        'status' => false,
                        'message' => 'Token expired',
                        'data' => null,
                    ], 401);
                }
            }
        }

        return $next($request);
    }
}
