<?php

namespace App\Http\Middleware;

use App\Models\DeliveryBoy;
use App\Models\User;
use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;
use Symfony\Component\HttpFoundation\Response;

class MobileRiderAuth
{
    private const MSG_UNAUTHENTICATED_LOGIN = 'Unauthenticated. Please log in.';
    private const MSG_INVALID_TOKEN = 'Invalid or expired token.';
    private const MSG_RIDER_REQUIRED = 'Access denied. Rider account required.';
    private const MSG_INACTIVE = 'Access denied. Rider account is inactive.';

    public function handle(Request $request, Closure $next): Response
    {
        $rider = $this->resolveRiderFromRequest($request);

        if ($rider instanceof JsonResponse) {
            return $rider;
        }

        auth('rider')->setUser($rider);
        auth()->setUser($rider);

        return $next($request);
    }

    private function resolveRiderFromRequest(Request $request): mixed
    {
        $token = $request->bearerToken();

        if (! $token) {
            return $this->errorResponse(self::MSG_UNAUTHENTICATED_LOGIN, 401);
        }

        $accessToken = PersonalAccessToken::findToken($token);

        if (! $accessToken) {
            return $this->errorResponse(self::MSG_INVALID_TOKEN, 401);
        }

        $tokenable = $accessToken->tokenable;

        // New path: token bound to a DeliveryBoy row.
        if ($tokenable instanceof DeliveryBoy) {
            if (! $tokenable->is_active) {
                return $this->errorResponse(self::MSG_INACTIVE, 403);
            }
            return $tokenable;
        }

        // Legacy path: token bound to a User with the delivery_boy role.
        // Kept so riders who logged in before the migration are not kicked
        // out until their token expires. Remove this branch after the
        // rider app has fully migrated to mobile_number + password.
        if ($tokenable instanceof User && $tokenable->hasRole('delivery_boy', 'sanctum')) {
            return $tokenable;
        }

        return $this->errorResponse(self::MSG_RIDER_REQUIRED, 403);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
        ], $status);
    }
}
