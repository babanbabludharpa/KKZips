<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Stancl\Tenancy\Database\Models\Domain;

class InitializeMobileTenancy
{
    public function handle(Request $request, Closure $next)
    {
        $tenantId = $request->header('X-Tenant');

        if (! $tenantId) {
            return response()->json([
                'status' => false,
                'message' => 'Tenant header missing.',
                'data' => [],
            ], 400);
        }

        $domain = Domain::where('domain', $tenantId)->first();

        if (! $domain) {
            return response()->json([
                'status' => false,
                'message' => 'Tenant not found.',
                'data' => [],
            ], 404);
        }

        tenancy()->initialize($domain->tenant);

        return $next($request);
    }
}
