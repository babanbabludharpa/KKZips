<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Stancl\Tenancy\Database\Models\Domain;
use Stancl\Tenancy\Middleware\InitializeTenancyBySubdomain;

class InitializeTenancyBySubdomainMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (str_contains($request->path(), 'api/v1/mobile')) {
            return $next($request);
        }
        $headerTenant = $request->header('X-Tenant');
        if ($headerTenant) {
            $domain = Domain::where('domain', $headerTenant)->first();
            if ($domain) {
                tenancy()->initialize($domain->tenant);
            }
            return $next($request);
        }
        $host = $request->getHost();
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $next($request);
        }
        $centralDomains = config('tenancy.central_domains', []);

        if (in_array($host, $centralDomains, true)) {
            return $next($request);
        }

        $subdomain = explode('.', $host)[0];
        $domain    = Domain::where('domain', $subdomain)->first();

        if (!$domain) {
            // For web requests, return JSON error; for HTML, fall through
            // (Laravel will show 404 or default error page).
            if ($request->expectsJson()) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Tenant not found for subdomain: ' . $subdomain,
                    'data'    => [],
                ], 404);
            }
            return $next($request);
        }

        tenancy()->initialize($domain->tenant);

        return $next($request);
    }
}
