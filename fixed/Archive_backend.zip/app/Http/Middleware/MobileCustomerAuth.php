<?php

namespace App\Http\Middleware;

use App\Models\Tenant\Customer;
use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

class MobileCustomerAuth
{
    private const MSG_UNAUTHENTICATED = 'Unauthenticated.';

    private const MSG_ACCOUNT_INACTIVE = 'Account is not active.';

    public function handle(Request $request, Closure $next)
    {
        $customer = $this->resolveAuthenticatedCustomer($request);

        if ($customer instanceof JsonResponse) {
            return $customer;
        }

        if (! $customer->isActive()) {
            return $this->errorResponse(self::MSG_ACCOUNT_INACTIVE, 403);
        }

        $request->setUserResolver(fn () => $customer);

        return $next($request);
    }

    /**
     * Returns a 401 JsonResponse if the token is missing/invalid/not a
     * customer, or the resolved Customer model on success.
     */
    private function resolveAuthenticatedCustomer(Request $request): Customer|JsonResponse
    {
        $token = $request->bearerToken();

        if (! $token) {
            return $this->errorResponse(self::MSG_UNAUTHENTICATED, 401);
        }

        $pat = PersonalAccessToken::findToken($token);

        if (! $pat || ! $pat->tokenable instanceof Customer) {
            return $this->errorResponse(self::MSG_UNAUTHENTICATED, 401);
        }

        return $pat->tokenable;
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
            'data' => [],
        ], $status);
    }
}
