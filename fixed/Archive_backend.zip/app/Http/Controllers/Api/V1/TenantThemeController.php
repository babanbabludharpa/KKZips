<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Tenant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TenantThemeController extends Controller
{
    private function validKeys(): array
    {
        return array_keys(config('themes', []));
    }

    public function updateByPlatformAdmin(Request $request, string $tenantId): JsonResponse
    {
        $data = $request->validate([
            'theme_key' => ['required', 'string', Rule::in($this->validKeys())],
            'custom_tokens' => ['nullable', 'array'],
        ]);

        $tenant = Tenant::find($tenantId);
        if (! $tenant) {
            return response()->json(['status' => false, 'message' => 'Tenant not found.', 'data' => []], 404);
        }

        $tenant->theme_key = $data['theme_key'];
        $tenant->custom_tokens = null;
        $tenant->save();

        return response()->json([
            'status' => true,
            'message' => 'Theme updated successfully.',
            'data' => ['theme_key' => $tenant->theme_key],
        ]);
    }

    public function updateByTenant(Request $request): JsonResponse
    {
        $data = $request->validate([
            'theme_key' => ['required', 'string', Rule::in($this->validKeys())],
        ]);

        if (! $request->user()->hasPermissionTo('manage_settings')) {
            return response()->json([
                'status' => false,
                'message' => 'You do not have permission to change the store appearance.',
                'data' => [],
            ], 403);
        }

        $tenantId = tenancy()->tenant->getTenantKey();
        $tenant = Tenant::find($tenantId);
        if (! $tenant) {
            return response()->json(['status' => false, 'message' => 'Tenant not found.', 'data' => []], 404);
        }

        $tenant->theme_key = $data['theme_key'];
        $tenant->custom_tokens = null;
        $tenant->save();

        return response()->json([
            'status' => true,
            'message' => 'Appearance updated successfully.',
            'data' => ['theme_key' => $data['theme_key']],
        ]);
    }
}
