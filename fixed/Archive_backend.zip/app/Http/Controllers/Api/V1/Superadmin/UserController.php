<?php

namespace App\Http\Controllers\Api\V1\Superadmin;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\UserResource;
use App\Models\User;
use App\Services\V1\Superadmin\UserService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpFoundation\StreamedResponse;

class UserController extends Controller
{
    private const BRANCH_ROLES = ['staff_headoffice', 'staff_stateoffice', 'staff_branch'];

    public function __construct(protected UserService $service) {}

    public function index(Request $request): JsonResponse|StreamedResponse
    {
        $filters = $request->only(['search', 'role', 'branch_id', 'per_page', 'sort_key', 'sort_dir']);

        if ($request->query('export') === 'csv') {
            return $this->service->exportCsv($filters);
        }

        $users = $this->service->getAll($filters);

        return response()->json([
            'status' => true,
            'message' => 'Users retrieved successfully.',
            'data' => [
                'users' => UserResource::collection($users)->resolve(),
                'meta' => [
                    'current_page' => $users->currentPage(),
                    'last_page' => $users->lastPage(),
                    'per_page' => $users->perPage(),
                    'total' => $users->total(),
                    'from' => $users->firstItem(),
                    'to' => $users->lastItem(),
                ],
            ],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $user = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'User retrieved successfully.',
            'data' => ['user' => new UserResource($user)],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate(array_merge([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', Rule::unique('users', 'email')],
            'username' => [
                'required', 'string', 'min:3', 'max:30',
                'regex:/^[a-z][a-z0-9_.]*$/',
                Rule::unique('users', 'username'),
            ],
            'mobile_number' => [
                'required', 'string', 'regex:/^[6-9]\d{9}$/',
                Rule::unique('users', 'mobile_number'),
            ],
            'password' => ['required', 'string', 'min:8'],
            'role' => ['required', 'string', 'exists:roles,name', Rule::notIn(['delivery_boy'])],
            'branch_id' => [
                Rule::requiredIf(in_array($request->role, self::BRANCH_ROLES)),
                'nullable', 'integer', 'exists:branches,id',
            ],
        ], $this->kycRules($request)));

        $user = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'User created successfully.',
            'data' => ['user' => new UserResource($user)],
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $user = $this->service->findById($id);

        $validated = $request->validate(array_merge([
            'name' => ['sometimes', 'string', 'max:100'],
            'email' => ['sometimes', 'email', Rule::unique('users', 'email')->ignore($user->id)],
            'username' => [
                'sometimes', 'required', 'string', 'min:3', 'max:30',
                'regex:/^[a-z][a-z0-9_.]*$/',
                Rule::unique('users', 'username')->ignore($user->id),
            ],
            'mobile_number' => [
                'sometimes', 'required', 'string', 'regex:/^[6-9]\d{9}$/',
                Rule::unique('users', 'mobile_number')->ignore($user->id),
            ],
            'password' => ['sometimes', 'nullable', 'string', 'min:8'],
            'role' => ['sometimes', 'string', 'exists:roles,name', Rule::notIn(['delivery_boy'])],
            'branch_id' => [
                Rule::requiredIf(in_array($request->role, self::BRANCH_ROLES)),
                'nullable', 'integer', 'exists:branches,id',
            ],
        ], $this->kycRules($request, $user)));

        $user = $this->service->update($user, $validated);

        return response()->json([
            'status' => true,
            'message' => 'User updated successfully.',
            'data' => ['user' => new UserResource($user)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $user = $this->service->findById($id);
        $this->service->delete($user);

        return response()->json([
            'status' => true,
            'message' => 'User deleted successfully.',
            'data' => [],
        ]);
    }

    public function assignRole(Request $request, int $id): JsonResponse
    {
        $user = $this->service->findById($id);

        $validated = $request->validate([
            'role' => ['required', 'string', 'exists:roles,name', Rule::notIn(['delivery_boy'])],
        ]);

        $user = $this->service->assignRole($user, $validated['role']);

        return response()->json([
            'status' => true,
            'message' => 'Role assigned successfully.',
            'data' => ['user' => new UserResource($user)],
        ]);
    }

    private function kycRules(Request $request, ?User $user = null): array
    {
        $role = $request->input('role', $user?->getRoleNames()->first());
        $needs = in_array($role, UserService::KYC_ROLES, true);

        $doc = ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'];

        return [
            'adhar_no' => [
                Rule::requiredIf($needs && ! $user?->adhar_hash),
                'nullable', 'digits:12',
                function ($attr, $value, $fail) use ($user) {
                    if (! $value) {
                        return;
                    }
                    $taken = User::where('adhar_hash', UserService::adharHash($value))
                        ->when($user, fn ($q) => $q->where('id', '!=', $user->id))
                        ->exists();
                    if ($taken) {
                        $fail('This Aadhaar number is already registered.');
                    }
                },
            ],
            'adhar_doc' => array_merge([Rule::requiredIf($needs && ! $user?->adhar_doc)], $doc),
            'pan_no'    => ['nullable', 'regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/'],
            'pan_doc'   => $doc,

            'emergency_contact_no' => ['nullable', 'regex:/^[6-9]\d{9}$/'],

            'bank_account_holder' => ['nullable', 'string', 'max:100', 'required_with:bank_account_no'],
            'bank_name'           => ['nullable', 'string', 'max:100'],
            'bank_account_no'     => ['nullable', 'digits_between:9,18'],
            'bank_ifsc'           => ['nullable', 'regex:/^[A-Z]{4}0[A-Z0-9]{6}$/', 'required_with:bank_account_no'],
            'upi_id'              => ['nullable', 'regex:/^[\w.\-]{2,256}@[a-zA-Z]{2,64}$/'],
        ];
    }
}
