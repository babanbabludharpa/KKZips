<?php

namespace App\Http\Controllers\Api\V1\Superadmin;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\MenuResource;
use App\Services\V1\Superadmin\MenuService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function __construct(protected MenuService $service) {}

    // Public (authenticated) — sidebar uses this
    public function sidebar(Request $request): JsonResponse
    {
        $permissions = $request->user()->getAllPermissions()->pluck('name')->toArray();
        $tree = $this->service->getFilteredTree($permissions);

        return response()->json([
            'status' => true,
            'message' => 'Menu retrieved successfully.',
            'data' => ['menus' => MenuResource::collection($tree)],
        ]);
    }

    // Superadmin — full unfiltered list for management UI
    public function index(): JsonResponse
    {
        $tree = $this->service->getFullTree();

        return response()->json([
            'status' => true,
            'message' => 'Menus retrieved successfully.',
            'data' => [
                'menus' => MenuResource::collection($tree),
                'flat' => MenuResource::collection($this->service->getAll()),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'route' => ['nullable', 'string', 'max:200'],
            'icon' => ['nullable', 'string', 'max:100'],
            'parent_id' => ['nullable', 'integer', 'exists:menus,id'],
            'permission' => ['nullable', 'string', 'exists:permissions,name'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['boolean'],
        ]);

        $menu = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Menu created successfully.',
            'data' => ['menu' => new MenuResource($menu)],
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $menu = $this->service->findById($id);
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'route' => ['nullable', 'string', 'max:200'],
            'icon' => ['nullable', 'string', 'max:100'],
            'parent_id' => ['nullable', 'integer', 'exists:menus,id'],
            'permission' => ['nullable', 'string', 'exists:permissions,name'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['boolean'],
        ]);

        $menu = $this->service->update($menu, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Menu updated successfully.',
            'data' => ['menu' => new MenuResource($menu)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $menu = $this->service->findById($id);
        $this->service->delete($menu);

        return response()->json([
            'status' => true,
            'message' => 'Menu deleted successfully.',
            'data' => [],
        ]);
    }

    // Drag-drop reorder endpoint
    // Accepts: { items: [{ id, sort_order, parent_id }] }
    public function reorder(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'items' => ['required', 'array'],
            'items.*.id' => ['required', 'integer', 'exists:menus,id'],
            'items.*.sort_order' => ['required', 'integer', 'min:0'],
            'items.*.parent_id' => ['nullable', 'integer', 'exists:menus,id'],
        ]);

        $this->service->reorder($validated['items']);

        return response()->json([
            'status' => true,
            'message' => 'Menu order updated.',
            'data' => [],
        ]);
    }
}
