<?php

namespace App\Http\Controllers\Api\V1\Superadmin;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\RoleResource;
use App\Services\V1\Superadmin\RoleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RoleController extends Controller
{
    public function __construct(protected RoleService $service) {}

    public function index(Request $request): JsonResponse
    {
        $filters = $request->only(['search', 'per_page', 'sort_key', 'sort_dir']);
        $roles = $this->service->getAll($filters);

        return response()->json([
            'status' => true,
            'message' => 'Roles retrieved successfully.',
            'data' => [
                'roles' => RoleResource::collection($roles)->resolve(),
                'meta' => [
                    'current_page' => $roles->currentPage(),
                    'last_page' => $roles->lastPage(),
                    'per_page' => $roles->perPage(),
                    'total' => $roles->total(),
                    'from' => $roles->firstItem(),
                    'to' => $roles->lastItem(),
                ],
            ],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $role = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'Role retrieved successfully.',
            'data' => ['role' => new RoleResource($role)],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => [
                'required', 'string', 'max:50',
                'regex:/^[a-z_]+$/',
                Rule::unique('roles', 'name'),
            ],
            'permissions' => ['nullable', 'array'],
            'permissions.*' => ['string', 'exists:permissions,name'],
        ], [
            'name.regex' => 'Role name must be lowercase letters and underscores only.',
        ]);

        $role = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Role created successfully.',
            'data' => ['role' => new RoleResource($role)],
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $role = $this->service->findById($id);

        $validated = $request->validate([
            'name' => [
                'sometimes', 'string', 'max:50',
                'regex:/^[a-z_]+$/',
                Rule::unique('roles', 'name')->ignore($role->id),
            ],
            'permissions' => ['nullable', 'array'],
            'permissions.*' => ['string', 'exists:permissions,name'],
        ]);

        $role = $this->service->update($role, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Role updated successfully.',
            'data' => ['role' => new RoleResource($role)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $role = $this->service->findById($id);
        $this->service->delete($role);

        return response()->json([
            'status' => true,
            'message' => 'Role deleted successfully.',
            'data' => [],
        ]);
    }

    public function syncPermissions(Request $request, int $id): JsonResponse
    {
        $role = $this->service->findById($id);

        $validated = $request->validate([
            'permissions' => ['required', 'array'],
            'permissions.*' => ['string', 'exists:permissions,name'],
        ]);

        $role = $this->service->syncPermissions($role, $validated['permissions']);

        return response()->json([
            'status' => true,
            'message' => 'Permissions synced successfully.',
            'data' => ['role' => new RoleResource($role)],
        ]);
    }
}
