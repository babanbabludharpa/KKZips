<?php

namespace App\Http\Controllers\Api\V1\Superadmin;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\PermissionResource;
use App\Services\V1\Superadmin\PermissionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PermissionController extends Controller
{
    public function __construct(protected PermissionService $service) {}

    public function index(): JsonResponse
    {
        $permissions = $this->service->getAll();

        return response()->json([
            'status' => true,
            'message' => 'Permissions retrieved successfully.',
            'data' => [
                'permissions' => PermissionResource::collection($permissions),
                'grouped' => $this->service->getGrouped(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:100',
                'regex:/^[a-z]+\.[a-z]+$/',
                Rule::unique('permissions', 'name'),
            ],
        ], [
            'name.regex' => 'Permission name must follow format: module.action (e.g. category.view)',
        ]);

        $permission = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Permission created successfully.',
            'data' => ['permission' => new PermissionResource($permission)],
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $permission = $this->service->findById($id);

        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:100',
                'regex:/^[a-z]+\.[a-z]+$/',
                Rule::unique('permissions', 'name')->ignore($permission->id),
            ],
        ], [
            'name.regex' => 'Permission name must follow format: module.action (e.g. category.view)',
        ]);

        $permission = $this->service->update($permission, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Permission updated successfully.',
            'data' => ['permission' => new PermissionResource($permission)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $permission = $this->service->findById($id);
        $this->service->delete($permission);

        return response()->json([
            'status' => true,
            'message' => 'Permission deleted successfully.',
            'data' => [],
        ]);
    }
}
