<?php

namespace App\Http\Controllers\Api\V1\Orders;

use App\Http\Controllers\Controller;
use App\Models\Tenant\Order;
use App\Models\User;
use App\Services\V1\Orders\InvoicePdfService;
use App\Services\V1\Orders\OrderStatusService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    private const LISTABLE_STATUSES = [
        'pending_payment', 'confirmed', 'preparing', 'out_for_delivery', 'picked_up', 'delivered',
        'payment_failed', 'packaging', 'cancelled', 'expired',
    ];

    private const SORTABLE = [
        'order_number' => 'orders.order_number',
        'customer' => 'customers.name',
        'status' => 'orders.status',
        'total' => 'orders.total',
        'created_at' => 'orders.created_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 1;

    private const MAX_PAGE_SIZE = 500;

    private const SELECT_ORDERS_ALL = 'orders.*';

    public function __construct(
        protected OrderStatusService $statusService,
        protected InvoicePdfService $invoicePdf,
    ) {}

    public function downloadInvoice(Request $request, $orderId)
    {
        $order = $this->scopedOrders($request)
            ->with(['items.variant.product', 'branch', 'customer'])
            ->findOrFail($orderId);

        return $this->invoicePdf->build($order)
            ->download('invoice-'.($order->order_number ?? $order->id).'.pdf');
    }

    private function scopedOrders(Request $request)
    {
        $query = Order::with(['items.variant.product', 'branch', 'deliveryBoy', 'customer']);

        if ($request->user()->branch_id !== null) {
            $query->where('branch_id', $request->user()->branch_id);
        }

        return $query;
    }

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'status' => 'nullable|string|max:30',
            'search' => 'nullable|string|max:255',
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $status = $request->query('status', 'confirmed');

        if (! in_array($status, self::LISTABLE_STATUSES, true)) {
            return response()->json([
                'status' => false,
                'message' => "'{$status}' is not a valid filter for this list.",
            ], 422);
        }

        $perPage = min(
            max((int) ($request->input('per_page') ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $request->input('sort_key');
        $sortDir = strtolower($request->input('sort_dir', 'desc')) === 'asc' ? 'asc' : 'desc';

        $query = $this->scopedOrders($request)
            ->when($status !== 'all', fn ($q) => $q->where('orders.status', $status))
            ->when($request->search, function ($q, $s) {
                $q->where(function ($w) use ($s) {
                    $w->where('orders.order_number', 'like', "%{$s}%")
                        ->orWhereHas('customer', function ($cq) use ($s) {
                            $cq->where('name', 'like', "%{$s}%")
                                ->orWhere('phone', 'like', "%{$s}%");
                        });
                });
            });

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            if ($column === 'customers.name') {
                $query->leftJoin('customers', 'customers.id', '=', 'orders.customer_id')
                    ->select(self::SELECT_ORDERS_ALL);
            }
            $query->orderBy($column, $sortDir);
            if ($column !== 'orders.created_at') {
                $query->orderByDesc('orders.created_at');
            }
            $query->orderByDesc('orders.id');
        } else {
            $query->orderByDesc('orders.created_at')->orderByDesc('orders.id');
        }

        $orders = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => [
                'data' => $orders->items(),
                'meta' => [
                    'current_page' => $orders->currentPage(),
                    'last_page' => $orders->lastPage(),
                    'per_page' => $orders->perPage(),
                    'total' => $orders->total(),
                    'from' => $orders->firstItem(),
                    'to' => $orders->lastItem(),
                ],
            ],
        ]);
    }

    public function show(Request $request, $orderId): JsonResponse
    {
        $order = $this->scopedOrders($request)
            ->with('statusHistory.changedBy')
            ->findOrFail($orderId);

        return response()->json(['status' => true, 'data' => $order]);
    }

    public function updateStatus(Request $request, $orderId): JsonResponse
    {
        $validated = $request->validate([
            'status' => 'required|string',
            'delivery_boy_id' => 'nullable|integer|exists:users,id',
            'notes' => 'nullable|string|max:500',
        ]);

        $order = $this->scopedOrders($request)->findOrFail($orderId);

        $updated = $this->statusService->transitionTo(
            $order,
            $validated['status'],
            $request->user(),
            $validated['delivery_boy_id'] ?? null,
            $validated['notes'] ?? null,
        );

        return response()->json([
            'status' => true,
            'message' => 'Order status updated.',
            'data' => $updated,
        ]);
    }

    public function deliveryQueue(Request $request): JsonResponse
    {
        $request->validate([
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $perPage = min(
            max((int) ($request->input('per_page') ?? 25), 1),
            500
        );

        $sortKey = $request->input('sort_key');
        $sortDir = strtolower($request->input('sort_dir', 'asc')) === 'desc' ? 'desc' : 'asc';

        $sortable = [
            'order_number' => 'orders.order_number',
            'status' => 'orders.status',
            'delivery_boy' => 'delivery_boys.name',
            'customer' => 'customers.name',
            'created_at' => 'orders.created_at',
        ];

        $query = $this->scopedOrders($request)
            ->whereIn('orders.status', ['preparing', 'picked_up', 'out_for_delivery']);

        $column = $sortable[$sortKey] ?? null;

        if ($column) {
            if ($column === 'delivery_boys.name') {
                $query->leftJoin('users as delivery_boys', 'delivery_boys.id', '=', 'orders.delivery_boy_id')
                    ->select(self::SELECT_ORDERS_ALL);
            } elseif ($column === 'customers.name') {
                $query->leftJoin('customers', 'customers.id', '=', 'orders.customer_id')
                    ->select(self::SELECT_ORDERS_ALL);
            }

            $query->orderBy($column, $sortDir);
            $query->orderByDesc('orders.id');
        } else {
            $query->orderBy('orders.status')->orderBy('orders.created_at');
        }

        $orders = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => [
                'data' => $orders->items(),
                'meta' => [
                    'current_page' => $orders->currentPage(),
                    'last_page' => $orders->lastPage(),
                    'per_page' => $orders->perPage(),
                    'total' => $orders->total(),
                    'from' => $orders->firstItem(),
                    'to' => $orders->lastItem(),
                ],
            ],
        ]);
    }

    public function availableDeliveryBoys(Request $request, $orderId): JsonResponse
    {
        $order = $this->scopedOrders($request)->findOrFail($orderId);

        $deliveryBoys = User::role('delivery_boy', 'sanctum')
            ->where('branch_id', $order->branch_id)
            ->select('id', 'name', 'branch_id')
            ->get();

        return response()->json(['status' => true, 'data' => $deliveryBoys]);
    }

    public function cancelledOrders(Request $request): JsonResponse
    {
        $request->validate([
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $perPage = min(
            max((int) ($request->input('per_page') ?? 25), 1),
            500
        );

        $sortKey = $request->input('sort_key');
        $sortDir = strtolower($request->input('sort_dir', 'desc')) === 'asc' ? 'asc' : 'desc';

        $sortable = [
            'order_number' => 'orders.order_number',
            'status' => 'orders.status',
            'customer' => 'customers.name',
            'total' => 'orders.total',
            'created_at' => 'orders.created_at',
        ];

        $query = $this->scopedOrders($request)
            ->whereIn('orders.status', ['payment_failed', 'cancelled', 'expired']);

        $column = $sortable[$sortKey] ?? null;

        if ($column) {
            if ($column === 'customers.name') {
                $query->leftJoin('customers', 'customers.id', '=', 'orders.customer_id')
                    ->select(self::SELECT_ORDERS_ALL);
            }
            $query->orderBy($column, $sortDir);
            if ($column !== 'orders.created_at') {
                $query->orderByDesc('orders.created_at');
            }
            $query->orderByDesc('orders.id');
        } else {
            $query->orderByDesc('orders.created_at')->orderByDesc('orders.id');
        }

        $orders = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => [
                'data' => $orders->items(),
                'meta' => [
                    'current_page' => $orders->currentPage(),
                    'last_page' => $orders->lastPage(),
                    'per_page' => $orders->perPage(),
                    'total' => $orders->total(),
                    'from' => $orders->firstItem(),
                    'to' => $orders->lastItem(),
                ],
            ],
        ]);
    }
}
