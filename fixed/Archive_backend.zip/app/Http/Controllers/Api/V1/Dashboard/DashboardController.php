<?php

namespace App\Http\Controllers\Api\V1\Dashboard;

use App\Http\Controllers\Controller;
use App\Services\V1\Dashboard\DashboardService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct(protected DashboardService $service) {}

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        // ★ Only superadmin sees cumulative data across all branches.
        //   Everyone else — including admin and staff_headoffice — is
        //   scoped to their own branch.
        $isSuperadmin = $user->hasRole('superadmin');

        $branchId = $isSuperadmin ? null : $user->branch_id;

        $data = $this->service->build($branchId, $isSuperadmin);

        return response()->json([
            'status' => true,
            'message' => 'Dashboard retrieved successfully.',
            'data' => $data,
        ]);
    }
}
