<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Http\JsonResponse;

// Deliberately separate from TenantProfileController. This must be
// reachable BEFORE login (the login page itself calls it) and must not
// 404/error when no TenantProfile row exists yet -- both of which rule
// out reusing the authenticated tenant-settings controller. Register its
// route outside any auth:* middleware group.
class BrandingController extends Controller
{
    public function __construct(protected TenantProfileService $service) {}

    public function index(): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Branding fetched',
            'data' => $this->service->getBranding(),
        ]);
    }
}
