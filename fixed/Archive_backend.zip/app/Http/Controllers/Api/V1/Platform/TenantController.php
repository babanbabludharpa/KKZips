<?php

namespace App\Http\Controllers\Api\V1\Platform;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\TenantResource;
use App\Models\Tenant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TenantController extends Controller
{
    private const MSG_TENANT_NOT_FOUND = 'Tenant not found.';

    private const MSG_DOMAIN_TAKEN = 'This domain is already in use.';

    private const MSG_EMAIL_TAKEN = 'A tenant with this email already exists.';

    private const MSG_SUBDOMAIN_TAKEN = 'This subdomain is already taken.';

    private const MSG_DOMAIN_NOT_FOUND = 'Domain not found for this tenant.';

    private const MSG_TENANT_CREATE_FAILED = 'Failed to create tenant. Please try again.';

    private const DEFAULT_THEME = 'crimson';

    private function themeKeys(): array
    {
        return array_keys(config('themes', []));
    }

    public function index(Request $request): JsonResponse
    {
        $tenants = Tenant::with('domains')
            ->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'status' => true,
            'message' => 'Tenants retrieved successfully.',
            'data' => TenantResource::collection($tenants->items()),
            'meta' => [
                'current_page' => $tenants->currentPage(),
                'last_page' => $tenants->lastPage(),
                'per_page' => $tenants->perPage(),
                'total' => $tenants->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email'],
            'plan' => ['required', Rule::in(['basic', 'pro', 'enterprise'])],
            'subdomain' => ['required', 'string', 'max:63', 'regex:/^[a-z0-9-]+$/'],
            'domain' => ['required', 'string', 'max:255', 'regex:/^[a-z0-9.-]+\.[a-z]{2,}$/i'],
            'theme_key' => ['sometimes', 'string', Rule::in($this->themeKeys())],
        ]);

        if ($error = $this->checkUniqueConstraints($request)) {
            return $error;
        }

        $tenant = $this->createTenantWithDomains($request);

        if (! $tenant) {
            return response()->json([
                'status' => false,
                'message' => self::MSG_TENANT_CREATE_FAILED,
                'data' => [],
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Tenant created successfully.',
            'data' => new TenantResource($tenant->load('domains')),
        ], 201);
    }

    private function checkUniqueConstraints(Request $request): ?JsonResponse
    {
        if (Tenant::where('email', $request->email)->exists()) {
            return $this->validationError(self::MSG_EMAIL_TAKEN, 'email', 'Email already taken.');
        }

        return $this->checkDomainConstraints($request);
    }

    private function checkDomainConstraints(Request $request): ?JsonResponse
    {
        $connection = \DB::connection((new Tenant)->getConnectionName());

        if ($connection->table('domains')->where('domain', $request->subdomain)->exists()) {
            return $this->validationError(self::MSG_SUBDOMAIN_TAKEN, 'subdomain', 'Subdomain already taken.');
        }

        if ($request->filled('domain')
            && $connection->table('domains')->where('domain', $request->domain)->exists()) {
            return $this->validationError(self::MSG_DOMAIN_TAKEN, 'domain', 'Domain already taken.');
        }

        return null;
    }

    private function createTenantWithDomains(Request $request): ?Tenant
    {
        try {
            return \DB::transaction(function () use ($request) {
                $tenant = Tenant::create([
                    'id' => $request->subdomain,
                    'name' => $request->name,
                    'email' => $request->email,
                    'plan' => $request->plan,
                    'status' => 'active',
                    'theme_key' => $request->theme_key ?? self::DEFAULT_THEME,
                ]);

                $tenant->domains()->create(['domain' => $request->subdomain]);
                $tenant->domains()->create(['domain' => $request->domain]);

                return $tenant;
            });
        } catch (\Throwable $e) {
            \Log::error('Tenant creation failed', [
                'subdomain' => $request->subdomain,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    public function addDomain(Request $request, string $id): JsonResponse
    {
        $tenant = Tenant::find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        $request->validate([
            'domain' => ['required', 'string', 'max:255', 'regex:/^[a-z0-9.-]+\.[a-z]{2,}$/i'],
        ]);

        $exists = \DB::connection((new Tenant)->getConnectionName())
            ->table('domains')->where('domain', $request->domain)->exists();

        if ($exists) {
            return $this->validationError(self::MSG_DOMAIN_TAKEN, 'domain', 'Domain already taken.');
        }

        $tenant->domains()->create(['domain' => $request->domain]);

        return response()->json([
            'status' => true,
            'message' => 'Domain added successfully.',
            'data' => new TenantResource($tenant->load('domains')),
        ], 201);
    }

    public function removeDomain(string $id, int $domainId): JsonResponse
    {
        $tenant = Tenant::with('domains')->find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        return $this->removeDomainFromTenant($tenant, $domainId);
    }

    private function removeDomainFromTenant(Tenant $tenant, int $domainId): JsonResponse
    {
        if ($tenant->domains->count() <= 1) {
            return $this->errorResponse('Cannot remove the last domain for a tenant.', 422);
        }

        $domain = $tenant->domains()->where('id', $domainId)->first();

        if (! $domain) {
            return $this->errorResponse(self::MSG_DOMAIN_NOT_FOUND, 404);
        }

        $domain->delete();

        return response()->json([
            'status' => true,
            'message' => 'Domain removed successfully.',
            'data' => new TenantResource($tenant->load('domains')),
        ]);
    }

    public function show(string $id): JsonResponse
    {
        $tenant = Tenant::with('domains')->find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        return response()->json([
            'status' => true,
            'message' => 'Tenant retrieved successfully.',
            'data' => new TenantResource($tenant),
        ]);
    }

    public function update(Request $request, string $id): JsonResponse
    {
        $tenant = Tenant::find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'email' => ['sometimes', 'email'],
            'plan' => ['sometimes', Rule::in(['basic', 'pro', 'enterprise'])],
            'status' => ['sometimes', Rule::in(['active', 'inactive', 'suspended'])],
            'theme_key' => ['sometimes', 'string', Rule::in($this->themeKeys())],
        ]);

        if (isset($validated['email'])) {
            $emailTaken = Tenant::where('email', $validated['email'])
                ->where('id', '!=', $id)
                ->exists();

            if ($emailTaken) {
                return $this->validationError(self::MSG_EMAIL_TAKEN, 'email', 'Email already taken.');
            }
        }

        $tenant->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Tenant updated successfully.',
            'data' => new TenantResource($tenant->load('domains')),
        ]);
    }

    public function destroy(string $id): JsonResponse
    {
        $tenant = Tenant::find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        if ($tenant->status === 'inactive') {
            return $this->errorResponse('Tenant is already inactive.', 422);
        }

        $tenant->update(['status' => 'inactive']);

        return response()->json([
            'status' => true,
            'message' => 'Tenant deactivated successfully.',
            'data' => [],
        ]);
    }

    public function restore(string $id): JsonResponse
    {
        $tenant = Tenant::find($id);

        if (! $tenant) {
            return $this->tenantNotFoundResponse();
        }

        if ($tenant->status === 'active') {
            return $this->errorResponse('Tenant is already active.', 422);
        }

        $tenant->update(['status' => 'active']);

        return response()->json([
            'status' => true,
            'message' => 'Tenant restored successfully.',
            'data' => new TenantResource($tenant->load('domains')),
        ]);
    }

    private function validationError(string $message, string $field, string $fieldMessage): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
            'data' => ['errors' => [$field => [$fieldMessage]]],
        ], 422);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
            'data' => [],
        ], $status);
    }

    private function tenantNotFoundResponse(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => self::MSG_TENANT_NOT_FOUND,
            'data' => [],
        ], 404);
    }
}
