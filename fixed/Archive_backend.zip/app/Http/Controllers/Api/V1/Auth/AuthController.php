<?php

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\ChangeMaster;
use App\Models\LoginMaster;
use App\Models\Tenant;
use App\Models\User;
use App\Services\V1\Sms\SmsService;
use Illuminate\Cache\RateLimiter as RateLimiterService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Laravel\Sanctum\PersonalAccessToken;
use Stancl\Tenancy\Database\Models\Domain;

class AuthController extends Controller
{
    private const MSG_INVALID_CREDENTIALS = 'Invalid credentials.';

    private const LOGIN_MAX_ATTEMPTS = 5;

    private const LOGIN_DECAY_SECONDS = 900;

    private const FORGOT_MAX_MOBILE_ATTEMPTS = 3;

    private const FORGOT_MAX_IP_ATTEMPTS = 10;

    private const FORGOT_DECAY_SECONDS = 3600;

    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
            'remember' => ['sometimes', 'boolean'],
        ]);

        $authCredentials = ['username' => $credentials['username'], 'password' => $credentials['password']];

        $limiter = new RateLimiterService(Cache::store('central'));
        $throttleKey = 'login:'.$request->ip().':'.$credentials['username'];

        if ($limiter->tooManyAttempts($throttleKey, self::LOGIN_MAX_ATTEMPTS)) {
            return $this->errorResponse('Too many login attempts. Please try again later.', 429);
        }

        if ($this->isPlatformAdmin($authCredentials)) {
            return $this->platformAdminLogin();
        }

        return $this->attemptTenantLogin($request, $authCredentials, $limiter, $throttleKey);
    }

    private function attemptTenantLogin(
        Request $request,
        array $authCredentials,
        RateLimiterService $limiter,
        string $throttleKey
    ): JsonResponse {
        $host = $request->getHost();

        if (in_array($host, config('tenancy.central_domains'))) {
            $limiter->hit($throttleKey, self::LOGIN_DECAY_SECONDS);

            return $this->errorResponse(self::MSG_INVALID_CREDENTIALS, 401);
        }

        $tenant = $this->resolveTenantFromHost($host);
        if (! $tenant) {
            return $this->errorResponse('Tenant not found.', 404);
        }

        if ($tenant->status !== 'active') {
            return $this->errorResponse($this->tenantStatusMessage($tenant->status), 403);
        }

        return $this->attemptAuth($request, $authCredentials, $tenant, $limiter, $throttleKey);
    }

    private function tenantStatusMessage(string $status): string
    {
        return match ($status) {
            'suspended' => 'Your account has been suspended. Please contact support.',
            'inactive' => 'This account is inactive.',
            default => 'Access denied.',
        };
    }

    private function attemptAuth(
        Request $request,
        array $authCredentials,
        Tenant $tenant,
        RateLimiterService $limiter,
        string $throttleKey
    ): JsonResponse {
        tenancy()->initialize($tenant);
        $tenant = Tenant::find($tenant->id);

        if (! Auth::attempt($authCredentials)) {
            $limiter->hit($throttleKey, self::LOGIN_DECAY_SECONDS);
            tenancy()->end();

            return $this->errorResponse(self::MSG_INVALID_CREDENTIALS, 401);
        }

        return $this->finalizeLogin($request, $tenant, $request->boolean('remember'), $limiter, $throttleKey);
    }

    private function finalizeLogin(
        Request $request,
        Tenant $tenant,
        bool $remember,
        RateLimiterService $limiter,
        string $throttleKey
    ): JsonResponse {
        $limiter->clear($throttleKey);

        /** @var User $user */
        $user = Auth::user();

        $expiresAt = $remember ? null : now()->addHours(8);
        $token = $user->createToken('auth_token', ['*'], $expiresAt)->plainTextToken;

        LoginMaster::create([
            'username' => $user->username,
            'ip_address' => $request->ip(),
            'logged_in_at' => now(),
            'logged_out_at' => null,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Login successful.',
            'data' => [
                'token' => $token,
                'user' => $this->formatTenantUser($user, $tenant),
                'connection' => 'tenant',
                'expires_at' => $expiresAt?->toIso8601String(),
            ],
        ]);
    }

    public function forgotPassword(Request $request, SmsService $smsService): JsonResponse
    {
        $data = $request->validate([
            'username' => ['required', 'string'],
            'mobile_number' => ['required', 'string'],
        ]);

        $limiter = new RateLimiterService(Cache::store('central'));
        $mobileKey = 'forgot-password:mobile:'.$data['mobile_number'];
        $ipKey = 'forgot-password:ip:'.$request->ip();

        if ($limiter->tooManyAttempts($mobileKey, self::FORGOT_MAX_MOBILE_ATTEMPTS)
            || $limiter->tooManyAttempts($ipKey, self::FORGOT_MAX_IP_ATTEMPTS)) {
            return $this->errorResponse('Too many requests. Please try again later.', 429);
        }

        $tenant = $this->resolveForgotPasswordTenant($request, $limiter, $mobileKey, $ipKey);
        if ($tenant instanceof JsonResponse) {
            return $tenant;
        }

        return $this->dispatchForgotPassword($request, $data, $tenant, $limiter, $mobileKey, $ipKey, $smsService);
    }

    private function dispatchForgotPassword(
        Request $request,
        array $data,
        Tenant $tenant,
        RateLimiterService $limiter,
        string $mobileKey,
        string $ipKey,
        SmsService $smsService
    ): JsonResponse {
        tenancy()->initialize($tenant);
        $this->hitForgotPasswordLimiters($limiter, $mobileKey, $ipKey);

        $user = User::where('username', $data['username'])
            ->where('mobile_number', $data['mobile_number'])
            ->first();

        if (! $user) {
            tenancy()->end();

            return $this->errorResponse(
                'No account found with these details. Please check your username and mobile number.',
                404
            );
        }

        if (! $smsService->isConfigured()) {
            Log::warning('Forgot-password requested but SMS gateway not configured for tenant.', [
                'tenant_id' => $tenant->id,
            ]);
            tenancy()->end();

            return $this->errorResponse(
                'SMS service is not available right now. Please contact support.',
                503
            );
        }

        return $this->resetPasswordAndSendSms($request, $user, $tenant, $smsService);
    }

    private function resolveForgotPasswordTenant(
        Request $request,
        RateLimiterService $limiter,
        string $mobileKey,
        string $ipKey
    ): Tenant|JsonResponse {
        $host = $request->getHost();

        $tenant = in_array($host, config('tenancy.central_domains'))
            ? null
            : $this->resolveTenantFromHost($host);

        if (! $tenant || $tenant->status !== 'active') {
            $this->hitForgotPasswordLimiters($limiter, $mobileKey, $ipKey);

            return $this->tenantResolutionFailedResponse();
        }

        return $tenant;
    }

    private function tenantResolutionFailedResponse(): JsonResponse
    {
        return $this->errorResponse(
            'Unable to process this request right now. Please try again later.',
            404
        );
    }

    private function resetPasswordAndSendSms(
        Request $request,
        User $user,
        Tenant $tenant,
        SmsService $smsService
    ): JsonResponse {
        $tempPassword = $this->generateTempPassword();

        $user->update([
            'password' => Hash::make($tempPassword),
            'force_password_change' => true,
        ]);

        $message = sprintf(
            'Dear %s Your password and transaction password has been reset to %s',
            $user->username,
            $tempPassword
        );

        $sent = $smsService->send($user->mobile_number, $message);

        ChangeMaster::create([
            'username' => $user->username,
            'added_by' => $user->username,
            'ip_address' => $request->ip(),
            'flag' => ChangeMaster::FLAG_FORGOT_PASSWORD,
            'panel' => ChangeMaster::PANEL_ADMIN,
            'remark' => $sent
                ? 'Password reset via SMS (forgot password)'
                : 'Password reset via SMS (forgot password) -- SMS send failed, see logs',
            'previous_value' => '',
            'new_value' => '',
        ]);

        tenancy()->end();

        if (! $sent) {
            Log::error('SMS send failed after password was reset.', [
                'user_id' => $user->id,
                'tenant_id' => $tenant->id,
            ]);

            return $this->errorResponse(
                'Failed to send SMS. Please try again or contact support.',
                502
            );
        }

        return response()->json([
            'status' => true,
            'message' => 'A new password has been sent to your registered mobile number.',
            'data' => [],
        ]);
    }

    public function changePassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'current_password' => ['required', 'string'],
            'new_password' => [
                'required',
                'string',
                'confirmed:password_confirmation',
                'min:8',
                'regex:/[a-z]/',
                'regex:/[A-Z]/',
                'regex:/[0-9]/',
                'regex:/[^a-zA-Z0-9]/',
            ],
            'password_confirmation' => ['required', 'string'],
        ]);

        /** @var User $user */
        $user = $request->user();

        if (! Hash::check($data['current_password'], $user->password)) {
            return $this->errorResponse('Current password is incorrect.', 422);
        }

        if (Hash::check($data['new_password'], $user->password)) {
            return $this->errorResponse(
                'New password must be different from the current one.',
                422
            );
        }

        $user->update([
            'password' => Hash::make($data['new_password']),
            'force_password_change' => false,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Password changed successfully.',
            'data' => [],
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $bearerToken = $request->bearerToken();

        if ($bearerToken && Cache::store('central')->has('platform_token:'.$bearerToken)) {
            Cache::store('central')->forget('platform_token:'.$bearerToken);

            return response()->json([
                'status' => true,
                'message' => 'Logged out successfully.',
                'data' => [],
            ]);
        }

        /** @var User $user */
        $user = $request->user();

        LoginMaster::where('username', $user->username)
            ->whereNull('logged_out_at')
            ->orderByDesc('id')
            ->limit(1)
            ->update(['logged_out_at' => now()]);

        /** @var PersonalAccessToken|null $accessToken */
        $accessToken = $user->currentAccessToken();
        $accessToken?->delete();

        return response()->json([
            'status' => true,
            'message' => 'Logged out successfully.',
            'data' => [],
        ]);
    }

    public function me(Request $request): JsonResponse
    {
        $token = $request->bearerToken();

        if ($token && Cache::store('central')->has('platform_token:'.$token)) {
            return response()->json([
                'status' => true,
                'message' => 'User retrieved successfully.',
                'data' => [
                    'user' => $this->formatPlatformAdmin(),
                ],
            ]);
        }

        /** @var User $user */
        $user = $request->user();

        if (! $user) {
            return $this->errorResponse('Unauthenticated.', 401);
        }

        $tenant = tenancy()->tenant;

        return response()->json([
            'status' => true,
            'message' => 'User retrieved successfully.',
            'data' => [
                'user' => $this->formatTenantUser($user, $tenant),
            ],
        ]);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
            'data' => [],
        ], $status);
    }

    private function hitForgotPasswordLimiters(RateLimiterService $limiter, string $mobileKey, string $ipKey): void
    {
        $limiter->hit($mobileKey, self::FORGOT_DECAY_SECONDS);
        $limiter->hit($ipKey, self::FORGOT_DECAY_SECONDS);
    }

    private function resolveTenantFromHost(string $host): ?Tenant
    {
        $domain = Domain::where('domain', $host)->first();

        if (! $domain) {
            $subdomain = explode('.', $host)[0];
            $domain = Domain::where('domain', $subdomain)->first();
        }

        return $domain?->tenant;
    }

    private function isPlatformAdmin(array $credentials): bool
    {
        return $credentials['username'] === config('platform.admin_email')
            && Hash::check($credentials['password'], config('platform.admin_password_hash'));
    }

    private function platformAdminLogin(): JsonResponse
    {
        $token = hash_hmac(
            'sha256',
            config('platform.admin_email').microtime(),
            config('platform.secret_key')
        );

        Cache::store('central')->put('platform_token:'.$token, true, now()->addHours(8));

        return response()->json([
            'status' => true,
            'message' => 'Login successful.',
            'data' => [
                'token' => $token,
                'user' => $this->formatPlatformAdmin(),
                'connection' => 'central',
            ],
        ]);
    }

    private function formatPlatformAdmin(): array
    {
        return [
            'id' => null,
            'name' => config('platform.admin_name'),
            'email' => config('platform.admin_email'),
            'role' => 'platform_admin',
            'permissions' => [],
            'themeKey' => 'pearlCrimson',
            'customTokens' => null,
        ];
    }

    private function formatTenantUser($user, $tenant = null): array
    {
        $user->loadMissing('roles', 'branch');

        return [
            'id' => $user->id,
            'name' => $user->name,
            'username' => $user->username,
            'email' => $user->email,
            'mobile_number' => $user->mobile_number,
            'role' => $user->getRoleNames()->first(),
            'permissions' => $user->getAllPermissions()->pluck('name')->values(),
            'branch_id' => $user->branch_id,
            'branch' => $user->branch ? [
                'id' => $user->branch->id,
                'name' => $user->branch->name,
            ] : null,
            'avatar_url' => $user->avatar_url,
            'created_at' => optional($user->created_at)->toDateTimeString(),
            'themeKey' => $tenant?->theme_key ?? 'crimson',
            'customTokens' => $tenant?->custom_tokens ?? null,
            'mustChangePassword' => (bool) $user->force_password_change,
        ];
    }

    private function generateTempPassword(): string
    {
        $upper = chr(random_int(65, 90));
        $lower = chr(random_int(97, 122));
        $number = (string) random_int(0, 9);
        $special = ['!', '@', '#', '$', '%', '&', '*'][random_int(0, 6)];
        $rest = Str::random(6);

        return str_shuffle($upper.$lower.$number.$special.$rest);
    }
}
