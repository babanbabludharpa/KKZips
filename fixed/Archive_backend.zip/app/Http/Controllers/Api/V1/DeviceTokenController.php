<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Tenant\DeviceToken;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeviceTokenController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'platform' => 'nullable|in:android,ios',
        ]);

        DeviceToken::updateOrCreate(
            ['token' => $validated['token']],
            ['customer_id' => $request->user()->id, 'platform' => $validated['platform'] ?? null],
        );

        return response()->json(['status' => true]);
    }

    // Call on logout, so the ex-customer's device stops getting this account's pushes
    public function destroy(Request $request): JsonResponse
    {
        $request->validate(['token' => 'required|string']);
        DeviceToken::where('token', $request->token)
            ->where('customer_id', $request->user()->id)
            ->delete();

        return response()->json(['status' => true]);
    }
}
