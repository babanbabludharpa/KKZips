<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\V1\ProfileService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function __construct(protected ProfileService $service) {}

    /**
     * GET /api/v1/profile
     */
    public function show(Request $request): JsonResponse
    {
        $user = $this->service->get($request->user());
        $tenant = tenancy()->tenant;

        return response()->json([
            'status' => true,
            'message' => 'Profile retrieved successfully.',
            'data' => [
                'user' => $this->formatUser($user, $tenant),
            ],
        ]);
    }

    /**
     * POST /api/v1/profile/avatar   (multipart, field "avatar")
     */
    public function uploadAvatar(Request $request): JsonResponse
    {
        $request->validate([
            'avatar' => ['required', 'file', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        $user = $this->service->uploadAvatar($request->user(), $request->file('avatar'));
        $tenant = tenancy()->tenant;

        return response()->json([
            'status' => true,
            'message' => 'Profile picture updated successfully.',
            'data' => ['user' => $this->formatUser($user, $tenant)],
        ]);
    }

    /**
     * DELETE /api/v1/profile/avatar
     */
    public function removeAvatar(Request $request): JsonResponse
    {
        $user = $this->service->removeAvatar($request->user());
        $tenant = tenancy()->tenant;

        return response()->json([
            'status' => true,
            'message' => 'Profile picture removed.',
            'data' => ['user' => $this->formatUser($user, $tenant)],
        ]);
    }

    /**
     * Same shape as AuthController::formatTenantUser so the frontend store
     * stays consistent across login / me / profile endpoints.
     */
    private function formatUser($user, $tenant = null): array
    {
        $user->loadMissing('roles', 'branch');

        return [
            'id' => $user->id,
            'name' => $user->name,
            'username' => $user->username,
            'email' => $user->email,
            'mobile_number' => $user->mobile_number,
            'role' => $user->getRoleNames()->first(),
            'permissions' => $user->getAllPermissions()->pluck('name')->values(),
            'branch_id' => $user->branch_id,
            'branch' => $user->branch ? [
                'id' => $user->branch->id,
                'name' => $user->branch->name,
            ] : null,
            'avatar_url' => $user->avatar_url,
            'created_at' => optional($user->created_at)->toDateTimeString(),
            'themeKey' => $tenant?->theme_key ?? 'crimson',
            'customTokens' => $tenant?->custom_tokens ?? null,
            'mustChangePassword' => (bool) $user->force_password_change,
        ];
    }
}
