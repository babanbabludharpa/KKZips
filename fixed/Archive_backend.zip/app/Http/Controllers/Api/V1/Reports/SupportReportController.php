<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use App\Models\SupportConversation;
use App\Services\V1\Reports\SupportReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupportReportController extends Controller
{
    public function __construct(protected SupportReportService $service) {}

    public function conversations(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date|after_or_equal:from_date',
            'status' => 'nullable|in:open,resolved,escalated',
            'customer_id' => 'nullable|integer',
            'search' => 'nullable|string|max:255',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        $paginated = $this->service->conversations($validated);

        return response()->json([
            'status' => true,
            'data' => $paginated->items(),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
                'from' => $paginated->firstItem(),
                'to' => $paginated->lastItem(),
            ],
        ]);
    }

    public function customers(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date|after_or_equal:from_date',
            'customer_id' => 'nullable|integer',
            'search' => 'nullable|string|max:255',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        $paginated = $this->service->customerActivity($validated);

        return response()->json([
            'status' => true,
            'data' => $paginated->items(),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
                'from' => $paginated->firstItem(),
                'to' => $paginated->lastItem(),
            ],
        ]);
    }

    public function unmatched(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date|after_or_equal:from_date',
            'customer_id' => 'nullable|integer',
            'search' => 'nullable|string|max:255',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        $paginated = $this->service->unmatchedMessages($validated);

        return response()->json([
            'status' => true,
            'data' => $paginated->items(),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
                'from' => $paginated->firstItem(),
                'to' => $paginated->lastItem(),
            ],
        ]);
    }

    public function conversationDetail(int $id): JsonResponse
    {
        $conversation = SupportConversation::query()
            ->with(['messages' => fn ($q) => $q->orderBy('created_at')])
            ->findOrFail($id);

        return response()->json([
            'status' => true,
            'data' => [
                'id' => $conversation->id,
                'customer_id' => $conversation->customer_id,
                'status' => $conversation->status,
                'created_at' => $conversation->created_at->toIso8601String(),
                'last_message_at' => optional($conversation->last_message_at)->toIso8601String(),
                'messages' => $conversation->messages->map(fn ($m) => [
                    'id' => $m->id,
                    'sender_type' => $m->sender_type,
                    'message' => $m->message,
                    'faq_id' => $m->matched_faq_id,
                    'confidence' => $m->confidence,
                    'metadata' => $m->metadata,
                    'created_at' => $m->created_at->toIso8601String(),
                ]),
            ],
        ]);
    }
}
