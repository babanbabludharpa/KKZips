<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;

class WalletReportController extends Controller
{
    private const PAGE_SIZE = 25;

    private const MAX_PAGE_SIZE = 100;

    /**
     * ★ HO roles see all branches (or filter to one). Everyone else is
     *   forced to their own branch. Same rule as ReportController.
     */
    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }

        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    public function balances(Request $request)
    {
        // ★ Branch scoping — HO users can filter to any branch; everyone
        //   else is forced to their own branch. null = show all (HO only).
        $branchId = $this->isHeadOffice($request)
            ? $request->input('branch_id')
            : $request->user()->branch_id;

        $query = DB::table('customer_wallets as cw')
            ->join('customers as c', 'c.id', '=', 'cw.customer_id')
            ->select([
                'c.id as customer_id',
                'c.name as customer_name',
                'c.phone',
                'c.status as customer_status',
                'cw.balance',
                'cw.updated_at as balance_updated_at',
            ]);

        if ($request->filled('customer_id')) {
            $query->where('c.id', $request->input('customer_id'));
        }

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('c.name', 'like', "%{$search}%")
                    ->orWhere('c.phone', 'like', "%{$search}%");
            });
        }

        if ($request->filled('balance_min')) {
            $query->where('cw.balance', '>=', (float) $request->input('balance_min'));
        }
        if ($request->filled('balance_max')) {
            $query->where('cw.balance', '<=', (float) $request->input('balance_max'));
        }

        // ★ Branch filter — customer appears if they have ANY address in
        //   that branch. EXISTS (not JOIN) so a customer with multiple
        //   addresses in the same branch still appears only once.
        if ($branchId) {
            $query->whereExists(function ($q) use ($branchId) {
                $q->select(DB::raw(1))
                    ->from('customer_addresses as ca')
                    ->whereColumn('ca.customer_id', 'c.id')
                    ->where('ca.branch_id', $branchId);
            });
        }

        // ★ Display branch — a customer can belong to multiple branches
        //   (one per address). Show all of them, comma-separated.
        $query->addSelect([
            'branch_name' => DB::table('customer_addresses as ca2')
                ->join('branches as b', 'ca2.branch_id', '=', 'b.id')
                ->whereColumn('ca2.customer_id', 'c.id')
                ->whereNotNull('ca2.branch_id')
                ->groupBy('ca2.customer_id')
                ->select(DB::raw('GROUP_CONCAT(DISTINCT b.name ORDER BY b.name SEPARATOR ", ")')),
        ]);

        match ($request->input('sort', 'balance_desc')) {
            'balance_asc' => $query->orderBy('cw.balance', 'asc'),
            'balance_desc' => $query->orderBy('cw.balance', 'desc'),
            'name_asc' => $query->orderBy('c.name', 'asc'),
            'name_desc' => $query->orderBy('c.name', 'desc'),
            default => $query->orderBy('cw.balance', 'desc'),
        };

        if ($request->input('export') === 'csv') {
            return $this->streamCsv(
                $query->get(),
                ['Customer', 'Phone', 'Status', 'Branch', 'Balance', 'Last Updated'],
                fn ($r) => [
                    $r->customer_name,
                    $r->phone,
                    $r->customer_status,
                    $r->branch_name ?? '—',
                    number_format((float) $r->balance, 2),
                    $r->balance_updated_at,
                ],
                'customer_wallet_balances'
            );
        }

        $perPage = min(max((int) $request->input('per_page', self::PAGE_SIZE), 1), self::MAX_PAGE_SIZE);
        $paginated = $query->paginate($perPage);

        return response()->json(['status' => true, 'data' => $paginated]);
    }

    public function transactions(Request $request)
    {
        $withDelta = DB::table('wallet_transactions as wt')
            ->select([
                'wt.*',
                DB::raw(
                    'wt.balance_after - COALESCE('
                    .'LAG(wt.balance_after) OVER (PARTITION BY wt.customer_id ORDER BY wt.created_at, wt.id)'
                    .', 0) as signed_delta'
                ),
            ]);

        $query = DB::query()->fromSub($withDelta, 'wt')
            ->join('customers as c', 'c.id', '=', 'wt.customer_id')
            ->leftJoin('users as u', 'u.id', '=', 'wt.added_by')
            ->select([
                'wt.id',
                'wt.customer_id',
                'c.name as customer_name',
                'c.phone',
                'wt.type',
                'wt.amount',
                'wt.signed_delta',
                'wt.balance_after',
                'wt.reference_type',
                'wt.reference_id',
                'wt.remark',
                'u.name as added_by_name',
                'wt.created_at',
            ]);

        if ($request->filled('customer_id')) {
            $query->where('wt.customer_id', $request->input('customer_id'));
        }

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('c.name', 'like', "%{$search}%")
                    ->orWhere('c.phone', 'like', "%{$search}%");
            });
        }

        if ($request->filled('type')) {
            $query->where('wt.type', $request->input('type'));
        }

        if ($request->filled('date_from')) {
            $query->whereDate('wt.created_at', '>=', $request->input('date_from'));
        }
        if ($request->filled('date_to')) {
            $query->whereDate('wt.created_at', '<=', $request->input('date_to'));
        }

        // ★ Branch scoping — same rule as balances. Non-HO users are
        //   forced to their own branch; a customer's transactions show
        //   up in every branch they have an address in.
        $branchId = $this->isHeadOffice($request)
            ? $request->input('branch_id')
            : $request->user()->branch_id;

        if ($branchId) {
            $query->whereExists(function ($q) use ($branchId) {
                $q->select(DB::raw(1))
                    ->from('customer_addresses as ca')
                    ->whereColumn('ca.customer_id', 'c.id')
                    ->where('ca.branch_id', $branchId);
            });
        }

        $sortMap = [
            'date_asc' => ['wt.created_at', 'asc'],
            'date_desc' => ['wt.created_at', 'desc'],
            'customer_asc' => ['c.name', 'asc'],
            'customer_desc' => ['c.name', 'desc'],
            'type_asc' => ['wt.type', 'asc'],
            'type_desc' => ['wt.type', 'desc'],
            'amount_asc' => ['wt.amount', 'asc'],
            'amount_desc' => ['wt.amount', 'desc'],
            'balance_asc' => ['wt.balance_after', 'asc'],
            'balance_desc' => ['wt.balance_after', 'desc'],
        ];
        [$sortCol, $sortDir] = $sortMap[$request->input('sort')] ?? ['wt.created_at', 'desc'];
        $query->orderBy($sortCol, $sortDir)->orderBy('wt.id', $sortDir);

        if ($request->input('export') === 'csv') {
            return $this->streamCsv(
                $query->get(),
                ['Date', 'Customer', 'Phone', 'Type', 'Amount', 'Balance After', 'Reference', 'Remark', 'Added By'],
                fn ($r) => [
                    $r->created_at,
                    $r->customer_name,
                    $r->phone,
                    $r->type,
                    ($r->signed_delta >= 0 ? '+' : '').number_format((float) $r->signed_delta, 2),
                    number_format((float) $r->balance_after, 2),
                    $r->reference_type ? "{$r->reference_type} #{$r->reference_id}" : '-',
                    $r->remark ?? '-',
                    $r->added_by_name ?? 'System',
                ],
                'wallet_transactions'
            );
        }

        $perPage = min(max((int) $request->input('per_page', self::PAGE_SIZE), 1), self::MAX_PAGE_SIZE);
        $paginated = $query->paginate($perPage);

        return response()->json(['status' => true, 'data' => $paginated]);
    }

    private function streamCsv(iterable $rows, array $headers, callable $mapRow, string $filenamePrefix): StreamedResponse
    {
        $filename = $filenamePrefix.'_'.now()->format('Y-m-d').'.csv';

        return response()->streamDownload(function () use ($rows, $headers, $mapRow) {
            $out = fopen('php://output', 'w');
            fputcsv($out, $headers);
            foreach ($rows as $row) {
                fputcsv($out, $mapRow($row));
            }
            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv']);
    }
}
