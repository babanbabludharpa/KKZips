<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use App\Services\V1\Reports\ReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends Controller
{
    public function __construct(protected ReportService $service) {}

    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }

        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    private function scopedParams(Request $request): array
    {
        $params = $request->all();

        if (! $this->isHeadOffice($request)) {
            $params['branch_id'] = (int) $request->user()->branch_id;
        }

        return $params;
    }

    public function stockLevels(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'branch_id' => 'nullable|integer|exists:branches,id',
            'search' => 'nullable|string|max:255',
            'low_stock' => 'nullable|boolean',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->stockLevelsCsv($params);
        }

        $data = $this->service->stockLevels($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function stockMovements(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'variant_id' => 'nullable|integer|exists:product_variants,id',
            'type' => 'nullable|in:inward,transfer',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->stockMovementsCsv($params);
        }

        $data = $this->service->stockMovements($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function stockRequests(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'from_branch_id' => 'nullable|integer|exists:branches,id',
            'to_branch_id' => 'nullable|integer|exists:branches,id',
            'status' => 'nullable|in:pending,approved,fulfilled,cancelled',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $request->all();

        if (! $this->isHeadOffice($request)) {
            $params['from_branch_id'] = (int) $request->user()->branch_id;
        }

        if ($request->export === 'csv') {
            return $this->service->stockRequestsCsv($params);
        }

        $data = $this->service->stockRequests($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function stockRequestDetail(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'from_branch_id' => 'nullable|integer|exists:branches,id',
            'to_branch_id' => 'nullable|integer|exists:branches,id',
            'status' => 'nullable|in:pending,approved,fulfilled,cancelled',
            'product_id' => 'nullable|integer|exists:products,id',
            'variant_id' => 'nullable|integer|exists:product_variants,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $request->all();

        if (! $this->isHeadOffice($request)) {
            $params['from_branch_id'] = (int) $request->user()->branch_id;
        }

        if ($request->export === 'csv') {
            return $this->service->stockRequestDetailCsv($params);
        }

        $data = $this->service->stockRequestDetail($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function priceHistory(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'product_id' => 'nullable|integer|exists:products,id',
            'variant_id' => 'nullable|integer|exists:product_variants,id',
            'source' => 'nullable|in:manual,schedule',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        if ($request->export === 'csv') {
            return $this->service->priceHistoryCsv($request->all());
        }

        $data = $this->service->priceHistory($request->all());

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function discountHistory(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'product_id' => 'nullable|integer|exists:products,id',
            'variant_id' => 'nullable|integer|exists:product_variants,id',
            'status' => 'nullable|in:pending,active,expired,cancelled',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        if ($request->export === 'csv') {
            return $this->service->discountHistoryCsv($request->all());
        }

        $data = $this->service->discountHistory($request->all());

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function deliveredOrders(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'delivery_boy_id' => 'nullable|integer|exists:users,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->deliveredOrdersCsv($params);
        }

        $data = $this->service->deliveredOrders($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function deliveredOrderItems(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'delivery_boy_id' => 'nullable|integer|exists:users,id',
            'product_id' => 'nullable|integer|exists:products,id',
            'variant_id' => 'nullable|integer|exists:product_variants,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->deliveredOrderItemsCsv($params);
        }

        $data = $this->service->deliveredOrderItems($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function customerAddresses(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'state' => 'nullable|string|max:255',
            'is_serviceable' => 'nullable|boolean',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->customerAddressesCsv($params);
        }

        $data = $this->service->customerAddresses($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function couponConsumption(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after_or_equal:from_date',
            'coupon_id' => 'nullable|integer',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
            'export' => 'nullable|in:csv',
        ]);

        $params = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->service->couponConsumptionCsv($params);
        }

        $data = $this->service->couponConsumption($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function couponConsumptionCoupons(): JsonResponse
    {
        $rows = $this->service->couponConsumptionCouponList();

        return response()->json(['status' => 'success', 'data' => $rows]);
    }
}
