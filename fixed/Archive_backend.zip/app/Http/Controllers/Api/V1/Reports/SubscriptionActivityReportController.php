<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use App\Services\V1\Subscriptions\SubscriptionActivityReportService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SubscriptionActivityReportController extends Controller
{
    public function __construct(protected SubscriptionActivityReportService $service) {}

    /**
     * ★ Same rule as ReportController — HO roles can pass any branch_id,
     *   everyone else is forced to their own branch.
     */
    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }

        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    private function scopedParams(Request $request): array
    {
        $params = $request->only([
            'customer_id', 'subscription_id', 'event_type', 'actor_type',
            'date_from', 'date_to', 'branch_id', 'per_page',
            'sort_key', 'sort_dir',
        ]);

        if (! $this->isHeadOffice($request)) {
            $params['branch_id'] = (int) $request->user()->branch_id;
        }

        return $params;
    }

    public function index(Request $request)
    {
        abort_unless($request->user()->can('report.subscription_activity'), 403);

        $filters = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->export($filters);
        }

        $report = $this->service->getReport($filters);

        return response()->json([
            'status' => true,
            'message' => 'Activity report retrieved successfully.',
            'data' => $this->formatRows(collect($report->items())),
            'meta' => [
                'current_page' => $report->currentPage(),
                'last_page' => $report->lastPage(),
                'per_page' => $report->perPage(),
                'total' => $report->total(),
                'from' => $report->firstItem(),
                'to' => $report->lastItem(),
            ],
        ]);
    }

    protected function export(array $filters): StreamedResponse
    {
        $rows = $this->service->getForExport($filters);

        return response()->streamDownload(function () use ($rows) {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF");

            fputcsv($handle, ['Date', 'Customer', 'Branch', 'Product', 'Event', 'Actor', 'Occurrence Date', 'Description']);

            foreach ($rows as $row) {
                fputcsv($handle, [
                    $row->created_at->toDateTimeString(),
                    $row->subscription->customer->name ?? '',
                    $row->subscription->branch->name ?? '',
                    $row->subscriptionItem->productVariant->product->name ?? '',
                    $row->event_type,
                    $row->actor_type,
                    $row->occurrence_date?->toDateString() ?? '',
                    $row->description,
                ]);
            }

            fclose($handle);
        }, 'subscription-activity-report.csv', ['Content-Type' => 'text/csv']);
    }

    protected function formatRows($rows)
    {
        return $rows->map(fn ($row) => [
            'id' => $row->id,
            'created_at' => $row->created_at->toDateTimeString(),
            'customer_name' => $row->subscription->customer->name ?? null,
            'branch_name' => $row->subscription->branch->name ?? null,
            'product_name' => $row->subscriptionItem->productVariant->product->name ?? null,
            'event_type' => $row->event_type,
            'actor_type' => $row->actor_type,
            'occurrence_date' => $row->occurrence_date?->toDateString(),
            'description' => $row->description,
            'metadata' => $row->metadata,
        ]);
    }
}
