<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use App\Models\DeliveryBoy;
use App\Services\V1\Subscriptions\SubscriptionDemandReportService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SubscriptionDemandReportController extends Controller
{
    public function __construct(protected SubscriptionDemandReportService $service) {}

    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }
        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    private function scopedFilters(Request $request): array
    {
        $user = $request->user();
        $isHeadOffice = $this->isHeadOffice($request);

        $filters = [
            'date' => $request->date ? Carbon::parse($request->date) : now()->addDay(),
            'branch_id' => $isHeadOffice ? ($request->branch_id ? (int) $request->branch_id : null) : (int) $user->branch_id,
            'zone_id' => $request->zone_id ? (int) $request->zone_id : null,
            'slot_id' => $request->slot_id ? (int) $request->slot_id : null,
            'category_id' => $request->category_id ? (int) $request->category_id : null,
        ];

        // If a zone is passed, its branch must match the effective branch.
        // Otherwise a branch user could infer another branch's demand by
        // guessing a zone id.
        if ($filters['zone_id'] && ! $isHeadOffice) {
            $zoneBranch = \App\Models\BranchServiceZone::where('id', $filters['zone_id'])
                ->value('branch_id');
            if ((int) $zoneBranch !== (int) $user->branch_id) {
                abort(response()->json([
                    'status' => false,
                    'message' => 'You cannot filter by a zone outside your branch.',
                ], 403));
            }
        }

        return $filters;
    }

    public function show(Request $request)
    {
        abort_unless($request->user()->can('report.subscription_demand'), 403);

        $filters = $this->scopedFilters($request);

        if ($request->export === 'csv' || $request->export === 'excel') {
            return $this->export($filters, $request->export);
        }

        $report = $this->service->forDate(
            $filters['date'],
            $filters['branch_id'],
            $filters['zone_id'],
            $filters['slot_id'],
            $filters['category_id'],
        );

        return response()->json([
            'status' => true,
            'message' => 'Demand report retrieved successfully.',
            'data' => $report,
        ]);
    }

    protected function export(array $filters, string $format): StreamedResponse
    {
        $report = $this->service->forDate(
            $filters['date'],
            $filters['branch_id'],
            $filters['zone_id'],
            $filters['slot_id'],
            $filters['category_id'],
        );

        $rows = $report['rows'] ?? [];
        $dateStr = $filters['date']->toDateString();

        if ($format === 'csv') {
            $filename = "subscription_demand_{$dateStr}.csv";
            $contentType = 'text/csv';

            return response()->streamDownload(function () use ($rows) {
                $handle = fopen('php://output', 'w');
                fwrite($handle, "\xEF\xBB\xBF");

                fputcsv($handle, [
                    'Product', 'SKU', 'Category', 'Branch', 'Zone', 'Slot',
                    'Slot Start', 'Slot End', 'Deliveries', 'Total Qty Needed',
                ]);

                foreach ($rows as $row) {
                    fputcsv($handle, [
                        $row['product_name'] ?? '',
                        $row['variant_sku'] ?? '',
                        $row['category_name'] ?? '',
                        $row['branch_name'] ?? '',
                        $row['zone_name'] ?? '',
                        $row['slot_name'] ?? '',
                        $row['slot_start_time'] ?? '',
                        $row['slot_end_time'] ?? '',
                        $row['delivery_count'] ?? 0,
                        $row['total_qty'] ?? 0,
                    ]);
                }
                fclose($handle);
            }, $filename, ['Content-Type' => $contentType]);
        }

        // Excel: HTML table with Excel content-type. This is the pragmatic
        // way to produce .xls without pulling in a PhpSpreadsheet dependency.
        // Excel and LibreOffice open it natively.
        $filename = "subscription_demand_{$dateStr}.xls";
        $contentType = 'application/vnd.ms-excel';

        return response()->streamDownload(function () use ($rows) {
            echo '<html><head><meta charset="UTF-8"></head><body>';
            echo '<table border="1" cellspacing="0" cellpadding="4">';
            echo '<thead><tr style="background:#eee;">';
            foreach (['Product', 'SKU', 'Category', 'Branch', 'Zone', 'Slot', 'Slot Start', 'Slot End', 'Deliveries', 'Total Qty Needed'] as $h) {
                echo '<th>' . htmlspecialchars($h) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ($rows as $row) {
                echo '<tr>';
                foreach ([
                    $row['product_name'] ?? '',
                    $row['variant_sku'] ?? '',
                    $row['category_name'] ?? '',
                    $row['branch_name'] ?? '',
                    $row['zone_name'] ?? '',
                    $row['slot_name'] ?? '',
                    $row['slot_start_time'] ?? '',
                    $row['slot_end_time'] ?? '',
                    $row['delivery_count'] ?? 0,
                    $row['total_qty'] ?? 0,
                ] as $v) {
                    echo '<td>' . htmlspecialchars((string) $v) . '</td>';
                }
                echo '</tr>';
            }
            echo '</tbody></table></body></html>';
        }, $filename, ['Content-Type' => $contentType]);
    }
}
