<?php

namespace App\Http\Controllers\Api\V1\Reports;

use App\Http\Controllers\Controller;
use App\Models\DeliveryBoy;
use App\Services\V1\Subscriptions\SubscriptionDeliveryReportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SubscriptionDeliveryReportController extends Controller
{
    public function __construct(protected SubscriptionDeliveryReportService $service) {}

    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }

        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    private function scopedParams(Request $request): array
    {
        $params = $request->only([
            'date_from', 'date_to', 'status', 'not_delivered_reason',
            'branch_id', 'zone_id', 'delivery_boy_id', 'product_variant_id',
            'per_page', 'sort_key', 'sort_dir',
        ]);

        $user = $request->user();
        $isHeadOffice = $this->isHeadOffice($request);

        // Non-HO users are locked to their own branch.
        if (! $isHeadOffice) {
            $params['branch_id'] = (int) $user->branch_id;
        }

        // Rider filter must belong to the effective branch. For HO users
        // with no branch filter yet, infer the branch from the rider so the
        // report never spans branches. For non-HO users, reject a rider
        // outside their branch with a 403 rather than silently ignoring
        // the filter.
        if (! empty($params['delivery_boy_id'])) {
            $riderBranchId = DeliveryBoy::where('id', (int) $params['delivery_boy_id'])
                ->value('branch_id');

            if ($riderBranchId === null) {
                abort(response()->json([
                    'status' => false,
                    'message' => 'Selected rider was not found.',
                ], 404));
            }

            if (! $isHeadOffice) {
                if ((int) $riderBranchId !== (int) $user->branch_id) {
                    abort(response()->json([
                        'status' => false,
                        'message' => 'You cannot filter by a rider outside your branch.',
                    ], 403));
                }
            } elseif (empty($params['branch_id'])) {
                // HO user picked a rider but no branch — anchor the query
                // to that rider's branch so branch/zone/rider all agree.
                $params['branch_id'] = (int) $riderBranchId;
            } elseif ((int) $riderBranchId !== (int) $params['branch_id']) {
                // HO user picked a rider whose branch does not match the
                // selected branch — reject rather than silently cross-branch.
                abort(response()->json([
                    'status' => false,
                    'message' => 'Selected rider does not belong to the chosen branch.',
                ], 422));
            }
        }

        return $params;
    }

    public function index(Request $request)
    {
        abort_unless($request->user()->can('report.subscription_delivery'), 403);

        $filters = $this->scopedParams($request);

        if ($request->export === 'csv') {
            return $this->export($filters);
        }

        $report = $this->service->getReport($filters);
        $summary = $this->service->getSummary($filters);

        return response()->json([
            'status' => true,
            'message' => 'Report retrieved successfully.',
            'data' => $this->formatRows(collect($report->items())),
            'summary' => $summary,
            'meta' => [
                'current_page' => $report->currentPage(),
                'last_page' => $report->lastPage(),
                'per_page' => $report->perPage(),
                'total' => $report->total(),
                'from' => $report->firstItem(),
                'to' => $report->lastItem(),
            ],
        ]);
    }

    protected function export(array $filters): StreamedResponse
    {
        $rows = $this->service->getForExport($filters);

        return response()->streamDownload(function () use ($rows) {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF");

            fputcsv($handle, [
                'Date', 'Customer', 'Branch', 'Zone', 'Slot',
                'Slot Start', 'Slot End',
                'Product', 'Qty', 'Status', 'Not Delivered Reason',
                'Rider', 'Rider Mobile', 'Assigned Type', 'Assigned At',
                'Photo URL',
            ]);

            foreach ($rows as $row) {
                $photoUrl = $row->delivery_photo_path
                    ? Storage::disk('public')->url($row->delivery_photo_path)
                    : '';

                $slot = $row->subscriptionItem->slot ?? null;
                $zone = $row->subscriptionItem->subscription->deliveryAddress->zone ?? null;
                $rider = $row->deliveryBoy;

                fputcsv($handle, [
                    $row->occurrence_date->toDateString(),
                    $row->subscriptionItem->subscription->customer->name ?? '',
                    $row->subscriptionItem->subscription->branch->name ?? '',
                    $zone->name ?? '',
                    $slot->name ?? '',
                    $slot ? substr($slot->start_time, 0, 5) : '',
                    $slot ? substr($slot->end_time, 0, 5) : '',
                    $row->subscriptionItem->productVariant->product->name ?? '',
                    $row->qty,
                    $row->status,
                    $row->not_delivered_reason ?? '',
                    $rider->name ?? '',
                    $rider->mobile_number ?? '',
                    $row->assignment_type ?? '',
                    $row->assigned_at ? $row->assigned_at->toDateTimeString() : '',
                    $photoUrl,
                ]);
            }

            fclose($handle);
        }, 'subscription-delivery-report.csv', ['Content-Type' => 'text/csv']);
    }

    protected function formatRows($rows)
    {
        return $rows->map(function ($row) {
            $photoUrl = $row->delivery_photo_path
                ? Storage::disk('public')->url($row->delivery_photo_path)
                : null;

            $slot = $row->subscriptionItem->slot ?? null;
            $zone = $row->subscriptionItem->subscription->deliveryAddress->zone ?? null;
            $rider = $row->deliveryBoy;

            return [
                'id' => $row->id,
                'occurrence_date' => $row->occurrence_date->toDateString(),
                'customer_name' => $row->subscriptionItem->subscription->customer->name ?? null,
                'branch_name' => $row->subscriptionItem->subscription->branch->name ?? null,
                'zone_name' => $zone->name ?? null,
                'slot_name' => $slot->name ?? null,
                'slot_start_time' => $slot ? substr($slot->start_time, 0, 5) : null,
                'slot_end_time' => $slot ? substr($slot->end_time, 0, 5) : null,
                'product_name' => $row->subscriptionItem->productVariant->product->name ?? null,
                'qty' => $row->qty,
                'status' => $row->status,
                'not_delivered_reason' => $row->not_delivered_reason,
                'delivery_boy_name' => $rider->name ?? null,
                'rider_mobile' => $rider->mobile_number ?? null,
                'assignment_type' => $row->assignment_type,
                'assigned_at' => $row->assigned_at ? $row->assigned_at->toDateTimeString() : null,
                'delivery_photo_url' => $photoUrl,
            ];
        });
    }
}
