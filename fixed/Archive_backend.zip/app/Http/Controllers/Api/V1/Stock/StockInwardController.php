<?php

namespace App\Http\Controllers\Api\V1\Stock;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\StockInwardResource;
use App\Services\V1\Stock\StockInwardService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StockInwardController extends Controller
{
    public function __construct(protected StockInwardService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'supplier_id' => 'nullable|integer|exists:suppliers,id',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $inwards = $this->service->getAll(
            $request->only(['supplier_id', 'branch_id', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Stock inward records fetched.',
            'data' => [
                'data' => StockInwardResource::collection($inwards->items()),
                'meta' => [
                    'current_page' => $inwards->currentPage(),
                    'last_page' => $inwards->lastPage(),
                    'per_page' => $inwards->perPage(),
                    'total' => $inwards->total(),
                    'from' => $inwards->firstItem(),
                    'to' => $inwards->lastItem(),
                ],
            ],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $inward = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'Stock inward record fetched.',
            'data' => ['stock_inward' => new StockInwardResource($inward)],
        ]);
    }

    // No update/destroy — inward entries are immutable once created.
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'supplier_id' => ['required', 'integer', 'exists:suppliers,id'],
            'received_date' => ['required', 'date'],
            'notes' => ['nullable', 'string'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_variant_id' => ['required', 'integer', 'exists:product_variants,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'items.*.expiry_date' => ['nullable', 'date'],
        ]);

        $inward = $this->service->create($validated, $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Stock inward recorded.',
            'data' => ['stock_inward' => new StockInwardResource($inward)],
        ], 201);
    }
}
