<?php

namespace App\Http\Controllers\Api\V1\Stock;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\StockRequestResource;
use App\Models\StockRequest;
use App\Services\V1\Stock\StockRequestService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class StockRequestController extends Controller
{
    public function __construct(protected StockRequestService $service) {}

    /**
     * ★ HO roles (staff_headoffice, admin, superadmin) see all requests and
     *   may filter by from_branch_id. staff_stateoffice sees requests
     *   addressed to their office (to_branch_id). staff_branch sees the
     *   requests they raised (from_branch_id).
     */
    private function isHeadOffice(Request $request): bool
    {
        $user = $request->user();
        if (! $user) {
            return false;
        }

        return $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']);
    }

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'status' => 'nullable|in:pending,approved,fulfilled,cancelled',
            'from_branch_id' => 'nullable|integer|exists:branches,id',
            'to_branch_id' => 'nullable|integer|exists:branches,id',
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $filters = $request->only([
            'status', 'from_branch_id', 'to_branch_id',
            'per_page', 'sort_key', 'sort_dir',
        ]);

        // ★ Branch scoping for non-HO users.
        if (! $this->isHeadOffice($request)) {
            $user = $request->user();
            $myBranch = (int) $user->branch_id;
            $branchType = $user->branch?->type;

            if ($branchType === 'state_office') {
                // State Office sees requests where they are the destination.
                $filters['to_branch_id'] = $myBranch;
                $filters['from_branch_id'] = null;
            } else {
                // Regular branch sees requests they raised.
                $filters['from_branch_id'] = $myBranch;
                $filters['to_branch_id'] = null;
            }
        }

        $requests = $this->service->getAll($filters);

        return response()->json([
            'status' => true,
            'message' => 'Stock requests fetched.',
            'data' => [
                'data' => StockRequestResource::collection($requests->items()),
                'meta' => [
                    'current_page' => $requests->currentPage(),
                    'last_page' => $requests->lastPage(),
                    'per_page' => $requests->perPage(),
                    'total' => $requests->total(),
                    'from' => $requests->firstItem(),
                    'to' => $requests->lastItem(),
                ],
            ],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $stockRequest = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'Stock request fetched.',
            'data' => ['stock_request' => new StockRequestResource($stockRequest)],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = $request->user();
        $userBranch = $user->branch;

        if (! $userBranch) {
            throw ValidationException::withMessages([
                'from_branch_id' => 'Your account is not assigned to a branch.',
            ]);
        }

        if ($userBranch->type === 'head_office') {
            throw ValidationException::withMessages([
                'from_branch_id' => 'Head office cannot create stock requests. Use stock inward instead.',
            ]);
        }

        $validated = $request->validate([
            'to_branch_id' => ['required', 'integer', 'exists:branches,id'],
            'notes' => ['nullable', 'string'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_variant_id' => ['required', 'integer', 'exists:product_variants,id'],
            'items.*.quantity_requested' => ['required', 'integer', 'min:1'],
        ]);

        $validated['from_branch_id'] = $userBranch->id;

        $stockRequest = $this->service->create($validated, $user->id);

        return response()->json([
            'status' => true,
            'message' => 'Stock request created.',
            'data' => ['stock_request' => new StockRequestResource($stockRequest)],
        ], 201);
    }

    public function approve(Request $request, StockRequest $stockRequest): JsonResponse
    {
        $this->guardApproverBranch($request);

        $validated = $request->validate([
            'approvals' => ['required', 'array', 'min:1'],
            'approvals.*.item_id' => ['required', 'integer', 'exists:stock_request_items,id'],
            'approvals.*.quantity_approved' => ['required', 'integer', 'min:0'],
        ]);

        $stockRequest = $this->service->approve($stockRequest, $validated['approvals'], $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Stock request approved.',
            'data' => ['stock_request' => new StockRequestResource($stockRequest)],
        ]);
    }

    public function fulfill(Request $request, StockRequest $stockRequest): JsonResponse
    {
        $this->guardApproverBranch($request);

        $stockRequest = $this->service->fulfill($stockRequest, $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Stock request fulfilled.',
            'data' => ['stock_request' => new StockRequestResource($stockRequest)],
        ]);
    }

    public function cancel(StockRequest $stockRequest): JsonResponse
    {
        $stockRequest = $this->service->cancel($stockRequest);

        return response()->json([
            'status' => true,
            'message' => 'Stock request cancelled.',
            'data' => ['stock_request' => new StockRequestResource($stockRequest)],
        ]);
    }

    private function guardApproverBranch(Request $request): void
    {
        $branch = $request->user()->branch;

        if (! $branch || ! in_array($branch->type, ['head_office', 'state_office'])) {
            throw ValidationException::withMessages([
                'branch' => 'Only head office or state office can approve or fulfill stock requests.',
            ]);
        }
    }
}
