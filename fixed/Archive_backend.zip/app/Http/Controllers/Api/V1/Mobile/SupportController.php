<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\FaqCollection;
use App\Models\FaqItem;
use App\Models\SupportConversation;
use App\Models\SupportMessage;
use App\Models\TenantProfile;
use App\Services\V1\Faq\FaqMatcher;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    private const CONVERSATION_REUSE_HOURS = 24;

    private const ESCALATION_THRESHOLD = 2;

    public function __construct(protected FaqMatcher $matcher) {}

    public function faqs(): JsonResponse
    {
        $collections = FaqCollection::query()
            ->active()
            ->ordered()
            ->with(['activeItems' => function ($q) {
                $q->select('id', 'collection_id', 'question', 'sort_order')
                    ->orderBy('sort_order')
                    ->orderBy('question');
            }])
            ->get(['id', 'name', 'slug', 'description', 'icon', 'sort_order']);

        return response()->json([
            'status' => true,
            'data' => $collections->map(fn ($c) => [
                'id' => $c->id,
                'name' => $c->name,
                'slug' => $c->slug,
                'description' => $c->description,
                'icon' => $c->icon,
                'items' => $c->activeItems->map(fn ($i) => [
                    'id' => $i->id,
                    'question' => $i->question,
                ]),
            ]),
        ]);
    }

    public function faqDetail(int $id): JsonResponse
    {
        $faq = FaqItem::query()
            ->active()
            ->with('collection:id,name')
            ->findOrFail($id);

        $faq->incrementViewCount();

        return response()->json([
            'status' => true,
            'data' => [
                'id' => $faq->id,
                'question' => $faq->question,
                'answer' => $faq->answer,
                'collection' => $faq->collection ? [
                    'id' => $faq->collection->id,
                    'name' => $faq->collection->name,
                ] : null,
                'helpful_count' => $faq->helpful_count,
                'not_helpful_count' => $faq->not_helpful_count,
            ],
        ]);
    }

    public function ask(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'question' => 'required|string|min:2|max:500',
            'conversation_id' => 'nullable|integer',
        ]);

        $customerId = $request->user()->id;
        $question = trim($validated['question']);

        $conversation = $this->resolveConversation(
            $customerId,
            $validated['conversation_id'] ?? null
        );

        SupportMessage::create([
            'conversation_id' => $conversation->id,
            'sender_type' => 'customer',
            'sender_user_id' => $customerId,
            'message' => $question,
        ]);

        $result = $this->matcher->match($question, $customerId);

        if ($result->isMatched()) {
            return $this->respondMatched($conversation, $result);
        }

        return $this->respondUnmatched($conversation, $result);
    }

    private function respondMatched(SupportConversation $conversation, $result): JsonResponse
    {
        $faq = $result->faq;
        $faq->incrementViewCount();

        $reply = $faq->answer;

        SupportMessage::create([
            'conversation_id' => $conversation->id,
            'sender_type' => 'bot',
            'message' => $reply,
            'matched_faq_id' => $faq->id,
            'confidence' => $this->scoreToDecimal($result->score),
            'metadata' => $result->toMetadata(),
        ]);

        $conversation->touchLastMessage();

        return response()->json([
            'status' => true,
            'data' => [
                'conversation_id' => $conversation->id,
                'reply' => $reply,
                'matched' => true,
                'faq_id' => $faq->id,
                'confidence' => $result->confidence,
            ],
        ]);
    }

    private function respondUnmatched(SupportConversation $conversation, $result): JsonResponse
    {
        $fallback = $this->buildFallbackMessage();

        SupportMessage::create([
            'conversation_id' => $conversation->id,
            'sender_type' => 'bot',
            'message' => $fallback,
            'metadata' => array_merge(
                $result->toMetadata(),
                ['suggestions' => $result->suggestions]
            ),
        ]);

        $conversation->touchLastMessage();

        $unmatchedBotReplies = SupportMessage::query()
            ->where('conversation_id', $conversation->id)
            ->where('sender_type', 'bot')
            ->whereNull('matched_faq_id')
            ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.layer')) = ?", ['fallback'])
            ->count();

        if ($unmatchedBotReplies >= self::ESCALATION_THRESHOLD) {
            $conversation->markEscalated();
        }

        return response()->json([
            'status' => true,
            'data' => [
                'conversation_id' => $conversation->id,
                'reply' => $fallback,
                'matched' => false,
                'suggestions' => $result->suggestions,
            ],
        ]);
    }

    public function conversation(Request $request, int $id): JsonResponse
    {
        $conversation = SupportConversation::query()
            ->where('id', $id)
            ->where('customer_id', $request->user()->id)
            ->with(['messages' => fn ($q) => $q->orderBy('created_at')])
            ->firstOrFail();

        return response()->json([
            'status' => true,
            'data' => [
                'id' => $conversation->id,
                'status' => $conversation->status,
                'last_message_at' => optional($conversation->last_message_at)->toIso8601String(),
                'messages' => $conversation->messages->map(fn ($m) => [
                    'id' => $m->id,
                    'sender_type' => $m->sender_type,
                    'message' => $m->message,
                    'faq_id' => $m->matched_faq_id,
                    'created_at' => $m->created_at->toIso8601String(),
                ]),
            ],
        ]);
    }

    public function feedback(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'helpful' => 'required|boolean',
        ]);

        $faq = FaqItem::findOrFail($id);

        if ($validated['helpful']) {
            $faq->recordHelpful();
        } else {
            $faq->recordNotHelpful();
        }

        return response()->json([
            'status' => true,
            'message' => 'Thank you for the feedback.',
        ]);
    }

    private function resolveConversation(int $customerId, ?int $conversationId): SupportConversation
    {
        if ($conversationId) {
            $existing = SupportConversation::query()
                ->where('id', $conversationId)
                ->where('customer_id', $customerId)
                ->firstOrFail();

            if ($existing->status !== 'open') {
                $existing->update(['status' => 'open']);
            }

            return $existing;
        }

        $latest = SupportConversation::query()
            ->where('customer_id', $customerId)
            ->where('status', 'open')
            ->orderByDesc('last_message_at')
            ->orderByDesc('id')
            ->first();

        if ($latest) {
            $stale = $latest->last_message_at
                && $latest->last_message_at->lt(now()->subHours(self::CONVERSATION_REUSE_HOURS));

            if ($stale) {
                $latest->markResolved();
            } else {
                return $latest;
            }
        }

        return SupportConversation::create([
            'customer_id' => $customerId,
            'status' => 'open',
        ]);
    }

    private function buildFallbackMessage(): string
    {
        $profile = TenantProfile::first();

        $hasContact = $profile?->support_phone || $profile?->support_email;

        $intro = "I couldn't find an exact answer to that.";

        if ($hasContact) {
            $bits = [];
            if ($profile->support_phone) {
                $bits[] = "call us at {$profile->support_phone}";
            }
            if ($profile->support_email) {
                $bits[] = "email us at {$profile->support_email}";
            }
            $contact = implode(', or ', $bits);

            return "{$intro} You can also {$contact}, and we'll help you personally.";
        }

        return "{$intro} Please try rephrasing, or contact our support team directly.";
    }

    private function scoreToDecimal(?float $score): ?float
    {
        if ($score === null) {
            return null;
        }

        return round($score, 4);
    }
}
