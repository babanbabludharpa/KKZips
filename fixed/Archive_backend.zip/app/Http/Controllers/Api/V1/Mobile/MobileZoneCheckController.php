<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Services\V1\Orders\ZoneCheckService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MobileZoneCheckController extends Controller
{
    public function __construct(private ZoneCheckService $zoneCheck) {}

    public function check(Request $request): JsonResponse
    {
        $request->validate([
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
        ]);

        $result = $this->zoneCheck->checkPoint($request->latitude, $request->longitude);

        return response()->json([
            'status' => true,
            'data' => $result,
        ]);
    }
}
