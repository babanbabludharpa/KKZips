<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/**
 * LayoutMediaController — handles uploads for:
 *   • Carousel images (home page)
 *   • Story section image (About page)
 *   • Theme logo (mobile + web)
 *   • Footer background image
 *   • Footer background video  ← NEW
 *   • Footer video poster image
 *
 * ═══════════════════════════════════════════════════════════════════
 * SIZE LIMITS — change these constants to adjust max upload sizes.
 * Values are in KILOBYTES (Laravel's `max` rule uses KB).
 *
 *   1024 KB  = 1 MB
 *   5120 KB  = 5 MB
 *   10240 KB = 10 MB
 *   20480 KB = 20 MB
 *   51200 KB = 50 MB
 *   102400 KB = 100 MB
 *
 * IMPORTANT: PHP's upload_max_filesize and post_max_size in php.ini
 * must be AT LEAST as large as MAX_VIDEO_SIZE_KB, and Nginx's
 * client_max_body_size must also be increased. See the README for
 * the full configuration checklist.
 * ═══════════════════════════════════════════════════════════════════
 */
class LayoutMediaController extends Controller
{
    const MAX_IMAGE_SIZE_KB = 10240;

    const MAX_VIDEO_SIZE_KB = 102400;

    const ALLOWED_IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/bmp'];

    const ALLOWED_VIDEO_MIMES = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];

    public function uploadLayoutImage(Request $request): JsonResponse
    {
        $file = $request->file('image');

        if (! $file) {
            return $this->errorResponse('No file provided.', 422);
        }

        $mimeType = $file->getMimeType();
        $isVideo = in_array($mimeType, self::ALLOWED_VIDEO_MIMES);
        $isImage = in_array($mimeType, self::ALLOWED_IMAGE_MIMES);

        return $this->dispatchUpload($file, $mimeType, $isVideo, $isImage);
    }

    /**
     * Validates the file type and size, then stores it. Returns the 422
     * response for unsupported types or oversized files, or the success
     * response when the file is accepted.
     */
    private function dispatchUpload($file, string $mimeType, bool $isVideo, bool $isImage): JsonResponse
    {
        if (! $isVideo && ! $isImage) {
            return $this->unsupportedTypeResponse($mimeType);
        }

        $maxKb = $isVideo ? self::MAX_VIDEO_SIZE_KB : self::MAX_IMAGE_SIZE_KB;
        $fileSizeKb = (int) ceil($file->getSize() / 1024);

        if ($fileSizeKb > $maxKb) {
            return $this->sizeLimitExceededResponse($fileSizeKb, $maxKb, $isVideo);
        }

        return $this->storeUploadedFile($file, $isVideo, $mimeType, $fileSizeKb);
    }

    private function unsupportedTypeResponse(string $mimeType): JsonResponse
    {
        return $this->errorResponse(
            "Unsupported file type: {$mimeType}. Allowed: ".
            implode(', ', array_merge(self::ALLOWED_IMAGE_MIMES, self::ALLOWED_VIDEO_MIMES)),
            422
        );
    }

    private function storeUploadedFile($file, bool $isVideo, string $mimeType, int $fileSizeKb): JsonResponse
    {
        $folder = $isVideo ? 'layout_videos' : 'layout_images';
        $path = $file->store($folder, 'public');
        $url = url(Storage::url($path));

        return response()->json([
            'status' => true,
            'message' => ucfirst($isVideo ? 'Video' : 'Image').' uploaded successfully.',
            'data' => [
                'url' => $url,
                'path' => $path,
                'type' => $isVideo ? 'video' : 'image',
                'mime' => $mimeType,
                'size_kb' => $fileSizeKb,
                'filename' => $file->getClientOriginalName(),
            ],
        ]);
    }

    private function sizeLimitExceededResponse(int $fileSizeKb, int $maxKb, bool $isVideo): JsonResponse
    {
        $maxMb = $maxKb / 1024;
        $fileMb = $fileSizeKb / 1024;
        $kind = $isVideo ? 'videos' : 'images';

        return $this->errorResponse(
            "File too large ({$fileMb}MB). Maximum for {$kind} is {$maxMb}MB.",
            422
        );
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
        ], $status);
    }
}
