<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Services\V1\Orders\GiftService;
use Illuminate\Http\JsonResponse;

/**
 * ★ FREE GIFTS — customer-facing endpoint for the cart progress bar.
 *
 * Public (no auth) on purpose: the cart drawer renders before login,
 * exactly like the product catalog. Returns the active campaign's
 * tiers + gift preview cards, or null when no campaign is running.
 * Eligibility (caps) and live branch stock are resolved server-side
 * at order preview — this payload is display-only.
 */
class GiftController extends Controller
{
    public function __construct(protected GiftService $gifts) {}

    public function active(): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => $this->gifts->activeCampaignPayload(),
        ]);
    }
}
