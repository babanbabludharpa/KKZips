<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Events\AppLayoutUpdated;
use App\Http\Controllers\Controller;
use App\Models\AppLayout;
use App\Support\AppLayoutValidator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Broadcast;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AppLayoutController extends Controller
{
    /**
     * Mobile app: fetch the currently-active layout.
     * PUBLIC route — works before login (it IS the home screen).
     */
    public function getActiveLayout(): JsonResponse
    {
        $layout = AppLayout::currentActive();

        if (! $layout) {
            // Hardcoded fallback so a freshly-onboarded tenant still has
            // a usable home screen before admin configures anything.
            return response()->json([
                'status' => true,
                'data' => [
                    'version_name' => 'System Default',
                    'components' => $this->defaultComponents(),
                    'theme_config' => $this->defaultThemeConfig(),
                    'is_default' => true,
                ],
            ]);
        }

        $data = $layout->toArray();
        // Always return a theme_config object — fall back to defaults if
        // the row predates the theme_config column or has null stored.
        $data['theme_config'] = $this->resolveThemeConfig($data['theme_config'] ?? null);
        $data['is_default'] = false;

        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }

    /**
     * Admin: list all layouts (most recent 50).
     */
    public function index(): JsonResponse
    {
        $layouts = AppLayout::orderByDesc('created_at')
            ->limit(50)
            ->get(['id', 'version_name', 'is_active', 'is_draft', 'scheduled_at', 'expires_at', 'created_by', 'created_at', 'published_at']);

        return response()->json([
            'status' => true,
            'data' => $layouts,
        ]);
    }

    /**
     * Admin: fetch a single layout (full components + theme_config).
     */
    public function show(int $id): JsonResponse
    {
        $layout = AppLayout::findOrFail($id);
        $data = $layout->toArray();
        $data['theme_config'] = $this->resolveThemeConfig($data['theme_config'] ?? null);

        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }

    /**
     * Admin: create or update a layout, then publish (or save as draft).
     *
     * Body:
     *   {
     *     "version_name": "Diwali 2025",
     *     "components":    [...],
     *     "theme_config":  { primary_color, accent_color, logo_url, brand_name, font_family },
     *     "is_draft":      false,
     *     "id":            null
     *   }
     */
    public function saveLayout(Request $request): JsonResponse
    {
        try {
            $data = $request->validate([
                'version_name' => ['required', 'string', 'max:120'],
                'components' => ['required', 'array'],
                'theme_config' => ['sometimes', 'array'],
                'is_draft' => ['sometimes', 'boolean'],
                'id' => ['nullable', 'integer', 'exists:app_layouts,id'],
            ]);

            AppLayoutValidator::validate($data['components']);

            $themeConfig = $this->sanitizeThemeConfig($data['theme_config'] ?? []);
            $isDraft = (bool) ($data['is_draft'] ?? false);

            // ★ Transaction returns the model; no response building, no broadcast inside.
            $layout = DB::transaction(function () use ($data, $isDraft, $themeConfig, $request) {
                if (! empty($data['id'])) {
                    $layout = AppLayout::findOrFail($data['id']);
                    $layout->fill([
                        'version_name' => $data['version_name'],
                        'components' => $data['components'],
                        'theme_config' => $themeConfig,
                        'is_draft' => $isDraft,
                        'is_active' => $isDraft ? false : true,
                    ]);
                    $layout->save();
                } else {
                    $layout = AppLayout::create([
                        'version_name' => $data['version_name'],
                        'components' => $data['components'],
                        'theme_config' => $themeConfig,
                        'is_draft' => $isDraft,
                        'is_active' => ! $isDraft,
                        'created_by' => $request->user()?->id,
                    ]);
                }

                return $layout;
            });

            // ★ Broadcast AFTER commit.
            if (! $isDraft) {
                broadcast(new AppLayoutUpdated($layout))->via('reverb');
            }

            // ★ Response built outside the transaction.
            return response()->json([
                'status' => true,
                'message' => $isDraft
                    ? 'Draft saved.'
                    : 'Layout published and broadcast to all apps.',
                'data' => $layout->fresh(),
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'status' => false,
                'message' => 'Failed to save layout: '.$e->getMessage(),
            ], 500);
        }
    }

    /**
     * Admin: activate a previously-saved layout (draft or older version).
     */
    public function activate(int $id): JsonResponse
    {
        try {
            // ★ Transaction returns the model.
            $layout = DB::transaction(function () use ($id) {
                $layout = AppLayout::findOrFail($id);
                $layout->is_active = true;
                $layout->is_draft = false;
                $layout->save();

                return $layout;
            });

            // ★ Broadcast AFTER commit.
            broadcast(new AppLayoutUpdated($layout))->via('reverb');

            return response()->json([
                'status' => true,
                'message' => 'Layout activated and broadcast.',
                'data' => $layout->fresh(),
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'status' => false,
                'message' => 'Activation failed: '.$e->getMessage(),
            ], 500);
        }
    }

    /**
     * Admin: duplicate a layout (handy for iterating without losing the original).
     */
    public function duplicate(int $id): JsonResponse
    {
        $source = AppLayout::findOrFail($id);
        $copy = AppLayout::create([
            'version_name' => $source->version_name.' (Copy)',
            'components' => $source->components,
            'theme_config' => $source->theme_config,
            'is_draft' => true,
            'is_active' => false,
            'created_by' => request()->user()?->id,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Layout duplicated as draft.',
            'data' => $copy,
        ]);
    }

    /**
     * Admin: delete a layout. Never deletes the currently-active one.
     */
    public function destroy(int $id): JsonResponse
    {
        $layout = AppLayout::findOrFail($id);
        if ($layout->is_active) {
            return response()->json([
                'status' => false,
                'message' => 'Cannot delete the active layout. Activate another first.',
            ], 422);
        }
        $layout->delete();

        return response()->json([
            'status' => true,
            'message' => 'Layout deleted.',
        ]);
    }

    // ──────────────────────────────────────────────────────────────────
    // THEME CONFIG helpers
    // ──────────────────────────────────────────────────────────────────

    /**
     * Returns a normalized theme_config array, falling back to defaults
     * for any missing/empty fields. Never returns null — always a full
     * object so the Flutter side can safely index into it.
     */
    private function resolveThemeConfig($raw): array
    {
        $raw = is_array($raw) ? $raw : [];
        $defaults = $this->defaultThemeConfig();

        return [
            'primary_color' => $this->nonEmpty($raw['primary_color'] ?? null, $defaults['primary_color']),
            'accent_color' => $this->nonEmpty($raw['accent_color'] ?? null, $defaults['accent_color']),
            'logo_url' => $this->nonEmpty($raw['logo_url'] ?? null, $defaults['logo_url']),
            'brand_name' => $this->nonEmpty($raw['brand_name'] ?? null, $defaults['brand_name']),
            'font_family' => $this->nonEmpty($raw['font_family'] ?? null, $defaults['font_family']),
            'legal_documents' => $raw['legal_documents'] ?? null,
        ];
    }

    /**
     * Strips unknown keys, validates hex colors + string lengths.
     * Returns a clean array safe for storage.
     */
    private function sanitizeThemeConfig(array $raw): array
    {
        $clean = [];

        // Primary + accent colors — accept #RRGGBB or #RGB hex strings.
        foreach (['primary_color', 'accent_color'] as $colorField) {
            $val = trim((string) ($raw[$colorField] ?? ''));
            if (preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $val)) {
                $clean[$colorField] = $val;
            }
        }

        // Logo URL — string, max 500 chars.
        $logo = trim((string) ($raw['logo_url'] ?? ''));
        if ($logo !== '' && strlen($logo) <= 500) {
            $clean['logo_url'] = $logo;
        }

        // Brand name — string, max 100 chars.
        $brand = trim((string) ($raw['brand_name'] ?? ''));
        if ($brand !== '' && strlen($brand) <= 100) {
            $clean['brand_name'] = $brand;
        }

        // Font family — must be one of the supported options.
        $allowedFonts = ['Inter', 'Roboto', 'Poppins', 'Montserrat', 'Lato', 'OpenSans', 'Nunito', 'System'];
        $font = trim((string) ($raw['font_family'] ?? ''));
        if (in_array($font, $allowedFonts, true)) {
            $clean['font_family'] = $font;
        }
        // ★ NEW: Pass through legal_documents as-is (admin-edited JSON blob
        // containing customer_app_privacy + customer_app_terms). Not validated
        // here — the admin UI controls the structure.
        if (isset($raw['legal_documents']) && is_array($raw['legal_documents'])) {
            $clean['legal_documents'] = $raw['legal_documents'];
        }

        return $clean;
    }

    private function nonEmpty($val, $fallback)
    {
        if (is_string($val)) {
            $val = trim($val);
        }

        return ($val === '' || $val === null) ? $fallback : $val;
    }

    /**
     * Default mobile theme. Same shape as the Flutter FlavorConfig
     * defaults so an unconfigured tenant sees the same colors as their
     * flavor baseline.
     */
    private function defaultThemeConfig(): array
    {
        return [
            'primary_color' => '#2563EB',
            'accent_color' => '#9333EA',
            'logo_url' => '',
            'brand_name' => '',
            'font_family' => 'Inter',
        ];
    }

    // ──────────────────────────────────────────────────────────────────
    // Default components returned when no active layout exists yet.
    // Kept here (not in the model) so it can be tailored per-tenant later.
    // ──────────────────────────────────────────────────────────────────
    private function defaultComponents(): array
    {
        return [
            [
                'type' => 'carousel',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'data' => [
                    'autoplay' => true,
                    'interval_seconds' => 4,
                    'aspect_ratio' => '16:9',
                    'images' => [],
                ],
            ],
            [
                'type' => 'categories_grid',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'title' => 'Shop by Category',
                'data' => [
                    'layout' => 'circle',
                    'category_ids' => [],
                    'limit' => 10,
                    'show_all' => true,
                ],
            ],
            [
                'type' => 'dashboard_menu',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'data' => [
                    'title' => 'What would you like to do?',
                    'columns' => 1,
                    'items' => [
                        ['id' => 'm1', 'label' => 'My Profile',    'icon' => 'person',       'color' => '#2563EB', 'route' => 'profile'],
                        ['id' => 'm2', 'label' => 'Subscriptions', 'icon' => 'calendar',     'color' => '#16A34A', 'route' => 'subscriptions'],
                        ['id' => 'm3', 'label' => 'Products',      'icon' => 'shopping_bag', 'color' => '#9333EA', 'route' => 'products'],
                        ['id' => 'm4', 'label' => 'My Orders',     'icon' => 'receipt',      'color' => '#EA580C', 'route' => 'orders'],
                    ],
                ],
            ],
            [
                'type' => 'quick_calendar',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'title' => "This Week's Deliveries",
                'data' => ['days_to_show' => 7, 'subscription_plan_id' => null, 'show_only_delivery_days' => true],
            ],
            [
                'type' => 'popular_products',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'title' => 'Trending Products',
                'data' => ['source' => 'recent', 'product_ids' => [], 'fallback_strategy' => 'recent', 'limit' => 4],
            ],
            [
                'type' => 'all_products',
                'id' => (string) Str::uuid(),
                'visible' => true,
                'title' => 'All Products',
                'data' => ['category_id' => null, 'sort_by' => 'name_asc', 'columns' => 2, 'page_size' => 20],
            ],
        ];
    }
}
