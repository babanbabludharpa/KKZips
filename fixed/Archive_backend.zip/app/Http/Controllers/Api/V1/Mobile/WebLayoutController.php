<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\WebLayout;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * ─────────────────────────────────────────────────────────────────────────
 * WebLayoutController — NO BROADCASTING version
 *
 * Path: app/Http/Controllers/Api/V1/Mobile/WebLayoutController.php
 *
 * Changes from previous version:
 *   • saveLayout() no longer calls broadcast() — broadcasting dependency
 *     removed to fix "Class view does not exist" framework boot error.
 *   • Customer portal polls the layout endpoint every 30 seconds to
 *     pick up admin changes.
 *
 * Routes:
 *   GET  /mobile/web/layout       → getActiveLayout()  (public)
 *   POST /mobile/web/layout/save  → saveLayout()       (admin only)
 *   GET  /mobile/web/layouts      → index()            (admin only)
 * ─────────────────────────────────────────────────────────────────────────
 */
class WebLayoutController extends Controller
{
    public function getActiveLayout(): JsonResponse
    {
        $layout = WebLayout::where('is_active', true)
            ->where('is_draft', false)
            ->orderByDesc('published_at')
            ->orderByDesc('id')
            ->first();

        if (! $layout) {
            return response()->json([
                'status' => true,
                'data' => [
                    'version_name' => 'System Default',
                    'theme_config' => $this->defaultThemeConfig(),
                    'layout_components' => [],
                    'navigation_config' => $this->defaultNavigationConfig(),
                    'footer_config' => $this->defaultFooterConfig(),
                    'product_display_config' => $this->defaultProductDisplayConfig(),
                    'custom_pages' => [],
                    'is_default' => true,
                ],
            ]);
        }

        $data = $layout->toArray();
        $data['theme_config'] = $data['theme_config'] ?? $this->defaultThemeConfig();
        $data['navigation_config'] = $data['navigation_config'] ?? $this->defaultNavigationConfig();
        $data['footer_config'] = $data['footer_config'] ?? $this->defaultFooterConfig();
        $data['product_display_config'] = $data['product_display_config'] ?? $this->defaultProductDisplayConfig();
        $data['custom_pages'] = $data['custom_pages'] ?? [];
        $data['is_default'] = false;

        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }

    public function saveLayout(Request $request): JsonResponse
    {
        $data = $request->validate([
            'version_name' => 'required|string|max:120',
            'theme_config' => 'sometimes|array',
            'layout_components' => 'sometimes|array',
            'navigation_config' => 'sometimes|nullable|array',
            'footer_config' => 'sometimes|nullable|array',
            'product_display_config' => 'sometimes|nullable|array',
            'custom_pages' => 'sometimes|nullable|array',
            'is_draft' => 'sometimes|boolean',
            'id' => 'nullable|integer|exists:web_layouts,id',
        ]);

        $isDraft = (bool) ($data['is_draft'] ?? false);

        return DB::transaction(function () use ($data, $isDraft) {
            if (! empty($data['id'])) {
                $layout = WebLayout::findOrFail($data['id']);
                $layout->fill([
                    'version_name' => $data['version_name'],
                    'theme_config' => $data['theme_config'] ?? $layout->theme_config,
                    'layout_components' => $data['layout_components'] ?? $layout->layout_components,
                    'navigation_config' => $data['navigation_config'] ?? $layout->navigation_config,
                    'footer_config' => $data['footer_config'] ?? $layout->footer_config,
                    'product_display_config' => $data['product_display_config'] ?? $layout->product_display_config,
                    'custom_pages' => $data['custom_pages'] ?? $layout->custom_pages,
                    'is_draft' => $isDraft,
                    'is_active' => ! $isDraft,
                ]);
                $layout->save();
            } else {
                $layout = WebLayout::create([
                    'version_name' => $data['version_name'],
                    'theme_config' => $data['theme_config'] ?? [],
                    'layout_components' => $data['layout_components'] ?? [],
                    'navigation_config' => $data['navigation_config'] ?? null,
                    'footer_config' => $data['footer_config'] ?? null,
                    'product_display_config' => $data['product_display_config'] ?? null,
                    'custom_pages' => $data['custom_pages'] ?? null,
                    'is_draft' => $isDraft,
                    'is_active' => ! $isDraft,
                ]);
            }

            // If publishing, deactivate all other layouts
            if (! $isDraft) {
                WebLayout::where('id', '!=', $layout->id)
                    ->where('is_active', true)
                    ->update(['is_active' => false]);

                // ★ BROADCASTING REMOVED — customer portal polls every 30s
                // If you want real-time updates later, re-add this once
                // Pusher is properly configured (see README):
                //
                //   try {
                //       broadcast(new \App\Events\WebLayoutUpdated($layout))->toOthers();
                //   } catch (\Throwable $e) {
                //       \Log::warning('WebLayout broadcast failed: ' . $e->getMessage());
                //   }
            }

            return response()->json([
                'status' => true,
                'message' => $isDraft ? 'Draft saved.' : 'Layout published!',
                'data' => $layout->fresh(),
            ]);
        });
    }

    public function index(): JsonResponse
    {
        $layouts = WebLayout::orderByDesc('created_at')->limit(50)->get();

        return response()->json([
            'status' => true,
            'data' => $layouts,
        ]);
    }

    // ═══════════════════════════════════════════════════════════════════
    // DEFAULT CONFIG VALUES
    // ═══════════════════════════════════════════════════════════════════

    private function defaultThemeConfig(): array
    {
        return [
            'primary_color' => '#FF7132',
            'secondary_color' => '#1E293B',
            'font_family' => 'Inter, sans-serif',
            'logo_url' => null,
            'brand_name' => 'Shop Hub',
            'border_radius' => 12,
            'shadow_style' => 'medium',
            'button_style' => 'rounded',
            'card_style' => 'shadowed',
            'typography_scale' => 'normal',
            'hero_style' => 'solid',
            'background_pattern' => 'dotted',
        ];
    }

    private function defaultNavigationConfig(): array
    {
        return [
            'links' => [
                ['id' => 'home',          'label' => 'Home',      'url' => '/',             'visible' => true, 'order' => 1],
                ['id' => 'about',         'label' => 'About Us',  'url' => '/about',        'visible' => true, 'order' => 2],
                ['id' => 'products',      'label' => 'Products',  'url' => '/products',     'visible' => true, 'order' => 3],
                ['id' => 'subscription',  'label' => 'Order Now', 'url' => '/subscription', 'visible' => true, 'order' => 4],
                ['id' => 'contact',       'label' => 'Contact',   'url' => '/contact',      'visible' => true, 'order' => 5],
            ],
            'navbar_style' => 'solid',
            'mobile_menu_style' => 'drawer',
        ];
    }

    private function defaultFooterConfig(): array
    {
        return [
            'enabled' => true,
            'bg_color' => '#1E293B',
            'text_color' => '#94A3B8',
            'columns' => [
                [
                    'id' => 'col1',
                    'title' => 'Shop Hub',
                    'type' => 'text',
                    'content' => 'Your daily needs, delivered fresh.',
                ],
                [
                    'id' => 'col2',
                    'title' => 'Quick Links',
                    'type' => 'links',
                    'links' => [
                        ['label' => 'Home',     'url' => '/'],
                        ['label' => 'Products', 'url' => '/products'],
                        ['label' => 'About',    'url' => '/about'],
                    ],
                ],
                [
                    'id' => 'col3',
                    'title' => 'Contact',
                    'type' => 'links',
                    'links' => [
                        ['label' => 'Contact Us', 'url' => '/contact'],
                    ],
                ],
            ],
            'copyright' => '© '.date('Y').' Shop Hub. All rights reserved.',
            'show_payment_badges' => true,
            'show_app_links' => false,
        ];
    }

    private function defaultProductDisplayConfig(): array
    {
        return [
            'default_view' => 'grid',
            'products_per_row' => 4,
            'show_mrp' => true,
            'show_discount' => true,
            'show_rating' => true,
            'show_stock' => true,
            'show_unit' => true,
            'default_sort' => 'name_asc',
            'card_style' => 'standard',
            'quick_view' => true,
            'show_add_to_cart' => true,
            'show_wishlist' => true,
            'image_aspect' => 'square',
            'out_of_stock_behavior' => 'dim',
        ];
    }
}
