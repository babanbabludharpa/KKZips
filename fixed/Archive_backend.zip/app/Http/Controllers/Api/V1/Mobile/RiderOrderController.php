<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\Tenant\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * ─────────────────────────────────────────────────────────────────────────
 * RiderOrderController — Order list, detail, and status updates for riders
 *
 * Path: app/Http/Controllers/Api/V1/Mobile/RiderOrderController.php
 *
 * Routes (add to routes/api.php inside the `tenant.mobile` group,
 * protected by `mobile.rider` middleware):
 *
 *   GET  /api/v1/mobile/rider/orders                  → index()    (list assigned orders)
 *   GET  /api/v1/mobile/rider/orders/{orderId}        → show()     (order detail)
 *   POST /api/v1/mobile/rider/orders/{orderId}/pickup → pickup()   (mark picked up)
 *   POST /api/v1/mobile/rider/orders/{orderId}/deliver → deliver() (mark delivered + photo + GPS)
 *
 * STATUS FLOW:
 *   out_for_delivery  → (admin assigns rider, sets delivery_boy_id + assigned_at)
 *       ↓
 *   picked_up         → (rider clicks "Mark Picked Up")
 *       ↓
 *   delivered         → (rider captures photo + GPS, clicks "Mark Delivered")
 * ─────────────────────────────────────────────────────────────────────────
 */
class RiderOrderController extends Controller
{
    private const MSG_ORDER_NOT_ASSIGNED = 'Order not found or not assigned to you.';

    private const STATUS_OUT_FOR_DELIVERY = 'out_for_delivery';

    private const STATUS_PICKED_UP = 'picked_up';

    private const STATUS_DELIVERED = 'delivered';

    public function index(Request $request): JsonResponse
    {
        $rider = $request->user();
        $status = $request->query('status', self::STATUS_OUT_FOR_DELIVERY);

        $query = Order::where('delivery_boy_id', $rider->id)
            ->with(['items.variant.product', 'branch', 'customer'])
            ->orderByDesc('assigned_at')
            ->orderByDesc('created_at');

        $this->applyStatusFilter($query, $status);

        $orders = $query->paginate(50);

        $formattedData = $orders->getCollection()->map(fn ($order) => $this->formatOrder($order))->toArray();

        return response()->json([
            'status' => true,
            'data' => [
                'current_page' => $orders->currentPage(),
                'data' => $formattedData,
                'total' => $orders->total(),
                'per_page' => $orders->perPage(),
                'last_page' => $orders->lastPage(),
            ],
        ]);
    }

    private function applyStatusFilter($query, string $status): void
    {
        if ($status === 'all') {
            return;
        }

        if (in_array($status, [
            self::STATUS_OUT_FOR_DELIVERY,
            self::STATUS_PICKED_UP,
            self::STATUS_DELIVERED,
        ], true)) {
            $query->where('status', $status);
        }
    }

    public function show(Request $request, int $orderId): JsonResponse
    {
        $order = $this->findRiderOrder($request, $orderId, ['items.variant.product', 'branch', 'customer', 'deliveryBoy']);

        if (! $order) {
            return $this->orderNotFoundResponse();
        }

        return response()->json([
            'status' => true,
            'data' => $this->formatOrder($order),
        ]);
    }

    public function pickup(Request $request, int $orderId): JsonResponse
    {
        $order = $this->findRiderOrder($request, $orderId);

        if (! $order) {
            return $this->orderNotFoundResponse();
        }

        if ($order->status !== self::STATUS_OUT_FOR_DELIVERY) {
            return $this->errorResponse("Cannot pick up order. Current status: {$order->status}.", 422);
        }

        $order->update(['status' => self::STATUS_PICKED_UP]);

        return response()->json([
            'status' => true,
            'message' => 'Order marked as picked up.',
            'data' => $this->formatOrder($order),
        ]);
    }

    public function deliver(Request $request, int $orderId): JsonResponse
    {
        $validationError = $this->validateDeliverRequest($request);

        if ($validationError) {
            return $validationError;
        }

        $order = $this->findRiderOrder($request, $orderId);

        if (! $order) {
            return $this->orderNotFoundResponse();
        }

        $statusError = $this->checkDeliverableStatus($order);

        if ($statusError) {
            return $statusError;
        }

        $this->markDelivered($order, $request);

        return response()->json([
            'status' => true,
            'message' => 'Order marked as delivered.',
            'data' => $this->formatOrder($order->fresh()),
        ]);
    }

    /**
     * Returns a 422 JsonResponse if the order is not in a deliverable state,
     * or null if it can be delivered.
     */
    private function checkDeliverableStatus(Order $order): ?JsonResponse
    {
        if ($order->status === self::STATUS_PICKED_UP) {
            return null;
        }

        return $this->errorResponse(
            "Cannot deliver order. Current status: {$order->status}. Must be picked_up first.",
            422
        );
    }

    /**
     * Returns a 422 JsonResponse if validation fails, or null if the request is valid.
     */
    private function validateDeliverRequest(Request $request): ?JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'photo' => 'required|file|image|max:8192',
            'lat' => 'required|numeric',
            'lng' => 'required|numeric',
            'delivery_remark' => 'nullable|string|max:500',
        ]);

        if (! $validator->fails()) {
            return null;
        }

        return response()->json([
            'status' => false,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }

    private function markDelivered(Order $order, Request $request): void
    {
        $tenantId = tenant('id') ?? 'unknown';
        $photoFile = $request->file('photo');
        $photoPath = $photoFile->storeAs(
            "tenants/{$tenantId}/deliveries",
            "order_{$order->id}_".time().'.'.$photoFile->getClientOriginalExtension(),
            'public'
        );

        $order->update([
            'status' => self::STATUS_DELIVERED,
            'delivered_at' => now(),
            'delivery_remark' => $request->input('delivery_remark'),
            'delivery_photo_path' => $photoPath,
            'delivery_lat' => $request->input('lat'),
            'delivery_lng' => $request->input('lng'),
        ]);
    }

    private function findRiderOrder(Request $request, int $orderId, array $with = []): ?Order
    {
        $query = Order::where('id', $orderId)
            ->where('delivery_boy_id', $request->user()->id);

        if (! empty($with)) {
            $query->with($with);
        }

        return $query->first();
    }

    private function formatOrder(Order $order): array
    {
        $deliveryAddress = $order->delivery_address ?? [];

        return [
            'id' => $order->id,
            'order_number' => $order->order_number,
            'status' => $order->status,
            'payment_mode' => $order->payment_mode,
            'payment_status' => $order->payment_status,
            'total' => (float) $order->total,
            'subtotal' => (float) $order->subtotal,
            'delivery_charge' => (float) $order->delivery_charge,
            'customer_remark' => $order->customer_remark,
            'delivery_remark' => $order->delivery_remark,
            'assigned_at' => $order->assigned_at?->toDateTimeString(),
            'delivered_at' => $order->delivered_at?->toDateTimeString(),

            'delivery_address' => [
                'name' => $deliveryAddress['name'] ?? null,
                'phone' => $deliveryAddress['phone'] ?? null,
                'line1' => $deliveryAddress['line1'] ?? null,
                'line2' => $deliveryAddress['line2'] ?? null,
                'city' => $deliveryAddress['city'] ?? null,
                'pincode' => $deliveryAddress['pincode'] ?? null,
                'lat' => $deliveryAddress['lat'] ?? $order->customer_lat,
                'lng' => $deliveryAddress['lng'] ?? $order->customer_lng,
            ],

            'branch' => $order->branch ? [
                'id' => $order->branch->id,
                'name' => $order->branch->name ?? null,
                'address' => $order->branch->address ?? null,
                'phone' => $order->branch->phone ?? null,
            ] : null,

            'items' => $order->items->map(fn ($item) => [
                'id' => $item->id,
                'product_variant_id' => $item->product_variant_id,
                'quantity' => $item->quantity,
                'unit_price' => (float) $item->unit_price,
                'final_price' => (float) $item->final_price,
                'line_total' => (float) $item->line_total,
                'product_name' => $item->variant?->product?->name ?? 'Unknown Product',
                'variant_sku' => $item->variant?->sku ?? null,
                'unit_abbr' => $item->variant?->unit?->abbreviation ?? null,
                'is_gift' => (bool) $item->is_gift, // ★ FREE GIFTS — rider sees a FREE chip on gift lines
                'image_url' => $item->variant?->image
                    ? url('storage/tenants/'.tenant('id').'/variants/'.$item->variant->image)
                    : null,
            ]),

            'customer' => $order->customer ? [
                'id' => $order->customer->id,
                'name' => $order->customer->name,
                'phone' => $order->customer->phone,
            ] : null,

            'delivery_photo_url' => $order->delivery_photo_path
                ? url('storage/'.$order->delivery_photo_path)
                : null,
            'delivery_lat' => $order->delivery_lat ? (float) $order->delivery_lat : null,
            'delivery_lng' => $order->delivery_lng ? (float) $order->delivery_lng : null,
        ];
    }

    private function orderNotFoundResponse(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => self::MSG_ORDER_NOT_ASSIGNED,
        ], 404);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
        ], $status);
    }
}
