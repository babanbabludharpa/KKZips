<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\AppLayout;
use Illuminate\Http\JsonResponse;

class MobileLegalController extends Controller
{
    public function show(string $type): JsonResponse
    {
        if (! in_array($type, ['privacy', 'terms'])) {
            return $this->errorResponse('Invalid document type. Use "privacy" or "terms".', 400);
        }

        $layout = AppLayout::currentActive();
        if (! $layout) {
            return $this->errorResponse('No active layout configured.', 404);
        }

        return $this->respondWithDocument($type, $layout->theme_config ?? []);
    }

    private function respondWithDocument(string $type, array $rawThemeConfig): JsonResponse
    {
        $themeConfig = $this->resolveThemeConfig($rawThemeConfig);
        $legalDocs = $themeConfig['legal_documents'] ?? null;

        if (! $legalDocs) {
            return $this->errorResponse('Legal documents not configured by tenant.', 404);
        }

        $key = $type === 'privacy' ? 'customer_app_privacy' : 'customer_app_terms';
        $doc = $legalDocs[$key] ?? null;

        if (! $doc) {
            return $this->errorResponse(ucfirst($type).' document not configured.', 404);
        }

        return response()->json([
            'status' => true,
            'data' => $doc,
        ]);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
        ], $status);
    }

    // Same helper as in AppLayoutController — or extract to a trait
    private function resolveThemeConfig(array $raw): array
    {
        $defaults = [
            'primary_color' => '#2563EB',
            'accent_color' => '#9333EA',
            'logo_url' => '',
            'brand_name' => '',
            'font_family' => 'Inter',
            'legal_documents' => null,
        ];

        return array_merge($defaults, $raw);
    }
}
