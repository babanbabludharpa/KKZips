<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\InvoiceResource;
use App\Models\Invoice;
use Illuminate\Http\Request;

class CustomerInvoiceController extends Controller
{
    public function index(Request $request)
    {
        $invoices = Invoice::where('customer_id', $request->user()->id)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Invoices retrieved successfully.',
            'data' => InvoiceResource::collection($invoices),
        ]);
    }

    // Explicit findOrFail instead of implicit binding - see note in
    // CustomerSubscriptionController::show for why.
    public function show(Request $request, int $invoiceId)
    {
        $invoice = Invoice::findOrFail($invoiceId);
        abort_unless($invoice->customer_id === $request->user()->id, 403);

        $invoice->load(['items', 'payments']);

        return response()->json([
            'status' => true,
            'message' => 'Invoice retrieved successfully.',
            'data' => new InvoiceResource($invoice),
        ]);
    }
}
