<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\DeliveryBoy;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RiderAuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $rider = DeliveryBoy::where('username', $request->username)->first();

        if (! $rider || ! Hash::check($request->password, $rider->password)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid credentials.',
            ], 401);
        }

        if (! $rider->is_active) {
            return response()->json([
                'status' => false,
                'message' => 'Access denied. This rider account is inactive.',
            ], 403);
        }

        $rider->tokens()->where('name', 'rider-app')->delete();
        $token = $rider->createToken('rider-app', ['rider'])->plainTextToken;
        $rider->update(['last_login_at' => now()]);

        return response()->json([
            'status' => true,
            'message' => 'Login successful.',
            'data' => [
                'token' => $token,
                'rider' => [
                    'id' => $rider->id,
                    'name' => $rider->name,
                    'username' => $rider->username,
                    'email' => $rider->email,
                    'mobile_number' => $rider->mobile_number,
                    'branch_id' => $rider->branch_id,
                    'is_active' => $rider->is_active,
                    'max_daily_deliveries' => $rider->max_daily_deliveries,
                ],
            ],
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $rider = auth('rider')->user();

        if ($rider && $rider->currentAccessToken()) {
            $rider->currentAccessToken()->delete();
        }

        return response()->json(['status' => true, 'message' => 'Logged out.']);
    }

    public function me(Request $request): JsonResponse
    {
        $rider = auth('rider')->user();

        return response()->json([
            'status' => true,
            'data' => $this->formatRider($rider),
        ]);
    }

    private function formatRider(DeliveryBoy $rider): array
    {
        return [
            'id' => $rider->id,
            'name' => $rider->name,
            'mobile_number' => $rider->mobile_number,
            'email' => $rider->email,
            'branch_id' => $rider->branch_id,
            'is_active' => $rider->is_active,
            'max_daily_deliveries' => $rider->max_daily_deliveries,
        ];
    }
}
