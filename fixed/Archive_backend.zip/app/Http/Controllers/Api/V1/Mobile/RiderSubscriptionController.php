<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\DeliveryAssignment;
use App\Services\V1\Subscriptions\DeliveryAssignmentService;
use App\Services\V1\Subscriptions\DeliveryConfirmationRequest;
use App\Services\V1\Subscriptions\DeliveryConfirmationService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class RiderSubscriptionController extends Controller
{
    public function __construct(
        protected DeliveryConfirmationService $service,
        protected DeliveryAssignmentService $assignmentService,
    ) {}

    public function index(Request $request)
    {
        $date = $request->date ? Carbon::parse($request->date) : now();

        $assignments = DeliveryAssignment::where('delivery_boy_id', $request->user()->id)
            ->whereDate('occurrence_date', $date)
            ->where('status', 'pending')
            ->with([
                'occurrence.subscriptionItem.slot',
                'occurrence.subscriptionItem.productVariant.product',
                'occurrence.subscriptionItem.subscription.customer',
                'occurrence.subscriptionItem.subscription.deliveryAddress',
            ])
            ->orderBy('sequence')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Assignments retrieved successfully.',
            'data' => $assignments->map(fn ($a) => [
                'delivery_assignment_id' => $a->id,
                'occurrence_id' => $a->occurrence->id,
                'occurrence_status' => $a->occurrence->status,
                'product_name' => $a->occurrence->subscriptionItem->productVariant->product->name ?? null,
                'qty' => $a->occurrence->qty,
                'customer_name' => $a->occurrence->subscriptionItem->subscription->customer->name ?? null,
                'address' => $a->occurrence->subscriptionItem->subscription->deliveryAddress->address_line1 ?? null,
                'slot' => $this->slotPayload($a->occurrence->subscriptionItem->slot),
                'sequence' => $a->sequence,
            ]),
        ]);
    }

    public function history(Request $request)
    {
        $date = $request->date ? Carbon::parse($request->date) : now();

        $assignments = DeliveryAssignment::where('delivery_boy_id', $request->user()->id)
            ->whereIn('status', ['delivered', 'not_delivered'])
            ->whereHas('occurrence', function ($q) use ($date) {
                $q->whereRaw('DATE(COALESCE(delivered_at, updated_at)) = ?', [$date->toDateString()]);
            })
            ->with([
                'occurrence.subscriptionItem.slot',
                'occurrence.subscriptionItem.productVariant.product',
                'occurrence.subscriptionItem.subscription.customer',
                'occurrence.subscriptionItem.subscription.deliveryAddress',
            ])
            ->orderBy('sequence')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Delivery history retrieved successfully.',
            'data' => $assignments->map(function ($a) {
                $occurrence = $a->occurrence;

                return [
                    'delivery_assignment_id' => $a->id,
                    'occurrence_id' => $occurrence->id,
                    'status' => $a->status,
                    'occurrence_date' => optional($occurrence->occurrence_date)->toDateString(),
                    'product_name' => $occurrence->subscriptionItem->productVariant->product->name ?? null,
                    'qty' => $occurrence->qty,
                    'customer_name' => $occurrence->subscriptionItem->subscription->customer->name ?? null,
                    'address' => $occurrence->subscriptionItem->subscription->deliveryAddress->address_line1 ?? null,
                    'slot' => $this->slotPayload($occurrence->subscriptionItem->slot),
                    'sequence' => $a->sequence,
                    'delivered_at' => optional($occurrence->delivered_at)->toDateTimeString(),
                    'delivery_note' => $occurrence->delivery_note,
                    'not_delivered_reason' => $occurrence->not_delivered_reason,
                    'not_delivered_note' => $occurrence->not_delivered_note,
                    'delivery_lat' => $occurrence->delivery_lat,
                    'delivery_lng' => $occurrence->delivery_lng,
                    'delivery_photo_url' => $occurrence->delivery_photo_path
                        ? Storage::disk('public')->url($occurrence->delivery_photo_path)
                        : null,
                ];
            }),
        ]);
    }

    public function pickup(Request $request, int $assignmentId)
    {
        $result = $this->assignmentService->pickup($request->user()->id, $assignmentId);

        return response()->json([
            'status' => true,
            'message' => 'Marked as picked up.',
            'data' => $result,
        ]);
    }

    public function submit(Request $request)
    {
        $request->validate([
            'lat' => ['required', 'numeric'],
            'lng' => ['required', 'numeric'],
            'results' => ['required', 'array', 'min:1'],
            'results.*.delivery_assignment_id' => ['required', 'exists:delivery_assignments,id'],
            'results.*.delivered' => ['required', 'boolean'],
            'results.*.reason' => [
                'required_if:results.*.delivered,false',
                'nullable',
                'in:customer_unavailable,customer_refused,stockout,vehicle_breakdown,address_not_found,other',
            ],
            'results.*.note' => ['nullable', 'string', 'max:500'],
        ]);

        $riderId = $request->user()->id;

        $assignmentIds = collect($request->results)->pluck('delivery_assignment_id');
        $ownedCount = DeliveryAssignment::whereIn('id', $assignmentIds)
            ->where('delivery_boy_id', $riderId)
            ->count();

        if ($ownedCount !== $assignmentIds->count()) {
            throw ValidationException::withMessages([
                'results' => 'One or more assignments do not belong to you.',
            ]);
        }

        $results = collect($request->results)->keyBy('delivery_assignment_id')
            ->map(fn ($r) => [
                'delivered' => $r['delivered'],
                'reason' => $r['reason'] ?? null,
                'note' => $r['note'] ?? null,
            ])->toArray();

        $this->service->submit($results, $riderId, (float) $request->lat, (float) $request->lng);

        return response()->json([
            'status' => true,
            'message' => 'Delivery results submitted successfully.',
            'data' => null,
        ]);
    }

    public function deliverOne(Request $request, int $assignmentId)
    {
        $rules = [
            'delivered' => ['required', 'boolean'],
            'lat' => ['required', 'numeric'],
            'lng' => ['required', 'numeric'],
            'note' => ['nullable', 'string', 'max:500'],
        ];

        if ($request->boolean('delivered')) {
            $rules['photo'] = ['required', 'file', 'image', 'max:10240'];
        } else {
            $rules['reason'] = ['required', 'in:customer_unavailable,customer_refused,stockout,vehicle_breakdown,address_not_found,other'];
        }

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $riderId = $request->user()->id;

        $assignment = DeliveryAssignment::where('id', $assignmentId)
            ->where('delivery_boy_id', $riderId)
            ->firstOrFail();

        $photoPath = null;
        if ($request->boolean('delivered')) {
            $tenantId = tenant('id') ?? 'unknown';
            $photoFile = $request->file('photo');
            $photoPath = $photoFile->storeAs(
                "tenants/{$tenantId}/subscription-deliveries",
                "occ_{$assignment->subscription_occurrence_id}_".time().'.'.$photoFile->getClientOriginalExtension(),
                'public'
            );
        }

        $this->service->submitOne(new DeliveryConfirmationRequest(
            assignment: $assignment,
            delivered: $request->boolean('delivered'),
            reason: $request->input('reason'),
            note: $request->input('note'),
            lat: (float) $request->lat,
            lng: (float) $request->lng,
            photoPath: $photoPath,
            submittedBy: $riderId,
        ));

        return response()->json([
            'status' => true,
            'message' => $request->boolean('delivered') ? 'Delivery confirmed.' : 'Marked not delivered.',
            'data' => null,
        ]);
    }

    private function slotPayload($slot): ?array
    {
        if (! $slot) {
            return null;
        }

        return [
            'id' => $slot->id,
            'name' => $slot->name,
            'start_time' => substr($slot->start_time, 0, 5),
            'end_time' => substr($slot->end_time, 0, 5),
        ];
    }
}
