<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Exceptions\PaymentGatewayException;
use App\Exceptions\RazorpayNotConfiguredException;
use App\Http\Controllers\Controller;
use App\Models\Tenant\WalletTopup;
use App\Services\V1\Tenant\TenantProfileService;
use App\Services\V1\Wallet\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    private const MSG_RAZORPAY_NOT_CONFIGURED = 'Online payment is not set up yet for this store. Please contact support.';
    private const MSG_NO_PAYMENT_INITIATED = 'No payment initiated.';
    private const MSG_PAYMENT_ALREADY_CONFIRMED = 'Payment already confirmed.';
    private const MSG_PAYMENT_VERIFICATION_FAILED = 'Payment verification failed.';
    private const MSG_GENERIC_TOPUP_FAILURE = 'Could not initiate top-up. Please try again.';
    private const MSG_PAYMENT_VERIFIED = 'Payment verified. Wallet credited.';

    public function __construct(
        protected WalletService $walletService,
        protected TenantProfileService $tenantProfileService,
    ) {}

    public function balance(Request $request): JsonResponse
    {
        $balance = DB::table('customer_wallets')
            ->where('customer_id', $request->user()->id)
            ->value('balance');

        return response()->json([
            'status' => true,
            'data' => ['balance' => (float) ($balance ?? 0)],
        ]);
    }

    public function transactions(Request $request): JsonResponse
    {
        $transactions = DB::table('wallet_transactions')
            ->where('customer_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->paginate(20);

        $transactions->getCollection()->transform(function ($row) {
            $row->amount = (float) $row->amount;
            $row->balance_after = (float) $row->balance_after;

            return $row;
        });

        return response()->json(['status' => true, 'data' => $transactions]);
    }

    public function topupStatus(Request $request, $walletTopupId): JsonResponse
    {
        $topup = WalletTopup::where('customer_id', $request->user()->id)->findOrFail($walletTopupId);

        return response()->json([
            'status' => true,
            'data' => ['status' => $topup->status],
        ]);
    }

    public function initiateTopup(Request $request): JsonResponse
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
        ]);

        if (! $this->tenantProfileService->razorpayIsConfigured()) {
            return $this->errorResponse(self::MSG_RAZORPAY_NOT_CONFIGURED, 422);
        }

        return $this->attemptTopup($request);
    }

    private function attemptTopup(Request $request): JsonResponse
    {
        try {
            $data = $this->walletService->initiateTopup($request->user(), (float) $request->amount);

            return response()->json(['status' => true, 'data' => $data], 201);
        } catch (PaymentGatewayException|RazorpayNotConfiguredException $e) {
            return $this->errorResponse($e->getMessage(), 422);
        } catch (\Throwable $e) {
            report($e);

            return $this->errorResponse(self::MSG_GENERIC_TOPUP_FAILURE, 422);
        }
    }

    public function verifyTopup(Request $request, $walletTopupId): JsonResponse
    {
        $request->validate([
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature' => 'required|string',
        ]);

        $topup = WalletTopup::where('customer_id', $request->user()->id)->findOrFail($walletTopupId);

        if (! $topup->razorpay_order_id) {
            return $this->errorResponse(self::MSG_NO_PAYMENT_INITIATED, 422);
        }

        return $this->finalizeVerification($request, $topup);
    }

    private function finalizeVerification(Request $request, WalletTopup $topup): JsonResponse
    {
        if ($topup->status === 'paid') {
            return $this->successMessage(self::MSG_PAYMENT_ALREADY_CONFIRMED);
        }

        return $this->verifyAndDispatch($request, $topup);
    }

    private function verifyAndDispatch(Request $request, WalletTopup $topup): JsonResponse
    {
        $ok = $this->walletService->verifyAndCredit(
            $topup,
            $request->razorpay_payment_id,
            $request->razorpay_signature
        );

        return $ok
            ? $this->successMessage(self::MSG_PAYMENT_VERIFIED)
            : $this->resolveVerifyFailure($topup);
    }

    private function resolveVerifyFailure(WalletTopup $topup): JsonResponse
    {
        $topup->refresh();

        if ($topup->status === 'paid') {
            return $this->successMessage(self::MSG_PAYMENT_ALREADY_CONFIRMED);
        }

        return $this->errorResponse(self::MSG_PAYMENT_VERIFICATION_FAILED, 422);
    }

    public function webhook(Request $request): JsonResponse
    {
        if (! $this->webhookSignatureIsValid($request)) {
            return response()->json(['status' => false], 400);
        }

        $this->dispatchWebhookEvent($request->all());

        return response()->json(['status' => true]);
    }

    private function webhookSignatureIsValid(Request $request): bool
    {
        $webhookSecret = config('services.razorpay.wallet_webhook_secret');

        if (! $webhookSecret) {
            return true;
        }

        $signature = $request->header('X-Razorpay-Signature');
        $expected = hash_hmac('sha256', $request->getContent(), $webhookSecret);

        return hash_equals($expected, $signature ?? '');
    }

    private function dispatchWebhookEvent(array $payload): void
    {
        $event = $payload['event'] ?? '';

        if ($event === 'payment.captured') {
            $this->handleWebhookCaptured($payload);

            return;
        }

        if ($event === 'payment.failed') {
            $this->handleWebhookFailed($payload);
        }
    }

    private function handleWebhookCaptured(array $payload): void
    {
        $paymentId = $payload['payload']['payment']['entity']['id'] ?? null;
        $razorpayOrderId = $payload['payload']['payment']['entity']['order_id'] ?? null;

        if ($paymentId && $razorpayOrderId) {
            $this->walletService->handleWebhookCaptured($razorpayOrderId, $paymentId);
        }
    }

    private function handleWebhookFailed(array $payload): void
    {
        $razorpayOrderId = $payload['payload']['payment']['entity']['order_id'] ?? null;

        if ($razorpayOrderId) {
            $this->walletService->handleWebhookFailed($razorpayOrderId);
        }
    }

    private function successMessage(string $message): JsonResponse
    {
        return response()->json(['status' => true, 'message' => $message]);
    }

    private function errorResponse(string $message, int $status): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => $message,
        ], $status);
    }
}
