<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Services\V1\Orders\ZoneCheckService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MobileAddressController extends Controller
{
    private const MSG_ADDRESS_NOT_FOUND = 'Address not found.';

    public function __construct(private ZoneCheckService $zoneCheck) {}

    public function index(Request $request): JsonResponse
    {
        $addresses = $request->user()
            ->addresses()
            ->orderByDesc('is_default')
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Addresses retrieved.',
            'data' => $addresses,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'label' => ['required', 'string', 'max:50'],
            'address_line1' => ['required', 'string', 'max:255'],
            'address_line2' => ['nullable', 'string', 'max:255'],
            'city' => ['required', 'string', 'max:100'],
            'state' => ['required', 'string', 'max:100'],
            'pincode' => ['required', 'string', 'max:10'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
        ]);

        $customer = $request->user();
        $isFirst = $customer->addresses()->count() === 0;

        // Resolve free-text state to a state_id FK, needed for GST split
        // (CGST/SGST vs IGST) at order time. Exact-match only — will
        // silently return null on any casing/abbreviation mismatch from
        // whatever the geocoder returned.
        $stateId = State::where('name', $validated['state'])->value('id');

        // UNRESOLVED — pick one, this cannot ship as a silent default:
        //
        // Option A — block the save on no match:
        // if ($stateId === null) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'Could not verify the state for this address. Please select it manually.',
        //         'data'    => [],
        //     ], 422);
        // }
        //
        // Option B — proceed with state_id = null (current behavior).
        // Whatever consumes state_id for GST calculation at order time
        // MUST explicitly handle null — decide there whether it means
        // "block the order," "default to intra-state," or something
        // else. Do not let it silently produce an incorrect tax split.

        // Zone check — only runs if coordinates were actually provided.
        $zoneResult = ['serviceable' => false, 'branch_id' => null];
        if ($validated['latitude'] !== null && $validated['longitude'] !== null) {
            $zoneResult = $this->zoneCheck->checkPoint(
                $validated['latitude'],
                $validated['longitude']
            );
        }

        $address = $customer->addresses()->create(
            array_merge($validated, [
                'country' => 'India',
                'state_id' => $stateId,
                'is_default' => $isFirst,
                'branch_id' => $zoneResult['branch_id'],
                'is_serviceable' => $zoneResult['serviceable'],
            ])
        );

        return response()->json([
            'status' => true,
            'message' => 'Address added.',
            'data' => $address,
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $address = $request->user()->addresses()->find($id);

        if (! $address) {
            return $this->addressNotFoundResponse();
        }

        $validated = $request->validate([
            'label' => ['sometimes', 'string', 'max:50'],
            'address_line1' => ['sometimes', 'string', 'max:255'],
            'address_line2' => ['nullable', 'string', 'max:255'],
            'city' => ['sometimes', 'string', 'max:100'],
            'state' => ['sometimes', 'string', 'max:100'],
            'pincode' => ['sometimes', 'string', 'max:10'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
        ]);

        // NOTE: if 'state' is present in this update, state_id is NOT
        // re-resolved here — this is a gap, not an oversight you can
        // ignore. Editing an address's state via update() will leave
        // state_id stale/mismatched with the new state text. Add the
        // same resolution block from store() here, gated on
        // isset($validated['state']), before this ships.

        $address->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Address updated.',
            'data' => $address->fresh(),
        ]);
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $address = $request->user()->addresses()->find($id);

        if (! $address) {
            return $this->addressNotFoundResponse();
        }

        $wasDefault = $address->is_default;
        $address->delete();

        if ($wasDefault) {
            $next = $request->user()->addresses()->first();
            if ($next) {
                $next->update(['is_default' => true]);
            }
        }

        return response()->json([
            'status' => true,
            'message' => 'Address deleted.',
            'data' => [],
        ]);
    }

    public function setDefault(Request $request, int $id): JsonResponse
    {
        $address = $request->user()->addresses()->find($id);

        if (! $address) {
            return $this->addressNotFoundResponse();
        }

        $request->user()->addresses()->update(['is_default' => false]);
        $address->update(['is_default' => true]);

        return response()->json([
            'status' => true,
            'message' => 'Default address updated.',
            'data' => $address->fresh(),
        ]);
    }

    private function addressNotFoundResponse(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => self::MSG_ADDRESS_NOT_FOUND,
            'data' => [],
        ], 404);
    }
}
