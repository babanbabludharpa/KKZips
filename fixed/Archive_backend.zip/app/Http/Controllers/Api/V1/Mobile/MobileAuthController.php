<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\Tenant\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class MobileAuthController extends Controller
{
    // ─── Register ─────────────────────────────────────────────────────
    public function register(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:customers,email',
            'phone' => 'required|string|max:20',
            'password' => 'required|string|min:6',
        ]);

        $customer = Customer::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
            'status' => 'active',
        ]);

        $token = $customer->createToken('mobile')->plainTextToken;

        return response()->json([
            'status' => true,
            'message' => 'Registration successful.',
            'data' => [
                'token' => $token,
                'customer' => $this->customerData($customer),
            ],
        ], 201);
    }

    // ─── Login ────────────────────────────────────────────────────────
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'phone' => 'required|string',
            'password' => 'required|string',
        ]);

        $customer = Customer::where('phone', $request->phone)->first();

        if (! $customer || ! Hash::check($request->password, $customer->password)) {
            throw ValidationException::withMessages([
                'phone' => 'Invalid credentials.',
            ]);
        }

        if ($customer->status !== 'active') {
            throw ValidationException::withMessages([
                'phone' => 'Your account is suspended.',
            ]);
        }

        $customer->tokens()->delete();
        $token = $customer->createToken('mobile')->plainTextToken;

        return response()->json([
            'status' => true,
            'message' => 'Login successful.',
            'data' => [
                'token' => $token,
                'customer' => $this->customerData($customer),
            ],
        ]);
    }

    // ─── Me ───────────────────────────────────────────────────────────
    // Returns customer NESTED under data.customer so Flutter can do
    // res['data']['customer'] consistently with login/register.
    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => [
                'customer' => $this->customerData($request->user()),
            ],
        ]);
    }

    // ─── Logout ───────────────────────────────────────────────────────
    public function logout(Request $request): JsonResponse
    {
        $token = $request->user()->currentAccessToken();
        if ($token) {
            $token->delete();
        }

        return response()->json(['status' => true, 'message' => 'Logged out.']);
    }

    // ─── Update Profile ───────────────────────────────────────────────
    public function updateProfile(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'phone' => 'sometimes|string|max:20',
        ]);

        $customer = $request->user();
        $customer->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Profile updated.',
            'data' => [
                'customer' => $this->customerData($customer->fresh()),
            ],
        ]);
    }

    // ─── Update Location ──────────────────────────────────────────────
    public function updateLocation(Request $request): JsonResponse
    {
        $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
        ]);

        $request->user()->update([
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'location_permission' => true,
        ]);

        return response()->json(['status' => true, 'message' => 'Location updated.']);
    }

    // ─── Change Password ──────────────────────────────────────────────
    public function changePassword(Request $request): JsonResponse
    {
        $request->validate([
            'current_password' => 'required|string',
            'password' => 'required|string|min:6|confirmed',
        ]);

        $customer = $request->user();

        if (! Hash::check($request->current_password, $customer->password)) {
            throw ValidationException::withMessages([
                'current_password' => 'Current password is incorrect.',
            ]);
        }

        $customer->update(['password' => Hash::make($request->password)]);

        // Revoke all other tokens
        $customer->tokens()
            ->where('id', '!=', $customer->currentAccessToken()->id)
            ->delete();

        return response()->json(['status' => true, 'message' => 'Password changed.']);
    }

    // ─── Helper: customer data array ──────────────────────────────────
    private function customerData(Customer $customer): array
    {
        $defaultAddress = $customer->addresses()->where('is_default', true)->first();

        return [
            'id' => $customer->id,
            'name' => $customer->name,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'phone_verified' => $customer->phone_verified,
            'email_verified_at' => $customer->email_verified_at,
            // active address for splash delta-check — replaces raw
            // customer-level lat/lng, which are now considered stale/orphaned
            'active_address' => $defaultAddress ? [
                'id' => $defaultAddress->id,
                'latitude' => $defaultAddress->latitude,
                'longitude' => $defaultAddress->longitude,
                'address_line1' => $defaultAddress->address_line1,
                'city' => $defaultAddress->city,
                'is_serviceable' => (bool) $defaultAddress->is_serviceable,
                'branch_id' => $defaultAddress->branch_id,
            ] : null,
        ];
    }

    // NOTE: raw 'latitude'/'longitude'/'location_permission' fields removed
    // from this response on purpose — they read from customers table directly,
    // which is now orphaned. Any Flutter code still reading
    // customer['latitude'] directly (instead of customer['active_address'])
    // needs to be updated or it will silently get null.
}
// file not staged
