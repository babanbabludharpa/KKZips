<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Mobile\Subscriptions\CustomerStoreSubscriptionRequest;
use App\Http\Resources\V1\SubscriptionOccurrenceResource;
use App\Http\Resources\V1\SubscriptionResource;
use App\Models\Subscription;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Models\Tenant\CustomerAddress;
use App\Models\TenantDeliverySlot;
use App\Services\V1\Subscriptions\DeliveryBoyAssignmentService;
use App\Services\V1\Subscriptions\SubscriptionLifecycleService;
use App\Services\V1\Subscriptions\SubscriptionOccurrenceGenerationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class CustomerSubscriptionController extends Controller
{
    public function __construct(
        protected SubscriptionOccurrenceGenerationService $generationService,
        protected SubscriptionLifecycleService $lifecycleService,
        protected DeliveryBoyAssignmentService $assignmentEngine,
    ) {}

    public function index(Request $request)
    {
        $subscriptions = Subscription::where('customer_id', $request->user()->id)
            ->with(['branch', 'deliveryAddress', 'items.slot', 'items.productVariant.product', 'items.productVariant.attributeValues.attribute'])
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Subscriptions retrieved successfully.',
            'data' => SubscriptionResource::collection($subscriptions),
        ]);
    }

    public function store(CustomerStoreSubscriptionRequest $request)
    {
        $address = CustomerAddress::findOrFail($request->delivery_address_id);

        abort_unless($address->customer_id === $request->user()->id, 403);

        if (! $address->is_serviceable || ! $address->branch_id) {
            throw ValidationException::withMessages([
                'delivery_address_id' => 'This address is not currently serviceable for subscriptions.',
            ]);
        }

        $subscription = DB::transaction(function () use ($request, $address) {
            $subscription = Subscription::create([
                'customer_id' => $request->user()->id,
                'branch_id' => $address->branch_id,
                'delivery_address_id' => $address->id,
                'status' => 'active',
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
            ]);

            foreach ($request->items as $itemData) {
                $item = SubscriptionItem::create([
                    'subscription_id' => $subscription->id,
                    'product_variant_id' => $itemData['product_variant_id'],
                    'default_qty' => $itemData['default_qty'],
                    'slot_id' => $itemData['slot_id'],
                    'schedule_type' => $itemData['schedule_type'],
                    'schedule_days' => $itemData['schedule_days'] ?? null,
                    'schedule_dates' => $itemData['schedule_dates'] ?? null,
                    'status' => 'active',
                ]);

                $this->generationService->generateInitialOccurrence($item);

                $occurrences = SubscriptionOccurrence::where('subscription_item_id', $item->id)
                    ->whereNull('delivery_boy_id')
                    ->with(['subscriptionItem.subscription.deliveryAddress'])
                    ->get();

                foreach ($occurrences as $occ) {
                    $this->assignmentEngine->assignOccurrence($occ);
                }
            }

            return $subscription;
        });

        return response()->json([
            'status' => true,
            'message' => 'Subscription created successfully.',
            'data' => new SubscriptionResource($subscription->load(['items.slot', 'items.productVariant.product', 'items.productVariant.attributeValues.attribute'])),
        ], 201);
    }

    public function show(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);

        $subscription->load(['branch', 'deliveryAddress', 'items.slot', 'items.productVariant.product', 'items.productVariant.attributeValues.attribute']);

        return response()->json([
            'status' => true,
            'message' => 'Subscription retrieved successfully.',
            'data' => new SubscriptionResource($subscription),
        ]);
    }

    public function upcomingOccurrences(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);

        $occurrences = $subscription->items()
            ->with(['slot', 'occurrences' => fn ($q) => $q->where('occurrence_date', '>=', now()->toDateString())
                ->orderBy('occurrence_date')
                ->limit(14)])
            ->get()
            ->pluck('occurrences')
            ->flatten();

        return response()->json([
            'status' => true,
            'message' => 'Upcoming occurrences retrieved successfully.',
            'data' => SubscriptionOccurrenceResource::collection($occurrences),
        ]);
    }

    public function deliveries(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);

        $perPage = min(max((int) $request->query('per_page', 20), 1), 100);

        $occurrences = SubscriptionOccurrence::query()
            ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                $q->where('subscription_id', $subscription->id);
            })
            ->where('status', 'delivered')
            ->with(['subscriptionItem.productVariant.product'])
            ->orderByDesc('occurrence_date')
            ->orderByDesc('id')
            ->paginate($perPage);

        return response()->json([
            'status' => true,
            'message' => 'Deliveries retrieved successfully.',
            'data' => collect($occurrences->items())->map(function ($o) {
                $photoUrl = $o->delivery_photo_path
                    ? Storage::disk('public')->url($o->delivery_photo_path)
                    : null;

                return [
                    'id' => $o->id,
                    'occurrence_date' => $o->occurrence_date->toDateString(),
                    'delivered_at' => optional($o->delivered_at)->toDateTimeString(),
                    'qty' => $o->qty,
                    'product_name' => $o->subscriptionItem->productVariant->product->name ?? null,
                    'variant_display' => $o->subscriptionItem->productVariant->sku ?? null,
                    'delivery_note' => $o->delivery_note,
                    'delivery_photo_url' => $photoUrl,
                ];
            }),
            'meta' => [
                'current_page' => $occurrences->currentPage(),
                'last_page' => $occurrences->lastPage(),
                'per_page' => $occurrences->perPage(),
                'total' => $occurrences->total(),
                'has_more' => $occurrences->hasMorePages(),
            ],
        ]);
    }

    public function pause(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);
        abort_unless($subscription->status === 'active', 422, 'Only an active subscription can be paused.');

        $subscription = $this->lifecycleService->pause($subscription, 'customer', $request->user()->id, $request->reason);

        return response()->json([
            'status' => true,
            'message' => 'Subscription paused successfully.',
            'data' => new SubscriptionResource($subscription),
        ]);
    }

    public function resume(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);
        abort_unless($subscription->status === 'paused', 422, 'Only a paused subscription can be resumed.');

        $subscription = $this->lifecycleService->resume($subscription, 'customer', $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Subscription resumed successfully.',
            'data' => new SubscriptionResource($subscription),
        ]);
    }

    public function cancel(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        abort_unless($subscription->customer_id === $request->user()->id, 403);
        abort_unless(in_array($subscription->status, ['active', 'paused']), 422, 'This subscription is already cancelled.');

        $subscription = $this->lifecycleService->cancel($subscription, 'customer', $request->user()->id, $request->reason);

        return response()->json([
            'status' => true,
            'message' => 'Subscription cancelled successfully.',
            'data' => new SubscriptionResource($subscription),
        ]);
    }

    public function config(Request $request)
    {
        $profile = app(\App\Services\V1\Tenant\TenantProfileService::class)->getProfile();

        $slots = TenantDeliverySlot::where('is_active', 1)
            ->orderBy('start_time')
            ->get(['id', 'name', 'start_time', 'end_time'])
            ->map(fn ($s) => [
                'id' => $s->id,
                'name' => $s->name,
                'start_time' => substr($s->start_time, 0, 5),
                'end_time' => substr($s->end_time, 0, 5),
            ]);

        // Resolve the customer's branch so blocked dates are branch-scoped.
        $addressId = $request->query('delivery_address_id');
        $branchId = null;
        if ($addressId) {
            $addr = CustomerAddress::find($addressId);
            if ($addr && $addr->customer_id === $request->user()->id && $addr->branch_id) {
                $branchId = (int) $addr->branch_id;
            }
        }
        if ($branchId === null) {
            $addr = CustomerAddress::where('customer_id', $request->user()->id)
                ->where('is_serviceable', true)
                ->whereNotNull('branch_id')
                ->first();
            if ($addr) $branchId = (int) $addr->branch_id;
        }

        $blocked = app(\App\Services\V1\Tenant\TenantLeaveService::class)
            ->blockedDatesFor($branchId, 90);

        return response()->json([
            'status' => true,
            'message' => 'Config retrieved successfully.',
            'data' => [
                'cutoff_time' => SubscriptionOccurrence::getCutoffTime(),
                'earliest_start_date' => SubscriptionOccurrence::earliestSelectableDate()->toDateString(),
                'slots' => $slots,
                'subscription_start_policy' => $profile?->subscription_start_policy ?? 'next_day_only',
                'same_day_lead_time_minutes' => (int) ($profile?->same_day_lead_time_minutes ?? 120),
                'blocked_dates' => $blocked,
            ],
        ]);
    }
}
