<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\SubscriptionOccurrenceResource;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionPause;
use App\Models\SubscriptionQtyOverride;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CustomerSubscriptionScheduleController extends Controller
{
    public function forItem(Request $request, int $itemId)
    {
        $item = SubscriptionItem::with(['subscription', 'slot'])->findOrFail($itemId);
        abort_unless($item->subscription->customer_id === $request->user()->id, 403);

        $year = (int) ($request->year ?? now()->year);
        $month = (int) ($request->month ?? now()->month);
        $monthStart = Carbon::create($year, $month, 1)->startOfMonth();
        $monthEnd = $monthStart->copy()->endOfMonth();

        $occurrences = $item->occurrences()
            ->whereBetween('occurrence_date', [$monthStart->toDateString(), $monthEnd->toDateString()])
            ->with(['subscriptionItem.slot'])
            ->get();

        $pauses = SubscriptionPause::where('subscription_item_id', $item->id)
            ->where('date_from', '<=', $monthEnd->toDateString())
            ->where('date_to', '>=', $monthStart->toDateString())
            ->get(['id', 'date_from', 'date_to', 'initiated_by']);

        $qtyOverrides = SubscriptionQtyOverride::where('subscription_item_id', $item->id)
            ->where('date_from', '<=', $monthEnd->toDateString())
            ->where('date_to', '>=', $monthStart->toDateString())
            ->get(['id', 'date_from', 'date_to', 'qty']);

        return response()->json([
            'status' => true,
            'message' => 'Schedule retrieved successfully.',
            'data' => [
                'item' => [
                    'id' => $item->id,
                    'slot' => $item->slot ? [
                        'id' => $item->slot->id,
                        'name' => $item->slot->name,
                        'start_time' => substr($item->slot->start_time, 0, 5),
                        'end_time' => substr($item->slot->end_time, 0, 5),
                    ] : null,
                    'schedule_type' => $item->schedule_type,
                    'schedule_days' => $item->schedule_days,
                    'default_qty' => $item->default_qty,
                    'status' => $item->status,
                ],
                'subscription_start_date' => $item->subscription->start_date?->toDateString(),
                'occurrences' => SubscriptionOccurrenceResource::collection($occurrences),
                'pauses' => $pauses,
                'qty_overrides' => $qtyOverrides,
            ],
        ]);
    }
}
