<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Mobile\Subscriptions\CustomerStorePauseRequest;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionPause;
use App\Services\V1\Subscriptions\SubscriptionPauseService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CustomerSubscriptionPauseController extends Controller
{
    public function __construct(protected SubscriptionPauseService $service) {}

    public function store(CustomerStorePauseRequest $request, int $itemId)
    {
        $item = SubscriptionItem::findOrFail($itemId);
        abort_unless($item->subscription->customer_id === $request->user()->id, 403);

        $pause = $this->service->create(
            $item,
            Carbon::parse($request->date_from),
            Carbon::parse($request->date_to),
            'customer',
            $request->user()->id,
            $request->reason,
        );

        return response()->json([
            'status' => true,
            'message' => 'Pause request submitted successfully.',
            'data' => $pause,
        ], 201);
    }

    public function destroy(Request $request, int $pauseId)
    {
        $pause = SubscriptionPause::findOrFail($pauseId);
        abort_unless($pause->subscriptionItem->subscription->customer_id === $request->user()->id, 403);

        $this->service->resume($pause, 'customer', $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Pause cancelled successfully.',
            'data' => null,
        ]);
    }
}
