<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CouponController extends Controller
{
    // GET /mobile/coupons?subtotal=499
    public function index(Request $request): JsonResponse
    {
        $customer = $request->user();
        $subtotal = (float) $request->query('subtotal', 0);
        $today = now()->toDateString();

        $coupons = Coupon::where('is_active', true)
            ->where('valid_from', '<=', $today)
            ->where(function ($q) use ($today) {
                $q->whereNull('valid_until')->orWhere('valid_until', '>=', $today);
            })
            ->where(function ($q) {
                $q->whereNull('usage_limit_total')
                    ->orWhereColumn('used_count', '<', 'usage_limit_total');
            })
            ->orderByDesc('created_at')
            ->get();

        $usageCountsByCoupon = DB::table('coupon_usages')
            ->where('customer_id', $customer->id)
            ->selectRaw('coupon_id, COUNT(*) as cnt')
            ->groupBy('coupon_id')
            ->pluck('cnt', 'coupon_id');

        $hasPreviousOrder = DB::table('orders')
            ->where('customer_id', $customer->id)
            ->whereIn('status', ['confirmed', 'preparing', 'out_for_delivery', 'delivered'])
            ->exists();

        $data = $coupons->map(function ($c) use ($subtotal, $usageCountsByCoupon, $hasPreviousOrder) {
            $usedByCustomer = $usageCountsByCoupon[$c->id] ?? 0;
            $alreadyUsedUp = $c->usage_limit_per_customer
                && $usedByCustomer >= $c->usage_limit_per_customer;
            $blockedFirstOrderOnly = $c->is_first_order_only && $hasPreviousOrder;

            return [
                'code' => $c->code,
                'description' => $c->description,
                'type' => $c->type,
                'value' => $c->value,
                'min_order_amount' => $c->min_order_amount,
                'max_discount_amount' => $c->max_discount_amount,
                'is_first_order_only' => $c->is_first_order_only,
                'meets_minimum' => $subtotal >= $c->min_order_amount,
                'already_used' => $alreadyUsedUp,
                'blocked_first_order' => $blockedFirstOrderOnly,
            ];
        });

        return response()->json(['status' => true, 'data' => $data]);
    }
}
