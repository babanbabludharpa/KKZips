<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Services\V1\Subscriptions\SubscriptionActivityReportService;
use Illuminate\Http\Request;

class CustomerActivityLogController extends Controller
{
    public function __construct(protected SubscriptionActivityReportService $service) {}

    /**
     * All of this customer's transaction history across every subscription,
     * or scoped to one via ?subscription_id= - ownership is enforced by
     * customer_id always being forced to the authenticated user, never
     * trusted from the request.
     */
    public function index(Request $request)
    {
        $filters = $request->only(['subscription_id', 'event_type', 'date_from', 'date_to', 'per_page']);

        $report = $this->service->getForCustomer($request->user()->id, $filters);

        return response()->json([
            'status' => true,
            'message' => 'Activity history retrieved successfully.',
            'data' => collect($report->items())->map(fn ($row) => [
                'id' => $row->id,
                'created_at' => $row->created_at->toDateTimeString(),
                'subscription_id' => $row->subscription_id,
                'product_name' => $row->subscriptionItem->productVariant->product->name ?? null,
                'event_type' => $row->event_type,
                'actor_type' => $row->actor_type,
                'occurrence_date' => $row->occurrence_date?->toDateString(),
                'description' => $row->description,
                'metadata' => $row->metadata,
            ]),
            'meta' => [
                'current_page' => $report->currentPage(),
                'last_page' => $report->lastPage(),
                'total' => $report->total(),
            ],
        ]);
    }
}
