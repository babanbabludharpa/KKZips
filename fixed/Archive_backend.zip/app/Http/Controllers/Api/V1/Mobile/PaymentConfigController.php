<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Http\JsonResponse;

class PaymentConfigController extends Controller
{
    public function __construct(protected TenantProfileService $service) {}

    public function show(): JsonResponse
    {
        $profile = $this->service->getProfile();

        return response()->json([
            'status' => true,
            'data' => [
                // Defaults here matter: if no profile row exists yet for this
                // tenant, fall back to the same defaults as the DB columns
                // (cod_enabled=0, online_payment_enabled=1) rather than
                // silently returning nulls the Flutter side has to guess about.
                'cod_enabled' => $profile ? (bool) $profile->cod_enabled : false,
                'online_payment_enabled' => $profile ? (bool) $profile->online_payment_enabled : true,
            ],
        ]);
    }
}
