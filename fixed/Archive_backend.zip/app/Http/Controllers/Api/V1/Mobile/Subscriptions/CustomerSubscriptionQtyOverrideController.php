<?php

namespace App\Http\Controllers\Api\V1\Mobile\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Mobile\Subscriptions\CustomerStoreQtyOverrideRequest;
use App\Models\SubscriptionItem;
use App\Services\V1\Subscriptions\SubscriptionQtyOverrideService;
use Carbon\Carbon;

class CustomerSubscriptionQtyOverrideController extends Controller
{
    public function __construct(protected SubscriptionQtyOverrideService $service) {}

    public function store(CustomerStoreQtyOverrideRequest $request, int $itemId)
    {
        $item = SubscriptionItem::findOrFail($itemId);
        abort_unless($item->subscription->customer_id === $request->user()->id, 403);

        $override = $this->service->create(
            $item,
            Carbon::parse($request->date_from),
            Carbon::parse($request->date_to),
            $request->qty,
            'customer',
            $request->user()->id,
            $request->reason,
        );

        return response()->json([
            'status' => true,
            'message' => 'Quantity change submitted successfully.',
            'data' => $override,
        ], 201);
    }
}
