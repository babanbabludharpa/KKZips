<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ThemeController extends Controller
{
    /**
     * GET /api/v1/themes
     * Returns the list of available theme templates.
     * Public endpoint — safe for login page, tenant form, etc.
     */
    public function index(): JsonResponse
    {
        $themes = collect(config('themes', []))
            ->map(fn ($meta, $key) => [
                'key' => $key,
                'label' => $meta['label'] ?? $key,
                'description' => $meta['description'] ?? '',
                'preview' => $meta['preview'] ?? '#475569',
            ])
            ->sortBy(fn ($t) => config("themes.{$t['key']}.sort", 999))
            ->values();

        return response()->json([
            'status' => true,
            'message' => 'Themes retrieved successfully.',
            'data' => $themes,
        ]);
    }
}
