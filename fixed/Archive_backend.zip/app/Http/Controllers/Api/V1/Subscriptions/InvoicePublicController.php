<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Services\V1\Orders\InvoicePdfService;
use Illuminate\Support\Facades\URL;

class InvoicePublicController extends Controller
{
    public function __construct(protected InvoicePdfService $invoicePdf) {}

    public function pdfLink(Invoice $invoice)
    {
        $url = URL::temporarySignedRoute(
            'invoices.pdf.public',
            now()->addDays(7),
            ['invoice' => $invoice->id]
        );

        return response()->json(['status' => true, 'data' => ['url' => $url]]);
    }

    public function pdf(Invoice $invoice)
    {
        $invoice->load(['customer', 'items.occurrence.subscriptionItem.productVariant', 'payments']);

        return $this->invoicePdf->buildForSubscriptionInvoice($invoice)
            ->stream('invoice-'.$invoice->id.'.pdf');
    }
}
