<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\SubscriptionOccurrenceResource;
use App\Models\SubscriptionOccurrence;
use Carbon\Carbon;
use Illuminate\Http\Request;

class SubscriptionOccurrenceController extends Controller
{
    private const SORTABLE = [
        'customer' => 'customers.name',
        'product' => 'products.name',
        'qty' => 'subscription_occurrences.qty',
        'slot' => 'tenant_delivery_slots.start_time',
        'occurred_at' => 'subscription_occurrences.occurrence_date',
    ];

    private const DEFAULT_PAGE_SIZE = 25;
    private const MIN_PAGE_SIZE = 1;
    private const MAX_PAGE_SIZE = 500;

    public function index(Request $request)
    {
        abort_unless($request->user()->can('subscription.view'), 403);

        $request->validate([
            'date' => 'nullable|date',
            'status' => 'nullable|in:scheduled,assigned,out_for_delivery,delivered,not_delivered,admin_paused,customer_paused,holiday_skipped',
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $branchId = $request->user()->branch_id;

        $date = $request->date ? Carbon::parse($request->date) : now();

        $perPage = min(
            max((int) ($request->input('per_page') ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $request->input('sort_key');
        $sortDir = strtolower($request->input('sort_dir', 'asc')) === 'desc' ? 'desc' : 'asc';

        $query = SubscriptionOccurrence::query()
            ->whereDate('occurrence_date', $date)
            ->when(
                $request->status,
                fn ($q, $v) => $q->where('subscription_occurrences.status', $v),
                fn ($q) => $q->where('subscription_occurrences.status', 'scheduled')
            )
            ->whereHas(
                'subscriptionItem.subscription',
                fn ($sq) => $sq->where('branch_id', $branchId)
            )
            ->with([
                'subscriptionItem.slot',
                'subscriptionItem.productVariant.product',
                'subscriptionItem.subscription.customer',
                'subscriptionItem.subscription.deliveryAddress',
            ]);

        $sortColumn = self::SORTABLE[$sortKey] ?? null;

        if ($sortColumn) {
            $needsJoins = str_contains($sortColumn, 'customers.')
                || str_contains($sortColumn, 'products.')
                || str_contains($sortColumn, 'tenant_delivery_slots.');

            if ($needsJoins) {
                $query
                    ->leftJoin('subscription_items', 'subscription_items.id', '=', 'subscription_occurrences.subscription_item_id')
                    ->leftJoin('subscriptions', 'subscriptions.id', '=', 'subscription_items.subscription_id')
                    ->leftJoin('customers', 'customers.id', '=', 'subscriptions.customer_id')
                    ->leftJoin('product_variants', 'product_variants.id', '=', 'subscription_items.product_variant_id')
                    ->leftJoin('products', 'products.id', '=', 'product_variants.product_id')
                    ->leftJoin('tenant_delivery_slots', 'tenant_delivery_slots.id', '=', 'subscription_items.slot_id')
                    ->select('subscription_occurrences.*');
            }

            $query->orderBy($sortColumn, $sortDir);
            if ($sortColumn !== 'subscription_occurrences.id') {
                $query->orderBy('subscription_occurrences.id', 'asc');
            }
        } else {
            $query->orderBy('subscription_occurrences.id', 'asc');
        }

        $paginated = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'message' => 'Occurrences retrieved successfully.',
            'data' => SubscriptionOccurrenceResource::collection($paginated->items()),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
                'from' => $paginated->firstItem(),
                'to' => $paginated->lastItem(),
            ],
        ]);
    }
}
