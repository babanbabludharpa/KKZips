<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\SubscriptionOccurrenceResource;
use App\Models\SubscriptionOccurrence;
use App\Services\V1\Subscriptions\DeliveryBoyAssignmentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OccurrenceAssignmentController extends Controller
{
    public function __construct(
        protected DeliveryBoyAssignmentService $engine,
    ) {}

    public function reassign(Request $request, int $occurrenceId): JsonResponse
    {
        abort_unless($request->user()->can('subscription.assign_delivery'), 403);

        $validated = $request->validate([
            'delivery_boy_id' => [
                'required',
                'integer',
                Rule::exists('delivery_boys', 'id')->where('is_active', 1),
            ],
            'scope' => ['required', 'in:this_only,this_and_future'],
        ]);

        $occurrence = SubscriptionOccurrence::with([
            'subscriptionItem.subscription.deliveryAddress',
        ])->findOrFail($occurrenceId);

        $user = $request->user();
        $isHeadOffice = is_null($user->branch_id) || $user->role === 'superadmin' || $user->branch?->type === 'head_office';

        $subscriptionBranchId = $occurrence->subscriptionItem?->subscription?->branch_id;

        if (! $isHeadOffice && (int) $subscriptionBranchId !== (int) $user->branch_id) {
            return response()->json([
                'status' => false,
                'message' => 'You do not have access to this occurrence\'s branch.',
            ], 403);
        }

        if (in_array($occurrence->status, ['delivered', 'out_for_delivery', 'billed'], true)) {
            return response()->json([
                'status' => false,
                'message' => 'Cannot reassign an occurrence that is already dispatched, delivered, or billed.',
            ], 422);
        }

        $outcome = $this->engine->manualReassign(
            $occurrence,
            (int) $validated['delivery_boy_id'],
            $validated['scope'],
            (int) $request->user()->id,
        );

        $current = $outcome['current'];

        return response()->json([
            'status' => $current->isAssigned(),
            'message' => $current->isAssigned()
                ? 'Occurrence reassigned successfully.'
                : 'Reassignment rejected: '.($current->reason ?? 'unknown reason'),
            'data' => [
                'current_assigned' => $current->isAssigned(),
                'current_reason' => $current->reason,
                'future_count' => $outcome['future_count'],
                'future_failed' => $outcome['future_failed'],
                'occurrence' => $current->isAssigned()
                    ? new SubscriptionOccurrenceResource(
                        $occurrence->fresh([
                            'subscriptionItem.slot',
                            'subscriptionItem.productVariant.product',
                            'subscriptionItem.subscription.customer',
                            'subscriptionItem.subscription.deliveryAddress',
                        ])
                    )
                    : null,
            ],
        ], $current->isAssigned() ? 200 : 422);
    }

    /**
     * Bulk reassign: one rider, many occurrences.
     *
     * For each occurrence:
     *   - clears the current assignment
     *   - runs the engine with the suggested rider (eligibility enforced)
     *   - collects the per-occurrence result
     *
     * Returns per-occurrence status, so the admin sees exactly which ones
     * went through and which were rejected, with reasons.
     *
     * The bulk operation is best-effort: some rows may succeed while others
     * fail eligibility. Each row's audit is written independently.
     */
    public function bulkReassign(Request $request): JsonResponse
    {
        abort_unless($request->user()->can('subscription.assign_delivery'), 403);

        $validated = $request->validate([
            'delivery_boy_id' => [
                'required',
                'integer',
                Rule::exists('delivery_boys', 'id')->where('is_active', 1),
            ],
            'scope' => ['required', 'in:this_only,this_and_future'],
            'occurrence_ids' => ['required', 'array', 'min:1', 'max:200'],
            'occurrence_ids.*' => ['integer', 'exists:subscription_occurrences,id'],
        ]);

        $user = $request->user();
        $isHeadOffice = is_null($user->branch_id) || $user->role === 'superadmin' || $user->branch?->type === 'head_office';

        $occurrences = SubscriptionOccurrence::with([
            'subscriptionItem.subscription.deliveryAddress',
        ])->whereIn('id', $validated['occurrence_ids'])->get();

        if ($occurrences->isEmpty()) {
            return response()->json([
                'status'  => false,
                'message' => 'No valid occurrences found.',
            ], 404);
        }

        $results = [
            'assigned' => [],
            'rejected' => [],
            'skipped'  => [],
        ];

        foreach ($occurrences as $occurrence) {
            $branchId = $occurrence->subscriptionItem?->subscription?->branch_id;

            if (! $isHeadOffice && (int) $branchId !== (int) $user->branch_id) {
                $results['skipped'][] = [
                    'occurrence_id' => $occurrence->id,
                    'reason'        => 'No access to this occurrence\'s branch.',
                ];
                continue;
            }

            if (in_array($occurrence->status, ['delivered', 'out_for_delivery', 'billed'], true)) {
                $results['skipped'][] = [
                    'occurrence_id' => $occurrence->id,
                    'reason'        => 'Already dispatched, delivered, or billed.',
                ];
                continue;
            }

            $outcome = $this->engine->manualReassign(
                $occurrence,
                (int) $validated['delivery_boy_id'],
                $validated['scope'],
                (int) $user->id,
            );

            $current = $outcome['current'];

            if ($current->isAssigned()) {
                $results['assigned'][] = [
                    'occurrence_id'   => $occurrence->id,
                    'future_count'    => $outcome['future_count'],
                    'future_failed'   => $outcome['future_failed'],
                ];
            } else {
                $results['rejected'][] = [
                    'occurrence_id' => $occurrence->id,
                    'reason'        => $current->reason ?? 'Unknown reason',
                ];
            }
        }

        return response()->json([
            'status'  => true,
            'message' => sprintf(
                'Bulk reassign: %d assigned, %d rejected, %d skipped.',
                count($results['assigned']),
                count($results['rejected']),
                count($results['skipped'])
            ),
            'data'    => $results,
        ]);
    }
}
