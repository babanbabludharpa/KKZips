<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\CancelInvoiceRequest;
use App\Http\Requests\V1\Subscriptions\GenerateInvoiceRequest;
use App\Http\Requests\V1\Subscriptions\StoreInvoicePaymentRequest;
use App\Http\Resources\V1\InvoiceResource;
use App\Models\Invoice;
use App\Models\InvoicePayment;
use App\Services\V1\Orders\InvoicePdfService;
use App\Services\V1\Subscriptions\InvoiceGenerationService;
use App\Services\V1\Subscriptions\InvoiceReversalService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    private const SORTABLE = [
        'customer' => 'customers.name',
        'period_start' => 'invoices.period_start',
        'period_end' => 'invoices.period_end',
        'total' => 'invoices.total',
        'amount_paid' => 'invoices.amount_paid',
        'amount_due' => 'invoices.amount_due',
        'status' => 'invoices.status',
        'generated_at' => 'invoices.generated_at',
    ];

    private const DEFAULT_PAGE_SIZE = 25;

    private const MIN_PAGE_SIZE = 1;

    private const MAX_PAGE_SIZE = 500;

    public function __construct(
        protected InvoiceGenerationService $generationService,
        protected InvoiceReversalService $reversalService,
    ) {}

    public function index(Request $request)
    {
        $request->validate([
            'customer_id' => 'nullable|integer|exists:customers,id',
            'status' => 'nullable|in:draft,generated,partially_paid,paid,overdue,cancelled',
            'search' => 'nullable|string|max:255',
            'date_from' => 'nullable|date',
            'date_to' => 'nullable|date|after_or_equal:date_from',
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $perPage = min(
            max((int) ($request->input('per_page') ?? self::DEFAULT_PAGE_SIZE), self::MIN_PAGE_SIZE),
            self::MAX_PAGE_SIZE
        );

        $sortKey = $request->input('sort_key');
        $sortDir = strtolower($request->input('sort_dir', 'desc')) === 'asc' ? 'asc' : 'desc';

        $branchId = $request->user()->branch_id;

        $query = Invoice::query()
            ->with('customer')
            ->where('branch_id', $branchId)
            ->when($request->customer_id, fn ($q, $v) => $q->where('customer_id', $v))
            ->when($request->status, fn ($q, $v) => $q->where('status', $v))
            ->when($request->search, fn ($q, $v) => $q->whereHas('customer', function ($cq) use ($v) {
                $cq->where('name', 'like', "%{$v}%")->orWhere('phone', 'like', "%{$v}%");
            }))
            ->when($request->date_from, fn ($q, $v) => $q->whereDate('generated_at', '>=', $v))
            ->when($request->date_to, fn ($q, $v) => $q->whereDate('generated_at', '<=', $v));

        $column = self::SORTABLE[$sortKey] ?? null;

        if ($column) {
            if ($column === 'customers.name') {
                $query->leftJoin('customers', 'customers.id', '=', 'invoices.customer_id')
                    ->select('invoices.*');
            }

            $query->orderBy($column, $sortDir);

            if ($column !== 'invoices.generated_at') {
                $query->orderByDesc('invoices.generated_at');
            }
            $query->orderByDesc('invoices.id');
        } else {
            $query->orderByDesc('invoices.generated_at')
                ->orderByDesc('invoices.id');
        }

        $invoices = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'message' => 'Invoices retrieved successfully.',
            'data' => InvoiceResource::collection($invoices->items()),
            'meta' => [
                'current_page' => $invoices->currentPage(),
                'last_page' => $invoices->lastPage(),
                'per_page' => $invoices->perPage(),
                'total' => $invoices->total(),
                'from' => $invoices->firstItem(),
                'to' => $invoices->lastItem(),
            ],
        ]);
    }

    public function show(Invoice $invoice)
    {
        $invoice->load(['customer', 'items', 'payments']);

        return response()->json([
            'status' => true,
            'message' => 'Invoice retrieved successfully.',
            'data' => new InvoiceResource($invoice),
        ]);
    }

    public function generate(GenerateInvoiceRequest $request, int $customerId)
    {
        $invoice = $this->generationService->generate(
            $customerId,
            $request->branch_id,
            Carbon::parse($request->start_date),
            Carbon::parse($request->end_date),
            $request->user()->id,
            $request->manual_adjustment_amount,
            $request->manual_adjustment_reason,
        );

        return response()->json([
            'status' => true,
            'message' => 'Invoice generated successfully.',
            'data' => new InvoiceResource($invoice->load(['items', 'payments'])),
        ], 201);
    }

    public function cancel(CancelInvoiceRequest $request, Invoice $invoice)
    {
        $invoice = $this->reversalService->cancel($invoice, $request->user()->id, $request->reason);

        return response()->json([
            'status' => true,
            'message' => 'Invoice cancelled and reversed successfully.',
            'data' => new InvoiceResource($invoice),
        ]);
    }

    public function storePayment(StoreInvoicePaymentRequest $request, Invoice $invoice)
    {
        if ($invoice->status === 'cancelled') {
            return response()->json([
                'status' => false,
                'message' => 'Cannot record a payment against a cancelled invoice.',
                'data' => null,
            ], 422);
        }

        InvoicePayment::create([
            'invoice_id' => $invoice->id,
            'amount' => $request->amount,
            'payment_mode' => $request->payment_mode,
            'received_by' => $request->user()->id,
            'received_at' => now(),
            'note' => $request->note,
        ]);

        $this->generationService->recalculateInvoiceStatus($invoice);

        return response()->json([
            'status' => true,
            'message' => 'Payment recorded successfully.',
            'data' => new InvoiceResource($invoice->fresh(['items', 'payments'])),
        ], 201);
    }

    public function preview(Request $request, int $customerId)
    {
        $request->validate([
            'branch_id' => ['required', 'integer', 'exists:branches,id'],
            'start_date' => ['required', 'date', 'before_or_equal:end_date'],
            'end_date' => ['required', 'date', 'before_or_equal:today', 'after_or_equal:start_date'],
        ]);

        $result = $this->generationService->preview(
            $customerId,
            $request->branch_id,
            Carbon::parse($request->start_date),
            Carbon::parse($request->end_date),
        );

        return response()->json(['status' => true, 'data' => $result]);
    }

    public function pdf(Invoice $invoice, InvoicePdfService $invoicePdf)
    {
        $invoice->load(['customer', 'items.occurrence.subscriptionItem.productVariant', 'payments']);

        return $invoicePdf->buildForSubscriptionInvoice($invoice)
            ->stream('invoice-'.$invoice->id.'.pdf');
    }

    public function bulkPdf(Request $request, InvoicePdfService $invoicePdf)
    {
        $request->validate([
            'invoice_ids' => ['required', 'array', 'min:1', 'max:100'],
            'invoice_ids.*' => ['integer', 'exists:invoices,id'],
        ]);

        $invoices = Invoice::whereIn('id', $request->invoice_ids)->get();

        return $invoicePdf->buildMultipleSubscriptionInvoices($invoices)
            ->stream('invoices-bulk-'.now()->format('Y-m-d').'.pdf');
    }
}
