<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\StoreSubscriptionPauseRequest;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionPause;
use App\Services\V1\Subscriptions\SubscriptionPauseService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class SubscriptionPauseController extends Controller
{
    public function __construct(protected SubscriptionPauseService $service) {}

    public function store(StoreSubscriptionPauseRequest $request, int $itemId)
    {
        $item = SubscriptionItem::findOrFail($itemId);

        $pause = $this->service->create(
            $item,
            Carbon::parse($request->date_from),
            Carbon::parse($request->date_to),
            'admin',
            $request->user()->id,
            $request->reason,
        );

        return response()->json([
            'status' => true,
            'message' => 'Pause recorded successfully.',
            'data' => $pause,
        ], 201);
    }

    public function destroy(Request $request, int $pauseId)
    {
        $pause = SubscriptionPause::findOrFail($pauseId);
        $this->service->resume($pause, 'admin', $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Pause resumed successfully.',
            'data' => null,
        ]);
    }
}
