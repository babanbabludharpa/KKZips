<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\SubmitDeliveryResultsRequest;
use App\Models\DeliveryAssignment;
use App\Services\V1\Subscriptions\DeliveryConfirmationService;
use Illuminate\Validation\ValidationException;

class DeliveryConfirmationController extends Controller
{
    public function __construct(protected DeliveryConfirmationService $service) {}

    public function submit(SubmitDeliveryResultsRequest $request)
    {
        $riderId = $request->user()->id;

        // Verify every assignment in this submission actually belongs to the
        // submitting rider - the permission check alone doesn't guarantee that.
        $assignmentIds = collect($request->results)->pluck('delivery_assignment_id');
        $ownedCount = DeliveryAssignment::whereIn('id', $assignmentIds)
            ->where('delivery_boy_id', $riderId)
            ->count();

        if ($ownedCount !== $assignmentIds->count()) {
            throw ValidationException::withMessages([
                'results' => 'One or more assignments do not belong to you.',
            ]);
        }

        $results = collect($request->results)->keyBy('delivery_assignment_id')
            ->map(fn ($r) => [
                'delivered' => $r['delivered'],
                'reason' => $r['reason'] ?? null,
                'note' => $r['note'] ?? null,
            ])->toArray();

        $this->service->submit($results, $riderId);

        return response()->json([
            'status' => true,
            'message' => 'Delivery results submitted successfully.',
            'data' => null,
        ]);
    }
}
