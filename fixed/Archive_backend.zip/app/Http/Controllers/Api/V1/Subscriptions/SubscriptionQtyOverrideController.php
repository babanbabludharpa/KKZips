<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\StoreSubscriptionQtyOverrideRequest;
use App\Models\SubscriptionItem;
use App\Services\V1\Subscriptions\SubscriptionQtyOverrideService;
use Carbon\Carbon;

class SubscriptionQtyOverrideController extends Controller
{
    public function __construct(protected SubscriptionQtyOverrideService $service) {}

    public function store(StoreSubscriptionQtyOverrideRequest $request, int $itemId)
    {
        $item = SubscriptionItem::findOrFail($itemId);

        $override = $this->service->create(
            $item,
            Carbon::parse($request->date_from),
            Carbon::parse($request->date_to),
            $request->qty,
            'admin',
            $request->user()->id,
            $request->reason,
        );

        return response()->json([
            'status' => true,
            'message' => 'Quantity override created successfully.',
            'data' => $override,
        ], 201);
    }
}
