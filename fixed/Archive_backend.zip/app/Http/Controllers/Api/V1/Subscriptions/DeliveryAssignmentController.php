<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\AssignDeliveryRequest;
use App\Models\DeliveryBoy;
use App\Services\V1\Subscriptions\DeliveryAssignmentService;
use Carbon\Carbon;
use Illuminate\Validation\ValidationException;

class DeliveryAssignmentController extends Controller
{
    public function __construct(protected DeliveryAssignmentService $service) {}

    public function store(AssignDeliveryRequest $request)
    {
        $requiredBranchId = $request->user()->branch_id;

        // Rider must belong to the caller's branch. Fixed: query the
        // delivery_boys table, not users. The FK on delivery_boy_id
        // references delivery_boys.id since the slot migration.
        $riderBranchId = DeliveryBoy::where('id', $request->delivery_boy_id)
            ->value('branch_id');

        if ((int) $riderBranchId !== (int) $requiredBranchId) {
            throw ValidationException::withMessages([
                'delivery_boy_id' => 'The selected rider does not belong to your branch.',
            ]);
        }

        $result = $this->service->assign(
            Carbon::parse($request->occurrence_date),
            (int) $request->delivery_boy_id,
            $request->occurrence_ids,
            $requiredBranchId,
        );

        return response()->json([
            'status' => true,
            'message' => count($result['assigned_occurrence_ids']).' occurrence(s) assigned successfully.',
            'data' => ['assigned_occurrence_ids' => $result['assigned_occurrence_ids']],
        ], 201);
    }
}
