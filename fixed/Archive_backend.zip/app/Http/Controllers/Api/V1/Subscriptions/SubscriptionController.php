<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Subscriptions\StoreSubscriptionRequest;
use App\Http\Resources\V1\SubscriptionResource;
use App\Models\Subscription;
use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Services\V1\Subscriptions\DeliveryBoyAssignmentService;
use App\Services\V1\Subscriptions\SubscriptionLifecycleService;
use App\Services\V1\Subscriptions\SubscriptionOccurrenceGenerationService;
use App\Services\V1\Tenant\TenantLeaveService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubscriptionController extends Controller
{
    public function __construct(
        protected SubscriptionOccurrenceGenerationService $generationService,
        protected SubscriptionLifecycleService $lifecycleService,
        protected DeliveryBoyAssignmentService $assignmentEngine,
    ) {}

    private function assertBranchAccess(Request $request, Subscription $subscription): void
    {
        $user = $request->user();
        if (! $this->userCanAccessAnyBranch($user)) {
            abort_unless((int) $subscription->branch_id === (int) $user->branch_id, 403, 'You do not have access to this subscription.');
        }
    }

    private function userCanAccessAnyBranch($user): bool
    {
        if (is_null($user->branch_id)) {
            return true;
        }
        if ($user->role === 'superadmin') {
            return true;
        }
        return $user->branch?->type === 'head_office';
    }

    public function index(Request $request)
    {
        if (! $request->hasAny(['customer_id', 'status', 'branch_id', 'date_from', 'date_to'])) {
            return response()->json([
                'status' => true,
                'message' => 'Provide at least one filter to search.',
                'data' => [],
                'meta' => ['current_page' => 1, 'last_page' => 1, 'per_page' => 15, 'total' => 0],
            ]);
        }

        $user = $request->user();
        $isHeadOffice = $this->userCanAccessAnyBranch($user);

        $subscriptions = Subscription::query()
            ->with(['customer', 'branch', 'items.slot', 'items.productVariant.product', 'deliveryInstruction'])
            ->when($request->customer_id, fn ($q, $v) => $q->where('customer_id', $v))
            ->when($request->date_from, fn ($q, $v) => $q->whereDate('start_date', '>=', $v))
            ->when($request->date_to, fn ($q, $v) => $q->whereDate('start_date', '<=', $v))
            ->when($request->status === 'bill_pending', function ($q) {
                $q->whereHas('items.occurrences', function ($oq) {
                    $oq->where('status', 'delivered')->whereNull('invoice_id');
                });
            }, function ($q) use ($request) {
                $q->when($request->status, fn ($q, $v) => $q->where('status', $v));
            })
            ->when(
                $isHeadOffice,
                fn ($q) => $q->when($request->branch_id, fn ($q, $v) => $q->where('branch_id', $v)),
                fn ($q) => $q->where('branch_id', $user->branch_id)
            )
            ->latest()
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'status' => true,
            'message' => 'Subscriptions retrieved successfully.',
            'data' => SubscriptionResource::collection($subscriptions->items()),
            'meta' => [
                'current_page' => $subscriptions->currentPage(),
                'last_page' => $subscriptions->lastPage(),
                'per_page' => $subscriptions->perPage(),
                'total' => $subscriptions->total(),
            ],
        ]);
    }

    public function show(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        $subscription->load(['customer', 'branch', 'deliveryAddress', 'items.slot', 'items.productVariant.product', 'deliveryInstruction']);

        return response()->json([
            'status' => true,
            'message' => 'Subscription retrieved successfully.',
            'data' => new SubscriptionResource($subscription),
        ]);
    }

    public function store(StoreSubscriptionRequest $request)
    {
        $user = $request->user();

        if (! $this->userCanAccessAnyBranch($user)) {
            abort_unless(
                (int) $request->branch_id === (int) $user->branch_id,
                403,
                'You can only create subscriptions for your own branch.'
            );
        }

        $subscription = DB::transaction(function () use ($request) {
            $subscription = Subscription::create([
                'customer_id' => $request->customer_id,
                'branch_id' => $request->branch_id,
                'delivery_address_id' => $request->delivery_address_id,
                'status' => 'active',
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
            ]);

            foreach ($request->items as $itemData) {
                $item = SubscriptionItem::create([
                    'subscription_id' => $subscription->id,
                    'product_variant_id' => $itemData['product_variant_id'],
                    'default_qty' => $itemData['default_qty'],
                    'slot_id' => $itemData['slot_id'],
                    'schedule_type' => $itemData['schedule_type'],
                    'schedule_days' => $itemData['schedule_days'] ?? null,
                    'schedule_dates' => $itemData['schedule_dates'] ?? null,
                    'qty_by_day' => $itemData['qty_by_day'] ?? null,
                    'status' => 'active',
                ]);

                $this->generationService->generateInitialOccurrence($item);

                $occurrences = SubscriptionOccurrence::where('subscription_item_id', $item->id)
                    ->whereNull('delivery_boy_id')
                    ->with(['subscriptionItem.subscription.deliveryAddress'])
                    ->get();

                foreach ($occurrences as $occ) {
                    $this->assignmentEngine->assignOccurrence($occ);
                }
            }

            return $subscription;
        });

        return response()->json([
            'status' => true,
            'message' => 'Subscription created successfully.',
            'data' => new SubscriptionResource($subscription->load('items')),
        ], 201);
    }

    public function pause(Request $request, int $subscriptionId)
    {
        abort_unless($request->user()->can('subscription.edit'), 403);

        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        abort_unless($subscription->status === 'active', 422, 'Only an active subscription can be paused.');

        DB::transaction(function () use ($subscription) {
            // 1. Update subscription status
            $subscription->update(['status' => 'paused']);

            // 2. Pause all FUTURE occurrences across this subscription that
            //    are still mutable. Past delivered / locked rows untouched.
            $mutableStatuses = ['scheduled', 'assigned'];

            SubscriptionOccurrence::query()
                ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                    $q->where('subscription_id', $subscription->id);
                })
                ->whereDate('occurrence_date', '>=', now()->toDateString())
                ->whereIn('status', $mutableStatuses)
                ->update([
                    'status' => 'admin_paused',
                    'skip_source' => 'admin',
                ]);
        });

        return response()->json([
            'status' => true,
            'message' => 'Subscription paused and future occurrences updated.',
            'data' => new SubscriptionResource($subscription->fresh()),
        ]);
    }

    public function resume(Request $request, int $subscriptionId)
    {
        abort_unless($request->user()->can('subscription.edit'), 403);

        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        abort_unless($subscription->status === 'paused', 422, 'Only a paused subscription can be resumed.');

        DB::transaction(function () use ($subscription) {
            // 1. Update subscription status
            $subscription->update(['status' => 'active']);

            // 2. Reactivate all future occurrences that were paused by the
            //    subscription-level pause. Do NOT touch occurrences that
            //    were paused by a specific date-range pause (SubscriptionPause)
            //    or by a leave (holiday_skipped).
            $today = now()->toDateString();

            SubscriptionOccurrence::query()
                ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                    $q->where('subscription_id', $subscription->id);
                })
                ->whereDate('occurrence_date', '>=', $today)
                ->where('status', 'admin_paused')
                ->update([
                    'status' => 'scheduled',
                    'skip_source' => null,
                ]);
        });

        return response()->json([
            'status' => true,
            'message' => 'Subscription resumed and future occurrences restored.',
            'data' => new SubscriptionResource($subscription->fresh()),
        ]);
    }

    public function cancel(Request $request, int $subscriptionId)
    {
        abort_unless($request->user()->can('subscription.edit'), 403);

        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        abort_unless(in_array($subscription->status, ['active', 'paused']), 422, 'This subscription is already cancelled.');

        DB::transaction(function () use ($subscription) {
            $subscription->update(['status' => 'cancelled']);

            $mutableStatuses = ['scheduled', 'assigned', 'admin_paused', 'customer_paused'];

            SubscriptionOccurrence::query()
                ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                    $q->where('subscription_id', $subscription->id);
                })
                ->whereDate('occurrence_date', '>=', now()->toDateString())
                ->whereIn('status', $mutableStatuses)
                ->update([
                    'status' => 'cancelled',
                    'skip_source' => 'admin',
                    'not_delivered_reason' => 'other',
                    'not_delivered_note' => 'Subscription terminated by admin',
                ]);
        });

        return response()->json([
            'status' => true,
            'message' => 'Subscription terminated and future occurrences cancelled.',
            'data' => new SubscriptionResource($subscription->fresh()),
        ]);
    }


    public function blockedDates(Request $request, TenantLeaveService $leaves)
    {
        $data = $request->validate([
            'branch_id'    => 'required|integer|exists:branches,id',
            'horizon_days' => 'nullable|integer|min:1|max:180',
        ]);

        $user = $request->user();
        if (! $this->userCanAccessAnyBranch($user)) {
            abort_unless(
                (int) $data['branch_id'] === (int) $user->branch_id,
                403,
                'You do not have access to this branch.'
            );
        }

        $horizon = (int) ($data['horizon_days'] ?? 120);

        return response()->json([
            'status' => true,
            'data'   => $leaves->blockedDatesFor((int) $data['branch_id'], $horizon),
        ]);
    }

    public function temporaryChanges(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        $pauses = \App\Models\SubscriptionPause::whereHas('subscriptionItem', function ($q) use ($subscriptionId) {
            $q->where('subscription_id', $subscriptionId);
        })->get()->map(fn($p) => [
            'id' => $p->id,
            'type' => 'pause',
            'duration' => \Carbon\Carbon::parse($p->date_from)->format('jS M') . ' - ' . \Carbon\Carbon::parse($p->date_to)->format('jS M, Y'),
            'change' => 'Cancelled by ' . $p->initiated_by,
            'raw_date_from' => $p->date_from,
            'raw_date_to' => $p->date_to,
        ]);

        $overrides = \App\Models\SubscriptionQtyOverride::whereHas('subscriptionItem', function ($q) use ($subscriptionId) {
            $q->where('subscription_id', $subscriptionId);
        })->get()->map(fn($o) => [
            'id' => $o->id,
            'type' => 'qty',
            'duration' => \Carbon\Carbon::parse($o->date_from)->format('jS M') . ' - ' . \Carbon\Carbon::parse($o->date_to)->format('jS M, Y'),
            'change' => 'Qty changed to ' . $o->qty,
            'raw_date_from' => $o->date_from,
            'raw_date_to' => $o->date_to,
        ]);

        $combined = $pauses->concat($overrides)->sortByDesc('raw_date_from')->values();

        return response()->json(['status' => true, 'data' => $combined]);
    }

    public function updateSettings(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        $validated = $request->validate([
            'auto_renew' => 'sometimes|boolean',
            'delivery_instruction_id' => 'nullable|integer|exists:delivery_instructions,id',
            'slot_id' => 'sometimes|integer|exists:tenant_delivery_slots,id',
            'schedule_type' => 'sometimes|string|in:daily,alternate,weekly,custom_days',
        ]);

        DB::transaction(function () use ($subscription, $validated) {
            $subData = [];
            if (isset($validated['auto_renew'])) $subData['auto_renew'] = $validated['auto_renew'];
            if (array_key_exists('delivery_instruction_id', $validated)) {
                $subData['delivery_instruction_id'] = $validated['delivery_instruction_id'];
            }
            if (!empty($subData)) $subscription->update($subData);

            $itemData = [];
            if (isset($validated['slot_id'])) $itemData['slot_id'] = $validated['slot_id'];
            if (isset($validated['schedule_type'])) $itemData['schedule_type'] = $validated['schedule_type'];

            if (!empty($itemData)) {
                $subscription->items()->update($itemData);
            }
        });

        return response()->json(['status' => true, 'message' => 'Subscription settings updated.']);
    }

        public function addPause(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        $validated = $request->validate([
            'date_from' => 'required|date',
            'date_to'   => 'required|date|after_or_equal:date_from',
            'reason'    => 'nullable|string|max:255',
        ]);

        DB::transaction(function () use ($subscription, $validated) {
            // 1. Create the pause records for each item
            foreach ($subscription->items as $item) {
                \App\Models\SubscriptionPause::create([
                    'subscription_item_id' => $item->id,
                    'date_from' => $validated['date_from'],
                    'date_to'   => $validated['date_to'],
                    'reason'    => $validated['reason'] ?? 'Paused by admin',
                    'initiated_by' => 'admin',
                ]);
            }

            // 2. Retroactively update existing occurrences to 'admin_paused'
            $mutableStatuses = ['scheduled', 'assigned'];

            SubscriptionOccurrence::query()
                ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                    $q->where('subscription_id', $subscription->id);
                })
                ->whereBetween('occurrence_date', [$validated['date_from'], $validated['date_to']])
                ->whereIn('status', $mutableStatuses)
                ->update([
                    'status' => 'admin_paused',
                    'skip_source' => 'admin',
                ]);
        });

        return response()->json(['status' => true, 'message' => 'Pause applied and occurrences updated.']);
    }

    public function deletePause(Request $request, int $pauseId)
    {
        $pause = \App\Models\SubscriptionPause::findOrFail($pauseId);
        $this->assertBranchAccess($request, $pause->subscriptionItem->subscription);

        DB::transaction(function () use ($pause) {
            $item = $pause->subscriptionItem;
            $dateFrom = $pause->date_from;
            $dateTo   = $pause->date_to;

            // 1. Delete the pause record
            $pause->delete();

            // 2. Restore occurrences back to 'scheduled' (if they aren't cancelled by leave)
            SubscriptionOccurrence::query()
                ->where('subscription_item_id', $item->id)
                ->whereBetween('occurrence_date', [$dateFrom, $dateTo])
                ->where('status', 'admin_paused')
                ->update([
                    'status' => 'scheduled',
                    'skip_source' => null,
                ]);
        });

        return response()->json(['status' => true, 'message' => 'Pause removed and occurrences restored.']);
    }

    public function addQtyOverride(Request $request, int $subscriptionId)
    {
        $subscription = Subscription::findOrFail($subscriptionId);
        $this->assertBranchAccess($request, $subscription);

        $validated = $request->validate([
            'date_from' => 'required|date',
            'date_to'   => 'required|date|after_or_equal:date_from',
            'qty'       => 'required|integer|min:0',
            'reason'    => 'nullable|string|max:255',
        ]);

        DB::transaction(function () use ($subscription, $validated) {
            // 1. Create the override row (for future generation cycles)
            foreach ($subscription->items as $item) {
                \App\Models\SubscriptionQtyOverride::create([
                    'subscription_item_id' => $item->id,
                    'date_from' => $validated['date_from'],
                    'date_to'   => $validated['date_to'],
                    'qty'       => $validated['qty'],
                    'initiated_by' => 'customer',
                    'reason'    => $validated['reason'] ?? 'demand',
                ]);
            }

            // 2. Retroactively update existing occurrences in the range —
            //    BUT only the ones that haven't moved past "assigned".
            //    Anything delivered / out_for_delivery / picked_up / cancelled
            //    is a historical record and must not be touched.
            $mutableStatuses = ['scheduled', 'assigned'];

            SubscriptionOccurrence::query()
                ->whereHas('subscriptionItem', function ($q) use ($subscription) {
                    $q->where('subscription_id', $subscription->id);
                })
                ->whereBetween('occurrence_date', [$validated['date_from'], $validated['date_to']])
                ->whereIn('status', $mutableStatuses)
                ->update(['qty' => (int) $validated['qty']]);
        });

        return response()->json(['status' => true, 'message' => 'Quantity updated.']);
    }

    public function deleteQtyOverride(Request $request, int $overrideId)
    {
        $override = \App\Models\SubscriptionQtyOverride::findOrFail($overrideId);
        $this->assertBranchAccess($request, $override->subscriptionItem->subscription);

        DB::transaction(function () use ($override) {
            $item = $override->subscriptionItem;
            $dateFrom = $override->date_from;
            $dateTo   = $override->date_to;

            // 1. Delete the override row
            $override->delete();

            // 2. Reset the qty on any still-mutable occurrences back to
            //    the item's default qty. Delivered / locked rows untouched.
            $mutableStatuses = ['scheduled', 'assigned'];

            SubscriptionOccurrence::query()
                ->where('subscription_item_id', $item->id)
                ->whereBetween('occurrence_date', [$dateFrom, $dateTo])
                ->whereIn('status', $mutableStatuses)
                ->update(['qty' => (int) $item->default_qty]);
        });

        return response()->json(['status' => true, 'message' => 'Quantity override removed.']);
    }
}
