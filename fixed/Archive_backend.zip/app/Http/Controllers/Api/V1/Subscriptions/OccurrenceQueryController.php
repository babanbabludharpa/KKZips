<?php

namespace App\Http\Controllers\Api\V1\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\SubscriptionOccurrenceResource;
use App\Models\DeliveryBoy;
use App\Models\SubscriptionOccurrence;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OccurrenceQueryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        abort_unless($request->user()->can('subscription.view'), 403);

        $request->validate([
            'date' => 'nullable|date',
            'date_from' => 'nullable|date',
            'date_to' => 'nullable|date|after_or_equal:date_from',
            'branch_id' => 'nullable|integer|exists:branches,id',
            'zone_id' => 'nullable|integer|exists:branch_service_zones,id',
            'delivery_boy_id' => 'nullable',
            'slot_id' => 'nullable|integer|exists:tenant_delivery_slots,id',
            'status' => 'nullable|string',
            'assignment_type' => 'nullable|in:preferred,substitute,manual_override',
            'per_page' => 'nullable|integer|min:1|max:200',
        ]);

        $user = $request->user();
        $isHeadOffice = is_null($user->branch_id)
            || $user->role === 'superadmin'
            || $user->branch?->type === 'head_office'
            || (method_exists($user, 'hasAnyRole')
                && $user->hasAnyRole(['staff_headoffice', 'superadmin', 'admin']));

        $perPage = (int) ($request->input('per_page') ?? 50);
        $perPage = max(1, min(200, $perPage));

        $query = SubscriptionOccurrence::query()
            ->with([
                'subscriptionItem.slot',
                'subscriptionItem.productVariant.product',
                'subscriptionItem.subscription.customer',
                'subscriptionItem.subscription.deliveryAddress.zone',
                'deliveryBoy',
            ])
            ->when($request->filled('date'), function ($q) use ($request) {
                $q->whereDate('occurrence_date', $request->input('date'));
            })
            ->when($request->filled('date_from'), function ($q) use ($request) {
                $q->whereDate('occurrence_date', '>=', $request->input('date_from'));
            })
            ->when($request->filled('date_to'), function ($q) use ($request) {
                $q->whereDate('occurrence_date', '<=', $request->input('date_to'));
            })
            ->when($request->filled('assignment_type'), function ($q) use ($request) {
                $q->where('assignment_type', $request->input('assignment_type'));
            })
            ->when($request->filled('status'), function ($q) use ($request) {
                $statuses = array_filter(
                    array_map('trim', explode(',', (string) $request->input('status')))
                );
                if (! empty($statuses)) {
                    $q->whereIn('status', $statuses);
                }
            });

        // ── Branch scoping ─────────────────────────────────────────
        if ($request->filled('branch_id')) {
            if (! $isHeadOffice && (int) $request->input('branch_id') !== (int) $user->branch_id) {
                return response()->json([
                    'status' => false,
                    'message' => 'You do not have access to that branch.',
                ], 403);
            }
            $query->where('branch_id', (int) $request->input('branch_id'));
        } elseif (! $isHeadOffice) {
            $query->where('branch_id', $user->branch_id);
        }

        // ── Rider-vs-branch strictness (new) ──────────────────────
        // Runs before the delivery_boy_id filter below so the effective
        // branch can be inferred from the rider when no branch filter
        // is present — this is what makes "find Rider A's work, reassign
        // to Rider B" safe: the operator can't accidentally span branches.
        if ($request->filled('delivery_boy_id') && $request->input('delivery_boy_id') !== 'null') {
            $riderId       = (int) $request->input('delivery_boy_id');
            $riderBranchId = DeliveryBoy::where('id', $riderId)->value('branch_id');

            if ($riderBranchId === null) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Selected rider was not found.',
                ], 404);
            }

            if (! $isHeadOffice) {
                if ((int) $riderBranchId !== (int) $user->branch_id) {
                    return response()->json([
                        'status'  => false,
                        'message' => 'You cannot filter by a rider outside your branch.',
                    ], 403);
                }
            } else {
                if ($request->filled('branch_id')) {
                    if ((int) $riderBranchId !== (int) $request->input('branch_id')) {
                        return response()->json([
                            'status'  => false,
                            'message' => 'Selected rider does not belong to the chosen branch.',
                        ], 422);
                    }
                } else {
                    $query->where('branch_id', (int) $riderBranchId);
                }
            }
        }

        if ($request->filled('delivery_boy_id')) {
            $raw = $request->input('delivery_boy_id');
            if ($raw === 'null') {
                $query->whereNull('delivery_boy_id');
            } else {
                $query->where('delivery_boy_id', (int) $raw);
            }
        }

        // ── Zone filter ───────────────────────────────────────────
        // This is the core of the outage flow: filter by zone to see
        // which occurrences in that zone had Rider A, so they can be
        // reassigned to Rider B (whose zone coverage is checked by the
        // engine at reassign time, not here).
        if ($request->filled('zone_id')) {
            $zoneId = (int) $request->input('zone_id');
            $query->whereHas('subscriptionItem.subscription.deliveryAddress', function ($q) use ($zoneId) {
                $q->where('zone_id', $zoneId);
            });
        }

        if ($request->filled('slot_id')) {
            $slotId = (int) $request->input('slot_id');
            $query->whereHas('subscriptionItem', function ($q) use ($slotId) {
                $q->where('slot_id', $slotId);
            });
        }

        $paginated = $query->orderBy('occurrence_date')->orderBy('id')->paginate($perPage);

        return response()->json([
            'status' => true,
            'message' => 'Occurrences retrieved successfully.',
            'data' => SubscriptionOccurrenceResource::collection($paginated->items()),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
                'from' => $paginated->firstItem(),
                'to' => $paginated->lastItem(),
            ],
        ]);
    }
}
