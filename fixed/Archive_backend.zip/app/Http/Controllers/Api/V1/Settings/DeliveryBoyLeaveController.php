<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Settings\StoreDeliveryBoyLeaveRequest;
use App\Models\DeliveryBoy;
use App\Models\DeliveryBoyLeave;
use App\Services\V1\Subscriptions\DeliveryBoyLeaveService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeliveryBoyLeaveController extends Controller
{
    public function __construct(
        protected DeliveryBoyLeaveService $service,
    ) {}

    public function index(Request $request, int $riderId): JsonResponse
    {
        abort_unless($request->user()->can('delivery_boy.view'), 403);

        $rider = DeliveryBoy::findOrFail($riderId);

        $leaves = DeliveryBoyLeave::with('slot')
            ->where('delivery_boy_id', $rider->id)
            ->orderByDesc('start_date')
            ->get()
                        ->map(fn ($l) => [
                'id'              => $l->id,
                'slot_id'         => $l->slot_id,
                'slot_name'       => $l->slot?->name,
                'slot_start_time' => $l->slot?->start_time ? substr($l->slot->start_time, 0, 5) : null,
                'slot_end_time'   => $l->slot?->end_time ? substr($l->slot->end_time, 0, 5) : null,
                'start_date'      => $l->start_date?->toDateString(),
                'end_date'        => $l->end_date?->toDateString(),
                'reason'          => $l->reason,
                'created_at'      => $l->created_at,
            ]);

        return response()->json([
            'status'  => true,
            'message' => 'Leaves retrieved.',
            'data'    => $leaves,
        ]);
    }

    public function store(StoreDeliveryBoyLeaveRequest $request, int $riderId): JsonResponse
    {
        $rider = DeliveryBoy::findOrFail($riderId);
        $validated = $request->validated();

        $slotId = array_key_exists('slot_id', $validated) && $validated['slot_id'] !== null
        ? (int) $validated['slot_id']
        : null;

        $leave = $this->service->create(
            $rider,
            $slotId,
            Carbon::parse($validated['start_date']),
            Carbon::parse($validated['end_date']),
            $validated['reason'] ?? null,
            (int) $request->user()->id,
        );

        return response()->json([
            'status'  => true,
            'message' => 'Leave created and affected occurrences rebalanced.',
            'data'    => [
                'id'         => $leave->id,
                'slot_id'    => $leave->slot_id,
                'start_date' => $leave->start_date?->toDateString(),
                'end_date'   => $leave->end_date?->toDateString(),
                'reason'     => $leave->reason,
            ],
        ], 201);
    }

    public function destroy(Request $request, int $riderId, int $leaveId): JsonResponse
    {
        abort_unless($request->user()->can('delivery_boy.edit'), 403);

        $leave = DeliveryBoyLeave::withTrashed()->find($leaveId);

        if (! $leave) {
            return response()->json([
                'status'  => false,
                'message' => 'Leave not found.',
            ], 404);
        }

        if ($leave->trashed()) {
            return response()->json([
                'status'  => false,
                'message' => 'This leave has already been deleted.',
            ], 422);
        }

        $this->service->delete($leave, (int) $request->user()->id);

        return response()->json([
            'status'  => true,
            'message' => 'Leave soft-deleted and future occurrences rebalanced.',
            'data'    => [],
        ]);
    }
}
