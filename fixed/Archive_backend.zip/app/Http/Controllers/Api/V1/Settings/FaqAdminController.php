<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Models\FaqCollection;
use App\Models\FaqItem;
use App\Models\FaqUnmatched;
use App\Services\V1\Faq\FaqMatcher;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FaqAdminController extends Controller
{
    public function __construct(protected FaqMatcher $matcher) {}

    public function collections(): JsonResponse
    {
        $collections = FaqCollection::query()
            ->withCount('items')
            ->ordered()
            ->get(['id', 'name', 'slug', 'description', 'icon', 'sort_order', 'is_active']);

        return response()->json([
            'status' => true,
            'data' => $collections,
        ]);
    }

    public function storeCollection(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'description' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:50',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'sometimes|boolean',
        ]);

        $validated['slug'] = $this->uniqueSlug($validated['name']);

        $collection = FaqCollection::create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Collection created.',
            'data' => $collection,
        ], 201);
    }

    public function updateCollection(Request $request, int $id): JsonResponse
    {
        $collection = FaqCollection::findOrFail($id);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:100',
            'description' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:50',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'sometimes|boolean',
        ]);

        $collection->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Collection updated.',
            'data' => $collection->fresh(),
        ]);
    }

    public function destroyCollection(int $id): JsonResponse
    {
        $collection = FaqCollection::withCount('items')->findOrFail($id);

        if ($collection->items_count > 0) {
            return response()->json([
                'status' => false,
                'message' => "Cannot delete a collection with {$collection->items_count} FAQ(s). Move or delete them first.",
            ], 422);
        }

        $collection->delete();

        return response()->json([
            'status' => true,
            'message' => 'Collection deleted.',
        ]);
    }

    public function items(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'search' => 'nullable|string|max:255',
            'collection_id' => 'nullable|integer|exists:faq_collections,id',
            'status' => 'nullable|in:active,inactive,all',
            'sort' => 'nullable|in:recent,views,feedback,question',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        $query = FaqItem::query()->with('collection:id,name,slug');

        if ($search = $validated['search'] ?? null) {
            $query->where(function ($q) use ($search) {
                $q->where('question', 'like', "%{$search}%")
                    ->orWhere('answer', 'like', "%{$search}%");
            });
        }

        if ($collectionId = $validated['collection_id'] ?? null) {
            $query->where('collection_id', $collectionId);
        }

        $status = $validated['status'] ?? 'active';
        if ($status === 'active') {
            $query->where('is_active', true);
        }
        if ($status === 'inactive') {
            $query->where('is_active', false);
        }

        match ($validated['sort'] ?? 'recent') {
            'views' => $query->orderByDesc('view_count'),
            'feedback' => $query->orderByRaw(
                '(CASE WHEN (helpful_count + not_helpful_count) = 0 THEN 0 '
                .'ELSE not_helpful_count / (helpful_count + not_helpful_count) END) DESC'
            ),
            'question' => $query->orderBy('question'),
            default => $query->orderByDesc('updated_at'),
        };

        $perPage = $validated['per_page'] ?? 25;
        $paginated = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => collect($paginated->items())->map(fn ($f) => $this->serializeItem($f)),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    public function showItem(int $id): JsonResponse
    {
        $faq = FaqItem::with('collection:id,name,slug')->findOrFail($id);

        return response()->json([
            'status' => true,
            'data' => $this->serializeItem($faq, detailed: true),
        ]);
    }

    public function storeItem(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'collection_id' => 'required|integer|exists:faq_collections,id',
            'question' => 'required|string|max:500',
            'answer' => 'required|string|max:10000',
            'alternative_questions' => 'nullable|array',
            'alternative_questions.*' => 'string|max:500',
            'keywords' => 'nullable|array',
            'keywords.*' => 'string|max:100',
            'is_active' => 'sometimes|boolean',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['language'] = 'en';
        $validated['is_active'] = $validated['is_active'] ?? true;

        $faq = FaqItem::create($validated);

        return response()->json([
            'status' => true,
            'message' => 'FAQ created.',
            'data' => $this->serializeItem($faq->fresh('collection')),
        ], 201);
    }

    public function updateItem(Request $request, int $id): JsonResponse
    {
        $faq = FaqItem::findOrFail($id);

        $validated = $request->validate([
            'collection_id' => 'sometimes|integer|exists:faq_collections,id',
            'question' => 'sometimes|string|max:500',
            'answer' => 'sometimes|string|max:10000',
            'alternative_questions' => 'nullable|array',
            'alternative_questions.*' => 'string|max:500',
            'keywords' => 'nullable|array',
            'keywords.*' => 'string|max:100',
            'is_active' => 'sometimes|boolean',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['customized_at'] = now();

        $faq->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'FAQ updated.',
            'data' => $this->serializeItem($faq->fresh('collection')),
        ]);
    }

    public function destroyItem(int $id): JsonResponse
    {
        $faq = FaqItem::findOrFail($id);

        $faq->embeddings()->delete();
        $faq->delete();

        return response()->json([
            'status' => true,
            'message' => 'FAQ deleted.',
        ]);
    }

    public function unmatched(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'status' => 'nullable|in:pending,converted,all',
            'search' => 'nullable|string|max:255',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        $query = FaqUnmatched::query();

        $status = $validated['status'] ?? 'pending';
        if ($status === 'pending') {
            $query->whereNull('converted_faq_id');
        }
        if ($status === 'converted') {
            $query->whereNotNull('converted_faq_id');
        }

        if ($search = $validated['search'] ?? null) {
            $query->where('question', 'like', "%{$search}%");
        }

        $query->orderByDesc('hit_count')->orderByDesc('last_asked_at');

        $perPage = $validated['per_page'] ?? 25;
        $paginated = $query->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => $paginated->items(),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    public function convertUnmatched(Request $request, int $id): JsonResponse
    {
        $unmatched = FaqUnmatched::findOrFail($id);

        if ($unmatched->converted_faq_id) {
            return response()->json([
                'status' => false,
                'message' => 'This question has already been converted.',
            ], 422);
        }

        $validated = $request->validate([
            'collection_id' => 'required|integer|exists:faq_collections,id',
            'question' => 'nullable|string|max:500',
            'answer' => 'required|string|max:10000',
            'alternatives' => 'nullable|array',
            'alternatives.*' => 'string|max:500',
            'keywords' => 'nullable|array',
            'keywords.*' => 'string|max:100',
        ]);

        $faq = DB::transaction(function () use ($validated, $unmatched) {
            $faq = FaqItem::create([
                'collection_id' => $validated['collection_id'],
                'language' => 'en',
                'question' => $validated['question'] ?? $this->humanize($unmatched->question),
                'answer' => $validated['answer'],
                'alternative_questions' => $validated['alternatives'] ?? [$unmatched->question],
                'keywords' => $validated['keywords'] ?? [],
                'is_active' => true,
                'customized_at' => now(),
            ]);

            $unmatched->update(['converted_faq_id' => $faq->id]);

            return $faq;
        });

        return response()->json([
            'status' => true,
            'message' => 'Question converted to FAQ.',
            'data' => $this->serializeItem($faq->fresh('collection')),
        ], 201);
    }

    public function dismissUnmatched(int $id): JsonResponse
    {
        $unmatched = FaqUnmatched::findOrFail($id);
        $unmatched->delete();

        return response()->json([
            'status' => true,
            'message' => 'Question dismissed.',
        ]);
    }

    public function test(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'question' => 'required|string|min:2|max:500',
        ]);

        $result = $this->matcher->match($validated['question'], null);

        $matchedFaq = null;
        if ($result->faq) {
            $matchedFaq = [
                'id' => $result->faq->id,
                'question' => $result->faq->question,
                'answer' => $result->faq->answer,
                'collection' => $result->faq->collection?->name,
            ];
        }

        return response()->json([
            'status' => true,
            'data' => [
                'matched' => $result->isMatched(),
                'layer' => $result->layer,
                'confidence' => $result->confidence,
                'score' => $result->score,
                'faq' => $matchedFaq,
                'suggestions' => $result->suggestions,
                'metadata' => $result->metadata,
            ],
        ]);
    }

    private function serializeItem(FaqItem $faq, bool $detailed = false): array
    {
        $base = [
            'id' => $faq->id,
            'question' => $faq->question,
            'answer' => $faq->answer,
            'collection_id' => $faq->collection_id,
            'collection' => $faq->collection ? [
                'id' => $faq->collection->id,
                'name' => $faq->collection->name,
                'slug' => $faq->collection->slug,
            ] : null,
            'is_active' => $faq->is_active,
            'view_count' => $faq->view_count,
            'helpful_count' => $faq->helpful_count,
            'not_helpful_count' => $faq->not_helpful_count,
            'helpful_ratio' => $faq->helpfulRatio(),
            'customized_at' => optional($faq->customized_at)->toIso8601String(),
            'updated_at' => optional($faq->updated_at)->toIso8601String(),
        ];

        if ($detailed) {
            $base['alternative_questions'] = $faq->alternative_questions ?? [];
            $base['keywords'] = $faq->keywords ?? [];
            $base['sort_order'] = $faq->sort_order;
        }

        return $base;
    }

    private function humanize(string $text): string
    {
        $text = trim($text);
        if ($text === '') {
            return $text;
        }
        $text = ucfirst($text);
        if (! preg_match('/[?!.]$/', $text)) {
            $text .= '?';
        }

        return $text;
    }

    private function uniqueSlug(string $name): string
    {
        $base = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $name), '-'));
        $slug = $base;
        $n = 2;
        while (FaqCollection::where('slug', $slug)->exists()) {
            $slug = "{$base}-{$n}";
            $n++;
        }

        return $slug;
    }
}
