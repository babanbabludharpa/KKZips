<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use App\Models\BranchServiceZone;
use App\Services\V1\Settings\BranchServiceZoneService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BranchServiceZoneController extends Controller
{
    private const MSG_ZONE_NOT_FOUND = 'Zone not found for this branch.';

    public function __construct(protected BranchServiceZoneService $service) {}

    // GET /settings/branches/{branch}/zones
    public function index(Branch $branch): JsonResponse
    {
        $zones = $this->service->getAllForBranch($branch);

        return response()->json([
            'status' => true,
            'message' => 'Zones fetched.',
            'data' => ['zones' => $zones],
        ]);
    }

    // POST /settings/branches/{branch}/zones
    public function store(Request $request, Branch $branch): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'coordinates' => ['required', 'array', 'min:3'],
            'coordinates.*' => ['array', 'size:2'],
            'is_active' => ['boolean'],
        ]);

        $zone = $this->service->create($branch, $validated, $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Zone created.',
            'data' => ['zone' => $zone],
        ], 201);
    }

    // PUT /settings/branches/{branch}/zones/{zone}
    public function update(Request $request, Branch $branch, BranchServiceZone $zone): JsonResponse
    {
        if ($zone->branch_id !== $branch->id) {
            return $this->zoneNotFoundResponse();
        }

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'coordinates' => ['sometimes', 'array', 'min:3'],
            'coordinates.*' => ['array', 'size:2'],
            'is_active' => ['boolean'],
        ]);

        $zone = $this->service->update($zone, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Zone updated.',
            'data' => ['zone' => $zone],
        ]);
    }

    // DELETE /settings/branches/{branch}/zones/{zone}
    public function destroy(Branch $branch, BranchServiceZone $zone): JsonResponse
    {
        if ($zone->branch_id !== $branch->id) {
            return $this->zoneNotFoundResponse();
        }

        $this->service->delete($zone);

        return response()->json([
            'status' => true,
            'message' => 'Zone deleted.',
            'data' => [],
        ]);
    }

    // PATCH /settings/branches/{branch}/zones/{zone}/toggle
    public function toggle(Branch $branch, BranchServiceZone $zone): JsonResponse
    {
        if ($zone->branch_id !== $branch->id) {
            return $this->zoneNotFoundResponse();
        }

        $zone = $this->service->toggleActive($zone);

        return response()->json([
            'status' => true,
            'message' => 'Zone status updated.',
            'data' => ['zone' => $zone],
        ]);
    }

    // POST /serviceability-check  (public — called from customer frontend)
    public function checkServiceability(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'lat' => ['required', 'numeric', 'between:-90,90'],
            'lng' => ['required', 'numeric', 'between:-180,180'],
        ]);

        $branches = $this->service->findServicingBranches($validated['lat'], $validated['lng']);

        return response()->json([
            'status' => true,
            'message' => count($branches) > 0 ? 'Serviceable branches found.' : 'No branches service this location.',
            'data' => ['branches' => $branches],
        ]);
    }

    private function zoneNotFoundResponse(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => self::MSG_ZONE_NOT_FOUND,
        ], 404);
    }
}
