<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\WarehouseResource;
use App\Models\Warehouse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WarehouseController extends Controller
{
    public function index(Request $request)
    {
        $warehouses = Warehouse::with(['city', 'state'])
            ->latest()
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'status' => true,
            'message' => 'Warehouses fetched.',
            'data' => WarehouseResource::collection($warehouses)->response()->getData(true),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'nullable|string|max:50|unique:warehouses,code',
            'address' => 'nullable|string',
            'state_id' => 'required|exists:states,id',
            'city_id' => 'required|exists:cities,id',
            'pincode' => 'nullable|string|max:10',
            'gst_no' => 'nullable|string|max:15',
            'fssai_no' => 'nullable|string|max:20',
            'phone' => 'nullable|string|max:15',
            'contact_email' => 'nullable|email|max:255',
            'is_primary' => 'boolean',
        ]);

        $warehouse = DB::transaction(function () use ($validated) {
            if (! empty($validated['is_primary']) && $validated['is_primary']) {
                Warehouse::where('is_primary', true)->update(['is_primary' => false]);
            }

            return Warehouse::create($validated);
        });

        return response()->json([
            'status' => true,
            'message' => 'Warehouse created successfully.',
            'data' => new WarehouseResource($warehouse->load(['city', 'state'])),
        ], 201);
    }

    public function show(Warehouse $warehouse)
    {
        return response()->json([
            'status' => true,
            'message' => 'Warehouse fetched.',
            'data' => new WarehouseResource($warehouse->load(['city', 'state'])),
        ]);
    }

    public function update(Request $request, Warehouse $warehouse)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'code' => 'sometimes|nullable|string|max:50|unique:warehouses,code,'.$warehouse->id,
            'address' => 'nullable|string',
            'state_id' => 'sometimes|exists:states,id',
            'city_id' => 'sometimes|exists:cities,id',
            'pincode' => 'nullable|string|max:10',
            'gst_no' => 'nullable|string|max:15',
            'fssai_no' => 'nullable|string|max:20',
            'phone' => 'nullable|string|max:15',
            'contact_email' => 'nullable|email|max:255',
            'is_primary' => 'boolean',
            'is_active' => 'boolean',
        ]);

        DB::transaction(function () use ($data, $warehouse) {
            if (! empty($data['is_primary']) && $data['is_primary']) {
                Warehouse::where('is_primary', true)
                    ->where('id', '!=', $warehouse->id)
                    ->update(['is_primary' => false]);
            }
            $warehouse->update($data);
        });

        return response()->json([
            'status' => true,
            'message' => 'Warehouse updated.',
            'data' => new WarehouseResource($warehouse->fresh()->load(['city', 'state'])),
        ]);
    }

    public function destroy(Warehouse $warehouse)
    {
        if ($warehouse->is_primary) {
            return response()->json([
                'status' => false,
                'message' => 'Cannot delete primary warehouse.',
                'data' => [],
            ], 422);
        }

        $warehouse->delete();

        return response()->json([
            'status' => true,
            'message' => 'Warehouse deleted.',
            'data' => [],
        ]);
    }
}
