<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\BranchResource;
use App\Models\Branch;
use App\Services\V1\Settings\BranchService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BranchController extends Controller
{
    public function __construct(protected BranchService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'type' => 'nullable|in:head_office,state_office,branch',
            'per_page' => 'nullable|integer|min:1|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $branches = $this->service->getAll(
            $request->only(['search', 'type', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Branches fetched.',
            'data' => BranchResource::collection($branches)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        if ($request->filled('code')) {
            $request->merge(['code' => strtoupper($request->input('code'))]);
        }

        $request->merge([
            'opens_at' => $request->filled('opens_at') ? substr($request->input('opens_at'), 0, 5) : null,
            'closes_at' => $request->filled('closes_at') ? substr($request->input('closes_at'), 0, 5) : null,
        ]);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'code' => ['required', 'string', 'size:4', 'regex:/^[A-Z0-9]{4}$/', 'unique:branches,code'],
            'type' => 'required|in:head_office,state_office,branch',
            'parent_id' => 'nullable|integer|exists:branches,id',
            'address' => 'nullable|string',
            'state_id' => 'required|exists:states,id',
            'city_id' => 'required|exists:cities,id',
            'pincode' => 'nullable|string|max:10',
            'gst_no' => 'nullable|string|max:15',
            'fssai_no' => 'nullable|string|max:20',
            'phone' => 'nullable|string|max:15',
            'contact_email' => 'nullable|email|max:255',
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'opens_at' => ['nullable', 'date_format:H:i'],
            'closes_at' => ['nullable', 'date_format:H:i'],
            'is_accepting_orders' => ['boolean'],
        ]);

        $branch = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Branch created successfully.',
            'data' => new BranchResource($branch),
        ], 201);
    }

    public function show(Branch $branch): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Branch fetched.',
            'data' => new BranchResource($branch->load(['city', 'state', 'parent'])),
        ]);
    }

    public function update(Request $request, Branch $branch): JsonResponse
    {
        if ($request->filled('code')) {
            $request->merge(['code' => strtoupper($request->input('code'))]);
        }

        $request->merge([
            'opens_at' => $request->filled('opens_at') ? substr($request->input('opens_at'), 0, 5) : null,
            'closes_at' => $request->filled('closes_at') ? substr($request->input('closes_at'), 0, 5) : null,
        ]);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'code' => ['sometimes', 'required', 'string', 'size:4', 'regex:/^[A-Z0-9]{4}$/', 'unique:branches,code,'.$branch->id],
            'type' => 'sometimes|in:head_office,state_office,branch',
            'parent_id' => 'nullable|integer|exists:branches,id',
            'address' => 'nullable|string',
            'state_id' => 'sometimes|exists:states,id',
            'city_id' => 'sometimes|exists:cities,id',
            'pincode' => 'nullable|string|max:10',
            'gst_no' => 'nullable|string|max:15',
            'fssai_no' => 'nullable|string|max:20',
            'phone' => 'nullable|string|max:15',
            'contact_email' => 'nullable|email|max:255',
            'is_active' => 'boolean',
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'opens_at' => ['nullable', 'date_format:H:i'],
            'closes_at' => ['nullable', 'date_format:H:i'],
            'is_accepting_orders' => ['boolean'],
        ]);

        $branch = $this->service->update($branch, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Branch updated.',
            'data' => new BranchResource($branch),
        ]);
    }

    public function destroy(Branch $branch): JsonResponse
    {
        $this->service->delete($branch);

        return response()->json([
            'status' => true,
            'message' => 'Branch deleted.',
            'data' => [],
        ]);
    }

    public function toggleOrders(Branch $branch): JsonResponse
    {
        $branch->update(['is_accepting_orders' => ! $branch->is_accepting_orders]);

        return response()->json([
            'status' => true,
            'message' => $branch->is_accepting_orders ? 'Branch is now accepting orders.' : 'Branch has paused orders.',
            'data' => ['branch' => new BranchResource($branch->fresh())],
        ]);
    }
}
