<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Models\TenantDeliverySlot;
use App\Models\Tenant\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeliverySlotController extends Controller
{
    public function index(): JsonResponse
    {
        $slots = TenantDeliverySlot::orderBy('start_time')->get();

        // Annotate each slot with whether it's already referenced by orders.
        // Frontend uses this to lock the start/end fields during edit.
        $usedIds = Order::query()
            ->whereNotNull('delivery_slot_id')
            ->distinct()
            ->pluck('delivery_slot_id')
            ->all();
        $usedSet = array_flip($usedIds);

        $data = $slots->map(function ($slot) use ($usedSet) {
            $row = $slot->toArray();
            $row['is_locked'] = isset($usedSet[$slot->id]);
            return $row;
        });

        return response()->json(['status' => true, 'data' => $data]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'        => 'required|string|max:60',
            'start_time'  => 'required|date_format:H:i',
            'end_time'    => 'required|date_format:H:i|after:start_time',
            'cutoff_time' => 'nullable|date_format:H:i',
        ]);

        // Cutoff must be earlier than the slot start.
        if (! empty($data['cutoff_time']) && $data['cutoff_time'] >= $data['start_time']) {
            return response()->json([
                'status'  => false,
                'message' => 'Cutoff time must be earlier than the slot start time.',
            ], 422);
        }

        $slot = TenantDeliverySlot::create([
            'name'        => $data['name'],
            'start_time'  => $data['start_time'],
            'end_time'    => $data['end_time'],
            'cutoff_time' => $data['cutoff_time'] ?? null,
            'is_active'   => true,
        ]);

        return response()->json(['status' => true, 'data' => $slot], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $slot = TenantDeliverySlot::findOrFail($id);

        // Once an order has referenced this slot, its time window is frozen —
        // changing it would corrupt the historical meaning of those orders.
        $isUsed = Order::where('delivery_slot_id', $slot->id)->exists();

        $rules = [
            'name'        => 'sometimes|string|max:60',
            'cutoff_time' => 'nullable|date_format:H:i',
            'is_active'   => 'sometimes|boolean',
        ];

        if (! $isUsed) {
            $rules['start_time'] = 'sometimes|date_format:H:i';
            $rules['end_time']   = 'sometimes|date_format:H:i';
        }

        $data = $request->validate($rules);

        // Reject attempts to change start/end on a locked slot.
        if ($isUsed && ($request->has('start_time') || $request->has('end_time'))) {
            return response()->json([
                'status'  => false,
                'message' => 'Start and end times cannot be changed because this slot is already used by past orders. You can only change the name, cutoff, or active status.',
            ], 422);
        }

        // Resolve the cutoff that will end up on the row.
        $start = $data['start_time'] ?? $slot->start_time;
        $end   = $data['end_time']   ?? $slot->end_time;

        if ($end <= $start) {
            return response()->json([
                'status'  => false,
                'message' => 'End time must be after start time.',
            ], 422);
        }

        $resultingCutoff = array_key_exists('cutoff_time', $data)
            ? $data['cutoff_time']
            : $slot->cutoff_time;

        if ($resultingCutoff !== null && $resultingCutoff >= $start) {
            return response()->json([
                'status'  => false,
                'message' => 'Cutoff time must be earlier than the slot start time.',
            ], 422);
        }

        // Explicit null clears cutoff_time.
        if ($request->exists('cutoff_time') && $request->input('cutoff_time') === null) {
            $data['cutoff_time'] = null;
        }

        $slot->update($data);

        return response()->json(['status' => true, 'data' => $slot->fresh()]);
    }

    public function toggle(int $id): JsonResponse
    {
        $slot = TenantDeliverySlot::findOrFail($id);
        $slot->update(['is_active' => ! $slot->is_active]);

        return response()->json(['status' => true, 'data' => $slot]);
    }

    public function destroy(int $id): JsonResponse
    {
        $slot = TenantDeliverySlot::findOrFail($id);

        // Refuse to delete a slot that has order history.
        if (Order::where('delivery_slot_id', $slot->id)->exists()) {
            return response()->json([
                'status'  => false,
                'message' => 'This slot has been used by past orders and cannot be deleted. Mark it inactive instead.',
            ], 422);
        }

        $slot->delete();

        return response()->json(['status' => true]);
    }
}
