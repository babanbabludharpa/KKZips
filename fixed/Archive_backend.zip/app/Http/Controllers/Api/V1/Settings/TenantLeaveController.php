<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Models\TenantDeliverySlot;
use App\Models\TenantLeave;
use App\Models\TenantLeaveAuditLog;
use App\Services\V1\Tenant\TenantLeaveService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class TenantLeaveController extends Controller
{
    private const DATE_MODES = ['single', 'range', 'recurring'];

    public function __construct(private TenantLeaveService $service) {}

    public function index(Request $request): JsonResponse
    {
        $leaves = TenantLeave::query()
            ->when($request->query('status'), fn ($q, $s) => $q->where('status', $s))
            ->orderByDesc('start_date')
            ->paginate(50);

        return response()->json(['status' => true, 'data' => $leaves]);
    }

    public function preview(Request $request): JsonResponse
    {
        $shape = $request->validate([
            'title'           => 'required|string|max:120',
            'start_date'      => 'required|date',
            'end_date'        => 'required|date|after_or_equal:start_date',
            'branch_ids'      => 'nullable|array',
            'branch_ids.*'    => 'integer|exists:branches,id',
            'slot_ids'        => 'nullable|array',
            'slot_ids.*'      => 'integer|exists:tenant_delivery_slots,id',
            'reason'          => 'required|string|max:500',
            'recurrence_rule' => 'nullable|string|max:120',
        ]);

        $preview = $this->service->preview($shape);

        // Echo back the leave scope so the frontend can build a
        // delivery-board URL that reflects what the preview is about.
        return response()->json([
            'status' => true,
            'data'   => array_merge($preview, [
                'branch_ids' => $shape['branch_ids'] ?? null,   // null = all branches
                'slot_ids'   => $shape['slot_ids']   ?? null,   // null = all slots
                'date_from'  => $shape['start_date'],
                'date_to'    => $shape['end_date'],
            ]),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($request->user()->can('profile.leaves_edit'), 403);

        $data = $this->validateShape($request, /* isPreview */ false);
        $data['created_by'] = $request->user()->id;

        $result = $this->service->create($data, $request->user()->id);

        return response()->json([
            'status'  => true,
            'message' => 'Leave created.',
            'data'    => $result,
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        abort_unless($request->user()->can('profile.leaves_edit'), 403);

        $leave = TenantLeave::where('status', 'active')->findOrFail($id);
        $data  = $this->validateShape($request, false, /* partial */ true);

        $result = $this->service->update($leave, $data, $request->user()->id);

        return response()->json([
            'status'  => true,
            'message' => 'Leave updated.',
            'data'    => $result,
        ]);
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        abort_unless($request->user()->can('profile.leaves_edit'), 403);

        $leave  = TenantLeave::where('status', 'active')->findOrFail($id);
        $result = $this->service->cancel($leave, $request->user()->id);

        return response()->json([
            'status'  => true,
            'message' => 'Leave cancelled and affected deliveries restored.',
            'data'    => $result,
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $leave = TenantLeave::findOrFail($id);

        $audit = TenantLeaveAuditLog::where('leave_id', $leave->id)
            ->orderByDesc('created_at')->limit(20)->get();

        return response()->json([
            'status' => true,
            'data'   => ['leave' => $leave, 'audit' => $audit],
        ]);
    }

    // ── Shared validation + shape normalization ────────────────
    private function validateShape(Request $request, bool $isPreview, bool $partial = false): array
    {
        $required = $partial ? 'sometimes' : 'required';

        $rules = [
            'title'           => [$required, 'string', 'min:2', 'max:120'],
            'date_mode'       => [$required, 'in:single,range,recurring'],
            'start_date'      => [$required, 'date', 'after_or_equal:today'],
            'end_date'        => [$required, 'date'],
            'branch_ids'      => ['nullable', 'array'],
            'branch_ids.*'    => ['integer', 'exists:branches,id'],
            'slot_ids'        => ['nullable', 'array'],
            'slot_ids.*'      => ['integer', 'exists:tenant_delivery_slots,id'],
            'reason'          => [$required, 'string', 'min:3', 'max:500'],
            'recurrence_rule' => ['nullable', 'string', 'max:120'],
        ];

        $data = $request->validate($rules);

        // Cross-field validation on date_mode
        if (! isset($data['date_mode'])) {
            $data['date_mode'] = 'single';
        }

        $start = $data['start_date'] ?? null;
        $end   = $data['end_date']   ?? null;
        $rule  = $data['recurrence_rule'] ?? null;

        if ($start && $end) {
            $startD = \Carbon\CarbonImmutable::parse($start);
            $endD   = \Carbon\CarbonImmutable::parse($end);

            switch ($data['date_mode']) {
                case 'single':
                    if (! $startD->isSameDay($endD)) {
                        throw ValidationException::withMessages([
                            'end_date' => 'Single-day leave must have the same start and end date.',
                        ]);
                    }
                    if ($rule) {
                        throw ValidationException::withMessages([
                            'recurrence_rule' => 'Single-day leaves cannot have a recurrence.',
                        ]);
                    }
                    break;

                case 'range':
                    if ($endD->lt($startD)) {
                        throw ValidationException::withMessages([
                            'end_date' => 'End date must be on or after start date.',
                        ]);
                    }
                    if ($rule) {
                        throw ValidationException::withMessages([
                            'recurrence_rule' => 'One-off range leaves cannot have a recurrence.',
                        ]);
                    }
                    break;

                case 'recurring':
                    if ($endD->lte($startD)) {
                        throw ValidationException::withMessages([
                            'end_date' => 'Recurring leaves must span more than one day.',
                        ]);
                    }
                    if (! $rule) {
                        throw ValidationException::withMessages([
                            'recurrence_rule' => 'Pick a recurrence for a recurring leave.',
                        ]);
                    }
                    if ($startD->diffInMonths($endD) > 24) {
                        throw ValidationException::withMessages([
                            'end_date' => 'Recurring horizon cannot exceed 2 years.',
                        ]);
                    }
                    break;
            }
        }

        // Validate slot IDs are active (not just exist).
        if (! empty($data['slot_ids'])) {
            $activeSlotIds = TenantDeliverySlot::query()
                ->whereIn('id', $data['slot_ids'])
                ->where('is_active', true)
                ->pluck('id')
                ->all();
            $invalid = array_diff($data['slot_ids'], $activeSlotIds);
            if (! empty($invalid)) {
                throw ValidationException::withMessages([
                    'slot_ids' => 'One or more slots are invalid or inactive: '.implode(', ', $invalid),
                ]);
            }
        }

        // Null out empty arrays for consistency with json columns.
        if (empty($data['branch_ids'])) $data['branch_ids'] = null;
        if (empty($data['slot_ids']))   $data['slot_ids']   = null;

        // Recurrence: null for non-recurring.
        if (($data['date_mode'] ?? 'single') !== 'recurring') {
            $data['recurrence_rule'] = null;
        }

        return $data;
    }
}
