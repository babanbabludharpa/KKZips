<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\TenantProfileResource;
use App\Models\DeliveryInstruction;
use App\Models\TenantProfile;
use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class TenantProfileController extends Controller
{
    public function __construct(protected TenantProfileService $service) {}

    public function show(): JsonResponse
    {
        $profile = $this->service->getProfile();

        if (! $profile) {
            return response()->json(['status' => true, 'message' => 'No profile found', 'data' => null]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Tenant profile fetched',
            'data' => new TenantProfileResource($profile),
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'company_name' => 'required|string|max:255',
            'pan_no' => 'nullable|string|size:10|regex:/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/',

            'support_phone' => 'nullable|string|max:20',
            'support_email' => 'nullable|email|max:120',
            'support_hours' => 'nullable|string|max:100',

            'has_orders' => 'sometimes|boolean',
            'use_order_slots' => 'sometimes|boolean',
            'has_subscriptions' => 'sometimes|boolean',
            'has_wallet' => 'sometimes|boolean',

            'order_start_policy' => 'sometimes|in:next_day_only,same_day_slot_wise',
            'order_same_day_lead_time_minutes' => 'sometimes|integer|min:30|max:720',

            'slot_wise_cutoff_enabled' => 'sometimes|boolean',
            'slot_cutoff_offset_minutes' => 'sometimes|integer|min:15|max:720',

            'cod_enabled' => 'sometimes|boolean',
            'online_payment_enabled' => 'sometimes|boolean',
            'razorpay_key_id' => ['nullable', 'string', 'max:255', 'regex:/^rzp_(test|live)_/'],
            'razorpay_key_secret' => 'nullable|string|max:255',
            'razorpay_webhook_secret' => 'nullable|string|max:255',
            'razorpay_is_live' => 'sometimes|boolean',

            'pusher_app_id' => 'nullable|string|max:255',
            'pusher_key' => 'nullable|string|max:255',
            'pusher_secret' => 'nullable|string|max:255',
            'pusher_cluster' => 'nullable|string|max:255',

            'subscription_cutoff_time' => 'sometimes|string|in:'
                .'19:00,19:30,20:00,20:30,21:00,21:30,22:00,22:30,23:00,23:30',
            'subscription_cutoff_restrict_admin' => 'sometimes|boolean',
            'subscription_start_policy' => 'sometimes|in:next_day_only,same_day_slot_wise',
            'same_day_lead_time_minutes' => 'sometimes|integer|min:30|max:720',
            'rider_assignment_time' => ['sometimes', 'string', 'regex:/^([01]\d|2[0-3]):[0-5]\d$/'],
            'order_stock_check_enabled' => 'sometimes|boolean',
            'subscription_stock_check_enabled' => 'sometimes|boolean',

            'sms_username' => 'nullable|string|max:255',
            'sms_password' => 'nullable|string|max:255',
            'sms_sender_id' => ['nullable', 'string', 'regex:/^[A-Za-z0-9]{6}$/'],
            'sms_enabled' => 'sometimes|boolean',
            'sms_channel_enabled' => 'sometimes|boolean',

            'notification_channel_enabled' => 'sometimes|boolean',
            'whatsapp_channel_enabled' => 'sometimes|boolean',
            'whatsapp_api_key' => 'nullable|string|max:255',
            'whatsapp_phone_number' => ['nullable', 'string', 'regex:/^\+?[0-9]{10,15}$/'],
            'email_channel_enabled' => 'sometimes|boolean',

            'wallet_warning_limit' => 'sometimes|numeric|max:0',
            'wallet_suspension_limit' => 'sometimes|numeric|max:0',

            'delivery_note_min_days' => 'sometimes|integer|min:0|max:60',
            'delivery_note_max_days' => 'sometimes|integer|min:0|max:90|gte:delivery_note_min_days',
            'delivery_note_text' => 'nullable|string|max:255',
        ]);

        if (isset($validated['sms_sender_id'])) {
            $validated['sms_sender_id'] = strtoupper($validated['sms_sender_id']);
        }

        // ── Permission gates ────────────────────────────────────
        if ($this->submittedAny($request, ['pusher_app_id', 'pusher_key', 'pusher_secret', 'pusher_cluster'])
            && ! $request->user()->can('profile.pusher_edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify realtime notification settings.'], 403));
        }

        if (($this->submittedAny($request, ['razorpay_key_id', 'razorpay_key_secret', 'razorpay_webhook_secret'])
             || $request->has('razorpay_is_live'))
            && ! $request->user()->can('profile.razorpay_edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify payment gateway settings.'], 403));
        }

        if (($this->submittedAny($request, ['sms_username', 'sms_password', 'sms_sender_id'])
             || $request->has('sms_enabled')
             || $request->has('sms_channel_enabled'))
            && ! $request->user()->can('profile.sms_edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify SMS gateway settings.'], 403));
        }

        if (($this->submittedAny($request, ['whatsapp_api_key', 'whatsapp_phone_number'])
             || $request->has('whatsapp_channel_enabled'))
            && ! $request->user()->can('profile.sms_edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify WhatsApp settings.'], 403));
        }

        if ($request->has('notification_channel_enabled') && ! $request->user()->can('profile.pusher_edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify notification settings.'], 403));
        }

        if ($request->has('email_channel_enabled') && ! $request->user()->can('profile.edit')) {
            abort(response()->json(['status' => false, 'message' => 'You do not have permission to modify email channel settings.'], 403));
        }

        if (! $request->user()->can('profile.stock_check_edit')) {
            unset($validated['order_stock_check_enabled'], $validated['subscription_stock_check_enabled']);
        }

        if (! $request->user()->can('profile.cutoff_edit')) {
            unset(
                $validated['subscription_cutoff_restrict_admin'],
                $validated['subscription_start_policy'],
                $validated['same_day_lead_time_minutes'],
                $validated['rider_assignment_time'],
                $validated['slot_wise_cutoff_enabled'],
                $validated['slot_cutoff_offset_minutes'],
            );
        }

        if (! $request->user()->can('profile.order_slots_edit')) {
            unset(
                $validated['use_order_slots'],
                $validated['order_start_policy'],
                $validated['order_same_day_lead_time_minutes'],
            );
        }

        if (! $request->user()->can('profile.modules_edit')) {
            unset($validated['has_orders'], $validated['has_subscriptions'], $validated['has_wallet']);
        }

        foreach (['wallet_warning_limit', 'wallet_suspension_limit'] as $f) {
            if (array_key_exists($f, $validated)) {
                $validated[$f] = (int) round($validated[$f] * 100);
            }
        }

        $existing = $this->service->getProfile();

        $this->assertAtLeastOnePaymentMethod($validated, $existing);
        $this->assertPusherConfigComplete($validated, $existing);
        $this->assertRazorpayConfigComplete($validated, $existing);
        $this->assertSmsCredentialsComplete($validated, $existing);
        $this->assertCutoffRestrictionIsConsistent($validated, $existing);
        $this->assertSchedulingConfigIsConsistent($validated, $existing);
        $this->assertOrderSlotConfigIsConsistent($validated, $existing);
        $this->assertWalletLimitsAreOrdered($validated, $existing);

        $profile = $this->service->upsert($validated);

        return response()->json([
            'status' => true,
            'message' => 'Tenant profile updated',
            'data' => new TenantProfileResource($profile),
        ]);
    }

    public function uploadLogo(Request $request): JsonResponse
    {
        $request->validate(['logo' => 'required|image|mimes:jpeg,png,jpg,webp|max:2048']);

        $profile = TenantProfile::first();
        if (! $profile) {
            return response()->json([
                'status' => false,
                'message' => 'Save company profile before uploading a logo',
                'data' => null,
            ], 422);
        }

        $filename = $this->service->uploadLogo($request->file('logo'));
        $profile->update(['logo' => $filename]);

        return response()->json([
            'status' => true,
            'message' => 'Logo uploaded',
            'data' => [
                'logo' => $filename,
                'logo_url' => $this->service->getLogoUrl($filename),
            ],
        ]);
    }

    // ── Delivery instructions ──────────────────────────────────
    public function instructions(): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => DeliveryInstruction::where('tenant_id', tenant()->getKey())
                ->orderBy('sort_order')->orderBy('id')->get(),
        ]);
    }

    public function createInstruction(Request $request): JsonResponse
    {
        abort_unless($request->user()->can('profile.edit'), 403);

        $data = $request->validate([
            'label' => 'required|string|max:120',
            'code'  => 'nullable|string|max:60|regex:/^[a-z0-9_]+$/',
        ]);

        $data['tenant_id'] = tenant()->getKey();

        // ★ Guarded: 'code' is optional and may not exist in the validated
        //   array when the client omits it. Derive it from the label.
        $code = $data['code'] ?? null;
        if (! $code) {
            $code = Str::slug($data['label'] ?? '', '_');
        }
        $data['code'] = $code;

        // Duplicate-code guard scoped to the current tenant.
        $exists = DeliveryInstruction::where('tenant_id', $data['tenant_id'])
            ->where('code', $data['code'])
            ->exists();

        if ($exists) {
            return response()->json([
                'status'  => false,
                'message' => 'An instruction with a similar name already exists.',
            ], 422);
        }

        $inst = DeliveryInstruction::create($data);

        return response()->json(['status' => true, 'data' => $inst], 201);
    }

    public function toggleInstruction(Request $request, int $id): JsonResponse
    {
        abort_unless($request->user()->can('profile.edit'), 403);

        $inst = DeliveryInstruction::where('tenant_id', tenant()->getKey())->findOrFail($id);
        $inst->update(['is_active' => ! $inst->is_active]);

        return response()->json(['status' => true, 'data' => $inst]);
    }

    // ── Assert helpers ─────────────────────────────────────────
    private function submittedAny(Request $request, array $fields): bool
    {
        foreach ($fields as $f) {
            if (filled($request->input($f))) return true;
        }
        return false;
    }

    private function assertAtLeastOnePaymentMethod(array $v, ?TenantProfile $existing): void
    {
        $codEnabled = $v['cod_enabled'] ?? $existing?->cod_enabled ?? false;
        $onlineEnabled = $v['online_payment_enabled'] ?? $existing?->online_payment_enabled ?? true;
        if (! $codEnabled && ! $onlineEnabled) {
            abort(response()->json(['status' => false, 'message' => 'At least one payment method must remain enabled.'], 422));
        }
    }

    private function assertPusherConfigComplete(array $v, ?TenantProfile $existing): void
    {
        $appId = $v['pusher_app_id'] ?? $existing?->pusher_app_id;
        $key = $v['pusher_key'] ?? $existing?->pusher_key;
        $secret = $v['pusher_secret'] ?? $existing?->pusher_secret;
        $cluster = $v['pusher_cluster'] ?? $existing?->pusher_cluster;

        $anySet = $appId || $key || $secret || $cluster;
        $allSet = $appId && $key && $secret && $cluster;

        if ($anySet && ! $allSet) {
            abort(response()->json([
                'status' => false,
                'message' => 'Pusher App ID, Key, Secret, and Cluster must all be set together.',
            ], 422));
        }
    }

    private function assertRazorpayConfigComplete(array $v, ?TenantProfile $existing): void
    {
        $keyId = $v['razorpay_key_id'] ?? $existing?->razorpay_key_id;
        $keySecret = $v['razorpay_key_secret'] ?? $existing?->razorpay_key_secret;
        $webhookSecret = $v['razorpay_webhook_secret'] ?? $existing?->razorpay_webhook_secret;
        $isLive = $v['razorpay_is_live'] ?? $existing?->razorpay_is_live ?? false;

        $anySet = $keyId || $keySecret || $webhookSecret;
        $allSet = $keyId && $keySecret && $webhookSecret;
        if ($anySet && ! $allSet) {
            abort(response()->json(['status' => false, 'message' => 'Razorpay Key ID, Key Secret, and Webhook Secret must all be set together.'], 422));
        }

        if ($keyId) {
            $isLivePrefixed = str_starts_with($keyId, 'rzp_live_');
            $isTestPrefixed = str_starts_with($keyId, 'rzp_test_');
            if ($isLive && ! $isLivePrefixed) {
                abort(response()->json(['status' => false, 'message' => 'Live mode is enabled but the Key ID is not a live key (rzp_live_...).'], 422));
            }
            if (! $isLive && ! $isTestPrefixed) {
                abort(response()->json(['status' => false, 'message' => 'Test mode is enabled but the Key ID is not a test key (rzp_test_...).'], 422));
            }
        }
    }

    /**
     * Only enforces the all-or-nothing credentials rule. Channel toggles
     * are user preferences and are NOT blocked by missing credentials.
     */
    private function assertSmsCredentialsComplete(array $v, ?TenantProfile $existing): void
    {
        $u = $v['sms_username'] ?? $existing?->sms_username;
        $p = $v['sms_password'] ?? $existing?->sms_password;
        $s = $v['sms_sender_id'] ?? $existing?->sms_sender_id;

        $anySet = $u || $p || $s;
        $allSet = $u && $p && $s;
        if ($anySet && ! $allSet) {
            abort(response()->json([
                'status' => false,
                'message' => 'SMS Username, Password, and Sender ID must all be set together.',
            ], 422));
        }
    }

    private function assertCutoffRestrictionIsConsistent(array $v, ?TenantProfile $existing): void
    {
        $restrict = $v['subscription_cutoff_restrict_admin'] ?? $existing?->subscription_cutoff_restrict_admin ?? false;
        $cutoff = $v['subscription_cutoff_time'] ?? $existing?->subscription_cutoff_time ?? null;
        if ($restrict && ! $cutoff) {
            abort(response()->json(['status' => false, 'message' => 'Set a subscription cutoff time before restricting admin-panel actions to it.'], 422));
        }
    }

    private function assertSchedulingConfigIsConsistent(array $v, ?TenantProfile $existing): void
    {
        $policy = $v['subscription_start_policy'] ?? $existing?->subscription_start_policy ?? 'next_day_only';
        if ($policy === 'same_day_slot_wise') {
            $lead = $v['same_day_lead_time_minutes'] ?? $existing?->same_day_lead_time_minutes ?? 120;
            if ($lead < 30) {
                abort(response()->json(['status' => false, 'message' => 'Same-day lead time must be at least 30 minutes.'], 422));
            }
        }
    }

    private function assertOrderSlotConfigIsConsistent(array $v, ?TenantProfile $existing): void
    {
        $hasOrders = $v['has_orders'] ?? $existing?->has_orders ?? true;
        $useSlots = $v['use_order_slots'] ?? $existing?->use_order_slots ?? false;

        if ($useSlots && ! $hasOrders) {
            abort(response()->json(['status' => false, 'message' => 'Order slots can only be enabled when the Orders module is on.'], 422));
        }

        if ($useSlots) {
            $policy = $v['order_start_policy'] ?? $existing?->order_start_policy ?? 'next_day_only';
            if ($policy === 'same_day_slot_wise') {
                $lead = $v['order_same_day_lead_time_minutes']
                    ?? $existing?->order_same_day_lead_time_minutes ?? 120;
                if ($lead < 30) {
                    abort(response()->json(['status' => false, 'message' => 'Order same-day lead time must be at least 30 minutes.'], 422));
                }
            }
        }

        $slotCutoff = $v['slot_wise_cutoff_enabled'] ?? $existing?->slot_wise_cutoff_enabled ?? false;
        $offset = $v['slot_cutoff_offset_minutes'] ?? $existing?->slot_cutoff_offset_minutes ?? 120;
        if ($slotCutoff && $offset < 15) {
            abort(response()->json(['status' => false, 'message' => 'Slot cutoff must be at least 15 minutes before the slot start.'], 422));
        }
    }

    private function assertWalletLimitsAreOrdered(array $v, ?TenantProfile $existing): void
    {
        $warning = $v['wallet_warning_limit'] ?? $existing?->wallet_warning_limit ?? -50000;
        $suspension = $v['wallet_suspension_limit'] ?? $existing?->wallet_suspension_limit ?? -500000;

        if ($warning >= 0 || $suspension >= 0) {
            abort(response()->json(['status' => false, 'message' => 'Wallet warning and suspension limits must be zero or negative.'], 422));
        }
        if ($suspension >= $warning) {
            abort(response()->json(['status' => false, 'message' => 'Wallet suspension limit must be more negative than the warning limit.'], 422));
        }
    }
}
