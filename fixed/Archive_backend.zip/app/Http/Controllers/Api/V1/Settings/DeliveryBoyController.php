<?php

namespace App\Http\Controllers\Api\V1\Settings;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Settings\StoreDeliveryBoyRequest;
use App\Http\Resources\V1\DeliveryBoyResource;
use App\Services\V1\Settings\DeliveryBoyService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class DeliveryBoyController extends Controller
{
    public function __construct(protected DeliveryBoyService $service) {}

    public function index(Request $request): Response
    {
        $request->validate([
            'search'    => 'nullable|string|max:255',
            'branch_id' => 'nullable|integer',
            'per_page'  => 'nullable|integer|min:10|max:500',
            'export'    => 'nullable|in:csv',
        ]);

        $filters = $request->only(['search', 'branch_id', 'per_page']);

        if ($request->query('export') === 'csv') {
            return $this->service->exportCsv($filters);
        }

        $riders = $this->service->getAll($filters);

        return response()->json([
            'status'  => true,
            'message' => 'Delivery boys retrieved successfully.',
            'data'    => [
                'users' => DeliveryBoyResource::collection($riders)->resolve(),
                'meta'  => [
                    'current_page' => $riders->currentPage(),
                    'last_page'    => $riders->lastPage(),
                    'per_page'     => $riders->perPage(),
                    'total'        => $riders->total(),
                    'from'         => $riders->firstItem(),
                    'to'           => $riders->lastItem(),
                ],
            ],
        ]);
    }

    public function store(StoreDeliveryBoyRequest $request): JsonResponse
    {
        $rider = $this->service->create($request->validated());

        return response()->json([
            'status'  => true,
            'message' => 'Delivery Boy created successfully.',
            'data'    => ['user' => new DeliveryBoyResource($rider)],
        ], 201);
    }

    public function update(StoreDeliveryBoyRequest $request, int $id): JsonResponse
    {
        $rider = $this->service->update($id, $request->validated());

        return response()->json([
            'status'  => true,
            'message' => 'Delivery Boy updated successfully.',
            'data'    => ['user' => new DeliveryBoyResource($rider)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $this->service->delete($id);

        return response()->json([
            'status'  => true,
            'message' => 'Delivery Boy deleted successfully.',
            'data'    => [],
        ]);
    }

    public function document(int $id, string $field): Response
    {
        return $this->service->documentResponse($id, $field);
    }
}
