<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Models\Tenant\Customer;
use App\Models\Tenant\WalletTopup;
use App\Services\V1\Tenant\TenantProfileService;
use App\Services\V1\Wallet\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class CustomerPaymentLinkController extends Controller
{
    public function __construct(
        private WalletService $walletService,
        private TenantProfileService $tenantProfileService,
    ) {}

    /**
     * Admin creates a payment link for a specific amount.
     * No Razorpay order is created yet — that happens when the customer opens
     * the link and clicks "Pay", so the order reflects the freshest amount.
     */
    public function create(Request $request, int $customer): JsonResponse
    {
        $data = $request->validate([
            'amount' => 'required|numeric|min:1',
        ]);

        $token = Str::random(48);

        DB::table('payment_links')->insert([
            'token'       => $token,
            'customer_id' => $customer,
            'amount'      => $data['amount'],
            'status'      => 'pending',
            'expires_at'  => now()->addDays(7),
            'created_by'  => $request->user()->id,
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);

        return response()->json([
            'status' => true,
            'data'   => ['token' => $token],
        ]);
    }

    /**
     * Public: fetch link metadata for display.
     */
    public function show(string $token): JsonResponse
    {
        $link = DB::table('payment_links')->where('token', $token)->first();
        if (! $link) {
            return response()->json(['status' => false, 'message' => 'Link not found.'], 404);
        }
        if ($link->status !== 'pending') {
            return response()->json(['status' => false, 'message' => 'Link already used or cancelled.'], 410);
        }
        if ($link->expires_at && now()->greaterThan($link->expires_at)) {
            return response()->json(['status' => false, 'message' => 'Link expired.'], 410);
        }

        $customer = Customer::find($link->customer_id);
        if (! $customer) {
            return response()->json(['status' => false, 'message' => 'Customer not found.'], 404);
        }

        $address = $customer->defaultAddress;
        $balance = (float) (DB::table('customer_wallets')->where('customer_id', $customer->id)->value('balance') ?? 0);
        $profile = \App\Models\TenantProfile::first();

        return response()->json([
            'status' => true,
            'data' => [
                'tenant_name'      => $profile?->company_name ?? 'Store',
                'tenant_address'   => trim(implode(', ', array_filter([
                    $profile?->support_phone,
                    $profile?->support_email,
                ]))),
                'customer_name'    => $customer->name,
                'customer_phone'   => $customer->phone,
                'customer_address' => $address ? trim(implode(', ', array_filter([
                    $address->address_line1,
                    $address->city,
                ]))) : null,
                'amount'           => (float) $link->amount,
                'balance'          => $balance,
                'razorpay_ready'   => $this->tenantProfileService->razorpayIsConfigured(),
            ],
        ]);
    }

    /**
     * Public: initiate a Razorpay payment for this link.
     * Creates a WalletTopup via the existing service, then a Razorpay order.
     */
    public function initiate(string $token): JsonResponse
    {
        $link = DB::table('payment_links')->where('token', $token)->first();
        if (! $link || $link->status !== 'pending') {
            return response()->json(['status' => false, 'message' => 'Invalid or already-used link.'], 410);
        }
        if ($link->expires_at && now()->greaterThan($link->expires_at)) {
            return response()->json(['status' => false, 'message' => 'Link expired.'], 410);
        }

        if (! $this->tenantProfileService->razorpayIsConfigured()) {
            return response()->json(['status' => false, 'message' => 'Online payment is not configured for this store.'], 422);
        }

        $customer = Customer::find($link->customer_id);
        if (! $customer) {
            return response()->json(['status' => false, 'message' => 'Customer not found.'], 404);
        }

        try {
            // Reuse the exact same flow the mobile app uses for wallet top-up.
            $data = $this->walletService->initiateTopup($customer, (float) $link->amount);

            // Attach the created WalletTopup to this payment link.
            DB::table('payment_links')->where('id', $link->id)->update([
                'wallet_topup_id' => $data['wallet_topup_id'] ?? null,
                'updated_at'      => now(),
            ]);

            return response()->json(['status' => true, 'data' => $data], 201);
        } catch (\Throwable $e) {
            Log::error('Public payment link initiate failed', [
                'token' => $token,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'status'  => false,
                'message' => $e->getMessage() ?: 'Could not initiate payment.',
            ], 422);
        }
    }

    /**
     * Public: verify the Razorpay signature and credit the wallet.
     * Reuses WalletService::verifyAndCredit so the audit trail and idempotency
     * behave exactly like a normal app top-up.
     */
    public function confirm(Request $request, string $token): JsonResponse
    {
        $data = $request->validate([
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature'  => 'required|string',
        ]);

        $link = DB::table('payment_links')->where('token', $token)->first();
        if (! $link) {
            return response()->json(['status' => false, 'message' => 'Invalid link.'], 404);
        }
        if (! $link->wallet_topup_id) {
            return response()->json(['status' => false, 'message' => 'Payment was not initiated for this link.'], 422);
        }

        $topup = WalletTopup::find($link->wallet_topup_id);
        if (! $topup) {
            return response()->json(['status' => false, 'message' => 'Topup record not found.'], 404);
        }

        if ($topup->status === 'paid') {
            // Already confirmed — mark the link paid too, and return success.
            DB::table('payment_links')->where('id', $link->id)->update([
                'status'     => 'paid',
                'paid_at'    => now(),
                'updated_at' => now(),
            ]);
            return response()->json(['status' => true, 'message' => 'Payment already confirmed.']);
        }

        try {
            $ok = $this->walletService->verifyAndCredit(
                $topup,
                $data['razorpay_payment_id'],
                $data['razorpay_signature'],
            );

            if (! $ok) {
                return response()->json(['status' => false, 'message' => 'Payment verification failed.'], 422);
            }

            DB::table('payment_links')->where('id', $link->id)->update([
                'status'     => 'paid',
                'paid_at'    => now(),
                'updated_at' => now(),
            ]);

            return response()->json(['status' => true, 'message' => 'Payment verified. Wallet credited.']);
        } catch (\Throwable $e) {
            Log::error('Public payment link confirm failed', [
                'token' => $token,
                'topup_id' => $topup->id,
                'error' => $e->getMessage(),
            ]);
            return response()->json(['status' => false, 'message' => 'Payment verification failed.'], 422);
        }
    }
}
