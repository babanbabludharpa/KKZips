<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\ProductResource;
use App\Models\Product;
use App\Services\V1\Masters\ProductService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function __construct(protected ProductService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'category_id' => 'nullable|integer|exists:categories,id',
    'is_active' => 'nullable|in:0,1,true,false',
    'is_gift' => 'nullable|in:0,1,true,false',
    'include_gifts' => 'nullable|in:0,1,true,false',
            'per_page' => 'nullable|integer|min:10|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $products = $this->service->getAll(
            $request->only(['search', 'category_id', 'is_active', 'is_gift', 'include_gifts', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Products fetched.',
            'data' => ProductResource::collection($products)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'description' => ['nullable', 'string'],
            'is_active' => ['boolean'],
        ]);

        $product = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Product created.',
            'data' => ['product' => new ProductResource($product)],
        ], 201);
    }

    public function show(int $id): JsonResponse
    {
        $product = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'Product fetched.',
            'data' => ['product' => new ProductResource($product)],
        ]);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:150'],
            'category_id' => ['sometimes', 'integer', 'exists:categories,id'],
            'description' => ['nullable', 'string'],
            'is_active' => ['boolean'],
        ]);

        $product = $this->service->update($product, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Product updated.',
            'data' => ['product' => new ProductResource($product)],
        ]);
    }

    public function destroy(Product $product): JsonResponse
    {
        $this->service->delete($product);

        return response()->json([
            'status' => true,
            'message' => 'Product deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Product $product): JsonResponse
    {
        $product = $this->service->toggleActive($product);

        return response()->json([
            'status' => true,
            'message' => 'Product status updated.',
            'data' => ['product' => new ProductResource($product)],
        ]);
    }
}
