<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\CategoryResource;
use App\Models\Category;
use App\Services\V1\Masters\CategoryService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function __construct(protected CategoryService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
            'per_page' => 'nullable|integer|min:10|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $categories = $this->service->getAll(
            $request->only(['search', 'is_active', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Categories fetched.',
            'data' => CategoryResource::collection($categories)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string'],
            'is_active' => ['boolean'],
            'image' => ['nullable', 'image', 'max:2048'], // 2MB
        ]);

        $category = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Category created.',
            'data' => ['category' => new CategoryResource($category)],
        ], 201);
    }

    public function show(Category $category): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Category fetched.',
            'data' => ['category' => new CategoryResource($category)],
        ]);
    }

    public function update(Request $request, Category $category): JsonResponse
    {
        // Frontend sends this as POST + _method=PUT (method spoofing) so
        // PHP actually populates $_FILES — a real PUT with a multipart
        // body is never parsed by PHP and the image would silently
        // vanish. This validate() call is unaffected either way.
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'description' => ['nullable', 'string'],
            'is_active' => ['boolean'],
            'image' => ['nullable', 'image', 'max:2048'],
        ]);

        $category = $this->service->update($category, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Category updated.',
            'data' => ['category' => new CategoryResource($category)],
        ]);
    }

    public function destroy(Category $category): JsonResponse
    {
        $this->service->delete($category);

        return response()->json([
            'status' => true,
            'message' => 'Category deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Category $category): JsonResponse
    {
        $category = $this->service->toggleActive($category);

        return response()->json([
            'status' => true,
            'message' => 'Category status updated.',
            'data' => ['category' => new CategoryResource($category)],
        ]);
    }
}
