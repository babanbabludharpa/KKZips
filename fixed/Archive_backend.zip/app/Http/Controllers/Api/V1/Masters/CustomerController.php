<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\CustomerResource;
use App\Services\V1\Masters\CustomerService;
use App\Models\Tenant\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function __construct(protected CustomerService $service) {}

    public function index(Request $request): JsonResponse|StreamedResponse
    {
        $request->validate([
            'search'    => 'nullable|string|max:255',
            'status'    => 'nullable|in:active,inactive,suspended',
            'from_date' => 'nullable|date',
            'to_date'   => 'nullable|date|after_or_equal:from_date',
            'per_page'  => 'nullable|integer|min:10|max:100',
            'sort_key'  => 'nullable|string|max:50',
            'sort_dir'  => 'nullable|in:asc,desc',
            'export'    => 'nullable|in:csv',
        ]);

        // Customers are tenant-wide identities. Branch scoping is a property
        // of the address, not the customer. No forced branch filter is applied.
        $params = $request->all();

        if ($request->export === 'csv') {
            return $this->service->customersCsv($params);
        }

        $data = $this->service->customersList360($params);

        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'           => ['required', 'string', 'max:255'],
            'email'          => ['required', 'email', 'max:255', 'unique:customers,email'],
            'phone'          => ['nullable', 'string', 'max:20'],
            'password'       => ['required', 'string', 'min:8', 'max:72', 'confirmed'],
            'status'         => ['nullable', 'in:active,inactive,suspended'],
            'phone_verified' => ['boolean'],
            'email_verified' => ['boolean'],
        ]);

        $customer = $this->service->create($validated);

        return response()->json([
            'status'  => 'success',
            'message' => 'Customer created.',
            'data'    => new CustomerResource($customer),
        ], 201);
    }

    public function update(Request $request, int $customer): JsonResponse
    {
        $validated = $request->validate([
            'name'           => ['sometimes', 'string', 'max:255'],
            'email'          => ['sometimes', 'email', 'max:255'],
            'phone'          => ['sometimes', 'nullable', 'string', 'max:20'],
            'status'         => ['sometimes', 'in:active,inactive,suspended'],
            'phone_verified' => ['boolean'],
            'email_verified' => ['boolean'],
        ]);

        $updated = $this->service->update($customer, $validated);

        return response()->json([
            'status'  => 'success',
            'message' => 'Customer updated.',
            'data'    => new CustomerResource($updated),
        ]);
    }

    public function resetPassword(Request $request, int $customer): JsonResponse
    {
        $request->validate([
            'password' => ['required', 'string', 'min:8', 'max:72', 'confirmed'],
        ]);

        $this->service->resetPassword($customer, $request->password);

        return response()->json([
            'status'  => 'success',
            'message' => 'Password reset.',
            'data'    => [],
        ]);
    }

    public function updateStatus(Request $request, int $customer): JsonResponse
    {
        $request->validate([
            'status' => 'required|in:active,inactive,suspended',
        ]);

        $updated = $this->service->updateStatus($customer, $request->status);

        return response()->json([
            'status' => 'success',
            'data'   => new CustomerResource($updated),
        ]);
    }

    public function destroy(Request $request, int $customer): JsonResponse
    {
        $this->service->delete($customer);

        return response()->json([
            'status'  => 'success',
            'message' => 'Customer deleted.',
            'data'    => [],
        ]);
    }

    public function addresses(int $customer): JsonResponse
    {
        $addresses = $this->service->addressesForCustomer($customer);

        return response()->json(['status' => 'success', 'data' => $addresses]);
    }

        public function profile(int $customer)
    {
        $data = $this->service->getProfile360($customer);
        return response()->json(['status' => 'success', 'data' => $data]);
    }

    public function updateSettings(Request $request, int $customer)
    {
        $validated = $request->validate([
            'dnd' => 'sometimes|boolean',
            'warning_limit' => 'nullable|numeric',
            'suspension_limit' => 'nullable|numeric',
        ]);

        $c = \App\Models\Tenant\Customer::findOrFail($customer);
        $c->update($validated);

        return response()->json(['status' => 'success', 'data' => $c]);
    }

    public function addNote(Request $request, int $customer)
    {
        $request->validate(['note' => 'required|string']);
        $note = \App\Models\CustomerNote::create([
            'customer_id' => $customer,
            'added_by' => $request->user()->id,
            'note' => $request->note,
        ]);
        return response()->json(['status' => 'success', 'data' => $note]);
    }

        public function updateProfile(Request $request, int $customer)
    {
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|max:255|unique:customers,email,' . $customer,
            'dnd' => 'sometimes|boolean',
            'warning_limit' => 'nullable|numeric',
            'suspension_limit' => 'nullable|numeric',
        ]);

        $c = \App\Models\Tenant\Customer::findOrFail($customer);
        $c->update($validated);

        return response()->json(['status' => 'success', 'data' => $c]);
    }

    public function storeAddress(Request $request, int $customer)
    {
        $validated = $request->validate([
            'label' => 'required|string|max:50',
            'address_line1' => 'required|string',
            'address_line2' => 'nullable|string',
            'city' => 'required|string',
            'state' => 'required|string',
            'pincode' => 'required|string',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'is_default' => 'boolean',
        ]);

        $validated['customer_id'] = $customer;
        
        // If this is the first address or explicitly set as default, clear other defaults
        if (!empty($validated['is_default'])) {
            \App\Models\Tenant\CustomerAddress::where('customer_id', $customer)->update(['is_default' => false]);
        }

        $addr = \App\Models\Tenant\CustomerAddress::create($validated);

        return response()->json(['status' => 'success', 'data' => $addr]);
    }

    public function transactions(Request $request, int $customer)
    {
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);

        $withDelta = \Illuminate\Support\Facades\DB::table('wallet_transactions as wt')
            ->where('wt.customer_id', $customer)
            ->select([
                'wt.*',
                \Illuminate\Support\Facades\DB::raw(
                    'wt.balance_after - COALESCE(LAG(wt.balance_after) OVER (PARTITION BY wt.customer_id ORDER BY wt.created_at, wt.id), 0) as signed_delta'
                ),
            ]);

        $transactions = \Illuminate\Support\Facades\DB::query()
            ->fromSub($withDelta, 'wt')
            ->orderByDesc('wt.created_at')
            ->orderByDesc('wt.id')
            ->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => $transactions->items(),
            'meta' => [
                'current_page' => $transactions->currentPage(),
                'last_page' => $transactions->lastPage(),
                'per_page' => $transactions->perPage(),
                'total' => $transactions->total(),
            ],
        ]);
    }

    public function deliveries(Request $request, int $customer)
    {
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);

        $subscriptionOccurrences = \Illuminate\Support\Facades\DB::table('subscription_occurrences as so')
            ->join('subscription_items as si', 'si.id', '=', 'so.subscription_item_id')
            ->join('subscriptions as s', 's.id', '=', 'si.subscription_id')
            ->leftJoin('product_variants as pv', 'pv.id', '=', 'si.product_variant_id')
            ->leftJoin('products as p', 'p.id', '=', 'pv.product_id')
            ->where('s.customer_id', $customer)
            ->whereIn('so.status', ['delivered', 'out_for_delivery', 'not_delivered', 'holiday_skipped', 'cancelled'])
            ->select(
                'so.id',
                'so.occurrence_date as delivery_date',
                'so.status',
                'so.qty',
                'so.unit_price_snapshot as rate',
                \Illuminate\Support\Facades\DB::raw("'Subscription' as type"),
                \Illuminate\Support\Facades\DB::raw("CONCAT(p.name, ' (', pv.sku, ')') as product_name")
            )
            ->orderByDesc('so.occurrence_date');

        $orders = \Illuminate\Support\Facades\DB::table('orders')
            ->where('customer_id', $customer)
            ->whereIn('status', ['delivered', 'out_for_delivery', 'cancelled'])
            ->select(
                'id',
                'created_at as delivery_date',
                'status',
                \Illuminate\Support\Facades\DB::raw('1 as qty'),
                'total as rate',
                \Illuminate\Support\Facades\DB::raw("'Order' as type"),
                \Illuminate\Support\Facades\DB::raw("CONCAT('Order #', order_number) as product_name")
            );

        $union = $subscriptionOccurrences->unionAll($orders);

        $paginated = \Illuminate\Support\Facades\DB::table(\Illuminate\Support\Facades\DB::raw("({$union->toSql()}) as deliveries"))
            ->mergeBindings($union)
            ->orderByDesc('delivery_date')
            ->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => $paginated->items(),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    public function subscriptions(Request $request, int $customer)
    {
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);

        $subs = \App\Models\Subscription::with([
                'items.productVariant.product',
                'items.slot',
                'deliveryInstruction',
            ])
            ->where('customer_id', $customer)
            ->orderByDesc('created_at')
            ->paginate($perPage);

        $data = collect($subs->items())->map(function ($sub) {
            $firstItem = $sub->items->first();
            $productName = $firstItem?->productVariant?->product?->name ?? 'Unknown Product';
            $variantName = $firstItem?->productVariant?->sku ?? '';
            $slotName = $firstItem?->slot ? "{$firstItem->slot->name} ({$firstItem->slot->start_time})" : '—';

            $pattern = '1 Unit | Everyday';
            if ($firstItem) {
                $qty = $firstItem->default_qty;
                $pattern = match ($firstItem->schedule_type) {
                    'daily' => "{$qty} Unit | Everyday",
                    'alternate' => "{$qty} Unit | Alternate",
                    'weekly' => "{$qty} Unit | Weekly",
                    'custom_days' => "{$qty} Unit | Custom Days",
                    default => "{$qty} Unit | {$firstItem->schedule_type}",
                };
            }

            return [
                'id' => $sub->id,
                'product' => $productName . ($variantName ? " ($variantName)" : ''),
                'schedule' => $pattern,
                'duration' => \Carbon\Carbon::parse($sub->start_date)->format('jS M, Y') . ' Onwards',
                'time' => $slotName,
                'status' => $sub->status,
                'auto_renew' => (bool) $sub->auto_renew,
                'delivery_instruction_id' => $sub->delivery_instruction_id,
                'delivery_instruction' => $sub->deliveryInstruction?->label,
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $data,
            'meta' => [
                'current_page' => $subs->currentPage(),
                'last_page' => $subs->lastPage(),
                'per_page' => $subs->perPage(),
                'total' => $subs->total(),
            ],
        ]);
    }

    public function bills(Request $request, int $customer)
    {
        $transactions = \Illuminate\Support\Facades\DB::table('wallet_transactions')
            ->where('customer_id', $customer)
            ->orderBy('created_at')
            ->get();

        $months = [];
        foreach ($transactions as $t) {
            $monthKey = \Carbon\Carbon::parse($t->created_at)->format('M-Y');
            if (! isset($months[$monthKey])) {
                $months[$monthKey] = [
                    'month' => $monthKey,
                    'opening_balance' => 0,
                    'amount' => 0,
                    'payment_credit' => 0,
                    'refund_cancellation' => 0,
                ];
            }
            $amount = (float) $t->amount;
            if (in_array($t->type, ['deposit', 'refund'])) {
                $months[$monthKey]['payment_credit'] += abs($amount);
                if ($t->type === 'refund') $months[$monthKey]['refund_cancellation'] += abs($amount);
            } else {
                $months[$monthKey]['amount'] += abs($amount);
            }
        }

        $sortedMonths = array_keys($months);
        usort($sortedMonths, fn ($a, $b) => strtotime("01 {$a}") <=> strtotime("01 {$b}"));

        $running = 0;
        $result = [];
        foreach ($sortedMonths as $monthKey) {
            $m = $months[$monthKey];
            $m['opening_balance'] = $running;
            $closing = $m['opening_balance'] + $m['payment_credit'] - $m['amount'] - $m['refund_cancellation'];
            $m['running_balance'] = $closing;
            $m['total_due'] = $closing < 0 ? abs($closing) : 0;
            $m['status'] = $closing <= 0 ? 'Paid' : 'Pending';
            $result[] = $m;
            $running = $closing;
        }

        // Manual pagination (small array, but keeps response shape consistent)
        $page = max((int) $request->input('page', 1), 1);
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);
        $all = array_reverse($result);
        $paged = array_slice($all, ($page - 1) * $perPage, $perPage);

        return response()->json([
            'status' => true,
            'data' => $paged,
            'meta' => [
                'current_page' => $page,
                'last_page' => max((int) ceil(count($all) / $perPage), 1),
                'per_page' => $perPage,
                'total' => count($all),
            ],
        ]);
    }

        /**
     * "Unbilled" drill-in for the Bills tab.
     * Returns delivered occurrences that have NOT yet been invoiced for this
     * customer. Optional date range narrows the window.
     */
    public function unbilledDeliveries(Request $request, int $customer)
    {
        $request->validate([
            'date_from' => 'nullable|date',
            'date_to'   => 'nullable|date|after_or_equal:date_from',
        ]);

        $query = \Illuminate\Support\Facades\DB::table('subscription_occurrences as so')
            ->join('subscription_items as si', 'si.id', '=', 'so.subscription_item_id')
            ->join('subscriptions as s', 's.id', '=', 'si.subscription_id')
            ->leftJoin('product_variants as pv', 'pv.id', '=', 'si.product_variant_id')
            ->leftJoin('products as p', 'p.id', '=', 'pv.product_id')
            ->leftJoin('tenant_delivery_slots as tds', 'tds.id', '=', 'si.slot_id')
            ->where('s.customer_id', $customer)
            ->where('so.status', 'delivered')
            ->whereNull('so.invoice_id')
            ->when($request->date_from, fn ($q, $v) => $q->whereDate('so.occurrence_date', '>=', $v))
            ->when($request->date_to, fn ($q, $v) => $q->whereDate('so.occurrence_date', '<=', $v))
            ->select(
                'so.id',
                'so.occurrence_date',
                'so.qty',
                'so.unit_price_snapshot as rate',
                \Illuminate\Support\Facades\DB::raw("(so.qty * so.unit_price_snapshot) as line_total"),
                's.id as subscription_id',
                'p.name as product_name',
                'pv.sku as variant_sku',
                'tds.name as slot_name',
                'tds.start_time as slot_start'
            )
            ->orderByDesc('so.occurrence_date');

        $rows = $query->get();
        $total = $rows->sum('line_total');

        return response()->json([
            'status' => true,
            'data' => $rows,
            'meta' => [
                'count' => $rows->count(),
                'total' => round($total, 2),
            ],
        ]);
    }

    /**
     * Bulk update status for multiple customers.
     */
    public function bulkUpdateStatus(Request $request)
    {
        $data = $request->validate([
            'customer_ids'   => 'required|array|min:1|max:500',
            'customer_ids.*' => 'integer|exists:customers,id',
            'status'         => 'required|in:active,inactive,suspended',
        ]);

        $updated = 0;
        DB::transaction(function () use ($data, &$updated) {
            $updated = \App\Models\Tenant\Customer::whereIn('id', $data['customer_ids'])
                ->where('status', '!=', $data['status'])
                ->update([
                    'status'            => $data['status'],
                    'status_changed_at' => now(),
                    'updated_at'        => now(),
                ]);
        });

        return response()->json([
            'status' => true,
            'message' => "{$updated} customer(s) updated.",
            'data' => ['updated' => $updated],
        ]);
    }

    /**
     * Bulk wallet credit/debit across multiple customers.
     */
    public function bulkWalletAdjust(Request $request, \App\Services\V1\Wallet\WalletService $walletService)
    {
        $data = $request->validate([
            'customer_ids'   => 'required|array|min:1|max:500',
            'customer_ids.*' => 'integer|exists:customers,id',
            'amount'         => 'required|numeric|min:0.01',
            'direction'      => 'required|in:credit,debit',
            'remark'         => 'required|string|max:255',
        ]);

        $results = ['success' => 0, 'failed' => 0, 'errors' => []];

        foreach ($data['customer_ids'] as $customerId) {
            try {
                $walletService->adminAdjust(
                    customerId: (int) $customerId,
                    amount: (float) $data['amount'],
                    direction: $data['direction'],
                    remark: $data['remark'],
                    addedBy: $request->user()->id,
                );
                $results['success']++;
            } catch (\Throwable $e) {
                $results['failed']++;
                $results['errors'][] = "Customer #{$customerId}: " . $e->getMessage();
            }
        }

        return response()->json([
            'status' => true,
            'message' => "{$results['success']} succeeded, {$results['failed']} failed.",
            'data' => $results,
        ]);
    }

    /**
     * CSV export from the Customer 360 profile page.
     * Streams a multi-section CSV: profile, addresses, subscriptions,
     * transactions, deliveries, bills.
     */
        public function exportProfile(int $customer)
    {
        $c = \App\Models\Tenant\Customer::with(['addresses.branch', 'addresses.zone'])->findOrFail($customer);

        $filename = "customer_{$c->id}_" . now()->format('Ymd_His') . ".csv";

        return response()->streamDownload(function () use ($c) {
            $out = fopen('php://output', 'w');
            fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // UTF-8 BOM

            // ── Section 1: Profile
            fputcsv($out, ['CUSTOMER PROFILE']);
            fputcsv($out, ['ID', 'Name', 'Email', 'Phone', 'Status', 'DND', 'Warning Limit', 'Suspension Limit', 'Registered On']);
            fputcsv($out, [
                $c->id, $c->name, $c->email, $c->phone ?? '', $c->status,
                $c->dnd ? 'Yes' : 'No',
                number_format($c->effectiveWarningLimit(), 2, '.', ''),
                number_format($c->effectiveSuspensionLimit(), 2, '.', ''),
                optional($c->created_at)->format('d-m-Y H:i'),
            ]);
            fputcsv($out, []);

            // ── Section 2: Addresses
            fputcsv($out, ['ADDRESSES']);
            fputcsv($out, ['Label', 'Address Line 1', 'Address Line 2', 'City', 'State', 'Pincode', 'Default', 'Branch', 'Zone']);
            foreach ($c->addresses as $a) {
                fputcsv($out, [
                    $a->label,
                    $a->address_line1 ?? '',
                    $a->address_line2 ?? '',
                    $a->city ?? '',
                    $a->state ?? '',
                    $a->pincode ?? '',
                    $a->is_default ? 'Yes' : 'No',
                    $a->branch?->name ?? '',
                    $a->zone?->name ?? '',
                ]);
            }
            fputcsv($out, []);

            // ── Section 3: Subscriptions
            fputcsv($out, ['SUBSCRIPTIONS']);
            fputcsv($out, ['ID', 'Start Date', 'End Date', 'Status', 'Branch', 'First Product', 'Schedule', 'Slot']);
            $subs = \App\Models\Subscription::with([
                'branch',
                'items.slot',
                'items.productVariant.product',
            ])->where('customer_id', $c->id)->orderByDesc('created_at')->get();

            foreach ($subs as $sub) {
                $firstItem = $sub->items->first();
                $productName = $firstItem?->productVariant?->product?->name ?? '—';
                $slotName = $firstItem?->slot
                    ? $firstItem->slot->name . ' (' . substr($firstItem->slot->start_time, 0, 5) . ')'
                    : '—';
                $pattern = $firstItem
                    ? "{$firstItem->default_qty} Unit | " . ucfirst(str_replace('_', ' ', $firstItem->schedule_type))
                    : '—';

                fputcsv($out, [
                    $sub->id,
                    optional($sub->start_date)->format('d-m-Y'),
                    optional($sub->end_date)->format('d-m-Y') ?? 'Ongoing',
                    $sub->status,
                    $sub->branch?->name ?? '',
                    $productName,
                    $pattern,
                    $slotName,
                ]);
            }
            fputcsv($out, []);

            // ── Section 4: Orders
            fputcsv($out, ['ORDERS']);
            fputcsv($out, ['Order #', 'Date', 'Branch', 'Payment Mode', 'Payment Status', 'Order Status', 'Total', 'Items']);
            $orders = DB::table('orders as o')
                ->leftJoin('branches as b', 'b.id', '=', 'o.branch_id')
                ->where('o.customer_id', $c->id)
                ->select('o.id', 'o.order_number', 'o.created_at', 'b.name as branch_name',
                         'o.payment_mode', 'o.payment_status', 'o.status', 'o.total')
                ->orderByDesc('o.created_at')
                ->get();

            foreach ($orders as $o) {
                $itemSummary = DB::table('order_items')
                    ->join('product_variants as pv', 'pv.id', '=', 'order_items.product_variant_id')
                    ->leftJoin('products as p', 'p.id', '=', 'pv.product_id')
                    ->where('order_id', $o->id)
                    ->select(
                        DB::raw("CONCAT(COALESCE(p.name, 'Item'), ' ×', order_items.quantity) as line")
                    )
                    ->pluck('line')
                    ->implode('; ');

                fputcsv($out, [
                    $o->order_number ?? '#' . $o->id,
                    \Carbon\Carbon::parse($o->created_at)->format('d-m-Y H:i'),
                    $o->branch_name ?? '',
                    $o->payment_mode,
                    $o->payment_status,
                    $o->status,
                    number_format((float) $o->total, 2, '.', ''),
                    $itemSummary,
                ]);
            }
            fputcsv($out, []);

            // ── Section 5: Invoices
            fputcsv($out, ['INVOICES']);
            fputcsv($out, ['Invoice #', 'Period Start', 'Period End', 'Total', 'Paid', 'Due', 'Status', 'Generated On', 'Line Items']);
            $invoices = \App\Models\Invoice::with('items')->where('customer_id', $c->id)
                ->orderByDesc('generated_at')->get();

            foreach ($invoices as $inv) {
                $lineSummary = $inv->items->map(fn ($it) => $it->description . ' ×' . $it->qty)->implode('; ');

                fputcsv($out, [
                    $inv->id,
                    optional($inv->period_start)->format('d-m-Y'),
                    optional($inv->period_end)->format('d-m-Y'),
                    number_format((float) $inv->total, 2, '.', ''),
                    number_format((float) $inv->amount_paid, 2, '.', ''),
                    number_format((float) $inv->amount_due, 2, '.', ''),
                    $inv->status,
                    optional($inv->generated_at)->format('d-m-Y H:i'),
                    $lineSummary,
                ]);
            }
            fputcsv($out, []);

            // ── Section 6: Transactions (last 200)
            fputcsv($out, ['WALLET TRANSACTIONS']);
            fputcsv($out, ['Date', 'Type', 'Amount', 'Balance After', 'Remark']);
            $txs = DB::table('wallet_transactions')->where('customer_id', $c->id)
                ->orderByDesc('created_at')->limit(200)->get();

            foreach ($txs as $t) {
                fputcsv($out, [
                    \Carbon\Carbon::parse($t->created_at)->format('d-m-Y H:i'),
                    $t->type,
                    number_format((float) $t->amount, 2, '.', ''),
                    number_format((float) $t->balance_after, 2, '.', ''),
                    $t->remark ?? '',
                ]);
            }
            fputcsv($out, []);

            // ── Section 7: Ledger (monthly wallet statement)
            fputcsv($out, ['MONTHLY LEDGER']);
            fputcsv($out, ['Month', 'Opening Balance', 'Amount (Debits)', 'Refund & Cancellation', 'Payment & Credit', 'Closing Balance', 'Status']);
            $allTxs = DB::table('wallet_transactions')->where('customer_id', $c->id)
                ->orderBy('created_at')->get();

            $byMonth = [];
            foreach ($allTxs as $t) {
                $key = \Carbon\Carbon::parse($t->created_at)->format('M-Y');
                if (! isset($byMonth[$key])) {
                    $byMonth[$key] = ['amount' => 0, 'refund' => 0, 'credit' => 0];
                }
                $amt = (float) $t->amount;
                if (in_array($t->type, ['deposit', 'refund'])) {
                    $byMonth[$key]['credit'] += abs($amt);
                    if ($t->type === 'refund') $byMonth[$key]['refund'] += abs($amt);
                } else {
                    $byMonth[$key]['amount'] += abs($amt);
                }
            }

            $sortedMonths = array_keys($byMonth);
            usort($sortedMonths, fn ($a, $b) => strtotime("01 {$a}") <=> strtotime("01 {$b}"));

            $running = 0;
            foreach ($sortedMonths as $key) {
                $m = $byMonth[$key];
                $closing = $running + $m['credit'] - $m['amount'] - $m['refund'];
                fputcsv($out, [
                    $key,
                    number_format($running, 2, '.', ''),
                    number_format($m['amount'], 2, '.', ''),
                    number_format($m['refund'], 2, '.', ''),
                    number_format($m['credit'], 2, '.', ''),
                    number_format($closing, 2, '.', ''),
                    $closing <= 0 ? 'Paid' : 'Pending',
                ]);
                $running = $closing;
            }
            fputcsv($out, []);

            // ── Section 8: Deliveries (last 200)
            fputcsv($out, ['DELIVERIES']);
            fputcsv($out, ['Date', 'Product', 'Slot', 'Qty', 'Rate', 'Line Total', 'Status']);
            $deliveries = DB::table('subscription_occurrences as so')
                ->join('subscription_items as si', 'si.id', '=', 'so.subscription_item_id')
                ->join('subscriptions as s', 's.id', '=', 'si.subscription_id')
                ->leftJoin('product_variants as pv', 'pv.id', '=', 'si.product_variant_id')
                ->leftJoin('products as p', 'p.id', '=', 'pv.product_id')
                ->leftJoin('tenant_delivery_slots as tds', 'tds.id', '=', 'si.slot_id')
                ->where('s.customer_id', $c->id)
                ->whereIn('so.status', ['delivered', 'out_for_delivery', 'not_delivered', 'holiday_skipped', 'cancelled'])
                ->select(
                    'so.occurrence_date',
                    'so.status',
                    'so.qty',
                    'so.unit_price_snapshot',
                    DB::raw('(so.qty * so.unit_price_snapshot) as line_total'),
                    'p.name as product_name',
                    'pv.sku as variant_sku',
                    'tds.name as slot_name'
                )
                ->orderByDesc('so.occurrence_date')
                ->limit(200)
                ->get();

            foreach ($deliveries as $d) {
                fputcsv($out, [
                    \Carbon\Carbon::parse($d->occurrence_date)->format('d-m-Y'),
                    ($d->product_name ?? 'Item') . ($d->variant_sku ? ' (' . $d->variant_sku . ')' : ''),
                    $d->slot_name ?? '—',
                    $d->qty,
                    number_format((float) $d->unit_price_snapshot, 2, '.', ''),
                    number_format((float) $d->line_total, 2, '.', ''),
                    $d->status,
                ]);
            }

            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
    
    public function subscriptionDetail(Request $request, int $customer, int $subscriptionId)
    {
        $sub = \App\Models\Subscription::with([
                'items.slot',
                'items.productVariant.product',
                'deliveryInstruction',
            ])
            ->where('customer_id', $customer)
            ->findOrFail($subscriptionId);

        $slots = \App\Models\TenantDeliverySlot::where('is_active', 1)
            ->orderBy('start_time')->get(['id', 'name', 'start_time', 'end_time']);
        $instructions = \App\Models\DeliveryInstruction::where('tenant_id', tenant()->getKey())
            ->where('is_active', 1)->orderBy('sort_order')->get(['id', 'label', 'code']);

        // ★ Build a rolling 7-day timeline centered on today.
        $today = \Carbon\Carbon::now()->startOfDay();
        $timelineStart = $today->copy()->subDays(3);
        $timelineEnd   = $today->copy()->addDays(3);

        $occurrences = \App\Models\SubscriptionOccurrence::query()
            ->whereHas('subscriptionItem', function ($q) use ($sub) {
                $q->where('subscription_id', $sub->id);
            })
            ->whereBetween('occurrence_date', [
                $timelineStart->toDateString(),
                $timelineEnd->toDateString(),
            ])
            ->get()
            ->groupBy(fn ($o) => $o->occurrence_date->toDateString());

        $pauses = \App\Models\SubscriptionPause::query()
            ->whereHas('subscriptionItem', function ($q) use ($sub) {
                $q->where('subscription_id', $sub->id);
            })
            ->whereDate('date_to', '>=', $timelineStart->toDateString())
            ->whereDate('date_from', '<=', $timelineEnd->toDateString())
            ->get();

        $qtyOverrides = \App\Models\SubscriptionQtyOverride::query()
            ->whereHas('subscriptionItem', function ($q) use ($sub) {
                $q->where('subscription_id', $sub->id);
            })
            ->whereDate('date_to', '>=', $timelineStart->toDateString())
            ->whereDate('date_from', '<=', $timelineEnd->toDateString())
            ->get();

        $mutableStates = ['holiday_skipped', 'cancelled', 'admin_paused', 'customer_paused'];

        $timeline = [];
        for ($d = $timelineStart->copy(); $d->lte($timelineEnd); $d->addDay()) {
            $dateStr = $d->toDateString();
            $dayOccs = $occurrences->get($dateStr, collect());

            if ($dayOccs->isNotEmpty()) {
                $allOff = $dayOccs->every(fn ($o) => in_array($o->status, $mutableStates));
                $totalQty = $dayOccs->sum('qty');

                $timeline[] = [
                    'date'    => $dateStr,
                    'day'     => $d->format('D'),
                    'day_num' => $d->format('j'),
                    'qty'     => $allOff ? 0 : $totalQty,
                    'status'  => $dayOccs->first()->status,
                    'label'   => $allOff ? 'Off' : (string) $totalQty,
                    'is_off'  => $allOff,
                ];
                continue;
            }

            $dayPaused = $pauses->first(function ($p) use ($dateStr) {
                return $p->date_from <= $dateStr && $p->date_to >= $dateStr;
            });

            if ($dayPaused) {
                $timeline[] = [
                    'date'    => $dateStr,
                    'day'     => $d->format('D'),
                    'day_num' => $d->format('j'),
                    'qty'     => 0,
                    'status'  => 'projected',
                    'label'   => 'Off',
                    'is_off'  => true,
                ];
                continue;
            }

            $defaultQty = (int) ($sub->items->first()?->default_qty ?? 1);
            $override = $qtyOverrides
                ->filter(fn ($o) => $o->date_from <= $dateStr && $o->date_to >= $dateStr)
                ->sortByDesc('created_at')
                ->first();

            $projectedQty = $override ? (int) $override->qty : $defaultQty;

            $timeline[] = [
                'date'    => $dateStr,
                'day'     => $d->format('D'),
                'day_num' => $d->format('j'),
                'qty'     => $projectedQty,
                'status'  => 'projected',
                'label'   => (string) $projectedQty,
                'is_off'  => false,
            ];
        }

        return response()->json([
            'status' => true,
            'data' => [
                'subscription' => $sub,
                'master_data' => [
                    'slots' => $slots,
                    'instructions' => $instructions,
                ],
                'timeline' => $timeline,
            ],
        ]);
    }

    public function getNotes(int $customer)
    {
        $notes = \App\Models\CustomerNote::with('addedBy:id,name')
            ->where('customer_id', $customer)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn ($n) => [
                'id' => $n->id,
                'note' => $n->note,
                'added_by' => $n->addedBy?->name ?? 'System',
                'created_at' => $n->created_at?->toIso8601String(),
            ]);

        return response()->json(['status' => true, 'data' => $notes]);
    }

        /**
     * Invoice list for a specific customer.
     * Wraps the same Invoice model used by InvoiceController but scoped
     * to one customer.
     */
    public function invoices(Request $request, int $customer)
    {
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);

        $invoices = \App\Models\Invoice::query()
            ->where('customer_id', $customer)
            ->orderByDesc('generated_at')
            ->orderByDesc('id')
            ->paginate($perPage);

        return response()->json([
            'status' => true,
            'data' => $invoices->items(),
            'meta' => [
                'current_page' => $invoices->currentPage(),
                'last_page' => $invoices->lastPage(),
                'per_page' => $invoices->perPage(),
                'total' => $invoices->total(),
            ],
        ]);
    }

    /**
     * Order list for a specific customer (includes all statuses).
     */
    public function orders(Request $request, int $customer)
    {
        $perPage = min(max((int) $request->input('per_page', 25), 1), 100);

        $orders = \Illuminate\Support\Facades\DB::table('orders as o')
            ->leftJoin('branches as b', 'b.id', '=', 'o.branch_id')
            ->where('o.customer_id', $customer)
            ->select(
                'o.id',
                'o.order_number',
                'o.status',
                'o.payment_mode',
                'o.payment_status',
                'o.total',
                'o.created_at',
                'b.name as branch_name'
            )
            ->orderByDesc('o.created_at')
            ->paginate($perPage);

        // Decorate with item count per order
        $orderIds = collect($orders->items())->pluck('id')->all();
        $itemCounts = $orderIds
            ? \Illuminate\Support\Facades\DB::table('order_items')
                ->whereIn('order_id', $orderIds)
                ->selectRaw('order_id, SUM(quantity) as total_qty, COUNT(*) as line_count')
                ->groupBy('order_id')
                ->get()
                ->keyBy('order_id')
            : collect();

        $decorated = collect($orders->items())->map(function ($o) use ($itemCounts) {
            $meta = $itemCounts->get($o->id);
            $o->line_count = $meta?->line_count ?? 0;
            $o->total_qty = (int) ($meta?->total_qty ?? 0);
            return $o;
        });

        return response()->json([
            'status' => true,
            'data' => $decorated,
            'meta' => [
                'current_page' => $orders->currentPage(),
                'last_page' => $orders->lastPage(),
                'per_page' => $orders->perPage(),
                'total' => $orders->total(),
            ],
        ]);
    }
}
