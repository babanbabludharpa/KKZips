<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\ProductVariantResource;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Services\V1\Masters\ProductVariantService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductVariantController extends Controller
{
    public function __construct(protected ProductVariantService $service) {}

    // POST /products/{product}/variants
    public function store(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'sku' => ['required', 'string', 'max:60'],
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'hsn_code' => ['nullable', 'string', 'max:20'],
            'image' => ['nullable', 'string'],
            'mrp' => ['required', 'numeric', 'min:0'],
            'purchase_price' => ['nullable', 'numeric', 'min:0'],
            'selling_price' => ['required', 'numeric', 'min:0'],
            'tax_rate_id' => ['nullable', 'integer', 'exists:tax_rates,id'],
            'min_order_qty' => ['nullable', 'integer', 'min:1'],
            'is_active' => ['boolean'],
            'is_coupon_eligible' => ['boolean'],
            'available_for_order' => ['boolean'],
            'available_for_subscription' => ['boolean'],
            'attribute_value_ids' => ['nullable', 'array'],
            'attribute_value_ids.*' => ['integer', 'exists:attribute_values,id'],
        ]);

        $variant = $this->service->create($product, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Product variant created.',
            'data' => ['variant' => new ProductVariantResource($variant)],
        ], 201);
    }

    // POST /products/{product}/variants/bulk
    public function bulkStore(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'variants' => ['required', 'array', 'min:1'],
            'variants.*.sku' => ['required', 'string', 'max:60'],
            'variants.*.unit_id' => ['required', 'integer', 'exists:units,id'],
            'variants.*.hsn_code' => ['nullable', 'string', 'max:20'],
            'variants.*.mrp' => ['required', 'numeric', 'min:0'],
            'variants.*.purchase_price' => ['nullable', 'numeric', 'min:0'],
            'variants.*.selling_price' => ['required', 'numeric', 'min:0'],
            'variants.*.tax_rate_id' => ['nullable', 'integer', 'exists:tax_rates,id'],
            'variants.*.min_order_qty' => ['nullable', 'integer', 'min:1'],
            'variants.*.is_active' => ['boolean'],
            'variants.*.is_coupon_eligible' => ['boolean'],
            'variants.*.available_for_order' => ['boolean'],
            'variants.*.available_for_subscription' => ['boolean'],
            'variants.*.attribute_value_ids' => ['nullable', 'array'],
            'variants.*.attribute_value_ids.*' => ['integer', 'exists:attribute_values,id'],
        ]);

        $variants = $this->service->bulkCreate($product, $validated['variants']);

        return response()->json([
            'status' => true,
            'message' => count($variants).' variants created.',
            'data' => ['variants' => ProductVariantResource::collection($variants)],
        ], 201);
    }

    // GET /variants/{variant}
    public function show(ProductVariant $variant): JsonResponse
    {
        $variant->load(['unit', 'taxRate', 'attributeValues.attribute']);

        return response()->json([
            'status' => true,
            'message' => 'Variant fetched.',
            'data' => ['variant' => new ProductVariantResource($variant)],
        ]);
    }

    // PUT /variants/{variant}
    public function update(Request $request, ProductVariant $variant): JsonResponse
    {
        // ★ FREE GIFTS — gift variants are managed exclusively from the
        // Free Gifts section (gift.* permissions), never from here.
        if ($variant->is_gift) {
            return response()->json([
                'status' => false,
                'message' => 'This is a gift product. Manage it from the Free Gifts section.',
            ], 422);
        }

        $validated = $request->validate([
            'sku' => ['sometimes', 'string', 'max:60'],
            'unit_id' => ['sometimes', 'integer', 'exists:units,id'],
            'hsn_code' => ['nullable', 'string', 'max:20'],
            'image' => ['nullable', 'string'],
            'mrp' => ['sometimes', 'numeric', 'min:0'],
            'purchase_price' => ['nullable', 'numeric', 'min:0'],
            'selling_price' => ['sometimes', 'numeric', 'min:0'],
            'tax_rate_id' => ['nullable', 'integer', 'exists:tax_rates,id'],
            'min_order_qty' => ['nullable', 'integer', 'min:1'],
            'is_active' => ['boolean'],
            'is_coupon_eligible' => ['boolean'],
            'available_for_order' => ['boolean'],
            'available_for_subscription' => ['boolean'],
            'attribute_value_ids' => ['nullable', 'array'],
            'attribute_value_ids.*' => ['integer', 'exists:attribute_values,id'],
        ]);

        $variant = $this->service->update($variant, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Variant updated.',
            'data' => ['variant' => new ProductVariantResource($variant)],
        ]);
    }

    // POST /variants/{variant}/image
    public function uploadImage(Request $request, ProductVariant $variant): JsonResponse
    {
        $request->validate([
            'image' => ['required', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'],
        ]);

        $variant = $this->service->uploadImage($variant, $request->file('image'));

        return response()->json([
            'status' => true,
            'message' => 'Variant image uploaded.',
            'data' => [
                'image' => $variant->image,
                'image_url' => $this->service->getImageUrl($variant->image),
            ],
        ]);
    }

    // DELETE /variants/{variant}
    public function destroy(ProductVariant $variant): JsonResponse
    {
        if ($variant->is_gift) {
            return response()->json([
                'status' => false,
                'message' => 'This is a gift product. Manage it from the Free Gifts section.',
            ], 422);
        }

        $this->service->delete($variant);

        return response()->json([
            'status' => true,
            'message' => 'Variant deleted.',
            'data' => [],
        ]);
    }

    // PATCH /variants/{variant}/toggle
    public function toggle(ProductVariant $variant): JsonResponse
    {
        if ($variant->is_gift) {
            return response()->json([
                'status' => false,
                'message' => 'This is a gift product. Manage it from the Free Gifts section.',
            ], 422);
        }

        $variant = $this->service->toggleActive($variant);

        return response()->json([
            'status' => true,
            'message' => 'Variant status updated.',
            'data' => ['variant' => new ProductVariantResource($variant)],
        ]);
    }
}
