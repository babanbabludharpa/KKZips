<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\CountryResource;
use App\Http\Resources\V1\StateResource;
use App\Models\Country;
use App\Models\State;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    // GET /v1/masters/countries
    public function countries(): JsonResponse
    {
        $countries = Country::active()->orderBy('name')->get();

        return response()->json([
            'status' => true,
            'message' => 'Countries retrieved successfully.',
            'data' => ['countries' => CountryResource::collection($countries)],
        ]);
    }

    // GET /v1/masters/states?country_id=1
    public function states(Request $request): JsonResponse
    {
        $query = State::active()->orderBy('name');

        if ($request->filled('country_id')) {
            $query->where('country_id', $request->country_id);
        }

        return response()->json([
            'status' => true,
            'message' => 'States retrieved successfully.',
            'data' => ['states' => StateResource::collection($query->get())],
        ]);
    }
}
