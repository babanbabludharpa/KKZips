<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\AttributeResource;
use App\Http\Resources\V1\AttributeValueResource;
use App\Models\Attribute;
use App\Models\AttributeValue;
use App\Services\V1\Masters\AttributeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AttributeController extends Controller
{
    public function __construct(protected AttributeService $service) {}

    public function index(Request $request): JsonResponse
    {
        $attributes = $this->service->getAll($request->only(['search', 'is_active', 'per_page']));

        return response()->json([
            'status' => true,
            'message' => 'Attributes fetched.',
            'data' => AttributeResource::collection($attributes)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:50'],
            'is_active' => ['boolean'],
        ]);

        $attribute = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Attribute created.',
            'data' => ['attribute' => new AttributeResource($attribute)],
        ], 201);
    }

    public function show(Attribute $attribute): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Attribute fetched.',
            'data' => ['attribute' => new AttributeResource($attribute->load('values'))],
        ]);
    }

    public function update(Request $request, Attribute $attribute): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:50'],
            'is_active' => ['boolean'],
        ]);

        $attribute = $this->service->update($attribute, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Attribute updated.',
            'data' => ['attribute' => new AttributeResource($attribute)],
        ]);
    }

    public function destroy(Attribute $attribute): JsonResponse
    {
        $this->service->delete($attribute);

        return response()->json([
            'status' => true,
            'message' => 'Attribute deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Attribute $attribute): JsonResponse
    {
        $attribute = $this->service->toggleActive($attribute);

        return response()->json([
            'status' => true,
            'message' => 'Attribute status updated.',
            'data' => ['attribute' => new AttributeResource($attribute)],
        ]);
    }

    // ── Attribute Values (nested) ──────────────────────────────────

    public function addValue(Request $request, Attribute $attribute): JsonResponse
    {
        $validated = $request->validate([
            'value' => ['required', 'string', 'max:50'],
            'is_active' => ['boolean'],
        ]);

        $value = $this->service->addValue($attribute, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Attribute value added.',
            'data' => ['value' => new AttributeValueResource($value)],
        ], 201);
    }

    public function updateValue(Request $request, AttributeValue $value): JsonResponse
    {
        $validated = $request->validate([
            'value' => ['sometimes', 'string', 'max:50'],
            'is_active' => ['boolean'],
        ]);

        $value = $this->service->updateValue($value, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Attribute value updated.',
            'data' => ['value' => new AttributeValueResource($value)],
        ]);
    }

    public function destroyValue(AttributeValue $value): JsonResponse
    {
        $this->service->deleteValue($value);

        return response()->json([
            'status' => true,
            'message' => 'Attribute value deleted.',
            'data' => [],
        ]);
    }
}// Testing
