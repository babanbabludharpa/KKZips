<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Models\Tenant\Customer;
use App\Services\V1\Wallet\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

// Grouped with Masters/CustomerController in routes/api.php (customer.*
// permissions, /masters/customers/... paths) rather than a separate
// Admin/ namespace -- matches how customer addresses/status already work
// (CustomerController::addresses, ::updateStatus), see route snippet.
class CustomerWalletController extends Controller
{
    private const DEFAULT_PAGE_SIZE = 25;

    private const MAX_PAGE_SIZE = 100;

    // Same expression DashboardService uses. Computes the per-row delta
    // from balance_after using LAG() over the customer's ledger, so the
    // frontend has an unambiguous signed value regardless of `type`.
    private const LAG_SIGNED_DELTA_EXPR =
        'wt.balance_after - COALESCE('
        .'LAG(wt.balance_after) OVER (PARTITION BY wt.customer_id ORDER BY wt.created_at, wt.id)'
        .', 0) as signed_delta';

    public function __construct(protected WalletService $walletService) {}

    // POST /masters/customers/{customer}/wallet/adjust
    // { amount, direction: 'credit'|'debit', remark }
    // For cash/cheque/other-offline payments an admin is recording on a
    // customer's behalf, or a manual correction. Never for anything
    // Razorpay-verified -- that always goes through the topup verify/
    // webhook path in WalletController, which has its own signature check
    // this endpoint deliberately does not replicate or bypass.
    public function adjust(Request $request, Customer $customer): JsonResponse
    {
        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'direction' => 'required|string|in:credit,debit',
            'remark' => 'required|string|max:255',
        ]);

        try {
            $this->walletService->adminAdjust(
                customerId: $customer->id,
                amount: (float) $data['amount'],
                direction: $data['direction'],
                remark: $data['remark'],
                addedBy: $request->user()->id,
            );
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
            ], 422);
        }

        $balance = DB::table('customer_wallets')
            ->where('customer_id', $customer->id)
            ->value('balance');

        return response()->json([
            'status' => true,
            'message' => $data['direction'] === 'credit'
                ? 'Wallet credited successfully.'
                : 'Wallet debited successfully.',
            'data' => ['balance' => (float) ($balance ?? 0)],
        ]);
    }

    // GET /masters/customers/{customer}/wallet/transactions
    // Read-only ledger view -- exists so the frontend can show a history
    // list next to the adjust form (the remark/added_by columns added
    // upstream are only useful if something surfaces them). Reuses
    // customer.view rather than a new permission: viewing history is not
    // the sensitive action here, adjusting the balance is.
    public function transactions(Request $request, Customer $customer): JsonResponse
    {
        // Clamp per_page the same way WalletReportController does -- 1 to 100,
        // default 25. The frontend sends ?per_page=... via PerPageSelector.
        $perPage = min(
            max((int) $request->input('per_page', self::DEFAULT_PAGE_SIZE), 1),
            self::MAX_PAGE_SIZE
        );

        // Compute signed_delta for every row in the customer's ledger, then
        // paginate. The LAG() window runs over the whole partition before
        // LIMIT is applied, so deltas are correct across pages -- not just
        // within the current page.
        $withDelta = DB::table('wallet_transactions as wt')
            ->where('wt.customer_id', $customer->id)
            ->select([
                'wt.*',
                DB::raw(self::LAG_SIGNED_DELTA_EXPR),
            ]);

        $transactions = DB::query()
            ->fromSub($withDelta, 'wt')
            ->orderByDesc('wt.created_at')
            ->orderByDesc('wt.id')
            ->paginate($perPage);

        $transactions->getCollection()->transform(function ($row) {
            $row->amount = (float) $row->amount;
            $row->balance_after = (float) $row->balance_after;
            $row->signed_delta = (float) $row->signed_delta;

            return $row;
        });

        $balance = DB::table('customer_wallets')
            ->where('customer_id', $customer->id)
            ->value('balance');

        return response()->json([
            'status' => true,
            'data' => [
                'balance' => (float) ($balance ?? 0),
                'transactions' => $transactions,
            ],
        ]);
    }
}
