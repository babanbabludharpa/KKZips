<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\PriceScheduleResource;
use App\Models\PriceSchedule;
use App\Models\ProductVariant;
use App\Services\V1\Masters\PriceScheduleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PriceScheduleController extends Controller
{
    public function __construct(protected PriceScheduleService $service) {}

    // GET /variants/{variant}/price-schedules
    public function index(Request $request, ProductVariant $variant): JsonResponse
    {
        $schedules = $this->service->getAllForVariant($variant, $request->only(['status', 'per_page']));

        return response()->json([
            'status' => true,
            'message' => 'Price schedules fetched.',
            'data' => PriceScheduleResource::collection($schedules)->response()->getData(true),
        ]);
    }

    // POST /variants/{variant}/price-schedules
    public function store(Request $request, ProductVariant $variant): JsonResponse
    {
        $validated = $request->validate([
            'mrp' => ['nullable', 'numeric', 'min:0'],
            'selling_price' => ['nullable', 'numeric', 'min:0'],
            'purchase_price' => ['nullable', 'numeric', 'min:0'],
            'effective_from' => ['required', 'date'],
        ]);

        $schedule = $this->service->create($variant, $validated, $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Price schedule created.',
            'data' => ['schedule' => new PriceScheduleResource($schedule)],
        ], 201);
    }

    // PUT /price-schedules/{schedule}
    public function update(Request $request, PriceSchedule $schedule): JsonResponse
    {
        $validated = $request->validate([
            'mrp' => ['nullable', 'numeric', 'min:0'],
            'selling_price' => ['nullable', 'numeric', 'min:0'],
            'purchase_price' => ['nullable', 'numeric', 'min:0'],
            'effective_from' => ['sometimes', 'date'],
        ]);

        $schedule = $this->service->update($schedule, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Price schedule updated.',
            'data' => ['schedule' => new PriceScheduleResource($schedule)],
        ]);
    }

    // PATCH /price-schedules/{schedule}/cancel
    public function cancel(PriceSchedule $schedule): JsonResponse
    {
        $schedule = $this->service->cancel($schedule);

        return response()->json([
            'status' => true,
            'message' => 'Price schedule cancelled.',
            'data' => ['schedule' => new PriceScheduleResource($schedule)],
        ]);
    }
}
