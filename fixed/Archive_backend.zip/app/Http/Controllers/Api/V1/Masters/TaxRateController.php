<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\TaxRateResource;
use App\Models\TaxRate;
use App\Services\V1\Masters\TaxRateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TaxRateController extends Controller
{
    public function __construct(protected TaxRateService $service) {}

    public function index(Request $request): JsonResponse
    {
        $taxrates = $this->service->getAll($request->only(['search', 'is_active', 'per_page']));

        return response()->json([
            'status' => true,
            'message' => 'TaxRates fetched.',
            'data' => TaxRateResource::collection($taxrates)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'label' => ['required', 'string', 'max:50'],
            'percentage' => ['required', 'numeric', 'min:0', 'max:20', 'regex:/^\d+(\.\d{1,2})?$/'],
            'is_active' => ['boolean'],
        ]);

        $taxRate = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'TaxRate created.',
            'data' => ['taxRate' => new TaxRateResource($taxRate)],
        ], 201);
    }

    public function show(TaxRate $taxRate): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'TaxRate fetched.',
            'data' => ['taxRate' => new TaxRateResource($taxRate)],
        ]);
    }

    public function update(Request $request, TaxRate $taxRate): JsonResponse
    {
        $validated = $request->validate([
            'label' => ['sometimes', 'string', 'max:50'],
            'percentage' => ['required', 'numeric', 'min:0', 'max:20', 'regex:/^\d+(\.\d{1,2})?$/'],
            'is_active' => ['boolean'],
        ]);

        $taxRate = $this->service->update($taxRate, $validated);

        return response()->json([
            'status' => true,
            'message' => 'TaxRate updated.',
            'data' => ['taxRate' => new TaxRateResource($taxRate)],
        ]);
    }

    public function destroy(TaxRate $taxRate): JsonResponse
    {
        $this->service->delete($taxRate);

        return response()->json([
            'status' => true,
            'message' => 'TaxRate deleted.',
            'data' => [],
        ]);
    }

    public function toggle(TaxRate $taxRate): JsonResponse
    {
        $taxRate = $this->service->toggleActive($taxRate);

        return response()->json([
            'status' => true,
            'message' => 'TaxRate status updated.',
            'data' => ['taxRate' => new TaxRateResource($taxRate)],
        ]);
    }
}
