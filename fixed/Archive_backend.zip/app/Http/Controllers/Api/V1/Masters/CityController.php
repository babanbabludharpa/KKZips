<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\CityResource;
use App\Services\V1\Masters\CityService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function __construct(protected CityService $service) {}

    // GET /v1/masters/cities?search=&state_id=&is_active=&per_page=&sort_key=&sort_dir=
    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'state_id' => 'nullable|integer|exists:states,id',
            'is_active' => 'nullable|boolean',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $cities = $this->service->getAll($request->only([
            'search', 'state_id', 'is_active', 'per_page', 'sort_key', 'sort_dir',
        ]));

        return response()->json([
            'status' => true,
            'message' => 'Cities retrieved successfully.',
            'data' => [
                'cities' => CityResource::collection($cities),
                'meta' => [
                    'current_page' => $cities->currentPage(),
                    'last_page' => $cities->lastPage(),
                    'per_page' => $cities->perPage(),
                    'total' => $cities->total(),
                    'from' => $cities->firstItem(),
                    'to' => $cities->lastItem(),
                ],
            ],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $city = $this->service->findById($id);

        return response()->json([
            'status' => true,
            'message' => 'City retrieved successfully.',
            'data' => ['city' => new CityResource($city)],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'state_id' => ['required', 'integer', 'exists:states,id'],
            'is_active' => ['boolean'],
        ]);

        $city = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'City created successfully.',
            'data' => ['city' => new CityResource($city)],
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $city = $this->service->findById($id);
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'state_id' => ['sometimes', 'integer', 'exists:states,id'],
            'is_active' => ['boolean'],
        ]);

        $city = $this->service->update($city, $validated);

        return response()->json([
            'status' => true,
            'message' => 'City updated successfully.',
            'data' => ['city' => new CityResource($city)],
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $city = $this->service->findById($id);
        $this->service->delete($city);

        return response()->json([
            'status' => true,
            'message' => 'City deleted successfully.',
            'data' => [],
        ]);
    }

    public function toggle(int $id): JsonResponse
    {
        $city = $this->service->findById($id);
        $city = $this->service->toggleActive($city);

        return response()->json([
            'status' => true,
            'message' => 'City status updated.',
            'data' => ['city' => new CityResource($city)],
        ]);
    }
}
