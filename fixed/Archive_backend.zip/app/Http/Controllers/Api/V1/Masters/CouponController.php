<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\CouponResource;
use App\Models\Coupon;
use App\Services\V1\Masters\CouponService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CouponController extends Controller
{
    public function __construct(protected CouponService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
            'per_page' => 'nullable|integer|min:10|max:100',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $coupons = $this->service->getAll(
            $request->only(['search', 'is_active', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Coupons retrieved.',
            'data' => [
                'data' => CouponResource::collection($coupons->items()),
                'meta' => [
                    'current_page' => $coupons->currentPage(),
                    'last_page' => $coupons->lastPage(),
                    'per_page' => $coupons->perPage(),
                    'total' => $coupons->total(),
                    'from' => $coupons->firstItem(),
                    'to' => $coupons->lastItem(),
                ],
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'code' => 'required|string|max:32|unique:coupons,code|regex:/^[A-Z0-9_]+$/',
            'description' => 'nullable|string|max:255',
            'type' => 'required|in:flat,percent',
            'value' => 'required|numeric|min:0.01',
            'min_order_amount' => 'nullable|numeric|min:0',
            'max_discount_amount' => 'nullable|numeric|min:0',
            'usage_limit_total' => 'nullable|integer|min:1',
            'usage_limit_per_customer' => 'nullable|integer|min:1',
            'valid_from' => 'required|date',
            'valid_until' => 'nullable|date|after_or_equal:valid_from',
            'is_first_order_only' => 'boolean',
            'is_active' => 'boolean',
        ]);

        if ($validated['type'] === 'percent' && $validated['value'] > 100) {
            return response()->json([
                'status' => false,
                'message' => 'Percent discount cannot exceed 100.',
            ], 422);
        }

        $coupon = Coupon::create([
            ...$validated,
            'min_order_amount' => $validated['min_order_amount'] ?? 0,
            'is_first_order_only' => $validated['is_first_order_only'] ?? false,
            'is_active' => $validated['is_active'] ?? true,
            'created_by' => Auth::id(),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Coupon created.',
            'data' => ['coupon' => new CouponResource($coupon)],
        ], 201);
    }

    public function show(Coupon $coupon): JsonResponse
    {
        $coupon->loadCount('usages');

        return response()->json([
            'status' => true,
            'data' => ['coupon' => new CouponResource($coupon)],
        ]);
    }

    public function update(Request $request, Coupon $coupon): JsonResponse
    {
        $validated = $request->validate([
            'code' => "sometimes|string|max:32|unique:coupons,code,{$coupon->id}|regex:/^[A-Z0-9_]+$/",
            'description' => 'nullable|string|max:255',
            'type' => 'sometimes|in:flat,percent',
            'value' => 'sometimes|numeric|min:0.01',
            'min_order_amount' => 'nullable|numeric|min:0',
            'max_discount_amount' => 'nullable|numeric|min:0',
            'usage_limit_total' => 'nullable|integer|min:1',
            'usage_limit_per_customer' => 'nullable|integer|min:1',
            'valid_from' => 'sometimes|date',
            'valid_until' => 'nullable|date|after_or_equal:valid_from',
            'is_first_order_only' => 'boolean',
            'is_active' => 'boolean',
        ]);

        $type = $validated['type'] ?? $coupon->type;
        $value = $validated['value'] ?? $coupon->value;

        if ($type === 'percent' && $value > 100) {
            return response()->json([
                'status' => false,
                'message' => 'Percent discount cannot exceed 100.',
            ], 422);
        }

        $coupon->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Coupon updated.',
            'data' => ['coupon' => new CouponResource($coupon)],
        ]);
    }

    public function destroy(Coupon $coupon): JsonResponse
    {
        if ($coupon->used_count > 0) {
            return response()->json([
                'status' => false,
                'message' => 'Cannot delete a coupon that has been used.',
            ], 422);
        }

        $coupon->delete();

        return response()->json([
            'status' => true,
            'message' => 'Coupon deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Coupon $coupon): JsonResponse
    {
        $coupon->update(['is_active' => ! $coupon->is_active]);

        return response()->json([
            'status' => true,
            'message' => 'Coupon status updated.',
            'data' => ['coupon' => new CouponResource($coupon)],
        ]);
    }
}
