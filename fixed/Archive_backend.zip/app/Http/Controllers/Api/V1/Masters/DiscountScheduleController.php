<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\DiscountScheduleResource;
use App\Models\DiscountSchedule;
use App\Models\ProductVariant;
use App\Services\V1\Masters\DiscountScheduleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DiscountScheduleController extends Controller
{
    public function __construct(protected DiscountScheduleService $service) {}

    // GET /variants/{variant}/discount-schedules
    public function index(Request $request, ProductVariant $variant): JsonResponse
    {
        $schedules = $this->service->getAllForVariant($variant, $request->only(['status', 'per_page']));

        return response()->json([
            'status' => true,
            'message' => 'Discount schedules fetched.',
            'data' => DiscountScheduleResource::collection($schedules)->response()->getData(true),
        ]);
    }

    // POST /variants/{variant}/discount-schedules
    public function store(Request $request, ProductVariant $variant): JsonResponse
    {
        $validated = $request->validate([
            'discount_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'starts_on' => ['required', 'date'],
            'ends_on' => ['nullable', 'date'],
        ]);

        $schedule = $this->service->create($variant, $validated, $request->user()->id);

        return response()->json([
            'status' => true,
            'message' => 'Discount schedule created.',
            'data' => ['schedule' => new DiscountScheduleResource($schedule)],
        ], 201);
    }

    // PUT /discount-schedules/{schedule}
    public function update(Request $request, DiscountSchedule $schedule): JsonResponse
    {
        $validated = $request->validate([
            'discount_percent' => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'starts_on' => ['sometimes', 'date'],
            'ends_on' => ['nullable', 'date'],
        ]);

        $schedule = $this->service->update($schedule, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Discount schedule updated.',
            'data' => ['schedule' => new DiscountScheduleResource($schedule)],
        ]);
    }

    // PATCH /discount-schedules/{schedule}/cancel
    public function cancel(DiscountSchedule $schedule): JsonResponse
    {
        $schedule = $this->service->cancel($schedule);

        return response()->json([
            'status' => true,
            'message' => 'Discount schedule cancelled.',
            'data' => ['schedule' => new DiscountScheduleResource($schedule)],
        ]);
    }
}
