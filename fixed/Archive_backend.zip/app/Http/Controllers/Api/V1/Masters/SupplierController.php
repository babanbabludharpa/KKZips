<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\SupplierResource;
use App\Models\Supplier;
use App\Services\V1\Masters\SupplierService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    public function __construct(protected SupplierService $service) {}

    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'search' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
            'per_page' => 'nullable|integer|min:10|max:500',
            'sort_key' => 'nullable|string|max:50',
            'sort_dir' => 'nullable|in:asc,desc',
        ]);

        $suppliers = $this->service->getAll(
            $request->only(['search', 'is_active', 'per_page', 'sort_key', 'sort_dir'])
        );

        return response()->json([
            'status' => true,
            'message' => 'Suppliers fetched.',
            'data' => SupplierResource::collection($suppliers)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate($this->rules());

        $supplier = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Supplier created.',
            'data' => ['supplier' => new SupplierResource($supplier)],
        ], 201);
    }

    public function show(Supplier $supplier): JsonResponse
    {
        $supplier->load('creator:id,name');

        return response()->json([
            'status' => true,
            'message' => 'Supplier fetched.',
            'data' => ['supplier' => new SupplierResource($supplier)],
        ]);
    }

    public function update(Request $request, Supplier $supplier): JsonResponse
    {
        $validated = $request->validate($this->rules(isUpdate: true));

        $supplier = $this->service->update($supplier, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Supplier updated.',
            'data' => ['supplier' => new SupplierResource($supplier)],
        ]);
    }

    public function destroy(Supplier $supplier): JsonResponse
    {
        $this->service->delete($supplier);

        return response()->json([
            'status' => true,
            'message' => 'Supplier deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Supplier $supplier): JsonResponse
    {
        $supplier = $this->service->toggleActive($supplier);

        return response()->json([
            'status' => true,
            'message' => 'Supplier status updated.',
            'data' => ['supplier' => new SupplierResource($supplier)],
        ]);
    }

    private function rules(bool $isUpdate = false): array
    {
        $required = $isUpdate ? 'sometimes' : 'required';
        $docRules = ['file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'];
        $docNullable = ['nullable', ...$docRules];

        return [
            'name' => [$required, 'string', 'max:150'],
            'contact_person' => ['nullable', 'string', 'max:100'],
            'phone' => [$required, 'string', 'max:20'],
            'alternate_phone' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:100'],
            'address' => ['nullable', 'string'],
            'gst_no' => ['nullable', 'string', 'max:20'],
            'registration_no' => ['nullable', 'string', 'max:100'],
            'pan_no' => ['nullable', 'string', 'max:20'],
            'fssai_no' => ['nullable', 'string', 'max:30'],
            'adhar_no' => [$required, 'string', 'max:20'],
            'shopact_no' => ['nullable', 'string', 'max:50'],
            'registration_doc' => $docNullable,
            'gst_doc' => $docNullable,
            'pan_doc' => $docNullable,
            'fssai_doc' => $docNullable,
            'adhar_doc' => $isUpdate ? $docNullable : ['required', ...$docRules],
            'shopact_doc' => $docNullable,
            'is_active' => ['boolean'],
        ];
    }
}
