<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\UnitResource;
use App\Models\Unit;
use App\Services\V1\Masters\UnitService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UnitController extends Controller
{
    public function __construct(protected UnitService $service) {}

    public function index(Request $request): JsonResponse
    {
        $units = $this->service->getAll($request->only(['search', 'is_active', 'per_page']));

        return response()->json([
            'status' => true,
            'message' => 'Units fetched.',
            'data' => UnitResource::collection($units)->response()->getData(true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:50'],
            'abbreviation' => ['required', 'string', 'max:20'],
            'is_active' => ['boolean'],
        ]);

        $unit = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Unit created.',
            'data' => ['unit' => new UnitResource($unit)],
        ], 201);
    }

    public function show(Unit $unit): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Unit fetched.',
            'data' => ['unit' => new UnitResource($unit)],
        ]);
    }

    public function update(Request $request, Unit $unit): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:50'],
            'abbreviation' => ['sometimes', 'string', 'max:20'],
            'is_active' => ['boolean'],
        ]);

        $unit = $this->service->update($unit, $validated);

        return response()->json([
            'status' => true,
            'message' => 'Unit updated.',
            'data' => ['unit' => new UnitResource($unit)],
        ]);
    }

    public function destroy(Unit $unit): JsonResponse
    {
        $this->service->delete($unit);

        return response()->json([
            'status' => true,
            'message' => 'Unit deleted.',
            'data' => [],
        ]);
    }

    public function toggle(Unit $unit): JsonResponse
    {
        $unit = $this->service->toggleActive($unit);

        return response()->json([
            'status' => true,
            'message' => 'Unit status updated.',
            'data' => ['unit' => new UnitResource($unit)],
        ]);
    }
}
