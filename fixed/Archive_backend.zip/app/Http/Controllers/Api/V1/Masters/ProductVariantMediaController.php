<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Models\ProductVariant;
use App\Models\ProductVariantMedia;
use App\Services\V1\Masters\ProductVariantMediaService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductVariantMediaController extends Controller
{
    public function __construct(protected ProductVariantMediaService $service) {}

    // GET /variants/{variant}/media
    public function index(ProductVariant $variant): JsonResponse
    {
        return response()->json([
            'status' => true,
            'message' => 'Variant media fetched.',
            'data' => ['media' => $this->mapMediaList($variant)],
        ]);
    }

    // POST /variants/{variant}/media   (one file per request: file + type)
    public function store(Request $request, ProductVariant $variant): JsonResponse
    {
        // Size/mime limits depend on the submitted type.
        // `max` uses KILOBYTES: 4096 = 4 MB (images), 51200 = 50 MB (videos).
        $rules = [
            'file' => ['required', 'file'],
            'type' => ['required', 'in:image,video'],
        ];

        if ($request->input('type') === 'video') {
            $rules['file'][] = 'mimes:mp4,mov,webm,avi,mkv';
            $rules['file'][] = 'max:51200';
        } else {
            $rules['file'][] = 'mimes:jpeg,jpg,png,webp';
            $rules['file'][] = 'max:4096';
        }

        $validated = $request->validate($rules);

        $this->service->add($variant, $request->file('file'), $validated['type']);

        return response()->json([
            'status' => true,
            'message' => 'Media uploaded.',
            'data' => ['media' => $this->mapMediaList($variant)],
        ], 201);
    }

    // PATCH /variants/{variant}/media/reorder
    public function reorder(Request $request, ProductVariant $variant): JsonResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array'],
            'ids.*' => ['integer'],
        ]);

        $this->service->reorder($variant, $validated['ids']);

        return response()->json([
            'status' => true,
            'message' => 'Media order updated.',
            'data' => ['media' => $this->mapMediaList($variant)],
        ]);
    }

    // DELETE /variants/{variant}/media/{media}
    public function destroy(ProductVariant $variant, ProductVariantMedia $media): JsonResponse
    {
        // Both models are route-bound; make sure the media row really
        // belongs to this variant before deleting.
        abort_unless($media->product_variant_id === $variant->id, 404);

        $this->service->remove($media);

        return response()->json([
            'status' => true,
            'message' => 'Media deleted.',
            'data' => ['media' => $this->mapMediaList($variant)],
        ]);
    }

    private function mapMediaList(ProductVariant $variant): array
    {
        return $this->service->list($variant)
            ->map(fn ($m) => $this->mapMedia($m))
            ->all();
    }

    private function mapMedia(ProductVariantMedia $m): array
    {
        return [
            'id' => $m->id,
            'type' => $m->type,
            'url' => $m->url,
            'original_name' => $m->original_name,
            'size' => (int) $m->size,
            'sort_order' => (int) $m->sort_order,
        ];
    }
}
