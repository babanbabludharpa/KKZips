<?php

namespace App\Http\Controllers\Api\V1\Masters;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\DeliveryChargeRuleResource;
use App\Models\DeliveryChargeRule;
use App\Services\V1\Masters\DeliveryChargeRuleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class DeliveryChargeController extends Controller
{
    public function __construct(protected DeliveryChargeRuleService $service) {}

    public function index(): JsonResponse
    {
        $rules = DeliveryChargeRule::orderByDesc('created_at')->get();

        return response()->json([
            'status' => true,
            'data' => DeliveryChargeRuleResource::collection($rules),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100|unique:delivery_charge_rules,name',
            'min_order_amount' => 'nullable|numeric|min:0',
            'free_delivery_above' => 'nullable|numeric|min:0',
            'base_charge' => 'required|numeric|min:0',
            'per_km_charge' => 'nullable|numeric|min:0',
            'max_charge' => 'nullable|numeric|min:0',
            'max_delivery_km' => 'nullable|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        $this->assertChargeConsistency($validated);

        $rule = $this->service->create($validated);

        return response()->json([
            'status' => true,
            'message' => 'Delivery charge rule created.',
            'data' => ['rule' => new DeliveryChargeRuleResource($rule)],
        ], 201);
    }

    public function show(DeliveryChargeRule $deliveryChargeRule): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => ['rule' => new DeliveryChargeRuleResource($deliveryChargeRule)],
        ]);
    }

    public function update(Request $request, DeliveryChargeRule $deliveryChargeRule): JsonResponse
    {
        $validated = $request->validate([
            'name' => "sometimes|string|max:100|unique:delivery_charge_rules,name,{$deliveryChargeRule->id}",
            'min_order_amount' => 'nullable|numeric|min:0',
            'free_delivery_above' => 'nullable|numeric|min:0',
            'base_charge' => 'sometimes|numeric|min:0',
            'per_km_charge' => 'nullable|numeric|min:0',
            'max_charge' => 'nullable|numeric|min:0',
            'max_delivery_km' => 'nullable|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        $this->assertChargeConsistency([
            'base_charge' => $validated['base_charge'] ?? $deliveryChargeRule->base_charge,
            'max_charge' => array_key_exists('max_charge', $validated) ? $validated['max_charge'] : $deliveryChargeRule->max_charge,
        ]);

        try {
            $rule = $this->service->update($deliveryChargeRule, $validated);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'errors' => $e->errors(),
            ], 422);
        }

        return response()->json([
            'status' => true,
            'message' => 'Delivery charge rule updated.',
            'data' => ['rule' => new DeliveryChargeRuleResource($rule)],
        ]);
    }

    public function destroy(DeliveryChargeRule $deliveryChargeRule): JsonResponse
    {
        try {
            $this->service->delete($deliveryChargeRule);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'errors' => $e->errors(),
            ], 422);
        }

        return response()->json([
            'status' => true,
            'message' => 'Delivery charge rule deleted.',
            'data' => [],
        ]);
    }

    public function toggle(DeliveryChargeRule $deliveryChargeRule): JsonResponse
    {
        try {
            $rule = $this->service->toggle($deliveryChargeRule);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'errors' => $e->errors(),
            ], 422);
        }

        return response()->json([
            'status' => true,
            'message' => 'Status updated.',
            'data' => ['rule' => new DeliveryChargeRuleResource($rule)],
        ]);
    }

    /**
     * max_charge below base_charge makes the MIN() formula always resolve to
     * max_charge regardless of distance — a silently broken pricing rule, not
     * a validation edge case. Block it outright rather than warn-and-allow.
     */
    protected function assertChargeConsistency(array $data): void
    {
        if (isset($data['max_charge']) && $data['max_charge'] !== null
            && (float) $data['max_charge'] < (float) $data['base_charge']) {
            throw ValidationException::withMessages([
                'max_charge' => 'Max charge cannot be lower than base charge — it would make the formula ignore distance entirely.',
            ]);
        }
    }
}
