<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionOccurrenceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subscription_item_id' => $this->subscription_item_id,
            'product_name' => $this->whenLoaded('subscriptionItem', fn () => $this->subscriptionItem->productVariant->product->name ?? null),
            'customer_name' => $this->whenLoaded('subscriptionItem', fn () => $this->subscriptionItem->subscription->customer->name ?? null),
            'slot' => $this->whenLoaded('subscriptionItem', fn () => $this->buildSlotPayload()),
            'delivery_address' => $this->whenLoaded('subscriptionItem', function () {
                $addr = $this->subscriptionItem->subscription->deliveryAddress ?? null;
                if (! $addr) {
                    return null;
                }

                return trim(implode(', ', array_filter([
                    $addr->address_line1,
                    $addr->address_line2,
                    $addr->city,
                ])));
            }),
            'occurrence_date' => $this->occurrence_date?->toDateString(),
            'qty' => $this->qty,
            'unit_price_snapshot' => $this->unit_price_snapshot,
            'status' => $this->status,
            'skip_source' => $this->skip_source,
            'not_delivered_reason' => $this->not_delivered_reason,
            'not_delivered_note' => $this->not_delivered_note,
            'delivery_boy_id' => $this->delivery_boy_id,
            'delivery_boy_name' => $this->whenLoaded('deliveryBoy', fn () => $this->deliveryBoy?->name),
            'assignment_type' => $this->assignment_type,
            'assigned_by' => $this->assigned_by,
            'assigned_at' => $this->assigned_at,
            'delivered_at' => $this->delivered_at,
            'invoice_id' => $this->invoice_id,
            'is_locked' => $this->isLocked(),
            'zone_id'   => $this->subscriptionItem?->subscription?->deliveryAddress?->zone_id,
            'zone_name' => $this->subscriptionItem?->subscription?->deliveryAddress?->zone?->name,

            // ★ Leave-related fields — surface the reason to the customer.
            'leave_id'                  => $this->leave_id,
            'leave_previous_status'     => $this->leave_previous_status,
            'leave_cancellation_reason' => $this->leave_cancellation_reason,
        ];
    }

    private function buildSlotPayload(): ?array
    {
        $slot = $this->subscriptionItem?->slot;

        if (! $slot) {
            return null;
        }

        return [
            'id' => $slot->id,
            'name' => $slot->name,
            'start_time' => $slot->start_time,
            'end_time' => $slot->end_time,
        ];
    }
}
