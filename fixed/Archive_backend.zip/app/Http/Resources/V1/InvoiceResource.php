<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'customer_id' => $this->customer_id,
            'customer_name' => $this->whenLoaded('customer', fn () => $this->customer->name),
            'customer_phone' => $this->whenLoaded('customer', fn () => $this->customer->phone),
            'period_start' => $this->period_start?->toDateString(),
            'period_end' => $this->period_end?->toDateString(),
            'subtotal' => $this->subtotal,
            'cgst_total' => $this->cgst_total,
            'sgst_total' => $this->sgst_total,
            'igst_total' => $this->igst_total,
            'tax_total' => $this->tax_total,
            'manual_adjustment_amount' => $this->manual_adjustment_amount,
            'manual_adjustment_reason' => $this->manual_adjustment_reason,
            'total' => $this->total,
            'amount_paid' => $this->amount_paid,
            'amount_due' => $this->amount_due,
            'status' => $this->status,
            'generated_at' => $this->generated_at,
            'cancelled_at' => $this->cancelled_at,
            'cancellation_reason' => $this->cancellation_reason,
            'items' => InvoiceItemResource::collection($this->whenLoaded('items')),
            'payments' => InvoicePaymentResource::collection($this->whenLoaded('payments')),
        ];
    }
}
