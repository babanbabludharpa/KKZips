<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RoleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'guard_name' => $this->guard_name,
            'permissions' => PermissionResource::collection(
                $this->whenLoaded('permissions')
            ),
            'users_count' => $this->when(
                isset($this->users_count),
                $this->users_count
            ),
            'created_at' => $this->created_at->toDateTimeString(),
        ];
    }
}
