<?php

namespace App\Http\Resources\V1;

use App\Services\V1\Tenant\TenantProfileService;
use Illuminate\Http\Resources\Json\JsonResource;

class TenantProfileResource extends JsonResource
{
    public function toArray($request): array
    {
        $service = app(TenantProfileService::class);

        return [
            'id' => $this->id,
            'company_name' => $this->company_name,
            'pan_no' => $this->pan_no,

            'has_orders' => (bool) ($this->has_orders ?? true),
            'use_order_slots' => (bool) ($this->use_order_slots ?? false),
            'has_subscriptions' => (bool) ($this->has_subscriptions ?? true),
            'has_wallet' => (bool) ($this->has_wallet ?? true),

            'logo' => $this->logo,
            'logo_url' => $service->getLogoUrl($this->logo),
            'cod_enabled' => (bool) $this->cod_enabled,
            'online_payment_enabled' => (bool) $this->online_payment_enabled,

            'subscription_cutoff_time' => $this->subscription_cutoff_time
                ? substr($this->subscription_cutoff_time, 0, 5) : null,
            'subscription_cutoff_restrict_admin' => (bool) $this->subscription_cutoff_restrict_admin,
            'subscription_start_policy' => $this->subscription_start_policy ?? 'next_day_only',
            'same_day_lead_time_minutes' => (int) ($this->same_day_lead_time_minutes ?? 120),

            'order_start_policy' => $this->order_start_policy ?? 'next_day_only',
            'order_same_day_lead_time_minutes' => (int) ($this->order_same_day_lead_time_minutes ?? 120),
            'slot_wise_cutoff_enabled' => (bool) $this->slot_wise_cutoff_enabled,
            'slot_cutoff_offset_minutes' => (int) ($this->slot_cutoff_offset_minutes ?? 120),

            'rider_assignment_time' => $this->rider_assignment_time
                ? substr($this->rider_assignment_time, 0, 5) : '21:00',
            'last_assignment_run' => $this->last_assignment_run?->toDateString(),
            'order_stock_check_enabled' => (bool) $this->order_stock_check_enabled,
            'subscription_stock_check_enabled' => (bool) $this->subscription_stock_check_enabled,

            'pusher_app_id' => $this->pusher_app_id,
            'pusher_key' => $this->pusher_key,
            'pusher_cluster' => $this->pusher_cluster,
            'pusher_configured' => (bool) ($this->pusher_key && $this->pusher_secret),

            'razorpay_key_id' => $this->razorpay_key_id,
            'razorpay_is_live' => (bool) $this->razorpay_is_live,
            'razorpay_configured' => (bool) (
                $this->razorpay_key_id && $this->razorpay_key_secret && $this->razorpay_webhook_secret
            ),

            'sms_username' => $this->sms_username,
            'sms_sender_id' => $this->sms_sender_id,
            'sms_enabled' => (bool) ($this->sms_enabled ?? true),
            'sms_configured' => (bool) ($this->sms_username && $this->sms_password && $this->sms_sender_id),

            // ★ new — channel toggles
            'sms_channel_enabled' => (bool) $this->sms_channel_enabled,
            'notification_channel_enabled' => (bool) ($this->notification_channel_enabled ?? true),
            'whatsapp_channel_enabled' => (bool) $this->whatsapp_channel_enabled,
            'whatsapp_phone_number' => $this->whatsapp_phone_number,
            'whatsapp_configured' => (bool) ($this->whatsapp_api_key && $this->whatsapp_phone_number),
            'email_channel_enabled' => (bool) ($this->email_channel_enabled ?? true),

            // ★ new — wallet & delivery note (rupees for UI)
            'wallet_warning_limit' => $this->wallet_warning_limit / 100,
            'wallet_suspension_limit' => $this->wallet_suspension_limit / 100,
            'delivery_note_min_days' => (int) $this->delivery_note_min_days,
            'delivery_note_max_days' => (int) $this->delivery_note_max_days,
            'delivery_note_text' => $this->delivery_note_text,

            'support_phone' => $this->support_phone,
            'support_email' => $this->support_email,
            'support_hours' => $this->support_hours,

            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
