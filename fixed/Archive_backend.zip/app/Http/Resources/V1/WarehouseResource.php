<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class WarehouseResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'address' => $this->address,
            'city_id' => $this->city_id,
            'city_name' => $this->city?->name,
            'state_id' => $this->state_id,
            'state_name' => $this->state?->name,
            'pincode' => $this->pincode,
            'gst_no' => $this->gst_no,
            'fssai_no' => $this->fssai_no,
            'phone' => $this->phone,
            'contact_email' => $this->contact_email,
            'is_primary' => $this->is_primary,
            'is_active' => $this->is_active,
        ];
    }
}
