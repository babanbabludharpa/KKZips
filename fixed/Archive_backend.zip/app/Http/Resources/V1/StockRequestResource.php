<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class StockRequestResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'from_branch_id' => $this->from_branch_id,
            'from_branch_name' => $this->fromBranch?->name,
            'to_branch_id' => $this->to_branch_id,
            'to_branch_name' => $this->toBranch?->name,
            'status' => $this->status,
            'requested_by' => $this->requestedBy?->name,
            'actioned_by' => $this->actionedBy?->name,
            'approved_at' => $this->approved_at?->toDateTimeString(),
            'fulfilled_at' => $this->fulfilled_at?->toDateTimeString(),
            'notes' => $this->notes,
            'items' => StockRequestItemResource::collection($this->whenLoaded('items')),
        ];
    }
}
