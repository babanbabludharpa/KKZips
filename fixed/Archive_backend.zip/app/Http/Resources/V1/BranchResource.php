<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class BranchResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'type' => $this->type,
            'parent_id' => $this->parent_id,
            'parent_name' => $this->parent?->name,
            'address' => $this->address,
            'city_id' => $this->city_id,
            'city_name' => $this->city?->name,
            'state_id' => $this->state_id,
            'state_name' => $this->state?->name,
            'pincode' => $this->pincode,
            'gst_no' => $this->gst_no,
            'fssai_no' => $this->fssai_no,
            'phone' => $this->phone,
            'contact_email' => $this->contact_email,
            'is_active' => $this->is_active,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'opens_at' => $this->opens_at,
            'closes_at' => $this->closes_at,
            'is_accepting_orders' => $this->is_accepting_orders,
            'zone_count' => $this->zone_count ?? null,
        ];
    }
}
