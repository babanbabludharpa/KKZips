<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductVariantResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'product_id' => $this->product_id,
            'sku' => $this->sku,
            'unit_id' => $this->unit_id,
            'unit_name' => $this->unit?->name,
            'unit_abbreviation' => $this->unit?->abbreviation,
            'hsn_code' => $this->hsn_code,
            'image' => $this->image,
            'image_url' => $this->image
                ? \Storage::disk('public')->url('tenants/'.tenant('id').'/variants/'.$this->image)
                : null,

            // ── Media gallery (present only when 'media' is eager-loaded) ──
            'images' => $this->whenLoaded('media', fn () => $this->media
                ->where('type', 'image')
                ->values()
                ->map(fn ($m) => $m->url)
                ->all()),
            'videos' => $this->whenLoaded('media', fn () => $this->media
                ->where('type', 'video')
                ->values()
                ->map(fn ($m) => $m->url)
                ->all()),
            'mrp' => $this->mrp,
            'purchase_price' => $this->purchase_price,
            'selling_price' => $this->selling_price,
            'final_price' => $this->final_price,
            'is_discount_active' => $this->is_discount_active,
            'active_discount_percent' => $this->is_discount_active
                ? $this->active_discount_percent
                : null,
            'is_coupon_eligible' => $this->is_coupon_eligible,

            // ── Channel flags ───────────────────────────────────────
            'available_for_order' => $this->available_for_order,
            'available_for_subscription' => $this->available_for_subscription,
            'channel' => $this->channel_label,

            'tax_rate_id' => $this->tax_rate_id,
            'tax_label' => $this->taxRate?->label,
            'min_order_qty' => $this->min_order_qty,
            'is_active' => $this->is_active,
            'attributes' => $this->whenLoaded('attributeValues', function () {
                return $this->attributeValues->map(fn ($av) => [
                    'value_id' => $av->id,
                    'attribute_id' => $av->attribute_id,
                    'attribute_name' => $av->attribute?->name,
                    'value' => $av->value,
                ]);
            }),
        ];
    }
}
