<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class StockInwardItemResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'product_variant_id' => $this->product_variant_id,
            'sku' => $this->variant?->sku,
            'product_name' => $this->variant?->product?->name,
            'quantity' => $this->quantity,
            'expiry_date' => $this->expiry_date?->toDateString(),
        ];
    }
}
