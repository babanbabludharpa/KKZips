<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'customer_id' => $this->customer_id,
            'customer_name' => $this->whenLoaded('customer', fn () => $this->customer->name),
            'branch_id' => $this->branch_id,
            'branch_name' => $this->whenLoaded('branch', fn () => $this->branch->name),
            'delivery_address_id' => $this->delivery_address_id,
            'delivery_address' => $this->whenLoaded('deliveryAddress', fn () => [
                'label' => $this->deliveryAddress->label,
                'address_line1' => $this->deliveryAddress->address_line1,
                'city' => $this->deliveryAddress->city,
                'state' => $this->deliveryAddress->state,
            ]),
            'delivery_boy_id' => $this->delivery_boy_id,
            'status' => $this->status,
            'start_date' => $this->start_date?->toDateString(),
            'end_date' => $this->end_date?->toDateString(),
            'items' => SubscriptionItemResource::collection($this->whenLoaded('items')),
            'created_at' => $this->created_at,
            'last_billed_occurrence_date' => $this->items()
                ->join('subscription_occurrences', 'subscription_occurrences.subscription_item_id', '=', 'subscription_items.id')
                ->whereNotNull('subscription_occurrences.invoice_id')
                ->max('subscription_occurrences.occurrence_date'),
        ];
    }
}
