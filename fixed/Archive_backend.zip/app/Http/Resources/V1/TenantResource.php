<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TenantResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'plan' => $this->plan,
            'status' => $this->status,
            'theme_key' => $this->theme_key ?? 'crimson', // real column
            // The slug domain row always has domain === tenant id (set in
            // TenantController::store()). Prefer any OTHER domain row as the
            // customer-facing one; fall back to the slug if none exists yet.
            'domain' => $this->domains
                ->first(fn ($d) => $d->domain !== $this->id)
                ?->domain ?? $this->domains->first()?->domain,
            // Full list — required by the edit modal's domain management UI.
            'domains' => $this->domains->map(fn ($d) => [
                'id' => $d->id,
                'domain' => $d->domain,
            ])->values(),
            'created_at' => $this->created_at?->toDateTimeString(),
            'updated_at' => $this->updated_at?->toDateTimeString(),
        ];
    }
}
