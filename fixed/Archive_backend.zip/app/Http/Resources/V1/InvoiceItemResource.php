<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceItemResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subscription_occurrence_id' => $this->subscription_occurrence_id,
            'description' => $this->description,
            'qty' => $this->qty,
            'unit_price' => $this->unit_price,
            'final_price' => $this->final_price,
            'tax_rate_percent' => $this->tax_rate_percent,
            'taxable_value' => $this->taxable_value,
            'tax_type' => $this->tax_type,
            'cgst_amount' => $this->cgst_amount,
            'sgst_amount' => $this->sgst_amount,
            'igst_amount' => $this->igst_amount,
            'tax_amount' => $this->tax_amount,
            'line_total' => $this->line_total,
        ];
    }
}
