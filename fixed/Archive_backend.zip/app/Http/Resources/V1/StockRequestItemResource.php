<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class StockRequestItemResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'product_variant_id' => $this->product_variant_id,
            'sku' => $this->variant?->sku,
            'product_name' => $this->variant?->product?->name,
            'unit_abbreviation' => $this->variant?->unit?->abbreviation,
            'quantity_requested' => $this->quantity_requested,
            'quantity_approved' => $this->quantity_approved,
            'quantity_fulfilled' => $this->quantity_fulfilled,
        ];
    }
}
