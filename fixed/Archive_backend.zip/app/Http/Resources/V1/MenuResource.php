<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MenuResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'route' => $this->route,
            'icon' => $this->icon,
            'parent_id' => $this->parent_id,
            'permission' => $this->permission,
            'sort_order' => $this->sort_order,
            'is_active' => $this->is_active,
            'children' => MenuResource::collection($this->whenLoaded('children')),
        ];
    }
}
