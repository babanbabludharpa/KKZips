<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class SubscriptionItemResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subscription_id' => $this->subscription_id,
            'product_variant_id' => $this->product_variant_id,
            'product_name' => $this->whenLoaded('productVariant', fn () => $this->productVariant?->product->name ?? null),
            'variant_sku' => $this->whenLoaded('productVariant', fn () => $this->productVariant?->sku),
            'variant' => $this->whenLoaded('productVariant', fn () => $this->buildVariantPayload()),
            'default_qty' => $this->default_qty,
            'slot_id' => $this->slot_id,
            'slot' => $this->whenLoaded('slot', fn () => $this->buildSlotPayload()),
            'schedule_type' => $this->schedule_type,
            'schedule_days' => $this->schedule_days,
            'qty_by_day' => $this->qty_by_day,
            'status' => $this->status,
        ];
    }

    private function buildSlotPayload(): ?array
    {
        $slot = $this->slot;

        if (! $slot) {
            return null;
        }

        return [
            'id' => $slot->id,
            'name' => $slot->name,
            'start_time' => $slot->start_time,
            'end_time' => $slot->end_time,
        ];
    }

    private function buildVariantPayload(): ?array
    {
        $variant = $this->productVariant;

        if (! $variant) {
            return null;
        }

        return [
            'id' => $variant->id,
            'sku' => $variant->sku,
            'mrp' => $variant->mrp,
            'selling_price' => $variant->selling_price,
            'final_price' => $variant->selling_price,
            'image_url' => $this->buildVariantImageUrl($variant),
            'attributes' => $this->buildVariantAttributes($variant),
        ];
    }

    private function buildVariantImageUrl($variant): ?string
    {
        if (! $variant->image) {
            return null;
        }

        return Storage::disk('public')->url('tenants/'.tenant('id').'/variants/'.$variant->image);
    }

    private function buildVariantAttributes($variant): array
    {
        if (! $variant->relationLoaded('attributeValues')) {
            return [];
        }

        return $variant->attributeValues->map(fn ($av) => [
            'value_id' => $av->id,
            'attribute_id' => $av->attribute_id,
            'attribute_name' => $av->attribute?->name,
            'value' => $av->value,
        ])->toArray();
    }
}
