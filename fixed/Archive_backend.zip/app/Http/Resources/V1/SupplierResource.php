<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class SupplierResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'contact_person' => $this->contact_person,
            'phone' => $this->phone,
            'alternate_phone' => $this->alternate_phone,
            'email' => $this->email,
            'address' => $this->address,
            'gst_no' => $this->gst_no,
            'registration_no' => $this->registration_no,
            'pan_no' => $this->pan_no,
            'fssai_no' => $this->fssai_no,
            'adhar_no' => $this->adhar_no,
            'shopact_no' => $this->shopact_no,
            'registration_doc' => $this->documentUrl($this->registration_doc),
            'gst_doc' => $this->documentUrl($this->gst_doc),
            'pan_doc' => $this->documentUrl($this->pan_doc),
            'fssai_doc' => $this->documentUrl($this->fssai_doc),
            'adhar_doc' => $this->documentUrl($this->adhar_doc),
            'shopact_doc' => $this->documentUrl($this->shopact_doc),
            'is_active' => $this->is_active,
            'created_by' => $this->created_by,
            'creator_name' => $this->whenLoaded('creator', fn () => $this->creator?->name),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }

    private function documentUrl(?string $path): ?string
    {
        return $path ? Storage::disk('public')->url($path) : null;
    }
}
