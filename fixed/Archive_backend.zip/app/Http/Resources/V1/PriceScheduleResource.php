<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class PriceScheduleResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'product_variant_id' => $this->product_variant_id,
            'mrp' => $this->mrp,
            'selling_price' => $this->selling_price,
            'purchase_price' => $this->purchase_price,
            'effective_from' => $this->effective_from?->toDateString(),
            'status' => $this->status,
            'created_by' => $this->createdBy?->name,
        ];
    }
}
