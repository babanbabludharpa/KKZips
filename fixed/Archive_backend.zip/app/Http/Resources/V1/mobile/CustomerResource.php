<?php

namespace App\Http\Resources\V1\mobile;

use Illuminate\Http\Resources\Json\JsonResource;

class CustomerResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'profile_photo' => $this->profile_photo
                                        ? asset('storage/'.$this->profile_photo)
                                        : null,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'location_permission' => $this->location_permission,
            'status' => $this->status,
            'email_verified' => ! is_null($this->email_verified_at),
            'phone_verified' => $this->phone_verified,
            'default_address' => $this->whenLoaded('defaultAddress',
                fn () => new CustomerAddressResource($this->defaultAddress)
            ),
            'created_at' => $this->created_at,
        ];
    }
}
