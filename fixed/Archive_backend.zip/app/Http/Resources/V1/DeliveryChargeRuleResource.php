<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class DeliveryChargeRuleResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'min_order_amount' => $this->min_order_amount,
            'free_delivery_above' => $this->free_delivery_above,
            'base_charge' => $this->base_charge,
            'per_km_charge' => $this->per_km_charge,
            'max_charge' => $this->max_charge,
            'max_delivery_km' => $this->max_delivery_km,
            'is_active' => $this->is_active,
            // Flags a config that will silently misbehave: if max_charge is set
            // below base_charge, MIN(max_charge, base+dist*per_km) always
            // resolves to max_charge regardless of distance. Surfacing this
            // lets the admin UI warn instead of the bug showing up as a support ticket.
            'has_inconsistent_cap' => $this->max_charge !== null
                                        && (float) $this->max_charge < (float) $this->base_charge,
            'created_at' => $this->created_at?->toDateTimeString(),
            'updated_at' => $this->updated_at?->toDateTimeString(),
        ];
    }
}
