<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoicePaymentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'amount' => $this->amount,
            'payment_mode' => $this->payment_mode,
            'received_by' => $this->received_by,
            'received_at' => $this->received_at,
            'note' => $this->note,
            'is_reversal' => $this->is_reversal,
        ];
    }
}
