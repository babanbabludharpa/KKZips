<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;

class GiftCampaignResource extends JsonResource
{
    public function toArray($request): array
    {
        $today = Carbon::today()->toDateString();

        return [
            'id' => $this->id,
            'name' => $this->name,
            'tier_mode' => $this->tier_mode,
            'threshold_basis' => $this->threshold_basis,
            'usage_limit_total' => $this->usage_limit_total,
            'usage_limit_per_customer' => $this->usage_limit_per_customer,
            'used_count' => $this->used_count,
            'remaining_uses' => $this->usage_limit_total
                ? max(0, $this->usage_limit_total - $this->used_count)
                : null,
            'valid_from' => $this->valid_from?->toDateString(),
            'valid_until' => $this->valid_until?->toDateString(),
            'is_active' => $this->is_active,
            'is_expired' => $this->valid_until
                ? $this->valid_until->toDateString() < $today
                : false,
            'usages_count' => $this->whenCounted('usages'),
            'tiers' => $this->whenLoaded('tiers', fn () => $this->tiers->map(fn ($tier) => [
                'id' => $tier->id,
                'threshold_amount' => (float) $tier->threshold_amount,
                'selection_mode' => $tier->selection_mode,
                'items' => $tier->items->map(fn ($item) => [
                    'id' => $item->id,
                    'product_variant_id' => $item->product_variant_id,
                    'quantity' => (int) $item->quantity,
                    'sku' => $item->variant?->sku,
                    'product_name' => $item->variant?->product?->name,
                    'mrp' => $item->variant ? (float) $item->variant->mrp : null,
                    'unit_abbr' => $item->variant?->unit?->abbreviation,
                    'image_url' => $item->variant?->image
                        ? \Storage::disk('public')->url('tenants/'.tenant('id').'/variants/'.$item->variant->image)
                        : null,
                    'variant_is_active' => (bool) $item->variant?->is_active,
                ]),
            ])),
            'created_by' => $this->created_by,
            'created_at' => $this->created_at?->toDateTimeString(),
            'updated_at' => $this->updated_at?->toDateTimeString(),
        ];
    }
}
