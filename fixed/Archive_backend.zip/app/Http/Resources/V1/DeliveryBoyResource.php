<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DeliveryBoyResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'                   => $this->id,
            'name'                 => $this->name,
            'username'             => $this->username,
            'email'                => $this->email,
            'mobile_number'        => $this->mobile_number,
            'branch_id'            => $this->branch_id,
            'branch_name'          => $this->whenLoaded('branch', fn() => $this->branch?->name),
            'vehicle_type'         => $this->vehicle_type,
            'max_daily_deliveries' => $this->max_daily_deliveries,
            'is_online'            => $this->is_online,
            'is_active'            => $this->is_active,

            // Full values of these never leave the server.
            'adhar_no_masked'        => $this->mask($this->adhar_no),
            'pan_no_masked'          => $this->mask($this->pan_no),
            'bank_account_no_masked' => $this->mask($this->bank_account_no),

            'emergency_contact_no' => $this->emergency_contact_no,
            'bank_account_holder'  => $this->bank_account_holder,
            'bank_name'            => $this->bank_name,
            'bank_ifsc'            => $this->bank_ifsc,
            'upi_id'               => $this->upi_id,

            // Booleans only. Files are fetched through the authorized document route.
            'documents' => [
                'adhar_doc' => $this->adhar_doc ? asset('storage/' . $this->adhar_doc) : null,
                'pan_doc' => $this->pan_doc ? asset('storage/' . $this->pan_doc) : null,
                'driving_licence_doc' => $this->driving_licence_doc ? asset('storage/' . $this->driving_licence_doc) : null,
            ],

            'zones' => $this->whenLoaded('zones', fn() => $this->zones->map(fn($z) => [
                'id'   => $z->id,
                'name' => $z->name,
            ])),
            'slots' => $this->whenLoaded('slots', fn() => $this->slots->map(fn($s) => [
                'slot_id'     => $s->id,
                'name'        => $s->name,
                'start_time'  => $s->start_time,
                'end_time'    => $s->end_time,
                'day_of_week' => $s->pivot->day_of_week,
            ])),
            'created_at' => $this->created_at,
        ];
    }

    private function mask(?string $value): ?string
    {
        if (! $value) {
            return null;
        }

        $len = strlen($value);

        return $len <= 4 ? $value : str_repeat('X', $len - 4) . substr($value, -4);
    }
}
