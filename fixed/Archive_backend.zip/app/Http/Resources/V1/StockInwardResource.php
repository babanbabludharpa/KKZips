<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class StockInwardResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'supplier_id' => $this->supplier_id,
            'supplier_name' => $this->supplier?->name,
            'branch_id' => $this->branch_id,
            'branch_name' => $this->branch?->name,
            'received_date' => $this->received_date?->toDateString(),
            'notes' => $this->notes,
            'created_by' => $this->createdBy?->name,
            'items' => StockInwardItemResource::collection($this->whenLoaded('items')),
        ];
    }
}
