<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'description' => $this->description,
            'image' => $this->image,      // raw stored path — kept for admin-side reference/debugging
            'image_url' => $this->image_url,  // resolved public URL the frontend should actually render
            'is_active' => $this->is_active,
        ];
    }
}
