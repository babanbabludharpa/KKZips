<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;

class CouponResource extends JsonResource
{
    public function toArray($request): array
    {
        $today = Carbon::today()->toDateString();

        return [
            'id' => $this->id,
            'code' => $this->code,
            'description' => $this->description,
            'type' => $this->type,
            'value' => $this->value,
            'min_order_amount' => $this->min_order_amount,
            'max_discount_amount' => $this->max_discount_amount,
            'usage_limit_total' => $this->usage_limit_total,
            'usage_limit_per_customer' => $this->usage_limit_per_customer,
            'used_count' => $this->used_count,
            'valid_from' => $this->valid_from?->toDateString(),
            'valid_until' => $this->valid_until?->toDateString(),
            'is_first_order_only' => $this->is_first_order_only,
            'is_active' => $this->is_active,
            'is_expired' => $this->valid_until
                                          ? $this->valid_until->toDateString() < $today
                                          : false,
            'remaining_uses' => $this->usage_limit_total
                                          ? max(0, $this->usage_limit_total - $this->used_count)
                                          : null,
            'created_by' => $this->created_by,
            'created_at' => $this->created_at?->toDateTimeString(),
            'updated_at' => $this->updated_at?->toDateTimeString(),
        ];
    }
}
