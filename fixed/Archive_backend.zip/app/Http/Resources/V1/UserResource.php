<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'username' => $this->username,
            'mobile_number' => $this->mobile_number,
            'role' => $this->getRoleNames()->first(),
            'branch_id' => $this->branch_id,
            'branch' => $this->whenLoaded('branch', fn () => [
                'id' => $this->branch->id,
                'name' => $this->branch->name,
            ]),
            'avatar_url' => $this->avatar_url,
            'permissions' => $this->when(
                $this->relationLoaded('permissions'),
                fn () => $this->getAllPermissions()->pluck('name')
            ),

            // Full numbers never leave the server. Documents are direct storage URLs.
            'adhar_no_masked'        => $this->mask($this->adhar_no),
            'pan_no_masked'          => $this->mask($this->pan_no),
            'bank_account_no_masked' => $this->mask($this->bank_account_no),
            'emergency_contact_no'   => $this->emergency_contact_no,
            'bank_account_holder'    => $this->bank_account_holder,
            'bank_name'              => $this->bank_name,
            'bank_ifsc'              => $this->bank_ifsc,
            'upi_id'                 => $this->upi_id,
            'has_adhar_doc'          => (bool) $this->adhar_doc,
            'has_pan_doc'            => (bool) $this->pan_doc,
            'adhar_doc_url'          => $this->adhar_doc ? asset('storage/' . $this->adhar_doc) : null,
            'pan_doc_url'            => $this->pan_doc ? asset('storage/' . $this->pan_doc) : null,

            'created_at' => optional($this->created_at)->toDateTimeString(),
        ];
    }

    private function mask(?string $value): ?string
    {
        if (! $value) {
            return null;
        }
        $len = strlen($value);

        return $len <= 4 ? $value : str_repeat('X', $len - 4) . substr($value, -4);
    }
}
