<?php

namespace App\Http\Requests\V1\Settings\Concerns;

use App\Models\DeliveryBoy;
use Illuminate\Validation\Rule;

/**
 * Use inside StoreDeliveryBoyRequest:
 *
 *   use ValidatesRiderKyc;
 *   public function rules(): array {
 *       return array_merge([ ...your existing rules... ], $this->kycRules());
 *   }
 */
trait ValidatesRiderKyc
{
    protected function kycRules(): array
    {
        $isUpdate = in_array($this->method(), ['PUT', 'PATCH'], true);
        $rider = $isUpdate ? DeliveryBoy::find($this->route('id')) : null;

        $fileRules = ['file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'];

        // Mandatory unless the rider already has one on file. Legacy riders
        // without documents are therefore forced to upload on their next edit.
        $mandatoryDoc = fn (string $field) => [
            Rule::requiredIf(! $rider?->{$field}),
            ...$fileRules,
        ];

        return [
            // Aadhaar number: on edit it may be left blank to keep the stored value.
            'adhar_no' => [Rule::requiredIf(! $rider?->adhar_no), 'nullable', 'regex:/^\d{12}$/'],
            'pan_no' => ['nullable', 'regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/'],
            'emergency_contact_no' => ['nullable', 'digits:10', 'different:mobile_number'],

            'bank_account_holder' => ['nullable', 'required_with:bank_account_no', 'string', 'max:100'],
            'bank_name' => ['nullable', 'string', 'max:100'],
            'bank_account_no' => ['nullable', 'regex:/^\d{9,18}$/'],
            'bank_ifsc' => ['nullable', 'required_with:bank_account_no', 'regex:/^[A-Z]{4}0[A-Z0-9]{6}$/'],
            'upi_id' => ['nullable', 'max:100', 'regex:/^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/'],

            'adhar_doc' => $mandatoryDoc('adhar_doc'),
            'driving_licence_doc' => $mandatoryDoc('driving_licence_doc'),
            'pan_doc' => ['nullable', ...$fileRules],
        ];
    }
}
