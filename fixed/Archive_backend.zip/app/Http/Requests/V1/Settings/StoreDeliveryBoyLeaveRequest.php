<?php

namespace App\Http\Requests\V1\Settings;

use Illuminate\Foundation\Http\FormRequest;

class StoreDeliveryBoyLeaveRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('delivery_boy.edit');
    }

    public function rules(): array
    {
        return [
            'slot_id'    => ['nullable', 'integer', 'exists:tenant_delivery_slots,id'],
            'start_date' => ['required', 'date', 'after_or_equal:today'],
            'end_date'   => [
                'required',
                'date',
                'after_or_equal:start_date',
                // If slot_id is set, end_date must equal start_date.
                function ($attribute, $value, $fail) {
                    if ($this->filled('slot_id') && $value !== $this->input('start_date')) {
                        $fail('A slot-specific leave is for a single day. Use a full-day leave for multi-day unavailability.');
                    }
                },
            ],
            'reason'     => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'start_date.after_or_equal' => 'A leave cannot start in the past.',
            'end_date.after_or_equal'   => 'End date must be on or after the start date.',
        ];
    }
}
