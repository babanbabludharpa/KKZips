<?php

namespace App\Http\Requests\V1\Settings;

use App\Http\Requests\V1\Settings\Concerns\ValidatesRiderKyc;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreDeliveryBoyRequest extends FormRequest
{
    use ValidatesRiderKyc;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $id = $this->route('id');

        return array_merge([
            'name'          => ['required', 'string', 'max:100'],
            'username'      => [
                'required', 'string', 'min:3', 'max:50',
                'regex:/^[a-z][a-z0-9_.]*$/',
                Rule::unique('delivery_boys', 'username')->ignore($id),
            ],
            'mobile_number' => [
                'required', 'string', 'regex:/^[6-9]\d{9}$/',
                Rule::unique('delivery_boys', 'mobile_number')->ignore($id),
            ],
            'email' => [
                'nullable', 'email', 'max:150',
                Rule::unique('delivery_boys', 'email')->ignore($id),
            ],
            'password'      => [$id ? 'nullable' : 'required', 'string', 'min:8'],
            'branch_id'     => ['required', 'integer', 'exists:branches,id'],
            'vehicle_type'  => ['required', 'in:bike,cycle,ev,van'],
            'max_daily_deliveries' => ['required', 'integer', 'min:1', 'max:200'],
            'zone_ids'       => ['required', 'array', 'min:1'],
            'zone_ids.*'     => ['integer', 'exists:branch_service_zones,id'],
            'slots'          => ['required', 'array'],
            'slots.*.slot_id'     => ['required', 'integer', 'exists:tenant_delivery_slots,id'],
            'slots.*.day_of_week' => ['required', 'integer', 'between:0,6'],
        ], $this->kycRules());
    }
}
