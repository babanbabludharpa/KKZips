<?php

namespace App\Http\Requests\V1\Mobile\Subscriptions;

use App\Models\SubscriptionOccurrence;
use App\Models\TenantDeliverySlot;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CustomerStoreSubscriptionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'delivery_address_id' => ['required', 'exists:customer_addresses,id'],
            'start_date' => ['required', 'date', 'after_or_equal:today'],
            'end_date' => ['nullable', 'date', 'after:start_date'],

            'items' => ['required', 'array', 'min:1'],
            'items.*.product_variant_id' => ['required', 'exists:product_variants,id'],
            'items.*.default_qty' => ['required', 'integer', 'min:1'],
            'items.*.slot_id' => [
                'required',
                'integer',
                Rule::exists('tenant_delivery_slots', 'id')->where('is_active', 1),
            ],
            'items.*.schedule_type' => ['required', 'in:daily,alternate,custom_days,custom_dates,weekly'],
            'items.*.schedule_days' => ['required_if:items.*.schedule_type,custom_days,weekly', 'array'],
            'items.*.schedule_days.*' => ['integer', 'between:0,6'],
            'items.*.schedule_dates' => ['required_if:items.*.schedule_type,custom_dates', 'array'],
            'items.*.schedule_dates.*' => ['date'],
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $startDate = $this->input('start_date');
            if ($startDate) {
                $earliest = SubscriptionOccurrence::earliestSelectableDate();
                if (Carbon::parse($startDate)->lt($earliest)) {
                    $validator->errors()->add(
                        'start_date',
                        "The earliest available start date right now is {$earliest->toDateString()}."
                    );
                }

                // Slot-time check — a slot whose window has already passed
                // for today cannot be booked. This is what prevents "create
                // a subscription at 12:00 for a 7-8 AM slot today".
                foreach ($this->input('items', []) as $index => $item) {
                    $slot = TenantDeliverySlot::find($item['slot_id'] ?? null);
                    if (! $slot) {
                        continue;
                    }
                    if (! SubscriptionOccurrence::isSlotBookableForStartDate($startDate, $slot)) {
                        $validator->errors()->add(
                            "items.{$index}.slot_id",
                            "This slot ({$slot->name}) is no longer bookable for {$startDate}. " .
                            "Choose a later slot or a future start date."
                        );
                    }
                }
            }

            foreach ($this->input('items', []) as $index => $item) {
                if (($item['schedule_type'] ?? null) === 'weekly'
                    && is_array($item['schedule_days'] ?? null)
                    && count($item['schedule_days']) !== 1) {
                    $validator->errors()->add(
                        "items.{$index}.schedule_days",
                        'Weekly items must have exactly one day selected.'
                    );
                }
            }
        });
    }
}
