<?php

namespace App\Http\Requests\V1\Mobile\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class CustomerStoreQtyOverrideRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // ownership of the item is checked in the controller
    }

    public function rules(): array
    {
        return [
            'date_from' => ['required', 'date', 'after_or_equal:today'],
            'date_to' => ['required', 'date', 'after_or_equal:date_from'],
            'qty' => ['required', 'integer', 'min:0'],
            'reason' => ['nullable', 'string', 'max:255'],
        ];
    }
}
