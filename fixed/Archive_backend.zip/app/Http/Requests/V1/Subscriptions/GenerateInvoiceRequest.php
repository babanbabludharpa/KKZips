<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class GenerateInvoiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('invoice.generate');
    }

    public function rules(): array
    {
        return [
            // required now that generation is branch-scoped. NOTE: this
            // still just validates the value EXISTS as a real branch --
            // it does NOT stop a branch-level user from passing a branch_id
            // that isn't theirs. That check has to happen separately,
            // server-side, keyed off the authenticated user's own branch --
            // see open question on how head-office vs branch users are
            // modeled, this rule alone is not sufficient authorization.
            'branch_id' => ['required', 'integer', 'exists:branches,id'],
            'start_date' => ['required', 'date', 'before_or_equal:end_date'],
            'end_date' => ['required', 'date', 'before_or_equal:today'],
            'manual_adjustment_amount' => ['nullable', 'numeric', 'min:0'],
            'manual_adjustment_reason' => ['required_with:manual_adjustment_amount', 'nullable', 'string', 'max:255'],
            // apply_wallet_amount REMOVED — wallet debit is now automatic
            // and unconditional (full invoice total, always) rather than an
            // admin-supplied partial amount. See InvoiceGenerationService.
        ];
    }
}
