<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class AssignDeliveryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('subscription.assign_delivery');
    }

    public function rules(): array
    {
        return [
            'occurrence_date' => ['required', 'date'],
            'delivery_boy_id' => ['required', 'exists:users,id'],
            'occurrence_ids' => ['required', 'array', 'min:1'],
            'occurrence_ids.*' => ['exists:subscription_occurrences,id'],
        ];
    }
}
