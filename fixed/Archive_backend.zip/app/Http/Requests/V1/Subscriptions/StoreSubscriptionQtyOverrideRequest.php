<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class StoreSubscriptionQtyOverrideRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('subscription.edit');
    }

    public function rules(): array
    {
        return [
            'date_from' => ['required', 'date'],
            'date_to' => ['required', 'date', 'after_or_equal:date_from'],
            'qty' => ['required', 'integer', 'min:0'],
            'reason' => ['nullable', 'string', 'max:255'],
        ];
    }
}
