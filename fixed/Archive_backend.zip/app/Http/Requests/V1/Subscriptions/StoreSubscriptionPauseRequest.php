<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class StoreSubscriptionPauseRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Customers pause their own items via the mobile API (separate request/controller,
        // added when the customer-app layer is built). This request is for admin-initiated
        // pauses via the tenant admin panel.
        return $this->user()->can('subscription.pause');
    }

    public function rules(): array
    {
        return [
            'date_from' => ['required', 'date'],
            'date_to' => ['required', 'date', 'after_or_equal:date_from'],
            'reason' => ['nullable', 'string', 'max:255'],
        ];
    }
}
