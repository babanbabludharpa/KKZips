<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class StoreInvoicePaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('invoice.collect_payment');
    }

    public function rules(): array
    {
        return [
            'amount' => ['required', 'numeric', 'min:0.01'],
            'payment_mode' => ['required', 'in:cash,online,upi'], // 'wallet' mode is only ever written by the system itself
            'note' => ['nullable', 'string', 'max:255'],
        ];
    }
}
