<?php

namespace App\Http\Requests\V1\Subscriptions;

use Illuminate\Foundation\Http\FormRequest;

class SubmitDeliveryResultsRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Rider must own the assignments they're submitting - enforced in the
        // controller/service (checked against auth user id), not just permission.
        return $this->user()->can('subscription.confirm_delivery');
    }

    public function rules(): array
    {
        return [
            'results' => ['required', 'array', 'min:1'],
            'results.*.delivery_assignment_id' => ['required', 'exists:delivery_assignments,id'],
            'results.*.delivered' => ['required', 'boolean'],
            'results.*.reason' => [
                'required_if:results.*.delivered,false',
                'nullable',
                'in:customer_unavailable,customer_refused,stockout,vehicle_breakdown,address_not_found,other',
            ],
            'results.*.note' => ['nullable', 'string', 'max:500'],
        ];
    }
}
