<?php

namespace App\Providers;

use App\Models\FaqItem;
use App\Models\Tenant\Order;
use App\Observers\FaqItemObserver;
use Illuminate\Support\Facades\Broadcast;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * All container bindings for this application are registered in
     * dedicated service providers or via auto-discovery. Nothing needs
     * to be bound here — this method is intentionally empty and kept
     * only because `register()` is part of the base ServiceProvider
     * contract and future bindings may be added.
     */
    public function register(): void
    {
        // Intentionally empty — see docblock above.
    }

    public function boot(): void
    {
        config(['permission.cache.store' => 'central']);

        // ★ Auto-embed FAQs on save. When a FAQ is created or updated via
        //   the admin panel, the observer calls the Python service and
        //   stores the resulting vector. Keeps faq_embeddings in sync
        //   without a background queue or manual command.
        FaqItem::observe(FaqItemObserver::class);

        // Private channel authorization for order status broadcasts.
        Broadcast::channel('orders.{orderId}', function ($customer, $orderId) {
            $order = Order::find($orderId);

            return $order && $order->customer_id === $customer->id;
        });
    }
}
