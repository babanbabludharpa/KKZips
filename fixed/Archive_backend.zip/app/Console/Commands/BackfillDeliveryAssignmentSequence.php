<?php

namespace App\Console\Commands;

use App\Models\DeliveryAssignment;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * One-time backfill for delivery_assignments.sequence.
 *
 * The column already exists (nullable int, no default) but nothing has
 * ever written to it -- every row created before the DeliveryAssignmentService
 * fix below is sitting at NULL. This assigns a stable order (by id, within
 * each occurrence_date + delivery_boy_id group) as a one-time correction so
 * RiderSubscriptionController::index()'s ->orderBy('sequence') stops
 * silently no-op'ing on old data.
 *
 * Run per tenant (separate DB per tenant): php artisan tenants:run
 *   backfill:delivery-sequence
 * Or scope manually per tenant connection if you're not using the
 * stancl/tenancy artisan wrapper for this.
 */
class BackfillDeliveryAssignmentSequence extends Command
{
    protected $signature = 'backfill:delivery-sequence';

    protected $description = 'Backfill NULL sequence values on delivery_assignments (one-time, safe to re-run)';

    public function handle(): int
    {
        $groups = DeliveryAssignment::whereNull('sequence')
            ->orderBy('occurrence_date')
            ->orderBy('id')
            ->get()
            ->groupBy(fn ($row) => $row->occurrence_date.'|'.$row->delivery_boy_id);

        $updated = 0;

        DB::transaction(function () use ($groups, &$updated) {
            foreach ($groups as $rows) {
                $i = 0;
                foreach ($rows as $row) {
                    $row->update(['sequence' => $i++]);
                    $updated++;
                }
            }
        });

        $this->info("Backfilled sequence on {$updated} delivery_assignments row(s).");

        return self::SUCCESS;
    }
}
