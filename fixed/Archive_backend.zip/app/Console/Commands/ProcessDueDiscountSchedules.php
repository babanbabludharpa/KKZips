<?php

namespace App\Console\Commands;

use App\Models\DiscountSchedule;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ProcessDueDiscountSchedules extends Command
{
    protected $signature = 'discounts:process-due';

    protected $description = 'Expire due discounts first, then activate pending ones';

    private int $totalExpired = 0;
    private int $totalActivated = 0;
    private int $totalFailed = 0;

    public function handle(): int
    {
        tenancy()->runForMultiple(null, function ($tenant) {
            $this->processTenant($tenant);
        });

        $this->info("Done. Expired: {$this->totalExpired}, Activated: {$this->totalActivated}, Failed: {$this->totalFailed}");

        return $this->totalFailed > 0 ? 1 : 0;
    }

    private function processTenant($tenant): void
    {
        $this->info("Processing tenant: {$tenant->id}");
        $today = Carbon::today()->toDateString();

        $this->expireDueSchedules($today);
        $this->activateDueSchedules($today);
    }

    private function expireDueSchedules(string $today): void
    {
        $toExpire = DiscountSchedule::with('variant')
            ->where('status', 'active')
            ->whereNotNull('ends_on')
            ->where('ends_on', '<', $today)
            ->get();

        foreach ($toExpire as $schedule) {
            $this->expireSchedule($schedule);
        }
    }

    private function expireSchedule(DiscountSchedule $schedule): void
    {
        $variant = $schedule->variant;

        DB::beginTransaction();
        try {
            $schedule->status = 'expired';
            $schedule->save();

            if ($variant) {
                $variant->is_discount_active = false;
                $variant->save();
            }

            DB::commit();
            $this->info("  Expired schedule #{$schedule->id} → ".($variant?->sku ?? 'unknown'));
            $this->totalExpired++;
        } catch (\Throwable $e) {
            DB::rollBack();
            $this->error("  Expire failed for schedule #{$schedule->id}: {$e->getMessage()}");
            $this->totalFailed++;
        }
    }

    private function activateDueSchedules(string $today): void
    {
        $toActivate = DiscountSchedule::with('variant')
            ->where('status', 'pending')
            ->where('starts_on', '<=', $today)
            ->get();

        foreach ($toActivate as $schedule) {
            $this->activateSchedule($schedule);
        }
    }

    private function activateSchedule(DiscountSchedule $schedule): void
    {
        $variant = $schedule->variant;

        if (! $variant) {
            $this->warn("  Schedule #{$schedule->id} — variant not found, skipping.");
            $this->totalFailed++;

            return;
        }

        DB::beginTransaction();
        try {
            $schedule->status = 'active';
            $schedule->save();
            $variant->is_discount_active = true;
            $variant->save();
            DB::commit();
            $this->info("  Activated schedule #{$schedule->id} → {$variant->sku} ({$schedule->discount_percent}%)");
            $this->totalActivated++;
        } catch (\Throwable $e) {
            DB::rollBack();
            $this->error("  Activate failed for schedule #{$schedule->id}: {$e->getMessage()}");
            $this->totalFailed++;
        }
    }
}
