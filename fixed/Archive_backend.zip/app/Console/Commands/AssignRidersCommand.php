<?php

namespace App\Console\Commands;

use App\Models\Tenant;
use App\Models\SubscriptionOccurrence;
use App\Services\V1\Subscriptions\DeliveryBoyAssignmentService;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class AssignRidersCommand extends Command
{
    protected $signature = 'subscriptions:assign-riders
                            {--window=all : all|today|tomorrow}
                            {--branch= : Restrict to a single branch id}
                            {--dry-run : Report counts without writing}
                            {--tenant= : Restrict to a single tenant id (default: all)}';

    protected $description = 'Auto-assign riders to unassigned subscription occurrences. Idempotent.';

    public function handle(DeliveryBoyAssignmentService $engine): int
    {
        $window  = strtolower((string) $this->option('window'));
        $branchId = $this->option('branch') !== null ? (int) $this->option('branch') : null;
        $dryRun  = (bool) $this->option('dry-run');
        $tenantFilter = $this->option('tenant');

        if (! in_array($window, ['all', 'today', 'tomorrow'], true)) {
            $this->error("Invalid --window value '{$window}'. Expected all|today|tomorrow.");
            return self::FAILURE;
        }

        $dates = $this->resolveDates($window);

        if (tenant()) {
            $counts = $this->runForTenant($engine, (string) tenant('id'), $dates, $branchId, $dryRun);

            $this->newLine();
            $this->table(
                ['Result', 'Count'],
                [
                    ['Assigned', $counts['assigned']],
                    ['Unassigned (no eligible rider)', $counts['unassigned']],
                    ['Failed', $counts['failed']],
                    ['Already assigned (skipped)', $counts['already']],
                ]
            );

            if ($dryRun) {
                $this->warn('Dry run — no changes were written.');
            }

            return $counts['failed'] > 0 ? self::FAILURE : self::SUCCESS;
        }

        $tenants = $tenantFilter
            ? Tenant::where('id', $tenantFilter)->get()
            : Tenant::all();

        if ($tenants->isEmpty()) {
            $this->info('No tenants found.');
            return self::SUCCESS;
        }

        $totalAssigned = 0;
        $totalUnassigned = 0;
        $totalFailed = 0;
        $totalAlready = 0;

        foreach ($tenants as $tenantModel) {
            tenancy()->initialize($tenantModel);

            try {
                $counts = $this->runForTenant($engine, (string) $tenantModel->id, $dates, $branchId, $dryRun);
                $totalAssigned += $counts['assigned'];
                $totalUnassigned += $counts['unassigned'];
                $totalFailed += $counts['failed'];
                $totalAlready += $counts['already'];
            } finally {
                tenancy()->end();
            }
        }

        $this->newLine();
        $this->table(
            ['Result', 'Count'],
            [
                ['Assigned', $totalAssigned],
                ['Unassigned (no eligible rider)', $totalUnassigned],
                ['Failed', $totalFailed],
                ['Already assigned (skipped)', $totalAlready],
            ]
        );

        if ($dryRun) {
            $this->warn('Dry run — no changes were written.');
        }

        return $totalFailed > 0 ? self::FAILURE : self::SUCCESS;
    }

    /**
     * @return array<int, Carbon>
     */
    private function resolveDates(string $window): array
    {
        $today = Carbon::today();

        return match ($window) {
            'today'    => [$today],
            'tomorrow' => [$today->copy()->addDay()],
            // --window=all matches the generator's 7-day horizon, so the
            // hourly cron assigns every occurrence the daily generator
            // created, not just tomorrow's.
            'all'      => collect(range(0, 7))
                ->map(fn ($d) => $today->copy()->addDays($d))
                ->all(),
        };
    }

    /**
     * @param  array<int, Carbon>  $dates
     * @return array{assigned:int, unassigned:int, failed:int, already:int}
     */
    private function runForTenant(
        DeliveryBoyAssignmentService $engine,
        string $tenantId,
        array $dates,
        ?int $branchId,
        bool $dryRun,
    ): array {
        $counts = ['assigned' => 0, 'unassigned' => 0, 'failed' => 0, 'already' => 0];

        $this->line("Tenant: {$tenantId}");

        foreach ($dates as $date) {
            if ($dryRun) {
                $pending = SubscriptionOccurrence::query()
                    ->whereDate('occurrence_date', $date->toDateString())
                    ->whereIn('status', ['scheduled', 'assigned'])
                    ->whereNull('delivery_boy_id')
                    ->when($branchId !== null, fn ($q) => $q->where('branch_id', $branchId))
                    ->count();

                $this->line("  {$date->toDateString()} — {$pending} occurrence(s) would be processed");
                continue;
            }

            $result = $engine->assignForDate($date, $branchId);

            $this->line(sprintf(
                '  %s — assigned %d, unassigned %d, failed %d, already %d',
                $date->toDateString(),
                $result['assigned'],
                $result['unassigned'],
                $result['failed'],
                $result['already']
            ));

            foreach ($result as $key => $value) {
                $counts[$key] += $value;
            }
        }

        Log::info('subscriptions:assign-riders ran', [
            'tenant' => $tenantId,
            'dates' => array_map(fn ($d) => $d->toDateString(), $dates),
            'branch_id' => $branchId,
            'dry_run' => $dryRun,
            'counts' => $counts,
        ]);

        return $counts;
    }
}
