<?php

namespace App\Console\Commands;

use App\Models\Tenant\CustomerAddress;
use App\Services\V1\Settings\BranchServiceZoneService;
use Illuminate\Console\Command;

class BackfillAddressZonesCommand extends Command
{
    protected $signature = 'addresses:backfill-zones
                            {--dry-run : Show what would be updated without writing}
                            {--force : Re-resolve even addresses that already have a zone_id}';

    protected $description = 'Resolve customer_addresses.zone_id using the polygon ST_Contains check. Idempotent.';

    public function handle(BranchServiceZoneService $zoneService): int
    {
        $dryRun = (bool) $this->option('dry-run');
        $force = (bool) $this->option('force');

        $query = CustomerAddress::query();

        if (! $force) {
            $query->whereNull('zone_id');
        }

        $total = (clone $query)->count();

        if ($total === 0) {
            $this->info('No addresses need zone backfill.');
            return self::SUCCESS;
        }

        $this->info(($dryRun ? '[DRY RUN] ' : '') . "Processing {$total} addresses...");

        $resolved = 0;
        $noZone = 0;
        $noCoords = 0;
        $errors = 0;

        $query->chunkById(200, function ($addresses) use (
            $zoneService, $dryRun, &$resolved, &$noZone, &$noCoords, &$errors
        ) {
            foreach ($addresses as $address) {
                try {
                    if ($address->latitude === null || $address->longitude === null) {
                        $noCoords++;
                        continue;
                    }

                    $matches = $zoneService->findServicingBranches(
                        (float) $address->latitude,
                        (float) $address->longitude
                    );

                    if (empty($matches)) {
                        $noZone++;
                        continue;
                    }

                    $zoneId = (int) $matches[0]->zone_id;

                    if ($dryRun) {
                        $this->line("  address #{$address->id}: would set zone_id = {$zoneId} ({$matches[0]->zone_name})");
                    } else {
                        $address->zone_id = $zoneId;
                        $address->save();
                    }

                    $resolved++;
                } catch (\Throwable $e) {
                    $errors++;
                    $this->error("  address #{$address->id}: {$e->getMessage()}");
                }
            }
        });

        $this->newLine();
        $this->table(
            ['Result', 'Count'],
            [
                ['Resolved (zone found)', $resolved],
                ['No zone (address outside all polygons)', $noZone],
                ['Skipped (missing lat/lng)', $noCoords],
                ['Errors', $errors],
                ['Total processed', $resolved + $noZone + $noCoords + $errors],
            ]
        );

        if ($dryRun) {
            $this->warn('Dry run — no changes were written.');
        }

        return $errors > 0 ? self::FAILURE : self::SUCCESS;
    }
}
