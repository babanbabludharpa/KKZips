<?php

namespace App\Console\Commands;

use App\Models\FaqEmbedding;
use App\Models\FaqItem;
use App\Services\V1\Faq\EmbeddingClient;
use App\Services\V1\Faq\Support\Embedder;
use Illuminate\Console\Command;

class EmbedFaqs extends Command
{
    protected $signature = 'faq:embed
                            {--force : Re-embed even if a vector already exists}
                            {--batch=25 : How many FAQs to embed per HTTP call}';

    protected $description = 'Compute and store embeddings for all active FAQs';

    public function handle(EmbeddingClient $embedder): int
    {
        $batch = max(1, (int) $this->option('batch'));

        if (! $embedder->isHealthy()) {
            $this->error('Embedder service is not reachable or model not loaded.');

            return self::FAILURE;
        }

        $query = FaqItem::query()->active();

        if (! $this->option('force')) {
            $query->whereDoesntHave('embeddings', fn ($q) => $q->where('model_name', Embedder::MODEL_NAME)
            );
        }

        $total = $query->count();
        if ($total === 0) {
            $this->info('Nothing to embed — all active FAQs already have vectors.');

            return self::SUCCESS;
        }

        $this->info("Embedding {$total} FAQs in batches of {$batch}…");
        $bar = $this->output->createProgressBar($total);
        $bar->start();

        $embedded = 0;
        $failed = 0;

        $query->with('embeddings')->chunkById($batch, function ($items) use (
            $embedder, $bar, &$embedded, &$failed
        ) {
            $texts = $items->map(fn (FaqItem $faq) => Embedder::buildEmbeddingText($faq)
            )->all();

            $vectors = $embedder->embedPassages($texts);

            if ($vectors === null) {
                $failed += $items->count();
                $bar->advance($items->count());

                return;
            }

            foreach ($items->values() as $index => $faq) {
                $vector = $vectors[$index] ?? null;
                if (! $vector) {
                    $failed++;

                    continue;
                }

                FaqEmbedding::updateOrCreate(
                    [
                        'faq_item_id' => $faq->id,
                        'model_name' => Embedder::MODEL_NAME,
                    ],
                    [
                        'vector' => $vector,
                        'source_text' => $texts[$index],
                    ]
                );
                $embedded++;
            }

            $bar->advance($items->count());
        });

        $bar->finish();
        $this->newLine(2);
        $this->info("Done. Embedded: {$embedded}, failed: {$failed}.");

        return $failed > 0 ? self::FAILURE : self::SUCCESS;
    }
}
