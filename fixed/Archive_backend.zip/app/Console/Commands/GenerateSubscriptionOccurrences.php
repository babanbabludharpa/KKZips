<?php

namespace App\Console\Commands;

use App\Models\SubscriptionItem;
use App\Models\SubscriptionOccurrence;
use App\Services\V1\Subscriptions\SubscriptionOccurrenceGenerationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class GenerateSubscriptionOccurrences extends Command
{
    protected $signature = 'subscriptions:generate-occurrences {--watchdog : Only log/alert on gaps, still attempts regeneration}';

    protected $description = 'Generate missing subscription_occurrences up to 7 days ahead (idempotent, self-healing). Pre-generates a week of occurrences so the hourly assigner always has future occurrences to work with, and so subscriptions created for a future start date get their first occurrence generated the same day.';

    public function handle(SubscriptionOccurrenceGenerationService $service): int
    {
        // Generate up to 7 days ahead. Rationale:
        //   1. The hourly assigner needs tomorrow's occurrences to exist today.
        //   2. A subscription created today for a start date within the next
        //      week must have its first occurrence created today, so the
        //      engine can assign a rider immediately at creation.
        //   3. If the daily cron misses a run, there is a 7-day buffer before
        //      occurrences run out.
        //   4. The AssignRidersCommand --window=all also covers a 7-day window,
        //      so the two commands stay in sync.
        $upTo = now()->startOfDay()->addDays(7);
        $isWatchdog = $this->option('watchdog');

        if ($isWatchdog) {
            $missingCount = $this->countActiveItemsMissingUpTo($upTo);
            if ($missingCount === 0) {
                $this->info('Watchdog check: no gaps found.');

                return self::SUCCESS;
            }
            $this->warn("Watchdog check: {$missingCount} active item(s) missing occurrence(s) up to {$upTo->toDateString()}. Re-running generation.");
        }

        $result = $service->generateUpTo($upTo);

        $this->info("Generation run complete. Created: {$result['created']}, Skipped: {$result['skipped']}");

        if ($isWatchdog) {
            $stillMissing = $this->countActiveItemsMissingUpTo($upTo);
            if ($stillMissing > 0) {
                $this->error("ALERT: {$stillMissing} active item(s) still missing occurrence(s) up to {$upTo->toDateString()} after regeneration attempt.");
                Log::critical('Subscription occurrence generation failed after watchdog retry', [
                    'missing_count' => $stillMissing,
                    'date' => $upTo->toDateString(),
                ]);
            }
        }

        return self::SUCCESS;
    }

    /**
     * Count active items that run on any day between today and $upTo
     * (inclusive) but are missing an occurrence for that day. Used only
     * by --watchdog.
     */
    protected function countActiveItemsMissingUpTo($upTo): int
    {
        $today = now()->startOfDay();
        $dates = [];
        for ($date = $today->copy(); $date->lte($upTo); $date->addDay()) {
            $dates[] = $date->copy();
        }

        $missing = 0;

        foreach ($dates as $date) {
            $activeItems = SubscriptionItem::where('status', 'active')->get()
                ->filter(fn ($item) => $item->runsOn($date));

            $activeItemIds = $activeItems->pluck('id');

            if ($activeItemIds->isEmpty()) {
                continue;
            }

            $existingIds = SubscriptionOccurrence::whereIn('subscription_item_id', $activeItemIds)
                ->whereDate('occurrence_date', $date)
                ->pluck('subscription_item_id');

            $missing += $activeItemIds->diff($existingIds)->count();
        }

        return $missing;
    }
}
