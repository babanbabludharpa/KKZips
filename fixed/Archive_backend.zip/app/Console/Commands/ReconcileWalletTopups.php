<?php

namespace App\Console\Commands;

use App\Services\V1\Wallet\WalletService;
use Illuminate\Console\Command;

class ReconcileWalletTopups extends Command
{
    protected $signature = 'wallet:reconcile-topups';

    protected $description = 'Sweep pending wallet topups older than 15 minutes, confirm against Razorpay, recover lost webhooks or mark expired.';

    public function handle(WalletService $walletService): int
    {
        $results = $walletService->reconcileStalePending();

        $this->info(sprintf(
            'Reconciled: %d recovered, %d expired, %d skipped (gateway error).',
            $results['recovered'],
            $results['expired'],
            $results['skipped']
        ));

        return self::SUCCESS;
    }
}

// Register in app/Console/Kernel.php:
//   $schedule->command('wallet:reconcile-topups')->everyFiveMinutes();
