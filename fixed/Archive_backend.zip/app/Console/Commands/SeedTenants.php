<?php

namespace App\Console\Commands;

use App\Models\Tenant;
use Illuminate\Console\Command;

class SeedTenants extends Command
{
    protected $signature = 'tenant:seed-all {seeder}';

    protected $description = 'Run a seeder across all tenants';

    public function handle(): void
    {
        foreach (Tenant::all() as $tenant) {
            try {
                $this->info("Initializing: {$tenant->id}");
                tenancy()->initialize($tenant);
                $this->info("Initialized: {$tenant->id}");

                \Artisan::call('db:seed', [
                    '--class' => $this->argument('seeder'),
                    '--force' => true,
                ]);
                $this->info("Done: {$tenant->id}");
            } catch (\Exception $e) {
                $this->error("Failed on {$tenant->id}: ".$e->getMessage());
                $this->error('File: '.$e->getFile().' Line: '.$e->getLine());
                $this->error($e->getTraceAsString());
            } finally {
                tenancy()->end();
            }
        }
    }
}
