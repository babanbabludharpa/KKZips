<?php

namespace App\Console\Commands;

use App\Models\PriceSchedule;
use App\Models\VariantPriceHistory;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ApplyDuePriceSchedules extends Command
{
    protected $signature = 'prices:apply-due';

    protected $description = 'Apply all pending price schedules where effective_from <= today';

    private int $totalApplied = 0;

    private int $totalFailed = 0;

    public function handle(): int
    {
        tenancy()->runForMultiple(null, function ($tenant) {
            $this->processTenant($tenant);
        });

        $this->info("Done. Applied: {$this->totalApplied}, Failed: {$this->totalFailed}");

        return $this->totalFailed > 0 ? 1 : 0;
    }

    private function processTenant($tenant): void
    {
        $this->info("Processing tenant: {$tenant->id}");
        $schedules = $this->getDueSchedules();

        if ($schedules->isEmpty()) {
            $this->info('  No due price schedules.');

            return;
        }

        foreach ($schedules as $schedule) {
            $this->applySchedule($schedule);
        }
    }

    private function getDueSchedules()
    {
        $today = Carbon::today()->toDateString();

        return PriceSchedule::with('variant')
            ->where('status', 'pending')
            ->where('effective_from', '<=', $today)
            ->get();
    }

    private function applySchedule(PriceSchedule $schedule): void
    {
        $variant = $schedule->variant;

        if (! $variant) {
            $this->warn("  Schedule #{$schedule->id} — variant not found, skipping.");
            $this->totalFailed++;

            return;
        }

        DB::beginTransaction();
        try {
            $updates = $this->extractUpdates($schedule);

            $this->recordHistory($schedule, $variant, $updates);

            if (! empty($updates)) {
                $variant->update($updates);
            }

            $schedule->status = 'applied';
            $schedule->save();
            DB::commit();

            $this->info("  Applied schedule #{$schedule->id} → {$variant->sku}");
            $this->totalApplied++;
        } catch (\Throwable $e) {
            DB::rollBack();
            $this->error("  Schedule #{$schedule->id} failed: {$e->getMessage()}");
            $this->totalFailed++;
        }
    }

    private function extractUpdates(PriceSchedule $schedule): array
    {
        $updates = [];

        if (! is_null($schedule->mrp)) {
            $updates['mrp'] = $schedule->mrp;
        }
        if (! is_null($schedule->selling_price)) {
            $updates['selling_price'] = $schedule->selling_price;
        }
        if (! is_null($schedule->purchase_price)) {
            $updates['purchase_price'] = $schedule->purchase_price;
        }

        return $updates;
    }

    private function recordHistory(PriceSchedule $schedule, $variant, array $updates): void
    {
        VariantPriceHistory::create([
            'product_variant_id' => $variant->id,
            'changed_by' => null,
            'source' => 'schedule',
            'schedule_id' => $schedule->id,
            'prev_mrp' => $variant->mrp,
            'prev_selling_price' => $variant->selling_price,
            'prev_purchase_price' => $variant->purchase_price,
            'new_mrp' => $updates['mrp'] ?? $variant->mrp,
            'new_selling_price' => $updates['selling_price'] ?? $variant->selling_price,
            'new_purchase_price' => $updates['purchase_price'] ?? $variant->purchase_price,
            'changed_at' => now(),
        ]);
    }
}
