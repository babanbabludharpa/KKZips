<?php

namespace App\Events;

use App\Models\AppLayout;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithBroadcasting; // <-- Add this
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class AppLayoutUpdated implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithBroadcasting, InteractsWithSockets, SerializesModels; // <-- Add trait

    public AppLayout $layout;

    public ?string $tenantId;

    public function __construct(AppLayout $layout)
    {
        $this->layout = $layout;
        $this->tenantId = tenant('id');
    }

    // Remove the broadcastConnection() method entirely

    public function broadcastOn(): Channel
    {
        return new Channel('tenant.'.($this->tenantId ?? 'unknown').'.layout');
    }

    public function broadcastAs(): string
    {
        return 'layout.updated';
    }

    public function broadcastWith(): array
    {
        return [
            'layout' => $this->layout->toArray(),
            'tenantId' => $this->tenantId,
            'published_at' => $this->layout->published_at?->toIso8601String(),
        ];
    }
}
