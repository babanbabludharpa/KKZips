<?php

namespace App\Events;

use App\Models\WebLayout;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * ─────────────────────────────────────────────────────────────────────────
 * WebLayoutUpdated event
 *
 * Path: app/Events/WebLayoutUpdated.php
 *
 * Broadcasts on `private-layout-updates` whenever an admin publishes a
 * new layout (theme, sections, navigation, footer, etc.). The customer
 * web portal's TenantProvider subscribes to this channel and re-fetches
 * the layout when the event fires.
 *
 * For this to work, all of the following must be true:
 *   1. .env has BROADCAST_CONNECTION=pusher (and Pusher keys configured)
 *   2. bootstrap/app.php's withRouting() includes `channels:`
 *   3. routes/channels.php authorizes the `layout-updates` channel
 *   4. WebLayoutController's saveLayout() calls broadcast(new WebLayoutUpdated($layout))->toOthers()
 * ─────────────────────────────────────────────────────────────────────────
 */
class WebLayoutUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public WebLayout $layout;

    public function __construct(WebLayout $layout)
    {
        $this->layout = $layout;
    }

    /**
     * Channel name Pusher subscribes to.
     * `new PrivateChannel('layout-updates')` → Pusher channel name `private-layout-updates`.
     * This MUST match what TenantProvider.jsx subscribes to.
     */
    public function broadcastOn(): array
    {
        return [
            new PrivateChannel('layout-updates'),
        ];
    }

    /**
     * Payload sent to the client. Keep it small — the client will
     * re-fetch the full layout via the API on receiving this event.
     */
    public function broadcastWith(): array
    {
        return [
            'id' => $this->layout->id,
            'version_name' => $this->layout->version_name,
            'updated_at' => $this->layout->updated_at?->toDateTimeString(),
        ];
    }

    /**
     * Event name Pusher dispatches.
     * TenantProvider.jsx binds to `App\\Events\\WebLayoutUpdated` —
     * Laravel automatically namespaces event classes this way.
     */
    public function broadcastAs(): string
    {
        return 'WebLayoutUpdated';
    }
}
