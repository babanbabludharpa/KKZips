<?php

namespace App\Events;

use App\Models\Tenant\Order;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Queue\SerializesModels;

class OrderStatusUpdated implements ShouldBroadcastNow
{
    use InteractsWithSockets, SerializesModels;

    public function __construct(public Order $order) {}

    // Channel name must match what the client subscribes to. Flutter side
    // subscribes to 'private-orders.{orderId}' -- Laravel's PrivateChannel
    // prepends the 'private-' prefix itself, so the channel string here is
    // 'orders.{id}', not 'private-orders.{id}'.
    public function broadcastOn(): array
    {
        return [
            new PrivateChannel('tenant.'.(tenant('id') ?? 'unknown').'.orders.'.$this->order->id),
        ];
    }

    // Must match the eventName the client's onEvent handler checks for.
    public function broadcastAs(): string
    {
        return 'order.status.updated';
    }

    // Keep the payload deliberately thin -- the Flutter screen refetches
    // the full order via _fetch() on receipt rather than trying to merge
    // this payload into local state (see order_detail_screen.dart comment).
    // No need to ship the whole Order (with relations) over the wire.
    public function broadcastWith(): array
    {
        return [
            'order_id' => $this->order->id,
            'status' => $this->order->status,
        ];
    }
}
