<?php

namespace App\Observers;

use App\Models\FaqEmbedding;
use App\Models\FaqItem;
use App\Services\V1\Faq\EmbeddingClient;
use App\Services\V1\Faq\Support\Embedder;
use Illuminate\Support\Facades\Log;

/**
 * Keeps faq_embeddings in sync with faq_items.
 *
 * Fires synchronously on saved — embedding one FAQ takes <100ms, so
 * there is no benefit to queuing. If the embedder service is down,
 * the FAQ still saves; the vector is left missing and a nightly
 * `faq:embed` run will fill the gap.
 */
class FaqItemObserver
{
    public function __construct(protected EmbeddingClient $embedder) {}

    public function saved(FaqItem $faq): void
    {
        if (! $faq->is_active) {
            // Don't embed inactive FAQs. If reactivated later, the
            // `saved` event fires again and this method runs.
            return;
        }

        $text = Embedder::buildEmbeddingText($faq);
        $vector = $this->embedder->embedOnePassage($text);

        if ($vector === null) {
            Log::info('FaqItemObserver: embedder unavailable, vector not stored', [
                'faq_id' => $faq->id,
            ]);

            return;
        }

        FaqEmbedding::updateOrCreate(
            [
                'faq_item_id' => $faq->id,
                'model_name' => Embedder::MODEL_NAME,
            ],
            [
                'vector' => $vector,
                'source_text' => $text,
            ]
        );
    }

    public function deleted(FaqItem $faq): void
    {
        // Cascade delete is on the foreign key, but be explicit.
        FaqEmbedding::where('faq_item_id', $faq->id)->delete();
    }
}
