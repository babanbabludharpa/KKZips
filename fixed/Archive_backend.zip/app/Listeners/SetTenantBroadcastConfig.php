<?php

namespace App\Listeners;

use App\Models\TenantProfile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Stancl\Tenancy\Events\TenancyInitialized;

class SetTenantBroadcastConfig
{
    /**
     * Per-request guard so a single request that initializes tenancy
     * multiple times logs the warning only once.
     *
     * @var array<string, bool>
     */
    private static array $warnedThisRequest = [];

    public function handle(): void
    {
        if (! Schema::hasTable('tenant_profiles')) {
            return;
        }

        $profile = TenantProfile::first();
        $tenantId = tenant('id') ?? 'central';

        if (! $profile || ! $profile->pusher_key || ! $profile->pusher_secret) {
            $this->warnOnce($tenantId);

            return;
        }

        config([
            'broadcasting.connections.pusher.key' => $profile->pusher_key,
            'broadcasting.connections.pusher.secret' => $profile->pusher_secret,
            'broadcasting.connections.pusher.app_id' => $profile->pusher_app_id,
            'broadcasting.connections.pusher.options.cluster' => $profile->pusher_cluster,
            'broadcasting.connections.pusher.options.host' => 'api-'.$profile->pusher_cluster.'.pusher.com',
        ]);
    }

    /**
     * Log the "no Pusher credentials" warning at most once per tenant
     * per request AND at most once every 24 hours overall. Uses a
     * filesystem flag under storage/framework/ so it works in a
     * multi-tenant app without needing a cache table in each tenant DB.
     */
    private function warnOnce(string $tenantId): void
    {
        if (isset(self::$warnedThisRequest[$tenantId])) {
            return;
        }
        self::$warnedThisRequest[$tenantId] = true;

        $flagDir = storage_path('framework');
        $flagFile = $flagDir.'/pusher_missing_'.hash('sha256', $tenantId).'.flag';

        if (is_file($flagFile) && (time() - filemtime($flagFile)) < 86400) {
            return;
        }

        Log::warning('Tenant has no Pusher credentials configured; broadcasting will fail.', [
            'tenant_id' => $tenantId,
        ]);

        if (is_dir($flagDir)) {
            @touch($flagFile);
        }
    }
}
