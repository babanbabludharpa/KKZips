<?php

namespace App\Enums;

class ChangeMasterFlag
{
    public const ADMIN_PASSWORD_RESET = '1';

    public const CUSTOMER_STATUS_CHANGE = '2';

    public static function label(string $flag): string
    {
        return match ($flag) {
            self::ADMIN_PASSWORD_RESET => 'Admin Password Reset',
            self::CUSTOMER_STATUS_CHANGE => 'Customer Status Change',
            default => "Unknown ({$flag})",
        };
    }
}
