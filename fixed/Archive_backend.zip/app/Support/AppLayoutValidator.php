<?php

namespace App\Support;

use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AppLayoutValidator
{
    public const VALID_TYPES = [
        'carousel',
        'dashboard_menu',
        'quick_calendar',
        'popular_products',
        'categories_grid',
        'all_products',
        'subscription_plans',
        'app_settings',
    ];

    public const ACTION_TYPES = ['none', 'product', 'category', 'subscription_plan', 'url', 'route'];

    public const DASHBOARD_ROUTES = ['profile', 'subscriptions', 'products', 'orders', 'cart', 'addresses'];

    private const MSG_LIMIT_1_TO_50 = 'limit must be 1–50.';

    /**
     * @throws ValidationException
     */
    public static function validate(array $components): void
    {
        if (empty($components)) {
            throw ValidationException::withMessages([
                'components' => 'At least one component is required.',
            ]);
        }

        $errors = [];

        foreach ($components as $i => $comp) {
            $errors = array_merge($errors, self::validateComponent($comp, $i));
        }

        if (! empty($errors)) {
            throw ValidationException::withMessages($errors);
        }
    }

    private static function validateComponent($comp, int $i): array
    {
        $prefix = "components.{$i}";

        if (! is_array($comp)) {
            return ["{$prefix}.type" => 'Component must be an object.'];
        }

        $type = $comp['type'] ?? null;

        $typeError = self::validateComponentType($type, $prefix);
        if ($typeError !== null) {
            return $typeError;
        }

        $errors = [];

        if (empty($comp['id'])) {
            $errors["{$prefix}.id"] = 'Component id is required (UUID).';
        }

        $method = 'validate'.Str::studly($type);
        if (method_exists(self::class, $method)) {
            foreach (self::{$method}($comp['data'] ?? []) as $field => $msg) {
                $errors["{$prefix}.data.{$field}"] = $msg;
            }
        }

        return $errors;
    }

    /**
     * Returns an error array if the component type is missing or unknown,
     * or null if the type is valid.
     */
    private static function validateComponentType(?string $type, string $prefix): ?array
    {
        if (! $type) {
            return ["{$prefix}.type" => 'Component type is required.'];
        }

        if (! in_array($type, self::VALID_TYPES, true)) {
            return ["{$prefix}.type" => 'Unknown type: '.$type];
        }

        return null;
    }

    protected static function validateCarousel(array $data): array
    {
        $images = $data['images'] ?? [];

        if (! is_array($images) || count($images) < 1) {
            return ['images' => 'Carousel requires at least one image.'];
        }

        $errors = self::validateCarouselImages($images);
        $errors = array_merge($errors, self::validateCarouselTiming($data));

        return $errors;
    }

    private static function validateCarouselImages(array $images): array
    {
        $errors = [];

        foreach ($images as $j => $img) {
            if (empty($img['url'])) {
                $errors["images.{$j}.url"] = 'Image URL is required.';
            }
            $errors = array_merge($errors, self::validateCarouselImageAction($img, $j));
        }

        return $errors;
    }

    private static function validateCarouselImageAction($img, int $j): array
    {
        $action = $img['action'] ?? null;

        if (! is_array($action)) {
            return [];
        }

        $t = $action['type'] ?? null;
        $errors = [];

        if ($t && ! in_array($t, self::ACTION_TYPES, true)) {
            $errors["images.{$j}.action.type"] = 'Invalid action type: '.$t;
        }
        if ($t && $t !== 'none' && empty($action['value'])) {
            $errors["images.{$j}.action.value"] = 'Action value required when type is not "none".';
        }

        return $errors;
    }

    private static function validateCarouselTiming(array $data): array
    {
        $errors = [];

        $autoplay = $data['autoplay'] ?? true;
        if (! is_bool($autoplay)) {
            $errors['autoplay'] = 'autoplay must be boolean.';
        }

        $interval = $data['interval_seconds'] ?? 4;
        if (! is_int($interval) || $interval < 1 || $interval > 60) {
            $errors['interval_seconds'] = 'interval_seconds must be 1–60.';
        }

        return $errors;
    }

    protected static function validateDashboardMenu(array $data): array
    {
        $items = $data['items'] ?? [];

        if (! is_array($items) || count($items) < 1) {
            return ['items' => 'Dashboard menu requires at least one item.'];
        }

        $errors = self::validateDashboardItems($items);

        $cols = $data['columns'] ?? 2;
        if (! in_array($cols, [1, 2, 3, 4], true)) {
            $errors['columns'] = 'columns must be 1, 2, 3 or 4.';
        }

        return $errors;
    }

    private static function validateDashboardItems(array $items): array
    {
        $errors = [];

        foreach ($items as $j => $item) {
            if (empty($item['label'])) {
                $errors["items.{$j}.label"] = 'Label is required.';
            }
            if (empty($item['route'])) {
                $errors["items.{$j}.route"] = 'Route is required.';
            } elseif (! in_array($item['route'], self::DASHBOARD_ROUTES, true)) {
                $errors["items.{$j}.route"] = 'Unknown route: '.$item['route'];
            }
        }

        return $errors;
    }

    protected static function validateQuickCalendar(array $data): array
    {
        $errors = [];
        $days = $data['days_to_show'] ?? 7;
        if (! is_int($days) || $days < 1 || $days > 14) {
            $errors['days_to_show'] = 'days_to_show must be 1–14.';
        }

        return $errors;
    }

    protected static function validatePopularProducts(array $data): array
    {
        $errors = [];

        $source = $data['source'] ?? 'recent';
        if (! in_array($source, ['manual', 'recent', 'top_rated', 'discounted'], true)) {
            $errors['source'] = 'Invalid source.';
        }

        if ($source === 'manual') {
            $ids = $data['product_ids'] ?? [];
            if (! is_array($ids) || count($ids) < 1) {
                $errors['product_ids'] = 'Manual source requires at least one product_id.';
            }
        }

        $limit = $data['limit'] ?? 8;
        if (! is_int($limit) || $limit < 1 || $limit > 50) {
            $errors['limit'] = self::MSG_LIMIT_1_TO_50;
        }

        return $errors;
    }

    protected static function validateCategoriesGrid(array $data): array
    {
        $errors = [];
        $layout = $data['layout'] ?? 'chips';
        if (! in_array($layout, ['chips', 'grid_2col', 'grid_3col', 'circle'], true)) {
            $errors['layout'] = 'Invalid layout.';
        }
        $limit = $data['limit'] ?? 10;
        if (! is_int($limit) || $limit < 1 || $limit > 50) {
            $errors['limit'] = self::MSG_LIMIT_1_TO_50;
        }

        return $errors;
    }

    protected static function validateAllProducts(array $data): array
    {
        $errors = [];
        $sort = $data['sort_by'] ?? 'name_asc';
        if (! in_array($sort, ['name_asc', 'name_desc', 'price_asc', 'price_desc', 'newest'], true)) {
            $errors['sort_by'] = 'Invalid sort_by.';
        }
        $cols = $data['columns'] ?? 2;
        if (! in_array($cols, [2, 3, 4], true)) {
            $errors['columns'] = 'columns must be 2, 3 or 4.';
        }
        $page = $data['page_size'] ?? 20;
        if (! is_int($page) || $page < 4 || $page > 100) {
            $errors['page_size'] = 'page_size must be 4–100.';
        }

        return $errors;
    }

    protected static function validateSubscriptionPlans(array $data): array
    {
        $errors = [];
        $limit = $data['limit'] ?? 6;
        if (! is_int($limit) || $limit < 1 || $limit > 50) {
            $errors['limit'] = self::MSG_LIMIT_1_TO_50;
        }

        return $errors;
    }
}
