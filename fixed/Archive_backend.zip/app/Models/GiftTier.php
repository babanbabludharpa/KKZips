<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GiftTier extends Model
{
    protected $fillable = [
        'gift_campaign_id',
        'threshold_amount',
        'selection_mode',
    ];

    protected $casts = [
        'threshold_amount' => 'decimal:2',
    ];

    public function campaign()
    {
        return $this->belongsTo(GiftCampaign::class, 'gift_campaign_id');
    }

    public function items()
    {
        return $this->hasMany(GiftTierItem::class);
    }
}
