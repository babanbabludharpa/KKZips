<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VariantPriceHistory extends Model
{
    public $timestamps = false;

    protected $table = 'variant_price_history';

    protected $fillable = [
        'product_variant_id',
        'changed_by',
        'source',
        'schedule_id',
        'prev_mrp',
        'prev_selling_price',
        'prev_purchase_price',
        'new_mrp',
        'new_selling_price',
        'new_purchase_price',
        'changed_at',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function schedule()
    {
        return $this->belongsTo(PriceSchedule::class, 'schedule_id');
    }

    public function changedBy()
    {
        return $this->belongsTo(User::class, 'changed_by');
    }
}
