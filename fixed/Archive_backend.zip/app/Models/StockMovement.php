<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockMovement extends Model
{
    protected $fillable = [
        'product_variant_id', 'branch_id', 'type',
        'opening_stock', 'in', 'out', 'closing_stock',
        'transaction_date', 'reference_id', 'expiry_date', 'created_by',
    ];

    protected $casts = [
        'transaction_date' => 'date',
        'expiry_date' => 'date',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
