<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductVariant extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'product_id',
        'sku',
        'unit_id',
        'hsn_code',
        'image',
        'mrp',
        'purchase_price',
        'selling_price',
        'is_discount_active',
        'is_coupon_eligible',
        'available_for_order',
        'available_for_subscription',
        'tax_rate_id',
        'min_order_qty',
        'is_active',
        'is_gift',
    ];

    protected $casts = [
        'mrp' => 'decimal:2',
        'purchase_price' => 'decimal:2',
        'selling_price' => 'decimal:2',
        'is_discount_active' => 'boolean',
        'is_coupon_eligible' => 'boolean',
        'available_for_order' => 'boolean',
        'available_for_subscription' => 'boolean',
        'is_active' => 'boolean',
        'min_order_qty' => 'integer',
        'is_gift' => 'boolean',
    ];

    // ── Scopes ──────────────────────────────────────────────────────

    public function scopeForOrder($q)
    {
        return $q->where('available_for_order', true);
    }

    public function scopeForSubscription($q)
    {
        return $q->where('available_for_subscription', true);
    }

    /**
     * ★ FREE GIFTS — gift variants must never appear in any
     * customer-facing catalog query.
     */
    public function scopeNotGift($q)
    {
        return $q->where('is_gift', false);
    }

    public function scopeGift($q)
    {
        return $q->where('is_gift', true);
    }

    // ── Relationships ───────────────────────────────────────────────

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }

    public function taxRate()
    {
        return $this->belongsTo(TaxRate::class);
    }

    public function attributeValues()
    {
        return $this->belongsToMany(
            AttributeValue::class,
            'variant_attribute_values',
            'variant_id',
            'attribute_value_id'
        );
    }

    public function inventory()
    {
        return $this->hasMany(Inventory::class);
    }

    public function stockMovements()
    {
        return $this->hasMany(StockMovement::class);
    }

    public function priceSchedules()
    {
        return $this->hasMany(PriceSchedule::class);
    }

    public function discountSchedules()
    {
        return $this->hasMany(DiscountSchedule::class);
    }

    public function priceHistory()
    {
        return $this->hasMany(VariantPriceHistory::class, 'product_variant_id');
    }

    // ── Accessors ───────────────────────────────────────────────────

    public function getFinalPriceAttribute(): string
    {
        if ($this->is_discount_active) {
            $active = $this->discountSchedules()
                ->where('status', 'active')
                ->latest()
                ->first();

            if ($active) {
                $discounted = $this->selling_price * (1 - $active->discount_percent / 100);

                return number_format($discounted, 2, '.', '');
            }
        }

        return number_format($this->selling_price, 2, '.', '');
    }

    public function getActiveDiscountPercentAttribute(): ?string
    {
        if (! $this->is_discount_active) {
            return null;
        }

        if ($this->relationLoaded('discountSchedules')) {
            return $this->discountSchedules
                ->where('status', 'active')
                ->first()
                ?->discount_percent;
        }

        return $this->discountSchedules()
            ->where('status', 'active')
            ->value('discount_percent');
    }

    public function getChannelLabelAttribute(): string
    {
        return match (true) {
            $this->available_for_order && $this->available_for_subscription => 'Both',
            $this->available_for_order => 'Order',
            $this->available_for_subscription => 'Subscription',
            default => 'None',
        };
    }
}
