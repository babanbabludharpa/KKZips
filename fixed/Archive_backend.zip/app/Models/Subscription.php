<?php

namespace App\Models;

use App\Models\Tenant\Customer;
use App\Models\Tenant\CustomerAddress;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Subscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id', 'branch_id', 'delivery_address_id', 'delivery_boy_id',
        'status', 'start_date', 'end_date',
        'auto_renew', 'delivery_instruction_id',
    ];

    protected $casts = [
        'customer_id' => 'integer',
        'start_date' => 'date',
        'end_date' => 'date',
        'delivery_boy_id' => 'integer',
        'auto_renew' => 'boolean',
    ];

    public function deliveryInstruction(): BelongsTo
    {
        return $this->belongsTo(\App\Models\DeliveryInstruction::class, 'delivery_instruction_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function deliveryAddress(): BelongsTo
    {
        return $this->belongsTo(CustomerAddress::class, 'delivery_address_id');
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function deliveryBoy(): BelongsTo
    {
        return $this->belongsTo(DeliveryBoy::class, 'delivery_boy_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(SubscriptionItem::class);
    }

    public function activeItems(): HasMany
    {
        return $this->items()->where('status', 'active');
    }
}
