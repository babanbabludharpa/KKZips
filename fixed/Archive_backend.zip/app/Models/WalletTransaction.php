<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WalletTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id', 'type', 'amount', 'balance_after', 'reference_type', 'reference_id',
        'remark', 'added_by',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    // The admin (or system actor) who entered a manual adjustment. Null
    // for anything gateway-driven (deposit/refund from a topup) -- only
    // meaningful alongside type=manual_adjustment.
    public function addedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'added_by');
    }
}
