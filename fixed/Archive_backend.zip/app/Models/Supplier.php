<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Supplier extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'contact_person',
        'phone',
        'alternate_phone',
        'email',
        'address',
        'gst_no',
        'registration_no',
        'pan_no',
        'fssai_no',
        'adhar_no',
        'shopact_no',
        'registration_doc',
        'gst_doc',
        'pan_doc',
        'fssai_doc',
        'adhar_doc',
        'shopact_doc',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
