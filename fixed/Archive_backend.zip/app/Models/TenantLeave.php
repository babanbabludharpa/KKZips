<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantLeave extends Model
{
    protected $fillable = [
        'title', 'start_date', 'end_date',
        'branch_ids', 'slot_ids', 'reason', 'recurrence_rule',
        'date_mode',            // single | range | recurring
        'status', 'created_by', 'cancelled_by', 'cancelled_at',
    ];

    protected $casts = [
        'start_date'   => 'date:Y-m-d',
        'end_date'     => 'date:Y-m-d',
        'branch_ids'   => 'array',
        'slot_ids'     => 'array',
        'cancelled_at' => 'datetime',
    ];

    public function scopeActive($q)
    {
        return $q->where('status', 'active');
    }

    /**
     * @return \Carbon\CarbonImmutable[]
     */
    public function effectiveDates(): array
    {
        $start = \Carbon\CarbonImmutable::parse($this->start_date);
        $end   = \Carbon\CarbonImmutable::parse($this->end_date);

        // Guard: recurring horizon max 24 months (server-side protection).
        if ($this->recurrence_rule && $start->diffInMonths($end) > 24) {
            throw new \RuntimeException('Recurring horizon cannot exceed 24 months.');
        }

        if (! $this->recurrence_rule) {
            $dates = [];
            for ($d = $start; $d->lte($end); $d = $d->addDay()) {
                $dates[] = $d;
            }
            return $dates;
        }

        return $this->expandRecurrence($start, $end);
    }

    private function expandRecurrence(\Carbon\CarbonImmutable $start, \Carbon\CarbonImmutable $end): array
    {
        // Format examples:
        //   daily
        //   weekly:0,2,4           → Sun/Wed/Fri
        //   monthly:1              → 1st of month
        //   monthly:last           → last day of month
        //   monthly_nth:2:1        → 2nd Monday of month (W:D)
        [$freq, $mod] = array_pad(explode(':', $this->recurrence_rule, 3), 3, null);

        $dates = [];
        for ($d = $start; $d->lte($end); $d = $d->addDay()) {
            if ($freq === 'daily') {
                $dates[] = $d;
                continue;
            }

            if ($freq === 'weekly' && $mod !== null) {
                $days = array_map('intval', explode(',', $mod));
                if (in_array((int) $d->dayOfWeek, $days, true)) {
                    $dates[] = $d;
                }
                continue;
            }

            if ($freq === 'monthly' && $mod !== null) {
                if ($mod === 'last') {
                    if ((int) $d->day === (int) $d->daysInMonth) $dates[] = $d;
                } else {
                    if ((int) $d->day === (int) $mod) $dates[] = $d;
                }
                continue;
            }

            if ($freq === 'monthly_nth' && $mod !== null) {
                [$week, $weekday] = array_pad(explode(':', $mod, 2), 2, null);
                if ($week === null || $weekday === null) continue;
                $nth = (int) $week;
                $wd  = (int) $weekday;
                if ((int) $d->dayOfWeek !== $wd) continue;
                // Is this the Nth occurrence of that weekday this month?
                $occurrence = intdiv((int) $d->day - 1, 7) + 1;
                if ($occurrence === $nth) {
                    $dates[] = $d;
                }
                continue;
            }
        }
        return $dates;
    }
}
