<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantLeaveAuditLog extends Model
{
    protected $table = 'tenant_leave_audit_log';   // ← explicit, matches migration

    public $timestamps = false;

    protected $fillable = ['leave_id', 'user_id', 'action', 'payload', 'counts', 'created_at'];

    protected $casts = [
        'payload' => 'array',
        'counts'  => 'array',
    ];
}
