<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FaqUnmatched extends Model
{
    /**
     * Eloquent's default pluralizer turns "FaqUnmatched" into
     * "faq_unmatcheds". The migration created "faq_unmatched". Point
     * the model at the actual table name explicitly.
     */
    protected $table = 'faq_unmatched';

    protected $fillable = [
        'question',
        'language_guess',
        'customer_id',
        'hit_count',
        'last_asked_at',
        'converted_faq_id',
    ];

    protected $casts = [
        'hit_count' => 'integer',
        'last_asked_at' => 'datetime',
        'converted_faq_id' => 'integer',
    ];

    public function convertedFaq(): BelongsTo
    {
        return $this->belongsTo(FaqItem::class, 'converted_faq_id');
    }

    public function isConverted(): bool
    {
        return $this->converted_faq_id !== null;
    }

    public function scopePending($query)
    {
        return $query->whereNull('converted_faq_id');
    }

    public function scopeFrequent($query, int $minHits = 3)
    {
        return $query->where('hit_count', '>=', $minHits);
    }

    public static function normalizeForAggregation(string $question): string
    {
        $q = mb_strtolower($question);
        $q = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $q);
        $q = preg_replace('/\s+/u', ' ', $q);

        return trim($q);
    }
}
