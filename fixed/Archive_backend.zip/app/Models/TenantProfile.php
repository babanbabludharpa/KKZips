<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantProfile extends Model
{
    protected $fillable = [
        'company_name', 'logo', 'pan_no',
        'support_phone', 'support_email', 'support_hours',

        'has_orders', 'use_order_slots', 'has_subscriptions', 'has_wallet',
        'cod_enabled', 'online_payment_enabled',

        'pusher_app_id', 'pusher_key', 'pusher_secret', 'pusher_cluster',

        'subscription_cutoff_time', 'subscription_cutoff_restrict_admin',
        'subscription_start_policy', 'same_day_lead_time_minutes',
        'order_start_policy', 'order_same_day_lead_time_minutes',
        'slot_wise_cutoff_enabled', 'slot_cutoff_offset_minutes',
        'rider_assignment_time', 'last_assignment_run',
        'order_stock_check_enabled', 'subscription_stock_check_enabled',

        'razorpay_key_id', 'razorpay_key_secret', 'razorpay_webhook_secret', 'razorpay_is_live',

        'sms_username', 'sms_password', 'sms_sender_id', 'sms_enabled',

        // ★ new — channel toggles + config
        'sms_channel_enabled',
        'notification_channel_enabled',
        'whatsapp_channel_enabled',
        'whatsapp_api_key', 'whatsapp_phone_number',
        'email_channel_enabled',

        // ★ new — wallet thresholds (paise, signed)
        'wallet_warning_limit', 'wallet_suspension_limit',

        // ★ new — delivery note
        'delivery_note_min_days', 'delivery_note_max_days', 'delivery_note_text',
    ];

    protected $casts = [
        'has_orders' => 'boolean',
        'use_order_slots' => 'boolean',
        'has_subscriptions' => 'boolean',
        'has_wallet' => 'boolean',

        'pusher_secret' => 'encrypted',
        'razorpay_key_secret' => 'encrypted',
        'razorpay_webhook_secret' => 'encrypted',
        'razorpay_is_live' => 'boolean',
        'sms_password' => 'encrypted',
        'sms_enabled' => 'boolean',

        'subscription_cutoff_restrict_admin' => 'boolean',
        'order_stock_check_enabled' => 'boolean',
        'subscription_stock_check_enabled' => 'boolean',
        'subscription_start_policy' => 'string',
        'same_day_lead_time_minutes' => 'integer',
        'order_start_policy' => 'string',
        'order_same_day_lead_time_minutes' => 'integer',
        'slot_wise_cutoff_enabled' => 'boolean',
        'slot_cutoff_offset_minutes' => 'integer',
        'rider_assignment_time' => 'string',
        'last_assignment_run' => 'date',

        // ★ new
        'sms_channel_enabled' => 'boolean',
        'notification_channel_enabled' => 'boolean',
        'whatsapp_channel_enabled' => 'boolean',
        'whatsapp_api_key' => 'encrypted',
        'email_channel_enabled' => 'boolean',
        'wallet_warning_limit' => 'integer',
        'wallet_suspension_limit' => 'integer',
        'delivery_note_min_days' => 'integer',
        'delivery_note_max_days' => 'integer',
    ];

    public function requiresOrderSlots(): bool
    {
        return $this->has_orders && $this->use_order_slots;
    }
}
