<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GiftCampaign extends Model
{
    protected $fillable = [
        'name',
        'tier_mode',
        'threshold_basis',
        'usage_limit_total',
        'usage_limit_per_customer',
        'used_count',
        'valid_from',
        'valid_until',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'usage_limit_total' => 'integer',
        'usage_limit_per_customer' => 'integer',
        'used_count' => 'integer',
        'valid_from' => 'date',
        'valid_until' => 'date',
        'is_active' => 'boolean',
    ];

    // ── Relationships ───────────────────────────────────────────────

    public function tiers()
    {
        return $this->hasMany(GiftTier::class)->orderBy('threshold_amount');
    }

    public function usages()
    {
        return $this->hasMany(GiftUsage::class);
    }

    // ── Scopes ──────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    // ── Helpers ─────────────────────────────────────────────────────

    public function isValidToday(): bool
    {
        $today = now()->toDateString();

        if ($this->valid_from->toDateString() > $today) {
            return false;
        }

        if ($this->valid_until && $this->valid_until->toDateString() < $today) {
            return false;
        }

        return true;
    }

    public function totalLimitReached(): bool
    {
        return $this->usage_limit_total !== null
            && $this->used_count >= $this->usage_limit_total;
    }
}
