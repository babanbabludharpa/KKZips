<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GiftTierItem extends Model
{
    protected $fillable = [
        'gift_tier_id',
        'product_variant_id',
        'quantity',
    ];

    protected $casts = [
        'quantity' => 'integer',
    ];

    public function tier()
    {
        return $this->belongsTo(GiftTier::class, 'gift_tier_id');
    }

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }
}
