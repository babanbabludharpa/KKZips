<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RecurringUnavailableDay extends Model
{
    use HasFactory;

    protected $fillable = ['product_category_id', 'day_of_week', 'slot_id', 'description'];

    protected $casts = [
        'product_category_id' => 'integer',
        'day_of_week' => 'integer',
        'slot_id' => 'integer',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'product_category_id');
    }

    public function slot(): BelongsTo
    {
        return $this->belongsTo(TenantDeliverySlot::class, 'slot_id');
    }
}
