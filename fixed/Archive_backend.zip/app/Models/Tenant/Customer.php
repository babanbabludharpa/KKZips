<?php

namespace App\Models\Tenant;

use App\Models\Subscription;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Tenant\CustomerAddress;
use App\Models\CustomerNote;

class Customer extends Authenticatable
{
    use HasApiTokens, Notifiable, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
        'profile_photo',
        'latitude',
        'longitude',
        'location_permission',
        'status',
        'email_verification_token',
        'email_verified_at',
        'phone_otp',
        'phone_otp_expires_at',
        'phone_verified',
        'dnd', 'warning_limit', 'suspension_limit',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'email_verification_token',
        'phone_otp',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'phone_otp_expires_at' => 'datetime',
        'location_permission' => 'boolean',
        'phone_verified' => 'boolean',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'dnd' => 'boolean',
        'warning_limit' => 'float',
        'suspension_limit' => 'float',
    ];

    // ── Relationships ─────────────────────────────────────────────────

    public function addresses()
    {
        return $this->hasMany(
            CustomerAddress::class  // ← full path
        );
    }

    public function defaultAddress()
    {
        return $this->hasOne(
            CustomerAddress::class  // ← full path
        )->where('is_default', true);
    }

    public function orders()
    {
        return $this->hasMany(
            Order::class            // ← full path
        );
    }

    public function subscriptions()
    {
        return $this->hasMany(
            Subscription::class     // ← full path
        );
    }

    public function deviceTokens()
    {
        return $this->hasMany(
            DeviceToken::class
        );
    }

    public function activeSubscriptions()
    {
        return $this->hasMany(
            Subscription::class     // ← full path
        )->where('status', 'active');
    }

    // ── Helpers ───────────────────────────────────────────────────────

    public function notes()
    {
        return $this->hasMany(CustomerNote::class);
    }

    // Helper to get effective limits (falls back to tenant default)
    public function effectiveWarningLimit()
    {
        if ($this->warning_limit !== null) return $this->warning_limit;
        $profile = \App\Models\TenantProfile::first();
        return $profile?->wallet_warning_limit ? $profile->wallet_warning_limit / 100 : -500;
    }

    public function effectiveSuspensionLimit()
    {
        if ($this->suspension_limit !== null) return $this->suspension_limit;
        $profile = \App\Models\TenantProfile::first();
        return $profile?->wallet_suspension_limit ? $profile->wallet_suspension_limit / 100 : -5000;
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isWithinDeliveryZone(
        float $zoneLat,
        float $zoneLng,
        float $radiusKm
    ): bool {
        if (! $this->latitude || ! $this->longitude) {
            return false;
        }

        $earthRadius = 6371;
        $dLat = deg2rad($zoneLat - $this->latitude);
        $dLng = deg2rad($zoneLng - $this->longitude);

        $a = sin($dLat / 2) ** 2
           + cos(deg2rad($this->latitude))
           * cos(deg2rad($zoneLat))
           * sin($dLng / 2) ** 2;

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        $distance = $earthRadius * $c;

        return $distance <= $radiusKm;
    }
}
