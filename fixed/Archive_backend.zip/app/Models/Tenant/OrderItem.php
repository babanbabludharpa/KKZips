<?php

namespace App\Models\Tenant;

use App\Models\ProductVariant;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $fillable = [
        'order_id', 'product_variant_id', 'quantity',
        'unit_price', 'mrp', 'discount_percent', 'final_price', 'line_total',
        'tax_rate_percent', 'tax_amount', 'taxable_value',
        'tax_type', 'cgst_amount', 'sgst_amount', 'igst_amount',
        'is_gift', 'gift_tier_id',
    ];

    protected $casts = [
        'unit_price' => 'decimal:2',
        'mrp' => 'decimal:2',
        'discount_percent' => 'decimal:2',
        'final_price' => 'decimal:2',
        'line_total' => 'decimal:2',
        'tax_rate_percent' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'taxable_value' => 'decimal:2',
        'cgst_amount' => 'decimal:2',
        'sgst_amount' => 'decimal:2',
        'igst_amount' => 'decimal:2',
        'is_gift' => 'boolean',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function giftTier()
    {
        return $this->belongsTo(\App\Models\GiftTier::class, 'gift_tier_id');
    }
}
