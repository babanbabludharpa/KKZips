<?php

namespace App\Models\Tenant;

use App\Models\State;
use App\Models\Branch;
use App\Models\BranchServiceZone;
use Illuminate\Database\Eloquent\Model;

class CustomerAddress extends Model
{
    protected $fillable = [
        'customer_id',
        'label',
        'address_line1',
        'address_line2',
        'city',
        'state',
        'state_id',
        'pincode',
        'country',
        'latitude',
        'longitude',
        'is_default',
        'branch_id',
        'zone_id',
        'is_serviceable',
    ];

    protected $casts = [
        'customer_id' => 'integer',
        'latitude' => 'float',
        'longitude' => 'float',
        'is_default' => 'boolean',
        'is_serviceable' => 'boolean',
        'branch_id' => 'integer',
        'zone_id' => 'integer',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function state()
    {
        return $this->belongsTo(State::class);
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function zone()
    {
        return $this->belongsTo(BranchServiceZone::class, 'zone_id');
    }
}
