<?php

namespace App\Models\Tenant;

use App\Models\Branch;
use App\Models\CouponUsage;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'order_number',
        'customer_id', 'branch_id', 'delivery_boy_id',
        'status', 'payment_mode', 'payment_status',
        'razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature',
        'delivery_address', 'customer_lat', 'customer_lng',
        'subtotal', 'delivery_charge', 'coupon_code', 'coupon_discount', 'total',
        'customer_remark', 'delivery_remark',
        'assigned_at', 'delivered_at',
        // ADDED: Delivery confirmation fields (rider app)
        'delivery_photo_path',
        'delivery_lat',
        'delivery_lng',
        'delivery_slot_id', 'delivery_date', 'uses_slot_at_checkout',
    ];

    protected $casts = [
        'customer_id' => 'integer',
        'delivery_address' => 'array',
        'subtotal' => 'decimal:2',
        'delivery_charge' => 'decimal:2',
        'coupon_discount' => 'decimal:2',
        'total' => 'decimal:2',
        'customer_lat' => 'decimal:8',
        'customer_lng' => 'decimal:8',
        'assigned_at' => 'datetime',
        'delivered_at' => 'datetime',
        // ADDED: Casts for delivery confirmation
        'delivery_lat' => 'decimal:8',
        'delivery_lng' => 'decimal:8',
        'delivery_date' => 'date',
        'uses_slot_at_checkout' => 'boolean',
    ];

    public function statusHistory()
    {
        return $this->hasMany(OrderStatusHistory::class)->latest();
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function deliveryBoy()
    {
        return $this->belongsTo(User::class, 'delivery_boy_id');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function couponUsage()
    {
        return $this->hasOne(CouponUsage::class);
    }

    public function isPending()
    {
        return $this->status === 'pending_payment';
    }

    public function isConfirmed()
    {
        return $this->status === 'confirmed';
    }

    public function isPaymentFailed()
    {
        return $this->status === 'payment_failed';
    }

    public function deliverySlot()
    {
        return $this->belongsTo(\App\Models\TenantDeliverySlot::class, 'delivery_slot_id');
    }
}
