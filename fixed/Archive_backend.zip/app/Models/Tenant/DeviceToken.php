<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Model;

class DeviceToken extends Model
{
    protected $fillable = ['customer_id', 'token', 'platform'];
}
