<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'email', 'phone', 'password', 'profile_photo',
        'latitude', 'longitude', 'location_permission',
        'status', 'status_changed_at',
        'phone_verified', 'email_verified_at',
        'dnd', 'warning_limit', 'suspension_limit', 
    ];

    protected $hidden = [
        'password', 'remember_token', 'email_verification_token', 'phone_otp',
    ];

    protected $casts = [
        'location_permission' => 'boolean',
        'phone_verified' => 'boolean',
        'status_changed_at' => 'datetime',
        'email_verified_at' => 'datetime',
        'phone_otp_expires_at' => 'datetime',
        'dnd' => 'boolean',
        'warning_limit' => 'float',
        'suspension_limit' => 'float',
    ];

    public function addresses(): HasMany
    {
        return $this->hasMany(CustomerAddress::class);
    }

    public function defaultAddress(): HasOne
    {
        return $this->hasOne(CustomerAddress::class)->where('is_default', true);
    }
}
