<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * ─────────────────────────────────────────────────────────────────────────
 * WebLayout — UPDATED with new customization fields
 *
 * Path: app/Models/Tenant/WebLayout.php
 *
 * New JSON columns:
 *   - navigation_config       → navbar links, styles, custom links
 *   - footer_config           → footer columns, social, copyright
 *   - product_display_config  → grid/list, columns, show/hide fields
 *   - custom_pages            → admin-created pages (FAQ, Privacy, etc.)
 * ─────────────────────────────────────────────────────────────────────────
 */
class WebLayout extends Model
{
    use SoftDeletes;

    protected $table = 'web_layouts';

    protected $fillable = [
        'version_name',
        'theme_config',
        'layout_components',
        // ★ NEW customization fields
        'navigation_config',
        'footer_config',
        'product_display_config',
        'custom_pages',
        'is_active',
        'is_draft',
        'published_at',
        'created_by',
    ];

    protected $casts = [
        'theme_config' => 'array',
        'layout_components' => 'array',
        // ★ NEW casts
        'navigation_config' => 'array',
        'footer_config' => 'array',
        'product_display_config' => 'array',
        'custom_pages' => 'array',
        'is_active' => 'boolean',
        'is_draft' => 'boolean',
        'published_at' => 'datetime',
    ];

    /**
     * Scope to fetch only active (published, non-draft) layouts.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true)->where('is_draft', false);
    }

    /**
     * Get the latest published layout for the current tenant.
     */
    public static function currentActive(): ?self
    {
        return static::active()
            ->latest('published_at')
            ->first();
    }
}
