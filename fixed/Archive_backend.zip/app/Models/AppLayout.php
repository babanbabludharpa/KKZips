<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class AppLayout extends Model
{
    protected $table = 'app_layouts';

    // ★ Added 'theme_config' — without this, $layout->fill(['theme_config' => ...])
    // silently drops the field and the value never reaches the database.
    protected $fillable = [
        'version_name',
        'components',
        'theme_config',   // ★ ADDED for mobile theme system
        'is_active',
        'is_draft',
        'scheduled_at',
        'expires_at',
        'created_by',
        'published_at',
    ];

    // ★ Added 'theme_config' => 'array' — without this, Laravel stores the
    // PHP array as the literal string "Array" instead of JSON, and reading
    // it back returns a string (not a Map). The Flutter LayoutProvider's
    // themeConfig getter checks `tc is Map` and returns {} for strings,
    // which is why ThemeProvider falls back to FlavorConfig defaults.
    protected $casts = [
        'components' => 'array',
        'theme_config' => 'array',   // ★ ADDED for mobile theme system
        'is_active' => 'boolean',
        'is_draft' => 'boolean',
        'scheduled_at' => 'datetime',
        'expires_at' => 'datetime',
        'published_at' => 'datetime',
    ];

    // ──────────────────────────────────────────────────────────────────
    // The tenant_id is NOT a column — it's resolved from the active
    // tenancy context. The event uses this accessor to build the channel
    // name: tenant.{tenantId}.layout
    // ──────────────────────────────────────────────────────────────────
    public function getTenantIdAttribute(): ?string
    {
        return tenant('id');
    }

    // ──────────────────────────────────────────────────────────────────
    // Scopes
    // ──────────────────────────────────────────────────────────────────
    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true)
            ->where('is_draft', false)
            ->where(function ($sq) {
                $sq->whereNull('scheduled_at')
                    ->orWhere('scheduled_at', '<=', now());
            })
            ->where(function ($sq) {
                $sq->whereNull('expires_at')
                    ->orWhere('expires_at', '>', now());
            });
    }

    /**
     * Returns the single active layout, with a deterministic tiebreaker.
     */
    public static function currentActive(): ?self
    {
        return static::active()
            ->orderByDesc('published_at')
            ->orderByDesc('id')
            ->first();
    }

    protected static function booted(): void
    {
        // When a layout is published, all others must be deactivated.
        // Doing it at the model level catches both `save()` and `create()`.
        static::saving(function (self $layout) {
            if ($layout->is_active && ! $layout->is_draft) {
                $layout->published_at = $layout->published_at ?? now();
            }
        });

        static::saved(function (self $layout) {
            if ($layout->is_active && ! $layout->is_draft) {
                // Deactivate others (excluding self) without firing events
                // to avoid recursion.
                static::where('id', '!=', $layout->id)
                    ->where('is_active', true)
                    ->update(['is_active' => false]);
            }
        });
    }
}
