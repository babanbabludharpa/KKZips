<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryChargeRule extends Model
{
    protected $fillable = [
        'name', 'min_order_amount', 'free_delivery_above',
        'base_charge', 'per_km_charge', 'max_charge',
        'max_delivery_km', 'is_active',
    ];

    protected $casts = [
        'min_order_amount' => 'decimal:2',
        'free_delivery_above' => 'decimal:2',
        'base_charge' => 'decimal:2',
        'per_km_charge' => 'decimal:2',
        'max_charge' => 'decimal:2',
        'max_delivery_km' => 'decimal:2',
        'is_active' => 'boolean',
    ];
}
