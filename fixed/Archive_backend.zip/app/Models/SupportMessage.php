<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SupportMessage extends Model
{
    protected $fillable = [
        'conversation_id',
        'sender_type',
        'sender_user_id',
        'message',
        'matched_faq_id',
        'confidence',
        'metadata',
    ];

    protected $casts = [
        'confidence' => 'float',
        'metadata' => 'array',
    ];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(SupportConversation::class, 'conversation_id');
    }

    public function matchedFaq(): BelongsTo
    {
        return $this->belongsTo(FaqItem::class, 'matched_faq_id');
    }

    public function isFromCustomer(): bool
    {
        return $this->sender_type === 'customer';
    }

    public function isFromBot(): bool
    {
        return $this->sender_type === 'bot';
    }

    public function isFromAgent(): bool
    {
        return $this->sender_type === 'agent';
    }
}
