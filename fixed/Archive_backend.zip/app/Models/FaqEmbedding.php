<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FaqEmbedding extends Model
{
    protected $fillable = [
        'faq_item_id',
        'model_name',
        'vector',
        'source_text',
    ];

    protected $casts = [
        'vector' => 'array',
    ];

    public function faqItem(): BelongsTo
    {
        return $this->belongsTo(FaqItem::class, 'faq_item_id');
    }

    public function scopeModel($query, string $modelName)
    {
        return $query->where('model_name', $modelName);
    }

    /**
     * Cosine similarity between two vectors. Returns -1.0 to 1.0,
     * where 1.0 is identical direction. Safe on zero-magnitude
     * vectors (returns 0.0 instead of dividing by zero).
     */
    public static function cosine(array $a, array $b): float
    {
        $len = min(count($a), count($b));
        if ($len === 0) {
            return 0.0;
        }

        $dot = 0.0;
        $magA = 0.0;
        $magB = 0.0;

        for ($i = 0; $i < $len; $i++) {
            $dot += $a[$i] * $b[$i];
            $magA += $a[$i] * $a[$i];
            $magB += $b[$i] * $b[$i];
        }

        $magA = sqrt($magA);
        $magB = sqrt($magB);

        if ($magA == 0.0 || $magB == 0.0) {
            return 0.0;
        }

        return $dot / ($magA * $magB);
    }
}
