<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InvoiceItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'invoice_id', 'subscription_occurrence_id', 'description', 'qty', 'unit_price',
        'discount_percent', 'final_price', 'tax_rate_percent', 'taxable_value', 'tax_type',
        'cgst_amount', 'sgst_amount', 'igst_amount', 'tax_amount', 'line_total',
    ];

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function occurrence(): BelongsTo
    {
        return $this->belongsTo(SubscriptionOccurrence::class, 'subscription_occurrence_id');
    }
}
