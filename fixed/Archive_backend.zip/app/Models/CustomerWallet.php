<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerWallet extends Model
{
    use HasFactory;

    protected $primaryKey = 'customer_id';

    public $incrementing = false;

    protected $fillable = ['customer_id', 'balance'];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
