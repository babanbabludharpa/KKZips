<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    protected $fillable = [
        'name',
        'code',
        'type',
        'parent_id',
        'address',
        'city_id',
        'state_id',
        'pincode',
        'phone',
        'contact_email',
        'gst_no',
        'fssai_no',
        'warehouse_id',
        'latitude',
        'longitude',
        'opens_at',
        'closes_at',
        'is_accepting_orders',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_accepting_orders' => 'boolean',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function state()
    {
        return $this->belongsTo(State::class);
    }

    public function warehouse()
    {
        return $this->belongsTo(Warehouse::class);
    }

    public function parent()
    {
        return $this->belongsTo(Branch::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Branch::class, 'parent_id');
    }

    public function serviceZones()
    {
        return $this->hasMany(BranchServiceZone::class);
    }

    public function inventory()
    {
        return $this->hasMany(Inventory::class);
    }

    // ── Helpers ────────────────────────────────────────────────────

    /**
     * Whether this branch is currently open based on operating hours.
     * Handles midnight-crossing schedules (e.g. 22:00 – 02:00).
     * Does not consider is_accepting_orders — check that separately.
     */
    public function isCurrentlyOpen(): bool
    {
        if (! $this->opens_at || ! $this->closes_at) {
            return true;
        }

        $now = now()->format('H:i');
        $opens = substr($this->opens_at, 0, 5);
        $closes = substr($this->closes_at, 0, 5);

        return $closes > $opens
            ? ($now >= $opens && $now <= $closes)       // normal day hours
            : ($now >= $opens || $now <= $closes);      // midnight-crossing
    }
}
