<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class DeliveryBoy extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;

    protected $guard = 'rider';

    protected $fillable = [
        'name', 'username', 'mobile_number', 'email', 'password',
        'branch_id', 'vehicle_type', 'max_daily_deliveries',
        'is_online', 'is_active', 'current_lat', 'current_lng', 'fcm_token',
        'adhar_no', 'pan_no', 'emergency_contact_no',
        'bank_account_holder', 'bank_name', 'bank_account_no', 'bank_ifsc', 'upi_id',
        'adhar_doc', 'pan_doc', 'driving_licence_doc',
    ];

    protected $hidden = [
        'password', 'remember_token',
        'adhar_no', 'pan_no', 'bank_account_no',
        'adhar_doc', 'pan_doc', 'driving_licence_doc',
    ];

    protected $casts = [
        'is_online' => 'boolean',
        'is_active' => 'boolean',
        'last_login_at' => 'datetime',
        'adhar_no' => 'encrypted',
        'pan_no' => 'encrypted',
        'bank_account_no' => 'encrypted',
    ];

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function zones()
    {
        return $this->belongsToMany(
            BranchServiceZone::class,
            'delivery_boy_zones',
            'delivery_boy_id',
            'zone_id'
        );
    }

    public function slots()
    {
        return $this->belongsToMany(
            TenantDeliverySlot::class,
            'delivery_boy_slots',
            'delivery_boy_id',
            'slot_id'
        )->withPivot('day_of_week', 'is_available');
    }

    public function leaves()
    {
        return $this->hasMany(DeliveryBoyLeave::class);
    }
}
