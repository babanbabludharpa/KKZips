<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChangeMaster extends Model
{
    protected $table = 'change_masters';

    protected $fillable = [
        'username', 'added_by', 'ip_address',
        'flag', 'panel', 'remark', 'previous_value', 'new_value',
    ];

    // ── flag: what action was performed ──────────────────────────
    // ASSUMPTION: numbering invented here, NOT confirmed against any
    // existing convention in your core-PHP system. If that system already
    // assigns specific numbers to these actions (needed for cross-system
    // reporting), give me the real values and I'll renumber -- these are
    // placeholders, not a settled contract.
    public const FLAG_FORGOT_PASSWORD = 1; // admin forgot password

    public const FLAG_CUSTOMER_STATUS_CHANGE = 2; // admin changes a customer's status (active/inactive/suspended)

    public const FLAG_USER_DETAILS_CHANGED = 3; // name/email/role/branch changed via Users CRUD

    public const FLAG_PASSWORD_CHANGED_BY_ADMIN = 4;  // if you still need it

    // ── panel: where the change originated ───────────────────────
    // Same ASSUMPTION as above.
    public const PANEL_ADMIN = 1;

    public const PANEL_CUSTOMER_APP = 2;

    public const PANEL_RIDER_APP = 3;

    // Never populate previous_value/new_value with an actual password
    // value (plaintext or hash) -- this table is a readable audit log,
    // not a secret store. For password-related actions, log a remark
    // only and leave both fields as empty strings.
}
