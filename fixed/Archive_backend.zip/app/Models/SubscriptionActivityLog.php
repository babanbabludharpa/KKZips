<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SubscriptionActivityLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'subscription_id', 'subscription_item_id', 'customer_id',
        'event_type', 'actor_type', 'actor_id',
        'occurrence_date', 'description', 'metadata',
    ];

    protected $casts = [
        'occurrence_date' => 'date',
        'metadata' => 'array',
    ];

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    public function subscriptionItem(): BelongsTo
    {
        return $this->belongsTo(SubscriptionItem::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
