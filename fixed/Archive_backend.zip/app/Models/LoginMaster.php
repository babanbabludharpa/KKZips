<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoginMaster extends Model
{
    protected $table = 'login_masters';

    // logged_in_at / logged_out_at carry the meaningful timestamps for
    // this log; created_at/updated_at would be redundant with them, so
    // Eloquent's automatic timestamps are switched off here.
    public $timestamps = false;

    protected $fillable = [
        'username', 'ip_address', 'logged_in_at', 'logged_out_at',
    ];

    // No sentinel constant needed anymore -- logged_out_at is nullable,
    // so "still logged in" is simply WHERE logged_out_at IS NULL.
}
