<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PriceSchedule extends Model
{
    protected $fillable = [
        'product_variant_id', 'mrp', 'selling_price', 'purchase_price',
        'effective_from', 'status', 'created_by',
    ];

    protected $casts = [
        'mrp' => 'decimal:2',
        'selling_price' => 'decimal:2',
        'purchase_price' => 'decimal:2',
        'effective_from' => 'date',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
