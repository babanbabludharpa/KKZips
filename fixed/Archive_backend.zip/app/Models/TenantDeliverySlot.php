<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TenantDeliverySlot extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'start_time',
        'end_time',
        'cutoff_time',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];
}
