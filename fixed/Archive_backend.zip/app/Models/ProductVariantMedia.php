<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class ProductVariantMedia extends Model
{
    protected $fillable = [
        'product_variant_id',
        'type',
        'path',
        'original_name',
        'mime_type',
        'size',
        'sort_order',
    ];

    protected $casts = [
        'size' => 'integer',
        'sort_order' => 'integer',
    ];

    // Include the computed URL whenever the model is serialized.
    protected $appends = ['url'];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    /**
     * `path` holds the FILENAME ONLY — the same convention as the legacy
     * `image` column on product_variants. Files live in
     * tenants/{tenantId}/variants/ on the public disk; rebuild the full
     * URL here so consumers never have to know the folder structure.
     */
    public function getUrlAttribute(): string
    {
        return Storage::disk('public')
            ->url('tenants/'.tenant('id').'/variants/'.$this->path);
    }
}
