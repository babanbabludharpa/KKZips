<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'username',
        'mobile_number',
        'password',
        'branch_id',
        'avatar',
        'force_password_change',
        'adhar_no',
        'adhar_hash',
        'pan_no',
        'emergency_contact_no',
        'bank_account_holder',
        'bank_name',
        'bank_account_no',
        'bank_ifsc',
        'upi_id',
        'adhar_doc',
        'pan_doc',
    ];

    /**
     * The attributes that should be hidden for serialization.
     * KYC fields are hidden so a raw User (login, /me) never leaks them;
     * UserResource reads the attributes directly.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'adhar_no',
        'adhar_hash',
        'pan_no',
        'emergency_contact_no',
        'bank_account_holder',
        'bank_name',
        'bank_account_no',
        'bank_ifsc',
        'upi_id',
        'adhar_doc',
        'pan_doc',
    ];

    /**
     * Always append avatar_url to array/JSON serialization.
     *
     * @var list<string>
     */
    protected $appends = [
        'avatar_url',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'force_password_change' => 'boolean',
            'adhar_no' => 'encrypted',
            'pan_no' => 'encrypted',
            'bank_account_no' => 'encrypted',
        ];
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    /**
     * Full public URL of the user's avatar, with a cache-busting ?v= timestamp.
     * Returns null when no avatar is set.
     */
    public function getAvatarUrlAttribute(): ?string
    {
        if (empty($this->avatar)) {
            return null;
        }

        // $this->avatar holds e.g. "tenants/infosoft/users/42/profile.jpg"
        $disk = Storage::disk('public');

        if (! $disk->exists($this->avatar)) {
            return null;
        }

        return $disk->url($this->avatar).'?v='.$disk->lastModified($this->avatar);
    }
}
