<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Invoice extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id', 'period_start', 'period_end',
        'subtotal', 'cgst_total', 'sgst_total', 'igst_total', 'tax_total',
        'manual_adjustment_amount', 'manual_adjustment_reason', 'adjusted_by',
        'total', 'amount_paid', 'amount_due', 'status',
        'generated_at', 'generated_by',
        'cancelled_at', 'cancelled_by', 'cancellation_reason',
    ];

    protected $casts = [
        'customer_id' => 'integer',
        'period_start' => 'date',
        'period_end' => 'date',
        'generated_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(InvoicePayment::class);
    }

    public function occurrences(): HasMany
    {
        return $this->hasMany(SubscriptionOccurrence::class);
    }
}
