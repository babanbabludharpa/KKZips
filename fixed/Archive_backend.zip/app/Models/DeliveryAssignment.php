<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class DeliveryAssignment extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'occurrence_date', 'delivery_boy_id', 'subscription_occurrence_id', 'sequence', 'status',
    ];

    protected $casts = [
        'occurrence_date' => 'date',
        'delivery_boy_id' => 'integer',
    ];

    public function deliveryBoy(): BelongsTo
    {
        return $this->belongsTo(DeliveryBoy::class, 'delivery_boy_id');
    }

    public function occurrence(): BelongsTo
    {
        return $this->belongsTo(SubscriptionOccurrence::class, 'subscription_occurrence_id');
    }
}