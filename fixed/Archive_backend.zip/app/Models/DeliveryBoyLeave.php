<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DeliveryBoyLeave extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'delivery_boy_id',
        'slot_id',
        'start_date',
        'end_date',
        'reason',
        'deleted_by',
    ];

    protected $casts = [
        'delivery_boy_id' => 'integer',
        'slot_id' => 'integer',
        'start_date' => 'date',
        'end_date' => 'date',
        'deleted_by' => 'integer',
    ];

    public function deliveryBoy()
    {
        return $this->belongsTo(DeliveryBoy::class);
    }

    public function slot()
    {
        return $this->belongsTo(TenantDeliverySlot::class, 'slot_id');
    }

    public function deletedBy()
    {
        return $this->belongsTo(User::class, 'deleted_by');
    }
}
