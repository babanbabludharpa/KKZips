<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Category extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name', 'slug', 'description', 'image', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    protected $appends = ['image_url'];

    public function getImageUrlAttribute(): ?string
    {
        // Derived from APP_URL via the storage disk config — resolves
        // correctly on its own in every environment (offline
        // http://inventory.test:8080, online https://kutumbkart.in) with
        // no hardcoded host/IP and no per-environment edit needed. The
        // stored $this->image path is already tenant-scoped as of
        // CategoryService's create()/update() (tenants/{id}/categories/...).
        return $this->image
            ? Storage::disk('public')->url($this->image)
            : null;
    }

    protected static function booted(): void
    {
        static::creating(fn ($c) => $c->slug ??= Str::slug($c->name));
        static::updating(fn ($c) => $c->slug = Str::slug($c->name));

        // Deliberately NOT on the regular 'deleted' event — that fires on
        // soft delete too, and this model uses SoftDeletes. Deleting the
        // physical file there would make a restored category permanently
        // lose its image. Only clean up on a genuine force delete.
        static::forceDeleted(function ($c) {
            if ($c->image) {
                Storage::disk('public')->delete($c->image);
            }
        });
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
