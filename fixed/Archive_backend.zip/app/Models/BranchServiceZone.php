<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BranchServiceZone extends Model
{
    protected $fillable = [
        'branch_id',
        'name',
        'is_active',
        'created_by',
    ];

    // coordinates is a spatial column — handled via raw queries in the service
    // never put it in fillable or casts

    protected $casts = [
        'branch_id' => 'integer',
        'is_active' => 'boolean',
    ];

    protected $hidden = ['coordinates'];

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
