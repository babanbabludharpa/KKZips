<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiscountSchedule extends Model
{
    protected $fillable = [
        'product_variant_id', 'discount_percent',
        'starts_on', 'ends_on', 'status', 'created_by',
    ];

    protected $casts = [
        'discount_percent' => 'decimal:2',
        'starts_on' => 'date',
        'ends_on' => 'date',
    ];

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
