<?php

namespace App\Models;

use Stancl\Tenancy\Contracts\TenantWithDatabase;
use Stancl\Tenancy\Database\Concerns\HasDatabase;
use Stancl\Tenancy\Database\Concerns\HasDomains;
use Stancl\Tenancy\Database\Models\Tenant as BaseTenant;

class Tenant extends BaseTenant implements TenantWithDatabase
{
    use HasDatabase, HasDomains;

    protected $fillable = [
        'id',
        'name',
        'email',
        'plan',
        'status',
        'theme_key',  // real column — already in DB
    ];

    /**
     * Tell Stancl which fields are REAL columns vs stored in the `data` JSON blob.
     * theme_key is a real column so it goes here.
     * custom_tokens does NOT exist as a column — it goes into `data` JSON automatically.
     */
    public static function getCustomColumns(): array
    {
        return [
            'id',
            'name',
            'email',
            'plan',
            'status',
            'theme_key',  // ← real column, declare it here
        ];
    }

    /**
     * custom_tokens lives inside the `data` JSON blob (Stancl default).
     * Access it as: $tenant->custom_tokens
     * Stancl handles serialization automatically for anything not in getCustomColumns().
     */
}
