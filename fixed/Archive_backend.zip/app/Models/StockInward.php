<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockInward extends Model
{
    protected $fillable = [
        'supplier_id', 'branch_id', 'received_date', 'notes', 'created_by',
    ];

    protected $casts = [
        'received_date' => 'date',
    ];

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function items()
    {
        return $this->hasMany(StockInwardItem::class);
    }
}
