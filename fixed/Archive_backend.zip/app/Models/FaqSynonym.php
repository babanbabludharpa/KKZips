<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FaqSynonym extends Model
{
    protected $fillable = [
        'word',
        'synonyms',
        'language',
    ];

    protected $casts = [
        'synonyms' => 'array',
    ];

    public function scopeLanguage($query, string $lang)
    {
        return $query->where('language', $lang);
    }

    /**
     * Expand a token to include every known synonym. Returns the
     * original token plus its synonyms (never replaces, only augments)
     * so the matcher always has at least the input to work with.
     */
    public static function expand(string $token, string $language = 'en'): array
    {
        $token = mb_strtolower(trim($token));

        $row = static::where('language', $language)
            ->whereRaw('LOWER(word) = ?', [$token])
            ->first();

        if (! $row) {
            return [$token];
        }

        $syns = array_map(
            fn ($s) => mb_strtolower(trim($s)),
            $row->synonyms ?? []
        );

        return array_values(array_unique(array_merge([$token], $syns)));
    }
}
