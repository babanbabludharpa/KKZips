<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockInwardItem extends Model
{
    protected $fillable = [
        'stock_inward_id', 'product_variant_id', 'quantity', 'expiry_date',
    ];

    protected $casts = [
        'expiry_date' => 'date',
    ];

    public function stockInward()
    {
        return $this->belongsTo(StockInward::class);
    }

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }
}
