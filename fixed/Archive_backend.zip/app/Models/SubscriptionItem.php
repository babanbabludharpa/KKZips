<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SubscriptionItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'subscription_id', 'product_variant_id', 'slot_id', 'default_qty',
        'schedule_type', 'schedule_days', 'schedule_dates', 'status', 'qty_by_day',
    ];

    protected $casts = [
        'schedule_days' => 'array',
        'schedule_dates' => 'array',
        'qty_by_day' => 'array',
        'slot_id' => 'integer',
    ];

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    public function productVariant(): BelongsTo
    {
        return $this->belongsTo(ProductVariant::class);
    }

    public function slot(): BelongsTo
    {
        return $this->belongsTo(TenantDeliverySlot::class, 'slot_id');
    }

    public function pauses(): HasMany
    {
        return $this->hasMany(SubscriptionPause::class);
    }

    public function occurrences(): HasMany
    {
        return $this->hasMany(SubscriptionOccurrence::class);
    }

    /**
     * Whether this item runs on the given day, per schedule_type/schedule_days.
     * 'alternate' is anchored to the subscription's start_date: every other
     * day counting from there (day 0, 2, 4... run; day 1, 3, 5... skip).
     */
    public function runsOn(\DateTimeInterface $date): bool
    {
        return match ($this->schedule_type) {
            'daily' => true,
            'custom_days' => in_array((int) $date->format('w'), $this->schedule_days ?? []),
            // 'weekly' is behaviorally identical to custom_days - it's a
            // recurring weekday pattern, just constrained to exactly one
            // day at creation time for a friendlier customer-facing label.
            // If this and custom_days ever diverge in meaning, split this
            // back out into its own method.
            'weekly' => in_array((int) $date->format('w'), $this->schedule_days ?? []),
            'custom_dates' => in_array(Carbon::parse($date)->toDateString(), $this->schedule_dates ?? []),
            'alternate' => $this->runsOnAlternate($date),
            default => false,
        };
    }

    protected function runsOnAlternate(\DateTimeInterface $date): bool
    {
        $anchor = Carbon::parse($this->subscription->start_date)->startOfDay();
        $target = Carbon::parse($date)->startOfDay();

        if ($target->lt($anchor)) {
            return false;
        }

        return $anchor->diffInDays($target) % 2 === 0;
    }

    /**
     * Resolves effective quantity for a date, in priority order:
     * 1. subscription_qty_overrides covering this date (ad-hoc, customer or admin initiated)
     * 2. qty_by_day standing weekly pattern (JSON keyed by Carbon dayOfWeek: 0=Sun..6=Sat)
     * 3. default_qty fallback
     */
    public function resolveQtyForDate(\DateTimeInterface $date): int
    {
        $override = $this->qtyOverrides()->covering($date)->first();
        if ($override) {
            return $override->qty;
        }

        $dayKey = (string) Carbon::parse($date)->dayOfWeek;
        if (is_array($this->qty_by_day) && array_key_exists($dayKey, $this->qty_by_day)) {
            return (int) $this->qty_by_day[$dayKey];
        }

        return $this->default_qty;
    }

    public function qtyOverrides(): HasMany
    {
        return $this->hasMany(SubscriptionQtyOverride::class);
    }
}
