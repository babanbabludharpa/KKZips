<?php

namespace App\Models;

use App\Services\V1\Tenant\TenantProfileService;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class SubscriptionOccurrence extends Model
{
    use HasFactory;

    protected $fillable = [
        'subscription_item_id', 'occurrence_date', 'qty', 'unit_price_snapshot',
        'status', 'skip_source', 'not_delivered_reason', 'not_delivered_note',
        'delivery_boy_id', 'assignment_type', 'assigned_by', 'assigned_at',
        'delivered_at', 'delivery_note', 'invoice_id',
        'delivery_lat', 'delivery_lng', 'delivery_photo_path', 'branch_id',
        'leave_id', 'leave_previous_status', 'leave_cancellation_reason',
    ];

    protected $casts = [
        'occurrence_date' => 'date',
        'delivered_at' => 'datetime',
        'assigned_at' => 'datetime',
        'delivery_lat' => 'float',
        'delivery_lng' => 'float',
    ];

    public function subscriptionItem(): BelongsTo
    {
        return $this->belongsTo(SubscriptionItem::class);
    }

    public function deliveryBoy(): BelongsTo
    {
        return $this->belongsTo(DeliveryBoy::class, 'delivery_boy_id');
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function deliveryAssignment(): HasOne
    {
        return $this->hasOne(DeliveryAssignment::class);
    }

    public function isLocked(): bool
    {
        return self::isDateLocked($this->occurrence_date);
    }

    protected static function cutoffMoment(\Illuminate\Support\Carbon $today): \Illuminate\Support\Carbon
    {
        $profile = app(TenantProfileService::class)->getProfile();
        $cutoffTime = $profile?->subscription_cutoff_time ?? '20:00';

        [$hour, $minute] = array_map('intval', explode(':', $cutoffTime));

        return $today->copy()->setTime($hour, $minute);
    }

    public static function getCutoffTime(): string
    {
        $today = now()->startOfDay();

        return self::cutoffMoment($today)->format('H:i');
    }

    public static function isDateLocked(\DateTimeInterface $occurrenceDate): bool
    {
        $now = now();
        $today = $now->copy()->startOfDay();
        $tomorrow = $today->copy()->addDay();
        $cutoff = self::cutoffMoment($today);

        $date = Carbon::parse($occurrenceDate)->startOfDay();

        if ($date->lte($today)) {
            return true;
        }

        if ($date->equalTo($tomorrow) && $now->gte($cutoff)) {
            return true;
        }

        return false;
    }

    public static function earliestSelectableDate(): \Illuminate\Support\Carbon
    {
        $now = now();
        $today = $now->copy()->startOfDay();
        $cutoff = self::cutoffMoment($today);

        $daysAhead = $now->gte($cutoff) ? 2 : 1;

        return $today->copy()->addDays($daysAhead);
    }

    public static function actorBypassesCutoffLock(string $actorType): bool
    {
        if ($actorType !== 'admin') {
            return false;
        }

        $profile = app(TenantProfileService::class)->getProfile();

        return ! ($profile?->subscription_cutoff_restrict_admin ?? false);
    }

    /**
     * Whether a delivery slot can be booked if the customer/admin picks
     * this start_date.
     *
     * Rules:
     *   - start_date before today             → never bookable
     *   - start_date after today              → always bookable
     *   - start_date === today:
     *       * policy = next_day_only          → never bookable
     *       * policy = same_day_slot_wise     → slot.start_time must be
     *                                           >= now + same_day_lead_time_minutes
     *
     * This is the single source of truth for the "past slot on today" rule.
     * Both StoreSubscriptionRequest (admin) and CustomerStoreSubscriptionRequest
     * (mobile/web) call it. Frontend dropdowns use the same rule so the UI
     * never shows an unbookable slot.
     */
    public static function isSlotBookableForStartDate(
        string|\DateTimeInterface $startDate,
        \App\Models\TenantDeliverySlot $slot,
    ): bool {
        $today = now()->copy()->startOfDay();
        $start = Carbon::parse($startDate)->startOfDay();

        if ($start->lt($today)) {
            return false;
        }

        if ($start->gt($today)) {
            return true;
        }

        // start_date === today
        $profile = app(TenantProfileService::class)->getProfile();
        $policy = $profile?->subscription_start_policy ?? 'next_day_only';

        if ($policy !== 'same_day_slot_wise') {
            return false;
        }

        $leadMinutes = (int) ($profile?->same_day_lead_time_minutes ?? 120);

        $slotStart = Carbon::parse(
            $today->toDateString() . ' ' . $slot->start_time
        );

        return $slotStart->gte(now()->copy()->addMinutes($leadMinutes));
    }
}
