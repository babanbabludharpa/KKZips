<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FaqItem extends Model
{
    protected $fillable = [
        'faq_group_id',
        'collection_id',
        'language',
        'question',
        'answer',
        'alternative_questions',
        'keywords',
        'sort_order',
        'is_active',
        'view_count',
        'helpful_count',
        'not_helpful_count',
        'metadata',
        'customized_at',
    ];

    protected $casts = [
        'alternative_questions' => 'array',
        'keywords' => 'array',
        'metadata' => 'array',
        'is_active' => 'boolean',
        'sort_order' => 'integer',
        'view_count' => 'integer',
        'helpful_count' => 'integer',
        'not_helpful_count' => 'integer',
        'customized_at' => 'datetime',
    ];

    public function collection(): BelongsTo
    {
        return $this->belongsTo(FaqCollection::class, 'collection_id');
    }

    public function embeddings(): HasMany
    {
        return $this->hasMany(FaqEmbedding::class, 'faq_item_id');
    }

    /**
     * Sibling translations of the same logical FAQ — includes self,
     * because callers usually want "give me every language variant of
     * this FAQ" and having to re-add the current row at the call site
     * is easy to forget.
     *
     * Returns a query, not a loaded relation, so callers can further
     * scope (e.g. ->where('language', 'hi')).
     */
    public function siblings()
    {
        if (! $this->faq_group_id) {
            // Standalone FAQ — no translations exist. Return a query
            // that matches only this row, so calling code never has
            // to special-case NULL faq_group_id.
            return static::where('id', $this->id);
        }

        return static::where('faq_group_id', $this->faq_group_id);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeLanguage($query, string $lang)
    {
        return $query->where('language', $lang);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('question');
    }

    /**
     * Every searchable string on this row, in the order the matcher
     * should weight them:
     *   1. The primary question (highest weight)
     *   2. Alternative questions (medium)
     *   3. Keywords (lowest — used for pre-filtering, not scoring)
     *
     * The matcher consumes this to build its per-FAQ search text and
     * to feed the embedding model.
     */
    public function searchableTexts(): array
    {
        return array_values(array_filter(array_merge(
            [$this->question],
            $this->alternative_questions ?? [],
        )));
    }

    public function incrementViewCount(): void
    {
        $this->increment('view_count');
    }

    public function recordHelpful(): void
    {
        $this->increment('helpful_count');
    }

    public function recordNotHelpful(): void
    {
        $this->increment('not_helpful_count');
    }

    /**
     * Helpfulness ratio — null when nobody has voted yet (so callers
     * can distinguish "no data" from "0% helpful" rather than getting
     * a misleading 0).
     */
    public function helpfulRatio(): ?float
    {
        $total = $this->helpful_count + $this->not_helpful_count;
        if ($total === 0) {
            return null;
        }

        return $this->helpful_count / $total;
    }
}
