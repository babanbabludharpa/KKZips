import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// ─────────────────────────────────────────────────────────────────────────
// vite.config.js  —  added /broadcasting proxy for Pusher auth
//
// Your existing /api and /storage proxies stay. We ADD /broadcasting so
// Pusher's auth POST (which goes to /broadcasting/auth absolute path)
// is forwarded to your Laravel backend on port 8000.
// ─────────────────────────────────────────────────────────────────────────

export default defineConfig({
  plugins: [
    tailwindcss(),
    react(),
  ],
  server: {
    proxy: {
      '/api': {
        target: 'http://192.168.29.147:8000',
        changeOrigin: true,
      },
      '/storage': {
        target: 'http://192.168.29.147:8000',
        changeOrigin: true,
      },
      // ★ NEW: Pusher broadcasting auth
      '/broadcasting': {
        target: 'http://192.168.29.147:8000',
        changeOrigin: true,
      },
    }
  }
})
