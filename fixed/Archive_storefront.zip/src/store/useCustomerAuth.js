import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import customerApi, { unwrap } from '../api/customerApi'

// ─────────────────────────────────────────────────────────────────────────
// useCustomerAuth.js
//
// Customer auth store. Persists to localStorage under
// `customer-auth-storage`. The axios interceptor in customerApi.js reads
// `state.token` from this same key to attach the Bearer header.
//
// Does NOT store tenantId — that's resolved from the URL by
// customerApi.js. Clean separation of concerns:
//   • useCustomerAuth  → WHO is the customer?
//   • URL subdomain    → WHICH tenant are they on?
// ─────────────────────────────────────────────────────────────────────────

export const useCustomerAuth = create(
  persist(
    (set, get) => ({
      token: null,
      customer: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      // ── Hydrate on app boot (call from App.jsx useEffect) ─────────────
      hydrate: async () => {
        const { token } = get()
        if (!token) return false

        try {
          const data = await unwrap(await customerApi.get('/mobile/auth/me'))
          set({
            customer: data?.customer ?? null,
            isAuthenticated: true,
            error: null,
          })
          return true
        } catch (e) {
          set({
            token: null,
            customer: null,
            isAuthenticated: false,
            error: null,
          })
          return false
        }
      },

      // ── Login ──────────────────────────────────────────────────────────
      // Returns true on success, false on failure. Sets `error` on failure.
      login: async ({ phone, password }) => {
        set({ isLoading: true, error: null })
        try {
          const data = await unwrap(
            await customerApi.post('/mobile/auth/login', { phone, password })
          )
          set({
            token: data.token,
            customer: data.customer,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          })
          return true
        } catch (e) {
          set({
            isLoading: false,
            error:
              e?.response?.data?.message ||
              e?.body?.message ||
              e.message ||
              'Login failed. Please try again.',
          })
          return false
        }
      },

      // ── Register ───────────────────────────────────────────────────────
      register: async ({ name, email, password, phone }) => {
        set({ isLoading: true, error: null })
        try {
          const data = await unwrap(
            await customerApi.post('/mobile/auth/register', {
              name, email, password, phone: phone || '',
            })
          )
          set({
            token: data.token,
            customer: data.customer,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          })
          return true
        } catch (e) {
          const errs = e?.response?.data?.errors || e?.body?.errors
          const firstErr = errs ? Object.values(errs)[0]?.[0] : null
          set({
            isLoading: false,
            error:
              firstErr ||
              e?.response?.data?.message ||
              e?.body?.message ||
              e.message ||
              'Registration failed.',
          })
          return false
        }
      },

      // ── Logout ─────────────────────────────────────────────────────────
      logout: async () => {
        try {
          await customerApi.post('/mobile/auth/logout', {})
        } catch (_) {}
        set({
          token: null,
          customer: null,
          isAuthenticated: false,
          error: null,
        })
      },

      // ── Update profile ─────────────────────────────────────────────────
      updateProfile: async ({ name, phone }) => {
        try {
          const data = await unwrap(
            await customerApi.post('/mobile/auth/update-profile', {
              name,
              ...(phone !== undefined ? { phone } : {}),
            })
          )
          set({ customer: data?.customer ?? get().customer })
          return true
        } catch (e) {
          set({
            error:
              e?.response?.data?.message ||
              e?.body?.message ||
              e.message ||
              'Failed to update profile.',
          })
          return false
        }
      },

      // ── Change password ────────────────────────────────────────────────
      changePassword: async ({ currentPassword, newPassword }) => {
        try {
          await unwrap(
            await customerApi.post('/mobile/auth/change-password', {
              current_password: currentPassword,
              password: newPassword,
              password_confirmation: newPassword,
            })
          )
          return null // null = success
        } catch (e) {
          const errs = e?.response?.data?.errors || e?.body?.errors
          const firstErr = errs ? Object.values(errs)[0]?.[0] : null
          return (
            firstErr ||
            e?.response?.data?.message ||
            e?.body?.message ||
            e.message ||
            'Failed to change password.'
          )
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'customer-auth-storage',
      partialize: (s) => ({
        token: s.token,
        customer: s.customer,
        isAuthenticated: s.isAuthenticated,
      }),
    }
  )
)
