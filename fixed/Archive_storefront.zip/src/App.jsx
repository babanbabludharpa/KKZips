import { BrowserRouter } from 'react-router-dom'
import AppRoutes from './routes/AppRoutes'
import { CartProvider } from './pages/CartContext'
import { AuthProvider } from './contexts/AuthContext'
import { TenantProvider, useTenant } from './contexts/TenantProvider'
import { Toaster } from 'react-hot-toast';
import { SubscriptionProvider } from './pages/SubscriptionContext'   // ★ THE FIX

// ★ NEW — Hard gate: shows plain spinner until tenant layout is ready
function AppGate({ children }) {
  const { ready } = useTenant();

  if (!ready) {
    return (
      <div
        style={{
          position: "fixed",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#ffffff",
        }}
      >
        <div
          style={{
            width: 36,
            height: 36,
            border: "3px solid #e5e5e5",
            borderTopColor: "#999",
            borderRadius: "50%",
            animation: "spin 0.8s linear infinite",
          }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
      </div>
    );
  }

  return children;
}

function App() {
  return (
    <TenantProvider>
      <AppGate>
        <AuthProvider>
          <CartProvider>
            <SubscriptionProvider>          {/* ★ ADD — wraps everything */}
              <BrowserRouter>
                <AppRoutes />
                <Toaster 
                  position="top-center"
                  reverseOrder={false}
                  toastOptions={{
                    style: {
                      fontFamily: "'Plus Jakarta Sans', sans-serif",
                      fontWeight: 700,
                      borderRadius: '16px',
                      padding: '16px 24px',
                      color: '#1E293B',
                      boxShadow: '0 12px 40px rgba(0,0,0,0.12)',
                      border: '1px solid #E2E8F0'
                    },
                    success: { iconTheme: { primary: '#22C55E', secondary: '#fff' } },
                    error: { iconTheme: { primary: '#EF4444', secondary: '#fff' } },
                  }} 
                />
              </BrowserRouter>
            </SubscriptionProvider>         {/* ★ ADD */}
          </CartProvider>
        </AuthProvider>
      </AppGate>
    </TenantProvider>
  )
}

export default App