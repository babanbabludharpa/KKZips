import axios from "axios";

const hostname = window.location.hostname;
let tenantId = hostname.split(".")[0];

if (hostname === "localhost" || hostname === "127.0.0.1") {
  tenantId = "infosoft"; // fallback for local dev
}

const api = axios.create({
  baseURL: "/api/v1/mobile", 
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "X-Tenant": tenantId, // Dynamic tenant!
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("auth_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;