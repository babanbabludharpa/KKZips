import React from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// GradientHero.jsx  —  FIXED gradient (uses color-mix for darker shade)
//
// Previous bug: used var(--color-primary) for BOTH gradient stops, so when
// the CSS variable was set, both stops were the same color → flat, no gradient.
//
// Fix: stop 1 uses var(--color-primary), stop 2 uses color-mix() to darken
// the primary color by 35%. Works regardless of what --color-primary is.
//
// color-mix() browser support: Chrome 111+, Firefox 113+, Safari 16.2+.
// Fallback: if color-mix isn't supported, the gradient still works but
// uses the hardcoded fallback colors.
// ─────────────────────────────────────────────────────────────────────────

export default function GradientHero({
  hero,
  Link,
  theme = { primary: "#FF7132", primaryHover: "#EA580C" },
}) {
  if (!hero) return null;

  const alignStyle =
    hero.alignment === "left"
      ? { textAlign: "left", marginLeft: "5vw", marginRight: "auto" }
      : hero.alignment === "right"
      ? { textAlign: "right", marginLeft: "auto", marginRight: "5vw" }
      : { textAlign: "center", margin: "0 auto" };

  const justifyContent =
    hero.alignment === "center"
      ? "center"
      : hero.alignment === "right"
      ? "flex-end"
      : "flex-start";

  const LinkComponent = Link || "a";

  // ★ FIX: gradient uses color-mix to darken the primary color for stop 2
  // Both stops reference --color-primary, but stop 2 mixes it with black
  // to create a darker shade. This gives a real gradient effect.
  const gradientBackground = `linear-gradient(135deg, var(--color-primary, ${theme.primary}), color-mix(in srgb, var(--color-primary, ${theme.primary}) 65%, #000))`;

  return (
    <section
      style={{
        position: "relative",
        width: "100%",
        minHeight: "clamp(500px, 80vh, 700px)",
        display: "flex",
        alignItems: "center",
        justifyContent,
        overflow: "hidden",
        background: gradientBackground,
      }}
    >
      {/* Dotted overlay pattern */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
          backgroundSize: "30px 30px",
          pointerEvents: "none",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{
          position: "relative",
          zIndex: 2,
          maxWidth: "600px",
          padding: "0 24px",
          ...alignStyle,
        }}
      >
        {hero.badge && (
          <motion.span
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
              display: "inline-block",
              background: "rgba(255,255,255,0.15)",
              border: "1px solid rgba(255,255,255,0.2)",
              color: "#fff",
              padding: "8px 20px",
              borderRadius: "100px",
              fontSize: "0.85rem",
              fontWeight: 700,
              marginBottom: 24,
              backdropFilter: "blur(4px)",
              WebkitBackdropFilter: "blur(4px)",
            }}
          >
            {hero.badge}
          </motion.span>
        )}

        {hero.title && (
          <h1
            style={{
              color: "#fff",
              fontSize: "clamp(2.5rem, 6vw, 4.5rem)",
              fontWeight: 900,
              marginBottom: 20,
              textShadow: "0 4px 12px rgba(0,0,0,0.3)",
              letterSpacing: "-0.02em",
              margin: "0 0 20px",
            }}
          >
            {hero.title}
          </h1>
        )}

        {hero.subtitle && (
          <p
            style={{
              color: "rgba(255,255,255,0.95)",
              fontSize: "clamp(1rem, 2vw, 1.25rem)",
              maxWidth: "600px",
              margin:
                hero.alignment === "center" ? "0 auto 40px" : "0 0 40px",
              textShadow: "0 2px 8px rgba(0,0,0,0.3)",
            }}
          >
            {hero.subtitle}
          </p>
        )}

        {(hero.primary_btn_text || hero.secondary_btn_text) && (
          <div
            style={{
              display: "flex",
              gap: 16,
              justifyContent,
              flexWrap: "wrap",
            }}
          >
            {hero.primary_btn_text && hero.primary_btn_link && (
              <LinkComponent
                to={hero.primary_btn_link}
                href={hero.primary_btn_link}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "16px 32px",
                  borderRadius: 12,
                  background: "#fff",
                  color: "var(--color-primary, #FF7132)",
                  fontWeight: 700,
                  textDecoration: "none",
                  boxShadow: "0 8px 24px rgba(0,0,0,0.3)",
                  transition: "transform 0.15s",
                }}
              >
                {hero.primary_btn_text} <ArrowRight size={18} />
              </LinkComponent>
            )}
            {hero.secondary_btn_text && hero.secondary_btn_link && (
              <LinkComponent
                to={hero.secondary_btn_link}
                href={hero.secondary_btn_link}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "16px 32px",
                  borderRadius: 12,
                  background: "rgba(255,255,255,0.1)",
                  color: "#fff",
                  fontWeight: 700,
                  textDecoration: "none",
                  border: "2px solid rgba(255,255,255,0.4)",
                  backdropFilter: "blur(4px)",
                  WebkitBackdropFilter: "blur(4px)",
                }}
              >
                {hero.secondary_btn_text}
              </LinkComponent>
            )}
          </div>
        )}
      </motion.div>
    </section>
  );
}
