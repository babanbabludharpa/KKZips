import { Routes, Route } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import Home from '../pages/Home'
import About from '../pages/About'
import Login from '../pages/Login'
import Register from '../pages/Register'
import Contact from '../pages/Contact'
import SubscriptionPlan from '../pages/SubscriptionPlan'        // the LIST
import SubscriptionCreate from '../pages/SubscriptionCreate'   // ★ NEW — the CREATE
import SubscriptionDetail from '../pages/SubscriptionDetail'   // ★ NEW (optional — see below)
import Products from '../pages/Products' 
import Checkout from '../pages/Checkout'; 
import Terms from '../pages/Terms';
import Privacy from '../pages/Privacy';
import Partner from '../pages/Partner';
import VendorStore from '../pages/VendorStore';
import Profile from '../pages/Profile'
import Addresses from '../pages/Addresses';
import Orders from '../pages/Orders'
import OrderDetail from '../pages/OrderDetail'
import CustomPage from '../pages/CustomPage'
import Wallet from "../pages/Wallet";
import ProductDetail from "../pages/ProductDetail";
import RefundPolicy from "../pages/RefundPolicy";
import ShippingPolicy from "../pages/ShippingPolicy";




const Layout = ({ children, showFooter = true }) => (
  <>
    <Navbar />
    <main>{children}</main>
    {showFooter && <Footer />}
  </>
)

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Layout><Home /></Layout>} />
      <Route path="/about" element={<Layout><About /></Layout>} />
      <Route path="/contact" element={<Layout><Contact /></Layout>} /> 
      <Route path="/products" element={<Layout><Products /></Layout>} />
      
      {/* ★ Subscription routes */}
      <Route path="/subscription" element={<Layout><SubscriptionPlan /></Layout>} />
      <Route path="/subscription/new" element={<Layout><SubscriptionCreate /></Layout>} />
      {/* Optional detail route — if you build SubscriptionDetail.jsx: */}
      { <Route path="/subscription/:id" element={<Layout><SubscriptionDetail /></Layout>} />}
      <Route path="/orders" element={<Layout><Orders /></Layout>} />
      <Route path="/orders/:id" element={<Layout><OrderDetail /></Layout>} />
      <Route path="/addresses" element={<Layout><Addresses /></Layout>} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="/profile" element={<Layout><Profile /></Layout>} />
      <Route path="/login" element={<Layout showFooter={false}><Login /></Layout>} />
      <Route path="/register" element={<Layout showFooter={false}><Register /></Layout>} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/partner" element={<Partner />} />
      <Route path="/store/:vendorId" element={<VendorStore />} />
      <Route path="/vendorStore" element={<VendorStore />} />
      <Route path="/page/:slug" element={<CustomPage />} />
      <Route path="/wallet" element={<Wallet />} />
      <Route path="/products/:id" element={<ProductDetail />} />
      <Route path="/refund-policy" element={<RefundPolicy />} />
      <Route path="/shipping-policy" element={<ShippingPolicy />} />
    </Routes>
  )
}      