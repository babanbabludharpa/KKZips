import { useState, useEffect } from "react";

// ═══════════════════════════════════════════════════════════════
// YouTubeVideo.jsx — Universal YouTube Video Component
//
// Extracted from SectionRenderer.jsx so ANY page can import and use it
// without going through the SectionRenderer switch statement.
//
// Usage:
//   import YouTubeVideo from "../components/YouTubeVideo";
//   <YouTubeVideo data={videoData} />
//
// data fields:
//   • youtube_url  (required) — any YouTube URL format
//   • title        (optional) — caption shown above the video
//   • caption      (optional) — short text below the video
//   • alignment    (optional) — "left" | "center" | "right" (title/caption align)
//   • autoplay     (optional) — boolean; starts muted autoplay on load
//   • loop         (optional) — boolean; restarts when finished
//   • start_time   (optional) — integer seconds; begin playback at N seconds
//
// The outer width / position / padding are NOT handled here — wrap this
// component in your own container or use the LayoutWrapper from
// SectionRenderer.jsx if you need canvas positioning.
// ═══════════════════════════════════════════════════════════════

const theme = {
  primary: "#FF7132", dark: "#1E293B", mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0",
};

export function parseYouTubeId(url) {
  if (!url || typeof url !== "string") return null;
  const trimmed = url.trim();

  let m = trimmed.match(/youtu\.be\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];

  m = trimmed.match(/[?&]v=([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];

  m = trimmed.match(/youtube\.com\/embed\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];

  m = trimmed.match(/youtube\.com\/shorts\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];

  m = trimmed.match(/youtube\.com\/live\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];

  if (/^[A-Za-z0-9_-]{11}$/.test(trimmed)) return trimmed;

  return null;
}

export default function YouTubeVideo({ data }) {
  const rawUrl = data?.youtube_url || data?.url || "";
  const videoId = parseYouTubeId(rawUrl);

  if (!videoId) {
    return (
      <div style={{ padding: 24, background: "#FEF3C7", border: "1px solid #F59E0B", borderRadius: 12, color: "#92400E", textAlign: "center" }}>
        <strong>⚠ Invalid YouTube URL</strong>
        <div style={{ fontSize: "0.85rem", marginTop: 4 }}>Paste a URL like https://www.youtube.com/watch?v=...</div>
      </div>
    );
  }

  const params = new URLSearchParams({
    rel: "0",
    modestbranding: "1",
    playsinline: "1",
    iv_load_policy: "3",
  });
  if (data.autoplay) {
    params.set("autoplay", "1");
    params.set("mute", "1");
  }
  if (data.loop) {
    params.set("loop", "1");
    params.set("playlist", videoId);
  }
  if (data.start_time && Number(data.start_time) > 0) {
    params.set("start", String(parseInt(data.start_time, 10)));
  }

  const embedUrl = `https://www.youtube.com/embed/${videoId}?${params.toString()}`;
  const alignStyle = data.alignment === "center" ? { textAlign: "center" } : data.alignment === "right" ? { textAlign: "right" } : { textAlign: "left" };

  return (
    <section style={{ width: "100%", boxSizing: "border-box" }}>
      {data.title && (
        <h3 style={{ fontSize: "clamp(1.2rem, 2.5vw, 1.6rem)", fontWeight: 800, color: theme.dark, marginBottom: 16, ...alignStyle }}>
          {data.title}
        </h3>
      )}

      <div
        style={{
          position: "relative",
          width: "100%",
          paddingTop: "56.25%",
          borderRadius: 16,
          overflow: "hidden",
          background: "#000",
          boxShadow: "0 8px 32px rgba(0,0,0,0.12)",
        }}
      >
        <iframe
          src={embedUrl}
          title={data.title || `YouTube video ${videoId}`}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            border: 0,
          }}
        />
      </div>

      {data.caption && (
        <p style={{ marginTop: 12, color: theme.mid, fontSize: "0.9rem", lineHeight: 1.5, ...alignStyle }}>
          {data.caption}
        </p>
      )}
    </section>
  );
}
