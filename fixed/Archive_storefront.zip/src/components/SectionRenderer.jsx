import { motion, AnimatePresence } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Star, ShoppingCart, Heart, Target, Eye, Quote, ChevronLeft, ChevronRight, Repeat } from "lucide-react";
import { useRef, useEffect, useState } from "react";
import { useSubscription } from "../pages/SubscriptionContext";   
import customerApi from "../api/customerApi";
import toast from "react-hot-toast";

// ★ FIX: primary now uses CSS variable set dynamically by TenantProvider
const theme = {
  primary: "var(--color-primary, #666666)",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

const cardBgs = [
  "linear-gradient(135deg,#DBEAFE,#EDE9FE)", "linear-gradient(135deg,#FEF3C7,#FDE68A)",
  "linear-gradient(135deg,#D1FAE5,#A7F3D0)", "linear-gradient(135deg,#EDE9FE,#DDD6FE)",
];

const HEIGHT_PRESETS = {
  small: "300px",
  medium: "450px",
  large: "600px",
  full: "100vh",
};

function fixImageUrl(url) {
  if (!url) return null;
  if (url.startsWith("http") || url.startsWith("data:") || url.startsWith("blob:")) return url;
  const backendUrl = import.meta.env.VITE_API_URL || import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";
  return backendUrl + (url.startsWith("/") ? url : "/" + url);
}
const storageBase = (() => {
  const explicit = import.meta.env.VITE_STORAGE_URL;
  if (explicit) return explicit.endsWith("/") ? explicit : explicit + "/";
  const base = import.meta.env.VITE_API_URL || import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";
  try { return new URL(base).origin + "/storage/"; } catch { return base + "/storage/"; }
})();

// ★ FIX: call fixImageUrl so relative URLs resolve correctly
const getCatImage = (cat) => {
  if (cat?.image_url) return fixImageUrl(cat.image_url);
  if (cat?.image) return fixImageUrl(storageBase + cat.image.replace(/^\/+/, ""));
  return null;
};

// ★ Layout Wrapper for Canvas Positioning
function LayoutWrapper({ section, children }) {
  const layout = section.layout || section.data?.layout || {};
  const isHalf = layout.width === 'half';
  const isContained = layout.width === 'contained';

  const wrapperStyle = isHalf ? {
    display: 'inline-block',
    width: 'calc(50% - 12px)',
    marginRight: 12,
    marginBottom: 12,
    verticalAlign: 'top',
    boxSizing: 'border-box',
    padding: '0 12px',
  } : {
    display: 'block',
    width: '100%',
    boxSizing: 'border-box',
    padding: isContained ? '0 24px' : '0',
    textAlign: layout.content_align === 'center' ? 'center' : (layout.content_align === 'right' ? 'right' : 'left'),
  };

  const innerStyle = isHalf ? {
    width: '100%',
    textAlign: layout.text_align || 'left',
  } : {
    display: 'inline-block',
    width: '100%',
    maxWidth: isContained ? '800px' : '100%',
    textAlign: layout.text_align || 'left',
  };

  return <div style={wrapperStyle}><div style={innerStyle}>{children}</div></div>;
}

export default function SectionRenderer({ section, addToCart, cartCount, setIsCartOpen }) {
  if (!section) return null;
  const { type, data = {}, visible = true } = section;
  if (visible === false) return null;

  const renderContent = () => {
    switch (type) {
      case "hero": return <HeroSection data={data} />;
      case "carousel": return <CarouselSection data={data} />;
      case "media_carousel": return <MediaCarouselSection data={data} />;
      case "mission": return <MissionSection data={data} />;
      case "products": return <ProductsSection data={data} addToCart={addToCart} />;
      case "categories": return <CategoriesSection data={data} />;
      case "testimonials": return <TestimonialsSection data={data} />;
      case "cta": return <CTASection data={data} />;
      case "story": return <StorySection data={data} />;
      case "whyUs": return <WhyUsSection data={data} />;
      case "info": return <InfoSection data={data} />;
      case "whatsapp": return <WhatsAppSection data={data} />;
      case "text_block": return <TextBlockSection data={data} />;
      case "image_block": return <ImageBlockSection data={data} />;
      case "youtube_video": return <YouTubeVideoSection data={data} />;
      case "subscription_products": return <SubscriptionProductsSection data={data} />;
      case "spacer": return <div style={{ height: data.height || 40 }} />;
      case "divider": return <hr style={{ border: "none", borderTop: `${data.thickness || 1}px solid ${data.color || "#E2E8F0"}`, margin: "40px 0" }} />;
      case "html_block": return <div style={{ padding: "40px 24px", maxWidth: 1200, margin: "0 auto" }} dangerouslySetInnerHTML={{ __html: data.html || "" }} />;
      default: return null;
    }
  };

  if (type === "hero" || type === "carousel" || type === "image_block") {
    
    return renderContent();
  }

  return <LayoutWrapper section={section}>{renderContent()}</LayoutWrapper>;
  
}

// ═══════════════════════════════════════════════════════════════
// YOUTUBE VIDEO SECTION
// ═══════════════════════════════════════════════════════════════
function parseYouTubeId(url) {
  if (!url || typeof url !== "string") return null;
  const trimmed = url.trim();
  let m = trimmed.match(/youtu\.be\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];
  m = trimmed.match(/[?&]v=([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];
  m = trimmed.match(/youtube\.com\/embed\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];
  m = trimmed.match(/youtube\.com\/shorts\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];
  m = trimmed.match(/youtube\.com\/live\/([A-Za-z0-9_-]{6,})/);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{11}$/.test(trimmed)) return trimmed;
  return null;
}

function YouTubeVideoSection({ data }) {
  const rawUrl = data.youtube_url || data.url || "";
  const videoId = parseYouTubeId(rawUrl);

  if (!videoId) {
    return (
      <div style={{ padding: 24, background: "#FEF3C7", border: "1px solid #F59E0B", borderRadius: 12, color: "#92400E", textAlign: "center" }}>
        <strong>⚠ Invalid YouTube URL</strong>
        <div style={{ fontSize: "0.85rem", marginTop: 4 }}>Paste a URL like https://www.youtube.com/watch?v=...</div>
      </div>
    );
  }

  const params = new URLSearchParams({
    rel: "0",
    modestbranding: "1",
    playsinline: "1",
    iv_load_policy: "3",
  });
  if (data.autoplay) {
    params.set("autoplay", "1");
    params.set("mute", "1");
  }
  if (data.loop) {
    params.set("loop", "1");
    params.set("playlist", videoId);
  }
  if (data.start_time && Number(data.start_time) > 0) {
    params.set("start", String(parseInt(data.start_time, 10)));
  }

  const embedUrl = `https://www.youtube.com/embed/${videoId}?${params.toString()}`;
  const alignStyle = data.alignment === "center" ? { textAlign: "center" } : data.alignment === "right" ? { textAlign: "right" } : { textAlign: "left" };

  return (
    <section style={{ width: "100%", boxSizing: "border-box" }}>
      {data.title && (
        <h3 style={{ fontSize: "clamp(1.2rem, 2.5vw, 1.6rem)", fontWeight: 800, color: theme.dark, marginBottom: 16, ...alignStyle }}>
          {data.title}
        </h3>
      )}
      <div style={{ position: "relative", width: "100%", paddingTop: "56.25%", borderRadius: 16, overflow: "hidden", background: "#000", boxShadow: "0 8px 32px rgba(0,0,0,0.12)" }}>
        <iframe
          src={embedUrl}
          title={data.title || `YouTube video ${videoId}`}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }}
        />
      </div>
      {data.caption && (
        <p style={{ marginTop: 12, color: theme.mid, fontSize: "0.9rem", lineHeight: 1.5, ...alignStyle }}>{data.caption}</p>
      )}
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// HERO — banner slideshow: each slide has its own image, text,
// and text color. Empty slide text falls back to the global hero
// text. Box sizing = MediaCarousel. Dots, swipe, dim, text style.
// ═══════════════════════════════════════════════════════════════
function HeroSection({ data }) {
  const slides = (Array.isArray(data.slides) && data.slides.length
    ? data.slides
    : (data.images || []).map((u) => ({ image_url: u }))
  ).filter((s) => s && (s.image_url || s.url));

  const [bgSlide, setBgSlide] = useState(0);
  const touchStartX = useRef(null);

  useEffect(() => {
    if (slides.length > 1) {
      const t = setInterval(() => setBgSlide((p) => (p + 1) % slides.length), 5000);
      return () => clearInterval(t);
    }
  }, [slides.length]);

  const hasBgImages = slides.length > 0;
  const showText = hasBgImages ? data.show_text !== false : true;
  const overlayOpacity = data.overlay_opacity !== undefined && data.overlay_opacity !== null
    ? Math.max(0, Math.min(100, Number(data.overlay_opacity) || 0)) / 100
    : 0.5;
  const textStyle = data.text_style || "light";
  const go = (dir) => setBgSlide((p) => (p + dir + slides.length) % slides.length);

  const alignStyle = data.alignment === "left"
    ? { textAlign: "left", marginLeft: "5vw", marginRight: "auto" }
    : data.alignment === "right"
    ? { textAlign: "right", marginLeft: "auto", marginRight: "5vw" }
    : { textAlign: "center", margin: "0 auto" };
  const itemsAlign = data.alignment === "center" ? "center" : data.alignment === "right" ? "flex-end" : "flex-start";

  // ── TEXT-ONLY HERO (no slides) ──
  if (!hasBgImages) {
    return (
      <section style={{ position: "relative", width: "100%", overflow: "hidden", background: "var(--color-primary, #666666)", padding: "clamp(64px, 12vh, 128px) 24px", boxSizing: "border-box", display: "flex", alignItems: "center", justifyContent: itemsAlign }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)", backgroundSize: "30px 30px", pointerEvents: "none" }} />
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} style={{ position: "relative", zIndex: 2, maxWidth: "600px", ...alignStyle }}>
          {data.badge && <span style={{ display: "inline-block", background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "8px 20px", borderRadius: "100px", fontSize: "0.85rem", fontWeight: 700, marginBottom: 24, backdropFilter: "blur(4px)" }}>{data.badge}</span>}
          {data.title && <h1 style={{ color: "#fff", fontSize: "clamp(2rem, 5vw, 4rem)", fontWeight: 900, margin: "0 0 28px", textShadow: "0 4px 12px rgba(0,0,0,0.3)" }}>{data.title}</h1>}
          {data.subtitle && <p style={{ color: "rgba(255,255,255,0.95)", fontSize: "clamp(1rem, 2vw, 1.2rem)", maxWidth: "600px", margin: data.alignment === "center" ? "0 auto 40px" : "0 0 40px" }}>{data.subtitle}</p>}
          {(data.primary_btn_text || data.secondary_btn_text) && (
            <div style={{ display: "flex", gap: 16, justifyContent: itemsAlign, flexWrap: "wrap" }}>
              {data.primary_btn_text && data.primary_btn_link && <Link to={data.primary_btn_link} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "16px 32px", borderRadius: 12, background: "#fff", color: "var(--color-primary, #666666)", fontWeight: 700, textDecoration: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.3)" }}>{data.primary_btn_text} <ArrowRight size={18} /></Link>}
              {data.secondary_btn_text && data.secondary_btn_link && <Link to={data.secondary_btn_link} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "16px 32px", borderRadius: 12, background: "rgba(255,255,255,0.1)", color: "#fff", fontWeight: 700, textDecoration: "none", border: "2px solid rgba(255,255,255,0.4)" }}>{data.secondary_btn_text}</Link>}
            </div>
          )}
        </motion.div>
      </section>
    );
  }

  const s = slides[bgSlide] || {};
  // ★ ALL-OR-NOTHING per slide:
  //    any text field filled  → personal slide: ONLY its own fields + its own color
  //    all fields empty       → common slide: the common hero text
  //    hide_text              → pure image
  const val = (v) => String(v ?? "").trim();
  const isPersonal = !!(val(s.badge) || val(s.title) || val(s.subtitle) || val(s.btn_text));
  const hideText = s.hide_text === true;

  let tBadge = "", tTitle = "", tSubtitle = "", tBtnText = "", tBtnLink = "", tColor = null, showSecondary = false;

  if (isPersonal && !hideText) {
    tBadge = val(s.badge);
    tTitle = val(s.title);
    tSubtitle = val(s.subtitle);
    tBtnText = val(s.btn_text);
    tBtnLink = val(s.btn_link);
    tColor = s.text_color || null;          // ★ slide's color — common can't touch it
  } else if (!hideText) {
    tBadge = val(data.badge);
    tTitle = val(data.title);
    tSubtitle = val(data.subtitle);
    tBtnText = val(data.primary_btn_text);
    tBtnLink = val(data.primary_btn_link);
    showSecondary = !!(val(data.secondary_btn_text) && val(data.secondary_btn_link));
  }

  const colorStyle = tColor ? { color: tColor } : undefined;

  return (
    <>
      <style>{`
        .hero-banner { width: 100%; position: relative; overflow: hidden; background: #1E293B; min-height: clamp(520px, 50vh, 650px); }
        @media (max-width: 768px) {
          .hero-banner { min-height: 400px !important; }
        }
        .hb-img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0; transition: opacity 1.5s ease-in-out; }
        .hb-img.active { opacity: 1; }
        .hb-text { position: absolute; inset: 0; z-index: 2; display: flex; flex-direction: column; align-items: ${itemsAlign}; justify-content: center; padding: 40px 24px; box-sizing: border-box; }
        .hb-badge { display: inline-block; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 8px 20px; border-radius: 100px; font-size: 0.85rem; font-weight: 700; margin-bottom: 24px; backdrop-filter: blur(4px); }
        .hb-title { color: #fff; font-size: clamp(2rem, 5vw, 4rem); font-weight: 900; line-height: 1.25; margin: 0 0 28px; text-shadow: 0 4px 12px rgba(0,0,0,0.3); }
        .hb-subtitle { color: rgba(255,255,255,0.95); font-size: clamp(1rem, 2vw, 1.2rem); line-height: 1.5; max-width: 600px; margin: 0 0 40px; text-shadow: 0 2px 8px rgba(0,0,0,0.4); }
        .hb-btns { display: flex; gap: 16px; flex-wrap: wrap; justify-content: ${itemsAlign}; }
        .hb-btn { display: inline-flex; align-items: center; gap: 8px; padding: 16px 32px; border-radius: 12px; font-weight: 700; text-decoration: none; }
        .hb-btn-main { background: #fff; color: var(--color-primary, #666666); box-shadow: 0 8px 24px rgba(0,0,0,0.3); }
        .hb-btn-ghost { background: rgba(255,255,255,0.1); color: #fff; border: 2px solid rgba(255,255,255,0.4); }
        .hb-dots { position: absolute; bottom: 24px; left: 0; right: 0; display: flex; justify-content: center; gap: 10px; z-index: 3; }
        .hb-dot { width: 10px; height: 10px; border-radius: 5px; border: none; padding: 0; background: rgba(255,255,255,0.6); cursor: pointer; }
        .hb-dot.active { width: 32px; background: var(--color-primary, #666666); }

        /* text style variants */
        .hb-text--dark .hb-title { color: #1E293B; text-shadow: 0 2px 12px rgba(255,255,255,0.8); }
        .hb-text--dark .hb-subtitle { color: #334155; text-shadow: 0 1px 10px rgba(255,255,255,0.75); }
        .hb-text--dark .hb-badge { color: #1E293B; background: rgba(255,255,255,0.75); border: 1px solid rgba(30,41,59,0.15); text-shadow: none; }
        .hb-text--dark .hb-btn-main { background: #1E293B; color: #fff; box-shadow: 0 8px 24px rgba(0,0,0,0.18); }
        .hb-text--dark .hb-btn-ghost { background: rgba(255,255,255,0.65); color: #1E293B; border: 2px solid rgba(30,41,59,0.25); }
        .hb-text--glass .hb-panel { background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.18); border-radius: 18px; padding: 28px 32px; }

        @media (max-width: 768px) {
          .hb-text { padding: 20px 16px; }
          .hb-badge { font-size: 0.72rem; padding: 6px 16px; margin-bottom: 16px; }
          .hb-title { font-size: 1.8rem; margin-bottom: 16px; line-height: 1.3; }
          .hb-subtitle { font-size: 0.95rem; margin-bottom: 20px; }
          .hb-btn { padding: 12px 24px; }
          .hb-text--glass .hb-panel { padding: 18px 16px; }
        }
      `}</style>
      <section
        className="hero-banner"
        onTouchStart={(e) => (touchStartX.current = e.touches[0].clientX)}
        onTouchEnd={(e) => {
          if (touchStartX.current == null) return;
          const dx = e.changedTouches[0].clientX - touchStartX.current;
          if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
          touchStartX.current = null;
        }}
      >
        {slides.map((sl, i) => (
          <img key={i} className={`hb-img ${i === bgSlide ? "active" : ""}`} src={fixImageUrl(sl.image_url || sl.url)} alt="" loading={i === 0 ? "eager" : "lazy"} />
        ))}
        {overlayOpacity > 0 && (
          <div style={{ position: "absolute", inset: 0, background: `rgba(15, 23, 42, ${overlayOpacity})`, pointerEvents: "none" }} />
        )}

        {showText && (
          <AnimatePresence>
            <motion.div
              key={isPersonal || hideText ? `slide-${bgSlide}` : "common"}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className={`hb-text hb-text--${textStyle}`}
            >
              <div className="hb-panel" style={{ maxWidth: "600px", ...alignStyle }}>
                {tBadge && <span className="hb-badge" style={colorStyle}>{tBadge}</span>}
                {tTitle && <h1 className="hb-title" style={colorStyle}>{tTitle}</h1>}
                {tSubtitle && <p className="hb-subtitle" style={colorStyle}>{tSubtitle}</p>}
                {(tBtnText || showSecondary) && (
                  <div className="hb-btns">
                    {tBtnText && tBtnLink && <Link to={tBtnLink} className="hb-btn hb-btn-main">{tBtnText} <ArrowRight size={18} /></Link>}
                    {showSecondary && <Link to={data.secondary_btn_link} className="hb-btn hb-btn-ghost">{data.secondary_btn_text}</Link>}
                  </div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        )}

        {slides.length > 1 && (
          <div className="hb-dots">
            {slides.map((_, i) => (
              <button key={i} className={`hb-dot ${i === bgSlide ? "active" : ""}`} onClick={() => setBgSlide(i)} aria-label={`Slide ${i + 1}`} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// STANDALONE CAROUSEL — responsive: height follows the banner's own
// aspect ratio, so the full banner shows at every screen width.
// ═══════════════════════════════════════════════════════════════
function CarouselSection({ data }) {
  const [activeSlide, setActiveSlide] = useState(0);
  const [ratio, setRatio] = useState(null); // ★ banner width ÷ height
  const touchStartX = useRef(null);
  const images = (data.images || []).filter(Boolean);

  useEffect(() => {
    if (images.length > 1) {
      const t = setInterval(() => setActiveSlide((p) => (p + 1) % images.length), 5000);
      return () => clearInterval(t);
    }
  }, [images.length]);

  // ★ Measure the first banner so the frame matches its shape
  useEffect(() => {
    if (!images.length || ratio) return;
    const probe = new Image();
    probe.onload = () => {
      if (probe.naturalWidth && probe.naturalHeight) setRatio(probe.naturalWidth / probe.naturalHeight);
    };
    probe.src = images[0];
  }, [images, ratio]);

  if (images.length === 0) return null;

  const go = (dir) => setActiveSlide((p) => (p + dir + images.length) % images.length);
  const containerRatio = ratio || 21 / 9; // wide-banner fallback while measuring

  return (
    <section
      className="responsive-carousel"
      onTouchStart={(e) => (touchStartX.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touchStartX.current == null) return;
        const dx = e.changedTouches[0].clientX - touchStartX.current;
        if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
        touchStartX.current = null;
      }}
      style={{
        position: "relative",
        width: "100%",
        overflow: "hidden",
        background: "#1E293B",
        aspectRatio: String(containerRatio),
        maxHeight: "70vh",   // safety cap — never taller than 70% of the screen
        minHeight: 160,      // safety floor — always visible on small screens
      }}
    >
      {images.map((img, i) => (
        <img
          key={i}
          src={fixImageUrl(img)}
          alt={`slide-${i + 1}`}
          loading={i === 0 ? "eager" : "lazy"}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            opacity: i === activeSlide ? 1 : 0,
            transition: "opacity 1.5s ease-in-out",
          }}
        />
      ))}
      {images.length > 1 && (
        <div style={{ position: "absolute", bottom: 24, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 10, zIndex: 3 }}>
          {images.map((_, i) => (
            <button key={i} onClick={() => setActiveSlide(i)} style={{ width: i === activeSlide ? 32 : 10, height: 10, borderRadius: 5, border: "none", background: i === activeSlide ? "var(--color-primary, #666666)" : "rgba(255,255,255,0.6)", cursor: "pointer", padding: 0 }} />
          ))}
        </div>
      )}
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// MEDIA CAROUSEL — Mixed Images + Videos (With Mobile Fix)
// ═══════════════════════════════════════════════════════════════
function MediaCarouselSection({ data }) {
  const items = Array.isArray(data.items) ? data.items : [];
  const [activeSlide, setActiveSlide] = useState(0);
  const videoRef = useRef(null);

  const objectFit = data.object_fit || "cover";
  const intervalMs = (data.interval_seconds || 5) * 1000;

  useEffect(() => {
    if (items.length <= 1) return;
    const currentItem = items[activeSlide];
    if (!currentItem || currentItem.type === "video") return;
    const t = setTimeout(() => setActiveSlide((p) => (p + 1) % items.length), intervalMs);
    return () => clearTimeout(t);
  }, [activeSlide, items, intervalMs]);

  if (items.length === 0) return null;

  const goToSlide = (i) => setActiveSlide(i);
  const nextSlide = () => setActiveSlide((p) => (p + 1) % items.length);
  const currentItem = items[activeSlide];

  return (
    <>
      <style>{`
        .responsive-media-carousel {
          width: 100%;
          position: relative;
          overflow: hidden;
          background: #1E293B;
          height: clamp(300px, 45vh, 450px);
        }
        .carousel-text-wrapper {
          padding: 40px 24px;
          box-sizing: border-box;
        }
        @media (max-width: 768px) {
          .responsive-media-carousel {
            height: 50vh !important; /* Takes exactly half the mobile screen */
            min-height: 300px !important;
          }
          .carousel-text-wrapper {
            padding: 20px 16px !important;
          }
          .carousel-title {
            font-size: 1.6rem !important;
            margin-bottom: 8px !important;
          }
          .carousel-subtitle {
            font-size: 0.95rem !important;
            margin-bottom: 16px !important;
          }
        }
      `}</style>
      <section className="responsive-media-carousel">
        {items.map((item, i) => {
          const isActive = i === activeSlide;
          if (item.type === "video") {
            return (
              <div key={i} style={{ position: "absolute", inset: 0, opacity: isActive ? 1 : 0, transition: "opacity 0.8s ease-in-out", zIndex: isActive ? 1 : 0 }}>
                {isActive && (
                  <video
                    ref={videoRef}
                    src={fixImageUrl(item.url)}
                    poster={item.poster ? fixImageUrl(item.poster) : undefined}
                    autoPlay
                    muted
                    playsInline
                    onEnded={nextSlide}
                    style={{ width: "100%", height: "100%", objectFit: objectFit }}
                  />
                )}
              </div>
            );
          }
          return (
            <div key={i} style={{ position: "absolute", inset: 0, opacity: isActive ? 1 : 0, transition: "opacity 1.5s ease-in-out", zIndex: isActive ? 1 : 0 }}>
              <div style={{ position: "absolute", inset: 0, backgroundImage: `url(${fixImageUrl(item.url)})`, backgroundSize: objectFit, backgroundPosition: "center center", backgroundRepeat: "no-repeat" }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(30,41,59,0.75), rgba(30,41,59,0.4))" }} />
              {isActive && (item.badge || item.title || item.subtitle || item.btn_text) && (
                <div className="carousel-text-wrapper" style={{ position: "relative", zIndex: 2, height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ textAlign: "center", maxWidth: "90%" }}>
                    {item.badge && <span style={{ display: "inline-block", background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "8px 20px", borderRadius: 100, fontSize: "0.85rem", fontWeight: 700, marginBottom: 16, backdropFilter: "blur(4px)" }}>{item.badge}</span>}
                    {item.title && <h2 className="carousel-title" style={{ color: "#fff", fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: 900, margin: "0 0 16px", textShadow: "0 4px 12px rgba(0,0,0,0.3)" }}>{item.title}</h2>}
                    {item.subtitle && <p className="carousel-subtitle" style={{ color: "rgba(255,255,255,0.9)", fontSize: "clamp(1rem, 2vw, 1.2rem)", margin: "0 0 24px" }}>{item.subtitle}</p>}
                    {item.btn_text && (item.btn_link || "/") && (
                      <Link to={item.btn_link || "/"} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "14px 32px", borderRadius: 12, background: "#fff", color: "var(--color-primary, #666666)", fontWeight: 700, textDecoration: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.3)" }}>
                        {item.btn_text} <ArrowRight size={18} />
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {items.length > 1 && (
          <div style={{ position: "absolute", bottom: 24, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 10, zIndex: 3 }}>
            {items.map((_, i) => (
              <button key={i} onClick={() => goToSlide(i)} style={{ width: i === activeSlide ? 32 : 10, height: 10, borderRadius: 5, border: "none", background: i === activeSlide ? "var(--color-primary, #666666)" : "rgba(255,255,255,0.6)", cursor: "pointer", padding: 0 }} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}

function MissionSection({ data }) {
  return (
    <section style={{ padding: "80px 24px", background: "#fff" }}>
      <div style={{ maxWidth: 1000, margin: "0 auto" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={{ textAlign: "center", marginBottom: 56 }}>
          <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 900, color: theme.dark }}>{data.title}</h2>
        </motion.div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 32 }}>
          {[{ icon: Target, label: "Mission", text: data.mission_text }, { icon: Eye, label: "Vision", text: data.vision_text }].map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={{ background: theme.bg, borderRadius: 20, padding: 32, border: `1px solid ${theme.border}` }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: "var(--color-primary, #666666)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 24 }}><item.icon size={24} color="#fff" /></div>
              <h3 style={{ fontSize: "1.25rem", fontWeight: 800, color: theme.dark, marginBottom: 12, textTransform: "uppercase" }}>{item.label}</h3>
              <p style={{ color: theme.mid, fontSize: "1rem", lineHeight: 1.6, margin: 0 }}>{item.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// PRODUCTS SECTION — responsive image via aspect-ratio + Load More
// ═══════════════════════════════════════════════════════════════
function ProductsSection({ data, addToCart }) {
  const products = data.products || [];
  const isDeliverable = data.isDeliverable !== false;
  const deliveryCheckDone = data.deliveryCheckDone || false;
  const loading = data.loading && products.length === 0;

  const [visibleCount, setVisibleCount] = useState(12);
  const shown = products.slice(0, visibleCount);

  if (products.length === 0 && !loading) return null;

  return (
    <section style={{ padding: "40px 24px 80px", background: theme.bg }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {loading ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 16 }}>
            {Array.from({ length: 8 }).map((_, i) => <ProductSkeleton key={i} />)}
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 16 }}>
              {shown.map((product, i) => (
                <HomeProductCard key={product.id} product={product} index={i} isDeliverable={isDeliverable} addToCart={addToCart} />
              ))}
            </div>
            {products.length > shown.length && (
              <div style={{ textAlign: "center", marginTop: 24 }}>
                <button
                  onClick={() => setVisibleCount((c) => c + 12)}
                  style={{ padding: "10px 28px", borderRadius: 8, border: `1px solid ${theme.border}`, background: "#fff", color: theme.dark, fontWeight: 700, cursor: "pointer" }}
                >
                  Load More ({shown.length} of {products.length})
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}

function ProductSkeleton() {
  return (
    <div style={{ background: "#fff", borderRadius: 20, overflow: "hidden", border: `1px solid ${theme.border}`, display: "flex", flexDirection: "column" }}>
      <div style={{ aspectRatio: "1 / 1", background: "#f1f5f9", animation: "pulse 1.5s ease-in-out infinite" }} />
      <div style={{ padding: 10 }}>
        <div style={{ height: 10, background: "#f1f5f9", borderRadius: 5, marginBottom: 6 }} />
        <div style={{ height: 10, background: "#f1f5f9", borderRadius: 5, width: "60%", marginBottom: 8 }} />
        <div style={{ height: 28, background: "#f1f5f9", borderRadius: 8 }} />
      </div>
      <style>{`@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }`}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// CATEGORIES SECTION — responsive width + aspect-ratio image
// ═══════════════════════════════════════════════════════════════
function CategoriesSection({ data }) {
  const categories = data.categories || [];
  if (categories.length === 0) return null;

  return (
    <section style={{ padding: "40px 24px", background: theme.bg }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2 style={{ fontSize: "1.5rem", fontWeight: 800, color: theme.dark, margin: 0 }}>
            {data.title || "Shop by Category"}
          </h2>
          <Link to="/products" style={{ color: theme.primary, textDecoration: "none", fontWeight: 600, fontSize: "0.9rem" }}>
            View All →
          </Link>
        </div>
        {/* ★ FIX: responsive card width (clamp) + aspect-ratio image */}
        <div style={{ display: "flex", gap: 16, overflowX: "auto", paddingBottom: 16 }}>
          {categories.map((cat) => {
            const img = getCatImage(cat);
            const name = cat.name || cat.category_name || "Category";
            return (
              <Link
                to={`/products?category=${cat.id}`}
                key={cat.id ?? name}
                style={{
                  textDecoration: "none",
                  flex: "0 0 auto",
                  width: "clamp(140px, 40vw, 180px)",
                  background: "#fff",
                  borderRadius: 16,
                  overflow: "hidden",
                  border: `1px solid ${theme.border}`,
                }}
              >
                {/* ★ aspect-ratio: 1 — image adapts to card width */}
                <div style={{
                  aspectRatio: "1 / 1",
                  position: "relative",
                  background: "linear-gradient(135deg,#DBEAFE,#EDE9FE)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}>
                  <span style={{ fontSize: 30, fontWeight: 800, color: theme.mid }}>
                    {name.charAt(0).toUpperCase()}
                  </span>
                  {img && (
                    <img
                      src={img}
                      alt={name}
                      loading="lazy"
                      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
                      onError={(e) => e.currentTarget.remove()}
                    />
                  )}
                </div>
                <p style={{ color: theme.dark, fontWeight: 700, margin: 0, padding: "10px 12px", fontSize: "0.85rem", textAlign: "center" }}>
                  {name}
                </p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// HOME PRODUCT CARD — variant switcher + responsive image
// ═══════════════════════════════════════════════════════════════
function HomeProductCard({ product, index, isDeliverable, addToCart }) {
  const navigate = useNavigate();
  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [showVariants, setShowVariants] = useState(false);

  const variants = product.variants || [];
  const normalizedVariants = variants.length > 0 ? variants : [
    {
      id: product.variant_id,
      final_price: product.price,
      mrp: product.mrp,
      has_discount: product.has_discount,
      discount_percent: product.discount_percent,
      unit_abbr: product.unit_abbr,
      image_url: product.image_url,
      available_stock: product.available_stock,
      is_out_of_stock: product.is_out_of_stock,
      is_low_stock: product.is_low_stock,
      attributes: [],
    },
  ];

  const selectedVariant = normalizedVariants[selectedVariantIdx] || normalizedVariants[0] || {};
  const hasMultipleVariants = normalizedVariants.length > 1;

  const isOutOfStock =
    !isDeliverable ||
    selectedVariant.is_out_of_stock === true ||
    (selectedVariant.available_stock !== null &&
      selectedVariant.available_stock !== undefined &&
      selectedVariant.available_stock <= 0);

  const isLowStock =
    isDeliverable &&
    !isOutOfStock &&
    selectedVariant.available_stock !== null &&
    selectedVariant.available_stock !== undefined &&
    selectedVariant.available_stock > 0 &&
    selectedVariant.available_stock <= 5;

  const stockLabel = !isDeliverable
    ? { text: "Not deliverable", color: "#DC2626" }
    : isOutOfStock
    ? { text: "Out of stock", color: "#EF4444" }
    : isLowStock
    ? { text: `Only ${selectedVariant.available_stock} left`, color: "#F59E0B" }
    : selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined
    ? { text: "In stock", color: "#16A34A" }
    : null;

  const getVariantLabel = (v) => {
    if (v.attributes && v.attributes.length > 0) {
      return v.attributes.map((a) => a.value).join(" · ");
    }
    return v.unit_abbr || "Variant";
  };

  const handleAdd = () => {
    addToCart({
      id: product.id,
      variant_id: selectedVariant.id,
      name: product.name,
      price: Number(selectedVariant.final_price || 0),
      unit: selectedVariant.unit_abbr || "",
      image_url: selectedVariant.image_url || product.image_url,
      quantity: 1,
      is_out_of_stock: selectedVariant.is_out_of_stock || false,
      available_stock: selectedVariant.available_stock ?? null,
      attributes: selectedVariant.attributes || [],   // ★ NEW
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      whileHover={{ y: isOutOfStock ? 0 : -6 }}
      onClick={() => navigate(`/products/${product.id}`)}
      style={{
        background: "#fff",
        borderRadius: 20,
        overflow: "hidden",
        border: `1px solid ${theme.border}`,
        display: "flex",
        flexDirection: "column",
        opacity: isOutOfStock ? 0.65 : 1,
        transition: "opacity 0.2s",
        position: "relative",
        cursor: "pointer",
      }}
    >
      {/* ★ FIX: aspect-ratio: 1 — image adapts to card width, no fixed 120px */}
      <div
        style={{
          aspectRatio: "1 / 1",
          background: cardBgs[index % cardBgs.length],
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 40,
          position: "relative",
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        {selectedVariant.image_url ? (
          <img
            src={fixImageUrl(selectedVariant.image_url)}
            alt={product.name}
            loading="lazy"
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        ) : (
          "📦"
        )}

        {isOutOfStock && (
          <span style={{ position: "absolute", top: 6, left: 6, background: "#FEE2E2", color: "#B91C1C", padding: "2px 7px", borderRadius: 5, fontSize: "0.6rem", fontWeight: 700 }}>
            {!isDeliverable ? "NOT DELIVERABLE" : "OUT OF STOCK"}
          </span>
        )}
        {!isOutOfStock && selectedVariant.has_discount && selectedVariant.discount_percent > 0 && (
          <span style={{ position: "absolute", top: 6, left: 6, background: "#16A34A", color: "#fff", padding: "2px 7px", borderRadius: 5, fontSize: "0.6rem", fontWeight: 700 }}>
            {selectedVariant.discount_percent}% OFF
          </span>
        )}
        {isLowStock && (
          <span style={{ position: "absolute", top: 6, left: 6, background: "#FEF3C7", color: "#92400E", padding: "2px 7px", borderRadius: 5, fontSize: "0.6rem", fontWeight: 700 }}>
            ONLY {selectedVariant.available_stock} LEFT
          </span>
        )}
      </div>

      <div style={{ padding: 10, display: "flex", flexDirection: "column", flex: 1 }}>
        <p style={{ fontSize: "0.62rem", color: theme.primary, fontWeight: 800, marginBottom: 2, textTransform: "uppercase" }}>
          {product.category}
        </p>
        <h3 style={{ fontSize: "0.88rem", fontWeight: 800, color: theme.dark, marginBottom: 6, lineHeight: 1.25 }}>
          {product.name}
        </h3>
        {/* ★ NEW — attribute chips (Size / Color / Fabric), always visible */}
        {(selectedVariant.attributes || []).length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 6 }}>
            {(selectedVariant.attributes || []).map((a, ai) => (
              <span key={ai} style={{ fontSize: "0.6rem", fontWeight: 600, color: theme.dark, background: "#F1F5F9", border: `1px solid ${theme.border}`, borderRadius: 5, padding: "2px 5px", whiteSpace: "nowrap" }}>
                {a.attribute_name}: {a.value}
              </span>
            ))}
          </div>
        )}

        {hasMultipleVariants && (
          <div style={{ marginBottom: 6, position: "relative" }}>
            <button
              onClick={(e) => { e.stopPropagation(); setShowVariants((v) => !v); }}
              style={{
                width: "100%", padding: "5px 8px", background: "#F8FAFF",
                border: `1px solid ${theme.border}`, borderRadius: 7, fontSize: "0.72rem",
                fontWeight: 600, color: theme.dark, cursor: "pointer",
                display: "flex", justifyContent: "space-between", alignItems: "center", gap: 4,
              }}
            >
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {getVariantLabel(selectedVariant)}
              </span>
              <span style={{ display: "inline-block", transform: showVariants ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s", flexShrink: 0, fontSize: "0.7rem" }}>▾</span>
            </button>

            {showVariants && (
              <div style={{ marginTop: 4, background: "#fff", border: `1px solid ${theme.border}`, borderRadius: 8, maxHeight: 180, overflowY: "auto" }}>
                {normalizedVariants.map((v, idx) => {
                  const vOutOfStock = !isDeliverable || v.is_out_of_stock === true || (v.available_stock !== null && v.available_stock !== undefined && v.available_stock <= 0);
                  const isSelected = idx === selectedVariantIdx;
                  return (
                    <button
                      key={v.id || idx}
                      onClick={(e) => { e.stopPropagation(); setSelectedVariantIdx(idx); setShowVariants(false); }}
                      style={{
                        width: "100%", padding: "7px 10px", background: isSelected ? "#FFF7ED" : "#fff",
                        border: "none", borderBottom: `1px solid ${theme.border}`, fontSize: "0.72rem",
                        fontWeight: 600, color: vOutOfStock ? "#94A3B8" : theme.dark, cursor: "pointer",
                        display: "flex", justifyContent: "space-between", alignItems: "center", gap: 4,
                        textAlign: "left", opacity: vOutOfStock ? 0.6 : 1,
                      }}
                    >
                      <span>{getVariantLabel(v)}</span>
                      <span style={{ display: "flex", alignItems: "center", gap: 4, flexShrink: 0, color: isSelected ? theme.primary : theme.mid, fontWeight: 700 }}>
                        ₹{Number(v.final_price || 0).toFixed(0)}
                        {isSelected && <span style={{ color: theme.primary }}>✓</span>}
                        {vOutOfStock && <span style={{ fontSize: "0.6rem", color: "#EF4444" }}>{!isDeliverable ? "N/A" : "Out"}</span>}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {stockLabel && (
          <div style={{ fontSize: "0.67rem", fontWeight: 700, color: stockLabel.color, marginBottom: 6 }}>● {stockLabel.text}</div>
        )}

        <div style={{ marginTop: "auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: "0.95rem", fontWeight: 900, color: theme.dark }}>₹{Number(selectedVariant.final_price || 0).toFixed(0)}</span>
            {selectedVariant.has_discount && selectedVariant.mrp > selectedVariant.final_price && (
              <span style={{ fontSize: "0.7rem", color: "#94A3B8", textDecoration: "line-through" }}>₹{Number(selectedVariant.mrp || 0).toFixed(0)}</span>
            )}
            {selectedVariant.unit_abbr && <span style={{ fontSize: "0.68rem", color: theme.mid }}>/ {selectedVariant.unit_abbr}</span>}
          </div>

          <button
            onClick={(e) => { e.stopPropagation(); handleAdd(); }}
            disabled={isOutOfStock}
            style={{
              width: "100%", padding: "8px", background: isOutOfStock ? "#E2E8F0" : theme.primary,
              color: isOutOfStock ? "#94A3B8" : "#fff", border: "none", borderRadius: 8, fontWeight: 700,
              cursor: isOutOfStock ? "not-allowed" : "pointer", fontSize: "0.75rem",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
            }}
          >
            <ShoppingCart size={12} />
            {!isDeliverable ? "Not Deliverable" : isOutOfStock ? "Out of Stock" : "Add to Cart"}
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SUBSCRIPTION PRODUCTS WIDGET — shows ONLY subscription-channel
// products. "Subscribe" (instead of Add to Cart) drops the selected
// variant into the subscription basket; floating basket button →
// /subscription/new to create the subscription.
// Self-contained: uses data.products if injected, else self-fetches.
// ═══════════════════════════════════════════════════════════════
function SubscriptionProductsSection({ data }) {
  const navigate = useNavigate();
  const subscription = useSubscription();
  const [products, setProducts] = useState(Array.isArray(data.products) ? data.products : []);
  const [loading, setLoading] = useState(!Array.isArray(data.products));
  const [visibleCount, setVisibleCount] = useState(Number(data.limit) || 8);

  const limit = Number(data.limit) || 8;

  // Self-fetch subscription channel products (skipped if page injected them)
// Self-fetch subscription channel products
useEffect(() => {
  if (Array.isArray(data.products)) { setProducts(data.products); setLoading(false); return; }
  let alive = true;
  (async () => {
    try {
      setLoading(true);
      const res = await customerApi.get("/mobile/products", {
        params: { channel: "subscription", per_page: 50, ...(data.category_id ? { category_id: data.category_id } : {}) },
      });
      // ★ DEBUG — check DevTools Console after this run
      console.log("[SubWidget] raw response:", res);

      // Handles ALL shapes:
      //   axios default → res.data = { status, message, data: [...] }
      //   unwrapped     → res      = { status, message, data: [...] }
      //   direct array  → res      = [...]
      const raw = res?.data ?? res;
      const list = Array.isArray(raw) ? raw : (raw?.products || raw?.data || []);
      console.log("[SubWidget] parsed:", list.length, "products");

      if (alive) setProducts(Array.isArray(list) ? list : []);
    } catch (e) {
      console.error("[SubWidget] fetch FAILED:", e?.response?.status, e?.response?.data || e.message);
      if (alive) setProducts([]);
    } finally {
      if (alive) setLoading(false);
    }
  })();
  return () => { alive = false; };
}, [data.products, data.category_id]);

  // Resolve the context's add method (addItem / addToSubscription / add)
  const addItem = subscription?.addItem || subscription?.addToSubscription || subscription?.add;
  const basketItems = subscription?.items || [];
  const basketCount = basketItems.reduce((n, it) => n + (Number(it.default_qty) || Number(it.quantity) || 1), 0);

  if (products.length === 0 && !loading && !data.title) return null;

const handleSubscribe = (item) => {
  if (!addItem) { toast.error("Basket unavailable"); return { ok: false }; }
  return addItem({ ...item, quantity: 1, default_qty: 1 });
};

  const shown = products.slice(0, visibleCount);

  return (
    <section style={{ padding: "40px 24px 80px", background: theme.bg, position: "relative" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {/* header row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24, gap: 12, flexWrap: "wrap" }}>
          <div>
            {data.title && <h2 style={{ fontSize: "1.5rem", fontWeight: 800, color: theme.dark, margin: 0 }}>{data.title}</h2>}
            {data.subtitle && <p style={{ color: theme.mid, fontSize: "0.85rem", margin: "4px 0 0" }}>{data.subtitle}</p>}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {basketCount > 0 && (
              <button
                onClick={() => navigate("/subscription/new")}
                style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "8px 16px", borderRadius: 100, border: "none", background: theme.primary, color: "#fff", fontWeight: 700, fontSize: "0.8rem", cursor: "pointer" }}
              >
                <Repeat size={14} /> Create Subscription ({basketCount})
              </button>
            )}
          </div>
        </div>

        {loading ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 16 }}>
            {Array.from({ length: Math.min(limit, 8) }).map((_, i) => <ProductSkeleton key={i} />)}
          </div>
        ) : products.length === 0 ? (
          <div style={{ padding: 32, textAlign: "center", color: theme.mid, background: "#fff", border: `1px dashed ${theme.border}`, borderRadius: 16, fontSize: "0.9rem" }}>
            No subscription products yet. Add products to the subscription channel to see them here.
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 16 }}>
              {shown.map((p, i) => (
                <SubscriptionProductCard key={p.id} product={p} index={i} onSubscribe={handleSubscribe} buttonText={data.button_text || "Subscribe"} />
              ))}
            </div>
            {products.length > shown.length && (
              <div style={{ textAlign: "center", marginTop: 24 }}>
                <button onClick={() => setVisibleCount((c) => c + 12)} style={{ padding: "10px 28px", borderRadius: 8, border: `1px solid ${theme.border}`, background: "#fff", color: theme.dark, fontWeight: 700, cursor: "pointer" }}>
                  Load More ({shown.length} of {products.length})
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Floating subscription basket */}
      {/* {basketCount > 0 && (
        <button
          onClick={() => navigate("/subscription/new")}
          style={{ position: "fixed", left: 20, bottom: 20, zIndex: 60, display: "flex", alignItems: "center", gap: 10, padding: "14px 22px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, fontSize: "0.9rem", cursor: "pointer", boxShadow: "0 12px 32px rgba(0,0,0,0.25)" }}
        >
          <Repeat size={18} />
          {basketCount} item{basketCount > 1 ? "s" : ""} · Create Subscription
        </button>
      )} */}
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// SUBSCRIPTION PRODUCT CARD — clone of HomeProductCard, Subscribe
// button instead of Add to Cart. No isDeliverable check (address
// is validated at subscription creation time, not here).
// ═══════════════════════════════════════════════════════════════
function SubscriptionProductCard({ product, index, onSubscribe, buttonText }) {
  const navigate = useNavigate();
  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [showVariants, setShowVariants] = useState(false);
  const [added, setAdded] = useState(false);

  const variants = product.variants || [];
  const normalizedVariants = variants.length > 0 ? variants : [
    {
      id: product.variant_id, final_price: product.price, mrp: product.mrp,
      has_discount: product.has_discount, discount_percent: product.discount_percent,
      unit_abbr: product.unit_abbr, image_url: product.image_url,
      available_stock: product.available_stock, is_out_of_stock: product.is_out_of_stock,
      is_low_stock: product.is_low_stock, attributes: [],
    },
  ];

  const selectedVariant = normalizedVariants[selectedVariantIdx] || normalizedVariants[0] || {};
  const hasMultipleVariants = normalizedVariants.length > 1;

  const isOutOfStock =
    selectedVariant.is_out_of_stock === true ||
    (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined && selectedVariant.available_stock <= 0);
  const isLowStock = !isOutOfStock && selectedVariant.available_stock != null && selectedVariant.available_stock > 0 && selectedVariant.available_stock <= 5;

  const stockLabel = isOutOfStock
    ? { text: "Out of stock", color: "#EF4444" }
    : isLowStock ? { text: `Only ${selectedVariant.available_stock} left`, color: "#F59E0B" } : null;

  const getVariantLabel = (v) => (v.attributes?.length ? v.attributes.map((a) => a.value).join(" · ") : v.unit_abbr || "Variant");

const handleSubscribe = () => {
  const res = onSubscribe({
    id: product.id,
    variant_id: selectedVariant.id,
    name: product.name,
    price: Number(selectedVariant.final_price || 0),
    unit: selectedVariant.unit_abbr || "",
    image_url: selectedVariant.image_url || product.image_url,
    attributes: selectedVariant.attributes || [],
    available_stock: selectedVariant.available_stock ?? null,
    is_out_of_stock: selectedVariant.is_out_of_stock || false,
  });
  if (res?.ok !== false) {
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
    toast.success("Added to subscription basket");
  }
};

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      whileHover={{ y: isOutOfStock ? 0 : -6 }}
      onClick={() => navigate(`/products/${product.id}`)}
      style={{
        background: "#fff", borderRadius: 20, overflow: "hidden",
        border: `1px solid ${theme.border}`, display: "flex", flexDirection: "column",
        opacity: isOutOfStock ? 0.65 : 1, transition: "opacity 0.2s",
        position: "relative", cursor: "pointer",
      }}
    >
      <div style={{ aspectRatio: "1 / 1", background: cardBgs[index % cardBgs.length], display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, position: "relative", overflow: "hidden", flexShrink: 0 }}>
        {selectedVariant.image_url ? (
          <img src={fixImageUrl(selectedVariant.image_url)} alt={product.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : "📦"}
        {isOutOfStock && (
          <span style={{ position: "absolute", top: 6, left: 6, background: "#FEE2E2", color: "#B91C1C", padding: "2px 7px", borderRadius: 5, fontSize: "0.6rem", fontWeight: 700 }}>OUT OF STOCK</span>
        )}
        {!isOutOfStock && selectedVariant.has_discount && selectedVariant.discount_percent > 0 && (
          <span style={{ position: "absolute", top: 6, left: 6, background: "#16A34A", color: "#fff", padding: "2px 7px", borderRadius: 5, fontSize: "0.6rem", fontWeight: 700 }}>
            {selectedVariant.discount_percent}% OFF
          </span>
        )}
      </div>

      <div style={{ padding: 10, display: "flex", flexDirection: "column", flex: 1 }}>
        <p style={{ fontSize: "0.62rem", color: theme.primary, fontWeight: 800, marginBottom: 2, textTransform: "uppercase" }}>{product.category}</p>
        <h3 style={{ fontSize: "0.88rem", fontWeight: 800, color: theme.dark, marginBottom: 6, lineHeight: 1.25 }}>{product.name}</h3>

        {(selectedVariant.attributes || []).length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 6 }}>
            {(selectedVariant.attributes || []).map((a, ai) => (
              <span key={ai} style={{ fontSize: "0.6rem", fontWeight: 600, color: theme.dark, background: "#F1F5F9", border: `1px solid ${theme.border}`, borderRadius: 5, padding: "2px 5px", whiteSpace: "nowrap" }}>
                {a.attribute_name}: {a.value}
              </span>
            ))}
          </div>
        )}

        {hasMultipleVariants && (
          <div style={{ marginBottom: 6, position: "relative" }}>
            <button
              onClick={(e) => { e.stopPropagation(); setShowVariants((v) => !v); }}
              style={{ width: "100%", padding: "5px 8px", background: "#F8FAFF", border: `1px solid ${theme.border}`, borderRadius: 7, fontSize: "0.72rem", fontWeight: 600, color: theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 4 }}
            >
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{getVariantLabel(selectedVariant)}</span>
              <span style={{ display: "inline-block", transform: showVariants ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s", flexShrink: 0, fontSize: "0.7rem" }}>▾</span>
            </button>
            {showVariants && (
              <div style={{ marginTop: 4, background: "#fff", border: `1px solid ${theme.border}`, borderRadius: 8, maxHeight: 180, overflowY: "auto" }}>
                {normalizedVariants.map((v, idx) => {
                  const vOutOfStock = v.is_out_of_stock === true || (v.available_stock != null && v.available_stock <= 0);
                  const isSelected = idx === selectedVariantIdx;
                  return (
                    <button
                      key={v.id || idx}
                      onClick={(e) => { e.stopPropagation(); setSelectedVariantIdx(idx); setShowVariants(false); }}
                      style={{ width: "100%", padding: "7px 10px", background: isSelected ? "#FFF7ED" : "#fff", border: "none", borderBottom: `1px solid ${theme.border}`, fontSize: "0.72rem", fontWeight: 600, color: vOutOfStock ? "#94A3B8" : theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 4, textAlign: "left", opacity: vOutOfStock ? 0.6 : 1 }}
                    >
                      <span>{getVariantLabel(v)}</span>
                      <span style={{ display: "flex", alignItems: "center", gap: 4, flexShrink: 0, color: isSelected ? theme.primary : theme.mid, fontWeight: 700 }}>
                        ₹{Number(v.final_price || 0).toFixed(0)}
                        {isSelected && <span style={{ color: theme.primary }}>✓</span>}
                        {vOutOfStock && <span style={{ fontSize: "0.6rem", color: "#EF4444" }}>Out</span>}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {stockLabel && <div style={{ fontSize: "0.67rem", fontWeight: 700, color: stockLabel.color, marginBottom: 6 }}>● {stockLabel.text}</div>}

        <div style={{ marginTop: "auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: "0.95rem", fontWeight: 900, color: theme.dark }}>₹{Number(selectedVariant.final_price || 0).toFixed(0)}</span>
            {selectedVariant.has_discount && selectedVariant.mrp > selectedVariant.final_price && (
              <span style={{ fontSize: "0.7rem", color: "#94A3B8", textDecoration: "line-through" }}>₹{Number(selectedVariant.mrp || 0).toFixed(0)}</span>
            )}
            {selectedVariant.unit_abbr && <span style={{ fontSize: "0.68rem", color: theme.mid }}>/ {selectedVariant.unit_abbr}</span>}
          </div>

          {/* ★ SUBSCRIBE button — instead of Add to Cart */}
          <button
            onClick={(e) => { e.stopPropagation(); handleSubscribe(); }}
            disabled={isOutOfStock}
            style={{
              width: "100%", padding: "8px",
              background: isOutOfStock ? "#E2E8F0" : theme.primary,
              color: isOutOfStock ? "#94A3B8" : "#fff",
              border: "none", borderRadius: 8, fontWeight: 700,
              cursor: isOutOfStock ? "not-allowed" : "pointer", fontSize: "0.75rem",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
            }}
          >
            <Repeat size={12} />
            {added ? "✓ Added" : isOutOfStock ? "Out of Stock" : buttonText}
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// TESTIMONIALS SECTION — Horizontal scroll with arrows + scoped CSS
// ═══════════════════════════════════════════════════════════════
function TestimonialsSection({ data }) {
  const items = data.items || [];
  const scrollRef = useRef(null);

  if (items.length === 0) return null;

  const scrollByAmount = (dir) => {
    const container = scrollRef.current;
    if (!container) return;
    const cardWidth = 350 + 24;
    container.scrollBy({ left: dir * cardWidth, behavior: "smooth" });
  };

  return (
    <section style={{ padding: "80px 0", background: "#fff", position: "relative" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={{ textAlign: "center", marginBottom: 40 }}>
          <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 900, color: theme.dark }}>{data.title}</h2>
        </motion.div>
      </div>

      <div style={{ position: "relative", maxWidth: 1200, margin: "0 auto" }}>
        {/* ★ Left arrow */}
        <button
          onClick={() => scrollByAmount(-1)}
          aria-label="Scroll testimonials left"
          style={{
            position: "absolute", left: -8, top: "50%", transform: "translateY(-50%)", zIndex: 10,
            width: 40, height: 40, borderRadius: "50%", background: "#fff",
            border: `1px solid ${theme.border}`, boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: theme.dark,
          }}
        >
          <ChevronLeft size={20} />
        </button>

        {/* ★ Right arrow */}
        <button
          onClick={() => scrollByAmount(1)}
          aria-label="Scroll testimonials right"
          style={{
            position: "absolute", right: -8, top: "50%", transform: "translateY(-50%)", zIndex: 10,
            width: 40, height: 40, borderRadius: "50%", background: "#fff",
            border: `1px solid ${theme.border}`, boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: theme.dark,
          }}
        >
          <ChevronRight size={20} />
        </button>

        {/* ★ Scroll container — scoped CSS class */}
        <div
          ref={scrollRef}
          className="testimonials-scroll"
          style={{
            display: "flex", overflowX: "auto", gap: 24, padding: "16px 56px",
            scrollSnapType: "x mandatory", scrollBehavior: "smooth",
          }}
        >
          <style>{`
            .testimonials-scroll::-webkit-scrollbar { height: 6px; }
            .testimonials-scroll::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 3px; }
            .testimonials-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
            .testimonials-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
          `}</style>
          {items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              style={{
                minWidth: 300, maxWidth: 350, scrollSnapAlign: "start",
                background: theme.bg, borderRadius: 20, padding: 32,
                border: `1px solid ${theme.border}`, position: "relative", flex: "0 0 auto",
              }}
            >
              <Quote size={40} color={theme.primary} style={{ opacity: 0.2, position: "absolute", top: 20, right: 20 }} />
              <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} size={16} fill={s < (item.rating || 5) ? "#F59E0B" : "none"} color={s < (item.rating || 5) ? "#F59E0B" : "#D1D5DB"} />
                ))}
              </div>
              <p style={{ color: theme.dark, fontSize: "1rem", lineHeight: 1.6, marginBottom: 24, fontStyle: "italic" }}>
                "{item.text}"
              </p>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: "50%", background: theme.primary, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800 }}>
                  {item.name?.charAt(0) || "?"}
                </div>
                <div>
                  <p style={{ color: theme.dark, fontWeight: 700, margin: 0 }}>{item.name}</p>
                  <p style={{ color: theme.mid, fontSize: "0.85rem", margin: 0 }}>Verified Customer</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection({ data }) {
  return (
    <section style={{ padding: "80px 24px", background: "var(--color-primary, #666666)" }}>
      <div style={{ maxWidth: 800, margin: "0 auto", textAlign: "center" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          {data.label && <span style={{ display: "inline-block", background: "rgba(255,255,255,0.15)", color: "#fff", padding: "6px 14px", borderRadius: 100, fontSize: "0.78rem", fontWeight: 700, marginBottom: 16 }}>{data.label}</span>}
          <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 900, color: "#fff", marginBottom: 16 }}>{data.title}</h2>
          {data.subtitle && <p style={{ color: "rgba(255,255,255,0.9)", fontSize: "1.05rem", maxWidth: 600, margin: "0 auto 32px" }}>{data.subtitle}</p>}
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            {data.btn1_text && data.btn1_link && <Link to={data.btn1_link} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "16px 32px", borderRadius: 12, background: "#fff", color: "var(--color-primary, #666666)", fontWeight: 700, textDecoration: "none" }}>{data.btn1_text} <ArrowRight size={18} /></Link>}
            {data.btn2_text && data.btn2_link && <Link to={data.btn2_link} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "16px 32px", borderRadius: 12, background: "transparent", color: "#fff", fontWeight: 700, textDecoration: "none", border: "2px solid rgba(255,255,255,0.5)" }}>{data.btn2_text}</Link>}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function StorySection({ data }) {
  return (
    <section style={{ padding: "80px 24px", background: "#fff" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 48, alignItems: "center" }}>
          <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            {data.label && <span style={{ display: "inline-block", background: "rgba(0,0,0,0.05)", color: theme.primary, padding: "6px 14px", borderRadius: 100, fontSize: "0.78rem", fontWeight: 700, marginBottom: 16 }}>{data.label}</span>}
            <h2 style={{ fontSize: "clamp(1.6rem, 4vw, 2.2rem)", fontWeight: 900, color: theme.dark, marginBottom: 20 }}>{data.title}</h2>
            <p style={{ color: theme.mid, fontSize: "1rem", lineHeight: 1.7, marginBottom: 16 }}>{data.desc1}</p>
            {data.desc2 && <p style={{ color: theme.mid, fontSize: "1rem", lineHeight: 1.7 }}>{data.desc2}</p>}
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
            {(data.stats || []).map((stat, i) => (
              <div key={i} style={{ background: theme.bg, borderRadius: 16, padding: 24, textAlign: "center", border: `1px solid ${theme.border}` }}>
                <div style={{ fontSize: "2rem", fontWeight: 900, color: theme.primary, marginBottom: 4 }}>{stat.n}</div>
                <div style={{ fontSize: "0.85rem", color: theme.mid }}>{stat.l}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function WhyUsSection({ data }) {
  return (
    <section style={{ padding: "80px 24px", background: theme.bg }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={{ textAlign: "center", marginBottom: 48 }}>
          {data.label && <span style={{ display: "inline-block", background: "rgba(0,0,0,0.05)", color: theme.primary, padding: "6px 14px", borderRadius: 100, fontSize: "0.78rem", fontWeight: 700, marginBottom: 12 }}>{data.label}</span>}
          <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 900, color: theme.dark, marginBottom: 12 }}>{data.title}</h2>
          {data.subtitle && <p style={{ color: theme.mid, fontSize: "1rem", maxWidth: 600, margin: "0 auto" }}>{data.subtitle}</p>}
        </motion.div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 24 }}>
          {(data.items || []).map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} style={{ background: "#fff", borderRadius: 16, padding: 24, border: `1px solid ${theme.border}` }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: theme.primary, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}><Star size={20} color="#fff" /></div>
              <h3 style={{ fontSize: "1.05rem", fontWeight: 800, color: theme.dark, marginBottom: 8 }}>{item.title}</h3>
              <p style={{ color: theme.mid, fontSize: "0.9rem", lineHeight: 1.6, margin: 0 }}>{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function InfoSection({ data }) {
  const items = [{ label: "Address", value: data.address }, { label: "Phone", value: data.phone }, { label: "Email", value: data.email }, { label: "Hours", value: data.hours }].filter(i => i.value);
  return (
    <section style={{ padding: "80px 24px", background: "#fff" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24 }}>
          {items.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} style={{ background: theme.bg, borderRadius: 20, padding: 28, border: `1px solid ${theme.border}`, textAlign: "center" }}>
              <h3 style={{ fontSize: "0.78rem", fontWeight: 800, color: theme.mid, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8 }}>{item.label}</h3>
              <p style={{ color: theme.dark, fontSize: "0.95rem", lineHeight: 1.5, margin: 0, whiteSpace: "pre-wrap" }}>{item.value}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhatsAppSection({ data }) {
  return (
    <section style={{ padding: "0 24px 80px", background: "#fff" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={{ background: "linear-gradient(135deg, #25D366, #128C7E)", borderRadius: 24, padding: 40, textAlign: "center", color: "#fff" }}>
          {data.title && <h3 style={{ fontSize: "1.5rem", fontWeight: 800, marginBottom: 8 }}>{data.title}</h3>}
          {data.desc && <p style={{ fontSize: "1rem", opacity: 0.95, marginBottom: 24, maxWidth: 500, margin: "0 auto 24px" }}>{data.desc}</p>}
          {data.btn_text && data.link && <a href={data.link} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "14px 32px", background: "#fff", color: "#128C7E", borderRadius: 12, fontWeight: 700, textDecoration: "none", fontSize: "0.95rem" }}>{data.btn_text}</a>}
        </motion.div>
      </div>
    </section>
  );
}

function TextBlockSection({ data }) {
  return (
    <section style={{ padding: "80px 24px", background: data.bg_color || "#fff" }}>
      <div style={{ maxWidth: 800, margin: "0 auto", textAlign: data.alignment || "left" }}>
        {data.title && <h2 style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 800, color: theme.dark, marginBottom: 16 }}>{data.title}</h2>}
        <p style={{ color: theme.mid, fontSize: "1rem", lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{data.content}</p>
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// IMAGE BLOCK SECTION
// ═══════════════════════════════════════════════════════════════
function ImageBlockSection({ data }) {
  const rawImages = Array.isArray(data.image_url) ? data.image_url : [data.image_url];
  const images = rawImages.filter(Boolean).map(img => fixImageUrl(img));

  const [activeSlide, setActiveSlide] = useState(0);
  useEffect(() => {
    if (images.length > 1) {
      const t = setInterval(() => setActiveSlide(p => (p + 1) % images.length), 5000);
      return () => clearInterval(t);
    }
  }, [images.length]);

  if (images.length === 0) return null;

  const imgHeight = HEIGHT_PRESETS[data.height] || "450px";
  const objectFit = data.object_fit || "cover";

  if (images.length === 1) {
    return (
      <section style={{ width: "100%", background: "#fff", textAlign: "center" }}>
        <div style={{ width: "100%", height: imgHeight, overflow: "hidden" }}>
          <img src={images[0]} alt={data.alt_text || ""} style={{ width: "100%", height: "100%", objectFit: objectFit }} />
        </div>
      </section>
    );
  }

  return (
    <section style={{ position: "relative", width: "100%", minHeight: imgHeight, overflow: "hidden", background: "#1E293B" }}>
      {images.map((img, i) => (
        <div key={i} style={{ position: "absolute", inset: 0, backgroundImage: `url(${img})`, backgroundSize: objectFit, backgroundPosition: "center", backgroundRepeat: "no-repeat", opacity: i === activeSlide ? 1 : 0, transition: "opacity 1.5s ease-in-out" }} />
      ))}
      {images.length > 1 && (
        <div style={{ position: "absolute", bottom: 24, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 10, zIndex: 3 }}>
          {images.map((_, i) => (
            <button key={i} onClick={() => setActiveSlide(i)} style={{ width: i === activeSlide ? 32 : 10, height: 10, borderRadius: 5, border: "none", background: i === activeSlide ? "var(--color-primary, #666666)" : "rgba(255,255,255,0.6)", cursor: "pointer", padding: 0 }} />
          ))}
        </div>
      )}
    </section>
  );
}