import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle, CheckCircle2, Eye, EyeOff, X } from "lucide-react";
import toast from "react-hot-toast";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";

const fallbackTheme = {
  primary: "#FF7132", dark: "#333333", mid: "#666666",
  border: "#E0E0E0", error: "#EF4444", success: "#22c55e",
  warning: "#f59e0b", info: "#3b82f6",
};

function getPasswordStrength(pwd) {
  if (!pwd) return { score: 0, label: "", color: "" };
  let score = 0;
  if (pwd.length >= 6) score++;
  if (pwd.length >= 10) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;

  if (score <= 1) return { score, label: "Weak", color: fallbackTheme.error };
  if (score <= 2) return { score, label: "Fair", color: fallbackTheme.warning };
  if (score <= 3) return { score, label: "Good", color: fallbackTheme.info };
  return { score, label: "Strong", color: fallbackTheme.success };
}

export default function RegisterModal({ onClose, onSwitchToLogin }) {
  const { register, clearError } = useCustomerAuth();
  // ★ Dynamic branding from tenant
  const { theme } = useTenant() || {};
  const primaryColor = theme?.primary_color || fallbackTheme.primary;
  const accentColor = theme?.secondary_color || fallbackTheme.dark;
  const logoUrl = theme?.logo_url;
  const brandName = theme?.brand_name || "Shop Hub";

  const [form, setForm] = useState({
    name: "", email: "", phone: "",
    password: "", confirmPassword: "", terms: false,
  });
  const [errors, setErrors] = useState({});
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const strength = getPasswordStrength(form.password);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Full name is required.";
    if (!form.email) errs.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Enter a valid email address.";
    if (!form.phone) errs.phone = "Phone number is required.";
    else if (!/^\+?[\d\s\-()]{7,15}$/.test(form.phone)) errs.phone = "Enter a valid phone number.";
    if (!form.password) errs.password = "Password is required.";
    else if (form.password.length < 6) errs.password = "Password must be at least 6 characters.";
    if (!form.confirmPassword) errs.confirmPassword = "Please confirm your password.";
    else if (form.password !== form.confirmPassword) errs.confirmPassword = "Passwords do not match.";
    if (!form.terms) errs.terms = "You must accept the Terms & Conditions.";
    return errs;
  };

  const handleChange = (field) => (e) => {
    const val = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((p) => ({ ...p, [field]: val }));
    if (errors[field]) setErrors((p) => ({ ...p, [field]: "" }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    clearError();

    try {
      const ok = await register({
        name: form.name, email: form.email,
        password: form.password, phone: form.phone,
      });

      if (ok) {
        setSuccess(true);
        setTimeout(() => { onClose(); }, 2000);
      } else {
        const { error } = useCustomerAuth.getState();
        const msg = error || "Failed to create account.";
        if (typeof msg === 'object' && msg.errors) {
          setErrors({
            name: msg.errors.name ? msg.errors.name[0] : "",
            email: msg.errors.email ? msg.errors.email[0] : "",
            password: msg.errors.password ? msg.errors.password[0] : "",
            phone: msg.errors.phone ? msg.errors.phone[0] : "",
          });
        } else {
          toast.error(msg);
        }
      }
    } catch (error) {
      toast.error("An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = (hasError) => ({
    width: "100%", padding: "12px 14px", borderRadius: "10px",
    border: `1.5px solid ${hasError ? fallbackTheme.error : fallbackTheme.border}`,
    fontSize: "0.95rem", color: fallbackTheme.dark, outline: "none",
    transition: "border-color 0.2s", backgroundColor: "#fff",
  });

  return (
    <AnimatePresence>
      <div style={{
        position: "fixed", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
        padding: "24px", zIndex: 1000, backgroundColor: "rgba(0,0,0,0.5)",
        backdropFilter: "blur(5px)", WebkitBackdropFilter: "blur(5px)",
      }} onClick={onClose}>
        <motion.div
          initial={{ opacity: 0, y: 32, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.98 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          style={{
            width: "100%", maxWidth: "480px", background: "#ffffff", borderRadius: "24px",
            padding: "40px", boxShadow: "0 24px 64px rgba(0,0,0,0.2)", position: "relative",
            maxHeight: "90vh", overflowY: "auto",
          }} onClick={(e) => e.stopPropagation()}
        >
          <AnimatePresence>
            {success && (
              <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                style={{
                  position: "absolute", inset: 0, borderRadius: "24px", background: "rgba(255,255,255,0.95)",
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", zIndex: 10, gap: "12px",
                }}
              >
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
                  <CheckCircle2 size={56} color={fallbackTheme.success} />
                </motion.div>
                <div style={{ fontSize: "1.4rem", fontWeight: "800", color: fallbackTheme.dark }}>Account created!</div>
                <div style={{ color: fallbackTheme.mid, fontSize: "0.95rem" }}>Redirecting you to your dashboard…</div>
              </motion.div>
            )}
          </AnimatePresence>

          <button type="button" onClick={onClose} style={{ position: "absolute", top: "16px", right: "16px", background: "none", border: "none", cursor: "pointer", padding: "8px", color: fallbackTheme.mid }}>
            <X size={20} />
          </button>

          {/* ★ Dynamic Header — uses tenant logo + brand name */}
          <div style={{ textAlign: "center", marginBottom: "28px" }}>
            <div style={{ display: "flex", justifyContent: "center", marginBottom: "16px" }}>
              {logoUrl ? (
                <img src={logoUrl} alt={brandName} style={{ height: "48px", objectFit: "contain" }} onError={(e) => { e.target.style.display = 'none' }} />
              ) : (
                <div style={{
                  width: "48px", height: "48px", borderRadius: "12px",
                  background: `linear-gradient(135deg, ${primaryColor}, ${accentColor})`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  <span style={{ color: "#fff", fontSize: "1.3rem", fontWeight: 800 }}>{brandName?.charAt(0)?.toUpperCase() || "S"}</span>
                </div>
              )}
            </div>
            <h1 style={{ fontSize: "1.8rem", fontWeight: "800", color: fallbackTheme.dark, marginBottom: "8px" }}>Create an account</h1>
            <p style={{ color: fallbackTheme.mid, fontSize: "0.9rem" }}>Join {brandName} and start shopping today</p>
          </div>

          <form onSubmit={handleSubmit} noValidate>
            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: fallbackTheme.dark, marginBottom: "6px" }}>Full Name</label>
              <input type="text" value={form.name} onChange={handleChange("name")} placeholder="Your Name" style={inputStyle(!!errors.name)} onFocus={(e) => (e.target.style.borderColor = primaryColor)} onBlur={(e) => { if (!errors.name) e.target.style.borderColor = fallbackTheme.border; }} />
              {errors.name && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.name}</span>}
            </div>

            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: fallbackTheme.dark, marginBottom: "6px" }}>Email Address</label>
              <input type="email" value={form.email} onChange={handleChange("email")} placeholder="you@email.com" style={inputStyle(!!errors.email)} onFocus={(e) => (e.target.style.borderColor = primaryColor)} onBlur={(e) => { if (!errors.email) e.target.style.borderColor = fallbackTheme.border; }} />
              {errors.email && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.email}</span>}
            </div>

            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: fallbackTheme.dark, marginBottom: "6px" }}>Phone Number</label>
              <input type="tel" value={form.phone} onChange={handleChange("phone")} placeholder="9876543210" style={inputStyle(!!errors.phone)} onFocus={(e) => (e.target.style.borderColor = primaryColor)} onBlur={(e) => { if (!errors.phone) e.target.style.borderColor = fallbackTheme.border; }} />
              {errors.phone && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.phone}</span>}
            </div>

            <div style={{ marginBottom: "16px" }}>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: fallbackTheme.dark, marginBottom: "6px" }}>Password</label>
              <div style={{ position: "relative" }}>
                <input type={showPwd ? "text" : "password"} value={form.password} onChange={handleChange("password")} placeholder="Please Enter Your Password" style={{ ...inputStyle(!!errors.password), paddingRight: "40px" }} onFocus={(e) => (e.target.style.borderColor = primaryColor)} onBlur={(e) => { if (!errors.password) e.target.style.borderColor = fallbackTheme.border; }} />
                <button type="button" onClick={() => setShowPwd(!showPwd)} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: fallbackTheme.mid }}>
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {form.password && (
                <div style={{ marginTop: "8px" }}>
                  <div style={{ display: "flex", gap: "4px", marginBottom: "4px" }}>
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} style={{ flex: 1, height: "4px", borderRadius: "2px", background: i <= strength.score ? strength.color : fallbackTheme.border, transition: "background 0.3s" }} />
                    ))}
                  </div>
                  <div style={{ fontSize: "0.75rem", color: strength.color, fontWeight: "600" }}>{strength.label} password</div>
                </div>
              )}
              {errors.password && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.password}</span>}
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: fallbackTheme.dark, marginBottom: "6px" }}>Confirm Password</label>
              <input type="password" value={form.confirmPassword} onChange={handleChange("confirmPassword")} placeholder="Re-enter password" style={inputStyle(!!errors.confirmPassword)} onFocus={(e) => (e.target.style.borderColor = primaryColor)} onBlur={(e) => { if (!errors.confirmPassword) e.target.style.borderColor = fallbackTheme.border; }} />
              {errors.confirmPassword && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.confirmPassword}</span>}
            </div>

            <div style={{ marginBottom: "24px" }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                <input type="checkbox" id="terms" checked={form.terms} onChange={handleChange("terms")} style={{ width: "16px", height: "16px", marginTop: "2px", accentColor: primaryColor, cursor: "pointer" }} />
                <label htmlFor="terms" style={{ fontSize: "0.85rem", color: fallbackTheme.mid, cursor: "pointer", lineHeight: "1.4" }}>
                  I agree to the <a href="#" style={{ color: primaryColor, fontWeight: "600", textDecoration: "none" }}>Terms of Service</a> and <a href="#" style={{ color: primaryColor, fontWeight: "600", textDecoration: "none" }}>Privacy Policy</a>
                </label>
              </div>
              {errors.terms && <span style={{ color: fallbackTheme.error, fontSize: "0.8rem", marginTop: "4px", display: "block" }}>{errors.terms}</span>}
            </div>

            {/* ★ Submit button uses tenant primary color */}
            <button type="submit" disabled={loading} style={{
              width: "100%", padding: "14px", borderRadius: "10px", border: "none",
              background: loading ? `${primaryColor}80` : primaryColor,
              color: "#fff", fontSize: "0.95rem", fontWeight: "700",
              cursor: loading ? "not-allowed" : "pointer", transition: "background 0.2s",
            }}>
              {loading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <div style={{ textAlign: "center", marginTop: "24px", fontSize: "0.85rem", color: fallbackTheme.mid }}>
            Already have an account?{" "}
            <button type="button" onClick={() => { onClose(); if (onSwitchToLogin) onSwitchToLogin(); }} style={{ background: "none", border: "none", color: primaryColor, fontWeight: "700", textDecoration: "none", cursor: "pointer", padding: 0, fontSize: "0.85rem" }}>
              Sign In
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
