import { motion, AnimatePresence } from "framer-motion";
import { X, Minus, Plus, Trash2, ShoppingBag, ArrowRight, AlertCircle, Truck, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../pages/CartContext";
import { useState, useEffect } from "react";
import customerApi from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
// ★ FREE GIFTS — cart progress bar, earned gift lines, unlock toast
import useGiftProgress from "../hooks/useGiftProgress";
import FreeGiftBar from "./gifts/FreeGiftBar";
import CartGiftLines from "./gifts/CartGiftLines";
import GiftToast from "./gifts/GiftToast";

// ─────────────────────────────────────────────────────────────────────────
// CartDrawer.jsx — delivery zone awareness + builder-configured suggestions
//
// Reads cart_config from the published layout:
//   enabled, mode (auto/manual), max_items, title, fill_with_recent, items
// Falls back to enabled/auto if the config can't be loaded.
// ─────────────────────────────────────────────────────────────────────────

const DEFAULT_SUGGEST = {
  enabled: true,
  mode: "auto",
  max_items: 5,
  title: "",
  fill_with_recent: true,
  items: [],
};

export default function CartDrawer() {
  const {
    cartItems,
    isCartOpen,
    setIsCartOpen,
    updateQuantity,
    removeFromCart,
    cartTotal,
    cartCount,
    hasOutOfStockItems,
    isDeliverable,
    addToCart,
  } = useCart();
  const navigate = useNavigate();
  const [toast, setToast] = useState(null);
  const [picking, setPicking] = useState(null);

  // ★ FREE GIFTS — live campaign + progress. Display-only: the server
  // re-resolves everything at orders/preview and again at place().
  // (No coupon discount exists in the drawer yet → couponDiscount stays 0.)
  const [giftToast, setGiftToast] = useState(null);
  const gifts = useGiftProgress({
    subtotal: Number(cartTotal) || 0,
    enabled: isCartOpen,
    onTierCrossed: (p) => setGiftToast({ tier: p.highest, lines: p.earnedLines }),
  });

  // ★ NEW: builder-published cart config
  const [suggestConfig, setSuggestConfig] = useState(DEFAULT_SUGGEST);

  // ★ NEW: load the config once on mount.
  // ⚠ ADJUST this endpoint to whatever your storefront uses to load the
  // active layout (the same source that gives you theme colors / footer).
  // If it fails, the drawer silently falls back to enabled/auto mode.
  useEffect(() => {
    let cancelled = false;
    customerApi
      .get("/mobile/web/layout")
      .then((res) => {
        const raw = res.data?.data;
        const layout = Array.isArray(raw) ? raw[0] : raw;              // handles both shapes
        const saved = layout?.product_display_config?.cart_suggestions; // ★ NEW location
        if (!cancelled && saved) {
          setSuggestConfig({ ...DEFAULT_SUGGEST, ...saved });
        }
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);
    // ★ NEW — resolve the customer's saved location so the suggestion pool
  //    gets REAL branch stock (without lat/lng the backend returns
  //    available_stock: null for everything — the OOS filters had nothing
  //    real to filter on). Guests / logged-out → no coords → falls back
  //    to "unknown stock" (checkout re-validation is the final gate).
  const { isAuthenticated } = useCustomerAuth();
  // ★ resolve the customer's saved location so the suggestion pool
  //    gets REAL branch stock. Guests skip this entirely (no coords →
  //    pool fetches without location, same as the products page).
  const [suggestLatLng, setSuggestLatLng] = useState(null);

  useEffect(() => {
    if (!isCartOpen || suggestLatLng !== null) return;
    // ★ guests: mark "no coords" and skip the auth-required call
    if (!isAuthenticated) {
      setSuggestLatLng(false);
      return;
    }
    let cancelled = false;
    customerApi
      .get("/mobile/addresses")
      .then((res) => {
        const addrs = res.data?.data || [];
        const def = addrs.find((a) => a.is_default) || addrs[0];
        if (!cancelled) {
          setSuggestLatLng(
            def && def.latitude != null && def.longitude != null
              ? { lat: def.latitude, lng: def.longitude }
              : false
          );
        }
      })
      .catch(() => { if (!cancelled) setSuggestLatLng(false); });
    return () => { cancelled = true; };
  }, [isCartOpen, isAuthenticated]);

  // ★ UPDATED: pool of ALL variant-level items, newest products first
  const [variantPool, setVariantPool] = useState([]);
  const [suggestionsLoading, setSuggestionsLoading] = useState(false);
  useEffect(() => {
    if (!isCartOpen || suggestConfig.enabled === false) return;
    let cancelled = false;
    setSuggestionsLoading(true);
    const poolParams = { limit: 50, per_page: 50 };
    if (suggestLatLng) {
      poolParams.lat = suggestLatLng.lat;
      poolParams.lng = suggestLatLng.lng;
    }
    customerApi
      .get("/mobile/products", { params: poolParams })
      .then((res) => {
        const products = res.data?.data || res.data?.products || [];
        if (!Array.isArray(products)) { if (!cancelled) setVariantPool([]); return; }
        const flat = [];
        products.forEach((p) => {
          (p.variants || []).forEach((v) => {
            const price = v.final_price ?? v.selling_price ?? v.mrp ?? 0;
            flat.push({
              id: v.id,
              product_id: p.id,
              name: p.name,
              price,
              mrp: v.mrp,
              discount_percent: v.discount_percent || 0,
              show_mrp: v.has_discount === true && Number(v.mrp) > Number(price),
              image_url: v.image_url,
              unit: v.unit_abbr || v.unit_name,
              available_stock: v.available_stock,
              is_out_of_stock: v.is_out_of_stock,
              attr_summary: (v.attributes || []).map((a) => a.value).join(" · "),
              attributes: v.attributes || [],
            });
          });
        });
        flat.sort((a, b) => b.product_id - a.product_id); // newest-first proxy
        if (!cancelled) setVariantPool(flat);
      })
      .catch(() => { if (!cancelled) setVariantPool([]); })
      .finally(() => { if (!cancelled) setSuggestionsLoading(false); });
    return () => { cancelled = true; };
    }, [isCartOpen, suggestConfig.enabled, suggestLatLng]);

  const showToast = (msg, kind = "error") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 2500);
  };

  // ★ variants of a product still in stock (drives the picker)
  const inStockVariantsOf = (productId) =>
    variantPool.filter((v) => v.product_id === productId && v.is_out_of_stock !== true);
  const handleAddSuggestion = (s) => {
    if (!isDeliverable) {
      showToast("Delivery is not available at your location.", "error");
      return;
    }
    if (s.is_out_of_stock === true) {
      showToast("This item is out of stock", "error");
      return;
    }
    if (inStockVariantsOf(s.product_id).length > 1) {
      setPicking(s);
      return;
    }
    const cartItem = {
      id: s.product_id,
      variant_id: s.id,
      product_id: s.product_id,
      name: s.name,
      price: s.price,
      mrp: s.mrp,
      image_url: s.image_url,
      unit: s.unit,
      available_stock: s.available_stock,
      is_out_of_stock: s.is_out_of_stock,
      attributes: s.attributes || [],
    };
    const result = addToCart(cartItem);
    if (result && result.success === false) {
      showToast(result.error || "Could not add this item");
    } else {
      showToast(`${s.name} added to cart`, "success");
    }
  };

  // ★ add a specifically picked variant
  const addPickedVariant = (v) => {
    if (!isDeliverable) {
      showToast("Delivery is not available at your location.", "error");
      return;
    }
    if (v.is_out_of_stock === true) {
      showToast("This variant is out of stock", "error");
      return;
    }
    const result = addToCart({
      id: v.product_id,
      variant_id: v.id,
      product_id: v.product_id,
      name: v.name,
      price: v.price,
      mrp: v.mrp,
      image_url: v.image_url,
      unit: v.unit,
      available_stock: v.available_stock,
      is_out_of_stock: v.is_out_of_stock,
      attributes: v.attributes || [],
    });
    setPicking(null);
    if (result && result.success === false) {
      showToast(result.error || "Could not add this item");
    } else {
      showToast(`${v.name} added to cart`, "success");
    }
  };

  const handleUpdateQty = (id, amount) => {
    const result = updateQuantity(id, amount);
    if (!result.success && result.error) {
      showToast(result.error);
    }
  };

  const handleCheckout = () => {
    if (!isDeliverable) {
      showToast("Delivery is not available at your location. Please set a deliverable location.");
      return;
    }
    if (hasOutOfStockItems()) {
      showToast("Please remove out-of-stock items before checkout");
      return;
    }
    setIsCartOpen(false);
    navigate("/checkout");
  };

  const canIncreaseQty = (item) => {
    if (!isDeliverable) return false;
    if (item.is_out_of_stock === true) return false;
    if (item.available_stock === null || item.available_stock === undefined) return true;
    return item.quantity < item.available_stock;
  };

  const isItemOutOfStock = (item) =>
    item.is_out_of_stock === true ||
    (item.available_stock !== null &&
      item.available_stock !== undefined &&
      item.available_stock < item.quantity);

  const outOfStockCount = cartItems.filter(isItemOutOfStock).length;
  const blockCheckout = !isDeliverable || outOfStockCount > 0;

  // ★ UPDATED: apply the builder config to build the final suggestion list
  const cartIds = new Set(cartItems.map((i) => i.id));
  const cartVariantIds = new Set(cartItems.map((i) => i.variant_id).filter(Boolean));
  const cartProductIds = new Set(cartItems.map((i) => i.product_id).filter(Boolean));
  const maxItems = Math.max(1, Math.min(10, parseInt(suggestConfig.max_items) || 5));

  // auto list: first in-stock variant per product, newest-first
  // auto list: first IN-STOCK variant per product, newest-first.
  // ★ If every variant of a product is OOS, the product still appears —
  //   greyed out and not addable — instead of vanishing.
  const autoList = [];
  {
    const seen = new Set();
    variantPool.forEach((s) => {
      if (s.is_out_of_stock !== true && !seen.has(s.product_id)) {
        seen.add(s.product_id);
        autoList.push(s);
      }
    });
    const firstByProduct = new Map();
    variantPool.forEach((s) => {
      if (!firstByProduct.has(s.product_id)) firstByProduct.set(s.product_id, s);
    });
    firstByProduct.forEach((first, productId) => {
      if (!seen.has(productId)) autoList.push(first); // all-OOS product → still shown
    });
  }

  let candidates = autoList;
  if (suggestConfig.mode === "manual") {
    const byVariantId = new Map(variantPool.map((s) => [s.id, s]));
    const byProductId = new Map(autoList.map((s) => [s.product_id, s]));
    candidates = [];
    (suggestConfig.items || []).forEach((it) => {
      const s = it.variant_id ? byVariantId.get(it.variant_id) : byProductId.get(it.product_id);
      if (s) candidates.push(s);
    });
    if (suggestConfig.fill_with_recent !== false) {
      const pickedProducts = new Set(candidates.map((s) => s.product_id));
      autoList.forEach((s) => {
        if (!pickedProducts.has(s.product_id)) candidates.push(s);
      });
    }
  }

  const visibleSuggestions = candidates
    .filter((s) => !cartVariantIds.has(s.id) && !cartIds.has(s.id) && !cartProductIds.has(s.product_id))
    .slice(0, maxItems);

  const stripTitle = (suggestConfig.title || "").trim() ||
    (cartItems.length === 0 ? "Popular right now" : "You may also like");
  const showSuggestions = suggestConfig.enabled !== false && (suggestionsLoading || visibleSuggestions.length > 0);

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", backdropFilter: "blur(4px)", zIndex: 9998 }}
          />

          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            style={{ position: "fixed", top: 0, right: 0, bottom: 0, width: "100%", maxWidth: "400px", background: "#fff", zIndex: 9999, display: "flex", flexDirection: "column", boxShadow: "-10px 0 30px rgba(0,0,0,0.15)" }}
          >
            {/* Header */}
            <div style={{ padding: "20px", borderBottom: "1px solid #E2E8F0", display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--color-primary, #FF7132)" }}>
              <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#fff", display: "flex", alignItems: "center", gap: "8px", margin: 0 }}>
                <ShoppingBag size={20} /> Your Cart ({cartCount})
              </h2>
              <button onClick={() => setIsCartOpen(false)} style={{ background: "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", color: "#fff", borderRadius: 8, padding: 6, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <X size={20} />
              </button>
            </div>

            {/* ★ Not deliverable warning */}
            {!isDeliverable && (
              <div style={{ padding: "12px 16px", background: "#FEF2F2", borderBottom: "1px solid #FECACA", display: "flex", alignItems: "center", gap: 8 }}>
                <Truck size={16} color="#DC2626" />
                <span style={{ fontSize: "0.82rem", color: "#B91C1C", fontWeight: 600 }}>
                  Delivery not available at your location — checkout blocked
                </span>
              </div>
            )}

            {/* Out-of-stock warning (only if deliverable) */}
            {isDeliverable && outOfStockCount > 0 && (
              <div style={{ padding: "12px 16px", background: "#FEF2F2", borderBottom: "1px solid #FECACA", display: "flex", alignItems: "center", gap: 8 }}>
                <AlertCircle size={16} color="#DC2626" />
                <span style={{ fontSize: "0.82rem", color: "#B91C1C", fontWeight: 600 }}>
                  {outOfStockCount} item{outOfStockCount !== 1 ? "s" : ""} out of stock — please remove before checkout
                </span>
              </div>
            )}

            {/* ★ FREE GIFTS — progress bar above the item list */}
            {cartItems.length > 0 && (
              <div style={{ padding: "12px 16px 0", background: "#F8FAFF" }}>
                <FreeGiftBar
                  campaign={gifts.campaign}
                  tiers={gifts.tiers}
                  progress={gifts.progress}
                  loading={gifts.loading}
                />
              </div>
            )}

            {/* Items + suggestions */}
            <div style={{ flex: 1, overflowY: "auto", padding: "16px", background: "#F8FAFF" }}>
              {cartItems.length === 0 ? (
                <div style={{ textAlign: "center", marginTop: showSuggestions ? "24px" : "60px", color: "#64748B" }}>
                  <ShoppingBag size={48} opacity={0.2} style={{ margin: "0 auto 16px" }} />
                  <p style={{ fontSize: "1rem", fontWeight: 600 }}>Your cart is empty</p>
                  <p style={{ fontSize: "0.85rem" }}>Add some products to get started!</p>
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  {cartItems.map((item) => {
                    const itemOos = isItemOutOfStock(item);
                    const atStockLimit = !canIncreaseQty(item);
                    return (
                      <div key={item.variant_id ?? item.id} style={{ display: "flex", gap: "12px", padding: "12px", background: "#fff", border: `1px solid ${itemOos ? "#FECACA" : "#E2E8F0"}`, borderRadius: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.04)", opacity: itemOos ? 0.7 : 1 }}>
                        <div style={{ width: "56px", height: "56px", background: "#F1F5F9", borderRadius: "10px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px", flexShrink: 0, overflow: "hidden", position: "relative" }}>
                          {item.image_url ? (
                            <img src={item.image_url} alt={item.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                          ) : (
                            "📦"
                          )}
                          {itemOos && (
                            <div style={{ position: "absolute", inset: 0, background: "rgba(239,68,68,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                              <span style={{ background: "#DC2626", color: "#fff", fontSize: "0.55rem", fontWeight: 700, padding: "2px 6px", borderRadius: 3 }}>{!isDeliverable ? "N/A" : "OUT"}</span>
                            </div>
                          )}
                        </div>

                        <div style={{ flex: 1, minWidth: 0 }}>
                          <h4 style={{ fontSize: "0.9rem", fontWeight: 700, color: "#1E293B", margin: "0 0 2px" }}>
                            {item.name}
                          </h4>
                          {(item.attributes || []).length > 0 && (
                            <p style={{ fontSize: "0.68rem", color: "#64748B", margin: "0 0 4px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                              {(item.attributes || []).map((a) => `${a.attribute_name}: ${a.value}`).join(" · ")}
                            </p>
                          )}
                          <p style={{ fontSize: "0.9rem", color: "var(--color-primary, #FF7132)", fontWeight: 700, margin: 0 }}>
                            ₹{Number(item.price || 0).toFixed(2)}
                          </p>
                          {itemOos ? (
                            <p style={{ fontSize: "0.7rem", color: "#EF4444", fontWeight: 600, margin: "4px 0 0" }}>
                              {!isDeliverable ? "Not deliverable to your location" : item.is_out_of_stock ? "Out of stock" : `Only ${item.available_stock} available`}
                            </p>
                          ) : item.available_stock !== null && item.available_stock !== undefined && item.available_stock <= 5 ? (
                            <p style={{ fontSize: "0.7rem", color: "#F59E0B", fontWeight: 600, margin: "4px 0 0" }}>
                              Only {item.available_stock} left
                            </p>
                          ) : null}
                        </div>

                        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", justifyContent: "space-between" }}>
                          <button
                            onClick={() => removeFromCart(item.variant_id ?? item.id)}
                            style={{ background: "none", border: "none", color: "#EF4444", cursor: "pointer", padding: 4 }}
                            title="Remove"
                          >
                            <Trash2 size={16} />
                          </button>
                          <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "#F1F5F9", borderRadius: "8px", padding: "4px 8px", opacity: itemOos ? 0.5 : 1 }}>
                            <button
                              onClick={() => handleUpdateQty(item.variant_id ?? item.id, -1)}
                              disabled={itemOos}
                              style={{ background: "none", border: "none", cursor: itemOos ? "not-allowed" : "pointer", padding: 2, display: "flex", opacity: itemOos ? 0.5 : 1 }}
                            >
                              <Minus size={14} color="#1E293B" />
                            </button>
                            <span style={{ fontSize: "0.9rem", fontWeight: 700, minWidth: 20, textAlign: "center" }}>
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleUpdateQty(item.variant_id ?? item.id, 1)}
                              disabled={itemOos || atStockLimit}
                              style={{ background: "none", border: "none", cursor: (itemOos || atStockLimit) ? "not-allowed" : "pointer", padding: 2, display: "flex", opacity: (itemOos || atStockLimit) ? 0.5 : 1 }}
                              title={atStockLimit ? `Only ${item.available_stock} in stock` : ""}
                            >
                              <Plus size={14} color={atStockLimit ? "#94A3B8" : "#1E293B"} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* ★ FREE GIFTS — earned gift lines under the cart items */}
              <CartGiftLines
                gifts={{
                  campaign: gifts.campaign,
                  earned: gifts.earnedLines,
                  progress: gifts.progress,
                }}
                mode="client"
              />

              {/* ★ Suggestions — loading skeleton (respects enabled + custom title) */}
              {suggestConfig.enabled !== false && suggestionsLoading && (
                <div style={{ marginTop: cartItems.length === 0 ? 12 : 20 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
                    <Sparkles size={14} color="var(--color-primary, #FF7132)" />
                    <span style={{ fontSize: "0.8rem", fontWeight: 800, color: "#1E293B", textTransform: "uppercase", letterSpacing: "0.03em" }}>
                      {stripTitle}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: 10 }}>
                    {[0, 1, 2, 3].map((i) => (
                      <motion.div
                        key={i}
                        animate={{ opacity: [0.4, 0.85, 0.4] }}
                        transition={{ repeat: Infinity, duration: 1.2, delay: i * 0.15 }}
                                                style={{ flex: "0 0 170px", height: 250, background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12 }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* ★ Suggestions — cards (manual picks first in admin order, then fill) */}
              {suggestConfig.enabled !== false && !suggestionsLoading && visibleSuggestions.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} style={{ marginTop: cartItems.length === 0 ? 12 : 20 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
                    <Sparkles size={14} color="var(--color-primary, #FF7132)" />
                    <span style={{ fontSize: "0.8rem", fontWeight: 800, color: "#1E293B", textTransform: "uppercase", letterSpacing: "0.03em" }}>
                      {stripTitle}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 6 }}>
                     {visibleSuggestions.map((s) => {
                      const tileOos = s.is_out_of_stock === true || !isDeliverable;
                      return (
                      <div
                        key={s.id}
                        onClick={() => { setIsCartOpen(false); navigate(`/products/${s.product_id}`); }}
                        style={{ flex: "0 0 170px", background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 10, display: "flex", flexDirection: "column", cursor: "pointer", opacity: tileOos ? 0.6 : 1 }}
                      >
                        <div style={{ position: "relative", width: "100%", height: 110, background: "#F1F5F9", borderRadius: 8, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26 }}>
                          {s.image_url ? (
                            <img src={s.image_url} alt={s.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                          ) : (
                            "📦"
                          )}
                          {s.discount_percent > 0 && !tileOos && (
                            <span style={{ position: "absolute", top: 5, left: 5, background: "#DC2626", color: "#fff", fontSize: "0.6rem", fontWeight: 700, padding: "2px 6px", borderRadius: 4 }}>
                              -{s.discount_percent}%
                            </span>
                          )}
                          {tileOos && (
                            <div style={{ position: "absolute", inset: 0, background: "rgba(255,255,255,0.78)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                              <span style={{ background: "#1E293B", color: "#fff", fontSize: "0.55rem", fontWeight: 800, padding: "3px 8px", borderRadius: 999 }}>
                                {!isDeliverable ? "NOT DELIVERABLE" : "OUT OF STOCK"}
                              </span>
                            </div>
                          )}
                        </div>
                        <p style={{ fontSize: "0.78rem", fontWeight: 700, color: "#1E293B", margin: "7px 0 1px", lineHeight: 1.25, minHeight: 34, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                          {s.name}
                        </p>
                        {(s.attr_summary || s.unit) && (
                          <p style={{ fontSize: "0.66rem", color: "#64748B", margin: 0, lineHeight: 1.35, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                            {s.attr_summary || s.unit}
                          </p>
                        )}
                        {inStockVariantsOf(s.product_id).length > 1 && (
                          <button onClick={(e) => { e.stopPropagation(); setPicking(s); }} style={{ display: "flex", alignItems: "center", gap: 3, marginTop: 2, background: "none", border: "none", padding: 0, cursor: "pointer", fontSize: "0.64rem", fontWeight: 700, color: "var(--color-primary, #FF7132)" }}>
                            {inStockVariantsOf(s.product_id).length} variants <span style={{ fontSize: "0.55rem" }}>▾</span>
                          </button>
                        )}
                        {s.available_stock !== null && s.available_stock !== undefined && s.available_stock <= 5 && !tileOos && (
                          <p style={{ fontSize: "0.62rem", color: "#F59E0B", fontWeight: 600, margin: "2px 0 0" }}>
                            Only {s.available_stock} left
                          </p>
                        )}
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "auto", paddingTop: 7, gap: 6 }}>
                          <div style={{ minWidth: 0 }}>
                            <span style={{ fontSize: "0.85rem", fontWeight: 800, color: "var(--color-primary, #FF7132)", display: "block", lineHeight: 1.15 }}>
                              ₹{Number(s.price || 0).toFixed(2)}
                            </span>
                            {s.show_mrp && (
                              <span style={{ fontSize: "0.64rem", color: "#94A3B8", textDecoration: "line-through", display: "block", lineHeight: 1.15 }}>
                                ₹{Number(s.mrp || 0).toFixed(2)}
                              </span>
                            )}
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleAddSuggestion(s); }}
                            disabled={tileOos}
                            title={tileOos ? (!isDeliverable ? "Not deliverable to your location" : "Out of stock") : "Add to cart"}
                            style={{ width: 32, height: 32, borderRadius: 9, background: tileOos ? "#CBD5E1" : "var(--color-primary, #FF7132)", color: "#fff", border: "none", cursor: tileOos ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: tileOos ? "none" : "0 2px 8px rgba(255,113,50,0.3)", flexShrink: 0 }}
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                      );
                    })} 
                  </div>
                </motion.div>
              )}
            </div>

            {/* Footer */}
            {cartItems.length > 0 && (
              <div style={{ padding: "20px", borderTop: "1px solid #E2E8F0", background: "#fff" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "16px", fontSize: "1.2rem", fontWeight: 800, color: "#1E293B" }}>
                  <span>Total ({cartCount} items)</span>
                  <span style={{ color: "var(--color-primary, #FF7132)" }}>
                    ₹{Number(cartTotal || 0).toFixed(2)}
                  </span>
                </div>
                <button
                  onClick={handleCheckout}
                  disabled={blockCheckout}
                  style={{
                    width: "100%",
                    padding: "16px",
                    background: blockCheckout ? "#94A3B8" : "var(--color-primary, #FF7132)",
                    color: "#fff",
                    border: "none",
                    borderRadius: "12px",
                    fontSize: "1rem",
                    fontWeight: 700,
                    cursor: blockCheckout ? "not-allowed" : "pointer",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "8px",
                    boxShadow: blockCheckout ? "none" : "0 4px 12px rgba(255,113,50,0.3)",
                  }}
                >
                  {!isDeliverable ? "Set a deliverable location" : outOfStockCount > 0 ? "Remove out-of-stock items" : "Proceed to Checkout"}
                  {blockCheckout ? null : <ArrowRight size={18} />}
                </button>
              </div>
            )}
          </motion.div>
          {/* ★ Variant picker for multi-variant suggestions */}
          {picking && (
            <div onClick={() => setPicking(null)} style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", zIndex: 10002, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
              <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 16, width: "100%", maxWidth: 380, maxHeight: "80vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
                <div style={{ padding: "16px 20px 12px", borderBottom: "1px solid #E2E8F0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "0.68rem", fontWeight: 800, color: "#64748B", textTransform: "uppercase", letterSpacing: "0.05em" }}>Choose Variant</div>
                    <div style={{ fontSize: "0.95rem", fontWeight: 800, color: "#1E293B", marginTop: 2 }}>{picking.name}</div>
                  </div>
                  <button onClick={() => setPicking(null)} style={{ background: "#F1F5F9", border: "none", borderRadius: 8, cursor: "pointer", color: "#64748B", padding: 6, display: "flex" }}>
                    <X size={16} />
                  </button>
                </div>
                <div style={{ overflowY: "auto", padding: 12 }}>
                  {variantPool.filter((v) => v.product_id === picking.product_id).map((v) => {
                    const vOos = v.is_out_of_stock === true;
                    const isCurrent = v.id === picking.id;
                    return (
                      <button key={v.id} disabled={vOos} onClick={() => addPickedVariant(v)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: 10, marginBottom: 6, background: isCurrent ? "#FFF7ED" : "#fff", border: `1px solid ${isCurrent ? "var(--color-primary, #FF7132)" : "#E2E8F0"}`, borderRadius: 10, cursor: vOos ? "not-allowed" : "pointer", opacity: vOos ? 0.55 : 1, textAlign: "left" }}>
                        <div style={{ width: 44, height: 44, borderRadius: 8, overflow: "hidden", background: "#F1F5F9", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                          {v.image_url ? <img src={v.image_url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : "📦"}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: "0.78rem", fontWeight: 700, color: "#1E293B", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {(v.attributes || []).length > 0 ? v.attributes.map((a) => `${a.attribute_name}: ${a.value}`).join(" · ") : v.unit || "Variant"}
                          </div>
                          <div style={{ fontSize: "0.72rem", marginTop: 2, display: "flex", alignItems: "center", gap: 6 }}>
                            <span style={{ fontWeight: 800, color: "var(--color-primary, #FF7132)" }}>₹{Number(v.price || 0).toFixed(0)}</span>
                            {v.show_mrp && <span style={{ color: "#94A3B8", textDecoration: "line-through", fontSize: "0.65rem" }}>₹{Number(v.mrp || 0).toFixed(0)}</span>}
                            {vOos ? <span style={{ color: "#EF4444", fontSize: "0.65rem", fontWeight: 700 }}>Out of stock</span>
                              : v.available_stock != null && v.available_stock <= 5 ? <span style={{ color: "#F59E0B", fontSize: "0.65rem", fontWeight: 700 }}>Only {v.available_stock} left</span>
                              : null}
                          </div>
                        </div>
                        {isCurrent && !vOos && <span style={{ fontSize: "0.62rem", fontWeight: 800, color: "var(--color-primary, #FF7132)", flexShrink: 0 }}>CURRENT</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
          {/* ★ FREE GIFTS — tier-unlock celebration toast */}
          <GiftToast toast={giftToast} onDismiss={() => setGiftToast(null)} />

          {/* Toast */}
          {toast && (
            <div style={{ position: "fixed", bottom: 24, right: 24, zIndex: 10001, background: toast.kind === "error" ? "#EF4444" : "#22C55E", color: "#fff", padding: "12px 20px", borderRadius: 10, boxShadow: "0 10px 30px rgba(0,0,0,0.3)", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: 8 }}>
              <AlertCircle size={16} />
              {toast.msg}
            </div>
          )}
        </>
      )}
    </AnimatePresence>
  );
}