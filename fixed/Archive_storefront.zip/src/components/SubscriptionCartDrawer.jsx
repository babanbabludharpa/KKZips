import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Plus, Minus, Trash2, X, Repeat2, ShoppingBag } from "lucide-react";
import { useSubscription } from "../pages/SubscriptionContext";

const theme = { primary: "#FF7132", dark: "#1E293B", mid: "#64748B", border: "#E2E8F0" };
const qtyBtn = { width: 28, height: 28, borderRadius: 8, border: `1px solid ${theme.border}`, background: "#fff", color: theme.dark, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" };

export default function SubscriptionCartDrawer({ open, onClose }) {
  const navigate = useNavigate();
  const { items, updateQty, remove, clear, total } = useSubscription();

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}
            style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,.45)", zIndex: 1100 }} />
          <motion.aside initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} transition={{ duration: .25 }}
            style={{ position: "fixed", top: 0, left: 0, bottom: 0, width: "min(92vw, 380px)", background: "#fff", zIndex: 1200, display: "flex", flexDirection: "column", boxShadow: "8px 0 40px rgba(0,0,0,.15)" }}>

            {/* header */}
            <div style={{ padding: "16px 18px", borderBottom: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 10 }}>
              <ShoppingBag size={20} style={{ color: theme.primary }} />
              <div style={{ flex: 1, fontWeight: 800, color: theme.dark }}>Subscription basket</div>
              {items.length > 0 && <button onClick={clear} style={{ background: "none", border: "none", color: "#EF4444", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>Clear all</button>}
              <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: theme.mid, display: "flex" }}><X size={20} /></button>
            </div>

            {items.length === 0 ? (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, padding: 24, textAlign: "center" }}>
                <Repeat2 size={36} style={{ color: theme.border }} />
                <div style={{ fontWeight: 700, color: theme.dark }}>No items yet</div>
                <div style={{ fontSize: 13, color: theme.mid }}>Tap "Add to subscription" on any product.</div>
                <button onClick={() => { onClose(); navigate("/subscription"); }} style={{ marginTop: 8, padding: "10px 16px", borderRadius: 999, border: `1px solid ${theme.border}`, background: "#fff", color: theme.dark, fontWeight: 700, cursor: "pointer" }}>View My Subscriptions</button>
              </div>
            ) : (
              <div style={{ flex: 1, overflowY: "auto" }}>
                {items.map(it => {
                  const k = String(it.variant_id ?? it.id);
                  return (
                    <div key={k} style={{ display: "flex", gap: 12, padding: "14px 18px", borderBottom: `1px solid ${theme.border}` }}>
                      <img src={it.image_url} alt="" style={{ width: 56, height: 56, borderRadius: 12, objectFit: "cover", background: "#F1F5F9" }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontWeight: 700, fontSize: 14, color: theme.dark, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.name}</div>
                        <div style={{ fontSize: 12, color: theme.mid, margin: "2px 0 8px" }}>₹{Number(it.price).toFixed(2)} / {it.unit || "unit"}</div>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <button onClick={() => updateQty(k, -1)} style={qtyBtn}><Minus size={14} /></button>
                          <span style={{ fontWeight: 800, minWidth: 20, textAlign: "center", color: theme.dark }}>{it.quantity || 1}</span>
                          <button onClick={() => updateQty(k, +1)} style={qtyBtn}><Plus size={14} /></button>
                        </div>
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", justifyContent: "space-between" }}>
                        <button onClick={() => remove(k)} style={{ background: "none", border: "none", color: "#EF4444", cursor: "pointer", display: "flex" }}><Trash2 size={16} /></button>
                        <div style={{ fontWeight: 800, color: theme.primary }}>₹{(Number(it.price) * Number(it.quantity || 1)).toFixed(2)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {items.length > 0 && (
              <div style={{ borderTop: `1px solid ${theme.border}`, padding: 16, display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: theme.mid }}>
                  <span>Per delivery</span><span style={{ fontWeight: 800, color: theme.dark, fontSize: 16 }}>₹{total.toFixed(2)}</span>
                </div>
                <button onClick={() => { onClose(); navigate("/subscription/new"); }}
                  style={{ width: "100%", padding: 13, border: "none", borderRadius: 12, background: theme.primary, color: "#fff", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>
                  Create Subscription
                </button>
                <button onClick={() => { onClose(); navigate("/subscription"); }}
                  style={{ width: "100%", padding: 11, border: `1px solid ${theme.border}`, borderRadius: 12, background: "#fff", color: theme.dark, fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  <Repeat2 size={15} /> View My Subscriptions
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}