import { Link } from "react-router-dom";
import { ShieldCheck, Smartphone } from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";

// ─────────────────────────────────────────────────────────────────────────
// Footer.jsx — 2-Column Layout (Branding Left, Links Right)
// ─────────────────────────────────────────────────────────────────────────

const SOCIAL_EMOJI = {
  facebook:  "f",
  instagram: "📷",
  youtube:   "▶",
  whatsapp:  "💬",
  twitter:   "𝕏",
  linkedin:  "in",
  telegram:  "✈",
};

function fixMediaUrl(url) {
  if (!url) return null;
  if (url.startsWith("http") || url.startsWith("data:") || url.startsWith("blob:")) return url;
  const backendUrl = import.meta.env.VITE_API_URL || import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";
  return backendUrl + (url.startsWith("/") ? url : "/" + url);
}

function hexToRgba(hex, opacity) {
  if (!hex || typeof hex !== "string") return `rgba(30, 41, 59, ${opacity})`;
  let s = hex.trim().replace("#", "");
  if (s.length === 3) s = s.split("").map((c) => c + c).join("");
  if (s.length !== 6) return `rgba(30, 41, 59, ${opacity})`;
  const r = parseInt(s.slice(0, 2), 16);
  const g = parseInt(s.slice(2, 4), 16);
  const b = parseInt(s.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

export default function Footer() {
  const { footerConfig, theme } = useTenant() || {};
  const config = footerConfig || {};
  
  if (config.enabled === false) return null;

  // Theme & Config values
  const primary = theme?.primary_color || "#666666";
  const logoUrl = theme?.logo_url;
  const brandName = theme?.brand_name || "";
  const tagline = "Your trusted daily delivery partner.";

  const bgType = config.bg_type || "color";
  const overlayOpacity = typeof config.bg_overlay === "number" ? config.bg_overlay : 0.75;
  const overlayColor = config.bg_color || "#1E293B";
  const overlayRgba = hexToRgba(overlayColor, overlayOpacity);

  const headingColor = config.heading_color || "#FFFFFF";
  const textColor = config.text_color || "#94A3B8";
  const linkHoverColor = config.link_hover_color || primary;
  const copyrightColor = config.copyright_color || textColor;
  const borderColor = config.border_color || "rgba(255,255,255,0.15)";
  const headingTransform = config.heading_text_transform || "uppercase";

  const socialBg = config.social_bg_color || "rgba(255,255,255,0.1)";
  const socialHoverBg = config.social_hover_bg_color || primary;
  const socialIconColor = config.social_icon_color || "#FFFFFF";

  // Filter out col1 so we don't duplicate the brand block
  const linkColumns = (config.columns || []).filter(col => col.id !== 'col1');

  const onLinkEnter = (e) => { e.currentTarget.style.color = linkHoverColor; };
  const onLinkLeave = (e) => { e.currentTarget.style.color = textColor; };

  return (
    <footer style={{ position: "relative", overflow: "hidden", color: textColor, background: bgType === "color" ? overlayColor : "#0f172a" }}>
      
      {/* ═══ MEDIA BACKGROUND LAYER ═══════════════════════════════════ */}
      {bgType === "image" && config.bg_image_url && (
        <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>
          <img src={fixMediaUrl(config.bg_image_url)} alt="" style={{ width: "100%", height: "100%", objectFit: config.bg_object_fit || "cover" }} onError={(e) => { e.target.style.display = "none"; }} />
        </div>
      )}

      {bgType === "video" && config.bg_video_url && (
        <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>
          <video src={fixMediaUrl(config.bg_video_url)} poster={fixMediaUrl(config.bg_video_poster) || undefined} autoPlay muted={config.bg_video_mute !== false} loop={config.bg_video_loop !== false} playsInline style={{ width: "100%", height: "100%", objectFit: config.bg_object_fit || "cover" }} onError={(e) => { e.target.style.display = "none"; }} />
        </div>
      )}

      {bgType !== "color" && (
        <div style={{ position: "absolute", inset: 0, zIndex: 1, background: overlayRgba }} />
      )}

      {/* ═══ FOOTER CONTENT ════════════════════════════════════════════ */}
      <div style={{ position: "relative", zIndex: 2, maxWidth: 1350, margin: "0 auto", padding: "60px 24px 24px 8px"}}>
        
        {/* ★ Main 2-Column Layout: Branding on Left, Links on Right */}
        <div style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "60px",
          marginBottom: "40px"
        }}>

          {/* ── BRAND BLOCK (Left Side) ── */}
          <div style={{ flex: "1 1 250px", maxWidth: "300px" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "12px", marginBottom: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                {logoUrl && (
                  <img 
                    src={fixMediaUrl(logoUrl)} 
                    alt={brandName || "Logo"} 
                    // ★ Made logo bigger (90px height)
                    style={{ height: "90px", maxHeight: "90px", width: "auto", maxWidth: "180px", objectFit: "contain" }} 
                  />
                )}
                {brandName && (
                  <span style={{ color: headingColor, fontSize: "1.4rem", fontWeight: 800, letterSpacing: "-0.02em", lineHeight: 1.2 }}>
                    {brandName}
                  </span>
                )}
              </div>
              <p style={{ color: textColor, fontSize: "0.9rem", margin: 0, lineHeight: 1.6, textAlign: "center" }}>
                {tagline}
              </p>
            </div>
          </div>

          {/* ── LINKS CONTAINER (Right Side) ── 
              Groups all link columns tightly together so they don't fall below the branding */}
          <div style={{ 
            flex: "2 1 500px", 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", 
            gap: "30px" // ★ Reduced gap to bring links closer
          }}>
            
            {linkColumns.map((col) => (
              <div key={col.id} style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
                <h4 style={{ color: headingColor, fontSize: "0.95rem", fontWeight: 700, marginBottom: "16px", textTransform: headingTransform, letterSpacing: "0.05em" }}>
                  {col.title}
                </h4>

                {col.type === "text" && (
                  <p style={{ fontSize: "0.875rem", lineHeight: 1.6, margin: 0, color: textColor }}>{col.content}</p>
                )}

                {col.type === "links" && (
                  <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "8px" // ★ Reduced gap between links
                  }}>
                    {col.links?.map((link, i) => {
                      const isExternal = link.url?.startsWith("http");
                      return isExternal ? (
                        <li key={i}><a href={link.url} target="_blank" rel="noopener noreferrer" style={{ color: textColor, textDecoration: "none", fontSize: "0.875rem", transition: "color 0.2s" }} onMouseEnter={onLinkEnter} onMouseLeave={onLinkLeave}>{link.label}</a></li>
                      ) : (
                        <li key={i}><Link to={link.url} style={{ color: textColor, textDecoration: "none", fontSize: "0.875rem", transition: "color 0.2s" }} onMouseEnter={onLinkEnter} onMouseLeave={onLinkLeave}>{link.label}</Link></li>
                      );
                    })}
                  </ul>
                )}

                {col.type === "social" && (
                  <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
                    {col.social?.map((s, i) => {
                      const emoji = SOCIAL_EMOJI[s.platform] || s.platform?.charAt(0)?.toUpperCase() || "•";
                      return (
                        <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" title={s.platform} style={{ width: 36, height: 36, borderRadius: "50%", background: socialBg, display: "flex", alignItems: "center", justifyContent: "center", color: socialIconColor, fontSize: "1rem", fontWeight: 700, textDecoration: "none", transition: "background 0.2s, transform 0.2s" }} onMouseEnter={(e) => { e.currentTarget.style.background = socialHoverBg; e.currentTarget.style.transform = "translateY(-2px)"; }} onMouseLeave={(e) => { e.currentTarget.style.background = socialBg; e.currentTarget.style.transform = "translateY(0)"; }}>
                          {emoji}
                        </a>
                      );
                    })}
                  </div>
                )}

                {col.type === "newsletter" && (
                  <div style={{ width: "100%" }}>
                    <p style={{ fontSize: "0.85rem", marginBottom: 12, color: textColor }}>{col.content || "Subscribe to our newsletter"}</p>
                    <div style={{ display: "flex", gap: "8px" }}>
                      <input type="email" placeholder={col.placeholder || "Enter email"} style={{ flex: 1, maxWidth: 200, padding: "10px 12px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.2)", background: "rgba(255,255,255,0.05)", color: "#fff", fontSize: "0.85rem", outline: "none" }} />
                      <button style={{ padding: "10px 16px", borderRadius: 8, border: "none", background: primary, color: "#fff", fontWeight: 600, cursor: "pointer", fontSize: "0.85rem", whiteSpace: "nowrap" }}>Subscribe</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── BOTTOM BAR ── */}
        <div style={{ borderTop: `1px solid ${borderColor}`, paddingTop: "24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px" }}>
          <p style={{ fontSize: "0.82rem", margin: 0, color: copyrightColor }}>{config.copyright}</p>
          <div style={{ display: "flex", alignItems: "center", gap: "16px", flexWrap: "wrap" }}>
            {config.show_payment_badges && (
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span style={{ fontSize: "0.7rem", fontWeight: 600, padding: "4px 8px", background: "rgba(255,255,255,0.15)", borderRadius: 4, color: "#fff" }}>UPI</span>
                <span style={{ fontSize: "0.7rem", fontWeight: 600, padding: "4px 8px", background: "rgba(255,255,255,0.15)", borderRadius: 4, color: "#fff" }}>VISA</span>
                <span style={{ fontSize: "0.7rem", fontWeight: 600, padding: "4px 8px", background: "rgba(255,255,255,0.15)", borderRadius: 4, color: "#fff" }}>Razorpay</span>
                <ShieldCheck size={14} style={{ opacity: 0.6, color: "#fff" }} />
              </div>
            )}
            {config.show_app_links && (
              <div style={{ display: "flex", gap: "8px" }}>
                <a href="#" style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", background: "rgba(255,255,255,0.15)", borderRadius: 8, color: "#fff", textDecoration: "none", fontSize: "0.75rem", fontWeight: 600 }}>App Store</a>
                <a href="#" style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", background: "rgba(255,255,255,0.15)", borderRadius: 8, color: "#fff", textDecoration: "none", fontSize: "0.75rem", fontWeight: 600 }}><Smartphone size={14} /> Play Store</a>
              </div>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}