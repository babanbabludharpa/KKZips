import { useState, useEffect, useRef } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ChevronDown } from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
// ★ Uses the same store LoginModal writes to
import { useCustomerAuth } from "../store/useCustomerAuth";
import LoginModal from "./LoginModal";
import RegisterModal from "./RegisterModal";

// ─────────────────────────────────────────────────────────────────────────
// Navbar.jsx — STEP 3: Navigation Customization
//
// Reads nav links from TenantProvider.navigationConfig.
// Admin can: reorder, rename, hide/show, add custom links.
//
// Defaults are used if navigationConfig is null (backward compatible).
// ─────────────────────────────────────────────────────────────────────────

const DEFAULT_NAV_LINKS = [
  { id: "home", label: "Home", url: "/", visible: true, order: 1 },
  { id: "about", label: "About Us", url: "/about", visible: true, order: 2 },
  { id: "products", label: "Products", url: "/products", visible: true, order: 3 },
  { id: "subscription", label: "Subscriptions", url: "/subscription", visible: true, order: 4 },
  { id: "contact", label: "Contact", url: "/contact", visible: true, order: 5 },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);
  const navigate = useNavigate();

  const { theme, navigationConfig } = useTenant();
  const { isAuthenticated, customer, logout } = useCustomerAuth();

  // ★ Read nav links from config (fallback to defaults)
  const navLinks = (navigationConfig?.links || DEFAULT_NAV_LINKS)
    .filter((link) => link.visible !== false)
    .sort((a, b) => (a.order || 0) - (b.order || 0));

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const onClick = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const handleLogout = async () => {
    await logout();
    setProfileOpen(false);
    setOpen(false);
    navigate("/");
  };
  

  const initial =
    (customer?.name && customer.name.trim().charAt(0).toUpperCase()) || "U";
  const firstName = customer?.name?.split(" ")[0] || "Account";

  const activeStyle = ({ isActive }) => ({
    color: isActive ? "var(--color-primary)" : "#fff",
    fontWeight: isActive ? "700" : "500",
    background: isActive ? "rgba(255, 255, 255, 0.68)" : "transparent",
    borderRadius: "8px",
  });
  
  const profileMenuItems = [
    { to: "/profile", label: "My Profile" },
    { to: "/subscription", label: "My Subscriptions" },
    { to: "/wallet", label: "My Wallet" }, 
    { to: "/addresses", label: "Addresses" },
    // ★ NEW
  ];

  return (
    <>
      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 50,
          // ★ Changed from solid color to a 135-degree gradient
          background: "linear-gradient(150deg, var(--color-primary), var(--color-secondary))",
          borderBottom: scrolled ? "1px solid rgba(255,255,255,0.1)" : "1px solid transparent",
          boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.2)" : "none",
          transition: "all 0.3s ease",
        }}
      >
          <nav style={{ maxWidth: "1280px", margin: "0 auto", padding: "3px 24px 3px 0.2px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: "80px" }}>

{/* ── LOGO + BRAND (Horizontal, Left-Aligned, Wraps if long) ── */}
<NavLink to="/" style={{ 
  display: "flex", 
  flexDirection: "row", 
  alignItems: "center", 
  justifyContent: "flex-start",
  textDecoration: "none", 
  height: "100%", 
  flexShrink: 0,
  gap: "10px", // Space between logo and text
  maxWidth: "260px" // Limits width so it doesn't push the menu off-screen
}}>
  {theme.logo_url && (
    <img 
      src={theme.logo_url} 
      alt="Logo" 
      style={{ 
        height: "90px", 
        maxHeight: "90px",
        width: "auto",
        maxWidth: "150px", 
        objectFit: "contain", 
      }} 
    />
  )}
  {theme.brand_name && (
    <span style={{ 
      color: "#fff", 
      fontSize: "1.1rem", 
      fontWeight: "800", 
      letterSpacing: "-0.02em",
      textAlign: "left", 
      lineHeight: "1.2",
      whiteSpace: "normal" // ★ Allows the text to wrap to the next line if it's long
    }}>
      {theme.brand_name}
    </span>
  )}
</NavLink>

            {/* ── DESKTOP NAV (dynamic links) ── */}
            {/* ★ marginLeft: auto pushes the menu to the far right, preventing overlap */}
            <div className="desktop-nav" style={{ marginLeft: "auto" }}>
              {navLinks.map((link) => {
                // Check if it's an external link
                const isExternal = link.url?.startsWith("http");
                if (isExternal) {
                  return (
                    <a
                      key={link.id}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="nav-link"
                      style={{ padding: "8px 14px", borderRadius: "8px", textDecoration: "none", color: "#fff", fontWeight: 500 }}
                    >
                      {link.label}
                    </a>
                  );
                }
                return (
                  <NavLink
                    key={link.id}
                    to={link.url}
                    end={link.url === "/"}
                    style={activeStyle}
                    className="nav-link"
                  >
                    {link.label}
                  </NavLink>
                );
              })}
              <div style={{ width: "1px", height: "24px", background: "rgba(255,255,255,0.2)", margin: "0 8px" }} />

              {/* Auth area */}
              {!isAuthenticated ? (
                <>
                  <button onClick={() => setIsLoginOpen(true)} className="btn-outline-nav">Log In</button>
                  <button onClick={() => setIsRegisterOpen(true)} className="btn-primary-nav">Get Started</button>
                </>
              ) : (
                <>
                  <div ref={profileRef} style={{ position: "relative" }}>
                    <button onClick={() => setProfileOpen((o) => !o)} className="btn-profile-nav" aria-label="Account menu">
                      <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 30, height: 30, borderRadius: "50%", background: "var(--color-primary)", color: "#fff", fontWeight: 700, fontSize: "0.85rem" }}>{initial}</span>
                      <span style={{ maxWidth: 100, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", fontSize: "0.9rem", fontWeight: 600 }}>{firstName}</span>
                      <ChevronDown size={14} style={{ opacity: 0.7 }} />
                    </button>
                    <AnimatePresence>
                      {profileOpen && (
                        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }} role="menu" className="profile-dropdown">
                          <div className="profile-dropdown-header">
                            <div style={{ fontWeight: 600, fontSize: "0.92rem", color: "#111" }}>{customer?.name || "My Account"}</div>
                            {customer?.email && <div style={{ fontSize: "0.78rem", color: "#6b7280", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>{customer.email}</div>}
                          </div>
                          {profileMenuItems.map((item) => (
                            <NavLink key={item.to} to={item.to} onClick={() => setProfileOpen(false)} className="profile-dropdown-item">{item.label}</NavLink>
                          ))}
                          <div style={{ height: 1, background: "#f1f1f1", margin: "0.3rem 0" }} />
                          <button onClick={handleLogout} className="profile-dropdown-logout">Logout</button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <button onClick={handleLogout} className="btn-outline-nav" aria-label="Logout">Logout</button>
                </>
              )}
            </div>

            {/* ── MOBILE HAMBURGER ── */}
            <button onClick={() => setOpen(!open)} className="hamburger-btn" aria-label="Toggle menu">
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>

          {/* ── MOBILE MENU ── */}
          <AnimatePresence>
            {open && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.22, ease: "easeInOut" }} style={{ overflow: "hidden", borderTop: "1px solid rgba(255,255,255,0.1)" }}>
                <div style={{ padding: "16px 0 20px", display: "flex", flexDirection: "column", gap: "4px" }}>
                  {navLinks.map((link) => {
                    const isExternal = link.url?.startsWith("http");
                    if (isExternal) {
                      return (
                        <a key={link.id} href={link.url} target="_blank" rel="noopener noreferrer" style={{ padding: "10px 12px", borderRadius: "10px", color: "#fff", fontWeight: 500, textDecoration: "none", fontSize: "0.95rem" }} onClick={() => setOpen(false)}>{link.label}</a>
                      );
                    }
                    return (
                      <NavLink key={link.id} to={link.url} end={link.url === "/"} style={({ isActive }) => ({ padding: "10px 12px", borderRadius: "10px", color: isActive ? "var(--color-primary)" : "#fff", fontWeight: isActive ? "600" : "500", textDecoration: "none", fontSize: "0.95rem" })} onClick={() => setOpen(false)}>{link.label}</NavLink>
                    );
                  })}
                  {!isAuthenticated ? (
                    <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                      <button onClick={() => { setOpen(false); setIsLoginOpen(true); }} className="btn-mobile-outline">Log In</button>
                      <button onClick={() => { setOpen(false); setIsRegisterOpen(true); }} className="btn-mobile-primary">Get Started</button>
                    </div>
                  ) : (
                    <>
                      <div style={{ padding: "12px", margin: "12px 0 4px", borderRadius: "12px", background: "rgba(255,255,255,0.08)", display: "flex", alignItems: "center", gap: "10px" }}>
                        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 36, height: 36, borderRadius: "50%", background: "var(--color-primary)", color: "#fff", fontWeight: 700 }}>{initial}</span>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ color: "#fff", fontWeight: 600, fontSize: "0.92rem" }}>{customer?.name || "My Account"}</div>
                          {customer?.email && <div style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.78rem", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{customer.email}</div>}
                        </div>
                      </div>
                      {profileMenuItems.map((item) => (
                        <NavLink key={item.to} to={item.to} onClick={() => setOpen(false)} style={({ isActive }) => ({ padding: "10px 12px", borderRadius: "10px", color: isActive ? "var(--color-primary)" : "#fff", fontWeight: isActive ? "600" : "500", textDecoration: "none", fontSize: "0.95rem" })}>{item.label}</NavLink>
                      ))}
                      <button onClick={handleLogout} className="btn-mobile-outline" style={{ marginTop: "12px", borderColor: "rgba(255,100,100,0.5)", color: "#ff8888" }}>Logout</button>
                    </>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </nav>

        <style>{`
          .desktop-nav { display: none; align-items: center; gap: 8px; }
          @media (min-width: 768px) { .desktop-nav { display: flex !important; } }
          .hamburger-btn { display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); background: transparent; cursor: pointer; color: #fff; }
          @media (min-width: 768px) { .hamburger-btn { display: none !important; } }
          .nav-link { padding: 8px 14px; border-radius: 8px; text-decoration: none; color: #fff; font-weight: 500; }
          .nav-link:hover { background: rgba(255,255,255,0.1); }
          .btn-outline-nav { padding: 10px 40px; border-radius: var(--button-radius, 12px); border: 1.5px solid var(--color-primary); background: transparent; color: var(--color-primary); font-size: 0.95rem; font-weight: 600; cursor: pointer; transition: all 0.2s; }
          .btn-outline-nav:hover { background: var(--color-primary); color: #fff; }
          .btn-primary-nav { padding: var(--button-padding-y, 10px) var(--button-padding-x, 22px); border-radius: var(--button-radius, 12px); background: var(--color-primary); color: #fff; border: none; font-size: 0.95rem; font-weight: 700; cursor: pointer; transition: all 0.2s; }
          .btn-primary-nav:hover { opacity: 0.9; }
          .btn-mobile-outline { flex: 1; padding: 12px; border-radius: 12px; border: 1.5px solid rgba(255,255,255,0.3); background: transparent; color: #fff; font-weight: 700; cursor: pointer; }
          .btn-mobile-primary { flex: 1; padding: 12px; border-radius: 12px; background: var(--color-primary); color: #fff; border: none; font-weight: 700; cursor: pointer; }
          .btn-profile-nav { display: flex; align-items: center; gap: 0.45rem; background: transparent; border: 1px solid rgba(255,255,255,0.2); border-radius: 999px; padding: 0.3rem 0.7rem 0.3rem 0.3rem; cursor: pointer; color: #fff; transition: background 0.2s; }
          .btn-profile-nav:hover { background: rgba(255,255,255,0.1); }
          .profile-dropdown { position: absolute; right: 0; top: calc(100% + 0.5rem); min-width: 220px; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.18); padding: 0.4rem; z-index: 60; }
          .profile-dropdown-header { padding: 0.6rem 0.8rem; border-bottom: 1px solid #f1f1f1; margin-bottom: 0.3rem; }
          .profile-dropdown-item { display: block; padding: 0.55rem 0.8rem; border-radius: 8px; text-decoration: none; color: #374151; font-size: 0.9rem; font-weight: 500; transition: background 0.15s; }
          .profile-dropdown-item:hover { background: #f3f4f6; }
          .profile-dropdown-logout { width: 100%; text-align: left; padding: 0.55rem 0.8rem; border-radius: 8px; background: transparent; border: none; color: #dc2626; font-size: 0.9rem; font-weight: 600; cursor: pointer; transition: background 0.15s; }
          .profile-dropdown-logout:hover { background: #fee2e2; }
        `}</style>
      </header>

      {isLoginOpen && (
        <LoginModal onClose={() => setIsLoginOpen(false)} onSwitchToRegister={() => { setIsLoginOpen(false); setIsRegisterOpen(true); }} />
      )}
      {isRegisterOpen && (
        <RegisterModal onClose={() => setIsRegisterOpen(false)} onSwitchToLogin={() => { setIsRegisterOpen(false); setIsLoginOpen(true); }} />
      )}
    </>
  );
}
