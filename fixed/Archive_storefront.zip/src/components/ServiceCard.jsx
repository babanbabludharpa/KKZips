import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function ServiceCard({
  icon: Icon,
  title,
  description,
  tags = [],
  delay = 0,
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      style={{
        background: "#fff",
        borderRadius: "16px",
        padding: "28px",
        border: "1px solid var(--color-border)",
        boxShadow: "var(--shadow-card)",
        display: "flex",
        flexDirection: "column",
        gap: "16px",
        cursor: "default",
        transition: "all 0.3s ease",
        position: "relative",
        overflow: "hidden",
      }}
      whileHover={{
        y: -4,
        borderColor: "var(--color-primary)",
        boxShadow: "0 16px 40px rgba(37,99,235,0.12)",
      }}
    >
      {/* Top accent bar */}
      <motion.div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: "3px",
          background:
            "linear-gradient(90deg, var(--color-primary), var(--color-primary-light))",
          transformOrigin: "left",
          scaleX: 0,
        }}
        whileHover={{ scaleX: 1 }}
        transition={{ duration: 0.3 }}
      />

      <div
        style={{
          width: "48px",
          height: "48px",
          borderRadius: "12px",
          background:
            "linear-gradient(135deg, rgba(37,99,235,0.08), rgba(79,125,255,0.04))",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon size={22} color="var(--color-primary)" />
      </div>

      <div>
        <h3
          style={{
            fontSize: "1rem",
            fontWeight: "700",
            color: "var(--color-dark)",
            marginBottom: "8px",
          }}
        >
          {title}
        </h3>
        <p
          style={{
            color: "var(--color-mid)",
            fontSize: "0.88rem",
            lineHeight: "1.65",
          }}
        >
          {description}
        </p>
      </div>

      {tags.length > 0 && (
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "6px",
            marginTop: "auto",
          }}
        >
          {tags.map((t) => (
            <span
              key={t}
              style={{
                padding: "3px 10px",
                borderRadius: "20px",
                background: "rgba(37,99,235,0.08)",
                color: "var(--color-primary)",
                fontSize: "0.75rem",
                fontWeight: "600",
              }}
            >
              {t}
            </span>
          ))}
        </div>
      )}

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "6px",
          color: "var(--color-primary)",
          fontSize: "0.85rem",
          fontWeight: "600",
          marginTop: "auto",
        }}
      >
        Learn more <ArrowRight size={14} />
      </div>
    </motion.div>
  );
}
