import { motion } from 'framer-motion'

export default function FeatureCard({ icon: Icon, title, description, delay = 0, accent = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -6, boxShadow: '0 20px 48px rgba(37,99,235,0.14)' }}
      style={{
        background: '#fff',
        borderRadius: '16px',
        padding: '32px',
        border: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-card)',
        cursor: 'default',
        transition: 'box-shadow 0.3s ease, transform 0.3s ease',
      }}
    >
      <div style={{
        width: '52px', height: '52px',
        borderRadius: '14px',
        background: accent
          ? 'linear-gradient(135deg, rgba(249,115,22,0.12), rgba(249,115,22,0.06))'
          : 'linear-gradient(135deg, rgba(37,99,235,0.12), rgba(79,125,255,0.05))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: '20px',
      }}>
        <Icon size={24} color={accent ? 'var(--color-accent)' : 'var(--color-primary)'} />
      </div>
      <h3 style={{ fontSize: '1.05rem', fontWeight: '700', color: 'var(--color-dark)', marginBottom: '10px' }}>
        {title}
      </h3>
      <p style={{ color: 'var(--color-mid)', fontSize: '0.9rem', lineHeight: '1.65' }}>
        {description}
      </p>
    </motion.div>
  )
}
