import { useTenant } from '../contexts/TenantProvider'

// ─────────────────────────────────────────────────────────────────────────
// DevTenantSwitcher
//
// Dev-only dropdown that lets you switch tenants at runtime without
// restarting Vite. Hidden in production builds (import.meta.env.PROD).
//
// Mount ONCE in App.jsx:
//   <DevTenantSwitcher />
//
// Why this exists:
// In production, the tenant is resolved from the subdomain
// (infosoft.platform.test → "infosoft"). In dev on `localhost:5174`
// there's no subdomain, so you need either:
//   A. Visit http://infosoft.localhost:5174 (recommended — mirrors prod)
//   B. Use this switcher to pick a tenant manually
// ─────────────────────────────────────────────────────────────────────────

const KNOWN_TENANTS = [
  'infosoft',
  'inforkart',
  // ★ Add your tenant domains here. To list them:
  //   php artisan tinker
  //   >>> \Stancl\Tenancy\Database\Models\Domain::pluck('domain')
]

export default function DevTenantSwitcher() {
  // Hidden in production builds
  if (import.meta.env.PROD) return null

  const { tenantId, setTenantId } = useTenant()

  const handleChange = (e) => {
    const value = e.target.value
    setTenantId(value || null)
    // Reload so all components + axios interceptor pick up the new tenant
    window.location.reload()
  }

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 16,
        right: 16,
        zIndex: 9999,
        background: '#fff',
        border: '1px solid #d1d5db',
        borderRadius: 10,
        padding: '8px 12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        fontSize: '0.82rem',
      }}
    >
      <label
        htmlFor="dev-tenant-select"
        style={{
          display: 'block',
          fontSize: '0.7rem',
          fontWeight: 700,
          color: '#6b7280',
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          marginBottom: 4,
        }}
      >
        🧪 Dev Tenant
      </label>
      <select
        id="dev-tenant-select"
        value={tenantId || ''}
        onChange={handleChange}
        style={{
          padding: '4px 8px',
          borderRadius: 6,
          border: '1px solid #d1d5db',
          background: '#fff',
          fontSize: '0.85rem',
          cursor: 'pointer',
          outline: 'none',
        }}
      >
        <option value="" disabled>
          Select tenant…
        </option>
        {KNOWN_TENANTS.map((t) => (
          <option key={t} value={t}>
            {t}
          </option>
        ))}
      </select>
      <div style={{ fontSize: '0.7rem', color: '#9ca3af', marginTop: 4 }}>
        Current: <strong>{tenantId || '(none)'}</strong>
      </div>
    </div>
  )
}
