/**
 * ★ FREE GIFTS — locked gift rows for the cart drawer & checkout (web).
 *
 * Renders what the current cart has earned, as LOCKED lines: quantity is
 * not editable, price is FREE, MRP is kept struck-through for delight.
 * They are NOT cart items — they are granted by the server when the
 * order is placed (never added to / removed from the client cart).
 *
 * Two modes:
 *
 *   mode="client"  (default) — cart drawer, before checkout.
 *     Pass the useGiftProgress() hook result; lines are display-only:
 *       <CartGiftLines gifts={{ campaign, earned: earnedLines, progress }} />
 *     A note reminds the shopper that eligibility is confirmed at checkout.
 *
 *   mode="preview" — checkout summary, from POST /mobile/orders/preview.
 *     Authoritative per serving branch; lines carry `available` /
 *     `available_stock`, and `ineligible_reason` may carry cap banners:
 *       <CartGiftLines gifts={preview.gifts} mode="preview" />
 *
 * Both gift shapes are normalized internally (client: name/sku; preview:
 * product_name/variant_sku).
 */

import React from 'react'
import { GiftIcon, LockIcon, PackageIcon } from './giftIcons'
import { formatINR } from '../../hooks/useGiftProgress'
import './gifts.css'

export default function CartGiftLines({ gifts, mode = 'client', className = '' }) {
  const campaign = gifts?.campaign ?? null
  const earned = gifts?.earned ?? []
  const reason = gifts?.ineligible_reason ?? null

  if (!campaign && !reason) return null
  if (!earned.length && !reason) return null

  let banner = null
  if (reason === 'campaign_limit_reached') {
    banner = 'This campaign’s free gifts are fully claimed.'
  } else if (reason === 'customer_limit_reached') {
    banner = 'You’ve already claimed your free gift in this campaign.'
  }

  return (
    <div className={`kg-root kg-lines ${className}`.trim()}>
      {earned.length > 0 && (
        <div className="kg-lines-head">
          <GiftIcon size={13} />
          <span>Free gifts · {earned.length}</span>
        </div>
      )}

      {banner && <div className="kg-banner"><GiftIcon size={14} /> {banner}</div>}

      {earned.map((line, i) => {
        // normalize client (name/sku) vs preview (product_name/variant_sku)
        const name = line.product_name ?? line.name ?? 'Free gift'
        const qty = line.quantity ?? 1
        const mrp = line.mrp ?? null
        const unit = line.unit_abbr ? ` ${line.unit_abbr}` : ''
        const fromTier = line.threshold_amount
          ? `unlocked at ${formatINR(line.threshold_amount)}`
          : null
        const unavailable = mode === 'preview' && line.available === false

        return (
          <div
            key={line.product_variant_id ?? i}
            className={`kg-line ${unavailable ? 'kg-line--unavailable' : ''}`.trim()}
            style={{ animationDelay: `${Math.min(i * 60, 240)}ms` }}
          >
            {line.image_url ? (
              <img className="kg-line-img" src={line.image_url} alt="" loading="lazy" />
            ) : (
              <span className="kg-line-img kg-line-ph">
                <PackageIcon size={18} />
              </span>
            )}

            <div className="kg-line-body">
              <div className="kg-line-name">
                <span>{name}</span>
                {unavailable && <span className="kg-line-na">out of stock here</span>}
              </div>
              <div className="kg-line-meta">
                {qty} {unit.trim()}
                {fromTier ? ` · ${fromTier}` : ''}
                {unavailable && mode === 'preview' && ' · will not be included in this order'}
              </div>
            </div>

            <div className="kg-line-right">
              {mrp != null && mrp > 0 && <span className="kg-line-mrp">{formatINR(mrp)}</span>}
              <span className="kg-pill">
                <GiftIcon size={10} /> FREE
              </span>
            </div>
          </div>
        )
      })}

      {mode === 'client' && earned.length > 0 && (
        <div className="kg-lines-note">
          <LockIcon size={12} />
          <span>Locked in — added automatically with your order. Final eligibility is confirmed at checkout.</span>
        </div>
      )}
    </div>
  )
}
