/**
 * ★ FREE GIFTS — "free gift unlocked" celebration toast (web storefront).
 *
 * Fired by the cart drawer when the cart value crosses a NEW tier
 * threshold (useGiftProgress → onTierCrossed). The gifts are not really
 * "added to the cart" client-side — they are granted by the server at
 * order placement — so the copy says "added automatically with your
 * order", which is both true and matches the UX the customer expects.
 *
 * Usage (owned by whatever component renders the cart):
 *
 *   const [giftToast, setGiftToast] = useState(null)
 *   const gifts = useGiftProgress({
 *     subtotal,
 *     onTierCrossed: (p) => setGiftToast({ tier: p.highest, lines: p.earnedLines }),
 *   })
 *   …
 *   <GiftToast toast={giftToast} onDismiss={() => setGiftToast(null)} />
 *
 * toast = { tier: { threshold_amount, gifts? }, lines: earnedLines } | null
 */

import React, { useEffect } from 'react'
import { GiftIcon, SparkIcon, XIcon } from './giftIcons'
import { formatINR } from '../../hooks/useGiftProgress'
import './gifts.css'

export default function GiftToast({ toast, onDismiss, duration = 5000 }) {
  useEffect(() => {
    if (!toast) return undefined
    const timer = setTimeout(() => onDismiss?.(), duration)
    return () => clearTimeout(timer)
  }, [toast, duration, onDismiss])

  useEffect(() => {
    if (!toast) return undefined
    const onKey = (e) => {
      if (e.key === 'Escape') onDismiss?.()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [toast, onDismiss])

  if (!toast) return null

  const lines = toast.lines ?? []
  const summary = lines
    .slice(0, 2)
    .map((l) => l.product_name ?? l.name ?? 'a free gift')
    .join(lines.length > 2 ? ', ' : ' and ')
  const extra = Math.max(0, lines.length - 2)
  const threshold = toast.tier?.threshold_amount

  return (
    <div className="kg-root kg-toast" role="status" aria-live="polite">
      <span className="kg-toast-icon">
        <GiftIcon size={20} />
        <span className="kg-toast-spark">
          <SparkIcon size={10} />
        </span>
      </span>

      <div className="kg-toast-body">
        <div className="kg-toast-title">Free gift unlocked!</div>
        {summary && (
          <div className="kg-toast-items">
            {summary}
            {extra > 0 ? ` +${extra} more` : ''}
            {threshold ? ` · ${formatINR(threshold)} tier` : ''}
          </div>
        )}
        <div className="kg-toast-sub">Added automatically with your order</div>
      </div>

      <button type="button" className="kg-toast-x" onClick={() => onDismiss?.()} aria-label="Dismiss">
        <XIcon size={14} />
      </button>

      <span className="kg-toast-timer" style={{ animationDuration: `${duration}ms` }} />
    </div>
  )
}
