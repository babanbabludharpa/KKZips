import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle, X } from "lucide-react";
import toast from "react-hot-toast";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";

/* ---- color helpers (tenant-aware, no hardcoding) ---- */
const darken = (hex, amount = 0.15) => {
  if (!hex || !hex.startsWith("#")) return hex;
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.floor(((n >> 16) & 0xff) * (1 - amount)));
  const g = Math.max(0, Math.floor(((n >> 8) & 0xff) * (1 - amount)));
  const b = Math.max(0, Math.floor((n & 0xff) * (1 - amount)));
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
};
const lighten = (hex, amount = 0.3) => {
  if (!hex || !hex.startsWith("#")) return hex;
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.floor(((n >> 16) & 0xff) + (255 - ((n >> 16) & 0xff)) * amount));
  const g = Math.min(255, Math.floor(((n >> 8) & 0xff) + (255 - ((n >> 8) & 0xff)) * amount));
  const b = Math.min(255, Math.floor((n & 0xff) + (255 - (n & 0xff)) * amount));
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
};
const hexToRgba = (hex, alpha = 0.3) => {
  if (!hex || !hex.startsWith("#")) return `rgba(255,113,50,${alpha})`;
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 0xff}, ${(n >> 8) & 0xff}, ${n & 0xff}, ${alpha})`;
};

export default function Login({ onClose }) {
  const navigate = useNavigate();
  const { login, clearError } = useCustomerAuth();
  const [form, setForm] = useState({ phone: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const { theme: tenantTheme } = useTenant();

  // ★ Build ONE theme object: tenant colors take priority, neutrals stay constant
  const primaryColor = tenantTheme?.primary_color || "#FF7132";
  const theme = {
    primary:   primaryColor,
    primaryHover: darken(primaryColor, 0.15),
    primaryDisabled: lighten(primaryColor, 0.3),
    primaryShadow: hexToRgba(primaryColor, 0.3),
    logo_url:  tenantTheme?.logo_url,
    brand_name: tenantTheme?.brand_name,
    // neutrals — these don't change per tenant
    dark:   "#333333",
    mid:    "#666666",
    border: "#E0E0E0",
    error:  "#EF4444",
  };

  const validate = () => {
    const errs = {};
    if (!form.phone) errs.phone = "Phone number is required.";
    else if (!/^\d{10}$/.test(form.phone.replace(/\D/g, "")))
      errs.phone = "Enter a valid 10-digit phone number.";
    if (!form.password) errs.password = "Password is required.";
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    setErrors({});
    setLoading(true);
    clearError();

    const ok = await login({
      phone: form.phone,
      password: form.password,
    });

    if (ok) {
      toast.success("Welcome back!");
      onClose?.();
      navigate("/", { replace: true });
    } else {
      const { error } = useCustomerAuth.getState();
      const msg = error || "Invalid phone number or password.";
      if (/phone/i.test(msg))        setErrors({ phone: msg });
      else if (/password/i.test(msg)) setErrors({ password: msg });
      else                            toast.error(msg);
    }

    setLoading(false);
  };

  const handleChange = (field) => (e) => {
    setForm((p) => ({ ...p, [field]: e.target.value }));
    if (errors[field]) setErrors((p) => ({ ...p, [field]: "" }));
  };

  return (
    <AnimatePresence>
      {/* ★ CHANGED: removed onClick={onClose} — modal now only closes via X button */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "24px",
          zIndex: 1000,
          backgroundColor: "rgba(0,0,0,0.5)",
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 32, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.98 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          style={{
            width: "100%",
            maxWidth: "480px",
            background: "#ffffff",
            borderRadius: "24px",
            padding: "30px",
            border: `1px solid ${theme.border}`,
            boxShadow: "0 24px 64px rgba(0,0,0,0.2)",
            position: "relative",
          }}
        >
          {/* Close Icon — only way to dismiss the modal */}
          <button
            type="button"
            onClick={onClose}
            style={{
              position: "absolute",
              top: "20px",
              right: "20px",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: "8px",
              color: theme.primary,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={24} />
          </button>

          {/* Logo Area */}
          <div style={{ textAlign: "center", marginBottom: "32px" }}>
            <Link
              to="/"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                textDecoration: "none",
                marginBottom: "24px",
              }}
            >
              {theme.logo_url && (
                <img
                  src={theme.logo_url}
                  alt={theme.brand_name || "Logo"}
                  style={{ height: "50px", width: "auto", objectFit: "contain" }}
                />
              )}
            </Link>
            <h1
              style={{
                fontSize: "20px",
                fontWeight: "800",
                color: theme.dark,
                letterSpacing: "-0.025em",
                marginBottom: "8px",
              }}
            >
              Welcome back
            </h1>
            <p style={{ color: theme.mid, fontSize: "0.95rem" }}>
              Sign in to continue shopping
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} noValidate>
            {/* Phone Number */}
            <div style={{ marginBottom: "20px" }}>
              <label
                style={{
                  display: "block",
                  fontSize: "0.9rem",
                  fontWeight: "600",
                  color: theme.dark,
                  marginBottom: "8px",
                }}
              >
                Phone Number
              </label>
              <input
                type="tel"
                value={form.phone}
                onChange={handleChange("phone")}
                placeholder="9876543210"
                maxLength={10}
                style={{
                  width: "100%",
                  padding: "14px 16px",
                  borderRadius: "12px",
                  border: `1.5px solid ${errors.phone ? theme.error : theme.border}`,
                  fontSize: "0.95rem",
                  color: theme.dark,
                  outline: "none",
                  transition: "border-color 0.2s",
                  backgroundColor: "#fff",
                }}
                onFocus={(e) => {
                  if (!errors.phone) e.target.style.borderColor = theme.primary;
                }}
                onBlur={(e) => {
                  if (!errors.phone) e.target.style.borderColor = theme.border;
                }}
              />
              {errors.phone && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                    marginTop: "6px",
                  }}
                >
                  <AlertCircle size={14} color={theme.error} />
                  <span style={{ color: theme.error, fontSize: "0.82rem" }}>
                    {errors.phone}
                  </span>
                </motion.div>
              )}
            </div>

            {/* Password */}
            <div style={{ marginBottom: "24px" }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "8px",
                }}
              >
                <label
                  style={{
                    fontSize: "0.9rem",
                    fontWeight: "600",
                    color: theme.dark,
                  }}
                >
                  Password
                </label>
                <a
                  href="#"
                  style={{
                    fontSize: "0.85rem",
                    color: theme.primary,
                    textDecoration: "none",
                    fontWeight: "600",
                  }}
                >
                  Forgot password?
                </a>
              </div>
              <input
                type="password"
                value={form.password}
                onChange={handleChange("password")}
                placeholder="Please Enter Your Password"
                style={{
                  width: "100%",
                  padding: "14px 16px",
                  borderRadius: "12px",
                  border: `1.5px solid ${errors.password ? theme.error : theme.border}`,
                  fontSize: "0.95rem",
                  color: theme.dark,
                  outline: "none",
                  transition: "border-color 0.2s",
                  backgroundColor: "#fff",
                }}
                onFocus={(e) => {
                  if (!errors.password) e.target.style.borderColor = theme.primary;
                }}
                onBlur={(e) => {
                  if (!errors.password) e.target.style.borderColor = theme.border;
                }}
              />
              {errors.password && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                    marginTop: "6px",
                  }}
                >
                  <AlertCircle size={14} color={theme.error} />
                  <span style={{ color: theme.error, fontSize: "0.82rem" }}>
                    {errors.password}
                  </span>
                </motion.div>
              )}
            </div>

            {/* Submit — fully dynamic tenant color */}
            <button
              type="submit"
              disabled={loading}
              style={{
                width: "100%",
                padding: "16px",
                borderRadius: "14px",
                border: "none",
                background: loading ? theme.primaryDisabled : theme.primary,
                color: "#fff",
                fontSize: "1rem",
                fontWeight: "700",
                cursor: loading ? "not-allowed" : "pointer",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                boxShadow: `0 4px 12px ${theme.primaryShadow}`,
              }}
              onMouseEnter={(e) => {
                if (!loading) {
                  e.currentTarget.style.background = theme.primaryHover;
                  e.currentTarget.style.transform = "translateY(-1px)";
                }
              }}
              onMouseLeave={(e) => {
                if (!loading) {
                  e.currentTarget.style.background = theme.primary;
                  e.currentTarget.style.transform = "none";
                }
              }}
            >
              {loading ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                    style={{
                      width: "18px",
                      height: "18px",
                      border: "2px solid rgba(255,255,255,0.3)",
                      borderTopColor: "#fff",
                      borderRadius: "50%",
                    }}
                  />
                  Signing in…
                </>
              ) : (
                "Sign In"
              )}
            </button>
          </form>

          {/* Footer link */}
          <div
            style={{
              textAlign: "center",
              marginTop: "32px",
              fontSize: "0.9rem",
              color: theme.dark,
              display: "flex",
              gap: "6px",
              justifyContent: "center",
            }}
          >
            <span>Don't have an account?</span>
            <Link
              to="/register"
              style={{
                color: theme.primary,
                fontWeight: "700",
                textDecoration: "none",
              }}
              onClick={onClose}
            >
              Sign Up
            </Link>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}