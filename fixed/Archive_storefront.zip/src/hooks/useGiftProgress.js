/**
 * ★ FREE GIFTS — cart progress hook (web storefront).
 *
 * Mirrors GiftService::resolveForCart() semantics on the client so the
 * cart drawer can animate the progress bar live, without a preview call
 * per keystroke. IMPORTANT: this is DISPLAY-ONLY. The server re-resolves
 * everything at `POST /mobile/orders/preview` and re-validates under lock
 * at `place()` — the client never sends gift lines anywhere.
 *
 * Usage:
 *   const { active, campaign, tiers, progress, loading } = useGiftProgress({ subtotal })
 *
 *   subtotal       – current cart item subtotal (number, ₹)
 *   couponDiscount – optional; applied when campaign.threshold_basis === 'after_coupon'
 *   enabled        – gate fetching (e.g. only while the drawer is open)
 *   onTierCrossed  – callback(progress) fired when the cart value crosses
 *                    a NEW threshold (drives the "free gift unlocked" toast)
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { getActiveGifts } from '../api/gifts'

// ── module-level cache ─────────────────────────────────────────────
// Campaigns change rarely; the drawer shouldn't refetch on every open.
// A cached `null` is also a valid result ("no campaign") — `has` keeps
// that distinct from "never fetched".
const CAMPAIGN_TTL = 5 * 60 * 1000
let campaignCache = { fetchedAt: 0, has: false, payload: null }
let inflight = null

function loadCampaign(force = false) {
  if (!force && campaignCache.has && Date.now() - campaignCache.fetchedAt < CAMPAIGN_TTL) {
    return Promise.resolve(campaignCache.payload)
  }
  if (inflight) return inflight

  inflight = getActiveGifts()
    .then((payload) => {
      campaignCache = { fetchedAt: Date.now(), has: true, payload }
      return payload
    })
    .finally(() => {
      inflight = null
    })

  return inflight
}

/** Call after a successful order placement (per-customer caps may now
 *  block the next cart) and after login/logout (customer context changed). */
export function invalidateGiftCampaign() {
  campaignCache = { fetchedAt: 0, has: false, payload: null }
}

// ── pure helpers (exported for unit tests) ─────────────────────────

export function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100
}

/** ₹1,234 / ₹1,234.50 — Indian grouping, paise only when needed. */
export function formatINR(amount) {
  const n = Number(amount) || 0
  const hasPaise = Math.round(n * 100) % 100 !== 0
  return (
    '₹' +
    n.toLocaleString('en-IN', {
      minimumFractionDigits: hasPaise ? 2 : 0,
      maximumFractionDigits: 2,
    })
  )
}

/**
 * Compute the display progress for a cart value.
 * Mirrors the server:
 *  - tiers sorted ascending; the highest tier whose threshold ≤ value is earned
 *  - tier_mode 'exact'      → only that tier's gifts
 *  - tier_mode 'cumulative' → that tier + every lower tier; a variant that
 *    appears in several tiers is granted once, at its highest quantity
 */
export function computeGiftProgress(campaign, tiers, value) {
  if (!campaign || !tiers || tiers.length === 0) return null

  const sorted = [...tiers].sort((a, b) => a.threshold_amount - b.threshold_amount)
  const v = round2(value)

  let highest = null
  for (const t of sorted) {
    if (v >= t.threshold_amount) highest = t
  }
  const next = sorted.find((t) => t.threshold_amount > v) || null

  // earned gift lines (server merge semantics)
  const earnedTiers =
    campaign.tier_mode === 'cumulative'
      ? sorted.filter((t) => highest && t.threshold_amount <= highest.threshold_amount)
      : highest
        ? [highest]
        : []

  const lines = new Map()
  for (const tier of earnedTiers) {
    for (const gift of tier.gifts || []) {
      const existing = lines.get(gift.product_variant_id)
      if (existing) {
        existing.quantity = Math.max(existing.quantity, gift.quantity || 1)
        existing.gift_tier_id = tier.id
        existing.threshold_amount = tier.threshold_amount
      } else {
        lines.set(gift.product_variant_id, {
          ...gift,
          quantity: gift.quantity || 1,
          gift_tier_id: tier.id,
          threshold_amount: tier.threshold_amount,
          is_gift: true,
        })
      }
    }
  }

  const percent = next
    ? Math.min(100, (v / next.threshold_amount) * 100)
    : highest
      ? 100
      : 0

  return {
    value: v,
    highest,
    next,
    percent,
    remaining: next ? round2(next.threshold_amount - v) : null,
    earnedLines: [...lines.values()],
    markers: sorted.map((t) => ({
      threshold_amount: t.threshold_amount,
      earned: !!highest && t.threshold_amount <= highest.threshold_amount,
    })),
    allUnlocked: !!highest && !next,
  }
}

// ── the hook ───────────────────────────────────────────────────────

export function useGiftProgress({
  subtotal = 0,
  couponDiscount = 0,
  enabled = true,
  onTierCrossed,
} = {}) {
  const [campaign, setCampaign] = useState(campaignCache.has ? campaignCache.payload : null)
  const [loading, setLoading] = useState(!campaignCache.has)

  // keep the callback fresh without retriggering effects
  const crossedCbRef = useRef(onTierCrossed)
  useEffect(() => {
    crossedCbRef.current = onTierCrossed
  })

  useEffect(() => {
    if (!enabled) return undefined

    let alive = true
    setLoading(true)

    loadCampaign()
      .then((payload) => {
        if (!alive) return
        setCampaign(payload)
        setLoading(false)
      })
      .catch(() => {
        if (alive) setLoading(false)
      })

    return () => {
      alive = false
    }
  }, [enabled])

  // the bar follows the same basis the server will use at preview:
  // 'after_coupon' → coupon-adjusted subtotal, 'before_coupon' → raw subtotal
  const basisValue = useMemo(() => {
    const sub = round2(subtotal)
    if (!campaign || campaign.threshold_basis !== 'after_coupon') return sub
    return round2(Math.max(0, sub - round2(couponDiscount)))
  }, [campaign, subtotal, couponDiscount])

  const tiers = campaign?.tiers ?? []
  const progress = useMemo(
    () => computeGiftProgress(campaign, tiers, basisValue),
    [campaign, tiers, basisValue],
  )

  // tier-crossing detection → toast. The first resolution after mount
  // only records state (no toast when the drawer opens on an already
  // qualifying cart); afterwards any upward crossing fires.
  const prevThresholdRef = useRef(undefined)
  const highestKey = progress?.highest?.threshold_amount ?? null
  useEffect(() => {
    const prev = prevThresholdRef.current
    prevThresholdRef.current = highestKey

    if (prev === undefined) return // first resolution — stay quiet
    if (highestKey && highestKey !== prev) {
      crossedCbRef.current?.(progress)
    }
  }, [highestKey])

  return {
    active: !!campaign,
    loading,
    campaign,
    tiers,
    progress, // { value, highest, next, percent, remaining, earnedLines, markers, allUnlocked }
    earnedLines: progress?.earnedLines ?? [],
    refresh: () => loadCampaign(true),
  }
}

export default useGiftProgress
