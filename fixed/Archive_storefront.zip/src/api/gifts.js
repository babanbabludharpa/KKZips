/**
 * ★ FREE GIFTS — storefront API module.
 *
 * The web store talks to the same `/mobile/*` endpoints as the customer
 * app (that is how the existing catalog / cart / checkout already works),
 * so this is deliberately thin: ONE new public endpoint for the progress
 * bar. Everything else (what the cart has actually earned) arrives inside
 * the existing `POST /mobile/orders/preview` response as a `gifts` block.
 *
 * Server contract (backend Phase 1):
 *   GET /mobile/gifts/active
 *   → { status: true, data: { campaign, tiers } | null }
 *
 *   campaign: { id, name, tier_mode: 'exact'|'cumulative',
 *               threshold_basis: 'after_coupon'|'before_coupon' }
 *   tiers:    [ { id, threshold_amount, selection_mode,
 *                 gifts: [ { product_variant_id, name, sku, mrp,
 *                            quantity, unit_abbr, image_url } ] } ]
 */

// ★ FIX: this project's axios instance lives in './customerApi'
//   (baseURL '/api/v1', attaches X-Tenant + Bearer token). './api'
//   does not exist, so the old import broke the whole gift module.
import customerApi from './customerApi'

/**
 * Active gift campaign for the cart progress bar.
 * Public — intentionally works before login, exactly like the catalog.
 * Resolves to `null` when no campaign is running (also cached as null,
 * so an idle tenant does not hammer the endpoint on every drawer open).
 */
export async function getActiveGifts() {
  const res = await customerApi.get('/mobile/gifts/active')
  return res?.data?.data ?? null
}
