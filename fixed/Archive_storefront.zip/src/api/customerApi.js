import axios from 'axios'

// ─────────────────────────────────────────────────────────────────────────
// customerApi.js
//
// ONE axios instance for the customer web portal. Used by:
//   • useCustomerAuth.js (login, register, me, logout)
//   • TenantProvider.jsx (fetch layout)
//   • Home.jsx, Products.jsx, etc. (fetch products, categories, etc.)
//   • pusher.js (no — Pusher uses its own client, but auth endpoint uses this)
//
// What it does on every request:
//   1. Attaches `Authorization: Bearer <token>` from customer-auth-storage
//   2. Attaches `X-Tenant: <tenantId>` resolved from the subdomain, or —
//      for real custom-domain tenants (directsellingnewsindia.com,
//      directsellingnews.in) where there's no subdomain to parse — from
//      the /branding endpoint's tenant_slug, cached after the first call.
//   3. Uses baseURL '/api/v1' (relative) so Vite's dev proxy handles it
//      → no CORS, no preflight
//
// What it does NOT do:
//   • Touch the admin's `auth-storage` (separate session)
//   • Force-redirect on 401 (your LoginModal is a modal, not a route)
//   • Hardcode any tenant id (multi-tenant: resolved from URL or /branding)
//
// ── FIX (see TenantProvider.jsx) ────────────────────────────────────────
// `ensureBrandingTenantId` is now exported. On custom domains (no
// subdomain to parse), `resolveTenantId()` returns null until /branding
// has resolved at least once. Previously nothing outside this file could
// await that resolution, so on a fresh page load on a bare custom domain,
// TenantProvider would see tenantId === null, bail out of fetchLayout
// immediately, and never retry — leaving the customer portal permanently
// unlayoutted. TenantProvider now calls ensureBrandingTenantId() directly
// on mount when resolveTenantId() comes back empty.
//
// ── FIX 2 ────────────────────────────────────────────────────────────────
// `dev-tenant.kutumbkart.in` (and any other infra/staging hostname with
// 3+ dot-separated parts) was being parsed by the subdomain rule below as
// tenant slug "dev-tenant" — a literal string that doesn't exist in the
// tenants table, so every request 404'd with "Tenant not found." The
// subdomain heuristic (parts.length >= 3) can't tell a real tenant
// subdomain from an infra/staging hostname that happens to have the same
// shape. HOSTNAME_TENANT_OVERRIDES below is an explicit escape hatch for
// hostnames that need to map to a specific real tenant (or to fall
// through to /branding resolution) instead of being parsed literally.
// UPDATE THIS MAP when a new non-tenant hostname (staging, preview, QA,
// etc.) is provisioned — don't rely on the subdomain heuristic to guess
// right for infra domains.
// ─────────────────────────────────────────────────────────────────────────

const AUTH_STORAGE_KEY = 'customer-auth-storage'

// Hostnames that must NOT be parsed as "first label = tenant slug" even
// though they have the shape of one. Map to a real tenant slug to pin
// this host to a specific tenant, or map to null to force /branding
// resolution instead.
const HOSTNAME_TENANT_OVERRIDES = {
  // TODO: confirm which real tenant this staging host should show and
  // update the value below. Currently pinned to null, which forces
  // /branding resolution (same path as bare custom domains) rather than
  // 404ing on a literal "dev-tenant" slug.
  'dev-tenant.kutumbkart.in': null,
}

// Cache the tenant slug for the lifetime of the page load once resolved via
// /branding, so we don't hit that endpoint on every single request.
let cachedBrandingTenantId = null
let brandingFetchPromise = null

// ── Resolve tenant from URL (NO env var, NO hardcoding) ─────────────────
//
//   infosoft.platform.test       → "infosoft"   (subdomain-style tenant)
//   inforkart.platform.test      → "inforkart"
//   infosoft.localhost:5174      → "infosoft"   (dev — Chrome auto-resolves *.localhost)
//   inforkart.localhost:5174     → "inforkart"  (dev)
//   directsellingnewsindia.com   → "krushnadairy" (real custom domain — no
//                                    subdomain to parse, resolved via the
//                                    cached /branding response instead)
//   dev-tenant.kutumbkart.in     → resolved via HOSTNAME_TENANT_OVERRIDES,
//                                    NOT parsed as literal slug "dev-tenant"
//   localhost:5174               → null (no subdomain — see DevTenantSwitcher)
//
// For dev on plain localhost, use the DevTenantSwitcher component (in
// this same bundle) to pick a tenant at runtime. It writes to
// localStorage['dev-tenant-override'] which takes priority below.
const resolveTenantId = () => {
  // 1. Manual dev override (set by DevTenantSwitcher)
  try {
    const override = localStorage.getItem('dev-tenant-override')
    if (override) return override
  } catch (_) {}

  const host = window.location.hostname.split(':')[0] // strip port

  // 2. Explicit hostname override — checked BEFORE the subdomain heuristic
  // so infra/staging hostnames never get misparsed as a literal tenant
  // slug. A mapped value of null means "don't trust this hostname's shape,
  // fall through to /branding resolution instead."
  if (Object.prototype.hasOwnProperty.call(HOSTNAME_TENANT_OVERRIDES, host)) {
    const override = HOSTNAME_TENANT_OVERRIDES[host]
    if (override) return override
    // else: fall through to step 4 (custom-domain / branding resolution)
  } else {
    // 3. Subdomain extraction (subdomain-style tenants only) — skipped
    // entirely for hostnames in HOSTNAME_TENANT_OVERRIDES.
    if (host.endsWith('.localhost')) {
      // infosoft.localhost → "infosoft"
      return host.slice(0, -'.localhost'.length)
    }
    const parts = host.split('.')
    if (parts.length >= 3 && !parts.every(p => /^\d+$/.test(p))) {
      return parts[0]
    }
  }

  // 4. Custom-domain tenant (directsellingnewsindia.com, dev-tenant.kutumbkart.in
  // via override, etc.) — no subdomain to extract, fall back to whatever
  // /branding resolved. Synchronous by design: this returns whatever's
  // cached so far. The first request or two on page load may go out with
  // no X-Tenant header while the /branding fetch below is still in
  // flight — see ensureBrandingTenantId(), which every request awaits
  // before this function's result is actually used.
  if (cachedBrandingTenantId) return cachedBrandingTenantId

  return null
}

// Fetches /branding once (subsequent calls reuse the same in-flight or
// resolved promise) and caches tenant_slug for resolveTenantId() to use.
// Needed for: custom-domain tenants, AND any hostname explicitly routed
// here via HOSTNAME_TENANT_OVERRIDES (e.g. dev-tenant.kutumbkart.in).
// Subdomain-style tenants resolve synchronously above and never need this
// network round-trip.
//
// Exported so callers outside the axios interceptor (TenantProvider on
// mount) can await resolution directly instead of relying on it being
// triggered as a side effect of some other request.
const ensureBrandingTenantId = async () => {
  if (cachedBrandingTenantId) return cachedBrandingTenantId

  const host = window.location.hostname.split(':')[0]

  // If this host is explicitly overridden to a real slug, or resolves via
  // the normal subdomain rule, /branding is unnecessary.
  if (Object.prototype.hasOwnProperty.call(HOSTNAME_TENANT_OVERRIDES, host)) {
    const override = HOSTNAME_TENANT_OVERRIDES[host]
    if (override) return override
    // override is null → this host intentionally needs /branding, fall through
  } else {
    const parts = host.split('.')
    const hasSubdomainTenant =
      host.endsWith('.localhost') ||
      (parts.length >= 3 && !parts.every(p => /^\d+$/.test(p)))
    if (hasSubdomainTenant) return null
  }

  if (!brandingFetchPromise) {
    brandingFetchPromise = axios.get('/api/v1/branding')
      .then((res) => {
        const slug = res.data?.data?.tenant_slug || null
        cachedBrandingTenantId = slug
        return slug
      })
      .catch(() => null)
  }
  return brandingFetchPromise
}

const customerApi = axios.create({
  baseURL: '/api/v1',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
})

// ── Request interceptor: attach Bearer + X-Tenant ───────────────────────
customerApi.interceptors.request.use(async (config) => {
  // 1. Bearer token (if logged in)
  const raw = localStorage.getItem(AUTH_STORAGE_KEY)
  if (raw) {
    try {
      const { state } = JSON.parse(raw)
      if (state?.token) {
        config.headers.Authorization = `Bearer ${state.token}`
      }
    } catch (_) {}
  }

  // 2. X-Tenant header (always — required by tenant.mobile middleware).
  // For custom-domain tenants this awaits the cached /branding fetch so
  // the very first request on page load still carries the header instead
  // of racing it.
  let tenantId = resolveTenantId()
  if (!tenantId) {
    tenantId = await ensureBrandingTenantId()
  }
  if (tenantId) {
    config.headers['X-Tenant'] = tenantId
  } else {
    console.warn(
      '[customerApi] No tenant resolved from URL or /branding.\n' +
      'In dev: visit http://infosoft.localhost:5174 OR use the DevTenantSwitcher.\n' +
      'In prod: visit a tenant subdomain or a domain registered in the tenants table.'
    )
  }

  return config
})

// ── Response interceptor: 401 just clears storage (no redirect) ─────────
customerApi.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem(AUTH_STORAGE_KEY)
    }
    return Promise.reject(error)
  }
)

// ── Helper: unwrap { status, message, data } → returns data ─────────────
export const unwrap = (res) => {
  const body = res.data
  if (!body || body.status !== true) {
    const err = new Error(body?.message || 'Request failed.')
    err.status = res.status
    err.data = body?.data
    err.errors = body?.errors
    err.response = res
    err.body = body
    throw err
  }
  return body.data
}

// Export resolveTenantId + ensureBrandingTenantId so other files
// (TenantProvider) can use the same resolution logic without duplicating
// it, and can await branding resolution instead of only reading whatever
// happens to be cached synchronously.
export { resolveTenantId, ensureBrandingTenantId }

export default customerApi