import { createContext, useContext, useState, useEffect } from "react";
import api from "../utils/api";
import toast from "react-hot-toast";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("auth_token") || null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  // Fetch user data if token exists on app load
  useEffect(() => {
    if (token) {
      api.get("/auth/me")
        .then((res) => {
          if (res.data.status) {
            // Change data.user to data.customer
            setUser(res.data.data.customer); 
          }
        })
        .catch(() => {
          logout();
        })
        .finally(() => setIsAuthLoading(false));
    } else {
      setIsAuthLoading(false);
    }
  }, [token]);

  const login = (newToken, userData) => {
    localStorage.setItem("auth_token", newToken);
    setToken(newToken);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem("auth_token");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!token, login, logout, isAuthLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);