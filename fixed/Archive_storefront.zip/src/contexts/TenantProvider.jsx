import { createContext, useContext, useEffect, useState, useRef } from "react";
import customerApi, { resolveTenantId, ensureBrandingTenantId } from "../api/customerApi";

// ─────────────────────────────────────────────────────────────────────────
// TenantProvider.jsx — SILENT POLLING version
//
// All Pusher code has been removed. Real-time layout updates are
// replaced with smart polling:
//
//   • On mount: fetch layout once (shows loading spinner)
//   • Every 30s: SILENT re-fetch (no spinner, no flicker)
//     - Deep-compares new data with last fetch via JSON signature
//     - If identical → skips ALL setState → React doesn't re-render
//     - If changed → updates state → UI refreshes smoothly
//   • On route change: re-resolve tenant (subdomain may have changed)
//   • Manually: call refetch() to force refresh (bypasses signature check)
//
// The user sees ZERO visual disruption during polls. Admin changes appear
// within 30 seconds (or instantly on manual refetch / page refresh).
//
// ── FIX ──────────────────────────────────────────────────────────────
// On bare custom domains (directsellingnewsindia.com, etc. — no subdomain
// to parse), resolveTenantId() returns null synchronously on first render,
// because tenant resolution there depends on an async /branding fetch.
// The old mount effect just did `setTenantId(resolveTenantId())`, which
// re-set it to the SAME null, and fetchLayout(null) bails out immediately
// without ever calling ensureBrandingTenantId() itself — so on a custom
// domain the app never recovered from that first null and the layout
// never loaded. Subdomain-style tenants (infosoft.localhost, etc.) never
// hit this because resolveTenantId() resolves synchronously for them —
// which is why this only shows up in production on the real domain and
// never in local dev.
//
// Now: if resolveTenantId() comes back empty, we explicitly await
// ensureBrandingTenantId() and set tenantId once it resolves.
// ─────────────────────────────────────────────────────────────────────────

const TenantContext = createContext(null);

const DEFAULT_PRODUCT_DISPLAY = {
  default_view: "grid",
  products_per_row: 4,
  show_mrp: true,
  show_discount: true,
  show_rating: true,
  show_stock: true,
  show_unit: true,
  default_sort: "name_asc",
  card_style: "standard",
  quick_view: true,
  show_add_to_cart: true,
  show_wishlist: true,
  image_aspect: "square",
  out_of_stock_behavior: "dim",
};

const DEFAULT_NAVIGATION = {
  links: [
    { id: "home", label: "Home", url: "/", visible: true, order: 1 },
    { id: "about", label: "About Us", url: "/about", visible: true, order: 2 },
    { id: "products", label: "Products", url: "/products", visible: true, order: 3 },
    { id: "subscription", label: "Order Now", url: "/subscription", visible: true, order: 4 },
    { id: "contact", label: "Contact", url: "/contact", visible: true, order: 5 },
  ],
  navbar_style: "solid",
  mobile_menu_style: "drawer",
};

const DEFAULT_FOOTER = {
  enabled: true,
  bg_color: "#1E293B",
  text_color: "#94A3B8",
  columns: [
    { id: "col1", title: "", type: "text", content: "" },
    { id: "col2", title: "Quick Links", type: "links", links: [
      { label: "Home", url: "/" }, { label: "Products", url: "/products" }, { label: "About", url: "/about" }
    ]},
    { id: "col3", title: "Contact", type: "links", links: [
      { label: "Contact Us", url: "/contact" }
    ]},
  ],
  copyright: "",
  show_payment_badges: true,
  show_app_links: false,
};

// ★ Polling interval — how often to re-fetch the layout to pick up
// admin changes. Since polls are now SILENT (no flicker, no loading
// spinner, deep-compared), you can safely lower this to 15s for faster
// updates without hurting UX. Keep at 30s if backend load is a concern.
//   15s = more responsive, ~4 req/min per active user
//   30s = balanced (default), ~2 req/min per active user
//   60s = conservative, ~1 req/min per active user
const POLL_INTERVAL_MS = 4 * 60 * 60 * 1000;

export function useTenant() {
  const ctx = useContext(TenantContext);
  if (!ctx) {
    return {
      tenantId: null,
      sections: [],
      theme: {
        primary_color: "#666666",
        secondary_color: "#1E293B",
        font_family: "Inter, sans-serif",
        logo_url: null,
        brand_name: "",
      },
      navigationConfig: DEFAULT_NAVIGATION,
      footerConfig: DEFAULT_FOOTER,
      customPages: [],
      productDisplayConfig: DEFAULT_PRODUCT_DISPLAY,
      isLoading: true,
      error: null,
      ready: false,
    };
  }
  return ctx;
}

export function TenantProvider({ children }) {
  const [tenantId, setTenantId] = useState(() => resolveTenantId());
  const [sections, setSections] = useState([]);
  const [theme, setTheme] = useState({
    primary_color: "#666666",
    secondary_color: "#1E293B",
    font_family: "Inter, sans-serif",
    logo_url: null,
    brand_name: "",
    border_radius: 12,
    shadow_style: "medium",
    button_style: "rounded",
    card_style: "shadowed",
    typography_scale: "normal",
    hero_style: "solid",
    background_pattern: "dotted",
  });

  const [navigationConfig, setNavigationConfig] = useState(DEFAULT_NAVIGATION);
  const [footerConfig, setFooterConfig] = useState(DEFAULT_FOOTER);
  const [customPages, setCustomPages] = useState([]);
  const [productDisplayConfig, setProductDisplayConfig] = useState(DEFAULT_PRODUCT_DISPLAY);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [ready, setReady] = useState(false);  // ★ NEW — hard gate flag
  // Ref so the polling interval always calls the latest fetchLayout
  const fetchLayoutRef = useRef(null);
  // ★ Track whether the first fetch has completed — only the FIRST fetch
  // shows the loading spinner. All subsequent polls are SILENT (no loading
  // state change, no error clearing) so the UI doesn't flicker every 30s.
  const isFirstFetchRef = useRef(true);
  // ★ Track the last fetched data signature — used to skip setState calls
  // when the backend returns identical data (which is 99% of polls).
  const lastDataSignatureRef = useRef(null);

  // ── FIX: resolve tenant on mount, awaiting /branding for custom domains ──
  // Previously this was `useEffect(() => { setTenantId(resolveTenantId()); }, [])`,
  // which just re-read the same synchronous (possibly null) value and never
  // gave custom-domain tenants a chance to resolve via /branding. Now we
  // explicitly fall through to ensureBrandingTenantId() when the synchronous
  // resolution comes back empty.
  useEffect(() => {
    let cancelled = false;
    const resolve = async () => {
      const tid = resolveTenantId();
      if (tid) {
        if (!cancelled) setTenantId(tid);
        return;
      }
      const resolved = await ensureBrandingTenantId();
      if (!cancelled && resolved) {
        setTenantId(resolved);
      }
    };
    resolve();
    return () => { cancelled = true; };
  }, []);

  // ── Layout fetch ──────────────────────────────────────────────────────
  // Two modes:
  //   • Initial fetch (isFirstFetchRef.current === true):
  //       - Shows loading spinner
  //       - Clears errors
  //       - Always updates state
  //   • Poll (isFirstFetchRef.current === false):
  //       - SILENT — no loading spinner, no error clearing
  //       - Deep-compares new data with last fetch
  //       - Skips ALL setState calls if data is identical → no re-render
  const fetchLayout = async (tid) => {
    if (!tid) {
      setSections([]);
      setIsLoading(false);
      return;
    }

    const isInitial = isFirstFetchRef.current;

    // Only show loading + clear error on the FIRST fetch.
    // Polls are silent — don't touch isLoading or error.
    if (isInitial) {
      setIsLoading(true);
      setError(null);
    }

    try {
      const res = await customerApi.get("/mobile/web/layout");
      const data = res.data?.data || {};

      // ★ Deep-compare: build a signature of the new data and compare
      // with the last fetch. If identical, skip ALL state updates —
      // React won't re-render, user sees no flicker.
      // JSON.stringify is fast enough for this payload size (~50KB).
      const signature = JSON.stringify({
        layout_components: data.layout_components || data.sections || [],
        theme_config: data.theme_config || {},
        navigation_config: data.navigation_config || null,
        footer_config: data.footer_config || null,
        custom_pages: data.custom_pages || [],
        product_display_config: data.product_display_config || {},
      });

      if (!isInitial && signature === lastDataSignatureRef.current) {
        // Data unchanged — silent skip. No setState, no re-render.
        return;
      }
      lastDataSignatureRef.current = signature;

      // Data changed (or this is the first fetch) — update state.
      const rawSections = data.layout_components || data.sections || [];
      setSections(Array.isArray(rawSections) ? rawSections : []);

      const t = data.theme_config || {};
      setTheme((prev) => ({
        ...prev,
        primary_color: t.primary_color || "#666666",
        secondary_color: t.secondary_color || "#1E293B",
        font_family: t.font_family || "Inter, sans-serif",
        logo_url: t.logo_url || null,
        brand_name: t.brand_name || "",
        border_radius: t.border_radius ?? 12,
        shadow_style: t.shadow_style || "medium",
        button_style: t.button_style || "rounded",
        card_style: t.card_style || "shadowed",
        typography_scale: t.typography_scale || "normal",
        hero_style: t.hero_style || "solid",
        background_pattern: t.background_pattern || "dotted",
      }));

      setNavigationConfig(data.navigation_config || DEFAULT_NAVIGATION);
      setFooterConfig(data.footer_config || DEFAULT_FOOTER);
      setCustomPages(data.custom_pages || []);
      setProductDisplayConfig({ ...DEFAULT_PRODUCT_DISPLAY, ...(data.product_display_config || {}) });

      // ★ NEW — mark app as ready to render (hard gate opens)
      setReady(true);

      // Clear any previous error on successful fetch (only if there was one)
      setError(null);
    } catch (e) {
      console.error("[TenantProvider] Layout fetch failed:", e?.message);
      // Only set error on initial fetch — don't disrupt the UI during polls
      // (the previous data is still showing, no need to scare the user).
      if (isInitial) {
        setError(e?.message);
        setSections([]);
      }
      // On poll failure: keep the existing data visible, just log it.
    } finally {
      // Mark first fetch as done — all future calls are silent polls.
      isFirstFetchRef.current = false;
      if (isInitial) {
        setIsLoading(false);
      }
    }
  };
  // ★ NEW — Update document title + favicon dynamically from tenant theme
  useEffect(() => {
    if (theme.brand_name) {
      document.title = `Welcome to ${theme.brand_name}`;
    }
    if (theme.logo_url) {
      let link = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = theme.logo_url;
    }
  }, [theme.brand_name, theme.logo_url]);
  // Keep the ref current
  useEffect(() => {
    fetchLayoutRef.current = fetchLayout;
  });

  // Initial fetch when tenantId changes
  useEffect(() => {
    // ★ Reset first-fetch flag + data signature when tenant changes —
    // switching tenants should show the loading spinner again, and
    // shouldn't skip the fetch due to a stale signature match.
    isFirstFetchRef.current = true;
    lastDataSignatureRef.current = null;
    fetchLayout(tenantId);
  }, [tenantId]);

  // ★ Polling fallback — re-fetch every 30 seconds
  // Picks up admin changes within ~30s without needing Pusher.
  useEffect(() => {
    if (!tenantId) return;
    const interval = setInterval(() => {
      if (fetchLayoutRef.current) {
        fetchLayoutRef.current(tenantId);
      }
    }, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [tenantId]);

  // Re-resolve tenant on browser navigation (subdomain may have changed)
  useEffect(() => {
    const onPop = () => {
      const newTid = resolveTenantId();
      if (newTid !== tenantId) setTenantId(newTid);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [tenantId]);

  // Inject CSS variables for advanced theme (Step 2)
  useEffect(() => {
    const root = document.documentElement;
    if (theme.primary_color) root.style.setProperty("--color-primary", theme.primary_color);
    if (theme.secondary_color) root.style.setProperty("--color-secondary", theme.secondary_color);
    if (theme.font_family) {
      root.style.setProperty("--font-family", theme.font_family);
      document.body.style.fontFamily = theme.font_family;
    }
    root.style.setProperty("--border-radius", (theme.border_radius ?? 12) + "px");
    root.style.setProperty("--border-radius-sm", Math.max(0, (theme.border_radius ?? 12) - 6) + "px");
    root.style.setProperty("--border-radius-lg", ((theme.border_radius ?? 12) + 8) + "px");

    const shadowMap = {
      none: "none",
      subtle: "0 1px 3px rgba(0,0,0,0.04)",
      medium: "0 4px 24px rgba(0,0,0,0.06)",
      strong: "0 8px 32px rgba(0,0,0,0.10)",
    };
    root.style.setProperty("--shadow", shadowMap[theme.shadow_style] || shadowMap.medium);
    root.style.setProperty("--shadow-hover", shadowMap.strong);

    const btnRadius = theme.button_style === "square" ? "0px" : theme.button_style === "pill" ? "999px" : (theme.border_radius ?? 12) + "px";
    root.style.setProperty("--button-radius", btnRadius);

    const cardRadius = theme.card_style === "flat" ? "0px" : ((theme.border_radius ?? 12) + 8) + "px";
    root.style.setProperty("--card-radius", cardRadius);
  }, [theme]);

  const value = {
    tenantId,
    sections,
    theme,
    navigationConfig,
    footerConfig,
    customPages,
    productDisplayConfig,
    isLoading,
    error,
    ready,
    setTenantId: (tid) => {
      if (tid) localStorage.setItem("dev-tenant-override", tid);
      else localStorage.removeItem("dev-tenant-override");
      setTenantId(tid || resolveTenantId());
    },
    // ★ Manual refetch — forces a fresh fetch + bypasses the signature
    // check (so admin "Publish" can be picked up immediately even if the
    // data somehow looks the same). Still silent (no loading spinner)
    // unless it's the first fetch.
    refetch: () => {
      lastDataSignatureRef.current = null;  // force update
      return fetchLayout(tenantId);
    },
  };

  return (
    <TenantContext.Provider value={value}>
      {children}
    </TenantContext.Provider>
  );
}
