// import Pusher from 'pusher-js'

// // ─────────────────────────────────────────────────────────────────────────
// // pusherService.js  —  REVERTED to match your working setup on port 8000
// //
// // Only ONE bug fixed: host was `window.location.hostname` (= infosoft.localhost)
// // VITE_PUSHER_HOST env var with fallback to window.location.hostname.
// //
// // Set VITE_PUSHER_HOST in your .env.development and you're done.
// // ─────────────────────────────────────────────────────────────────────────

// import customerApi from '../api/customerApi'

// let pusherInstance = null
// let currentTenantId = null
// const subscribedChannels = new Map()

// // ── Config (env vars with sensible fallbacks) ──────────────────────────
// const PUSHER_APP_KEY    = import.meta.env.VITE_PUSHER_APP_KEY    || 'local-key'
// const PUSHER_CLUSTER    = import.meta.env.VITE_PUSHER_CLUSTER    || 'mt1'

// // ★ FIX: use VITE_PUSHER_HOST (your backend host), fallback to current hostname
// const PUSHER_WS_HOST    = import.meta.env.VITE_PUSHER_HOST       || window.location.hostname

// // ★ KEEP your existing port — 8000 (or whatever you had working)
// const PUSHER_WS_PORT    = parseInt(import.meta.env.VITE_PUSHER_WS_PORT  || '8000', 10)
// const PUSHER_WSS_PORT   = parseInt(import.meta.env.VITE_PUSHER_WSS_PORT || '8000', 10)

// const PUSHER_FORCE_TLS  = import.meta.env.VITE_PUSHER_FORCE_TLS === 'true' || import.meta.env.PROD

// const resolveTenantId = () => {
//   try {
//     const override = localStorage.getItem('dev-tenant-override')
//     if (override) return override
//   } catch (_) {}
//   const host = window.location.hostname.split(':')[0]
//   if (host.endsWith('.localhost')) return host.slice(0, -'.localhost'.length)
//   const parts = host.split('.')
//   if (parts.length >= 3 && !parts.every(p => /^\d+$/.test(p))) return parts[0]
//   return null
// }

// class PusherService {
//   getInstance() {
//     const tenantId = resolveTenantId()

//     if (!pusherInstance || currentTenantId !== tenantId) {
//       if (pusherInstance) {
//         pusherInstance.disconnect()
//       }
//       subscribedChannels.clear()

//       pusherInstance = new Pusher(PUSHER_APP_KEY, {
//         cluster: PUSHER_CLUSTER,
//         wsHost: PUSHER_WS_HOST,
//         wsPort: PUSHER_WS_PORT,
//         wssPort: PUSHER_WSS_PORT,
//         forceTLS: PUSHER_FORCE_TLS,
//         enabledTransports: ['ws', 'wss'],
//         // Authorize private channels via customerApi (Bearer + X-Tenant)
//         authorizer: (channel) => ({
//           authorize: (socketId, callback) => {
//             customerApi
//               .post('/broadcasting/auth', {
//                 socket_id: socketId,
//                 channel_name: channel.name,
//               })
//               .then((res) => callback(false, res.data))
//               .catch((err) => callback(true, err))
//           },
//         }),
//       })

//       currentTenantId = tenantId
//     }

//     return pusherInstance
//   }

//   subscribe(channelName) {
//     const pusher = this.getInstance()
//     if (subscribedChannels.has(channelName)) {
//       return subscribedChannels.get(channelName)
//     }

//     const fullName = channelName.startsWith('private-') || channelName.startsWith('public-')
//       ? channelName
//       : `private-${channelName}`

//     const channel = pusher.subscribe(fullName)
//     subscribedChannels.set(channelName, channel)
//     return channel
//   }

//   unsubscribe(channelName) {
//     if (!pusherInstance) return
//     const fullName = channelName.startsWith('private-') || channelName.startsWith('public-')
//       ? channelName
//       : `private-${channelName}`
//     pusherInstance.unsubscribe(fullName)
//     subscribedChannels.delete(channelName)
//   }

//   disconnect() {
//     if (pusherInstance) {
//       pusherInstance.disconnect()
//       pusherInstance = null
//       currentTenantId = null
//       subscribedChannels.clear()
//     }
//   }

//   getCurrentTenant() {
//     return currentTenantId
//   }
// }

// const pusherService = new PusherService()
// export default pusherService
