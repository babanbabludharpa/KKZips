import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, MapPin, Pause, Play, X, Edit3 } from "lucide-react";
import customerApi from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";

const theme = {
  primary: "#FF7132", primaryHover: "#EA580C", dark: "#1E293B",
  mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0",
};

const STATUS_COLORS = {
  active:         { bg: "#dcfce7", fg: "#15803d" },
  paused:         { bg: "#fef9c3", fg: "#a16207" },
  cancelled:      { bg: "#fee2e2", fg: "#b91c1c" },
  expired:        { bg: "#f3f4f6", fg: "#6b7280" },
  pending:        { bg: "#fef9c3", fg: "#a16207" },
  delivered:      { bg: "#dcfce7", fg: "#15803d" },
  not_delivered:  { bg: "#fee2e2", fg: "#b91c1c" },
  skipped:        { bg: "#f3f4f6", fg: "#6b7280" },
  holiday_skipped:{ bg: "#FEF2F2", fg: "#B91C1C" },
};

const DAYS           = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const SCHEDULE_LABELS= { daily:"Daily", alternate:"Alternate Days", weekly:"Weekly", custom_days:"Custom Days", custom_dates:"Custom Dates" };

// ════════════════════════════════════════════════════════
// Date helpers
// ════════════════════════════════════════════════════════
function toLocalISOString(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function toDateOnly(val) {
  if (!val) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(val)) return val;
  const d = new Date(val);
  if (isNaN(d.getTime())) return "";
  return toLocalISOString(d);
}

const fmtDate = (val) => {
  const d = toDateOnly(val);
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
    day: "2-digit", month: "short", year: "numeric",
  });
};

const fmtShort = (val) => {
  const d = toDateOnly(val);
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
    day: "2-digit", month: "short",
  });
};

export default function SubscriptionDetail() {
  const { id }           = useParams();
  const navigate         = useNavigate();
  const { isAuthenticated } = useCustomerAuth();
  const { theme: tenantTheme } = useTenant() || {};
  const primaryColor = tenantTheme?.primary_color || "#FF7132";
  const accentColor  = tenantTheme?.secondary_color || "#EA580C";

  const [sub,          setSub]          = useState(null);
  const [occurrences,  setOccurrences]  = useState([]);
  const [itemPauses,   setItemPauses]   = useState({});
  const [loading,      setLoading]      = useState(true);
  const [actionLoading,setActionLoading]= useState(false);
  const [error,        setError]        = useState(null);
  const [toast,        setToast]        = useState(null);
  const [pauseModal,   setPauseModal]   = useState(null);
  const [qtyModal,     setQtyModal]     = useState(null);

  const todayStr = toLocalISOString(new Date());

  const showToast = (msg, kind = "success") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3500);
  };

  // ════════════════════════════════════════════════════════
  // Fetch pauses via schedule endpoint (only POST exists on /pauses)
  // ════════════════════════════════════════════════════════
  const fetchItemPauses = async (items) => {
    if (!items || items.length === 0) return;

    const now = new Date();
    const pausesMap = {};

    await Promise.all(items.map(async (item) => {
      try {
        const currYear  = now.getFullYear();
        const currMonth = now.getMonth() + 1;
        const nextYear  = now.getMonth() === 11 ? now.getFullYear() + 1 : now.getFullYear();
        const nextMonth = now.getMonth() === 11 ? 1 : now.getMonth() + 2;

        const [currRes, nextRes] = await Promise.all([
          customerApi.get(`/mobile/subscriptions/items/${item.id}/schedule`, {
            params: { year: currYear, month: currMonth },
          }),
          customerApi.get(`/mobile/subscriptions/items/${item.id}/schedule`, {
            params: { year: nextYear, month: nextMonth },
          }),
        ]);

        const currPauses = currRes.data?.data?.pauses || [];
        const nextPauses = nextRes.data?.data?.pauses || [];
        const all        = [...currPauses, ...nextPauses];

        const seen = new Set();
        const unique = all.filter(p => {
          if (!p?.id || seen.has(p.id)) return false;
          seen.add(p.id);
          return true;
        });

        pausesMap[item.id] = unique.map(p => ({
          ...p,
          date_from: toDateOnly(p.date_from),
          date_to:   toDateOnly(p.date_to),
        }));
      } catch (e) {
        console.error(`fetchItemPauses failed for item ${item.id}:`, e?.response?.data);
        pausesMap[item.id] = [];
      }
    }));

    setItemPauses(pausesMap);
  };

  // ════════════════════════════════════════════════════════
  // Refresh all data
  // ════════════════════════════════════════════════════════
  const refresh = async () => {
    try {
      const [subRes, occRes] = await Promise.all([
        customerApi.get(`/mobile/subscriptions/${id}`),
        customerApi.get(`/mobile/subscriptions/${id}/upcoming-occurrences`),
      ]);
      const subData = subRes.data?.data || null;
      setSub(subData);
      setOccurrences(Array.isArray(occRes.data?.data) ? occRes.data.data : []);
      if (subData?.items) await fetchItemPauses(subData.items);
    } catch (e) {
      console.error("Refresh failed:", e);
    }
  };

  // ════════════════════════════════════════════════════════
  // Initial load
  // ════════════════════════════════════════════════════════
  useEffect(() => {
    if (!isAuthenticated) { navigate("/", { replace: true }); return; }

    const load = async () => {
      try {
        const [subRes, occRes] = await Promise.all([
          customerApi.get(`/mobile/subscriptions/${id}`),
          customerApi.get(`/mobile/subscriptions/${id}/upcoming-occurrences`),
        ]);
        const subData = subRes.data?.data || null;
        setSub(subData);
        setOccurrences(Array.isArray(occRes.data?.data) ? occRes.data.data : []);
        if (subData?.items) await fetchItemPauses(subData.items);
      } catch (e) {
        console.error("Load failed:", e);
        setError(e?.response?.data?.message || "Failed to load subscription.");
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [id, isAuthenticated, navigate]);

  // ════════════════════════════════════════════════════════
  // Subscription-level actions
  // ════════════════════════════════════════════════════════
  const pauseSub = async () => {
    const reason = window.prompt("Reason for pausing (optional):") || null;
    setActionLoading(true);
    try {
      await customerApi.post(`/mobile/subscriptions/${id}/pause`, { reason });
      showToast("Subscription paused.");
      await refresh();
    } catch (e) {
      console.error("Pause sub failed:", e?.response?.data);
      showToast(e?.response?.data?.message || "Failed to pause.", "error");
    } finally { setActionLoading(false); }
  };

  const resumeSub = async () => {
    setActionLoading(true);
    try {
      await customerApi.post(`/mobile/subscriptions/${id}/resume`, {});
      showToast("Subscription resumed.");
      await refresh();
    } catch (e) {
      console.error("Resume sub failed:", e?.response?.data);
      showToast(e?.response?.data?.message || "Failed to resume.", "error");
    } finally { setActionLoading(false); }
  };

  const cancelSub = async () => {
    if (!window.confirm("Cancel this subscription permanently?")) return;
    const reason = window.prompt("Reason (optional):") || null;
    setActionLoading(true);
    try {
      await customerApi.post(`/mobile/subscriptions/${id}/cancel`, { reason });
      showToast("Subscription cancelled.");
      await refresh();
    } catch (e) {
      console.error("Cancel sub failed:", e?.response?.data);
      showToast(e?.response?.data?.message || "Failed to cancel.", "error");
    } finally { setActionLoading(false); }
  };

  // ════════════════════════════════════════════════════════
  // Per-item pause actions
  // ════════════════════════════════════════════════════════
  const submitItemPause = async (itemId, dateFrom, dateTo, reason) => {
    try {
      const payload = { date_from: dateFrom, date_to: dateTo, reason };
      await customerApi.post(`/mobile/subscriptions/items/${itemId}/pauses`, payload);
      showToast("Pause applied.");
      setPauseModal(null);
      await refresh();
    } catch (e) {
      console.error("Create pause failed:", e?.response?.data);
      showToast(e?.response?.data?.message || "Failed to apply pause.", "error");
    }
  };

  const cancelItemPause = async (pauseId, itemName) => {
    if (!window.confirm(
      `Resume deliveries for "${itemName}"?\n\nThis cancels the selected pause — deliveries will resume normally.`
    )) return;

    setActionLoading(true);
    try {
      await customerApi.delete(`/mobile/subscriptions/pauses/${pauseId}`);
      showToast("Pause cancelled — deliveries will resume.");
      await refresh();
    } catch (e) {
      console.error("Cancel pause failed:", e?.response?.status, e?.response?.data);
      if (e?.response?.status === 404)
        showToast("Pause not found — may already be cancelled.", "error");
      else if (e?.response?.status === 403)
        showToast("No permission to cancel this pause.", "error");
      else
        showToast(e?.response?.data?.message || "Failed to cancel pause.", "error");
    } finally { setActionLoading(false); }
  };

  const submitQtyOverride = async (itemId, dateFrom, dateTo, qty, reason) => {
    try {
      const payload = { date_from: dateFrom, date_to: dateTo, qty, reason };
      await customerApi.post(`/mobile/subscriptions/items/${itemId}/qty-overrides`, payload);
      showToast("Quantity updated.");
      setQtyModal(null);
      await refresh();
    } catch (e) {
      console.error("Qty override failed:", e?.response?.data);
      showToast(e?.response?.data?.message || "Failed to update quantity.", "error");
    }
  };

  // ════════════════════════════════════════════════════════
  // Loading / Error / Not-found
  // ════════════════════════════════════════════════════════
  if (loading) return (
    <div style={{ minHeight:"100vh", background:theme.bg, display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ textAlign:"center" }}>
        <div style={{ width:40, height:40, border:`4px solid ${theme.border}`, borderTopColor:primaryColor, borderRadius:"50%", margin:"0 auto 16px", animation:"spin 0.8s linear infinite" }} />
        <div style={{ color:theme.mid }}>Loading…</div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    </div>
  );

  if (error) return (
    <div style={{ minHeight:"100vh", background:theme.bg, display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}>
      <div style={{ background:"#fff", borderRadius:16, padding:32, textAlign:"center", maxWidth:400, border:`1px solid ${theme.border}` }}>
        <div style={{ fontSize:48, marginBottom:16 }}>⚠️</div>
        <h3 style={{ margin:"0 0 8px", color:theme.dark }}>Error</h3>
        <p style={{ color:theme.mid, fontSize:"0.9rem", marginBottom:16 }}>{error}</p>
        <button onClick={() => navigate("/subscription")} style={{ background:primaryColor, color:"#fff", border:"none", borderRadius:8, padding:"10px 20px", fontWeight:600, cursor:"pointer" }}>Back to List</button>
      </div>
    </div>
  );

  if (!sub) return (
    <div style={{ minHeight:"100vh", background:theme.bg, display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}>
      <div style={{ background:"#fff", borderRadius:16, padding:32, textAlign:"center", maxWidth:400, border:`1px solid ${theme.border}` }}>
        <div style={{ fontSize:48, marginBottom:16 }}>🔍</div>
        <h3 style={{ margin:"0 0 8px", color:theme.dark }}>Not Found</h3>
        <p style={{ color:theme.mid, fontSize:"0.9rem", marginBottom:16 }}>This subscription doesn't exist.</p>
        <button onClick={() => navigate("/subscription")} style={{ background:primaryColor, color:"#fff", border:"none", borderRadius:8, padding:"10px 20px", fontWeight:600, cursor:"pointer" }}>Back to List</button>
      </div>
    </div>
  );

  const subItems       = Array.isArray(sub.items) ? sub.items : [];
  const subStatus      = STATUS_COLORS[sub.status] || STATUS_COLORS.expired;
  const subOccurrences = Array.isArray(occurrences) ? occurrences : [];

  // ★ Group skipped occurrences by reason for the banner.
  const skippedByReason = {};
  subOccurrences.forEach(o => {
    if (o?.status === 'holiday_skipped') {
      const r = o.leave_cancellation_reason || 'Store closed';
      skippedByReason[r] = (skippedByReason[r] || 0) + 1;
    }
  });
  const skippedTotal = Object.values(skippedByReason).reduce((a, b) => a + b, 0);

  return (
    <div style={{ minHeight:"100vh", background:theme.bg, paddingBottom:40 }}>

      {/* ── Hero ── */}
      <div style={{ background:`linear-gradient(135deg, ${primaryColor}, ${accentColor})`, padding:"40px 24px 60px", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"relative", zIndex:1, maxWidth:900, margin:"0 auto" }}>
          <button
            onClick={() => navigate("/subscription")}
            style={{ display:"inline-flex", alignItems:"center", gap:6, background:"rgba(255,255,255,0.15)", border:"1px solid rgba(255,255,255,0.2)", color:"#fff", padding:"8px 16px", borderRadius:100, fontSize:"0.85rem", fontWeight:600, cursor:"pointer", marginBottom:16 }}
          >
            <ArrowLeft size={14} /> Back
          </button>

          <div style={{ display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
            <h1 style={{ color:"#fff", fontSize:"clamp(1.5rem,4vw,2rem)", fontWeight:900, margin:0 }}>
              Subscription #{sub.id || "?"}
            </h1>
            {sub.status && (
              <span style={{ background:subStatus.bg, color:subStatus.fg, padding:"4px 12px", borderRadius:999, fontSize:"0.75rem", fontWeight:700, textTransform:"uppercase" }}>
                {sub.status}
              </span>
            )}
          </div>

          <div style={{ color:"rgba(255,255,255,0.85)", fontSize:"0.9rem", marginTop:8, display:"flex", gap:16, flexWrap:"wrap" }}>
            <span>📅 {fmtDate(sub.start_date)}{sub.end_date ? ` → ${fmtDate(sub.end_date)}` : " (ongoing)"}</span>
            {sub.branch_name && <span>🏪 {sub.branch_name}</span>}
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      <div style={{ maxWidth:900, margin:"-32px auto 0", padding:"0 24px", position:"relative", zIndex:10 }}>

        {/* ── Action bar ── */}
        <div style={{ display:"flex", gap:8, marginBottom:16, flexWrap:"wrap" }}>
          {sub.status === "active" && (
            <button onClick={pauseSub} disabled={actionLoading} style={btnStyle("warning", primaryColor)}>
              <Pause size={14} /> {actionLoading ? "…" : "Pause All"}
            </button>
          )}
          {sub.status === "paused" && (
            <button onClick={resumeSub} disabled={actionLoading} style={btnStyle("primary", primaryColor)}>
              <Play size={14} /> {actionLoading ? "Resuming…" : "Resume Subscription"}
            </button>
          )}
          {["active","paused"].includes(sub.status) && (
            <button onClick={cancelSub} disabled={actionLoading} style={btnStyle("danger", primaryColor)}>
              <X size={14} /> {actionLoading ? "…" : "Cancel"}
            </button>
          )}
        </div>

        {/* ★ Store-closure banner */}
        {skippedTotal > 0 && (
          <div style={{
            background:"#FEF2F2", border:"1px solid #FECACA",
            borderRadius:10, padding:"12px 14px", marginBottom:16,
            display:"flex", gap:10, alignItems:"flex-start",
            fontSize:"0.85rem", color:"#7F1D1D",
          }}>
            <span style={{ fontSize:"1rem", flexShrink:0 }}>⚠️</span>
            <div>
              <strong>{skippedTotal} upcoming deliver{skippedTotal === 1 ? "y is" : "ies are"} skipped — store closed.</strong>
              <div style={{ marginTop:4, fontSize:"0.78rem", color:"#991B1B" }}>
                {Object.entries(skippedByReason).map(([reason, count]) => (
                  <div key={reason}>
                    {count} deliver{count === 1 ? "y" : "ies"} — <em>{reason}</em>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── DEV debug panel ── */}
        {process.env.NODE_ENV === "development" && (
          <div style={{ background:"#1E293B", color:"#94A3B8", borderRadius:8, padding:12, marginBottom:16, fontSize:"0.7rem", fontFamily:"monospace" }}>
            <div style={{ color:"#FF7132", fontWeight:700, marginBottom:4 }}>🔧 DEBUG</div>
            <div>Status: <b style={{ color:"#fff" }}>{sub.status}</b> | Today: <b style={{ color:"#fff" }}>{todayStr}</b></div>
            <div>Items: <b style={{ color:"#fff" }}>{subItems.length}</b> | Occurrences: <b style={{ color:"#fff" }}>{subOccurrences.length}</b> | Skipped: <b style={{ color:"#EF4444" }}>{skippedTotal}</b></div>
            {subItems.map(item => (
              <div key={item.id}>
                Item {item.id} pauses: <b style={{ color:"#4ADE80" }}>{JSON.stringify(itemPauses[item.id] || [])}</b>
              </div>
            ))}
          </div>
        )}

        {/* ── Items ── */}
        <h2 style={{ fontSize:"1.1rem", fontWeight:700, color:theme.dark, marginBottom:12 }}>
          Items ({subItems.length})
        </h2>

        <div style={{ display:"flex", flexDirection:"column", gap:12, marginBottom:24 }}>

          {subItems.length === 0 && (
            <div style={{ background:"#fff", borderRadius:14, padding:24, textAlign:"center", color:theme.mid, border:`1px solid ${theme.border}` }}>
              No items in this subscription.
            </div>
          )}

          {subItems.map(item => {
            const itemStatus = STATUS_COLORS[item.status] || STATUS_COLORS.active;
            const itemOccs   = subOccurrences.filter(o => o && o.subscription_item_id === item.id);
            const variant    = item.variant || {};
            const img        = variant.image_url || null;
            const productName= item.product_name || "Product";

            const pauses       = itemPauses[item.id] || [];
            const activePauses = pauses.filter(p => p?.date_to >= todayStr);
            const pastPauses   = pauses.filter(p => p?.date_to  < todayStr);

            return (
              <div key={item.id} style={{ background:"#fff", borderRadius:14, padding:16, border:`1px solid ${theme.border}`, boxShadow:"0 1px 3px rgba(0,0,0,0.04)" }}>

                {/* Item header */}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, flexWrap:"wrap", marginBottom:8 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    {img && (
                      <img src={img} alt="" style={{ width:48, height:48, borderRadius:8, objectFit:"cover" }}
                        onError={(e) => e.target.style.display = "none"} />
                    )}
                    <div>
                      <h3 style={{ margin:0, fontSize:"1rem", fontWeight:700 }}>{productName}</h3>
                      <div style={{ fontSize:"0.78rem", color:theme.mid, display:"flex", gap:8, flexWrap:"wrap", marginTop:2 }}>
                        <span>×{item.default_qty || 1}</span>
                        <span>•</span>
                        <span>
                          {item.slot
                            ? `${item.slot.name} (${item.slot.start_time?.slice(0, 5)}–${item.slot.end_time?.slice(0, 5)})`
                            : '—'}
                        </span>
                        <span>•</span>
                        <span>{SCHEDULE_LABELS[item.schedule_type] || item.schedule_type || "—"}</span>
                        {(item.schedule_type === "custom_days" || item.schedule_type === "weekly") &&
                          Array.isArray(item.schedule_days) && item.schedule_days.length > 0 && (
                          <span>• {item.schedule_days.map(d => DAYS[d] || "?").join(", ")}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <span style={{ background:itemStatus.bg, color:itemStatus.fg, padding:"2px 8px", borderRadius:6, fontSize:"0.7rem", fontWeight:700 }}>
                    {item.status || "active"}
                  </span>
                </div>

                {/* Per-item actions */}
                {item.status === "active" && sub.status === "active" && (
                  <div style={{ display:"flex", gap:6, marginTop:8, flexWrap:"wrap" }}>
                    <button
                      onClick={() => setPauseModal({ itemId:item.id, itemName:productName })}
                      style={btnStyle("warning", primaryColor)}
                    >
                      <Pause size={12} /> Pause Dates
                    </button>
                    <button
                      onClick={() => setQtyModal({ itemId:item.id, itemName:productName, defaultQty:item.default_qty || 1 })}
                      style={btnStyle("secondary", primaryColor)}
                    >
                      <Edit3 size={12} /> Change Qty
                    </button>
                  </div>
                )}

                {/* Active / upcoming pauses */}
                {activePauses.length > 0 && (
                  <div style={{ marginTop:10, paddingTop:10, borderTop:`1px solid ${theme.border}` }}>
                    <div style={{ fontSize:"0.72rem", color:"#A16207", textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:6, fontWeight:700 }}>
                      ⏸ Active / Upcoming Pauses
                    </div>
                    <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                      {activePauses.map(pause => {
                        if (!pause?.id) return null;
                        const isNow = pause.date_from <= todayStr && pause.date_to >= todayStr;
                        return (
                          <div
                            key={pause.id}
                            style={{
                              display:"flex", alignItems:"center", justifyContent:"space-between", gap:8,
                              padding:"8px 12px", borderRadius:8,
                              background: isNow ? "#FEF9C3" : "#EFF6FF",
                              border:`1px solid ${isNow ? "#FACC15" : "#BFDBFE"}`,
                            }}
                          >
                            <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:"0.78rem", flexWrap:"wrap" }}>
                              <Pause size={12} color={isNow ? "#A16207" : "#3B82F6"} />
                              <span style={{ fontWeight:600, color:theme.dark }}>
                                {fmtShort(pause.date_from)} → {fmtShort(pause.date_to)}
                              </span>
                              {isNow ? (
                                <span style={{ fontSize:"0.65rem", color:"#A16207", fontWeight:700, background:"#FEF08A", padding:"1px 6px", borderRadius:4 }}>NOW</span>
                              ) : (
                                <span style={{ fontSize:"0.65rem", color:"#3B82F6", fontWeight:700, background:"#DBEAFE", padding:"1px 6px", borderRadius:4 }}>UPCOMING</span>
                              )}
                              {pause.reason && <span style={{ fontSize:"0.65rem", color:theme.mid }}>"{pause.reason}"</span>}
                              {pause.initiated_by && <span style={{ fontSize:"0.65rem", color:theme.mid }}>by {pause.initiated_by}</span>}
                            </div>

                            <button
                              type="button"
                              disabled={actionLoading}
                              onClick={() => cancelItemPause(pause.id, productName)}
                              style={{
                                display:"inline-flex", alignItems:"center", gap:4,
                                padding:"5px 12px", borderRadius:6,
                                fontSize:"0.72rem", fontWeight:600,
                                background:`linear-gradient(135deg, ${primaryColor}, ${accentColor})`,
                                color:"#fff", border:"none", cursor:"pointer",
                                opacity: actionLoading ? 0.6 : 1,
                                whiteSpace:"nowrap",
                              }}
                            >
                              <Play size={10} /> {actionLoading ? "…" : "Resume"}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Past pauses */}
                {pastPauses.length > 0 && (
                  <div style={{ marginTop:8 }}>
                    <details>
                      <summary style={{ fontSize:"0.72rem", color:theme.mid, cursor:"pointer", userSelect:"none", marginBottom:4 }}>
                        {pastPauses.length} past pause{pastPauses.length > 1 ? "s" : ""}
                      </summary>
                      <div style={{ display:"flex", flexDirection:"column", gap:4, marginTop:6 }}>
                        {pastPauses.map(pause => (
                          <div key={pause.id} style={{ padding:"6px 10px", borderRadius:6, background:"#F3F4F6", border:"1px solid #E5E7EB", fontSize:"0.72rem", color:theme.mid }}>
                            {fmtShort(pause.date_from)} → {fmtShort(pause.date_to)}
                            {pause.reason && ` — "${pause.reason}"`}
                          </div>
                        ))}
                      </div>
                    </details>
                  </div>
                )}

                {/* Upcoming occurrences */}
                {itemOccs.length > 0 && (
                  <div style={{ marginTop:10, paddingTop:10, borderTop:`1px solid ${theme.border}` }}>
                    <div style={{ fontSize:"0.72rem", color:theme.mid, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:6 }}>
                      Upcoming Deliveries
                    </div>
                    <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                      {itemOccs.slice(0, 7).map(occ => {
                        if (!occ) return null;
                        const isSkipped = occ.status === 'holiday_skipped';
                        const occStatus = STATUS_COLORS[occ.status] || STATUS_COLORS.pending;
                        return (
                          <div
                            key={occ.id || Math.random()}
                            title={isSkipped && occ.leave_cancellation_reason ? `Skipped: ${occ.leave_cancellation_reason}` : ''}
                            style={{
                              display:"flex", flexDirection:"column", alignItems:"center",
                              padding:"6px 8px", borderRadius:8, minWidth:68,
                              background: isSkipped ? "#FEF2F2" : occ.is_locked ? "#f3f4f6" : theme.bg,
                              border: `1px solid ${isSkipped ? "#FECACA" : occ.is_locked ? "#e5e7eb" : theme.border}`,
                            }}
                          >
                            <span style={{
                              fontSize:"0.7rem", fontWeight:600,
                              color: isSkipped ? "#B91C1C" : theme.dark,
                              textDecoration: isSkipped ? "line-through" : "none",
                            }}>
                              {fmtShort(occ.occurrence_date)}
                            </span>
                            {isSkipped ? (
                              <span style={{ fontSize:"0.6rem", color:"#B91C1C", fontWeight:700, textAlign:"center" }}>
                                Closed
                              </span>
                            ) : (
                              <span style={{ fontSize:"0.65rem", color:occStatus.fg, fontWeight:600 }}>
                                {occ.qty || 0}× ₹{Number(occ.unit_price_snapshot || 0).toFixed(0)}
                              </span>
                            )}
                            {occ.is_locked && !isSkipped && (
                              <span style={{ fontSize:"0.55rem", color:"#9ca3af" }}>🔒</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

              </div>
            );
          })}
        </div>

        {/* Delivery address */}
        {sub.delivery_address && (
          <div style={{ background:"#fff", borderRadius:14, padding:16, border:`1px solid ${theme.border}`, marginBottom:16 }}>
            <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
              <MapPin size={16} color={primaryColor} />
              <h3 style={{ margin:0, fontSize:"0.9rem", fontWeight:700 }}>Delivery Address</h3>
            </div>
            <p style={{ margin:0, fontSize:"0.85rem", color:theme.mid }}>
              {sub.delivery_address.label || ""}: {sub.delivery_address.address_line1 || ""},{" "}
              {sub.delivery_address.city || ""}, {sub.delivery_address.state || ""}
            </p>
          </div>
        )}
      </div>

      {/* Modals */}
      {pauseModal && (
        <PauseModal
          item={pauseModal}
          onClose={() => setPauseModal(null)}
          onSubmit={submitItemPause}
          primaryColor={primaryColor}
          accentColor={accentColor}
        />
      )}
      {qtyModal && (
        <QtyModal
          item={qtyModal}
          onClose={() => setQtyModal(null)}
          onSubmit={submitQtyOverride}
          primaryColor={primaryColor}
          accentColor={accentColor}
        />
      )}

      {/* Toast */}
      {toast && (
        <motion.div
          initial={{ opacity:0, y:20 }}
          animate={{ opacity:1, y:0 }}
          style={{
            position:"fixed", bottom:24, right:24, zIndex:9999,
            background: toast.kind === "error" ? "#dc2626" : "#16a34a",
            color:"#fff", padding:"0.75rem 1.25rem", borderRadius:10,
            boxShadow:"0 10px 30px rgba(0,0,0,0.2)",
            fontWeight:500, fontSize:"0.9rem", maxWidth:320,
          }}
        >
          {toast.msg}
        </motion.div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// Pause Modal
// ════════════════════════════════════════════════════════
function PauseModal({ item, onClose, onSubmit, primaryColor, accentColor }) {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo,   setDateTo]   = useState("");
  const [reason,   setReason]   = useState("");
  const today     = toLocalISOString(new Date());
  const canSubmit = dateFrom && dateTo && dateTo >= dateFrom;

  return (
    <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.6)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:1000, padding:24 }}>
      <motion.div
        initial={{ scale:0.9, opacity:0 }}
        animate={{ scale:1, opacity:1 }}
        onClick={(e) => e.stopPropagation()}
        style={{ background:"#fff", borderRadius:16, maxWidth:440, width:"100%", padding:24 }}
      >
        <h3 style={{ margin:"0 0 4px", fontSize:"1.1rem", fontWeight:800 }}>Pause: {item.itemName}</h3>
        <p style={{ margin:"0 0 16px", fontSize:"0.82rem", color:theme.mid }}>
          Select a date range to pause deliveries for this item only.
        </p>

        <label style={{ fontSize:"0.72rem", color:theme.mid, marginBottom:2, display:"block" }}>From</label>
        <input type="date" value={dateFrom} min={today}
          onChange={(e) => setDateFrom(e.target.value)}
          style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none", marginBottom:8 }}
        />

        <label style={{ fontSize:"0.72rem", color:theme.mid, marginBottom:2, display:"block" }}>To</label>
        <input type="date" value={dateTo} min={dateFrom || today}
          onChange={(e) => setDateTo(e.target.value)}
          style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none", marginBottom:8 }}
        />

        <input type="text" value={reason} onChange={(e) => setReason(e.target.value)}
          placeholder="Reason (optional)"
          style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none", marginBottom:16 }}
        />

        <div style={{ display:"flex", gap:8 }}>
          <button type="button" onClick={onClose}
            style={{ flex:1, padding:"10px", borderRadius:8, border:`1px solid ${theme.border}`, background:"#fff", color:theme.dark, fontWeight:600, cursor:"pointer" }}>
            Cancel
          </button>
          <button type="button" onClick={() => onSubmit(item.itemId, dateFrom, dateTo, reason || null)}
            disabled={!canSubmit}
            style={{ flex:1, padding:"10px", borderRadius:8, border:"none", background:!canSubmit ? "#E2E8F0" : `linear-gradient(135deg, ${primaryColor}, ${accentColor})`, color:!canSubmit ? "#94A3B8" : "#fff", fontWeight:700, cursor:!canSubmit ? "not-allowed" : "pointer" }}>
            Apply Pause
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// Qty Override Modal
// ════════════════════════════════════════════════════════
function QtyModal({ item, onClose, onSubmit, primaryColor, accentColor }) {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo,   setDateTo]   = useState("");
  const [qty,      setQty]      = useState(item.defaultQty || 1);
  const [reason,   setReason]   = useState("");
  const today     = toLocalISOString(new Date());
  const canSubmit = dateFrom && dateTo && dateTo >= dateFrom && qty >= 0;

  return (
    <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.6)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:1000, padding:24 }}>
      <motion.div
        initial={{ scale:0.9, opacity:0 }}
        animate={{ scale:1, opacity:1 }}
        onClick={(e) => e.stopPropagation()}
        style={{ background:"#fff", borderRadius:16, maxWidth:440, width:"100%", padding:24 }}
      >
        <h3 style={{ margin:"0 0 4px", fontSize:"1.1rem", fontWeight:800 }}>Change Qty: {item.itemName}</h3>
        <p style={{ margin:"0 0 16px", fontSize:"0.82rem", color:theme.mid }}>
          Temporarily change the delivery quantity. Default: {item.defaultQty}
        </p>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
          <div>
            <label style={{ fontSize:"0.72rem", color:theme.mid, marginBottom:2, display:"block" }}>From</label>
            <input type="date" value={dateFrom} min={today}
              onChange={(e) => setDateFrom(e.target.value)}
              style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none" }}
            />
          </div>
          <div>
            <label style={{ fontSize:"0.72rem", color:theme.mid, marginBottom:2, display:"block" }}>To</label>
            <input type="date" value={dateTo} min={dateFrom || today}
              onChange={(e) => setDateTo(e.target.value)}
              style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none" }}
            />
          </div>
        </div>

        <label style={{ fontSize:"0.72rem", color:theme.mid, marginBottom:2, display:"block" }}>New Quantity</label>
        <input type="number" min="0" value={qty} onChange={(e) => setQty(e.target.value)}
          style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none", marginBottom:8 }}
        />

        <input type="text" value={reason} onChange={(e) => setReason(e.target.value)}
          placeholder="Reason (optional)"
          style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1px solid ${theme.border}`, fontSize:"0.9rem", outline:"none", marginBottom:16 }}
        />

        <div style={{ display:"flex", gap:8 }}>
          <button type="button" onClick={onClose}
            style={{ flex:1, padding:"10px", borderRadius:8, border:`1px solid ${theme.border}`, background:"#fff", color:theme.dark, fontWeight:600, cursor:"pointer" }}>
            Cancel
          </button>
          <button type="button" onClick={() => onSubmit(item.itemId, dateFrom, dateTo, parseInt(qty), reason || null)}
            disabled={!canSubmit}
            style={{ flex:1, padding:"10px", borderRadius:8, border:"none", background:!canSubmit ? "#E2E8F0" : `linear-gradient(135deg, ${primaryColor}, ${accentColor})`, color:!canSubmit ? "#94A3B8" : "#fff", fontWeight:700, cursor:!canSubmit ? "not-allowed" : "pointer" }}>
            Apply
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// Button style helper
// ════════════════════════════════════════════════════════
function btnStyle(kind, primary) {
  const map = {
    primary:   { background: primary || theme.primary, color:"#fff", border:"none" },
    secondary: { background:"#fff", color:theme.dark, border:`1px solid ${theme.border}` },
    warning:   { background:"#fff", color:"#a16207", border:"1px solid #facc15" },
    danger:    { background:"#fff", color:"#b91c1c", border:"1px solid #fecaca" },
  };
  const s = map[kind] || map.primary;
  return { ...s, padding:"0.4rem 0.85rem", borderRadius:8, fontSize:"0.8rem", fontWeight:600, cursor:"pointer", display:"inline-flex", alignItems:"center", gap:4 };
}