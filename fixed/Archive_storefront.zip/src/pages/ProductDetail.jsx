import { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Star, Minus, Plus, ShoppingCart, Zap, ChevronDown, ChevronRight, ChevronLeft,
  Check, X, Sparkles, Leaf, ShieldCheck, Gift, Award, BadgeCheck, Truck, MapPin, Play,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import { useCart } from "./CartContext";
import { useCustomerAuth } from "../store/useCustomerAuth";
import customerApi from "../api/customerApi";
import CartDrawer from "../components/CartDrawer";

const HL_ICONS = { Leaf, Shield: ShieldCheck, Gift, Award, Badge: BadgeCheck, Sparkles };
const fmt = (n) => `₹${Number(n || 0).toFixed(2)}`;

// ★ Variant media ready: ordered images + videos per variant (new API),
// with legacy single-image / product-image fallback. Accepts URL strings
// or {url} / {image_url} objects.
const collectMedia = (variant, product) => {
  const out = [];
  const seen = new Set();
  const asUrl = (u) => (typeof u === "string" ? u : u?.url || u?.image_url);
  const push = (type, u) => {
    const url = asUrl(u);
    if (!url || seen.has(url)) return;
    seen.add(url);
    out.push({ type, url });
  };
  (variant?.images || []).forEach((u) => push("image", u));   // new API — already ordered
  (variant?.videos || []).forEach((u) => push("video", u));   // new API — already ordered
  push("image", variant?.image_url);                          // legacy column
  (Array.isArray(product?.images) ? product.images : [product?.image_url])
    .forEach((u) => push("image", u));                        // product-level fallback
  return out;
};

// ★ First image of a variant — wherever a single image is needed (cart, related).
const firstImage = (v) => {
  if (!v) return null;
  if (v.image_url) return v.image_url;
  const u = (v.images || [])[0];
  return typeof u === "string" ? u : (u?.url || u?.image_url || null);
};

function extractLatLng(addr) {
  if (!addr) return null;
  let lat = null, lng = null;
  for (const f of ["latitude", "lat", "Latitude"]) {
    if (addr[f] !== undefined && addr[f] !== null && addr[f] !== "") {
      lat = parseFloat(addr[f]); if (!isNaN(lat)) break; lat = null;
    }
  }
  for (const f of ["longitude", "lng", "long", "Longitude"]) {
    if (addr[f] !== undefined && addr[f] !== null && addr[f] !== "") {
      lng = parseFloat(addr[f]); if (!isNaN(lng)) break; lng = null;
    }
  }
  return lat === null || lng === null ? null : { lat, lng };
}

const Stars = ({ value = 0, size = 14 }) => (
  <div style={{ display: "flex", gap: 2 }}>
    {[1, 2, 3, 4, 5].map((i) => (
      <Star key={i} size={size}
        color={i <= Math.round(value) ? "#F59E0B" : "#CBD5E1"}
        fill={i <= Math.round(value) ? "#F59E0B" : "none"} />
    ))}
  </div>
);

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, setIsCartOpen } = useCart();
  const { isAuthenticated } = useCustomerAuth();
  const { theme, productDisplayConfig } = useTenant() || {};
  // ★ NEW — same suggestions config that powers the cart drawer strip
  const suggestCfg = productDisplayConfig?.cart_suggestions || {};
  const linkToCartSuggestions = suggestCfg.show_on_pdp === true && suggestCfg.enabled !== false;

  const PRIMARY = theme?.primary_color || "#FF7132";
  const DARK = theme?.secondary_color || "#1E293B";

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [relatedPool, setRelatedPool] = useState([]);
  const [selectedAttrs, setSelectedAttrs] = useState({});
  const [qty, setQty] = useState(1);
  const [activeMedia, setActiveMedia] = useState(0);
  const [toast, setToast] = useState(null);
  const [faqOpen, setFaqOpen] = useState(null);
  const [reviewFilter, setReviewFilter] = useState(null);   // null = all, or 1–5
  const [reviewSort, setReviewSort] = useState("recent");
  const [reviewSearch, setReviewSearch] = useState("");
  const [reviewLimit, setReviewLimit] = useState(6);        // ★ paginate instead of endless list
  const [lightbox, setLightbox] = useState(null);

  // ★ Location (same pattern as your Products page)
  const [latLng, setLatLng] = useState(null);
  const [isDeliverable, setIsDeliverable] = useState(true);
  const [locNote, setLocNote] = useState(null);

  const showToast = (msg, kind = "success") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 2500);
  };

  const askBrowserLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setLatLng({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setLocNote("Allow location access or log in with a saved address to see accurate stock for your area."),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
    );
  };

  useEffect(() => {
    if (!isAuthenticated) { askBrowserLocation(); return; }
    (async () => {
      try {
        const res = await customerApi.get("/mobile/addresses");
        const addrs = res.data?.data || [];
        const def = addrs.find((a) => a.is_default) || addrs[0];
        const ll = extractLatLng(def);
        if (ll) setLatLng(ll); else askBrowserLocation();
      } catch { askBrowserLocation(); }
    })();
  }, [isAuthenticated]);

  // ── Load product (re-fetches when coords arrive, like Products page) ──
  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError(null);
    const params = {};
    if (latLng) { params.lat = latLng.lat; params.lng = latLng.lng; }
    customerApi.get(`/mobile/products/${id}`, { params })
      .then((res) => {
        const d = res.data?.data;
        const p = d?.variants ? d : (d?.product || d);
        if (!cancelled) {
          if (p && p.id) {
            setProduct(p);
            const first = (p.variants || [])[0] || {};
            const attrs = {};
            (first.attributes || []).forEach((a) => { attrs[a.attribute_name || a.name] = a.value; });
            setSelectedAttrs(attrs);
            setQty(1);
            // ★ Same delivery heuristic as your Products page:
            // sent coords + ALL variants null stock → outside delivery zone
            const vs = p.variants || [];
            if (latLng && vs.length > 0 && vs.every((v) => v.available_stock === null || v.available_stock === undefined)) {
              setIsDeliverable(false);
            } else setIsDeliverable(true);
          } else setError("Product not found.");
        }
      })
      .catch(() => { if (!cancelled) setError("Could not load this product."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id, latLng]);

  // ── "You May Also Like" pool — one fetch, config decides the order ──
  useEffect(() => {
    if (!product?.id) return;
    let cancelled = false;
    customerApi.get("/mobile/products", { params: { limit: 50 } })
      .then((res) => {
        const d = res.data?.data;
        const list = Array.isArray(d) ? d : Array.isArray(d?.data) ? d.data : [];
        if (!cancelled) setRelatedPool(list);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [product?.id]);

    // ★ NEW — build the "You May Also Like" list:
  //   linked mode: admin's cart picks first (admin order), then auto-fill
  //   fallback mode: same category first, then newest products overall
  const related = useMemo(() => {
    if (!product?.id) return [];
    const maxItems = Math.max(1, Math.min(10, parseInt(suggestCfg.max_items) || 5));
    const pool = [...relatedPool]
      .filter((p) => p.id !== product.id)
      .sort((a, b) => b.id - a.id); // newest first
    const sameCat = pool.filter((p) => p.category_id === product.category_id);

    // base order: same category first, then the rest, deduped
    const ordered = [];
    const seen = new Set();
    [...sameCat, ...pool].forEach((p) => {
      if (!seen.has(p.id)) { seen.add(p.id); ordered.push(p); }
    });

    let candidates = ordered;
    if (linkToCartSuggestions) {
      const byId = new Map(ordered.map((p) => [p.id, p]));
      const picks = [];
      const pickSeen = new Set();
      (suggestCfg.items || []).forEach((it) => {
        const p = byId.get(Number(it.product_id));
        if (p && !pickSeen.has(p.id)) { pickSeen.add(p.id); picks.push(p); }
      });
      candidates = [...picks, ...ordered.filter((p) => !pickSeen.has(p.id))];
    }
    return candidates.slice(0, maxItems);
  }, [relatedPool, product, suggestCfg, linkToCartSuggestions]);

  const relatedTitle = (linkToCartSuggestions && suggestCfg.title) || "You May Also Like";

  // ── Variant logic ──
  const variants = useMemo(() => product?.variants || [], [product]);

  const attributeGroups = useMemo(() => {
    const map = {};
    variants.forEach((v) => (v.attributes || []).forEach((a) => {
      const k = a.attribute_name || a.name;
      if (!map[k]) map[k] = [];
      if (!map[k].includes(a.value)) map[k].push(a.value);
    }));
    return Object.entries(map);
  }, [variants]);

  const activeVariant = useMemo(() => {
    if (!variants.length) return null;
    const exact = variants.find((v) =>
      (v.attributes || []).every((a) => selectedAttrs[a.attribute_name || a.name] === a.value));
    if (exact) return exact;
    const partial = variants.find((v) =>
      (v.attributes || []).some((a) => selectedAttrs[a.attribute_name || a.name] === a.value));
    return partial || variants[0];
  }, [variants, selectedAttrs]);

  const media = useMemo(() => collectMedia(activeVariant, product), [activeVariant, product]);
  const current = media[activeMedia] || media[0];
  useEffect(() => { setActiveMedia(0); }, [activeVariant?.id]);
  useEffect(() => { setReviewFilter(null); setReviewSearch(""); setReviewLimit(6); }, [id]);
  

  const price = activeVariant ? (activeVariant.final_price ?? activeVariant.selling_price ?? activeVariant.mrp ?? 0) : 0;
  const mrp = activeVariant?.mrp || 0;
  const hasDiscount = mrp > price;
  const saveAmt = hasDiscount ? mrp - price : 0;
  const savePct = hasDiscount ? Math.round((saveAmt / mrp) * 100) : 0;

  // ★ Same OOS convention as your Products page
  const oos = !isDeliverable || activeVariant?.is_out_of_stock === true ||
    (activeVariant?.available_stock !== null && activeVariant?.available_stock !== undefined && activeVariant?.available_stock <= 0);
  const stock = activeVariant?.available_stock;
  const lowStock = !oos && stock !== null && stock !== undefined && stock > 0 && stock <= 5;
  const maxQty = stock === null || stock === undefined ? 99 : Math.max(1, stock);

  const isValueAvailable = (name, value) =>
    variants.some((v) => (v.attributes || []).some((a) => (a.attribute_name || a.name) === name && a.value === value));

  const selectAttr = (name, value) => {
    if (!isValueAvailable(name, value)) return;
    const next = { ...selectedAttrs, [name]: value };
    const exists = variants.some((v) =>
      (v.attributes || []).every((a) => next[a.attribute_name || a.name] === a.value));
    if (exists) { setSelectedAttrs(next); return; }
    const fb = variants.find((v) =>
      (v.attributes || []).some((a) => (a.attribute_name || a.name) === name && a.value === value));
    if (fb) {
      const reset = {};
      (fb.attributes || []).forEach((a) => { reset[a.attribute_name || a.name] = a.value; });
      setSelectedAttrs(reset);
    }
  };

  // ── Cart actions (★ your exact cart item shape) ──
  const buildCartItem = (quantity) => ({
    id: product.id,
    variant_id: activeVariant.id,
    name: product.name,
    price: Number(price || 0),
    unit: activeVariant.unit_abbr || activeVariant.unit_name || "",
    image_url: firstImage(activeVariant),
    quantity,
    is_out_of_stock: activeVariant.is_out_of_stock || false,
    available_stock: activeVariant.available_stock ?? null,
    attributes: activeVariant.attributes || [],   // ★ NEW
  });

  const handleAdd = (openDrawer = true) => {
    if (!activeVariant) return;
    if (!isDeliverable) { showToast("Delivery is not available at your location. Please set a deliverable location.", "error"); return; }
    if (activeVariant.is_out_of_stock === true || (stock !== null && stock !== undefined && stock <= 0)) {
      showToast(`${product.name} is out of stock`, "error"); return;
    }
    const result = addToCart(buildCartItem(qty));
    if (result.success) { showToast(`${qty} × ${product.name} added to cart`); if (openDrawer) setIsCartOpen(true); }
    else showToast(result.error || "Could not add to cart", "error");
  };

  const handleBuyNow = () => {
    if (!activeVariant) return;
    if (!isDeliverable) { showToast("Delivery is not available at your location.", "error"); return; }
    if (activeVariant.is_out_of_stock === true || (stock !== null && stock !== undefined && stock <= 0)) {
      showToast(`${product.name} is out of stock`, "error"); return;
    }
    const result = addToCart(buildCartItem(qty));
    if (result.success) navigate("/checkout");
    else showToast(result.error || "Could not add to cart", "error");
  };

  const quickAdd = (p) => {
    if (!isDeliverable) { showToast("Delivery is not available at your location.", "error"); return; }
    const v = (p.variants || []).find((x) => x.is_out_of_stock !== true) || (p.variants || [])[0];
    if (!v) return;
    const result = addToCart({
      id: p.id, variant_id: v.id, name: p.name,
      price: Number(v.final_price || 0), unit: v.unit_abbr || "",
      image_url: firstImage(v), quantity: 1,
      is_out_of_stock: v.is_out_of_stock || false,
      available_stock: v.available_stock ?? null,
      attributes: v.attributes || [],   // ★ NEW
    });
    if (result.success) showToast(`${p.name} added to cart`);
    else showToast(result.error || "Could not add", "error");
  };

  // ── Optional data (sections hide themselves if absent) ──
  const highlights = Array.isArray(product?.highlights) ? product.highlights : [];
  const offers = Array.isArray(product?.offers) ? product.offers : [];
  const faq = Array.isArray(product?.faq) ? product.faq : [];
  const comparison = Array.isArray(product?.comparison) ? product.comparison : [];
  const specs = [
    ...(Array.isArray(product?.specifications) ? product.specifications.map((s) => [s.label, s.value]) : []),
    ...(activeVariant?.attributes || []).map((a) => [a.attribute_name || a.name, a.value]),
  ];
  const reviews = Array.isArray(product?.reviews) ? product.reviews : [];
  const reviewStats = useMemo(() => {
    if (!reviews.length) return null;
    const total = reviews.length;
    const avg = reviews.reduce((s, r) => s + (Number(r.rating) || 0), 0) / total;
    const dist = [5, 4, 3, 2, 1].map((star) => ({
      star, count: reviews.filter((r) => Math.round(Number(r.rating) || 0) === star).length,
    }));
    return { total, avg, dist };
  }, [reviews]);

    const filteredReviews = useMemo(() => {
    let list = [...reviews];
    if (reviewFilter) list = list.filter((r) => Math.round(Number(r.rating) || 0) === reviewFilter);
    if (reviewSearch) {
      const q = reviewSearch.toLowerCase();
      list = list.filter((r) => (r.text || "").toLowerCase().includes(q) || (r.name || "").toLowerCase().includes(q));
    }
    if (reviewSort === "highest") list.sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0));
    else if (reviewSort === "lowest") list.sort((a, b) => (Number(a.rating) || 0) - (Number(b.rating) || 0));
    else list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return list;
  }, [reviews, reviewFilter, reviewSearch, reviewSort]);
  const visibleReviews = filteredReviews.slice(0, reviewLimit);

  if (loading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#F8FAFF" }}>
        <div style={{ textAlign: "center", color: "#64748B" }}>
          <div style={{ width: 40, height: 40, border: "4px solid #E2E8F0", borderTopColor: PRIMARY, borderRadius: "50%", margin: "0 auto 16px", animation: "pdpSpin 0.8s linear infinite" }} />
          Loading product…
          <style>{`@keyframes pdpSpin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div style={{ minHeight: "50vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "#F8FAFF", gap: 12 }}>
        <p style={{ fontSize: "1.1rem", fontWeight: 700, color: DARK }}>{error || "Product not found."}</p>
        <Link to="/products" style={{ color: PRIMARY, fontWeight: 700 }}>← Back to Products</Link>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFF", paddingBottom: "80px" }}>
      {/* ── Breadcrumb ── */}
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "20px 16px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.85rem", color: "#64748B", flexWrap: "wrap" }}>
          <Link to="/" style={{ color: "#64748B", textDecoration: "none" }}>Home</Link>
          <ChevronRight size={14} />
          <Link to="/products" style={{ color: "#64748B", textDecoration: "none" }}>Products</Link>
          {product.category_name && (<><ChevronRight size={14} /><span>{product.category_name}</span></>)}
          <ChevronRight size={14} />
          <span style={{ color: DARK, fontWeight: 600 }}>{product.name}</span>
        </div>
      </div>

      {/* ── Not deliverable banner (same as your Products page) ── */}
      {!isDeliverable && (
        <div style={{ maxWidth: "1200px", margin: "16px auto 0", padding: "0 16px" }}>
          <div style={{ background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 12, padding: "14px 18px", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <Truck size={20} color="#DC2626" />
            <span style={{ flex: 1, minWidth: 200, fontSize: "0.85rem", fontWeight: 700, color: "#B91C1C" }}>
              Delivery not available at your location — purchases are disabled on this page.
            </span>
            <Link to={isAuthenticated ? "/addresses" : "/login"} style={{ padding: "8px 16px", background: "#DC2626", color: "#fff", borderRadius: 8, fontWeight: 700, fontSize: "0.8rem", textDecoration: "none" }}>
              <MapPin size={14} style={{ verticalAlign: -2, marginRight: 4 }} />{isAuthenticated ? "Manage addresses" : "Login & add address"}
            </Link>
          </div>
        </div>
      )}
      {locNote && isDeliverable && (
        <div style={{ maxWidth: "1200px", margin: "16px auto 0", padding: "0 16px" }}>
          <div style={{ background: "#FEF3C7", border: "1px solid #FCD34D", borderRadius: 12, padding: "10px 16px", fontSize: "0.8rem", color: "#92400E" }}>
            <MapPin size={14} style={{ verticalAlign: -2, marginRight: 6 }} />{locNote}
          </div>
        </div>
      )}

      {/* ── Main grid: Gallery + Info ── */}
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "16px" }}>
        <div className="pdp-grid">
          {/* Gallery */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="pdp-card">
              <div className="pdp-main-img">
              {current ? (
                current.type === "video" ? (
                  <video key={current.url} src={current.url} controls playsInline preload="metadata"
                    style={{ width: "100%", height: "100%", objectFit: "contain", background: "#000" }} />
                ) : (
                  <img src={current.url} alt={product.name} onClick={() => setLightbox(current.url)}
                    style={{ width: "100%", height: "100%", objectFit: "contain", cursor: "zoom-in" }} />
                )
              ) : (
                <span style={{ fontSize: 64 }}>📦</span>
              )}
              {savePct > 0 && !oos && (
                <span style={{ position: "absolute", top: 14, left: 14, background: "#DC2626", color: "#fff", fontWeight: 800, fontSize: "0.85rem", padding: "6px 12px", borderRadius: 999 }}>-{savePct}%</span>
              )}
              {oos && (
                <div style={{ position: "absolute", inset: 0, background: "rgba(255,255,255,0.75)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ background: "#1E293B", color: "#fff", fontWeight: 800, padding: "8px 18px", borderRadius: 999 }}>{!isDeliverable ? "NOT DELIVERABLE" : "OUT OF STOCK"}</span>
                </div>
              )}
              {media.length > 1 && (
                <>
                  <button onClick={() => setActiveMedia((i) => (i - 1 + media.length) % media.length)} className="pdp-arrow" style={{ left: 12 }}><ChevronLeft size={20} /></button>
                  <button onClick={() => setActiveMedia((i) => (i + 1) % media.length)} className="pdp-arrow" style={{ right: 12 }}><ChevronRight size={20} /></button>
                </>
              )}
            </div>
            {media.length > 1 && (
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", maxWidth: 440, margin: "14px auto 0" }}>
                {media.map((m, i) => (
                  <button key={i} onClick={() => setActiveMedia(i)} className={`thumb ${i === activeMedia ? "active" : ""}`}>
                    {m.type === "video" ? (
                      <span style={{ position: "relative", display: "block", width: "100%", height: "100%" }}>
                        <video src={`${m.url}#t=0.5`} muted preload="metadata" playsInline
                          style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                        <span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.4)" }}>
                          <Play size={16} color="#fff" fill="#fff" />
                        </span>
                      </span>
                    ) : (
                      <img src={m.url} alt="" loading="lazy" decoding="async" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    )}
                  </button>
                ))}
              </div>
            )}
          </motion.div>

          {/* Info */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="pdp-card">
            {product.category_name && (
              <span style={{ display: "inline-block", background: "#FFF7ED", color: PRIMARY, fontWeight: 800, fontSize: "0.75rem", padding: "6px 14px", borderRadius: 999, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 12 }}>
                {product.category_name}
              </span>
            )}
            <h1 style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 900, color: DARK, margin: "0 0 4px", letterSpacing: "-0.02em" }}>{product.name}</h1>
            {activeVariant?.unit_abbr && <p style={{ color: "#64748B", margin: "0 0 16px", fontSize: "0.9rem" }}>Unit: {activeVariant.unit_abbr} · SKU: {activeVariant.sku}</p>}

            <div style={{ display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap", marginBottom: 4 }}>
              <span style={{ fontSize: "1.9rem", fontWeight: 900, color: PRIMARY }}>{fmt(price)}</span>
              {hasDiscount && (
                <>
                  <span style={{ fontSize: "1.05rem", color: "#94A3B8", textDecoration: "line-through" }}>{fmt(mrp)}</span>
                  <span style={{ background: "#DCFCE7", color: "#15803D", fontWeight: 800, fontSize: "0.8rem", padding: "4px 12px", borderRadius: 999 }}>
                    Save {fmt(saveAmt)} ({savePct}%)
                  </span>
                </>
              )}
            </div>
            <p style={{ color: "#94A3B8", fontSize: "0.78rem", margin: "0 0 20px" }}>Taxes included. Shipping calculated at checkout.</p>

            {product.short_description && (
              <p style={{ color: "#475569", fontSize: "1rem", lineHeight: 1.6, margin: "0 0 20px" }}>{product.short_description}</p>
            )}

            {/* Highlights (from product.highlights) */}
            {highlights.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10, marginBottom: 20 }}>
                {highlights.map((h, i) => {
                  const Icon = HL_ICONS[h.icon] || Sparkles;
                  return (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, background: "#F8FAFC", border: "1px solid #E2E8F0", borderRadius: 12, padding: "10px 12px" }}>
                      <Icon size={18} color={PRIMARY} />
                      <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#334155" }}>{h.text || h.title || h}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Variant selectors */}
            {attributeGroups.map(([groupName, values]) => (
              <div key={groupName} style={{ marginBottom: 18 }}>
                <p style={{ fontSize: "0.85rem", fontWeight: 800, color: DARK, margin: "0 0 8px" }}>
                  {groupName}: <span style={{ color: PRIMARY }}>{selectedAttrs[groupName]}</span>
                </p>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {values.map((val) => {
                    const selected = selectedAttrs[groupName] === val;
                    const available = isValueAvailable(groupName, val);
                    return (
                      <button key={val} className={`variant-chip ${selected ? "selected" : ""}`} disabled={!available}
                        onClick={() => selectAttr(groupName, val)}>{val}</button>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Quantity + stock */}
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20, flexWrap: "wrap" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14, background: "#F1F5F9", borderRadius: 12, padding: "8px 14px" }}>
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1} style={{ background: "none", border: "none", cursor: qty <= 1 ? "not-allowed" : "pointer", opacity: qty <= 1 ? 0.4 : 1, padding: 2 }}>
                  <Minus size={16} color={DARK} />
                </button>
                <span style={{ fontWeight: 800, minWidth: 24, textAlign: "center", fontSize: "1.05rem" }}>{qty}</span>
                <button onClick={() => setQty((q) => Math.min(maxQty, q + 1))} disabled={qty >= maxQty} style={{ background: "none", border: "none", cursor: qty >= maxQty ? "not-allowed" : "pointer", opacity: qty >= maxQty ? 0.4 : 1, padding: 2 }}>
                  <Plus size={16} color={DARK} />
                </button>
              </div>
              {lowStock && <span style={{ color: "#F59E0B", fontWeight: 700, fontSize: "0.85rem" }}>Hurry — only {stock} left!</span>}
              {!isDeliverable && <span style={{ color: "#DC2626", fontWeight: 700, fontSize: "0.85rem" }}>Not deliverable to your location</span>}
            </div>

            {/* Action buttons */}
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <button onClick={() => handleAdd(true)} disabled={oos}
                style={{ flex: "1 1 200px", padding: "15px 24px", borderRadius: 14, border: "none", background: oos ? "#94A3B8" : PRIMARY, color: "#fff", fontWeight: 800, fontSize: "1rem", cursor: oos ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, boxShadow: "0 4px 14px rgba(0,0,0,0.12)" }}>
                <ShoppingCart size={18} /> {!isDeliverable ? "Not Deliverable" : "Add to Cart"}
              </button>
              <button onClick={handleBuyNow} disabled={oos}
                style={{ flex: "1 1 160px", padding: "15px 24px", borderRadius: 14, border: `2px solid ${PRIMARY}`, background: "#fff", color: PRIMARY, fontWeight: 800, fontSize: "1rem", cursor: oos ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, opacity: oos ? 0.5 : 1 }}>
                <Zap size={18} /> Buy It Now
              </button>
            </div>
            {activeVariant?.is_coupon_eligible && (
              <p style={{ display: "flex", alignItems: "center", gap: 6, color: "#15803D", fontWeight: 700, fontSize: "0.8rem", marginTop: 14, marginBottom: 0 }}>
                <BadgeCheck size={14} /> Coupon codes can be applied to this product
              </p>
            )}
          </motion.div>
        </div>

        {/* ── Product Description ── */}
        <div className="pdp-card" style={{ marginTop: 28 }}>
          <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 16 }}>Product Description</h2>
          <div style={{ color: "#475569", fontSize: "1rem", lineHeight: 1.8 }}>
            {(product.description || "No description available.").split("\n").map((para, i) => (
              <p key={i} style={{ margin: "0 0 12px" }}>{para}</p>
            ))}
          </div>
        </div>

        {/* ── Offers / Deal unlocks (from product.offers) ── */}
        {offers.length > 0 && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 16 }}>Deals & Free Gifts</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14 }}>
              {offers.map((o, i) => (
                <div key={i} style={{ border: `1px dashed ${PRIMARY}`, background: "#FFF7ED", borderRadius: 14, padding: 16, display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <Gift size={20} color={PRIMARY} style={{ flexShrink: 0, marginTop: 2 }} />
                  <div>
                    {o.badge && <span style={{ display: "inline-block", background: PRIMARY, color: "#fff", fontWeight: 800, fontSize: "0.65rem", padding: "3px 10px", borderRadius: 999, textTransform: "uppercase" }}>{o.badge}</span>}
                    <p style={{ fontWeight: 800, color: DARK, margin: "6px 0 2px" }}>{o.title}</p>
                    {o.text && <p style={{ color: "#64748B", fontSize: "0.85rem", margin: 0 }}>{o.text}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Specifications ── */}
        {specs.length > 0 && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 16 }}>Specifications</h2>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {specs.map(([label, value], i) => (
                  <tr key={i} style={{ borderBottom: "1px solid #F1F5F9" }}>
                    <td style={{ padding: "12px 8px", color: "#64748B", fontWeight: 600, width: "40%", fontSize: "0.92rem" }}>{label}</td>
                    <td style={{ padding: "12px 8px", color: DARK, fontWeight: 700, fontSize: "0.92rem" }}>{String(value)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Comparison table (from product.comparison) ── */}
        {comparison.length > 0 && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 16 }}>Why Choose Us</h2>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #E2E8F0" }}>
                  <th style={{ textAlign: "left", padding: "10px 8px", color: "#64748B", fontSize: "0.85rem" }}>Feature</th>
                  <th style={{ padding: "10px 8px", color: PRIMARY, fontSize: "0.85rem" }}>Us</th>
                  <th style={{ padding: "10px 8px", color: "#64748B", fontSize: "0.85rem" }}>Others</th>
                </tr>
              </thead>
              <tbody>
                {comparison.map((row, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid #F1F5F9" }}>
                    <td style={{ padding: "12px 8px", color: DARK, fontWeight: 600, fontSize: "0.9rem" }}>{row.feature}</td>
                    <td style={{ padding: "12px 8px", textAlign: "center" }}>{row.ours ? <Check size={18} color="#16A34A" strokeWidth={3} /> : <X size={18} color="#CBD5E1" strokeWidth={3} />}</td>
                    <td style={{ padding: "12px 8px", textAlign: "center" }}>{row.others ? <Check size={18} color="#16A34A" strokeWidth={3} /> : <X size={18} color="#CBD5E1" strokeWidth={3} />}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* ── FAQ (from product.faq) ── */}
        {faq.length > 0 && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 16 }}>Frequently Asked Questions</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {faq.map((item, i) => (
                <div key={i} style={{ border: "1px solid #E2E8F0", borderRadius: 12, overflow: "hidden" }}>
                  <button onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                    style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, padding: "16px 18px", background: faqOpen === i ? "#FFF7ED" : "#fff", border: "none", cursor: "pointer", textAlign: "left", fontSize: "0.95rem", fontWeight: 700, color: DARK }}>
                    {item.question}
                    <ChevronDown size={18} style={{ transform: faqOpen === i ? "rotate(180deg)" : "none", transition: "transform 0.2s", flexShrink: 0 }} />
                  </button>
                  {faqOpen === i && <p style={{ padding: "0 18px 16px", color: "#64748B", lineHeight: 1.7, margin: 0, fontSize: "0.92rem" }}>{item.answer}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── You May Also Like ── */}
        {related.length > 0 && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 20 }}>You May Also Like</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 16 }}>
              {related.map((p) => {
                const v = (p.variants || []).find((x) => x.is_out_of_stock !== true) || (p.variants || [])[0] || {};
                const pPrice = v.final_price ?? v.selling_price ?? v.mrp ?? 0;
                return (
                  <div key={p.id} onClick={() => navigate(`/products/${p.id}`)}
                    style={{ border: "1px solid #E2E8F0", borderRadius: 14, overflow: "hidden", cursor: "pointer", background: "#fff", transition: "transform 0.15s" }}
                    onMouseOver={(e) => (e.currentTarget.style.transform = "translateY(-3px)")}
                    onMouseOut={(e) => (e.currentTarget.style.transform = "none")}>
                    <div style={{ width: "100%", aspectRatio: "1/1", background: "#F1F5F9", overflow: "hidden" }}>
                      {firstImage(v) ? <img src={firstImage(v)} alt={p.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center", fontSize: 32 }}>📦</div>}
                    </div>
                    <div style={{ padding: 12 }}>
                        {(v.attributes || []).length > 0 && (
                          <p style={{ fontSize: "0.62rem", color: "#64748B", margin: "0 0 4px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                            {(v.attributes || []).map((a) => `${a.attribute_name}: ${a.value}`).join(" · ")}
                          </p>
                        )}
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontWeight: 800, color: PRIMARY }}>{fmt(pPrice)}</span>
                        <button onClick={(e) => { e.stopPropagation(); quickAdd(p); }}
                          style={{ width: 30, height: 30, borderRadius: 8, border: "none", background: PRIMARY, color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <Plus size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── Reviews (from product.reviews) ── */}
        {reviewStats && (
          <div className="pdp-card" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.35rem", fontWeight: 900, color: DARK, marginBottom: 20 }}>
              Customer Reviews <span style={{ fontSize: "1rem", color: "#64748B", fontWeight: 600 }}>({reviewStats.total})</span>
            </h2>

            {/* Summary + clickable distribution bars (tap a bar to filter) */}
            <div style={{ display: "flex", gap: 32, flexWrap: "wrap", marginBottom: 20 }}>
              <div style={{ textAlign: "center", minWidth: 150 }}>
                <p style={{ fontSize: "2.6rem", fontWeight: 900, color: DARK, margin: 0 }}>{reviewStats.avg.toFixed(2)}</p>
                <Stars value={reviewStats.avg} size={18} />
                <p style={{ color: "#64748B", fontSize: "0.8rem", marginTop: 6 }}>Based on {reviewStats.total} reviews</p>
                {reviewFilter && (
                  <button onClick={() => setReviewFilter(null)} style={{ marginTop: 6, background: PRIMARY, color: "#fff", border: "none", borderRadius: 999, padding: "4px 14px", fontSize: "0.72rem", fontWeight: 700, cursor: "pointer" }}>
                    Clear {reviewFilter}★ filter ✕
                  </button>
                )}
              </div>
              <div style={{ flex: 1, minWidth: 240, display: "flex", flexDirection: "column", gap: 6, justifyContent: "center" }}>
                {reviewStats.dist.map(({ star, count }) => (
                  <button key={star} onClick={() => { setReviewFilter(reviewFilter === star ? null : star); setReviewLimit(6); }}
                    style={{ display: "flex", alignItems: "center", gap: 10, background: "transparent", border: "none", cursor: "pointer", padding: 0, font: "inherit" }}>
                    <span style={{ fontSize: "0.78rem", color: "#64748B", minWidth: 26 }}>{star}★</span>
                    <div style={{ flex: 1, height: 8, background: "#F1F5F9", borderRadius: 999, overflow: "hidden" }}>
                      <div style={{ width: `${(count / reviewStats.total) * 100}%`, height: "100%", background: reviewFilter === star ? PRIMARY : "#F59E0B" }} />
                    </div>
                    <span style={{ fontSize: "0.78rem", color: "#64748B", minWidth: 24, textAlign: "right" }}>{count}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Search + sort */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 18 }}>
              <input type="text" value={reviewSearch} onChange={(e) => { setReviewSearch(e.target.value); setReviewLimit(6); }}
                placeholder="Search reviews…" style={{ flex: "1 1 200px", padding: "10px 14px", borderRadius: 10, border: "1px solid #E2E8F0", fontSize: "0.88rem", outline: "none" }} />
              <select value={reviewSort} onChange={(e) => setReviewSort(e.target.value)}
                style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid #E2E8F0", fontSize: "0.88rem", background: "#fff", color: "#1E293B" }}>
                <option value="recent">Most Recent</option>
                <option value="highest">Highest Rated</option>
                <option value="lowest">Lowest Rated</option>
              </select>
            </div>

            {/* Review cards (paginated) */}
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {visibleReviews.map((r, i) => (
                <div key={i} style={{ borderBottom: "1px solid #F1F5F9", paddingBottom: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                    <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#FFF7ED", color: PRIMARY, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.9rem", flexShrink: 0 }}>
                      {(r.name || "?").charAt(0).toUpperCase()}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                      <span style={{ fontWeight: 700, color: DARK, fontSize: "0.9rem" }}>{r.name || "Anonymous"}</span>
                      <Stars value={Number(r.rating) || 0} size={12} />
                      {r.date && <span style={{ fontSize: "0.72rem", color: "#94A3B8" }}>{r.date}</span>}
                    </div>
                  </div>
                  <p style={{ color: "#475569", fontSize: "0.92rem", lineHeight: 1.6, margin: "0 0 8px" }}>{r.text || r.comment || ""}</p>
                  {(r.images || []).length > 0 && (
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {(r.images || []).map((img, j) => (
                        <button key={j} onClick={() => setLightbox(img)} title="View photo"
                          style={{ width: 60, height: 60, padding: 0, border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden", cursor: "zoom-in", background: "#F1F5F9" }}>
                          <img src={img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              {visibleReviews.length === 0 && (
                <p style={{ color: "#64748B", fontSize: "0.9rem", textAlign: "center", padding: "16px 0" }}>
                  No reviews match your filter{reviewSearch ? ` / search "${reviewSearch}"` : ""}.
                </p>
              )}
            </div>

            {/* Load more — never an endless list */}
            {filteredReviews.length > reviewLimit && (
              <button onClick={() => setReviewLimit((n) => n + 6)}
                style={{ width: "100%", marginTop: 16, padding: "12px", background: "#fff", border: `1px solid ${PRIMARY}`, color: PRIMARY, borderRadius: 12, fontWeight: 700, fontSize: "0.9rem", cursor: "pointer" }}>
                Show 6 more reviews ({filteredReviews.length - reviewLimit} remaining)
              </button>
            )}
          </div>
        )}
      </div>

      <CartDrawer />

      <style>{`
        .pdp-grid { display: grid; grid-template-columns: minmax(0, 440px) minmax(0, 1fr); gap: 32px; align-items: start; }
        .pdp-main-img { position: relative; width: 100%; max-width: 440px; margin: 0 auto; aspect-ratio: 1 / 1; background: #F1F5F9; border-radius: 16px; overflow: hidden; display: flex; align-items: center; justify-content: center; }
        .pdp-card { background: #fff; border-radius: 20px; padding: 24px; border: 1px solid #E2E8F0; box-shadow: 0 10px 40px rgba(0,0,0,0.03); }
        .variant-chip { padding: 8px 16px; border-radius: 10px; border: 1.5px solid #E2E8F0; background: #fff; font-weight: 700; font-size: 0.85rem; cursor: pointer; color: #334155; font-family: inherit; }
        .variant-chip.selected { border-color: ${PRIMARY}; color: ${PRIMARY}; background: #FFF7ED; }
        .variant-chip:disabled { opacity: 0.35; cursor: not-allowed; text-decoration: line-through; }
        .thumb { width: 64px; height: 64px; border-radius: 10px; overflow: hidden; border: 2px solid transparent; cursor: pointer; padding: 0; background: #F1F5F9; }
        .thumb.active { border-color: ${PRIMARY}; }
        .pdp-arrow { position: absolute; top: 50%; transform: translateY(-50%); width: 38px; height: 38px; border-radius: 50%; border: none; background: rgba(255,255,255,0.92); box-shadow: 0 2px 10px rgba(0,0,0,0.15); cursor: pointer; display: flex; align-items: center; justify-content: center; color: #1E293B; }
        @media (max-width: 900px) {
          .pdp-grid { grid-template-columns: 1fr; }
          .pdp-card { padding: 16px; }
        }
        @media (max-width: 640px) {
          .pdp-main-img { max-width: 340px; }
          .thumb { width: 56px; height: 56px; }
        }
      `}</style>

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", bottom: 24, right: 24, zIndex: 10001, background: toast.kind === "error" ? "#EF4444" : "#22C55E", color: "#fff", padding: "12px 20px", borderRadius: 10, boxShadow: "0 10px 30px rgba(0,0,0,0.3)", fontWeight: 600, fontSize: "0.9rem" }}>
          {toast.msg}
        </div>
      )}      {/* ★ Review photo lightbox */}
      {lightbox && (
        <div onClick={() => setLightbox(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 10002, display: "flex", alignItems: "center", justifyContent: "center", padding: 24, cursor: "zoom-out" }}>
          <img src={lightbox} alt="Review photo" style={{ maxWidth: "92%", maxHeight: "92%", borderRadius: 12, boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }} />
        </div>
      )}

    </div>
  );
}