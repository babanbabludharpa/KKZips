import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, Calendar, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react";
import customerApi from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";
import { useSubscription } from "./SubscriptionContext";

const theme = {
  primary: "#FF7132", primaryHover: "#EA580C", dark: "#1E293B",
  mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0",
};

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const SCHEDULE_TYPES = [
  { value: "daily", label: "Daily — every day" },
  { value: "alternate", label: "Alternate Days — every other day" },
  { value: "weekly", label: "Weekly — one day per week" },
  { value: "custom_days", label: "Custom Days — select specific weekdays" },
  { value: "custom_dates", label: "Custom Dates — select specific calendar dates" },
];

function toLocalISOString(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

// "2026-11-18" -> "Wednesday 18th Nov 2026"
function formatLongDate(iso) {
  const d = new Date(iso + "T00:00:00");
  const day = d.getDate();
  const suffix =
    day % 100 >= 11 && day % 100 <= 13 ? "th"
    : { 1: "st", 2: "nd", 3: "rd" }[day % 10] || "th";
  const weekday = d.toLocaleDateString("en-US", { weekday: "long" });
  const month = d.toLocaleDateString("en-US", { month: "short" });
  return `${weekday} ${day}${suffix} ${month} ${d.getFullYear()}`;
}

// Mirror the backend's date generation. Used only for client-side pre-check.
function expandScheduleDates(item, startDate, endDate) {
  if (!startDate) return [];
  const start = new Date(startDate + "T00:00:00");
  const end   = endDate ? new Date(endDate + "T00:00:00") : new Date(start.getTime() + 90 * 86400 * 1000);
  const dates = [];
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const iso = toLocalISOString(d);
    let match = false;
    switch (item.schedule_type) {
      case "daily":
        match = true; break;
      case "alternate": {
        const diff = Math.floor((d - start) / 86400000);
        match = diff % 2 === 0; break;
      }
      case "weekly":
      case "custom_days":
        match = (item.schedule_days || []).map(Number).includes(d.getDay()); break;
      case "custom_dates":
        match = (item.schedule_dates || []).includes(iso); break;
    }
    if (match) dates.push(iso);
    if (item.schedule_type === "custom_dates" && dates.length && d > end) break;
  }
  return dates;
}

function getVariantLabel(variant) {
  let attrs = "";
  if (Array.isArray(variant.attributes) && variant.attributes.length > 0) {
    attrs = variant.attributes.map(a => a.value).filter(Boolean).join(", ");
  }
  if (!attrs) attrs = variant.unit_abbr || variant.sku || `Variant ${variant.id}`;
  const price = variant.final_price ?? variant.selling_price ?? 0;
  return { attrs, price };
}

// ─── Styled Date Picker with blocked-date support ──────────────────────────
function StyledDatePicker({ value, onChange, min, max, primaryColor, accentColor, label, blockedDates }) {
  const [showCalendar, setShowCalendar] = useState(false);
  const initialDate = value ? new Date(value + "T00:00:00") : new Date();
  const [viewMonth, setViewMonth] = useState(() => new Date(initialDate.getFullYear(), initialDate.getMonth(), 1));

  const primary = primaryColor || "#FF7132";
  const accent = accentColor || "#EA580C";
  const minDate = min ? new Date(min + "T00:00:00") : null;
  const maxDate = max ? new Date(max + "T00:00:00") : null;
  const selectedDate = value ? new Date(value + "T00:00:00") : null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = viewMonth.toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const isDisabled = (date) => {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;
    if (blockedDates?.has(toLocalISOString(date))) return true;
    return false;
  };

  const isSameDay = (a, b) =>
    a && b && a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  const handleDateClick = (day) => {
    const date = new Date(year, month, day);
    if (isDisabled(date)) return;
    onChange(toLocalISOString(date));
    setShowCalendar(false);
  };

  const prevMonth = (e) => { e.preventDefault(); setViewMonth(new Date(year, month - 1, 1)); };
  const nextMonth = (e) => { e.preventDefault(); setViewMonth(new Date(year, month + 1, 1)); };

  const formatDate = (iso) => {
    if (!iso) return "";
    return new Date(iso + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  };

  return (
    <div style={{ position: "relative" }}>
      {label && (
        <label style={{ display: "block", fontSize: "0.72rem", color: theme.mid, marginBottom: 2 }}>{label}</label>
      )}
      <button
        type="button"
        onClick={() => setShowCalendar(!showCalendar)}
        style={{
          width: "100%", padding: "12px 14px", borderRadius: 10,
          border: `1px solid ${showCalendar ? primary : theme.border}`,
          fontSize: "0.9rem", outline: "none", textAlign: "left",
          backgroundColor: "#fff", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 8,
        }}
      >
        <Calendar size={16} color={primary} />
        <span style={{ color: value ? theme.dark : "#94A3B8" }}>
          {value ? formatDate(value) : "Select date…"}
        </span>
      </button>

      {showCalendar && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 999 }} onClick={() => setShowCalendar(false)} />
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
              position: "absolute", top: "100%", left: 0, zIndex: 1000,
              background: "#fff", borderRadius: 16, padding: 16,
              boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
              border: `1px solid ${theme.border}`, width: 320, marginTop: 4,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <button type="button" onClick={prevMonth} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: theme.mid }}>
                <ChevronLeft size={18} />
              </button>
              <span style={{ fontWeight: 700, fontSize: "0.9rem", color: theme.dark }}>{monthName}</span>
              <button type="button" onClick={nextMonth} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: theme.mid }}>
                <ChevronRight size={18} />
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 4 }}>
              {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
                <div key={i} style={{ textAlign: "center", fontSize: "0.65rem", fontWeight: 700, color: theme.mid, padding: "4px 0" }}>{d}</div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2 }}>
              {Array.from({ length: firstDay }).map((_, i) => <div key={`empty-${i}`} />)}
              {Array.from({ length: daysInMonth }).map((_, dayIdx) => {
                const day = dayIdx + 1;
                const date = new Date(year, month, day);
                date.setHours(0, 0, 0, 0);
                const disabled = isDisabled(date);
                const selected = isSameDay(date, selectedDate);
                const isTodayDate = isSameDay(date, today);
                const blocked = blockedDates?.get(toLocalISOString(date));

                return (
                  <button
                    key={day}
                    type="button"
                    onClick={(e) => { e.preventDefault(); handleDateClick(day); }}
                    disabled={disabled}
                    title={blocked?.reason || ""}
                    style={{
                      aspectRatio: "1", borderRadius: 8, position: "relative",
                      fontSize: "0.8rem", fontWeight: selected ? 800 : 500,
                      cursor: disabled ? "not-allowed" : "pointer",
                      color: selected ? "#fff" : disabled ? "#CBD5E1" : isTodayDate ? primary : theme.dark,
                      background: selected
                        ? `linear-gradient(135deg, ${primary}, ${accent})`
                        : blocked ? "#FEE2E2"
                        : isTodayDate ? `${primary}15` : "transparent",
                      border: blocked && !selected ? "1px solid #FCA5A5" : isTodayDate && !selected ? `1px solid ${primary}40` : "1px solid transparent",
                      opacity: disabled && !blocked ? 0.4 : 1,
                    }}
                  >
                    {day}
                    {blocked && !selected && (
                      <span style={{ position: "absolute", bottom: 2, left: "50%", transform: "translateX(-50%)", width: 4, height: 4, borderRadius: "50%", background: "#DC2626" }} />
                    )}
                  </button>
                );
              })}
            </div>

            {blockedDates && blockedDates.size > 0 && (
              <div style={{ marginTop: 10, padding: 8, background: "#FEF2F2", borderRadius: 8, fontSize: "0.7rem", color: "#B91C1C", display: "flex", gap: 6, alignItems: "flex-start" }}>
                <AlertTriangle size={14} style={{ flexShrink: 0, marginTop: 1 }} />
                <span>Red days are unavailable (store closed). Hover for reason.</span>
              </div>
            )}
          </motion.div>
        </>
      )}
    </div>
  );
}

// ─── Custom Dates Picker with blocked-date support ────────────────────────
function CustomDatesPicker({ selectedDates, onChange, primaryColor, accentColor, minDate, blockedDates }) {
  const [viewMonth, setViewMonth] = useState(() => new Date());
  const primary = primaryColor || "#FF7132";
  const accent = accentColor || "#EA580C";
  const min = minDate ? new Date(minDate + "T00:00:00") : null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = viewMonth.toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const dateSet = useMemo(() => {
    const s = new Set();
    (selectedDates || []).forEach(d => {
      const date = new Date(d + "T00:00:00");
      s.add(`${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`);
    });
    return s;
  }, [selectedDates]);

  const toggleDate = (day) => {
    const date = new Date(year, month, day);
    date.setHours(0, 0, 0, 0);
    if (min && date < min) return;
    const iso = toLocalISOString(date);
    if (blockedDates?.has(iso)) return;
    const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;

    if (dateSet.has(key)) {
      onChange((selectedDates || []).filter(d => {
        const dd = new Date(d + "T00:00:00");
        return `${dd.getFullYear()}-${dd.getMonth()}-${dd.getDate()}` !== key;
      }));
    } else {
      onChange([...(selectedDates || []), iso].sort());
    }
  };

  const prevMonth = (e) => { e.preventDefault(); setViewMonth(new Date(year, month - 1, 1)); };
  const nextMonth = (e) => { e.preventDefault(); setViewMonth(new Date(year, month + 1, 1)); };

  return (
    <div style={{ background: theme.bg, borderRadius: 12, padding: 12, border: `1px solid ${theme.border}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <button type="button" onClick={prevMonth} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: theme.mid }}>
          <ChevronLeft size={16} />
        </button>
        <span style={{ fontWeight: 700, fontSize: "0.85rem", color: theme.dark }}>{monthName}</span>
        <button type="button" onClick={nextMonth} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: theme.mid }}>
          <ChevronRight size={16} />
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 2 }}>
        {["S","M","T","W","T","F","S"].map((d, i) => (
          <div key={i} style={{ textAlign: "center", fontSize: "0.6rem", fontWeight: 700, color: theme.mid, padding: "2px 0" }}>{d}</div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2 }}>
        {Array.from({ length: firstDay }).map((_, i) => <div key={`e-${i}`} />)}
        {Array.from({ length: daysInMonth }).map((_, dayIdx) => {
          const day = dayIdx + 1;
          const date = new Date(year, month, day);
          date.setHours(0, 0, 0, 0);
          const tooEarly = min && date < min;
          const blocked = blockedDates?.has(toLocalISOString(date));
          const disabled = tooEarly || blocked;
          const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
          const selected = dateSet.has(key);
          const isToday = date.getTime() === today.getTime();

          return (
            <button
              key={day}
              type="button"
              onClick={(e) => { e.preventDefault(); toggleDate(day); }}
              disabled={disabled}
              title={blocked ? blockedDates.get(toLocalISOString(date))?.reason : ""}
              style={{
                aspectRatio: "1", borderRadius: 6, position: "relative",
                fontSize: "0.75rem", fontWeight: selected ? 800 : 500,
                cursor: disabled ? "not-allowed" : "pointer",
                color: selected ? "#fff" : blocked ? "#B91C1C" : tooEarly ? "#CBD5E1" : isToday ? primary : theme.dark,
                background: selected ? `linear-gradient(135deg, ${primary}, ${accent})` : blocked ? "#FEE2E2" : isToday && !disabled ? `${primary}15` : "transparent",
                border: selected ? "none" : blocked ? "1px solid #FCA5A5" : isToday ? `1px solid ${primary}40` : "1px solid transparent",
                opacity: tooEarly ? 0.4 : 1,
              }}
            >
              {day}
            </button>
          );
        })}
      </div>

      {selectedDates && selectedDates.length > 0 && (
        <div style={{ marginTop: 8, fontSize: "0.72rem", color: theme.mid }}>
          {selectedDates.length} date(s) selected
        </div>
      )}
    </div>
  );
}

export default function SubscriptionCreate() {
  const navigate = useNavigate();
  const { isAuthenticated } = useCustomerAuth();
  const { theme: tenantTheme } = useTenant() || {};
  const primaryColor = tenantTheme?.primary_color || "#FF7132";
  const accentColor = tenantTheme?.secondary_color || "#EA580C";

  const [addresses, setAddresses] = useState([]);
  const [products, setProducts] = useState([]);
  const [config, setConfig] = useState({ cutoff_time: "20:00", earliest_start_date: null, slots: [], blocked_dates: [] });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const [selectedAddressId, setSelectedAddressId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [items, setItems] = useState([]);
  const { items: basketItems, clear: clearBasket } = useSubscription();

  // ── Blocked dates derived from config ──────────────────────────────────
  const blockedDates = useMemo(() => {
    const map = new Map();
    (config.blocked_dates || []).forEach(b => map.set(b.date, b));
    return map;
  }, [config.blocked_dates]);

  // Nearest few future blocked dates for the inline warning panel.
  const upcomingBlocked = useMemo(() => {
    const today = toLocalISOString(new Date());
    return [...blockedDates.values()]
      .filter(b => b.date >= today)
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 3);
  }, [blockedDates]);

  // Load addresses + products + config
  useEffect(() => {
    if (!isAuthenticated) { navigate("/", { replace: true }); return; }
    Promise.all([
      customerApi.get("/mobile/addresses"),
      customerApi.get("/mobile/products", { params: { per_page: 100, channel: "subscription" } }),
      customerApi.get("/mobile/subscriptions/config"),
    ]).then(([addrRes, prodRes, cfgRes]) => {
      const addrs = addrRes.data?.data || [];
      setAddresses(addrs);
      const serviceable = addrs.find(a => a.is_serviceable && a.branch_id);
      if (serviceable) setSelectedAddressId(serviceable.id);
      const prods = prodRes.data?.data || [];
      setProducts(Array.isArray(prods) ? prods : []);
      if (cfgRes.data?.data) setConfig(cfgRes.data.data);
      if (cfgRes.data?.data?.earliest_start_date) setStartDate(cfgRes.data.data.earliest_start_date);
    }).catch(e => setError(e?.response?.data?.message || "Failed to load data."))
      .finally(() => setLoading(false));
  }, [isAuthenticated, navigate]);

  // When the customer changes address, refetch config so blocked_dates
  // reflect the new branch.
  useEffect(() => {
    if (!selectedAddressId) return;
    customerApi.get("/mobile/subscriptions/config", {
      params: { delivery_address_id: selectedAddressId },
    }).then(res => {
      if (res.data?.data?.blocked_dates) {
        setConfig(prev => ({ ...prev, blocked_dates: res.data.data.blocked_dates }));
      }
    }).catch(() => {});
  }, [selectedAddressId]);

  // Prefill basket items
  useEffect(() => {
    if (!basketItems?.length) return;
    setItems(prev => (prev.length ? prev : basketItems.map(it => ({
      id: it.variant_id ?? it.id,
      product_variant_id: String(it.variant_id ?? it.id),
      default_qty: it.default_qty || it.quantity || 1,
      slot_id: "",
      schedule_type: "daily",
      schedule_days: [],
      schedule_dates: [],
    }))));
  }, [basketItems]);

  const addItem = () => setItems(prev => [...prev, {
    id: Date.now(), product_variant_id: "", default_qty: 1, slot_id: "",
    schedule_type: "daily", schedule_days: [], schedule_dates: [],
  }]);

  const updateItem = (idx, field, value) => {
    setItems(prev => {
      const updated = [...prev];
      updated[idx] = { ...updated[idx], [field]: value };
      if (field === "schedule_type") {
        updated[idx].schedule_days = [];
        updated[idx].schedule_dates = [];
      }
      return updated;
    });
  };

  const toggleDay = (idx, day) => {
    day = parseInt(day);
    setItems(prev => {
      const updated = [...prev];
      const cur = { ...updated[idx] };
      const days = (cur.schedule_days || []).map(d => parseInt(d));
      if (days.includes(day)) {
        cur.schedule_days = days.filter(d => d !== day);
      } else {
        cur.schedule_days = cur.schedule_type === "weekly" ? [day] : [...days, day];
      }
      updated[idx] = cur;
      return updated;
    });
  };

  const removeItem = (idx) => setItems(prev => prev.filter((_, i) => i !== idx));

  const handleSubmit = async () => {
    setError(null);
    if (!selectedAddressId) { setError("Please select a delivery address."); return; }
    if (!startDate) { setError("Please select a start date."); return; }
    if (items.length === 0) { setError("Please add at least one item."); return; }

    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (!it.product_variant_id) { setError(`Item ${i + 1}: Please select a product.`); return; }
      if (!it.default_qty || it.default_qty < 1) { setError(`Item ${i + 1}: Quantity must be at least 1.`); return; }
      if (!it.slot_id) { setError(`Item ${i + 1}: Please select a delivery slot.`); return; }
      if ((it.schedule_type === "custom_days" || it.schedule_type === "weekly") && (!it.schedule_days || it.schedule_days.length === 0)) {
        setError(`Item ${i + 1}: Please select at least one day.`); return;
      }
      if (it.schedule_type === "custom_dates" && (!it.schedule_dates || it.schedule_dates.length === 0)) {
        setError(`Item ${i + 1}: Please select at least one date.`); return;
      }
    }

    // ── Client-side leave pre-check ────────────────────────────────────
    // We do NOT reject if a date is blocked — those become 'holiday_skipped'
    // on the server with the reason preserved. But we warn the customer
    // so nothing is a surprise on delivery day.
    const warnings = [];
    for (const it of items) {
      const slotId = Number(it.slot_id);
      for (const date of expandScheduleDates(it, startDate, endDate)) {
        const blocked = blockedDates.get(date);
        if (!blocked) continue;
        if (blocked.all_slots || blocked.slot_ids?.includes(slotId)) {
          warnings.push(`${formatLongDate(date)}: ${blocked.reason}`);
        }
      }
    }

    if (warnings.length > 0) {
      const unique = [...new Set(warnings)].slice(0, 3);
      const extra = warnings.length > 3 ? ` (+${warnings.length - 3} more)` : "";
      const ok = window.confirm(
        `Your subscription will be created, but the store is closed on:\n\n${unique.join("\n")}${extra}\n\nThose deliveries will be skipped. Continue?`
      );
      if (!ok) return;
    }

    setSaving(true);
    try {
      const payload = {
        delivery_address_id: parseInt(selectedAddressId),
        start_date: startDate,
        end_date: endDate || null,
        items: items.map(it => ({
          product_variant_id: parseInt(it.product_variant_id),
          default_qty: parseInt(it.default_qty),
          slot_id: parseInt(it.slot_id),
          schedule_type: it.schedule_type,
          schedule_days: (it.schedule_type === "custom_days" || it.schedule_type === "weekly") ? it.schedule_days : undefined,
          schedule_dates: it.schedule_type === "custom_dates" ? it.schedule_dates : undefined,
        })),
      };
      await customerApi.post("/mobile/subscriptions", payload);
      clearBasket();
      navigate("/subscription", { replace: true });
    } catch (e) {
      const errs = e?.response?.data?.errors;
      setError(errs ? (Object.values(errs)[0]?.[0] || "Validation failed.") : (e?.response?.data?.message || "Failed to create subscription."));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: theme.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: primaryColor, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
          <div style={{ color: theme.mid }}>Loading…</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: 40 }}>
      <div style={{ background: `linear-gradient(135deg, ${primaryColor}, ${accentColor})`, padding: "40px 24px 60px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "relative", zIndex: 1, maxWidth: 800, margin: "0 auto" }}>
          <button onClick={() => navigate("/subscription")} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "8px 16px", borderRadius: 100, fontSize: "0.85rem", fontWeight: 600, cursor: "pointer", marginBottom: 16 }}>
            <ArrowLeft size={14} /> Back to Subscriptions
          </button>
          <h1 style={{ color: "#fff", fontSize: "clamp(1.75rem, 4vw, 2.5rem)", fontWeight: 900, margin: "0 0 8px", textShadow: "0 4px 12px rgba(0,0,0,0.2)" }}>Create Subscription</h1>
          <p style={{ color: "rgba(255,255,255,0.9)", fontSize: "1rem", margin: 0 }}>Set up recurring deliveries for your daily essentials.</p>
        </div>
      </div>

      <div style={{ maxWidth: 800, margin: "-32px auto 0", padding: "0 24px", position: "relative", zIndex: 10 }}>
        <div style={{ background: "#fff", borderRadius: 16, padding: 24, boxShadow: "0 4px 24px rgba(0,0,0,0.06)", border: `1px solid ${theme.border}` }}>
          {error && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 8, padding: "12px 16px", color: "#b91c1c", marginBottom: 16, fontSize: "0.9rem" }}>
              {error}
            </div>
          )}

          <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: theme.dark, marginBottom: 6 }}>Delivery Address</label>
          <select
            value={selectedAddressId}
            onChange={(e) => setSelectedAddressId(e.target.value)}
            style={{ width: "100%", padding: "12px 14px", borderRadius: 10, border: `1px solid ${theme.border}`, fontSize: "0.95rem", outline: "none", marginBottom: 16, backgroundColor: "#fff" }}
          >
            <option value="">Select address…</option>
            {addresses.map(a => (
              <option key={a.id} value={a.id} disabled={!a.is_serviceable}>
                {a.label}: {a.address_line1}, {a.city}{!a.is_serviceable ? " (not serviceable)" : ""}
              </option>
            ))}
          </select>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
            <div>
              <StyledDatePicker value={startDate} onChange={setStartDate} min={config.earliest_start_date || toLocalISOString(new Date())} primaryColor={primaryColor} accentColor={accentColor} label="Start Date" blockedDates={blockedDates} />
              <small style={{ color: theme.mid, fontSize: "0.72rem" }}>Cutoff: {config.cutoff_time}</small>
            </div>
            <div>
              <StyledDatePicker value={endDate} onChange={setEndDate} min={startDate || config.earliest_start_date || toLocalISOString(new Date())} primaryColor={primaryColor} accentColor={accentColor} label="End Date (optional)" blockedDates={blockedDates} />
              <small style={{ color: theme.mid, fontSize: "0.72rem" }}>Leave empty for ongoing</small>
            </div>
          </div>

          {upcomingBlocked.length > 0 && (
            <div style={{ background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 8, padding: "10px 14px", marginBottom: 16, fontSize: "0.82rem", color: "#B91C1C", display: "flex", gap: 8 }}>
              <AlertTriangle size={16} style={{ flexShrink: 0, marginTop: 1 }} />
              <div>
                <strong>Store closed on:</strong>{" "}
                {upcomingBlocked.map((b, i) => (
                  <span key={b.date}>
                    {formatLongDate(b.date)} ({b.reason}){i < upcomingBlocked.length - 1 ? ", " : ""}
                  </span>
                ))}
                {blockedDates.size > upcomingBlocked.length && (
                  <span> and {blockedDates.size - upcomingBlocked.length} more.</span>
                )}
                <div style={{ fontSize: "0.75rem", marginTop: 4, color: "#7F1D1D" }}>
                  Deliveries on these days will be skipped. You can still create a subscription covering other days.
                </div>
              </div>
            </div>
          )}

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <h3 style={{ margin: 0, fontSize: "1rem", fontWeight: 700, color: theme.dark }}>Items ({items.length})</h3>
            <button type="button" onClick={addItem} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: primaryColor, color: "#fff", border: "none", borderRadius: 8, padding: "8px 14px", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer" }}>
              <Plus size={14} /> Add Item
            </button>
          </div>

          {items.length === 0 && (
            <div style={{ textAlign: "center", padding: "2rem 1rem", color: theme.mid, border: `1px dashed ${theme.border}`, borderRadius: 10, marginBottom: 16 }}>
              No items yet. Click "Add Item" to start.
            </div>
          )}

          {items.map((item, idx) => (
            <div key={item.id} style={{ background: theme.bg, borderRadius: 12, padding: 16, marginBottom: 12, border: `1px solid ${theme.border}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <span style={{ fontWeight: 700, fontSize: "0.85rem", color: theme.dark }}>Item {idx + 1}</span>
                <button type="button" onClick={() => removeItem(idx)} style={{ background: "transparent", border: "none", color: "#b91c1c", cursor: "pointer", padding: 4 }}>✕</button>
              </div>

              <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 2, display: "block" }}>Product</label>
              <select value={item.product_variant_id} onChange={(e) => updateItem(idx, "product_variant_id", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.9rem", outline: "none", marginBottom: 8, backgroundColor: "#fff" }}>
                <option value="">Select product…</option>
                {products.map(p => {
                  const variants = Array.isArray(p.variants) ? p.variants : [];
                  if (variants.length === 0) return null;
                  if (variants.length === 1) {
                    const v = variants[0];
                    const { attrs, price } = getVariantLabel(v);
                    return <option key={v.id} value={v.id}>{p.name} — ₹{price} ({attrs})</option>;
                  }
                  return (
                    <optgroup key={p.id} label={p.name}>
                      {variants.map(v => {
                        const { attrs, price } = getVariantLabel(v);
                        return <option key={v.id} value={v.id}>{attrs} — ₹{price}</option>;
                      })}
                    </optgroup>
                  );
                })}
              </select>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 8 }}>
                <div>
                  <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 2, display: "block" }}>Quantity</label>
                  <input type="number" min="1" value={item.default_qty} onChange={(e) => updateItem(idx, "default_qty", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.9rem", outline: "none" }} />
                </div>
                <div>
                  <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 2, display: "block" }}>Delivery Slot</label>
                  <select value={item.slot_id} onChange={(e) => updateItem(idx, "slot_id", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.9rem", outline: "none", backgroundColor: "#fff" }}>
                    <option value="">Select slot…</option>
                    {(config.slots || []).map(s => <option key={s.id} value={s.id}>{s.name} ({s.start_time} – {s.end_time})</option>)}
                  </select>
                </div>
              </div>

              <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 2, display: "block" }}>Schedule</label>
              <select value={item.schedule_type} onChange={(e) => updateItem(idx, "schedule_type", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.9rem", outline: "none", marginBottom: 8, backgroundColor: "#fff" }}>
                {SCHEDULE_TYPES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>

              {(item.schedule_type === "custom_days" || item.schedule_type === "weekly") && (
                <div style={{ marginBottom: 8 }}>
                  <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 4, display: "block" }}>
                    {item.schedule_type === "weekly" ? "Select one day per week" : "Select days"}
                  </label>
                  <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                    {DAYS.map((day, dayIdx) => {
                      const selected = (item.schedule_days || []).map(d => parseInt(d)).includes(dayIdx);
                      return (
                        <button key={dayIdx} type="button" onClick={(e) => { e.preventDefault(); toggleDay(idx, dayIdx); }} style={{ padding: "8px 14px", borderRadius: 8, border: `1px solid ${selected ? primaryColor : theme.border}`, background: selected ? `linear-gradient(135deg, ${primaryColor}, ${accentColor})` : "#fff", color: selected ? "#fff" : theme.dark, fontSize: "0.78rem", fontWeight: 600, cursor: "pointer" }}>
                          {day}
                        </button>
                      );
                    })}
                  </div>
                  {item.schedule_type === "weekly" && item.schedule_days?.length > 0 && (
                    <small style={{ color: theme.mid, fontSize: "0.7rem", marginTop: 4, display: "block" }}>Selected: {DAYS[item.schedule_days[0]]}</small>
                  )}
                </div>
              )}

              {item.schedule_type === "custom_dates" && (
                <div style={{ marginBottom: 8 }}>
                  <label style={{ fontSize: "0.72rem", color: theme.mid, marginBottom: 4, display: "block" }}>Select specific dates</label>
                  <CustomDatesPicker
                    selectedDates={item.schedule_dates}
                    onChange={(dates) => updateItem(idx, "schedule_dates", dates)}
                    primaryColor={primaryColor}
                    accentColor={accentColor}
                    minDate={config.earliest_start_date || startDate || toLocalISOString(new Date())}
                    blockedDates={blockedDates}
                  />
                </div>
              )}
            </div>
          ))}

          <button type="button" onClick={handleSubmit} disabled={saving || items.length === 0} style={{ width: "100%", padding: "14px", borderRadius: 12, background: saving ? "#E2E8F0" : `linear-gradient(135deg, ${primaryColor}, ${accentColor})`, color: saving ? "#94A3B8" : "#fff", border: "none", fontSize: "1rem", fontWeight: 700, cursor: saving ? "not-allowed" : "pointer", marginTop: 8 }}>
            {saving ? "Creating…" : "Create Subscription"}
          </button>
        </div>
      </div>
    </div>
  );
}