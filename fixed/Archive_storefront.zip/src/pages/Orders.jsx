import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Package, ChevronRight, ShoppingBag } from "lucide-react";
import customerApi, { unwrap } from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";
import SectionRenderer from "../components/SectionRenderer";

const theme = {
  primary: "#FF7132",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

const STATUS_CONFIG = {
  pending_payment:   { bg: "#FEF3C7", fg: "#92400E", label: "Payment Pending" },
  confirmed:         { bg: "#DBEAFE", fg: "#1E40AF", label: "Confirmed" },
  preparing:         { bg: "#E0E7FF", fg: "#3730A3", label: "Preparing" },
  out_for_delivery:  { bg: "#FFEDD5", fg: "#9A3412", label: "Out for Delivery" },
  delivered:         { bg: "#DCFCE7", fg: "#15803D", label: "Delivered" },
  cancelled:         { bg: "#FEE2E2", fg: "#B91C1C", label: "Cancelled" },
  payment_failed:    { bg: "#FEE2E2", fg: "#B91C1C", label: "Payment Failed" },
};

const fmtDate = (d) =>
  d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const fmtMoney = (n) => `₹${Number(n ?? 0).toFixed(2)}`;

const defaultOrdersData = {
  hero: { alignment: "center", badge: "Order History", title: "My Orders", subtitle: "Track your orders and view past purchases." },
  emptyState: { icon: "🛍️", title: "No orders yet", message: "When you place your first order, it will appear here.", buttonText: "Browse Products" },
  // ★ NEW: section_order allows admin to insert custom sections (media_carousel,
  // text_block, youtube_video, etc.) before or after the order list.
  section_order: ['hero', 'order_list'],
  section_visibility: {},
};

export default function Orders() {
  const navigate = useNavigate();
  const { isAuthenticated, customer } = useCustomerAuth();
  const { sections } = useTenant();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);

  // Read content from layout
  const safeSections = Array.isArray(sections) ? sections : [];
  const ordersData = safeSections.find((s) => s.page === "orders")?.data || defaultOrdersData;
  const hero = ordersData.hero || defaultOrdersData.hero;
  const emptyState = ordersData.emptyState || defaultOrdersData.emptyState;

  // ★ Read section_order — admin can insert custom sections before/after order list
  const sectionOrder = ordersData.section_order || ['hero', 'order_list'];
  const sectionVisibility = ordersData.section_visibility || {};

  useEffect(() => {
    if (!isAuthenticated) navigate("/", { replace: true });
  }, [isAuthenticated, navigate]);

  const fetchOrders = async (pageNum = 1) => {
    if (!isAuthenticated) return;
    setLoading(true);
    setError(null);
    try {
      const res = await customerApi.get(`/mobile/orders?page=${pageNum}`);
      const body = res.data;
      if (body?.status) {
        const data = body.data;
        const orderList = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
        setOrders(orderList);
        setLastPage(data?.last_page || 1);
        setPage(data?.current_page || 1);
      }
    } catch (e) {
      setError(e?.response?.data?.message || e.message || "Failed to load orders.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) fetchOrders();
  }, [isAuthenticated]);

  if (!isAuthenticated) {
    return <div style={{ padding: "3rem", textAlign: "center", color: theme.mid }}>Please log in to view your orders.</div>;
  }

  // ── Render the hero section ──
  const renderHero = () => (
    <div
      key="hero"
      style={{
        background: `linear-gradient(135deg, var(--color-primary, ${theme.primary}), var(--color-secondary, ${theme.primaryHover}))`,
        padding: "40px 24px 80px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
          backgroundSize: "30px 30px",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "relative",
          zIndex: 1,
          maxWidth: 1100,
          margin: "50px auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
        }}
      >
        <div
          style={{
            width: "100%",
            alignSelf: "stretch",
            textAlign: "left",
            marginBottom: 20,
          }}
        >
          <button
            onClick={() => navigate("/subscription")}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              background: "rgba(255,255,255,0.15)",
              border: "1px solid rgba(255,255,255,0.2)",
              color: "#fff",
              padding: "8px 16px",
              borderRadius: 100,
              fontSize: "0.85rem",
              fontWeight: 600,
              cursor: "pointer",
              backdropFilter: "blur(4px)",
            }}
          >
            <ArrowLeft size={14} /> Back
          </button>
        </div>

        <motion.span
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            display: "inline-block",
            background: "rgba(255,255,255,0.15)",
            border: "1px solid rgba(255,255,255,0.2)",
            color: "#fff",
            padding: "8px 20px",
            borderRadius: 100,
            fontSize: "0.85rem",
            fontWeight: 700,
            marginBottom: 16,
            backdropFilter: "blur(4px)",
          }}
        >
          {hero.badge}
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          style={{
            color: "#fff",
            fontSize: "clamp(1.75rem, 4vw, 2.5rem)",
            fontWeight: 900,
            margin: "0 0 8px",
            textShadow: "0 4px 12px rgba(0,0,0,0.2)",
            letterSpacing: "-0.02em",
          }}
        >
          {hero.title}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          style={{ color: "rgba(255,255,255,0.95)", fontSize: "1rem", margin: 0 }}
        >
          {hero.subtitle}
        </motion.p>
      </div>
    </div>
  );

  // ── Render the order list (the main content) ──
  const renderOrderList = () => (
    <div key="order_list" style={{ maxWidth: 900, margin: "-48px auto 0", padding: "0 24px", position: "relative", zIndex: 10 }}>
      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: theme.mid }}>
          <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
          Loading orders…
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      ) : error ? (
        <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12, padding: "1.5rem", color: "#b91c1c", textAlign: "center" }}>
          {error}
          <div style={{ marginTop: "0.75rem" }}>
            <button onClick={() => fetchOrders()} style={{ padding: "0.5rem 1rem", background: theme.primary, color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}>Retry</button>
          </div>
        </div>
      ) : orders.length === 0 ? (
        <div style={{ background: "#fff", border: `1px dashed ${theme.border}`, borderRadius: 14, padding: "3rem 1rem", textAlign: "center" }}>
          <div style={{ fontSize: "2.5rem", marginBottom: 16 }}>{emptyState.icon}</div>
          <h3 style={{ margin: "0 0 8px", color: theme.dark }}>{emptyState.title}</h3>
          <p style={{ color: theme.mid, margin: "0 auto 24px", maxWidth: 420 }}>{emptyState.message}</p>
          <button
            onClick={() => navigate("/products")}
            style={{ background: theme.primary, color: "#fff", border: "none", borderRadius: 999, padding: "0.65rem 1.4rem", fontWeight: 600, cursor: "pointer" }}
          >
            {emptyState.buttonText}
          </button>
        </div>
      ) : (
        <>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {orders.map((order, i) => {
              const status = STATUS_CONFIG[order.status] || { bg: "#F1F5F9", fg: "#64748B", label: order.status };
              const itemCount = (order.items || []).reduce((acc, it) => acc + Number(it.quantity || 0), 0);
              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => navigate(`/orders/${order.id}`)}
                  style={{
                    background: "#fff",
                    border: `1px solid ${theme.border}`,
                    borderRadius: 14,
                    padding: 20,
                    boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: 16,
                    transition: "transform 0.15s, box-shadow 0.15s",
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.08)"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.04)"; }}
                >
                  <div
                    style={{
                      width: 56,
                      height: 56,
                      borderRadius: 12,
                      background: status.bg,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <Package size={24} color={status.fg} />
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <h3 style={{ margin: 0, fontSize: "1rem", fontWeight: 700, color: theme.dark }}>
                        Order #{order.id}
                      </h3>
                      <span
                        style={{
                          background: status.bg,
                          color: status.fg,
                          padding: "2px 10px",
                          borderRadius: 100,
                          fontSize: "0.72rem",
                          fontWeight: 700,
                          textTransform: "uppercase",
                          letterSpacing: "0.04em",
                        }}
                      >
                        {status.label}
                      </span>
                    </div>
                    <div style={{ fontSize: "0.82rem", color: theme.mid, display: "flex", gap: 12, flexWrap: "wrap" }}>
                      <span>{fmtDate(order.created_at)}</span>
                      <span>•</span>
                      <span>{itemCount} item{itemCount !== 1 ? "s" : ""}</span>
                      {order.branch && (<><span>•</span><span>{order.branch.name}</span></>)}
                    </div>
                  </div>

                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontSize: "1.1rem", fontWeight: 800, color: theme.primary }}>{fmtMoney(order.total)}</div>
                    {order.coupon_discount > 0 && (
                      <div style={{ fontSize: "0.72rem", color: "#16A34A", fontWeight: 600 }}>−{fmtMoney(order.coupon_discount)} coupon</div>
                    )}
                    <ChevronRight size={16} color={theme.mid} style={{ marginTop: 4 }} />
                  </div>
                </motion.div>
              );
            })}
          </div>

          {lastPage > 1 && (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 8, marginTop: 24 }}>
              <button
                onClick={() => fetchOrders(page - 1)}
                disabled={page <= 1}
                style={{
                  padding: "8px 16px",
                  background: page <= 1 ? "#F1F5F9" : "#fff",
                  color: page <= 1 ? "#94A3B8" : theme.dark,
                  border: `1px solid ${theme.border}`,
                  borderRadius: 8,
                  cursor: page <= 1 ? "not-allowed" : "pointer",
                  fontWeight: 600,
                  fontSize: "0.85rem",
                }}
              >
                Prev
              </button>
              <span style={{ color: theme.mid, fontSize: "0.85rem" }}>Page {page} of {lastPage}</span>
              <button
                onClick={() => fetchOrders(page + 1)}
                disabled={page >= lastPage}
                style={{
                  padding: "8px 16px",
                  background: page >= lastPage ? "#F1F5F9" : "#fff",
                  color: page >= lastPage ? "#94A3B8" : theme.dark,
                  border: `1px solid ${theme.border}`,
                  borderRadius: 8,
                  cursor: page >= lastPage ? "not-allowed" : "pointer",
                  fontWeight: 600,
                  fontSize: "0.85rem",
                }}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );

  // Map built-in section keys to render functions
  const builtinRenderers = {
    hero: renderHero,
    order_list: renderOrderList,
  };

  // Build the list of sections to render
  const sectionsToRender = sectionOrder
    .filter(key => sectionVisibility[key] !== false)
    .map(key => {
      if (key.startsWith("custom-")) {
        const customData = ordersData[key] || {};
        return { id: key, type: customData.type || "text_block", data: customData, visible: true, isCustom: true };
      }
      return { id: key, type: key, data: ordersData[key] || {}, visible: true, isCustom: false };
    });

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: 40 }}>
      {/* ★ Dynamic section rendering — iterates section_order.
          Built-in sections (hero, order_list) use custom JSX.
          Custom sections (media_carousel, text_block, etc.) use SectionRenderer. */}
      {sectionsToRender.map(section => {
        if (!section.isCustom && builtinRenderers[section.type]) {
          return builtinRenderers[section.type]();
        }
        if (section.isCustom) {
          return <SectionRenderer key={section.id} section={section} />;
        }
        return null;
      })}
    </div>
  );
}
