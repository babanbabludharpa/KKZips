import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  FileText, Shield, Wallet, Truck, AlertCircle, RefreshCcw, Scale, CheckCircle2, ChevronRight,
} from "lucide-react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import api from "../utils/api"; // ⚠ SAME api import your working CartDrawer uses

const ICONS = { FileText, Shield, Wallet, Truck, AlertCircle, RefreshCcw, Scale, CheckCircle2 };
const getIcon = (name) => ICONS[name] || FileText;

const theme = {
  primary: "var(--color-secondary, #F97316)", // ★ now follows the site theme
  dark: "#002868",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

// ★ Fallback defaults — used until the published layout loads (or if fetch fails)
const DEFAULT_TERMS = {
  hero: { badge: "Legal Information", title: "Terms & Conditions", subtitle: "Please read these terms and conditions carefully before using our platform.", last_updated: "June 15, 2026" },
  intro: { title: "Agreement to Terms", content: "These Terms and Conditions constitute a legally binding agreement made between you, whether personally or on behalf of an entity (\"you\") and us (\"we,\" \"us\" or \"our\"), concerning your access to and use of our platform and daily subscription services." },
  sections: [
    { id: "acceptance", icon: "CheckCircle2", title: "1. Acceptance of Terms", content: "By accessing and using our website and mobile application (collectively, the \"Platform\"), you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you must not use our services. These terms apply to all visitors, users, and others who access or use the Service." },
    { id: "accounts", icon: "Shield", title: "2. User Accounts & Security", content: "To use certain features like Subscriptions and Wallet, you must register for an account. You are responsible for safeguarding the password and OTPs that you use to access the Service. We reserve the right to suspend or terminate accounts if any information provided is proven to be inaccurate, false, or in violation of these Terms." },
    { id: "wallet", icon: "Wallet", title: "3. Wallet & Auto-Pay", content: "We operate on a prepaid wallet model for daily subscriptions. \n\n• Users must maintain a minimum balance to ensure uninterrupted daily deliveries.\n• Auto-pay will automatically deduct the daily service charge (e.g., milk, tiffin) from your wallet upon successful delivery.\n• Wallet balances are non-transferable but can be refunded to the original payment source upon account closure, subject to a processing time of 5-7 business days." },
    { id: "deliveries", icon: "Truck", title: "4. Subscriptions & Deliveries", content: "• Morning deliveries (Milk, Newspaper, Flowers) are typically completed between 5:00 AM and 7:30 AM. \n• Users can pause or modify their daily subscription up until 9:00 PM the previous day. Changes made after the cutoff time will reflect on the subsequent day.\n• We act as an aggregator. While we strictly vet our local vendors for hygiene and quality, the respective vendors are ultimately responsible for the specific product quality." },
    { id: "cancellation", icon: "RefreshCcw", title: "5. Refunds & Cancellations", content: "• If an order is not delivered or delivered in a damaged/spoiled condition, users must raise a complaint within 12 hours of the delivery schedule.\n• Verified complaints will result in a direct refund to the Wallet within 24 hours.\n• One-time orders (non-subscription) cannot be cancelled once they are out for delivery." },
    { id: "liability", icon: "Scale", title: "6. Limitation of Liability", content: "In no event shall we, nor our directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service." },
    { id: "changes", icon: "AlertCircle", title: "7. Changes to Terms", content: "We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will notify users of any material changes via email or platform notifications. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms." },
  ],
  contact: { heading: "Still have questions?", text: "Our legal and support teams are here to help you understand our policies.", btn_text: "Contact Support", btn_link: "/contact" },
};

export default function Terms() {
  const [cfg, setCfg] = useState(DEFAULT_TERMS);
  const [activeSection, setActiveSection] = useState(DEFAULT_TERMS.sections[0]?.id);

  // ★ Load the published terms config (same endpoint your CartDrawer successfully uses)
  useEffect(() => {
    let cancelled = false;
    api
      .get("/web/layout") // ⚠ replace with the SAME layout endpoint your working CartDrawer uses
      .then((res) => {
        const raw = res.data?.data;
        const layout = Array.isArray(raw) ? raw[0] : raw;
        const comp = (layout?.layout_components || []).find((c) => c.page === "terms");
        if (!cancelled && comp?.data) {
          const merged = {
            hero: { ...DEFAULT_TERMS.hero, ...(comp.data.hero || {}) },
            intro: { ...DEFAULT_TERMS.intro, ...(comp.data.intro || {}) },
            sections: Array.isArray(comp.data.sections) ? comp.data.sections : DEFAULT_TERMS.sections,
            contact: { ...DEFAULT_TERMS.contact, ...(comp.data.contact || {}) },
          };
          setCfg(merged);
          setActiveSection(merged.sections[0]?.id);
        }
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const scrollToSection = (id) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -120;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = cfg.sections.map((t) => document.getElementById(t.id));
      const scrollPosition = window.scrollY + 150;
      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(section.id);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [cfg]);

  return (
    <>
      <Navbar />

      <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: "80px" }}>
        {/* ── Hero Header ──────────────────────────────────────── */}
        <section className="terms-hero">
          <div
            style={{
              position: "absolute", inset: 0,
              backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
              backgroundSize: "30px 30px", pointerEvents: "none",
            }}
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
            style={{ position: "relative", zIndex: 1, maxWidth: "800px", margin: "0 auto" }}
          >
            <div className="hero-badge">
              <FileText size={16} /> {cfg.hero.badge}
            </div>
            <h1 className="hero-title">{cfg.hero.title}</h1>
            <p className="hero-desc">
              {cfg.hero.subtitle}
              <br />
              {cfg.hero.last_updated && (
                <span style={{ color: theme.primary, fontWeight: "700", display: "inline-block", marginTop: "12px" }}>
                  Last Updated: {cfg.hero.last_updated}
                </span>
              )}
            </p>
          </motion.div>
        </section>

        {/* ── Main Content Layout ──────────────────────────────── */}
        <div style={{ maxWidth: "1200px", margin: "-40px auto 0", padding: "0 8px", position: "relative", zIndex: 10 }}>
          <div className="layout-grid">
            {/* LEFT: Sticky Table of Contents */}
            <div className="sidebar-wrapper">
              <motion.div
                initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}
                className="toc-card"
              >
                <h3 style={{ fontSize: "1.1rem", fontWeight: "900", color: theme.dark, marginBottom: "20px", letterSpacing: "-0.01em" }}>
                  Table of Contents
                </h3>
                <nav style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {cfg.sections.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => scrollToSection(item.id)}
                      className={`toc-btn ${activeSection === item.id ? "active" : ""}`}
                    >
                      <span className="toc-text">{item.title}</span>
                      {activeSection === item.id && <ChevronRight size={16} />}
                    </button>
                  ))}
                </nav>
              </motion.div>
            </div>

            {/* RIGHT: Legal Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}
              className="content-card"
            >
              {cfg.intro.title && (
                <div style={{ marginBottom: "40px", paddingBottom: "24px", borderBottom: `1px solid ${theme.border}` }}>
                  <h2 style={{ fontSize: "1.6rem", fontWeight: "900", color: theme.dark, marginBottom: "16px", letterSpacing: "-0.02em" }}>
                    {cfg.intro.title}
                  </h2>
                  <p style={{ color: theme.mid, fontSize: "1.05rem", lineHeight: "1.7", margin: 0 }}>
                    {cfg.intro.content}
                  </p>
                </div>
              )}

              <div style={{ display: "flex", flexDirection: "column", gap: "48px" }}>
                {cfg.sections.map((section) => {
                  const Icon = getIcon(section.icon);
                  return (
                    <section key={section.id} id={section.id} style={{ scrollMarginTop: "120px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "20px" }}>
                        <div className="section-icon">
                          <Icon size={24} color={theme.primary} />
                        </div>
                        <h2 style={{ fontSize: "1.4rem", fontWeight: "800", color: theme.dark, margin: 0 }}>
                          {section.title}
                        </h2>
                      </div>
                      <div className="section-body">
                        {(section.content || "").split("\n").map((paragraph, idx) => (
                          <p key={idx}>{paragraph}</p>
                        ))}
                      </div>
                    </section>
                  );
                })}
              </div>

              {cfg.contact.heading && (
                <div
                  style={{
                    marginTop: "60px", padding: "32px", background: "#F8FAFC", borderRadius: "20px",
                    border: `1px solid ${theme.border}`, textAlign: "center",
                  }}
                >
                  <h3 style={{ fontSize: "1.25rem", fontWeight: "800", color: theme.dark, marginBottom: "12px" }}>
                    {cfg.contact.heading}
                  </h3>
                  <p style={{ color: theme.mid, fontSize: "1rem", marginBottom: "20px" }}>{cfg.contact.text}</p>
                  <a
                    href={cfg.contact.btn_link || "/contact"}
                    style={{
                      display: "inline-block", background: theme.primary, color: "#fff", padding: "12px 28px",
                      borderRadius: "12px", textDecoration: "none", fontWeight: "700", transition: "all 0.2s",
                      boxShadow: "0 4px 14px rgba(249, 115, 22, 0.25)",
                    }}
                  >
                    {cfg.contact.btn_text || "Contact Support"}
                  </a>
                </div>
              )}
            </motion.div>
          </div>
        </div>

        {/* ── Styles (unchanged from your design) ── */}
        <style>{`
          .terms-hero { background: linear-gradient(135deg, #001440 0%, #001440 100%); padding: 80px 24px 64px; text-align: center; position: relative; overflow: hidden; }
          .hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(18, 89, 255, 0.21); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 8px 18px; border-radius: 100px; font-size: 0.85rem; font-weight: 700; margin-bottom: 24px; letter-spacing: 0.05em; text-transform: uppercase; }
          .hero-title { color: #fff; font-size: clamp(2.4rem, 5vw, 3.8rem); font-weight: 900; margin-bottom: 16px; letter-spacing: -0.03em; line-height: 1.1; }
          .hero-desc { color: rgba(255,255,255,0.9); font-size: clamp(1rem, 2vw, 1.15rem); max-width: 600px; margin: 0 auto; line-height: 1.5; }
          .layout-grid { display: grid; grid-template-columns: 320px 1fr; gap: 40px; align-items: start; }
          .sidebar-wrapper { position: sticky; top: 100px; }
          .toc-card { background: #fff; border-radius: 24px; padding: 32px 24px; box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border}; }
          .toc-btn { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; background: transparent; border: none; border-radius: 12px; color: ${theme.mid}; font-size: 0.95rem; font-weight: 600; cursor: pointer; text-align: left; transition: all 0.2s; font-family: inherit; }
          .toc-btn:hover { background: #F8FAFC; color: ${theme.dark}; }
          .toc-btn.active { background: #FFF7ED; color: ${theme.primary}; font-weight: 800; }
          .content-card { background: #fff; border-radius: 24px; padding: clamp(32px, 5vw, 56px); box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border}; }
          .section-icon { width: 48px; height: 48px; border-radius: 14px; background: #FFF7ED; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
          .section-body p { color: ${theme.mid}; font-size: 1.05rem; line-height: 1.75; margin-bottom: 12px; }
          .section-body p:last-child { margin-bottom: 0; }
          @media (max-width: 992px) {
            .layout-grid { grid-template-columns: 1fr; }
            .sidebar-wrapper { position: static; }
            .toc-card { padding: 24px; }
            .toc-card nav { flex-direction: row; overflow-x: auto; padding-bottom: 10px; scrollbar-width: none; }
            .toc-card nav::-webkit-scrollbar { display: none; }
            .toc-btn { white-space: nowrap; width: auto; padding: 12px 20px; }
          }
          @media (max-width: 640px) {
            .terms-hero { padding: 80px 24px 60px; }
            .content-card { padding: 32px 20px; }
            .section-icon { width: 40px; height: 40px; border-radius: 12px; }
            .section-icon svg { width: 20px; height: 20px; }
          }
        `}</style>
      </div>

      <Footer />
    </>
  );
}