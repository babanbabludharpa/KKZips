import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ShoppingCart, MapPin, Navigation, X, User, Truck, AlertCircle, Check, Repeat2 } from "lucide-react";import { useTenant } from "../contexts/TenantProvider";
import { useCart } from "./CartContext";
import { useCustomerAuth } from "../store/useCustomerAuth";
import customerApi from "../api/customerApi";
import SectionRenderer from "../components/SectionRenderer";
import CartDrawer from "../components/CartDrawer";
import { useSubscription } from "./SubscriptionContext";
import SubscriptionCartDrawer from "../components/SubscriptionCartDrawer";
// ★ FIX: No hardcoded theme — built dynamically inside the component from useTenant()

const DEFAULT_SECTION_ORDER = [
  "hero", "carousel", "categories", "mission", "products", "testimonials", "cta",
  // ★ "categories" is now part of section_order — admin can reorder/hide it
];

function fixImageUrl(url) {
  if (!url) return null;
  if (url.startsWith("http") || url.startsWith("data:") || url.startsWith("blob:")) {
    return url;
  }
  const backendUrl =
    import.meta.env.VITE_API_URL ||
    import.meta.env.VITE_BACKEND_URL ||
    "http://localhost:8000";
  return backendUrl + (url.startsWith("/") ? url : "/" + url);
}

function extractLatLng(addr) {
  if (!addr) return null;
  const latCandidates = ["latitude", "lat", "Latitude"];
  const lngCandidates = ["longitude", "lng", "long", "Longitude"];
  let lat = null, lng = null;
  for (const f of latCandidates) {
    if (addr[f] != null && addr[f] !== "") {
      lat = parseFloat(addr[f]);
      if (!isNaN(lat)) break;
      lat = null;
    }
  }
  for (const f of lngCandidates) {
    if (addr[f] != null && addr[f] !== "") {
      lng = parseFloat(addr[f]);
      if (!isNaN(lng)) break;
      lng = null;
    }
  }
  if (lat === null || lng === null) return null;
  return { lat, lng };
}

export default function Home() {
  const { sections, isLoading, theme: tenantTheme } = useTenant();
  const { addToCart, cartCount, isCartOpen, setIsCartOpen } = useCart(); 
  const { add: addSub, has: subHas, count: subCount } = useSubscription();   // ← ADD THIS
  const [subCartOpen, setSubCartOpen] = useState(false);                    // ← AND THIS

  const { isAuthenticated } = useCustomerAuth();
  const navigate = useNavigate();

  // ★ Dynamic theme — primary from tenant, neutrals stay constant
  const theme = {
    primary: tenantTheme?.primary_color || "#666666",
    dark: "#1E293B",
    mid: "#64748B",
    bg: "#F8FAFF",
    border: "#E2E8F0",
  };

  const [products, setProducts] = useState([]);
  const [subscriptionProducts, setSubscriptionProducts] = useState([]);
  const [categories, setCategories] = useState([]);

  // ── Location state ──────────────────────────────────────────
  const [customerLatLng, setCustomerLatLng] = useState(null);
  const [locationSource, setLocationSource] = useState(null);
  const [locationWarning, setLocationWarning] = useState(null);
  const [showLocationModal, setShowLocationModal] = useState(false);

  // ── Delivery zone state ─────────────────────────────────────
  const [isDeliverable, setIsDeliverable] = useState(true);
  const [deliveryCheckDone, setDeliveryCheckDone] = useState(false);

  const [toast, setToast] = useState(null);

  const showToast = (msg, kind = "info") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3000);
  };

  // ── 1. Location resolution ──────────────────────────────────
  useEffect(() => {
    if (!isAuthenticated) {
      requestBrowserLocation();
      return;
    }
    const fetchAddr = async () => {
      try {
        const res = await customerApi.get("/mobile/addresses");
        const addrs = res.data?.data || [];
        const def = addrs.find((a) => a.is_default) || addrs[0];
        const ll = extractLatLng(def);
        if (ll) {
          setCustomerLatLng(ll);
          setLocationSource("address");
          setLocationWarning(null);
        } else {
          requestBrowserLocation();
        }
      } catch (e) {
        requestBrowserLocation();
      }
    };
    fetchAddr();
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) return;
    requestBrowserLocation();
  }, [isAuthenticated]);

  const requestBrowserLocation = () => {
    if (!navigator.geolocation) {
      setLocationWarning(
        "Your browser doesn't support geolocation. Please log in and add a default address to see products available in your area."
      );
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCustomerLatLng({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocationSource("geolocation");
        setLocationWarning(null);
      },
      () => {
        setLocationWarning(
          isAuthenticated
            ? "No default address with location found, and browser geolocation was denied. Please add a default address with your location, or allow location access."
            : "Browser geolocation was denied. Please allow location access, or log in and add a default address."
        );
      },
      { timeout: 8000, enableHighAccuracy: false }
    );
  };

  const clearLocation = () => {
    setCustomerLatLng(null);
    setLocationSource(null);
    setLocationWarning(null);
    setIsDeliverable(true);
    setDeliveryCheckDone(false);
    showToast("Location cleared — showing all products");
  };

  const goToLogin = () => {
    setShowLocationModal(false);
    navigate("/login");
  };

  // ── 3. Fetch products ───────────────────────────────────────
  useEffect(() => {
    if (isLoading) return;
    const fetchData = async () => {
      try {
        setDeliveryCheckDone(false);
        const params = { per_page: 50 };
        if (customerLatLng) {
          params.lat = customerLatLng.lat;
          params.lng = customerLatLng.lng;
        }
        const [prodRes, catRes] = await Promise.all([
          customerApi.get("/mobile/products", { params }),
          customerApi.get("/mobile/products/categories"),
        ]);

        if (prodRes.data?.status) {
          const list = Array.isArray(prodRes.data.data) ? prodRes.data.data : [];

          if (customerLatLng && list.length > 0) {
            const allVariants = list.flatMap((p) => p.variants || []);
            const variantsWithStock = allVariants.filter(
              (v) => v.available_stock !== null && v.available_stock !== undefined
            );
            setIsDeliverable(!(allVariants.length > 0 && variantsWithStock.length === 0));
          } else {
            setIsDeliverable(true);
          }
          setDeliveryCheckDone(true);

          setProducts(
            list.map((p) => {
              const firstVariant = p.variants?.[0] || {};
              return {
                id: p.id,
                name: p.name,
                category: p.category_name || "General",
                variants: (p.variants || []).map((v) => ({
                  id: v.id,
                  sku: v.sku,
                  final_price: Number(v.final_price || 0),
                  mrp: Number(v.mrp || 0),
                  has_discount: v.has_discount || false,
                  discount_percent: Number(v.discount_percent || 0),
                  unit_abbr: v.unit_abbr || "",
                  image_url: v.image_url || null,
                  available_stock: v.available_stock ?? null,
                  is_out_of_stock: v.is_out_of_stock || false,
                  is_low_stock: v.is_low_stock || false,
                  attributes: v.attributes || [],
                })),
                variant_id: firstVariant.id,
                image_url: firstVariant.image_url || null,
                price: Number(firstVariant.final_price || 0),
                mrp: Number(firstVariant.mrp || 0),
                has_discount: firstVariant.has_discount || false,
                discount_percent: Number(firstVariant.discount_percent || 0),
                unit_abbr: firstVariant.unit_abbr || "",
                unit: "/ " + (firstVariant.unit_abbr || "unit"),
                available_stock: firstVariant.available_stock ?? null,
                is_out_of_stock: firstVariant.is_out_of_stock || false,
                is_low_stock: firstVariant.is_low_stock || false,
              };
            })
          );
        }
        // ★ subscription-channel products for the home widget
        try {
          const subParams = { channel: "subscription" };
          if (customerLatLng) {
            subParams.lat = customerLatLng.lat;
            subParams.lng = customerLatLng.lng;
          }
          const subRes = await customerApi.get("/mobile/products", { params: subParams });
          if (subRes.data?.status) {
            const subList = Array.isArray(subRes.data.data) ? subRes.data.data : [];
            setSubscriptionProducts(
              subList.map((p) => {
                const firstVariant =
                  [...(p.variants || [])].find((v) => v.is_out_of_stock !== true) ||
                  (p.variants || [])[0] || {};
                return {
                  id: p.id,
                  name: p.name,
                  variant_id: firstVariant.id,          // ★ the create page pre-fills from this
                  image_url: firstVariant.image_url || null,
                  price: Number(firstVariant.final_price || 0),
                  unit: "/ " + (firstVariant.unit_abbr || "unit"),
                  is_out_of_stock: firstVariant.is_out_of_stock || false,
                  available_stock: firstVariant.available_stock ?? null,
                  attributes: firstVariant.attributes || [],
                };
              })
            );
          }
        } catch (e) {}
        if (catRes.data?.status) {
          setCategories(Array.isArray(catRes.data.data) ? catRes.data.data : []);
        }
      } catch (err) {
        console.error("Failed to fetch data", err);
      }
    };
    fetchData();
  }, [isLoading, customerLatLng]);

  // ── Add to cart with zone + stock validation ────────────────
  const handleAddToCart = (product) => {
    if (!isDeliverable) {
      showToast("Delivery is not available at your location.", "error");
      return;
    }
    if (product.is_out_of_stock === true) {
      showToast(`${product.name} is out of stock`, "error");
      return;
    }
    if (product.available_stock !== null && product.available_stock !== undefined && product.available_stock <= 0) {
      showToast(`${product.name} is out of stock`, "error");
      return;
    }
    const result = addToCart({
      id: product.id,
      variant_id: product.variant_id,
      name: product.name,
      price: product.price,
      unit: product.unit_abbr || product.unit || "",
      image_url: product.image_url,
      quantity: 1,
      is_out_of_stock: product.is_out_of_stock || false,
      available_stock: product.available_stock ?? null,
      attributes: product.attributes || [],   // ★ NEW
    });
    if (result?.success === false) {
      showToast(result.error || "Could not add to cart", "error");
    } else {
      showToast(`${product.name} added to cart`, "success");
    }
  };

    const handleAddToSubscription = (p) => {
    if (!isDeliverable) { showToast("Delivery is not available at your location.", "error"); return; }
    if (p.is_out_of_stock === true) { showToast(`${p.name} is out of stock`, "error"); return; }
    addSub({
      variant_id: p.variant_id,
      id: p.variant_id,
      name: p.name,
      price: p.price,
      unit: p.unit,               // already "/ 500g" format from your mapping
      image_url: p.image_url,
      attributes: p.attributes || [],
    });
    showToast(`${p.name} added to subscription basket`, "success");
  };

  if (isLoading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              width: 40, height: 40,
              border: `4px solid ${theme.border}`,
              borderTopColor: theme.primary,
              borderRadius: "50%",
              margin: "0 auto 16px",
              animation: "spin 0.8s linear infinite",
            }}
          />
          <div style={{ color: theme.mid }}>Loading…</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  const safeSections = Array.isArray(sections) ? sections : [];
  const homeData = safeSections.find((s) => s.page === "home")?.data || {};
  const sectionOrder = homeData.section_order || DEFAULT_SECTION_ORDER;
  const sectionVisibility = homeData.section_visibility || {};
  const carouselImages = (homeData.carousel?.images || []).map((img) => fixImageUrl(img));

  const sectionsToRender = sectionOrder
    .filter((key) => sectionVisibility[key] !== false)
    .map((key) => {
      if (key === "hero") {
        const heroImages = (homeData.hero?.images || []).map((img) => fixImageUrl(img));
        return { id: key, type: "hero", data: { ...homeData.hero, hero_images: heroImages }, visible: true };
      }
      if (key === "carousel") {
        return { id: key, type: "carousel", data: { ...homeData.carousel, images: carouselImages }, visible: true };
      }
      if (key === "products") {
        return {
          id: key,
          type: "products",
          // ★ Pass FULL array — SectionRenderer paginates with its own Load More
          data: { products, isDeliverable, deliveryCheckDone, customerLatLng },
          visible: true,
        };
      }
      if (key === "categories") {
        return { id: key, type: "categories", data: { categories }, visible: true };
      }
      if (key.startsWith("custom-")) {
        const customData = homeData[key] || {};
        return { id: key, type: customData.type || "text_block", data: customData, visible: true };
      }
      return { id: key, type: key, data: homeData[key] || {}, visible: true };
    });

  return (
    <div style={{ background: theme.bg }}>
      {/* ★ NOT DELIVERABLE BANNER */}
      {deliveryCheckDone && !isDeliverable && (
        <div style={{ background: "#FEF2F2", borderBottom: "2px solid #FECACA", padding: "16px 24px", position: "sticky", top: 0, zIndex: 30 }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: "#FEE2E2", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Truck size={20} color="#DC2626" />
            </div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <h3 style={{ margin: 0, fontSize: "0.95rem", fontWeight: 800, color: "#B91C1C" }}>Delivery not available at your location</h3>
              <p style={{ margin: "4px 0 0", fontSize: "0.82rem", color: "#991B1B" }}>
                We can't deliver to {customerLatLng ? `${customerLatLng.lat.toFixed(4)}, ${customerLatLng.lng.toFixed(4)}` : "your location"}. Please set a different location within our delivery zone.
              </p>
            </div>
            <button onClick={() => setShowLocationModal(true)} style={{ padding: "10px 20px", background: "#DC2626", color: "#fff", border: "none", borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
              <MapPin size={16} /> Set Different Location
            </button>
          </div>
        </div>
      )}

      {/* ★ LOCATION STATUS BAR — deliverable */}
      {isDeliverable && customerLatLng && !locationWarning && (
        <div style={{ background: "#F0FDF4", borderBottom: "1px solid #BBF7D0", padding: "6px 24px", display: "flex", alignItems: "center", gap: 8, fontSize: "0.75rem", color: "#16A34A", flexWrap: "wrap", position: "sticky", top: 0, zIndex: 30 }}>
          <MapPin size={14} />
          <span>
            Showing products for your location ({locationSource === "address" ? "saved address" : "browser"}): {customerLatLng.lat.toFixed(4)}, {customerLatLng.lng.toFixed(4)}
          </span>
          <button onClick={() => setShowLocationModal(true)} style={{ marginLeft: "auto", padding: "2px 10px", background: "transparent", color: "#16A34A", border: "1px solid #16A34A", borderRadius: 4, cursor: "pointer", fontSize: "0.7rem", fontWeight: 600 }}>Change</button>
          <button onClick={clearLocation} style={{ padding: "2px 10px", background: "transparent", color: "#92400E", border: "1px solid #FCD34D", borderRadius: 4, cursor: "pointer", fontSize: "0.7rem", fontWeight: 600 }}>Clear</button>
        </div>
      )}

      {/* ★ LOCATION WARNING */}
      {locationWarning && (
        <div style={{ background: "#FEF3C7", borderBottom: "1px solid #FCD34D", padding: "10px 24px", display: "flex", alignItems: "center", gap: 8, fontSize: "0.85rem", color: "#92400E", flexWrap: "wrap", position: "sticky", top: 0, zIndex: 30 }}>
          <MapPin size={16} />
          <span style={{ flex: 1 }}>{locationWarning}</span>
          <button onClick={() => setShowLocationModal(true)} style={{ padding: "4px 12px", background: theme.primary, color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", fontSize: "0.75rem", fontWeight: 600 }}>Set Location</button>
        </div>
      )}

      {/* ★ Sections — includes categories */}
      {sectionsToRender.map((section) => (
        <SectionRenderer
          key={section.id}
          section={section}
          addToCart={handleAddToCart}
          cartCount={cartCount}
          setIsCartOpen={setIsCartOpen}
        />
      ))}
            {/* ★ SUBSCRIPTION — finally uses subscriptionProducts */}
      {subscriptionProducts.length > 0 && (
        <div style={{ maxWidth: 1200, margin: "32px auto", padding: "0 24px" }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 14 }}>
            <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: theme.dark, margin: 0 }}>Subscribe & Save</h2>
            <span style={{ fontSize: "0.8rem", color: theme.mid }}>Delivered on your schedule</span>
            <button onClick={() => navigate("/subscription")} style={{ marginLeft: "auto", background: "none", border: "none", color: theme.primary, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}>
              My Subscriptions →
            </button>
          </div>
          <div style={{ display: "flex", gap: 14, overflowX: "auto", paddingBottom: 8 }}>
            {subscriptionProducts.filter((p) => p.is_out_of_stock !== true).map((p) => {
              const added = subHas(p.variant_id);
              return (
                <div key={p.variant_id} style={{ minWidth: 170, background: "#fff", border: `1px solid ${theme.border}`, borderRadius: 14, padding: 12 }}>
                  <img src={fixImageUrl(p.image_url) || undefined} alt={p.name} style={{ width: "100%", height: 110, objectFit: "cover", borderRadius: 10, background: "#F1F5F9" }} />
                  <div style={{ fontWeight: 700, fontSize: "0.85rem", color: theme.dark, marginTop: 8, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                  <div style={{ fontSize: "0.78rem", color: theme.mid, margin: "2px 0 8px" }}>₹{p.price} {p.unit}</div>
                  <button onClick={() => handleAddToSubscription(p)} disabled={added}
                    style={{ width: "100%", padding: 8, borderRadius: 8, border: "none", fontWeight: 700, fontSize: "0.78rem", cursor: added ? "default" : "pointer", background: added ? "#F0FDF4" : theme.primary, color: added ? "#16A34A" : "#fff" }}>
                    {added ? "Added ✓" : "Add to subscription"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating cart */}
      {cartCount > 0 && !isCartOpen && (
        <button
          onClick={() => setIsCartOpen(true)}
          style={{
            position: "fixed", bottom: 24, right: 24, zIndex: 100,
            background: "var(--color-primary, #666666)",
            color: "#fff", border: "none", borderRadius: 999,
            padding: "14px 24px", fontSize: "0.95rem", fontWeight: 700, cursor: "pointer",
            display: "flex", alignItems: "center", gap: 8,
            boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
          }}
        >
          <ShoppingCart size={20} /> {cartCount} item{cartCount !== 1 ? "s" : ""}{" "}
          <span style={{ marginLeft: 4, fontSize: "0.8rem", opacity: 0.8 }}>View Cart →</span>
        </button>
      )}
      {/* ★ Floating SUBSCRIPTION basket — bottom-LEFT */}
      {subCount > 0 && !subCartOpen && (
        <button onClick={() => setSubCartOpen(true)}
          style={{ position: "fixed", bottom: 24, left: 24, zIndex: 100, background: "var(--color-primary, #666666)", color: "#fff", border: "none", borderRadius: 999, padding: "14px 20px", fontSize: "0.9rem", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, boxShadow: "0 8px 24px rgba(0,0,0,0.2)" }}>
          <Repeat2 size={18} /> {subCount} item{subCount !== 1 ? "s" : ""} · Subscription basket
        </button>
      )}

      {/* ★ LOCATION MODAL */}
      {showLocationModal && (
        <div
          onClick={() => setShowLocationModal(false)}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            style={{ background: "#fff", borderRadius: 16, maxWidth: 440, width: "100%", padding: 24, position: "relative" }}
          >
            <button onClick={() => setShowLocationModal(false)} style={{ position: "absolute", top: 12, right: 12, background: "none", border: "none", cursor: "pointer", color: theme.mid }}>
              <X size={20} />
            </button>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#FFF7ED", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
                <MapPin size={28} color={theme.primary} />
              </div>
              <h3 style={{ fontSize: "1.15rem", fontWeight: 800, color: theme.dark, margin: "0 0 4px" }}>Set your delivery location</h3>
              <p style={{ fontSize: "0.82rem", color: theme.mid, margin: 0 }}>
                Allow location access to see products available in your area, or log in and add a saved address.
              </p>
            </div>

            <button
              onClick={() => { setShowLocationModal(false); requestBrowserLocation(); }}
              style={{ width: "100%", padding: "12px", background: theme.primary, color: "#fff", border: "none", borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 12 }}
            >
              <Navigation size={16} /> Use my current location
            </button>

            <div style={{ textAlign: "center", margin: "8px 0 12px", color: theme.mid, fontSize: "0.75rem" }}>OR</div>

            {isAuthenticated ? (
              <button
                onClick={() => { setShowLocationModal(false); navigate("/addresses"); }}
                style={{ width: "100%", padding: "12px", background: "transparent", color: theme.primary, border: `1px solid ${theme.primary}`, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
              >
                <MapPin size={16} /> Manage saved addresses
              </button>
            ) : (
              <button
                onClick={goToLogin}
                style={{ width: "100%", padding: "12px", background: "transparent", color: theme.primary, border: `1px solid ${theme.primary}`, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
              >
                <User size={16} /> Login & Add Address
              </button>
            )}

            <p style={{ fontSize: "0.72rem", color: theme.mid, textAlign: "center", margin: "12px 0 0", lineHeight: 1.5 }}>
              {isAuthenticated ? (
                <Link to="/addresses" style={{ color: theme.primary, fontWeight: 600 }}>Go to saved addresses →</Link>
              ) : (
                "You'll be asked to log in first, then you can add a default address with your location."
              )}
            </p>
          </motion.div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: "fixed", bottom: 90, right: 24, zIndex: 10000,
            background: toast.kind === "error" ? "#EF4444" : toast.kind === "success" ? "#22C55E" : "#3B82F6",
            color: "#fff", padding: "12px 20px", borderRadius: 10,
            boxShadow: "0 10px 30px rgba(0,0,0,0.3)", fontWeight: 600, fontSize: "0.9rem",
            display: "flex", alignItems: "center", gap: 8,
          }}
        >
          {toast.kind === "error" ? <AlertCircle size={16} /> : <Check size={16} />}
          {toast.msg}
        </div>
      )}

      <CartDrawer />
            <SubscriptionCartDrawer open={subCartOpen} onClose={() => setSubCartOpen(false)} />
    </div>
  );
}//testing storage link exclude or not