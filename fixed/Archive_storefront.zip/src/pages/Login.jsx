import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle, X } from "lucide-react";
import toast from "react-hot-toast";
import { useCustomerAuth } from "../store/useCustomerAuth";
// ★ ADDED: Dynamic tenant branding
import { useTenant } from "../contexts/TenantProvider";

export default function Login({ onClose }) {
  const navigate = useNavigate();
  const { login, clearError } = useCustomerAuth();
  const [form, setForm] = useState({ phone: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  // ★ ADDED: Fetch tenant theme dynamically
  const { theme: tenantTheme } = useTenant() || {};
  const primaryColor = tenantTheme?.primary_color || "#FF7132";
  const accentColor = tenantTheme?.secondary_color || "#1E293B";
  const logoUrl = tenantTheme?.logo_url;
  const brandName = tenantTheme?.brand_name || "Shop Hub";

  const isModal = typeof onClose === "function";

  const validate = () => {
    const errs = {};
    if (!form.phone) errs.phone = "Phone number is required.";
    else if (!/^\d{10}$/.test(form.phone.replace(/\D/g, "")))
      errs.phone = "Enter a valid 10-digit phone number.";
    if (!form.password) errs.password = "Password is required.";
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    setErrors({});
    setLoading(true);
    clearError();

    const ok = await login({
      phone: form.phone,
      password: form.password,
    });

    if (ok) {
      toast.success("Welcome back!");
      if (isModal) onClose();
      navigate("/", { replace: true });
    } else {
      const { error } = useCustomerAuth.getState();
      const msg = error || "Invalid phone number or password.";

      if (/phone/i.test(msg)) {
        setErrors({ phone: msg });
      } else if (/password/i.test(msg)) {
        setErrors({ password: msg });
      } else {
        toast.error(msg);
      }
    }

    setLoading(false);
  };

  const handleChange = (field) => (e) => {
    setForm((p) => ({ ...p, [field]: e.target.value }));
    if (errors[field]) setErrors((p) => ({ ...p, [field]: "" }));
  };

  // ── ROUTE MODE (full page) ─────────────────────────────────────────────
  if (!isModal) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 24,
          background: "var(--color-bg, #F8FAFF)",
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 32, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          style={{
            width: "100%",
            maxWidth: "480px",
            background: "#ffffff",
            borderRadius: "24px",
            padding: "30px",
            border: `1px solid #E0E0E0`,
            boxShadow: "0 24px 64px rgba(0,0,0,0.1)",
          }}
        >
          <LoginFormBody
            form={form}
            errors={errors}
            loading={loading}
            handleChange={handleChange}
            handleSubmit={handleSubmit}
            primaryColor={primaryColor}
            accentColor={accentColor}
            logoUrl={logoUrl}
            brandName={brandName}
          />
        </motion.div>
      </div>
    );
  }

  // ── MODAL MODE (overlay) ───────────────────────────────────────────────
  return (
    <AnimatePresence>
      <div
        style={{
          position: "fixed",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "24px",
          zIndex: 1000,
          backgroundColor: "rgba(0,0,0,0.5)",
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
        }}
        // ★ FIX 1: Removed onClick={onClose} so clicking background does NOT close modal
      >
        <motion.div
          initial={{ opacity: 0, y: 32, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.98 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          style={{
            width: "100%",
            maxWidth: "480px",
            background: "#ffffff",
            borderRadius: "24px",
            padding: "30px",
            border: `1px solid #E0E0E0`,
            boxShadow: "0 24px 64px rgba(0,0,0,0.2)",
            position: "relative",
          }}
        >
          {/* Close Icon (only in modal mode) - Clicking this is the ONLY way to close */}
          <button
            type="button"
            onClick={onClose}
            style={{
              position: "absolute",
              top: "20px",
              right: "20px",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: "8px",
              color: primaryColor, // ★ Dynamic color
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={24} />
          </button>

          <LoginFormBody
            form={form}
            errors={errors}
            loading={loading}
            handleChange={handleChange}
            handleSubmit={handleSubmit}
            primaryColor={primaryColor}
            accentColor={accentColor}
            logoUrl={logoUrl}
            brandName={brandName}
          />
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

// ── Shared form body (used by both modal + route modes) ─────────────────
function LoginFormBody({ form, errors, loading, handleChange, handleSubmit, primaryColor, accentColor, logoUrl, brandName }) {
  return (
    <>
      {/* ★ DYNAMIC Logo Area */}
      <div style={{ textAlign: "center", marginBottom: "32px" }}>
        <Link
          to="/"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            textDecoration: "none",
            marginBottom: "24px",
          }}
        >
          {logoUrl ? (
            <img
              src={logoUrl}
              alt={brandName}
              style={{ height: "45px", width: "auto", objectFit: "contain" }}
              onError={(e) => { e.target.style.display = 'none'; }}
            />
          ) : (
            <div style={{ 
              width: "40px", 
              height: "40px", 
              borderRadius: "10px", 
              background: `linear-gradient(135deg, ${primaryColor}, ${accentColor})`,
              display: "flex", 
              alignItems: "center", 
              justifyContent: "center",
            }}>
              <span style={{ color: "#fff", fontSize: "1.2rem", fontWeight: 800 }}>
                {brandName?.charAt(0)?.toUpperCase() || "S"}
              </span>
            </div>
          )}
        </Link>
        <h1
          style={{
            fontSize: "20px",
            fontWeight: "800",
            color: "#333333",
            letterSpacing: "-0.025em",
            marginBottom: "8px",
          }}
        >
          Welcome back
        </h1>
        <p style={{ color: "#666666", fontSize: "0.95rem" }}>
          Sign in to continue shopping
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} noValidate>
        {/* Phone Number */}
        <div style={{ marginBottom: "20px" }}>
          <label
            style={{
              display: "block",
              fontSize: "0.9rem",
              fontWeight: "600",
              color: "#333333",
              marginBottom: "8px",
            }}
          >
            Phone Number
          </label>
          <input
            type="tel"
            value={form.phone}
            onChange={handleChange("phone")}
            placeholder="9876543210"
            maxLength={10}
            style={{
              width: "100%",
              padding: "14px 16px",
              borderRadius: "12px",
              border: `1.5px solid ${errors.phone ? "#EF4444" : "#E0E0E0"}`,
              fontSize: "0.95rem",
              color: "#333333",
              outline: "none",
              transition: "border-color 0.2s",
              backgroundColor: "#fff",
              boxSizing: "border-box",
            }}
            onFocus={(e) => {
              if (!errors.phone) e.target.style.borderColor = primaryColor; // ★ Dynamic
            }}
            onBlur={(e) => {
              if (!errors.phone) e.target.style.borderColor = "#E0E0E0";
            }}
          />
          {errors.phone && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "5px",
                marginTop: "6px",
              }}
            >
              <AlertCircle size={14} color="#EF4444" />
              <span style={{ color: "#EF4444", fontSize: "0.82rem" }}>
                {errors.phone}
              </span>
            </motion.div>
          )}
        </div>

        {/* Password */}
        <div style={{ marginBottom: "24px" }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "8px",
            }}
          >
            <label
              style={{
                fontSize: "0.9rem",
                fontWeight: "600",
                color: "#333333",
              }}
            >
              Password
            </label>
            <a
              href="#"
              style={{
                fontSize: "0.85rem",
                color: primaryColor, // ★ Dynamic
                textDecoration: "none",
                fontWeight: "600",
              }}
            >
              Forgot password?
            </a>
          </div>
          <input
            type="password"
            value={form.password}
            onChange={handleChange("password")}
            placeholder="Please Enter Your Password"
            style={{
              width: "100%",
              padding: "14px 16px",
              borderRadius: "12px",
              border: `1.5px solid ${errors.password ? "#EF4444" : "#E0E0E0"}`,
              fontSize: "0.95rem",
              color: "#333333",
              outline: "none",
              transition: "border-color 0.2s",
              backgroundColor: "#fff",
              boxSizing: "border-box",
            }}
            onFocus={(e) => {
              if (!errors.password) e.target.style.borderColor = primaryColor; // ★ Dynamic
            }}
            onBlur={(e) => {
              if (!errors.password) e.target.style.borderColor = "#E0E0E0";
            }}
          />
          {errors.password && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "5px",
                marginTop: "6px",
              }}
            >
              <AlertCircle size={14} color="#EF4444" />
              <span style={{ color: "#EF4444", fontSize: "0.82rem" }}>
                {errors.password}
              </span>
            </motion.div>
          )}
        </div>

        {/* ★ DYNAMIC Submit Button */}
        <button
          type="submit"
          disabled={loading}
          style={{
            width: "100%",
            padding: "16px",
            borderRadius: "14px",
            border: "none",
            // ★ FIX 2: Use dynamic primary color instead of hardcoded #FF7132
            background: loading ? `${primaryColor}80` : primaryColor,
            color: "#fff",
            fontSize: "1rem",
            fontWeight: "700",
            cursor: loading ? "not-allowed" : "pointer",
            transition: "all 0.2s",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            boxShadow: `0 4px 12px ${primaryColor}50`,
          }}
          onMouseEnter={(e) => {
            if (!loading) {
              e.currentTarget.style.background = accentColor; // ★ Dynamic hover
              e.currentTarget.style.transform = "translateY(-1px)";
            }
          }}
          onMouseLeave={(e) => {
            if (!loading) {
              e.currentTarget.style.background = primaryColor; // ★ Dynamic reset
              e.currentTarget.style.transform = "none";
            }
          }}
        >
          {loading ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{
                  duration: 0.8,
                  repeat: Infinity,
                  ease: "linear",
                }}
                style={{
                  width: "18px",
                  height: "18px",
                  border: "2px solid rgba(255,255,255,0.3)",
                  borderTopColor: "#fff",
                  borderRadius: "50%",
                }}
              />
              Signing in…
            </>
          ) : (
            "Sign In"
          )}
        </button>
      </form>

      {/* Footer link */}
      <div
        style={{
          textAlign: "center",
          marginTop: "32px",
          fontSize: "0.9rem",
          color: "#333333",
          display: "flex",
          gap: "6px",
          justifyContent: "center",
        }}
      >
        <span>Don't have an account?</span>
        <Link
          to="/register"
          style={{
            color: primaryColor, // ★ Dynamic
            fontWeight: "700",
            textDecoration: "none",
          }}
        >
          Sign Up
        </Link>
      </div>
    </>
  );
}
