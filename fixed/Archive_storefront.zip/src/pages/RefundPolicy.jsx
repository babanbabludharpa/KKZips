import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  RotateCcw, RefreshCcw, Undo2, Ban, Clock, CalendarClock, CalendarX,
  CreditCard, Wallet, Banknote, ShieldCheck, BadgeCheck, PackageCheck, PackageX,
  AlertCircle, MessageCircle, Receipt, Scale, FileText, ChevronRight,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

// ═══════════════════════════════════════════════════════════════
// Icon map — string names (stored in admin) → Lucide components.
// ═══════════════════════════════════════════════════════════════
const ICON_MAP = {
  RotateCcw, RefreshCcw, Undo2, Ban, Clock, CalendarClock, CalendarX,
  CreditCard, Wallet, Banknote, ShieldCheck, BadgeCheck, PackageCheck, PackageX,
  AlertCircle, MessageCircle, Receipt, Scale, FileText,
};

// Default data — used when the tenant hasn't configured their refund page yet.
const DEFAULT_REFUND_DATA = {
  hero: {
    badge: "Our Policy",
    title: "Refunds & Cancellations",
    subtitle: "Flexible cancellation windows, honest refunds, and zero fine-print surprises.",
    last_updated: "November 1, 2026",
  },
  intro: {
    title: "Fair, Fast & Transparent",
    content: "We want you to subscribe with confidence. This policy explains exactly when you can cancel, how refunds are processed, and how quickly money returns to you — in plain, simple language.",
  },
  sections: [
    { id: "cancellation-window", icon: "Clock", title: "1. Cancellation Window & Cutoff", content: "You stay in control of every subscription — changes are free and take effect instantly until the nightly cutoff.\n\n• Pause, skip, or cancel anytime from your dashboard.\n• Changes made before 9:00 PM apply to the next day's delivery.\n• Changes made after the 9:00 PM cutoff take effect from the following delivery cycle." },
    { id: "subscription-control", icon: "RotateCcw", title: "2. Pause, Skip or Cancel Subscriptions", content: "No calls, no emails, no cancellation fees — your dashboard gives you full control over every active plan.\n\n• Pausing a subscription is free, and you keep your slot and pricing when you resume.\n• Skipping a delivery pauses just that day — the schedule continues as normal afterwards.\n• Cancelling stops all future deliveries and auto-pay deductions immediately." },
    { id: "one-time-orders", icon: "Ban", title: "3. One-Time Orders", content: "One-time (non-subscription) orders follow a shorter cancellation window, since they are packed fresh specifically for you.\n\n• Cancel free of charge any time before the order is packed for dispatch.\n• Once an order is out for delivery, it can no longer be cancelled — you may refuse it at the door or request a refund under Section 4." },
    { id: "damaged-items", icon: "PackageX", title: "4. Damaged, Spoiled or Missing Items", content: "If something reaches you damaged or spoiled — or doesn't reach you at all — we make it right, quickly.\n\n• Report the issue within 24 hours of your delivery slot via Order History → Report Issue, or WhatsApp support.\n• Keep a photo of the item handy — it speeds up verification with the vendor.\n• Verified complaints are refunded in full to your wallet within 24 hours." },
    { id: "refund-request", icon: "MessageCircle", title: "5. How to Request a Refund", content: "Requesting a refund takes less than a minute — pick the order, pick the reason, done.\n\n• Open Order History → select the order → tap Report Issue and choose the reason.\n• Alternatively, message our WhatsApp support team with your order number.\n• You will receive a status update within a few hours and a resolution within 24 hours." },
    { id: "refund-timeline", icon: "Wallet", title: "6. Refund Timelines", content: "Every refund starts immediately after approval — the timeline depends only on where the money is going.\n\n• Wallet refunds are credited within 24 hours of approval — usually instantly.\n• Refunds to the original payment method (card, UPI, netbanking) take 5–7 business days depending on your bank.\n• Subscription auto-pay deductions are reversed to your wallet within 24 hours of a verified complaint." },
    { id: "auto-pay", icon: "CreditCard", title: "7. Wallet & Auto-Pay Protection", content: "You never pay for a delivery that didn't happen — auto-pay is protected end to end.\n\n• If a delivery fails on a day your wallet was charged, the amount is auto-credited back.\n• Wallet balances are non-transferable between users but fully refundable to the original source upon account closure.\n• You receive a notification for every deduction and every refund — no silent charges, ever." },
    { id: "non-refundable", icon: "AlertCircle", title: "8. Non-Refundable Situations", content: "To keep refunds fast and fair for everyone, there are a few situations we can't refund.\n\n• Complaints raised after the 24-hour reporting window.\n• Perishable items reported after same-day consumption, where no photo evidence is possible.\n• Unclaimed reattempted deliveries (see our Shipping Policy for reattempt details)." },
    { id: "policy-updates", icon: "RefreshCcw", title: "9. Policy Updates", content: "We keep this policy current — and we always tell you when it changes.\n\n• This policy may be updated to reflect changes in our services or local regulations.\n• The \"Last Updated\" date at the top of this page always reflects the current version.\n• Material changes are notified via app notification or email." },
  ],
  contact: {
    heading: "Still have a refund question?",
    text: "Our support team usually replies within a few hours and can see your full order history to help fast.",
    btn_text: "Contact Support",
    btn_link: "/contact",
  },
};

const theme = {
  primary: "#F97316",
  primaryHover: "#EA580C",
  dark: "#002868",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

export default function RefundPolicy() {
  const { sections, isLoading } = useTenant();

  const data = (Array.isArray(sections) ? sections : []).find((s) => s.page === "refund_policy")?.data || {};

  // ★ Per-key merge — a partial admin save never wipes the defaults
  const finalData = {
    hero: { ...DEFAULT_REFUND_DATA.hero, ...(data.hero || {}) },
    intro: { ...DEFAULT_REFUND_DATA.intro, ...(data.intro || {}) },
    sections: Array.isArray(data.sections) ? data.sections : DEFAULT_REFUND_DATA.sections,
    contact: { ...DEFAULT_REFUND_DATA.contact, ...(data.contact || {}) },
  };

  const hero = finalData.hero;
  const intro = finalData.intro;
  const policySections = finalData.sections;
  const contact = finalData.contact;

  const [activeSection, setActiveSection] = useState(policySections[0]?.id || "cancellation-window");

  // Reset active section when data changes
  useEffect(() => {
    if (policySections.length > 0 && !policySections.find((s) => s.id === activeSection)) {
      setActiveSection(policySections[0].id);
    }
  }, [policySections]);

  // Smooth scroll to section
  const scrollToSection = (id) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -120;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  // Update active section based on scroll position
  useEffect(() => {
    if (policySections.length === 0) return;
    const handleScroll = () => {
      const sectionEls = policySections.map((s) => document.getElementById(s.id)).filter(Boolean);
      const scrollPosition = window.scrollY + 150;
      for (let i = sectionEls.length - 1; i >= 0; i--) {
        if (sectionEls[i].offsetTop <= scrollPosition) {
          setActiveSection(policySections[i].id);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [policySections]);

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
            <div style={{ color: theme.mid }}>Loading…</div>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />

      <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: "80px" }}>
        {/* ── Hero Header ──────────────────────────────────────── */}
        <section className="refund-hero">
          <div
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
              backgroundSize: "30px 30px",
              pointerEvents: "none",
            }}
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            style={{ position: "relative", zIndex: 1, maxWidth: "800px", margin: "0 auto" }}
          >
            <div className="hero-badge">
              <RotateCcw size={16} /> {hero.badge || "Our Policy"}
            </div>
            <h1 className="hero-title">{hero.title || "Refunds & Cancellations"}</h1>
            <p className="hero-desc">
              {hero.subtitle || ""}
              {hero.last_updated && (
                <>
                  <br />
                  <span style={{ color: theme.primary, fontWeight: "700", display: "inline-block", marginTop: "12px" }}>
                    Last Updated: {hero.last_updated}
                  </span>
                </>
              )}
            </p>
          </motion.div>
        </section>

        {/* ── Main Content Layout ──────────────────────────────── */}
        <div style={{ maxWidth: "1200px", margin: "-40px auto 0", padding: "0 8px", position: "relative", zIndex: 10 }}>
          <div className="layout-grid">
            {/* LEFT: Sticky Navigation (Table of Contents) */}
            {policySections.length > 0 && (
              <div className="sidebar-wrapper">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="toc-card"
                >
                  <h3 style={{ fontSize: "1.1rem", fontWeight: "900", color: theme.dark, marginBottom: "20px", letterSpacing: "-0.01em" }}>
                    Refund Topics
                  </h3>
                  <nav style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                    {policySections.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className={`toc-btn ${activeSection === item.id ? "active" : ""}`}
                      >
                        <span className="toc-text">{item.title}</span>
                        {activeSection === item.id && <ChevronRight size={16} />}
                      </button>
                    ))}
                  </nav>
                </motion.div>
              </div>
            )}

            {/* RIGHT: Policy Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="content-card"
            >
              {/* Intro Section */}
              {(intro.title || intro.content) && (
                <div style={{ marginBottom: "40px", paddingBottom: "24px", borderBottom: `1px solid ${theme.border}` }}>
                  {intro.title && (
                    <h2 style={{ fontSize: "1.6rem", fontWeight: "900", color: theme.dark, marginBottom: "16px", letterSpacing: "-0.02em" }}>
                      {intro.title}
                    </h2>
                  )}
                  {intro.content && (
                    <p style={{ color: theme.mid, fontSize: "1.05rem", lineHeight: "1.7", margin: 0 }}>
                      {intro.content}
                    </p>
                  )}
                </div>
              )}

              {/* Policy Sections */}
              {policySections.length > 0 && (
                <div style={{ display: "flex", flexDirection: "column", gap: "48px" }}>
                  {policySections.map((section) => {
                    const Icon = ICON_MAP[section.icon] || RotateCcw;
                    return (
                      <section key={section.id} id={section.id} style={{ scrollMarginTop: "120px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "20px" }}>
                          <div className="section-icon">
                            <Icon size={24} color={theme.primary} />
                          </div>
                          <h2 style={{ fontSize: "1.4rem", fontWeight: "800", color: theme.dark, margin: 0 }}>
                            {section.title}
                          </h2>
                        </div>
                        <div className="section-body">
                          {(section.content || "").split("\n").map((paragraph, idx) => (
                            <p key={idx}>{paragraph}</p>
                          ))}
                        </div>
                      </section>
                    );
                  })}
                </div>
              )}

              {/* Empty state */}
              {policySections.length === 0 && !intro.title && !intro.content && (
                <div style={{ textAlign: "center", padding: "60px 20px", color: theme.mid }}>
                  <RotateCcw size={48} style={{ marginBottom: 16, opacity: 0.4 }} />
                  <p>This policy page has no content yet.</p>
                </div>
              )}

              {/* Footer Contact Prompt */}
              {(contact.heading || contact.text || contact.btn_text) && (
                <div style={{ marginTop: "60px", padding: "32px", background: "#F8FAFC", borderRadius: "20px", border: `1px solid ${theme.border}`, textAlign: "center" }}>
                  {contact.heading && (
                    <h3 style={{ fontSize: "1.25rem", fontWeight: "800", color: theme.dark, marginBottom: "12px" }}>
                      {contact.heading}
                    </h3>
                  )}
                  {contact.text && (
                    <p style={{ color: theme.mid, fontSize: "1rem", marginBottom: "20px" }}>
                      {contact.text}
                    </p>
                  )}
                  {(contact.btn_text || contact.btn_link) && (
                    <a
                      href={contact.btn_link || "/contact"}
                      style={{
                        display: "inline-block",
                        background: theme.primary,
                        color: "#fff",
                        padding: "12px 28px",
                        borderRadius: "12px",
                        textDecoration: "none",
                        fontWeight: "700",
                        transition: "all 0.2s",
                        boxShadow: "0 4px 14px rgba(249, 115, 22, 0.25)",
                      }}
                    >
                      {contact.btn_text || "Contact Support"}
                    </a>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        </div>

        <style>{`
          .refund-hero {
            background: linear-gradient(135deg, #001440 0%, #001440 100%);
            padding: 80px 24px 64px;
            text-align: center;
            position: relative;
            overflow: hidden;
          }
          .hero-badge {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(18, 89, 255, 0.21); border: 1px solid rgba(255,255,255,0.15);
            color: #fff; padding: 8px 18px; border-radius: 100px;
            font-size: 0.85rem; font-weight: 700; margin-bottom: 24px;
            letter-spacing: 0.05em; text-transform: uppercase;
          }
          .hero-title {
            color: #fff; font-size: clamp(2.4rem, 5vw, 3.8rem);
            font-weight: 900; margin-bottom: 16px; letter-spacing: -0.03em;
            line-height: 1.1;
          }
          .hero-desc {
            color: rgba(255,255,255,0.9); font-size: clamp(1rem, 2vw, 1.15rem);
            max-width: 600px; margin: 0 auto; line-height: 1.5;
          }
          .layout-grid {
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 40px;
            align-items: start;
          }
          .sidebar-wrapper { position: sticky; top: 100px; }
          .toc-card {
            background: #fff; border-radius: 24px; padding: 32px 24px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border};
          }
          .toc-btn {
            width: 100%; display: flex; align-items: center; justify-content: space-between;
            padding: 14px 16px; background: transparent; border: none; border-radius: 12px;
            color: ${theme.mid}; font-size: 0.95rem; font-weight: 600; cursor: pointer;
            text-align: left; transition: all 0.2s; font-family: inherit;
          }
          .toc-btn:hover { background: #F8FAFC; color: ${theme.dark}; }
          .toc-btn.active { background: #FFF7ED; color: ${theme.primary}; font-weight: 800; }
          .content-card {
            background: #fff; border-radius: 24px; padding: clamp(32px, 5vw, 56px);
            box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border};
          }
          .section-icon {
            width: 48px; height: 48px; border-radius: 14px; background: #FFF7ED;
            display: flex; align-items: center; justify-content: center; flex-shrink: 0;
          }
          .section-body p {
            color: ${theme.mid}; font-size: 1.05rem; line-height: 1.75;
            margin-bottom: 12px;
          }
          .section-body p:first-child { color: ${theme.dark}; font-weight: 600; }
          .section-body p:last-child { margin-bottom: 0; }
          @media (max-width: 992px) {
            .layout-grid { grid-template-columns: 1fr; }
            .sidebar-wrapper { position: static; }
            .toc-card { padding: 24px; }
            .toc-card nav {
              flex-direction: row; overflow-x: auto; padding-bottom: 10px;
              scrollbar-width: none;
            }
            .toc-card nav::-webkit-scrollbar { display: none; }
            .toc-btn { white-space: nowrap; width: auto; padding: 12px 20px; }
          }
          @media (max-width: 640px) {
            .refund-hero { padding: 80px 24px 60px; }
            .content-card { padding: 32px 20px; }
            .section-icon { width: 40px; height: 40px; border-radius: 12px; }
            .section-icon svg { width: 20px; height: 20px; }
          }
        `}</style>
      </div>

      <Footer />
    </>
  );
}