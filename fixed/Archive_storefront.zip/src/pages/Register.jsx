import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  User,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";
import toast from "react-hot-toast";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";

function getPasswordStrength(pwd) {
  if (!pwd) return { score: 0, label: "", color: "" };
  let score = 0;
  if (pwd.length >= 8) score++;
  if (pwd.length >= 12) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;

  if (score <= 1) return { score, label: "Weak", color: "#ef4444" };
  if (score <= 2) return { score, label: "Fair", color: "#f59e0b" };
  if (score <= 3) return { score, label: "Good", color: "#3b82f6" };
  return { score, label: "Strong", color: "#22c55e" };
}

const InputField = ({ icon: Icon, label, error, extra, children }) => (
  <div style={{ marginBottom: "14px" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "7px" }}>
      <label style={{ fontSize: "0.85rem", fontWeight: "600", color: "var(--color-dark)" }}>
        {label}
      </label>
      {extra}
    </div>
    <div style={{ position: "relative" }}>
      <Icon size={16} style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", color: error ? "var(--color-accent)" : "var(--color-mid)", zIndex: 1, pointerEvents: "none" }} />
      {children}
    </div>
    <AnimatePresence>
      {error && (
        <motion.div initial={{ opacity: 0, y: -4, height: 0 }} animate={{ opacity: 1, y: 0, height: "auto" }} exit={{ opacity: 0, y: -4, height: 0 }} style={{ display: "flex", alignItems: "center", gap: "5px", marginTop: "5px" }}>
          <AlertCircle size={12} color="var(--color-accent)" />
          <span style={{ color: "var(--color-accent)", fontSize: "0.78rem" }}>{error}</span>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

const inputStyle = (hasError) => ({
  width: "100%",
  padding: "11px 14px 11px 40px",
  borderRadius: "10px",
  border: `1.5px solid ${hasError ? "var(--color-accent)" : "var(--color-border)"}`,
  background: hasError ? "rgba(255,59,48,0.04)" : "#fff",
  fontSize: "0.9rem",
  color: "var(--color-dark)",
  outline: "none",
  transition: "border-color 0.2s",
});

export default function Register() {
  const navigate = useNavigate();
  const { register, clearError } = useCustomerAuth();
  // ★ Dynamic branding from tenant
  const { theme } = useTenant() || {};
  const primaryColor = theme?.primary_color || "#FF7132";
  const accentColor = theme?.secondary_color || "#1E293B";
  const logoUrl = theme?.logo_url;
  const brandName = theme?.brand_name || "Shop Hub";

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    terms: false,
  });
  const [errors, setErrors] = useState({});
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const strength = getPasswordStrength(form.password);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Full name is required.";
    else if (form.name.trim().length < 2) errs.name = "Name must be at least 2 characters.";
    if (!form.email) errs.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Enter a valid email address.";
    if (form.phone && !/^\+?[\d\s\-()]{7,15}$/.test(form.phone)) errs.phone = "Enter a valid phone number.";
    if (!form.password) errs.password = "Password is required.";
    else if (form.password.length < 8) errs.password = "Password must be at least 8 characters.";
    if (!form.confirmPassword) errs.confirmPassword = "Please confirm your password.";
    else if (form.password !== form.confirmPassword) errs.confirmPassword = "Passwords do not match.";
    if (!form.terms) errs.terms = "You must accept the Terms & Conditions.";
    return errs;
  };

  const handleChange = (field) => (e) => {
    const val = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((p) => ({ ...p, [field]: val }));
    if (errors[field]) setErrors((p) => ({ ...p, [field]: "" }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    setErrors({});
    setLoading(true);
    clearError();

    try {
      const ok = await register({
        name: form.name,
        email: form.email,
        password: form.password,
        phone: form.phone,
      });

      if (ok) {
        setSuccess(true);
        setTimeout(() => navigate("/"), 2000);
      } else {
        const { error } = useCustomerAuth.getState();
        const msg = error || "Failed to create account.";
        if (typeof msg === 'object' && msg.errors) {
          setErrors({
            name: msg.errors.name ? msg.errors.name[0] : "",
            email: msg.errors.email ? msg.errors.email[0] : "",
            password: msg.errors.password ? msg.errors.password[0] : "",
            phone: msg.errors.phone ? msg.errors.phone[0] : "",
          });
        } else {
          toast.error(msg);
        }
      }
    } catch (error) {
      toast.error("An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: "calc(100vh - 68px)",
      // ★ Dynamic gradient using tenant colors
      background: `linear-gradient(135deg, ${accentColor} 0%, ${primaryColor} 50%, ${accentColor} 100%)`,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "40px 24px", position: "relative", overflow: "hidden",
    }}>
      {/* Decorative orbs using tenant primary color */}
      <div style={{
        position: "absolute", width: "500px", height: "500px", borderRadius: "50%",
        background: `radial-gradient(circle, ${primaryColor}40 0%, transparent 70%)`,
        top: "-200px", left: "-100px", pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", width: "350px", height: "350px", borderRadius: "50%",
        background: `radial-gradient(circle, ${primaryColor}20 0%, transparent 70%)`,
        bottom: "-100px", right: "5%", pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)",
        backgroundSize: "28px 28px", pointerEvents: "none",
      }} />

      <motion.div
        initial={{ opacity: 0, y: 32, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        style={{
          width: "100%", maxWidth: "480px",
          background: "rgba(255,255,255,0.92)",
          backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)",
          borderRadius: "24px", padding: "clamp(28px, 5vw, 40px)",
          border: "1px solid rgba(255,255,255,0.6)",
          boxShadow: "0 24px 64px rgba(0,0,0,0.2)",
          position: "relative", zIndex: 1,
        }}
      >
        {/* Success overlay */}
        <AnimatePresence>
          {success && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              style={{
                position: "absolute", inset: 0, borderRadius: "24px",
                background: "rgba(255,255,255,0.97)",
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                zIndex: 10, gap: "12px",
              }}
            >
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.1, type: "spring" }}>
                <CheckCircle2 size={56} color="#22c55e" />
              </motion.div>
              <div style={{ fontSize: "1.2rem", fontWeight: "800", color: "var(--color-dark)" }}>Account created!</div>
              <div style={{ color: "var(--color-mid)", fontSize: "0.88rem" }}>Redirecting to your dashboard…</div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ★ Dynamic Header — uses tenant logo + brand name */}
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <Link to="/" style={{ display: "inline-flex", alignItems: "center", gap: "8px", textDecoration: "none", marginBottom: "16px" }}>
            {logoUrl ? (
              <img src={logoUrl} alt={brandName} style={{ height: "40px", objectFit: "contain" }} onError={(e) => { e.target.style.display = 'none' }} />
            ) : (
              <div style={{
                width: "38px", height: "38px", borderRadius: "11px",
                background: `linear-gradient(135deg, ${primaryColor}, ${accentColor})`,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <span style={{ color: "#fff", fontSize: "1.1rem", fontWeight: 800 }}>{brandName?.charAt(0)?.toUpperCase() || "S"}</span>
              </div>
            )}
            <span style={{ fontSize: "1.25rem", fontWeight: "800", color: "var(--color-dark)", letterSpacing: "-0.02em" }}>
              {brandName}
            </span>
          </Link>
          <h1 style={{ fontSize: "1.45rem", fontWeight: "800", color: "var(--color-dark)", letterSpacing: "-0.025em", marginBottom: "5px" }}>
            Create your account
          </h1>
          <p style={{ color: "var(--color-mid)", fontSize: "0.87rem" }}>
            Join {brandName} and start shopping today
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <InputField icon={User} label="Full Name" error={errors.name}>
            <input type="text" value={form.name} onChange={handleChange("name")} placeholder="Your Name" style={inputStyle(!!errors.name)} onFocus={(e) => { if (!errors.name) e.target.style.borderColor = primaryColor; }} onBlur={(e) => { if (!errors.name) e.target.style.borderColor = "var(--color-border)"; }} />
          </InputField>

          <InputField icon={Mail} label="Email Address" error={errors.email}>
            <input type="email" value={form.email} onChange={handleChange("email")} placeholder="you@email.com" style={inputStyle(!!errors.email)} onFocus={(e) => { if (!errors.email) e.target.style.borderColor = primaryColor; }} onBlur={(e) => { if (!errors.email) e.target.style.borderColor = "var(--color-border)"; }} />
          </InputField>

          <InputField icon={Phone} label="Phone Number" error={errors.phone}>
            <input type="tel" value={form.phone} onChange={handleChange("phone")} placeholder="9876543210" style={inputStyle(!!errors.phone)} onFocus={(e) => { if (!errors.phone) e.target.style.borderColor = primaryColor; }} onBlur={(e) => { if (!errors.phone) e.target.style.borderColor = "var(--color-border)"; }} />
          </InputField>

          {/* Password */}
          <div style={{ marginBottom: "14px" }}>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: "var(--color-dark)", marginBottom: "7px" }}>Password</label>
            <div style={{ position: "relative" }}>
              <Lock size={16} style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", color: errors.password ? "var(--color-accent)" : "var(--color-mid)", zIndex: 1, pointerEvents: "none" }} />
              <input type={showPwd ? "text" : "password"} value={form.password} onChange={handleChange("password")} placeholder="Please Enter Your Password" style={{ ...inputStyle(!!errors.password), paddingRight: "44px" }} onFocus={(e) => { if (!errors.password) e.target.style.borderColor = primaryColor; }} onBlur={(e) => { if (!errors.password) e.target.style.borderColor = "var(--color-border)"; }} />
              <button type="button" onClick={() => setShowPwd(!showPwd)} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "var(--color-mid)", padding: "4px", display: "flex" }}>
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {form.password && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: "8px" }}>
                <div style={{ display: "flex", gap: "4px", marginBottom: "4px" }}>
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} style={{ flex: 1, height: "3px", borderRadius: "2px", background: i <= strength.score ? strength.color : "var(--color-border)", transition: "background 0.3s" }} />
                  ))}
                </div>
                <div style={{ fontSize: "0.75rem", color: strength.color, fontWeight: "600" }}>{strength.label} password</div>
              </motion.div>
            )}

            <AnimatePresence>
              {errors.password && (
                <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} style={{ display: "flex", alignItems: "center", gap: "5px", marginTop: "5px" }}>
                  <AlertCircle size={12} color="var(--color-accent)" />
                  <span style={{ color: "var(--color-accent)", fontSize: "0.78rem" }}>{errors.password}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Confirm Password */}
          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", color: "var(--color-dark)", marginBottom: "7px" }}>Confirm Password</label>
            <div style={{ position: "relative" }}>
              <Lock size={16} style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", color: errors.confirmPassword ? "var(--color-accent)" : "var(--color-mid)", zIndex: 1, pointerEvents: "none" }} />
              <input type={showConfirm ? "text" : "password"} value={form.confirmPassword} onChange={handleChange("confirmPassword")} placeholder="Re-enter password" style={{ ...inputStyle(!!errors.confirmPassword), paddingRight: "44px" }} onFocus={(e) => { if (!errors.confirmPassword) e.target.style.borderColor = primaryColor; }} onBlur={(e) => { if (!errors.confirmPassword) e.target.style.borderColor = "var(--color-border)"; }} />
              <button type="button" onClick={() => setShowConfirm(!showConfirm)} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "var(--color-mid)", padding: "4px", display: "flex" }}>
                {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <AnimatePresence>
              {errors.confirmPassword && (
                <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} style={{ display: "flex", alignItems: "center", gap: "5px", marginTop: "5px" }}>
                  <AlertCircle size={12} color="var(--color-accent)" />
                  <span style={{ color: "var(--color-accent)", fontSize: "0.78rem" }}>{errors.confirmPassword}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Terms */}
          <div style={{ marginBottom: "20px" }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
              <input type="checkbox" id="terms" checked={form.terms} onChange={handleChange("terms")} style={{ width: "16px", height: "16px", marginTop: "2px", accentColor: primaryColor, cursor: "pointer", flexShrink: 0 }} />
              <label htmlFor="terms" style={{ fontSize: "0.83rem", color: "var(--color-mid)", cursor: "pointer", lineHeight: "1.5" }}>
                I agree to the <a href="/terms" style={{ color: primaryColor, fontWeight: "600", textDecoration: "none" }}>Terms of Service</a> and <a href="/privacy" style={{ color: primaryColor, fontWeight: "600", textDecoration: "none" }}>Privacy Policy</a>
              </label>
            </div>
            <AnimatePresence>
              {errors.terms && (
                <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} style={{ display: "flex", alignItems: "center", gap: "5px", marginTop: "6px" }}>
                  <AlertCircle size={12} color="var(--color-accent)" />
                  <span style={{ color: "var(--color-accent)", fontSize: "0.78rem" }}>{errors.terms}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* ★ Submit button uses tenant primary color */}
          <button type="submit" disabled={loading} style={{
            width: "100%", padding: "13px", borderRadius: "12px", border: "none",
            background: loading ? `${primaryColor}80` : primaryColor,
            color: "#fff", fontSize: "0.95rem", fontWeight: "700",
            cursor: loading ? "not-allowed" : "pointer", transition: "all 0.2s",
            display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
            boxShadow: `0 4px 16px ${primaryColor}50`,
          }} onMouseEnter={(e) => { if (!loading) { e.currentTarget.style.background = accentColor; e.currentTarget.style.transform = "translateY(-1px)"; } }} onMouseLeave={(e) => { if (!loading) { e.currentTarget.style.background = primaryColor; e.currentTarget.style.transform = "none"; } }}>
            {loading ? (
              <>
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }} style={{ width: "16px", height: "16px", border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%" }} />
                Creating account…
              </>
            ) : "Create Free Account"}
          </button>
        </form>

        <p style={{ textAlign: "center", marginTop: "18px", fontSize: "0.87rem", color: "var(--color-mid)" }}>
          Already have an account?{" "}
          <Link to="/login" style={{ color: primaryColor, fontWeight: "600", textDecoration: "none" }}>Sign in</Link>
        </p>
      </motion.div>
    </div>
  );
}
