import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Star,
  Clock,
  Search,
  Plus,
  Minus,
  Leaf,
  BadgeCheck,
  MapPin,
  Store,
  PhoneCall,
  Navigation,
  ChevronRight,
} from "lucide-react";

import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useCart } from "./CartContext";

/* ─────────────────────────────────────────────
   MOCK DATA: Vendor, Products & Franchisees
───────────────────────────────────────────── */
const vendorData = {
  id: "krishna-dairy",
  name: "Shree Krishna Dairy & Sweets",
  rating: 4.8,
  reviews: "1.2k+",
  deliveryTime: "Next Day Morning (6 AM - 8 AM)",
  type: "Pure Veg",
  bannerBg: "linear-gradient(135deg, #001440 0%, #003782 100%)",
  about:
    "Delivering farm-fresh A2 milk, homemade paneer, and bakery essentials directly to your society.",

  franchisees: [
    {
      id: "f1",
      name: "Kharadi Branch",
      address: "Shop 4, IT Park Road, Kharadi",
      distance: "1.2 km away",
      phone: "+91 9876543210",
      isOpen: true,
    },
    {
      id: "f2",
      name: "Viman Nagar",
      address: "Phoenix Mall Road, Viman Nagar",
      distance: "3.5 km away",
      phone: "+91 9876543211",
      isOpen: true,
    },
  ],

  menuCategories: [
    {
      categoryName: "Daily Milk Subscriptions",
      items: [
        {
          id: "m1",
          name: "A2 Farm Fresh Cow Milk (1L)",
          desc: "Antibiotic-free, freshly milked everyday.",
          price: 85,
          oldPrice: 95,
          isVeg: true,
          type: "Subscription",
          image: "🥛",
        },
        {
          id: "m2",
          name: "Creamy Buffalo Milk (1L)",
          desc: "High fat content, perfect for making thick curd and chai.",
          price: 90,
          oldPrice: null,
          isVeg: true,
          type: "Subscription",
          image: "🐄",
        },
      ],
    },
    {
      categoryName: "Paneer & Curd",
      items: [
        {
          id: "p1",
          name: "Fresh Malai Paneer (250g)",
          desc: "Soft and creamy paneer made fresh daily. No preservatives.",
          price: 110,
          oldPrice: 130,
          isVeg: true,
          type: "One-Time",
          image: "🧀",
        },
        {
          id: "p2",
          name: "Thick Farm Curd / Dahi (500g)",
          desc: "Probiotic rich thick traditional matka curd.",
          price: 65,
          oldPrice: 75,
          isVeg: true,
          type: "One-Time",
          image: "🥣",
        },
      ],
    },
    {
      categoryName: "Morning Bakery & Breakfast",
      items: [
        {
          id: "b1",
          name: "100% Whole Wheat Bread",
          desc: "Freshly baked everyday. Zero maida.",
          price: 55,
          oldPrice: null,
          isVeg: true,
          type: "One-Time",
          image: "🍞",
        },
        {
          id: "b2",
          name: "Amul Butter (100g)",
          desc: "Classic salted butter.",
          price: 58,
          oldPrice: null,
          isVeg: true,
          type: "One-Time",
          image: "🧈",
        },
        {
          id: "b3",
          name: "Farm Eggs (Pack of 6)",
          desc: "Fresh brown eggs directly from poultry.",
          price: 65,
          oldPrice: null,
          isVeg: false,
          type: "One-Time",
          image: "🥚",
        },
      ],
    },
  ],
};

export default function VendorStore() {
  /*  const { vendorId } = useParams(); */
  const navigate = useNavigate();

  // Safe Cart Setup
  const cartContext = useCart() || {};
  const setCartItems =
    cartContext.setCartItems || (() => console.warn("setCartItems missing!"));

  const vendor = vendorData;

  const [activeCategory, setActiveCategory] = useState(
    vendor.menuCategories[0].categoryName,
  );
  const [localCart, setLocalCart] = useState({});
  const [showCart, setShowCart] = useState(false);

  const handleAdd = (id) => {
    setLocalCart((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    setShowCart(true);
  };
  const handleRemove = (id) =>
    setLocalCart((prev) => ({
      ...prev,
      [id]: Math.max((prev[id] || 0) - 1, 0),
    }));

  const totalCartItems = Object.values(localCart).reduce((a, b) => a + b, 0);
  const getSafeId = (name) => name.replace(/[^a-zA-Z0-9]/g, "-");

  // Navigate & Pass Data to Checkout
  const proceedToCheckout = () => {
    try {
      console.log("LOCAL CART:", localCart);

      const globalCartArray = [];

      Object.keys(localCart).forEach((itemId) => {
        const qty = localCart[itemId];

        if (qty > 0) {
          let foundItem = null;

          vendor.menuCategories.forEach((cat) => {
            const item = cat.items.find((i) => i.id === itemId);
            if (item) foundItem = item;
          });

          if (foundItem) {
            globalCartArray.push({
              id: foundItem.id,
              name: foundItem.name,
              type: foundItem.type,
              price: foundItem.price,
              quantity: qty,
              image: foundItem.image,
            });
          }
        }
      });

      console.log("GLOBAL CART:", globalCartArray);
      setCartItems(globalCartArray);
      navigate("/checkout");
    } catch (error) {
      console.error("Navigation error:", error);
      navigate("/checkout");
    }
  };

  return (
    <>
      <Navbar />

      <div
        style={{
          background: "#F8FAFF",
          minHeight: "100vh",
          paddingBottom: totalCartItems > 0 ? "120px" : "60px",
        }}
      >
        {/* ── HEADER BANNER ── */}
        <div
          className="store-header"
          style={{
            background: vendor.bannerBg,
            padding: "48px 24px 80px",
            position: "relative",
            borderBottom: "4px solid #F97316",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              opacity: 0.05,
              backgroundImage: "radial-gradient(#fff 1px, transparent 1px)",
              backgroundSize: "24px 24px",
            }}
          />

          <div
            style={{
              maxWidth: "1200px",
              margin: "0 auto",
              position: "relative",
              zIndex: 1,
            }}
          >
            <button
              onClick={() => navigate(-1)}
              style={{
                color: "#fff",
                border: "none",
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                fontSize: "0.9rem",
                fontWeight: 600,
                marginBottom: "24px",
                background: "rgba(255,255,255,0.15)",
                padding: "6px 14px",
                borderRadius: "8px",
                backdropFilter: "blur(8px)",
              }}
            >
              <ArrowLeft size={16} /> Back
            </button>

            <h1
              className="store-title"
              style={{
                fontSize: "clamp(1.8rem, 4.5vw, 3.2rem)",
                fontWeight: 900,
                color: "#fff",
                margin: "0 0 10px",
                letterSpacing: "-0.02em",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                flexWrap: "wrap",
              }}
            >
              {vendor.name} <BadgeCheck size={32} color="#4ADE80" fill="#fff" />
            </h1>
            <p
              style={{
                color: "rgba(255,255,255,0.85)",
                fontSize: "1rem",
                maxWidth: "600px",
                lineHeight: 1.6,
                marginBottom: "20px",
              }}
            >
              {vendor.about}
            </p>

            <div
              className="store-meta-tags"
              style={{
                display: "flex",
                gap: "12px",
                flexWrap: "wrap",
                color: "#fff",
              }}
            >
              <span
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "0.9rem",
                  fontWeight: 700,
                  background: "rgba(255,255,255,0.15)",
                  padding: "6px 12px",
                  borderRadius: "8px",
                  backdropFilter: "blur(8px)",
                }}
              >
                <Star size={16} fill="#FDE047" color="#FDE047" />{" "}
                {vendor.rating} ({vendor.reviews})
              </span>
              <span
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "0.9rem",
                  fontWeight: 600,
                  background: "rgba(255,255,255,0.15)",
                  padding: "6px 12px",
                  borderRadius: "8px",
                  backdropFilter: "blur(8px)",
                }}
              >
                <Clock size={16} /> {vendor.deliveryTime}
              </span>
            </div>
          </div>
        </div>

        {/* ── MAIN LAYOUT (Fully Responsive Grid) ── */}
        <div
          className="store-layout"
          style={{
            maxWidth: "1200px",
            margin: "-40px auto 0",
            padding: "0 24px",
            position: "relative",
            zIndex: 2,
          }}
        >
          {/* COLUMN A: PRODUCTS LIST */}
          <div className="store-main-col">
            <div
              style={{
                background: "#fff",
                borderRadius: "16px",
                padding: "14px 20px",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                boxShadow: "0 8px 30px rgba(0,55,130,0.06)",
                marginBottom: "24px",
                border: "1px solid #E5E7EB",
              }}
            >
              <Search size={20} color="#003782" />
              <input
                type="text"
                placeholder={`Search in ${vendor.name}...`}
                style={{
                  border: "none",
                  outline: "none",
                  width: "100%",
                  fontSize: "1rem",
                  color: "#1E293B",
                  background: "transparent",
                }}
              />
            </div>

            {/* STICKY CATEGORIES TABS */}
            <div className="hide-scrollbar sticky-tabs-container">
              {vendor.menuCategories.map((cat) => (
                <button
                  key={cat.categoryName}
                  onClick={() => {
                    setActiveCategory(cat.categoryName);
                    const element = document.getElementById(
                      getSafeId(cat.categoryName),
                    );
                    if (element) {
                      const y =
                        element.getBoundingClientRect().top +
                        window.pageYOffset -
                        160;
                      window.scrollTo({ top: y, behavior: "smooth" });
                    }
                  }}
                  style={{
                    padding: "10px 20px",
                    borderRadius: "100px",
                    fontSize: "0.9rem",
                    fontWeight: 700,
                    whiteSpace: "nowrap",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    background:
                      activeCategory === cat.categoryName ? "#003782" : "#fff",
                    color:
                      activeCategory === cat.categoryName ? "#fff" : "#64748B",
                    boxShadow:
                      activeCategory === cat.categoryName
                        ? "0 8px 20px rgba(0,55,130,0.2)"
                        : "0 2px 8px rgba(0,0,0,0.04)",
                    border:
                      activeCategory !== cat.categoryName
                        ? "1px solid #E5E7EB"
                        : "none",
                  }}
                >
                  {cat.categoryName}
                </button>
              ))}
            </div>

            {/* PRODUCTS MAPPING */}
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "40px",
                marginTop: "16px",
              }}
            >
              {vendor.menuCategories.map((category) => (
                <div
                  key={category.categoryName}
                  id={getSafeId(category.categoryName)}
                >
                  <h2
                    style={{
                      fontSize: "1.4rem",
                      fontWeight: 900,
                      color: "#003782",
                      marginBottom: "16px",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    {category.categoryName}{" "}
                    <span
                      style={{
                        fontSize: "1rem",
                        color: "#F97316",
                        fontWeight: 700,
                        background: "#FFF7ED",
                        padding: "2px 10px",
                        borderRadius: "8px",
                      }}
                    >
                      {category.items.length}
                    </span>
                  </h2>

                  <div className="product-list-grid">
                    {category.items.map((item) => (
                      <motion.div
                        whileHover={{
                          translateY: -3,
                          boxShadow: "0 12px 30px rgba(0,0,0,0.08)",
                        }}
                        key={item.id}
                        className="vendor-product-card"
                        style={{
                          background: "#fff",
                          borderRadius: "20px",
                          padding: "20px",
                          border: "1px solid #E5E7EB",
                          display: "flex",
                          gap: "16px",
                          alignItems: "flex-start",
                          minWidth: 0,
                          transition: "all 0.2s",
                        }}
                      >
                        <div
                          className="product-image"
                          style={{
                            width: "90px",
                            height: "90px",
                            background:
                              "linear-gradient(135deg, #F1F5F9, #E2E8F0)",
                            borderRadius: "16px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: "40px",
                            flexShrink: 0,
                          }}
                        >
                          {item.image}
                        </div>

                        <div
                          className="product-details"
                          style={{
                            flex: 1,
                            minWidth: 0,
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "6px",
                              marginBottom: "6px",
                            }}
                          >
                            {item.isVeg ? (
                              <Leaf size={14} color="#16A34A" />
                            ) : (
                              <div
                                style={{
                                  width: "12px",
                                  height: "12px",
                                  background: "#DC2626",
                                  borderRadius: "50%",
                                }}
                              />
                            )}
                            <span
                              style={{
                                fontSize: "0.7rem",
                                fontWeight: 800,
                                color: "#2563EB",
                                background: "#EFF6FF",
                                padding: "3px 8px",
                                borderRadius: "6px",
                                textTransform: "uppercase",
                              }}
                            >
                              {item.type}
                            </span>
                          </div>
                          <h3
                            style={{
                              fontSize: "1.1rem",
                              fontWeight: 800,
                              color: "#1E293B",
                              margin: "0 0 4px",
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {item.name}
                          </h3>
                          <p
                            style={{
                              margin: "0 0 10px",
                              fontSize: "0.85rem",
                              color: "#64748B",
                              lineHeight: 1.4,
                              display: "-webkit-box",
                              WebkitLineClamp: 2,
                              WebkitBoxOrient: "vertical",
                              overflow: "hidden",
                            }}
                          >
                            {item.desc}
                          </p>
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "8px",
                            }}
                          >
                            <span
                              style={{
                                fontSize: "1.15rem",
                                fontWeight: 900,
                                color: "#003782",
                              }}
                            >
                              ₹{item.price}
                            </span>
                            {item.oldPrice && (
                              <span
                                style={{
                                  fontSize: "0.85rem",
                                  color: "#94A3B8",
                                  textDecoration: "line-through",
                                  fontWeight: 500,
                                }}
                              >
                                ₹{item.oldPrice}
                              </span>
                            )}
                          </div>
                        </div>

                        <div
                          className="add-btn-container"
                          style={{
                            width: "100px",
                            minWidth: "80px",
                            flexShrink: 0,
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                          }}
                        >
                          {!localCart[item.id] ? (
                            <button
                              onClick={() => handleAdd(item.id)}
                              style={{
                                width: "100%",
                                background: "#fff",
                                color: "#F97316",
                                border: "2px solid #F97316",
                                padding: "8px 0",
                                borderRadius: "10px",
                                fontSize: "0.95rem",
                                fontWeight: 800,
                                cursor: "pointer",
                                transition: "all 0.2s",
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = "#F97316";
                                e.currentTarget.style.color = "#fff";
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = "#fff";
                                e.currentTarget.style.color = "#F97316";
                              }}
                            >
                              ADD
                            </button>
                          ) : (
                            <div
                              style={{
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                background: "#F97316",
                                color: "#fff",
                                width: "100%",
                                borderRadius: "10px",
                                overflow: "hidden",
                                boxShadow: "0 4px 12px rgba(249,115,22,0.3)",
                              }}
                            >
                              <button
                                onClick={() => handleRemove(item.id)}
                                style={{
                                  background: "none",
                                  border: "none",
                                  color: "#fff",
                                  padding: "8px",
                                  cursor: "pointer",
                                }}
                              >
                                <Minus size={16} />
                              </button>
                              <span
                                style={{ fontWeight: 800, fontSize: "0.95rem" }}
                              >
                                {localCart[item.id]}
                              </span>
                              <button
                                onClick={() => handleAdd(item.id)}
                                style={{
                                  background: "none",
                                  border: "none",
                                  color: "#fff",
                                  padding: "8px",
                                  cursor: "pointer",
                                }}
                              >
                                <Plus size={16} />
                              </button>
                            </div>
                          )}
                          {item.type === "Subscription" && (
                            <span
                              style={{
                                fontSize: "0.7rem",
                                color: "#64748B",
                                marginTop: "6px",
                                fontWeight: 600,
                              }}
                            >
                              Daily
                            </span>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* COLUMN B: FRANCHISEE SIDEBAR */}
          <div className="store-sidebar-col">
            <div
              className="sticky-sidebar"
              style={{
                background: "#fff",
                borderRadius: "24px",
                padding: "24px",
                border: "1px solid #E5E7EB",
                boxShadow: "0 10px 40px rgba(0,55,130,0.05)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  marginBottom: "20px",
                  paddingBottom: "16px",
                  borderBottom: "1px dashed #E2E8F0",
                }}
              >
                <div
                  style={{
                    background: "#EFF6FF",
                    padding: "10px",
                    borderRadius: "12px",
                  }}
                >
                  <Store size={24} color="#2563EB" />
                </div>
                <div>
                  <h3
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: 900,
                      color: "#003782",
                      margin: 0,
                    }}
                  >
                    Our Branches
                  </h3>
                  <p
                    style={{
                      margin: 0,
                      fontSize: "0.85rem",
                      color: "#64748B",
                      fontWeight: 600,
                    }}
                  >
                    Serving across Pune
                  </p>
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "12px",
                }}
              >
                {vendor.franchisees.map((branch) => (
                  <div
                    key={branch.id}
                    style={{
                      background: "#F8FAFF",
                      padding: "16px",
                      borderRadius: "16px",
                      border: "1px solid #DBEAFE",
                      transition: "all 0.2s",
                      cursor: "default",
                    }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.borderColor = "#93C5FD")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.borderColor = "#DBEAFE")
                    }
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        marginBottom: "8px",
                      }}
                    >
                      <h4
                        style={{
                          fontSize: "0.95rem",
                          fontWeight: 800,
                          color: "#1E293B",
                          margin: 0,
                        }}
                      >
                        {branch.name}
                      </h4>
                      {branch.isOpen ? (
                        <span
                          style={{
                            background: "#DCFCE7",
                            color: "#166534",
                            fontSize: "0.65rem",
                            fontWeight: 800,
                            padding: "2px 6px",
                            borderRadius: "6px",
                          }}
                        >
                          OPEN
                        </span>
                      ) : (
                        <span
                          style={{
                            background: "#FEE2E2",
                            color: "#991B1B",
                            fontSize: "0.65rem",
                            fontWeight: 800,
                            padding: "2px 6px",
                            borderRadius: "6px",
                          }}
                        >
                          CLOSED
                        </span>
                      )}
                    </div>
                    <p
                      style={{
                        margin: "0 0 10px",
                        fontSize: "0.85rem",
                        color: "#64748B",
                        lineHeight: 1.4,
                        display: "flex",
                        alignItems: "flex-start",
                        gap: "6px",
                      }}
                    >
                      <MapPin
                        size={14}
                        color="#F97316"
                        style={{ flexShrink: 0, marginTop: "3px" }}
                      />
                      {branch.address}
                    </p>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "0.75rem",
                          fontWeight: 700,
                          color: "#2563EB",
                          background: "#DBEAFE",
                          padding: "4px 10px",
                          borderRadius: "100px",
                        }}
                      >
                        {branch.distance}
                      </span>
                      <div style={{ display: "flex", gap: "8px" }}>
                        <a
                          href={`tel:${branch.phone}`}
                          style={{
                            background: "#fff",
                            border: "1px solid #E2E8F0",
                            padding: "6px",
                            borderRadius: "8px",
                            color: "#10B981",
                          }}
                        >
                          <PhoneCall size={14} />
                        </a>
                        <button
                          style={{
                            background: "#fff",
                            border: "1px solid #E2E8F0",
                            padding: "6px",
                            borderRadius: "8px",
                            color: "#3B82F6",
                            cursor: "pointer",
                          }}
                        >
                          <Navigation size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── 100% FIXED BOTTOM CART BAR (NEVER HIDES) ── */}
      <AnimatePresence>
        {totalCartItems > 0 && (
          <motion.div
            className="cart-bottom-bar"
            style={{
              position: "fixed",
              bottom: "20px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "calc(100% - 32px)",
              maxWidth: "450px",
              background: "#003782",
              borderRadius: "16px",
              padding: "16px 20px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              boxShadow: "0 10px 40px rgba(0,20,80,0.4)",
              zIndex: 99999,
              border: "2px solid #2563EB",
              boxSizing: "border-box",
            }}
          >
            <div
              style={{
                color: "#fff",
                flex: 1,
                minWidth: 0,
                overflow: "hidden",
              }}
            >
              <p
                style={{
                  margin: 0,
                  fontSize: "0.8rem",
                  color: "#93C5FD",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                }}
              >
                {totalCartItems} Items Added
              </p>
              <p
                style={{
                  margin: 0,
                  fontSize: "1.15rem",
                  fontWeight: 900,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                Proceed to Checkout
              </p>
            </div>

            <button
              onClick={proceedToCheckout}
              style={{
                flexShrink: 0,
                border: "none",
                cursor: "pointer",
                background: "#F97316",
                color: "#fff",
                padding: "12px 16px",
                borderRadius: "12px",
                fontWeight: 800,
                fontSize: "0.95rem",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                boxShadow: "0 4px 14px rgba(249,115,22,0.4)",
                whiteSpace: "nowrap",
              }}
            >
              Continue <ChevronRight size={18} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {showCart && (
        <>
          {/* Overlay */}
          <div
            onClick={() => setShowCart(false)}
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.45)",
              zIndex: 99998,
            }}
          />

          {/* Drawer */}
          <div
            style={{
              position: "fixed",
              top: 0,
              right: 0,
              width: "420px",
              maxWidth: "100%",
              height: "100vh",
              background: "#F8FAFC",
              zIndex: 99999,
              boxShadow: "-10px 0 40px rgba(0,0,0,0.18)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* Header */}
            <div
              style={{
                background: "#003782",
                color: "#fff",
                padding: "24px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div>
                <h2 style={{ margin: 0, fontSize: "1.4rem" }}>Your Cart</h2>
                <p style={{ margin: "4px 0 0", color: "#CBD5E1" }}>
                  {totalCartItems} Items Added
                </p>
              </div>

              <button
                onClick={() => setShowCart(false)}
                style={{
                  border: "none",
                  background: "rgba(255,255,255,0.2)",
                  color: "#fff",
                  width: "40px",
                  height: "40px",
                  borderRadius: "50%",
                  cursor: "pointer",
                }}
              >
                ✕
              </button>
            </div>

            {/* Items */}
            <div
              style={{
                flex: 1,
                overflowY: "auto",
                padding: "20px",
              }}
            >
              {Object.keys(localCart).map((itemId) => {
                const qty = localCart[itemId];
                if (qty <= 0) return null;

                let foundItem = null;

                vendor.menuCategories.forEach((cat) => {
                  const item = cat.items.find((i) => i.id === itemId);
                  if (item) foundItem = item;
                });

                if (!foundItem) return null;

                return (
                  <div
                    key={itemId}
                    style={{
                      background: "#fff",
                      borderRadius: "16px",
                      padding: "16px",
                      marginBottom: "14px",
                      boxShadow: "0 4px 16px rgba(0,0,0,0.05)",
                    }}
                  >
                    <h4 style={{ margin: "0 0 8px" }}>{foundItem.name}</h4>

                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <span>Qty: {qty}</span>
                      <span style={{ fontWeight: 700 }}>
                        ₹{foundItem.price * qty}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Footer */}
            <div
              style={{
                background: "#fff",
                padding: "20px",
                borderTop: "1px solid #E2E8F0",
              }}
            >
              <button
                onClick={proceedToCheckout}
                style={{
                  width: "100%",
                  background: "#F97316",
                  color: "#fff",
                  border: "none",
                  padding: "16px",
                  borderRadius: "14px",
                  fontWeight: 800,
                  fontSize: "1rem",
                  cursor: "pointer",
                }}
              >
                Continue to Checkout
              </button>
            </div>
          </div>
        </>
      )}

      <Footer />

      {/* ── RESPONSIVE CSS ── */}
      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
  display: none;
}

.hide-scrollbar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

/* =========================
   LAYOUT
========================= */

.store-layout {
  display: flex;
  gap: 32px;
  align-items: flex-start;
}

.store-main-col {
  flex: 1;
  min-width: 0;
}

.store-sidebar-col {
  width: 340px;
  flex-shrink: 0;
}

.sticky-sidebar {
  position: sticky;
  top: 130px;
  z-index: 20;
}

/* =========================
   CATEGORY TABS
========================= */

.sticky-tabs-container {
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding-bottom: 14px;
  position: sticky;
  top: 70px;
  z-index: 40;
  background: #f8faff;
  padding-top: 12px;
}

/* =========================
   PRODUCT GRID
========================= */

.product-list-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 18px;
}

.vendor-product-card {
  min-width: 0;
}

.product-details {
  min-width: 0;
  flex: 1;
}

.product-details h3 {
  word-break: break-word;
}

/* =========================
   LARGE DESKTOP
========================= */

@media (min-width: 1400px) {
  .store-layout {
    max-width: 1400px;
  }

  .product-list-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}

/* =========================
   LAPTOP
========================= */

@media (max-width: 1200px) {
  .store-sidebar-col {
    width: 300px;
  }

  .product-list-grid {
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  }
}

/* =========================
   TABLET
========================= */

@media (max-width: 992px) {

  .store-layout {
    flex-direction: column;
    gap: 24px;
  }

  .store-main-col,
  .store-sidebar-col {
    width: 100%;
  }

  .sticky-sidebar {
    position: relative;
    top: 0;
  }

  .product-list-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .sticky-tabs-container {
    top: 65px;
  }
}

/* =========================
   SMALL TABLET
========================= */

@media (max-width: 768px) {

  .store-header {
    padding: 32px 18px 60px !important;
  }

  .store-layout {
    padding: 0 18px !important;
    margin-top: -30px !important;
  }

  .product-list-grid {
    grid-template-columns: 1fr;
  }

  .sticky-tabs-container {
    gap: 8px;
  }

  .sticky-tabs-container button {
    padding: 8px 16px !important;
    font-size: 0.85rem !important;
  }
}

/* =========================
   MOBILE
========================= */

@media (max-width: 640px) {

  .store-header {
    padding: 24px 14px 55px !important;
  }

  .store-title {
    font-size: 1.5rem !important;
    line-height: 1.3;
  }

  .store-layout {
    padding: 0 14px !important;
    margin-top: -25px !important;
  }

  .vendor-product-card {
    padding: 14px !important;
    gap: 12px !important;
    align-items: flex-start !important;
  }

  .product-image {
    width: 70px !important;
    height: 70px !important;
    font-size: 32px !important;
  }

  .product-details h3 {
    font-size: 0.95rem !important;
    white-space: normal !important;
  }

  .product-details p {
    font-size: 0.8rem !important;
  }

  .add-btn-container {
    width: 82px !important;
  }

  .store-meta-tags {
    flex-direction: column;
    align-items: flex-start;
  }

  .sticky-tabs-container {
    top: 60px;
    padding-top: 10px;
  }

  .sticky-sidebar {
    padding: 18px !important;
  }
}

/* =========================
   EXTRA SMALL MOBILE
========================= */

@media (max-width: 480px) {

  .store-title {
    font-size: 1.3rem !important;
  }

  .product-image {
    width: 60px !important;
    height: 60px !important;
    font-size: 28px !important;
  }

  .product-details h3 {
    font-size: 0.9rem !important;
  }

  .add-btn-container {
    width: 72px !important;
  }

  .add-btn-container button {
    font-size: 0.8rem !important;
  }

  .sticky-tabs-container button {
    padding: 7px 14px !important;
    font-size: 0.8rem !important;
  }
}

/* =========================
   CART BAR RESPONSIVE
========================= */

.cart-bottom-bar {
  position: fixed;
  left: 50%;
  transform: translateX(-50%);
  z-index: 99999;
  box-sizing: border-box;
}

@media (max-width: 768px) {

  .cart-bottom-bar {
    width: calc(100% - 24px) !important;
    bottom: 12px !important;
    padding: 12px 14px !important;
  }

  .cart-bottom-bar p:last-child {
    font-size: 1rem !important;
  }

  .cart-bottom-bar button {
    padding: 10px 14px !important;
    font-size: 0.85rem !important;
  }
}

@media (max-width: 480px) {

  .cart-bottom-bar {
    gap: 10px !important;
  }

  .cart-bottom-bar button {
    padding: 10px 12px !important;
    font-size: 0.8rem !important;
  }
}

/* =========================
   BRANCH CARDS
========================= */

@media (max-width: 640px) {

  .sticky-sidebar > div:last-child {
    gap: 10px;
  }

  .sticky-sidebar h3 {
    font-size: 1.05rem !important;
  }
}

/* =========================
   LANDSCAPE MOBILE
========================= */

@media (max-height: 500px) and (orientation: landscape) {

  .sticky-tabs-container {
    top: 0;
  }

  .sticky-sidebar {
    position: relative;
  }

  .cart-bottom-bar {
    bottom: 8px !important;
  }
}
      `}</style>
    </>
  );
}
