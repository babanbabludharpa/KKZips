import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Plus, Clock, Calendar, MapPin, Package } from "lucide-react";
import customerApi, { unwrap } from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";
import SectionRenderer from "../components/SectionRenderer";

const STATUS_COLORS = {
  active:    { bg: "#dcfce7", fg: "#15803d", label: "Active" },
  paused:    { bg: "#fef9c3", fg: "#a16207", label: "Paused" },
  cancelled: { bg: "#fee2e2", fg: "#b91c1c", label: "Cancelled" },
  expired:   { bg: "#f3f4f6", fg: "#6b7280", label: "Expired" },
};

const SLOT_LABELS = { morning: "Morning", lunch: "Lunch", dinner: "Dinner", evening: "Evening" };
const SCHEDULE_LABELS = {
  daily: "Daily", alternate: "Alternate Days", weekly: "Weekly",
  custom_days: "Custom Days", custom_dates: "Custom Dates",
};

const theme = {
  primary: "#FF7132", primaryHover: "#EA580C", dark: "#1E293B",
  mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0",
};

const fmtDate = (d) => d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const fmtMoney = (n) => `₹${Number(n ?? 0).toFixed(2)}`;

// Build a human-readable schedule summary from item data
function scheduleSummary(item) {
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  switch (item.schedule_type) {
    case "daily": return "Every day";
    case "alternate": return "Every alternate day";
    case "weekly": return item.schedule_days?.length ? `${days[item.schedule_days[0]]}` : "Weekly";
    case "custom_days":
      return item.schedule_days?.map(d => days[d]).join(", ") || "Custom days";
    case "custom_dates": return `${item.schedule_dates?.length || 0} specific dates`;
    default: return item.schedule_type || "—";
  }
}

const defaultSubscriptionsData = {
  hero: { badge: "My Subscriptions", title: "Manage Your Subscriptions", subtitle: "Pause, resume, or cancel your recurring deliveries here." },
  emptyState: { icon: "🔁", title: "No subscriptions yet", message: "Subscribe to your favourite products and have them delivered on a schedule that works for you.", buttonText: "Create your first subscription" },
  newButton: { text: "New Subscription" },
  section_order: ['hero', 'subscription_list'],
  section_visibility: {},
};

export default function SubscriptionPlan() {
  const navigate = useNavigate();
  const { isAuthenticated, customer } = useCustomerAuth();
  const { sections } = useTenant();

  const [subs, setSubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);

  const safeSections = Array.isArray(sections) ? sections : [];
  const subsData = safeSections.find((s) => s.page === "subscriptions")?.data || defaultSubscriptionsData;
  const hero = subsData.hero || defaultSubscriptionsData.hero;
  const emptyState = subsData.emptyState || defaultSubscriptionsData.emptyState;
  const newButton = subsData.newButton || defaultSubscriptionsData.newButton;
  const sectionOrder = subsData.section_order || ['hero', 'subscription_list'];
  const sectionVisibility = subsData.section_visibility || {};

  useEffect(() => {
    if (!isAuthenticated) navigate("/", { replace: true });
  }, [isAuthenticated, navigate]);

  const showToast = (msg, kind = "success") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchSubs = async () => {
    if (!isAuthenticated) return;
    setLoading(true); setError(null);
    try {
      const res = await customerApi.get("/mobile/subscriptions");
      const data = res.data?.data || [];
      setSubs(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || "Failed to load subscriptions.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) fetchSubs();
  }, [isAuthenticated]);

  // ── Subscription-level actions (pause/resume/cancel entire subscription) ──
  const handlePauseSubscription = async (subId) => {
    const reason = prompt("Reason for pausing (optional):", "") || null;
    try {
      await customerApi.post(`/mobile/subscriptions/${subId}/pause`, { reason });
      showToast("Subscription paused.");
      fetchSubs();
    } catch (e) {
      showToast(e?.response?.data?.message || "Failed to pause.", "error");
    }
  };

  const handleResumeSubscription = async (subId) => {
    try {
      await customerApi.post(`/mobile/subscriptions/${subId}/resume`, {});
      showToast("Subscription resumed.");
      fetchSubs();
    } catch (e) {
      showToast(e?.response?.data?.message || "Failed to resume.", "error");
    }
  };

  const handleCancelSubscription = async (subId) => {
    if (!window.confirm("Cancel this subscription permanently? This cannot be undone.")) return;
    const reason = prompt("Reason for cancelling (optional):", "") || null;
    try {
      await customerApi.post(`/mobile/subscriptions/${subId}/cancel`, { reason });
      showToast("Subscription cancelled.");
      fetchSubs();
    } catch (e) {
      showToast(e?.response?.data?.message || "Failed to cancel.", "error");
    }
  };

  // ── Render subscription card ──
  const renderSub = (sub) => {
    const status = STATUS_COLORS[sub.status] || STATUS_COLORS.expired;
    const totalPerDay = (sub.items || []).reduce((acc, it) => {
      const price = Number(it.variant?.final_price || 0);
      return acc + price * Number(it.default_qty || 0);
    }, 0);

    return (
      <motion.article
        key={sub.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => navigate(`/subscription/${sub.id}`)}
        style={{
          background: "#fff", border: `1px solid ${theme.border}`, borderRadius: 14,
          padding: 20, boxShadow: "0 1px 3px rgba(0,0,0,0.04)", cursor: "pointer",
          display: "flex", flexDirection: "column", gap: 12,
          transition: "transform 0.15s, box-shadow 0.15s",
        }}
        onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.08)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.04)"; }}
      >
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: "1.1rem", fontWeight: 700, color: theme.dark }}>
              Subscription #{sub.id}
            </h3>
            <div style={{ fontSize: "0.8rem", color: theme.mid, marginTop: 4, display: "flex", gap: 8, flexWrap: "wrap" }}>
              <span>📅 {fmtDate(sub.start_date)}</span>
              {sub.end_date && <span>→ {fmtDate(sub.end_date)}</span>}
              <span>•</span>
              <span>{(sub.items || []).length} item{(sub.items || []).length !== 1 ? "s" : ""}</span>
              {sub.branch_name && (<><span>•</span><span>{sub.branch_name}</span></>)}
            </div>
          </div>
          <span style={{ background: status.bg, color: status.fg, padding: "4px 12px", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em" }}>
            {status.label}
          </span>
        </div>

        {/* Items preview */}
        {Array.isArray(sub.items) && sub.items.length > 0 && (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {sub.items.slice(0, 3).map((it) => (
              <div key={it.id} style={{ display: "flex", alignItems: "center", gap: 6, background: theme.bg, borderRadius: 8, padding: "6px 10px", fontSize: "0.82rem" }}>
                {it.variant?.image_url && <img src={it.variant.image_url} alt="" style={{ width: 24, height: 24, borderRadius: 4, objectFit: "cover" }} onError={(e) => e.target.style.display = "none"} />}
                <span style={{ fontWeight: 600 }}>{it.product_name || "Product"}</span>
                <span style={{ color: theme.mid }}>×{it.default_qty}</span>
                <span style={{ color: theme.primary, fontSize: "0.72rem" }}>{SCHEDULE_LABELS[it.schedule_type] || it.schedule_type}</span>
              </div>
            ))}
            {sub.items.length > 3 && <div style={{ display: "flex", alignItems: "center", color: theme.mid, fontSize: "0.82rem", padding: "6px 4px" }}>+{sub.items.length - 3} more</div>}
          </div>
        )}

        {/* Delivery address */}
        {sub.delivery_address && (
          <div style={{ fontSize: "0.82rem", color: theme.mid, display: "flex", alignItems: "center", gap: 4 }}>
            <MapPin size={13} /> {sub.delivery_address.label}: {sub.delivery_address.address_line1}, {sub.delivery_address.city}
          </div>
        )}

        {/* Footer with est + actions */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 8, borderTop: `1px solid ${theme.border}` }}>
          <div style={{ fontSize: "0.85rem", color: theme.mid }}>
            Est. <span style={{ fontWeight: 800, color: theme.primary, fontSize: "1rem" }}>{fmtMoney(totalPerDay)}</span>/day
          </div>
          <div style={{ display: "flex", gap: 6 }} onClick={(e) => e.stopPropagation()}>
            {sub.status === "active" && (
              <button onClick={() => handlePauseSubscription(sub.id)} style={btnStyle("warning")}>⏸ Pause All</button>
            )}
            {sub.status === "paused" && (
              <button onClick={() => handleResumeSubscription(sub.id)} style={btnStyle("primary")}>▶ Resume</button>
            )}
            {["active", "paused"].includes(sub.status) && (
              <button onClick={() => handleCancelSubscription(sub.id)} style={btnStyle("danger")}>✕ Cancel</button>
            )}
          </div>
        </div>
      </motion.article>
    );
  };

  // ── Built-in section renderers ──
  const renderHero = () => (
    <div key="hero" style={{ background: `linear-gradient(135deg, var(--color-primary, ${theme.primary}), var(--color-secondary, ${theme.primaryHover}))`, padding: "40px 24px 80px", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)", backgroundSize: "30px 30px", pointerEvents: "none" }} />
      <div style={{ position: "relative", zIndex: 1, maxWidth: 1100, margin: "50px auto", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
        <motion.span initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} style={{ display: "inline-block", background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "8px 20px", borderRadius: 100, fontSize: ".85rem", fontWeight: 700, marginBottom: 16, backdropFilter: "blur(4px)" }}>{hero.badge}</motion.span>
        <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} style={{ color: "#fff", fontSize: "clamp(2rem, 4vw, 2.5rem)", fontWeight: 900, margin: "0 0 8px", textShadow: "0 4px 12px rgba(0,0,0,0.2)", letterSpacing: "-0.02em" }}>{hero.title}</motion.h1>
        <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} style={{ color: "rgba(255,255,255,0.95)", fontSize: "1.05rem", margin: 0 }}>{hero.subtitle}</motion.p>
      </div>
    </div>
  );

  const renderSubscriptionList = () => (
    <div key="subscription_list" style={{ maxWidth: 1100, margin: "-48px auto 0", padding: "0 24px", position: "relative", zIndex: 10 }}>
      <motion.button
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        onClick={() => navigate("/subscription/new")}
        style={{ width: "100%", background: "linear-gradient(135deg, #ffffff 0%, #fff7f2 100%)", color: "#000", border: "1px solid rgba(255,113,50,0.25)", borderRadius: 18, padding: "20px", fontSize: "1rem", fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, marginBottom: 24, transition: "all 0.25s ease" }}
      >
        <Plus size={18} /> {newButton.text}
      </motion.button>

      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: theme.mid }}>
          <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
          Loading subscriptions…
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      ) : error ? (
        <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12, padding: "1.5rem", color: "#b91c1c", textAlign: "center" }}>
          {error}
          <div style={{ marginTop: "0.75rem" }}>
            <button onClick={fetchSubs} style={btnStyle("primary")}>Retry</button>
          </div>
        </div>
      ) : subs.length === 0 ? (
        <div style={{ background: "#fff", border: `1px dashed ${theme.border}`, borderRadius: 14, padding: "3rem 1rem", textAlign: "center" }}>
          <div style={{ fontSize: "2.5rem", marginBottom: 16 }}>{emptyState.icon}</div>
          <h3 style={{ margin: "0 0 8px", color: theme.dark }}>{emptyState.title}</h3>
          <p style={{ color: theme.mid, margin: "0 auto 24px", maxWidth: 420 }}>{emptyState.message}</p>
          <button onClick={() => navigate("/subscription/new")} style={{ background: theme.primary, color: "#fff", border: "none", borderRadius: 999, padding: "0.65rem 1.4rem", fontWeight: 600, cursor: "pointer" }}>{emptyState.buttonText}</button>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))", gap: 16 }}>
          {subs.map(renderSub)}
        </div>
      )}
    </div>
  );

  const builtinRenderers = { hero: renderHero, subscription_list: renderSubscriptionList };
  const sectionsToRender = sectionOrder.filter(k => sectionVisibility[k] !== false).map(key => {
    if (key.startsWith("custom-")) { const cd = subsData[key] || {}; return { id: key, type: cd.type || "text_block", data: cd, visible: true, isCustom: true }; }
    return { id: key, type: key, data: subsData[key] || {}, visible: true, isCustom: false };
  });

  if (!isAuthenticated) return <div style={{ padding: "3rem", textAlign: "center", color: theme.mid }}>Please log in to view your subscriptions.</div>;

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: 40 }}>
      {sectionsToRender.map(section => {
        if (!section.isCustom && builtinRenderers[section.type]) return builtinRenderers[section.type]();
        if (section.isCustom) return <SectionRenderer key={section.id} section={section} />;
        return null;
      })}
      {toast && (
        <div style={{ position: "fixed", bottom: 24, right: 24, zIndex: 100, background: toast.kind === "error" ? "#dc2626" : "#16a34a", color: "#fff", padding: "0.75rem 1.25rem", borderRadius: 10, boxShadow: "0 10px 30px rgba(0,0,0,0.2)", fontWeight: 500, fontSize: "0.9rem", maxWidth: 320 }}>{toast.msg}</div>
      )}
    </div>
  );
}

const btnStyle = (kind) => {
  const map = {
    primary: { background: theme.primary, color: "#fff", border: "none" },
    warning: { background: "#fff", color: "#a16207", border: "1px solid #facc15" },
    danger: { background: "#fff", color: "#b91c1c", border: "1px solid #fecaca" },
  };
  const s = map[kind] || map.primary;
  return { ...s, padding: "0.4rem 0.85rem", borderRadius: 8, fontSize: "0.8rem", fontWeight: 600, cursor: "pointer" };
};
