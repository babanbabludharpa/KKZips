import { createContext, useContext, useState, useEffect, useRef } from "react";

// ─────────────────────────────────────────────────────────────────────────
// CartContext.jsx — with delivery zone + stock validation + localStorage persistence
//
// Cart now persists to localStorage so refreshes don't wipe items.
// Storage key is tenant-aware so carts don't bleed across tenant sites.
// ─────────────────────────────────────────────────────────────────────────

import { resolveTenantId } from "../api/customerApi";

const CART_KEY_PREFIX = "cart-items";

// Build a tenant-scoped storage key so carts don't leak between tenants.
// Falls back to "default" if no tenant resolved (e.g. localhost dev).
const getStorageKey = () => {
  const tid = resolveTenantId() || "default";
  return `${CART_KEY_PREFIX}-${tid}`;
};

// Safely read the cart from localStorage. Returns [] on any error.
const readCartFromStorage = () => {
  try {
    const key = getStorageKey();
    const saved = localStorage.getItem(key);
    if (!saved) return [];
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.warn("[CartContext] Failed to read cart from localStorage:", e);
    return [];
  }
};

// Safely write the cart to localStorage.
const writeCartToStorage = (items) => {
  try {
    const key = getStorageKey();
    localStorage.setItem(key, JSON.stringify(items));
  } catch (e) {
    console.warn("[CartContext] Failed to persist cart to localStorage:", e);
  }
};

const CartContext = createContext();

export function CartProvider({ children }) {
  // ★ Lazy initial state — read from localStorage synchronously on first render.
  // This is what makes the cart survive refreshes.
  const [cartItems, setCartItems] = useState(() => readCartFromStorage());
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isDeliverable, setIsDeliverable] = useState(true);

  // ★ Persist cart to localStorage on every change.
  useEffect(() => {
    writeCartToStorage(cartItems);
  }, [cartItems]);
    // ★ NEW — always-fresh mirror of the cart for synchronous reads
  const cartRef = useRef(cartItems);
  useEffect(() => { cartRef.current = cartItems; }, [cartItems]);

  // ★ On tenant change (subdomain switch via popstate), reload the cart
  // from the new tenant's storage bucket — prevents cart bleed across tenants.
  useEffect(() => {
    const reloadCartForTenant = () => {
      setCartItems(readCartFromStorage());
    };
    reloadCartForTenant();
    window.addEventListener("popstate", reloadCartForTenant);
    return () => window.removeEventListener("popstate", reloadCartForTenant);
  }, []);

  // Allow external components to set deliverability
  // (Products.jsx will call this after checking the delivery zone)
  useEffect(() => {
    window.__setCartDeliverable = setIsDeliverable;
    return () => { delete window.__setCartDeliverable; };
  }, []);

  const validateStock = (product, requestedQty) => {
    if (!isDeliverable) {
      return { ok: false, error: "Delivery is not available at your location" };
    }
    if (product.is_out_of_stock === true) {
      return { ok: false, error: "This item is out of stock" };
    }
    if (product.available_stock === null || product.available_stock === undefined) {
      return { ok: true };
    }
    if (product.available_stock <= 0) {
      return { ok: false, error: "This item is out of stock" };
    }
    if (requestedQty > product.available_stock) {
      return { ok: false, error: `Only ${product.available_stock} left in stock` };
    }
    return { ok: true };
  };

  const addToCart = (product) => {
    const cartKey = product.variant_id || product.id;
    const existingItem = cartRef.current.find((item) => item.variant_id === cartKey);
    const newQty = existingItem ? existingItem.quantity + 1 : 1;

    // ★ validate BEFORE updating — the return value is now always truthful
    const validation = validateStock(product, newQty);
    if (!validation.ok) {
      return { success: false, error: validation.error };
    }

    setCartItems((prev) => {
      const ex = prev.find((item) => item.variant_id === cartKey);
      if (ex) {
        return prev.map((item) =>
          item.variant_id === cartKey ? { ...item, quantity: ex.quantity + 1 } : item,
        );
      }
      return [...prev, {
        ...product,
        variant_id: cartKey,
        price: Number(product.price || 0),
        quantity: 1,
        is_out_of_stock: product.is_out_of_stock || false,
        available_stock: product.available_stock ?? null,
      }];
    });
    return { success: true, error: null };
  };

  const updateQuantity = (id, amount) => {
    const item = cartRef.current.find((i) => i.id === id || i.variant_id === id);
    if (!item) return { success: false, error: "Item not found in cart" };

    const newQty = item.quantity + amount;
    if (newQty < 1) return { success: false, error: "Minimum quantity is 1" };
    if (!isDeliverable) return { success: false, error: "Delivery not available at your location" };
    if (item.available_stock !== null && item.available_stock !== undefined && newQty > item.available_stock) {
      return { success: false, error: `Only ${item.available_stock} left in stock` };
    }
    if (item.is_out_of_stock === true) return { success: false, error: "This item is out of stock" };

    setCartItems((prev) =>
      prev.map((i) => (i.id === id || i.variant_id === id ? { ...i, quantity: newQty } : i)),
    );
    return { success: true, error: null };
  };

  const removeFromCart = (id) => {
    setCartItems((prev) =>
      prev.filter((item) => item.id !== id && item.variant_id !== id),
    );
  };

  // ★ NEW: Clear cart entirely (logout flow or after order placement).
  const clearCart = () => {
    setCartItems([]);
    writeCartToStorage([]);
  };

  const hasOutOfStockItems = () => {
    if (!isDeliverable) return true;
    return cartItems.some(
      (item) =>
        item.is_out_of_stock === true ||
        (item.available_stock !== null &&
          item.available_stock !== undefined &&
          item.available_stock < item.quantity),
    );
  };

  const getOutOfStockItems = () => {
    return cartItems.filter(
      (item) =>
        item.is_out_of_stock === true ||
        (item.available_stock !== null &&
          item.available_stock !== undefined &&
          item.available_stock < item.quantity),
    );
  };

  const cartTotal = cartItems.reduce(
    (total, item) => total + (Number(item.price) || 0) * (Number(item.quantity) || 0),
    0,
  );
  const cartCount = cartItems.reduce(
    (count, item) => count + (Number(item.quantity) || 0),
    0,
  );

  return (
    <CartContext.Provider
      value={{
        cartItems,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        cartTotal,
        cartCount,
        setCartItems,
        hasOutOfStockItems,
        getOutOfStockItems,
        isDeliverable,
        setIsDeliverable,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    console.warn("CartProvider is missing!");
    return {
      cartItems: [],
      isCartOpen: false,
      setIsCartOpen: () => {},
      addToCart: () => ({ success: false, error: "Cart not available" }),
      updateQuantity: () => ({ success: false, error: "Cart not available" }),
      removeFromCart: () => {},
      clearCart: () => {},
      cartTotal: 0,
      cartCount: 0,
      setCartItems: () => {},
      hasOutOfStockItems: () => false,
      getOutOfStockItems: () => [],
      isDeliverable: true,
      setIsDeliverable: () => {},
    };
  }
  return context;
};