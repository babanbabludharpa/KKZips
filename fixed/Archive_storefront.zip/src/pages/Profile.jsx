import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Package, MapPin, CreditCard, LogOut, Star, Truck, User, Mail, Phone, Home as HomeIcon } from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import { useCustomerAuth } from "../store/useCustomerAuth";
import customerApi from "../api/customerApi";

// ─────────────────────────────────────────────────────────────────────────
// Profile.jsx — FIXED: shows default address + allows setting default
//
// FIXES:
//   1. Fetches /mobile/addresses on mount
//   2. Shows the default address in a card
//   3. If no default is set, shows the first address
//   4. "Set as Default" button on each address
//   5. Uses PATCH /mobile/addresses/{id}/default to set default
// ─────────────────────────────────────────────────────────────────────────

const theme = { primary: "#FF7132", dark: "#1E293B", mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0" };

const defaultProfileData = {
  hero: { alignment: "center", badge: "My Account", title: "Your Profile", subtitle: "Manage your account, orders, and subscriptions in one place." },
  banner: { enabled: true, text: "Welcome back!", bg_color: "#FFF7ED", text_color: "#9A3412" },
  quickLinks: {
    title: "Quick Links",
    show_orders: true, orders_label: "My Orders", orders_desc: "View order history",
    show_subscriptions: true, subscriptions_label: "My Subscriptions", subscriptions_desc: "Manage subscriptions",
    show_addresses: true, addresses_label: "Addresses", addresses_desc: "Saved delivery addresses",
  },
};

export default function Profile() {
  const { sections, isLoading } = useTenant();
  const { customer, logout } = useCustomerAuth();
  const [addresses, setAddresses] = useState([]);
  const [loadingAddr, setLoadingAddr] = useState(true);
  const [settingDefault, setSettingDefault] = useState(null);

  const profileData = (Array.isArray(sections) ? sections : []).find(s => s.page === "profile")?.data || defaultProfileData;
  const hero = profileData.hero || defaultProfileData.hero;
  const banner = profileData.banner || defaultProfileData.banner;
  const quickLinks = profileData.quickLinks || defaultProfileData.quickLinks;

  // ★ Fetch addresses
  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const res = await customerApi.get("/mobile/addresses");
        const addrs = res.data?.data || [];
        setAddresses(addrs);
      } catch (e) {
        console.error("Failed to fetch addresses:", e);
      } finally {
        setLoadingAddr(false);
      }
    };
    fetchAddresses();
  }, []);

  // ★ Set default address
  const handleSetDefault = async (id) => {
    setSettingDefault(id);
    try {
      await customerApi.patch(`/mobile/addresses/${id}/default`);
      // Update local state
      setAddresses(prev => prev.map(a => ({ ...a, is_default: a.id === id })));
    } catch (e) {
      console.error("Failed to set default:", e);
      alert("Failed to set default address. Please try again.");
    } finally {
      setSettingDefault(null);
    }
  };

  // ★ Get default address (or first one if no default)
  const defaultAddr = addresses.find(a => a.is_default) || addresses[0] || null;

  if (isLoading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
          <div style={{ color: theme.mid }}>Loading…</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  const initial = (customer?.name && customer.name.trim().charAt(0).toUpperCase()) || "U";

  return (
    <div style={{ background: theme.bg, minHeight: "100vh" }}>
      {/* Hero Section */}
      <section style={{ background: "var(--color-primary, #FF7132)", color: "#fff", padding: "40px 24px", textAlign: hero.alignment || "center" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={{ maxWidth: 600, margin: "0 auto" }}>
          <div style={{ width: 70, height: 70, borderRadius: "50%", background: "#fff", margin: "0 auto 16px", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--color-primary, #FF7132)", fontWeight: 800, fontSize: "1.8rem" }}>{initial}</div>
          {hero.badge && <span style={{ display: "inline-block", background: "rgba(255,255,255,0.2)", padding: "4px 14px", borderRadius: 100, fontSize: "0.75rem", fontWeight: 700, marginBottom: 8 }}>{hero.badge}</span>}
          <h1 style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 900, margin: "0 0 8px" }}>{hero.title}</h1>
          <p style={{ opacity: 0.9, fontSize: "0.95rem" }}>{hero.subtitle}</p>
        </motion.div>
      </section>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "24px" }}>
        {/* Welcome Banner */}
        {banner.enabled !== false && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} style={{ background: banner.bg_color || "#FFF7ED", color: banner.text_color || "#9A3412", padding: "16px 20px", borderRadius: 12, marginBottom: 24, display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: "1.5rem" }}>👋</span>
            <span style={{ fontSize: "0.9rem", fontWeight: 600 }}>{banner.text || "Welcome back!"}</span>
          </motion.div>
        )}

        {/* Account Info Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={{ background: "#fff", borderRadius: 16, padding: 24, marginBottom: 24, border: `1px solid ${theme.border}` }}>
          <h2 style={{ fontSize: "1.1rem", fontWeight: 800, color: theme.dark, marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
            <User size={18} color="var(--color-primary, #FF7132)" /> Account Information
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 }}>
            <div>
              <label style={{ fontSize: "0.75rem", color: theme.mid, fontWeight: 600, textTransform: "uppercase" }}>Name</label>
              <p style={{ fontSize: "0.95rem", color: theme.dark, fontWeight: 600, margin: "4px 0 0" }}>{customer?.name || "—"}</p>
            </div>
            <div>
              <label style={{ fontSize: "0.75rem", color: theme.mid, fontWeight: 600, textTransform: "uppercase" }}>Email</label>
              <p style={{ fontSize: "0.95rem", color: theme.dark, fontWeight: 600, margin: "4px 0 0", display: "flex", alignItems: "center", gap: 4 }}><Mail size={14} /> {customer?.email || "—"}</p>
            </div>
            <div>
              <label style={{ fontSize: "0.75rem", color: theme.mid, fontWeight: 600, textTransform: "uppercase" }}>Phone</label>
              <p style={{ fontSize: "0.95rem", color: theme.dark, fontWeight: 600, margin: "4px 0 0", display: "flex", alignItems: "center", gap: 4 }}><Phone size={14} /> {customer?.phone || "—"}</p>
            </div>
          </div>
        </motion.div>

        {/* ★ DEFAULT ADDRESS CARD — NEW */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={{ background: "#fff", borderRadius: 16, padding: 24, marginBottom: 24, border: `1px solid ${theme.border}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 800, color: theme.dark, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>
              <MapPin size={18} color="var(--color-primary, #FF7132)" /> Default Delivery Address
            </h2>
            <Link to="/addresses" style={{ fontSize: "0.8rem", color: "var(--color-primary, #FF7132)", textDecoration: "none", fontWeight: 600 }}>Manage all →</Link>
          </div>

          {loadingAddr ? (
            <div style={{ textAlign: "center", padding: 20, color: theme.mid, fontSize: "0.85rem" }}>Loading address…</div>
          ) : defaultAddr ? (
            <div style={{ background: theme.bg, borderRadius: 12, padding: 16, border: `1px solid ${theme.border}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                    <HomeIcon size={14} color="var(--color-primary, #FF7132)" />
                    <span style={{ fontWeight: 700, fontSize: "0.9rem", color: theme.dark }}>{defaultAddr.label || defaultAddr.type || "Home"}</span>
                    {defaultAddr.is_default && <span style={{ background: "var(--color-primary, #FF7132)", color: "#fff", fontSize: "0.6rem", padding: "2px 6px", borderRadius: 4, fontWeight: 700 }}>DEFAULT</span>}
                  </div>
                  <p style={{ fontSize: "0.85rem", color: theme.dark, margin: "4px 0", lineHeight: 1.5 }}>
                    {defaultAddr.address_line_1 || defaultAddr.address || "—"}<br />
                    {defaultAddr.address_line_2 && <>{defaultAddr.address_line_2}<br /></>}
                    {[defaultAddr.city, defaultAddr.state, defaultAddr.pincode].filter(Boolean).join(", ")}
                  </p>
                  {defaultAddr.latitude && defaultAddr.longitude && (
                    <p style={{ fontSize: "0.7rem", color: theme.mid, marginTop: 4 }}>
                      📍 {parseFloat(defaultAddr.latitude).toFixed(4)}, {parseFloat(defaultAddr.longitude).toFixed(4)}
                    </p>
                  )}
                </div>
              </div>
              {!defaultAddr.is_default && (
                <button
                  onClick={() => handleSetDefault(defaultAddr.id)}
                  disabled={settingDefault === defaultAddr.id}
                  style={{ marginTop: 8, padding: "6px 14px", background: "var(--color-primary, #FF7132)", color: "#fff", border: "none", borderRadius: 8, fontSize: "0.75rem", fontWeight: 700, cursor: "pointer", opacity: settingDefault === defaultAddr.id ? 0.6 : 1 }}
                >
                  {settingDefault === defaultAddr.id ? "Setting…" : "Set as Default"}
                </button>
              )}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: 24, background: theme.bg, borderRadius: 12, border: `1px dashed ${theme.border}` }}>
              <MapPin size={32} color={theme.mid} style={{ margin: "0 auto 8px" }} />
              <p style={{ color: theme.dark, fontWeight: 600, marginBottom: 4, fontSize: "0.9rem" }}>No address saved</p>
              <p style={{ color: theme.mid, fontSize: "0.8rem", marginBottom: 12 }}>Add a delivery address for accurate deliveries</p>
              <Link to="/addresses" style={{ display: "inline-block", padding: "8px 16px", background: "var(--color-primary, #FF7132)", color: "#fff", borderRadius: 8, textDecoration: "none", fontSize: "0.8rem", fontWeight: 700 }}>+ Add Address</Link>
            </div>
          )}

          {/* Show other addresses (if any) */}
          {addresses.length > 1 && (
            <div style={{ marginTop: 16 }}>
              <small style={{ color: theme.mid, fontWeight: 600, textTransform: "uppercase", fontSize: "0.7rem" }}>Other Addresses ({addresses.length - 1})</small>
              {addresses.filter(a => a.id !== defaultAddr?.id).map(addr => (
                <div key={addr.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", marginTop: 4, background: theme.bg, borderRadius: 8, border: `1px solid ${theme.border}` }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ fontSize: "0.8rem", fontWeight: 600, color: theme.dark }}>{addr.label || addr.type || "Address"}</span>
                    <p style={{ fontSize: "0.7rem", color: theme.mid, margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {addr.address_line_1 || addr.address || "—"}
                    </p>
                  </div>
                  <button
                    onClick={() => handleSetDefault(addr.id)}
                    disabled={settingDefault === addr.id}
                    style={{ padding: "4px 10px", background: "transparent", color: "var(--color-primary, #FF7132)", border: `1px solid var(--color-primary, #FF7132)`, borderRadius: 6, fontSize: "0.7rem", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", opacity: settingDefault === addr.id ? 0.6 : 1 }}
                  >
                    {settingDefault === addr.id ? "…" : "Set Default"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Quick Links */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={{ marginBottom: 24 }}>
          <h2 style={{ fontSize: "1.1rem", fontWeight: 800, color: theme.dark, marginBottom: 16 }}>{quickLinks.title || "Quick Links"}</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12 }}>
            {quickLinks.show_orders !== false && (
              <Link to="/orders" style={{ textDecoration: "none" }}>
                <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 12, transition: "box-shadow 0.2s", cursor: "pointer" }} onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.08)"} onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: "var(--color-primary, #FF7132)", display: "flex", alignItems: "center", justifyContent: "center" }}><Package size={20} color="#fff" /></div>
                  <div><p style={{ color: theme.dark, fontWeight: 700, margin: 0, fontSize: "0.9rem" }}>{quickLinks.orders_label || "My Orders"}</p><p style={{ color: theme.mid, fontSize: "0.75rem", margin: 0 }}>{quickLinks.orders_desc || "View order history"}</p></div>
                </div>
              </Link>
            )}
            {quickLinks.show_subscriptions !== false && (
              <Link to="/subscription" style={{ textDecoration: "none" }}>
                <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 12, transition: "box-shadow 0.2s", cursor: "pointer" }} onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.08)"} onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: "var(--color-primary, #FF7132)", display: "flex", alignItems: "center", justifyContent: "center" }}><Truck size={20} color="#fff" /></div>
                  <div><p style={{ color: theme.dark, fontWeight: 700, margin: 0, fontSize: "0.9rem" }}>{quickLinks.subscriptions_label || "My Subscriptions"}</p><p style={{ color: theme.mid, fontSize: "0.75rem", margin: 0 }}>{quickLinks.subscriptions_desc || "Manage subscriptions"}</p></div>
                </div>
              </Link>
            )}
            {quickLinks.show_addresses !== false && (
              <Link to="/addresses" style={{ textDecoration: "none" }}>
                <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 12, transition: "box-shadow 0.2s", cursor: "pointer" }} onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.08)"} onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: "var(--color-primary, #FF7132)", display: "flex", alignItems: "center", justifyContent: "center" }}><MapPin size={20} color="#fff" /></div>
                  <div><p style={{ color: theme.dark, fontWeight: 700, margin: 0, fontSize: "0.9rem" }}>{quickLinks.addresses_label || "Addresses"}</p><p style={{ color: theme.mid, fontSize: "0.75rem", margin: 0 }}>{quickLinks.addresses_desc || "Saved delivery addresses"}</p></div>
                </div>
              </Link>
            )}
          </div>
        </motion.div>

        {/* Logout */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={logout}
          style={{ width: "100%", padding: "14px", background: "transparent", color: "#ef4444", border: "1px solid #ef4444", borderRadius: 12, fontSize: "0.9rem", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          <LogOut size={16} /> Logout
        </motion.button>
      </div>
    </div>
  );
}
