import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Store,
  TrendingUp,
  Banknote,
  ShieldCheck,
  CheckCircle2,
  User,
  Phone,
  MapPin,
  Briefcase,
  AlertCircle,
} from "lucide-react";

// Header aur Footer import karein
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

// Shop Hub Theme Colors
const theme = {
  primary: "#F97316",
  primaryHover: "#EA580C",
  dark: "#002868",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
  success: "#22C55E",
  error: "#EF4444",
};

const benefits = [
  {
    icon: TrendingUp,
    title: "Assured Daily Orders",
    desc: "Get a predictable number of daily subscription orders from nearby societies.",
  },
  {
    icon: Banknote,
    title: "Weekly Auto-Payouts",
    desc: "No more cash collection hassle. Get your payments directly in your bank account every week.",
  },
  {
    icon: Store,
    title: "Digital Storefront",
    desc: "Manage your inventory, prices, and daily dispatches right from your smartphone.",
  },
  {
    icon: ShieldCheck,
    title: "Verified Customers",
    desc: "We pre-verify customers and their wallet balances, ensuring zero defaults on payments.",
  },
];

const steps = [
  {
    num: "1",
    title: "Register Online",
    desc: "Fill out the simple partner application form below with your basic business details.",
  },
  {
    num: "2",
    title: "Quick Verification",
    desc: "Our team will call you to verify your services, hygiene standards, and delivery capacity.",
  },
  {
    num: "3",
    title: "Go Live",
    desc: "Your services get listed on the Shop Hub app for customers in your selected pin codes.",
  },
  {
    num: "4",
    title: "Start Earning",
    desc: "Receive morning dispatch lists digitally and start fulfilling daily subscriptions.",
  },
];

export default function Partner() {
  const [form, setForm] = useState({
    ownerName: "",
    businessName: "",
    phone: "",
    category: "",
    pincode: "",
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (errors[name]) setErrors((p) => ({ ...p, [name]: "" }));
  };

  const validate = () => {
    const errs = {};
    if (!form.ownerName.trim()) errs.ownerName = "Owner Name is required";
    if (!form.businessName.trim())
      errs.businessName = "Business Name is required";
    if (!form.phone.trim() || form.phone.length < 10)
      errs.phone = "Valid 10-digit Phone Number is required";
    if (!form.category) errs.category = "Please select a business category";
    if (!form.pincode.trim() || form.pincode.length !== 6)
      errs.pincode = "Valid 6-digit Pincode is required";
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    setLoading(true);
    // API Call Simulation
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setSuccess(true);
    setForm({
      ownerName: "",
      businessName: "",
      phone: "",
      category: "",
      pincode: "",
    });

    setTimeout(() => setSuccess(false), 5000);
  };

  const scrollToForm = () => {
    const formSection = document.getElementById("register-form");
    if (formSection) {
      const yOffset = -100;
      const y =
        formSection.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  const inputClass = (fieldName) =>
    `form-input ${errors[fieldName] ? "has-error" : ""}`;

  return (
    <>
      <Navbar />

      <div style={{ minHeight: "100vh", background: theme.bg }}>
        {/* ── Hero Section ──────────────────────────────────────── */}
        <section className="partner-hero">
          <div
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage:
                "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
              backgroundSize: "30px 30px",
              pointerEvents: "none",
            }}
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            style={{
              position: "relative",
              zIndex: 1,
              maxWidth: "800px",
              margin: "0 auto",
            }}
          >
            <span className="hero-badge">Partner With Shop Hub</span>
            <h1 className="hero-title">Grow Your Local Business With Us</h1>
            <p className="hero-desc">
              Join thousands of local dairy farmers, tiffin centers, and laundry
              services who have multiplied their daily orders and simplified
              their payments.
            </p>
            <div style={{ marginTop: "32px" }}>
              <button onClick={scrollToForm} className="btn-primary">
                Apply Now <ArrowRightIcon size={18} />
              </button>
            </div>
          </motion.div>
        </section>

        {/* ── Benefits Section ──────────────────────────────────── */}
        <section className="section-padding" style={{ background: "#fff" }}>
          <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: "48px" }}>
              <h2 className="section-title">Why Partner With Shop Hub?</h2>
              <p
                style={{
                  color: theme.mid,
                  fontSize: "1.05rem",
                  maxWidth: "500px",
                  margin: "0 auto",
                }}
              >
                Focus on quality and delivery. Leave the digital storefront,
                customer acquisition, and payments to us.
              </p>
            </div>
            <div className="benefits-grid">
              {benefits.map((b, i) => {
                const Icon = b.icon;
                return (
                  <motion.div
                    key={b.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="benefit-card"
                  >
                    <div className="benefit-icon">
                      <Icon size={24} color={theme.primary} />
                    </div>
                    <h3
                      style={{
                        fontSize: "1.15rem",
                        fontWeight: "800",
                        color: theme.dark,
                        marginBottom: "8px",
                      }}
                    >
                      {b.title}
                    </h3>
                    <p
                      style={{
                        color: theme.mid,
                        fontSize: "0.95rem",
                        lineHeight: "1.6",
                        margin: 0,
                      }}
                    >
                      {b.desc}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ── Steps & Form Section ──────────────────────────────── */}
        <section
          id="register-form"
          className="section-padding"
          style={{ background: theme.bg }}
        >
          <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
            <div className="form-layout-grid">
              {/* Left Side: How it works */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h2
                  className="section-title"
                  style={{ textAlign: "left", marginBottom: "32px" }}
                >
                  How It Works
                </h2>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "24px",
                  }}
                >
                  {steps.map((step, i) => (
                    <div key={i} style={{ display: "flex", gap: "20px" }}>
                      <div className="step-number">{step.num}</div>
                      <div>
                        <h4
                          style={{
                            fontSize: "1.1rem",
                            fontWeight: "800",
                            color: theme.dark,
                            marginBottom: "4px",
                          }}
                        >
                          {step.title}
                        </h4>
                        <p
                          style={{
                            color: theme.mid,
                            fontSize: "0.95rem",
                            lineHeight: "1.5",
                            margin: 0,
                          }}
                        >
                          {step.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div
                  style={{
                    marginTop: "48px",
                    padding: "24px",
                    background: "#EFF6FF",
                    borderRadius: "16px",
                    border: "1px solid #BFDBFE",
                  }}
                >
                  <h4
                    style={{
                      fontSize: "1rem",
                      fontWeight: "800",
                      color: "#1E3A8A",
                      marginBottom: "8px",
                    }}
                  >
                    Need help onboarding?
                  </h4>
                  <p
                    style={{
                      color: "#1E40AF",
                      fontSize: "0.9rem",
                      marginBottom: "0",
                    }}
                  >
                    Call our dedicated vendor support line:{" "}
                    <strong>+91 93734 23799</strong>
                  </p>
                </div>
              </motion.div>

              {/* Right Side: Application Form */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="form-card"
              >
                <h3
                  style={{
                    fontSize: "1.6rem",
                    fontWeight: "900",
                    color: theme.dark,
                    marginBottom: "8px",
                    letterSpacing: "-0.02em",
                  }}
                >
                  Partner Application
                </h3>
                <p
                  style={{
                    color: theme.mid,
                    fontSize: "0.95rem",
                    marginBottom: "32px",
                  }}
                >
                  Fill out the details below. Our onboarding team will contact
                  you within 24 hours.
                </p>

                <form onSubmit={handleSubmit} noValidate>
                  <div className="form-row">
                    <div>
                      <label className="form-label">Owner's Full Name</label>
                      <div className="input-wrapper">
                        <User size={18} className="input-icon" />
                        <input
                          type="text"
                          name="ownerName"
                          value={form.ownerName}
                          onChange={handleChange}
                          placeholder="Rahul Kumar"
                          className={inputClass("ownerName")}
                        />
                      </div>
                      {errors.ownerName && (
                        <span className="error-text">
                          <AlertCircle size={14} /> {errors.ownerName}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="form-label">Business Name</label>
                      <div className="input-wrapper">
                        <Briefcase size={18} className="input-icon" />
                        <input
                          type="text"
                          name="businessName"
                          value={form.businessName}
                          onChange={handleChange}
                          placeholder="Fresh Dairy Farm"
                          className={inputClass("businessName")}
                        />
                      </div>
                      {errors.businessName && (
                        <span className="error-text">
                          <AlertCircle size={14} /> {errors.businessName}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="form-row">
                    <div>
                      <label className="form-label">Phone Number</label>
                      <div className="input-wrapper">
                        <Phone size={18} className="input-icon" />
                        <input
                          type="tel"
                          name="phone"
                          value={form.phone}
                          onChange={handleChange}
                          placeholder="98765 43210"
                          maxLength={10}
                          className={inputClass("phone")}
                        />
                      </div>
                      {errors.phone && (
                        <span className="error-text">
                          <AlertCircle size={14} /> {errors.phone}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="form-label">Service Category</label>
                      <select
                        name="category"
                        value={form.category}
                        onChange={handleChange}
                        className={inputClass("category")}
                        style={{ cursor: "pointer", paddingLeft: "16px" }}
                      >
                        <option value="">Select Category...</option>
                        <option value="Milk & Dairy">Milk & Dairy</option>
                        <option value="Tiffin Services">Tiffin Services</option>
                        <option value="Water Jars">Water Jars</option>
                        <option value="Laundry & Iron">Laundry & Iron</option>
                        <option value="Flowers & Pooja">Flowers & Pooja</option>
                        <option value="Other">Other</option>
                      </select>
                      {errors.category && (
                        <span className="error-text">
                          <AlertCircle size={14} /> {errors.category}
                        </span>
                      )}
                    </div>
                  </div>

                  <div style={{ marginBottom: "32px" }}>
                    <label className="form-label">Primary Pincode</label>
                    <div className="input-wrapper">
                      <MapPin size={18} className="input-icon" />
                      <input
                        type="text"
                        name="pincode"
                        value={form.pincode}
                        onChange={handleChange}
                        placeholder="e.g. 411057"
                        maxLength={6}
                        className={inputClass("pincode")}
                      />
                    </div>
                    {errors.pincode && (
                      <span className="error-text">
                        <AlertCircle size={14} /> {errors.pincode}
                      </span>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="submit-btn"
                  >
                    {loading ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          ease: "linear",
                        }}
                        style={{ display: "flex" }}
                      >
                        <RefreshSpinner />
                      </motion.div>
                    ) : (
                      <>
                        <CheckCircle2 size={18} /> Submit Application
                      </>
                    )}
                  </button>

                  <AnimatePresence>
                    {success && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        style={{
                          marginTop: "20px",
                          padding: "16px",
                          background: "#F0FDF4",
                          border: "1px solid #BBF7D0",
                          borderRadius: "12px",
                          display: "flex",
                          alignItems: "flex-start",
                          gap: "12px",
                          color: "#15803D",
                        }}
                      >
                        <CheckCircle2
                          size={20}
                          color={theme.success}
                          style={{ flexShrink: 0 }}
                        />
                        <span
                          style={{ fontWeight: "600", fontSize: "0.95rem" }}
                        >
                          Application submitted successfully! Our partner team
                          will call you on your registered mobile number soon.
                        </span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </form>
              </motion.div>
            </div>
          </div>
        </section>
      </div>

      <Footer />

      {/* ─────────────────────────────────────────────
          GLOBAL STYLES FOR PARTNER PAGE
      ───────────────────────────────────────────── */}
      <style>{`
        /* Core Utils */
        .section-padding { padding: 96px 24px; }
        .section-title { font-size: clamp(1.8rem, 4vw, 2.6rem); font-weight: 900; color: ${theme.dark}; letter-spacing: -0.02em; margin-bottom: 16px; }

        /* Hero Section */
        .partner-hero {
          background: linear-gradient(135deg, #001440 0%, #001440 100%);
          padding: 80px 24px 64px;
          text-align: center; position: relative; overflow: hidden;
        }
        .hero-badge {
          display: inline-block; background: rgba(18, 89, 255, 0.21); 
          border: 1px solid rgba(255,255,255,0.15); color: #fff;
          padding: 8px 18px; border-radius: 100px; font-size: 0.85rem; 
          font-weight: 800; margin-bottom: 24px; letter-spacing: 0.05em; 
          text-transform: uppercase;
        }
        .hero-title {
          color: #fff; font-size: clamp(2.4rem, 5vw, 4rem); 
          font-weight: 900; margin-bottom: 16px; letter-spacing: -0.03em; 
          line-height: 1.1;
        }
        .hero-desc {
          color: rgba(255,255,255,0.9); font-size: clamp(1rem, 2vw, 1.15rem); 
          max-width: 600px; margin: 0 auto; line-height: 1.5;
        }

        /* Buttons */
        .btn-primary {
          display: inline-flex; align-items: center; justify-content: center; gap: 8px;
          padding: 16px 32px; border-radius: 14px; background: ${theme.primary};
          color: #fff; border: none; font-size: 1.05rem; font-weight: 800;
          cursor: pointer; transition: all 0.2s; box-shadow: 0 8px 24px rgba(249,115,22,0.3);
          font-family: inherit;
        }
        .btn-primary:hover {
          background: ${theme.primaryHover}; transform: translateY(-2px);
          box-shadow: 0 12px 32px rgba(249,115,22,0.4);
        }

        /* Benefits Grid */
        .benefits-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 24px; }
        .benefit-card { background: #fff; border: 1px solid ${theme.border}; border-radius: 20px; padding: 32px; transition: all 0.3s; }
        .benefit-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,0.06); border-color: #CBD5E1; }
        .benefit-icon { width: 56px; height: 56px; border-radius: 16px; background: #FFF7ED; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }

        /* Form Layout */
        .form-layout-grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 64px; align-items: start; }
        .step-number { width: 40px; height: 40px; border-radius: 50%; background: ${theme.dark}; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; font-weight: 900; flex-shrink: 0; }

        /* Form Card */
        .form-card { background: #fff; border-radius: 24px; padding: clamp(24px, 4vw, 48px); box-shadow: 0 20px 50px rgba(0,0,0,0.06); border: 1px solid ${theme.border}; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .form-label { display: block; font-size: 0.9rem; font-weight: 700; color: ${theme.dark}; margin-bottom: 8px; }
        .input-wrapper { position: relative; }
        .input-icon { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: ${theme.mid}; }
        .form-input {
          width: 100%; padding: 16px 16px 16px 44px; border-radius: 12px;
          border: 1.5px solid ${theme.border}; background: #F8FAFC;
          font-size: 0.95rem; color: ${theme.dark}; outline: none;
          transition: all 0.2s ease; font-family: inherit;
        }
        .form-input:focus { border-color: ${theme.primary}; background: #fff; box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1); }
        .form-input.has-error { border-color: ${theme.error}; background: #FEF2F2; }
        .error-text { display: flex; align-items: center; gap: 4px; color: ${theme.error}; font-size: 0.8rem; margin-top: 6px; font-weight: 600; }

        .submit-btn {
          width: 100%; padding: 18px; border-radius: 14px; background: ${theme.dark};
          color: #fff; border: none; font-size: 1.05rem; font-weight: 800; cursor: pointer;
          display: flex; align-items: center; justify-content: center; gap: 10px;
          transition: all 0.2s ease; font-family: inherit;
        }
        .submit-btn:hover:not(:disabled) { background: #0F172A; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(30,41,59,0.25); }
        .submit-btn:disabled { opacity: 0.7; cursor: not-allowed; }

        /* Responsive Breakpoints */
        @media (max-width: 992px) {
          .form-layout-grid { grid-template-columns: 1fr; gap: 48px; }
        }
        @media (max-width: 640px) {
          .section-padding { padding: 64px 20px; }
          .partner-hero { padding: 80px 20px 60px; }
          .form-row { grid-template-columns: 1fr !important; gap: 16px !important; }
        }
      `}</style>
    </>
  );
}

const ArrowRightIcon = ({ size }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M5 12h14" />
    <path d="m12 5 7 7-7 7" />
  </svg>
);
const RefreshSpinner = () => (
  <svg
    width="22"
    height="22"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
  </svg>
);
