import { useParams } from "react-router-dom";
import { useTenant } from "../contexts/TenantProvider";
import SectionRenderer from "../components/SectionRenderer";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const theme = {
  primary: "#FF7132",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

export default function CustomPage() {
  const { slug } = useParams();
  const { customPages, isLoading } = useTenant();

  if (isLoading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
          <div style={{ color: theme.mid }}>Loading…</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  const page = (customPages || []).find((p) => p.slug === slug);

  if (!page) {
    return (
      <>
        <Navbar />
        <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg, padding: 24 }}>
          <div style={{ background: "#fff", borderRadius: 20, padding: 40, textAlign: "center", maxWidth: 480, border: `1px solid ${theme.border}` }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📄</div>
            <h2 style={{ color: theme.dark, marginBottom: 8 }}>Page Not Found</h2>
            <p style={{ color: theme.mid, marginBottom: 24 }}>The page "{slug}" doesn't exist or has been removed.</p>
            <a href="/" style={{ padding: "12px 24px", background: theme.primary, color: "#fff", border: "none", borderRadius: 12, fontWeight: 600, cursor: "pointer", textDecoration: "none" }}>Go Home</a>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const sections = page.sections || [];

  if (page.seo_title) document.title = page.seo_title;
  else document.title = page.title || "Page";

  return (
    <>
      <Navbar />
      {/* ★ Flex container allows sections to sit side-by-side if configured as 'half' width */}
      <div style={{ background: theme.bg, minHeight: "100vh", display: "flex", flexWrap: "wrap", alignContent: "flex-start" }}>
        {sections.map((section, index) => (
          <SectionRenderer key={section.id || index} section={section} />
        ))}
      </div>
      <Footer />
    </>
  );
}