import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Wallet as WalletIcon, Plus, ArrowDownCircle, ArrowUpCircle,
  Loader, AlertCircle, X, Check, ArrowLeft
} from "lucide-react";
import customerApi from "../api/customerApi";
import { useTenant } from "../contexts/TenantProvider";
import { useCustomerAuth } from "../store/useCustomerAuth";
import toast from "react-hot-toast";

// ── Helpers ──
const fmtMoney = (n) => `₹${Number(n ?? 0).toFixed(2)}`;
const fmtDate = (d) => d ? new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—";

export default function Wallet() {
  const { theme: tenantTheme } = useTenant();
  const navigate = useNavigate();
  const { isAuthenticated } = useCustomerAuth();

  // ★ Dynamic theme
  const theme = {
    primary: tenantTheme?.primary_color || "#666666",
    dark: "#1E293B",
    mid: "#64748B",
    bg: "#F8FAFF",
    border: "#E2E8F0",
    success: "#22C55E",
    error: "#EF4444",
  };

  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [loadingBalance, setLoadingBalance] = useState(true);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  
  const [processingPayment, setProcessingPayment] = useState(false);
  const [showAddMoneyModal, setShowAddMoneyModal] = useState(false);
  const [pendingTopupId, setPendingTopupId] = useState(null);

  // ── Fetch Balance ──
  const fetchBalance = async () => {
    try {
      const res = await customerApi.get("/mobile/wallet/balance");
      if (res.data?.status) {
        setBalance(Number(res.data.data.balance || 0));
      }
    } catch (e) {
      console.error("Wallet balance fetch failed:", e);
    } finally {
      setLoadingBalance(false);
    }
  };

  // ── Fetch Transaction History ──
  const fetchHistory = async (pageNum = 1, append = false) => {
    if (pageNum === 1) setLoadingHistory(true);
    else setLoadingMore(true);

    try {
      const res = await customerApi.get("/mobile/wallet/transactions", {
        params: { page: pageNum }
      });
      
      if (res.data?.status) {
        const paginationData = res.data.data;
        const newTxns = paginationData.data || [];
        
        setTransactions(prev => append ? [...prev, ...newTxns] : newTxns);
        setHasMore(paginationData.current_page < paginationData.last_page);
        setPage(paginationData.current_page);
      }
    } catch (e) {
      console.error("Wallet history fetch failed:", e);
      toast.error("Could not load transaction history.");
    } finally {
      setLoadingHistory(false);
      setLoadingMore(false);
    }
  };

  // ── Reconciliation (if user closes tab mid-payment) ──
  const reconcilePendingTopup = useCallback(async () => {
    if (!pendingTopupId) return;
    try {
      const res = await customerApi.get(`/mobile/wallet/topup/${pendingTopupId}/status`);
      const status = res.data?.data?.status;
      
      if (status === "paid") {
        setPendingTopupId(null);
        await fetchBalance();
        await fetchHistory(1);
        toast.success("Wallet credited successfully!");
      } else if (status === "failed" || status === "expired") {
        setPendingTopupId(null);
        toast.error("Payment was not completed. Please try again.");
      }
    } catch (e) {
      console.error("Reconciliation failed:", e);
    }
  }, [pendingTopupId]);

  // ── Init ──
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login", { replace: true });
      return;
    }
    fetchBalance();
    fetchHistory(1);
  }, [isAuthenticated, navigate]);

  // Check for pending topups on mount or when window regains focus
  useEffect(() => {
    const onFocus = () => { if (pendingTopupId) reconcilePendingTopup(); };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [pendingTopupId, reconcilePendingTopup]);

  // ── Load Razorpay Script ──
  const loadRazorpayScript = () =>
    new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });

  // ── Razorpay "Add Money" Flow ──
  const handleAddMoney = async (amount) => {
    setShowAddMoneyModal(false);
    setProcessingPayment(true);

    try {
      const res = await customerApi.post("/mobile/wallet/topup", { amount });
      const data = res.data?.data;
      if (!data) throw new Error("Failed to initiate payment");

      setPendingTopupId(data.wallet_topup_id);

      // ★ Load the script before opening Razorpay
      const scriptLoaded = await loadRazorpayScript();
      if (!scriptLoaded) {
        setProcessingPayment(false);
        toast.error("Razorpay SDK failed to load. Check your internet connection.");
        return;
      }

      const options = {
        key: data.key_id,
        amount: data.amount, // in paise
        currency: data.currency || "INR",
        name: "Wallet Top-up",
        description: "Add money to wallet",
        order_id: data.razorpay_order_id,
        handler: async function (response) {
          // Payment succeeded, verify signature
          try {
            await customerApi.post(`/mobile/wallet/topup/${data.wallet_topup_id}/verify`, {
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            setPendingTopupId(null);
            await fetchBalance();
            await fetchHistory(1);
            toast.success("Wallet credited successfully!");
          } catch (err) {
            console.error("Verify failed, attempting reconciliation:", err);
            await reconcilePendingTopup();
          }
        },
        modal: {
          ondismiss: () => {
            setProcessingPayment(false);
            toast("Payment cancelled. If money was deducted, it will be credited shortly.", { icon: "ℹ️" });
          }
        },
        theme: { color: theme.primary }
      };

      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", function (response) {
        setProcessingPayment(false);
        toast.error(response.error.description || "Payment failed");
      });
      
      rzp.open();

    } catch (e) {
      setProcessingPayment(false);
      toast.error(e.response?.data?.message || "Could not start payment.");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, padding: "40px 24px" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        
        {/* ★ Back to Home Button */}
        <button 
          onClick={() => navigate("/")} 
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            background: "transparent",
            border: "none",
            color: theme.mid,
            fontSize: "0.9rem",
            fontWeight: 600,
            cursor: "pointer",
            padding: 0,
            marginBottom: 16
          }}
        >
          <ArrowLeft size={18} />
          Back to Home
        </button>

        <h1 style={{ fontSize: "1.8rem", fontWeight: 900, color: theme.dark, marginTop: 8, marginBottom: 24 }}>
          My Wallet
        </h1>

        {/* Balance Card */}
        <div style={{
          background: theme.primary,
          padding: 32,
          borderRadius: 20,
          color: "#fff",
          marginBottom: 32,
          boxShadow: "0 10px 30px rgba(0,0,0,0.1)"
        }}>
          <p style={{ margin: 0, opacity: 0.9, fontSize: "0.9rem", marginBottom: 8 }}>Current Balance</p>
          {loadingBalance ? (
            <Loader size={32} className="animate-spin" />
          ) : (
            <h2 style={{ fontSize: "3rem", fontWeight: 900, margin: 0 }}>
              {fmtMoney(balance)}
            </h2>
          )}
          {balance < 0 && !loadingBalance && (
            <p style={{ fontSize: "0.8rem", opacity: 0.8, marginTop: 8 }}>
              Negative balance reflects amount due on invoices.
            </p>
          )}
          
          <button
            onClick={() => setShowAddMoneyModal(true)}
            disabled={processingPayment}
            style={{
              marginTop: 24,
              padding: "12px 24px",
              background: "rgba(255,255,255,0.2)",
              color: "#fff",
              border: "1px solid rgba(255,255,255,0.4)",
              borderRadius: 12,
              fontWeight: 700,
              cursor: processingPayment ? "not-allowed" : "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 8
            }}
          >
            {processingPayment ? <Loader size={16} className="animate-spin" /> : <Plus size={16} />}
            {processingPayment ? "Processing..." : "Add Money"}
          </button>
        </div>

        {/* Transaction History */}
        <h3 style={{ fontSize: "1.2rem", fontWeight: 800, color: theme.dark, marginBottom: 16 }}>
          Transaction History
        </h3>

        {loadingHistory ? (
          <div style={{ textAlign: "center", padding: 40 }}>
            <Loader size={32} className="animate-spin" color={theme.primary} />
          </div>
        ) : transactions.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40, background: "#fff", borderRadius: 16, border: `1px solid ${theme.border}` }}>
            <p style={{ color: theme.mid }}>No transactions yet.</p>
          </div>
        ) : (
          <>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {transactions.map((tx, i) => {
                let isCredit;
                // ★ 1. Explicitly handle known credit types
                if (tx.type === 'deposit' || tx.type === 'refund') {
                  isCredit = true;
                // ★ 2. Explicitly handle known debit types (order_payment added here)
                } else if (tx.type === 'invoice_payment' || tx.type === 'order_payment') {
                  isCredit = false;
                } else {
                  // 3. For manual_adjustment (or unknown), infer from balance change.
                  // The list is sorted newest to oldest. The NEXT item (i+1) is the previous transaction.
                  const prevTx = transactions[i + 1];
                  const prevBalance = prevTx ? Number(prevTx.balance_after || 0) : 0;
                  const currentBalance = Number(tx.balance_after || 0);
                  
                  // If the balance went UP from the previous transaction, it's a Credit. 
                  // If it went DOWN, it's a Debit.
                  isCredit = currentBalance > prevBalance;
                }

                return <TransactionTile key={tx.id || i} tx={tx} theme={theme} isCredit={isCredit} />
              })}
            </div>

            {hasMore && (
              <div style={{ textAlign: "center", marginTop: 24 }}>
                <button
                  onClick={() => fetchHistory(page + 1, true)}
                  disabled={loadingMore}
                  style={{
                    padding: "10px 28px",
                    background: "#fff",
                    color: theme.primary,
                    border: `1px solid ${theme.border}`,
                    borderRadius: 12,
                    fontWeight: 700,
                    cursor: loadingMore ? "not-allowed" : "pointer"
                  }}
                >
                  {loadingMore ? <Loader size={16} className="animate-spin" /> : "Load More"}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {showAddMoneyModal && (
        <AddMoneyModal
          theme={theme}
          onClose={() => setShowAddMoneyModal(false)}
          onConfirm={handleAddMoney}
        />
      )}
    </div>
  );
}

// ── Transaction Tile Component ──
function TransactionTile({ tx, theme, isCredit }) {
  const amount = Number(tx.amount || 0);
  const balanceAfter = Number(tx.balance_after || 0);

  const getLabel = (type) => {
    switch (type) {
      case "deposit": return "Added to Wallet";
      case "invoice_payment": return "Invoice Payment";
      // ★ NEW: label for wallet-paid orders
      case "order_payment": return "Order Payment";
      case "refund": return "Refund";
      case "manual_adjustment": return "Manual Adjustment";
      default: return type || "Transaction";
    }
  };

  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      gap: 16,
      background: "#fff",
      padding: 16,
      borderRadius: 16,
      border: `1px solid ${theme.border}`
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: "50%",
        display: "flex", alignItems: "center", justifyContent: "center",
        background: isCredit ? `${theme.success}20` : `${theme.error}20`
      }}>
        {isCredit ? 
          <ArrowDownCircle size={20} color={theme.success} /> : 
          <ArrowUpCircle size={20} color={theme.error} />
        }
      </div>
      
      <div style={{ flex: 1 }}>
        <p style={{ margin: 0, fontWeight: 700, color: theme.dark }}>{getLabel(tx.type)}</p>
        <p style={{ margin: 0, fontSize: "0.8rem", color: theme.mid }}>{fmtDate(tx.created_at)}</p>
      </div>

      <div style={{ textAlign: "right" }}>
        <p style={{ 
          margin: 0, 
          fontWeight: 800, 
          color: isCredit ? theme.success : theme.error 
        }}>
          {/* ★ Explicitly add the + or - sign based on whether it's a credit or debit */}
          {isCredit ? "+" : "-"}{fmtMoney(amount)}
        </p>
        <p style={{ margin: 0, fontSize: "0.75rem", color: theme.mid }}>
          Bal: {fmtMoney(balanceAfter)}
        </p>
      </div>
    </div>
  );
}

// ── Add Money Modal Component ──
function AddMoneyModal({ theme, onClose, onConfirm }) {
  const [amount, setAmount] = useState("");

  const handleProceed = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast.error("Please enter a valid amount.");
      return;
    }
    onConfirm(numAmount);
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, padding: 24
    }}>
      <div style={{
        background: "#fff", borderRadius: 20, padding: 32,
        width: "100%", maxWidth: 420, position: "relative"
      }}>
        <button onClick={onClose} style={{
          position: "absolute", top: 16, right: 16, background: "none", border: "none", cursor: "pointer"
        }}>
          <X size={20} color={theme.mid} />
        </button>

        <h3 style={{ margin: "0 0 24px", fontSize: "1.2rem", fontWeight: 800, color: theme.dark }}>
          Add Money
        </h3>

        <label style={{ fontSize: "0.85rem", fontWeight: 600, color: theme.mid, display: "block", marginBottom: 8 }}>
          Amount (₹)
        </label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter amount"
          style={{
            width: "100%", padding: 16, fontSize: "1.2rem",
            border: `1.5px solid ${theme.border}`, borderRadius: 12,
            outline: "none", boxSizing: "border-box", marginBottom: 16
          }}
        />

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
          {[100, 200, 500, 1000].map(v => (
            <button
              key={v}
              onClick={() => setAmount(String(v))}
              style={{
                padding: "8px 16px", background: theme.bg,
                border: `1px solid ${theme.border}`, borderRadius: 20,
                color: theme.dark, fontWeight: 600, cursor: "pointer"
              }}
            >
              ₹{v}
            </button>
          ))}
        </div>

        <button
          onClick={handleProceed}
          style={{
            width: "100%", padding: 16, background: theme.primary,
            color: "#fff", border: "none", borderRadius: 12,
            fontWeight: 800, fontSize: "1rem", cursor: "pointer"
          }}
        >
          Proceed to Pay
        </button>
      </div>
    </div>
  );
}