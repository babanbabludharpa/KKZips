import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";

const STORAGE_KEY = "kutumb_subscription_basket"; // ⚠️ if your current context uses a different key, keep it so existing baskets survive
const SubscriptionContext = createContext(null);

const read = () => {
  try {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
};
const keyOf = (it) => String(it?.variant_id ?? it?.id);

export function SubscriptionProvider({ children }) {
  const [items, setItems] = useState(read);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch {}
  }, [items]);

  const add = useCallback((item, qty = 1) => {
    if (!item) return;
    const k = keyOf(item);
    setItems(prev => {
      const hit = prev.find(it => keyOf(it) === k);
      if (hit) return prev.map(it => keyOf(it) === k
        ? { ...it, quantity: Math.min(99, (Number(it.quantity) || 1) + (Number(qty) || 1)) } : it);
      return [...prev, {
        variant_id: item.variant_id ?? item.id,
        id: item.id ?? item.variant_id,
        name: item.name || "Product",
        price: Number(item.price || 0),
        unit: item.unit || "",
        image_url: item.image_url || null,
        attributes: item.attributes || [],
        quantity: Number(qty) || 1,
      }];
    });
  }, []);

  const updateQty = useCallback((id, delta) => {          // +1 / -1
    setItems(prev => prev.map(it => keyOf(it) === String(id)
      ? { ...it, quantity: Math.max(1, Math.min(99, (Number(it.quantity) || 1) + delta)) } : it));
  }, []);

  const remove = useCallback((id) => {                      // 🗑 per-item delete
    setItems(prev => prev.filter(it => keyOf(it) !== String(id)));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const has = useCallback((id) => items.some(it => keyOf(it) === String(id)), [items]);
  const total = useMemo(() => items.reduce((s, it) => s + Number(it.price || 0) * Number(it.quantity || 1), 0), [items]);

  return (
    <SubscriptionContext.Provider value={{ items, add, remove, updateQty, setQty: undefined, clear, has, total, count: items.length }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export const useSubscription = () => useContext(SubscriptionContext);