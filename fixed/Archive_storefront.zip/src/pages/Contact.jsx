import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin, Phone, Mail, Clock, Send, MessageSquare, CheckCircle2, AlertCircle,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";

// Defaults are only used if the backend has NO data for the Contact page at all.
const defaultContactData = {
  hero: { badge: "We're Here to Help", title: "Get in Touch with Us", subtitle: "Have a question about your daily subscriptions, local vendor partnership, or a recent order? Drop us a message!" },
  info: { address: "Royal Arcade, Near Shankar Maharaj Math, Pune Satara Road, Dhankawadi, Pune", phone: "+91 93734 23799", email: "sanjay_khinvsara@yahoo.co.in", hours: "Monday - Sunday \n7:00 AM - 9:00 PM" },
  whatsapp: { title: "Need instant help?", desc: "Skip the form and chat directly with our WhatsApp support team for quick resolution.", btn_text: "Chat on WhatsApp", link: "https://wa.me/919373423799" }
};

export default function Contact() {
  const { sections } = useTenant();
  const data = sections.find((s) => s.page === "contact")?.data || {};
  
  // If backend has no data saved for Contact, use defaults. Otherwise, strictly use backend data.
  const finalData = Object.keys(data).length === 0 ? defaultContactData : data;

  const hero = finalData.hero;
  const info = finalData.info;
  const whatsapp = finalData.whatsapp;

  const theme = {
  primary: "#FF7132",
  primaryHover: "#EA580C",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
  success: "#22C55E",
  error: "#EF4444",
};

  const contactInfo = info ? [
    { icon: MapPin, title: "Office Address", desc: info.address },
    { icon: Phone, title: "Call Us", desc: info.phone },
    { icon: Mail, title: "Email Us", desc: info.email },
    { icon: Clock, title: "Support Hours", desc: info.hours },
  ] : [];

  const [form, setForm] = useState({ name: "", email: "", subject: "General Inquiry", message: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (errors[name]) setErrors((p) => ({ ...p, [name]: "" }));
  };

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!form.email) errs.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Invalid email address";
    if (!form.message.trim()) errs.message = "Message cannot be empty";
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setSuccess(true);
    setForm({ name: "", email: "", subject: "General Inquiry", message: "" });
    setTimeout(() => setSuccess(false), 4000);
  };

  const inputClass = (fieldName) => `form-input ${errors[fieldName] ? "has-error" : ""}`;

  return (
    <div style={{ minHeight: "100vh", background: "var(--color-bg)", paddingBottom: "80px" }}>
      {/* ── Hero Header ──────────────────────────────────────── */}
      {hero && (
        <section className="contact-hero">
          <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)", backgroundSize: "30px 30px", pointerEvents: "none" }} />
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} style={{ position: "relative", zIndex: 1 }}>
            <span className="hero-badge">{hero.badge}</span>
            <h1 className="hero-title">{hero.title}</h1>
            <p className="hero-desc">{hero.subtitle}</p>
          </motion.div>
        </section>
      )}

      {/* ── Main Content ─────────────────────────────────────── */}
      <div style={{ maxWidth: "1200px", margin: "-40px auto 0", padding: "0 10px", position: "relative", zIndex: 10 }}>
        <div className="contact-grid">
          {/* Left: Contact Form */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="contact-card">
            <div style={{ marginBottom: "32px" }}>
              <h2 style={{ fontSize: "1.8rem", fontWeight: "900", color: "var(--color-dark)", marginBottom: "8px", letterSpacing: "-0.02em" }}>Send a Message</h2>
              <p style={{ color: "var(--color-mid)", fontSize: "1rem" }}>We typically reply within a few hours.</p>
            </div>

            <form onSubmit={handleSubmit} noValidate>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "20px" }} className="form-row">
                <div>
                  <label className="form-label">Full Name</label>
                  <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="John Doe" className={inputClass("name")} />
                  {errors.name && (<span className="error-text"><AlertCircle size={14} /> {errors.name}</span>)}
                </div>
                <div>
                  <label className="form-label">Email Address</label>
                  <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="john@example.com" className={inputClass("email")} />
                  {errors.email && (<span className="error-text"><AlertCircle size={14} /> {errors.email}</span>)}
                </div>
              </div>

              <div style={{ marginBottom: "20px" }}>
                <label className="form-label">How can we help?</label>
                <select name="subject" value={form.subject} onChange={handleChange} className="form-input" style={{ cursor: "pointer" }}>
                  <option>General Inquiry</option>
                  <option>Subscription & Delivery Issue</option>
                  <option>Vendor Partnership</option>
                  <option>Refunds & Returns</option>
                </select>
              </div>

              <div style={{ marginBottom: "32px" }}>
                <label className="form-label">Your Message</label>
                <textarea name="message" value={form.message} onChange={handleChange} placeholder="Tell us more about your query..." className={inputClass("message")} style={{ minHeight: "140px", resize: "vertical" }} />
                {errors.message && (<span className="error-text"><AlertCircle size={14} /> {errors.message}</span>)}
              </div>

              <button type="submit" disabled={loading} className="submit-btn">
                {loading ? (
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} style={{ display: "flex" }}><RefreshSpinner /></motion.div>
                ) : (<><Send size={18} /> Send Message</>)}
              </button>

              <AnimatePresence>
                {success && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} style={{ marginTop: "24px", padding: "16px", background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: "12px", display: "flex", alignItems: "center", gap: "12px", color: "#15803D" }}>
                    <CheckCircle2 size={20} color="#22C55E" />
                    <span style={{ fontWeight: "700", fontSize: "0.95rem" }}>Message sent successfully! We'll be in touch soon.</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </form>
          </motion.div>

          {/* Right: Info Cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
            {contactInfo.map((info, i) => {
              const Icon = info.icon;
              return (
                <motion.div key={i} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }} className="info-card">
                  <div style={{ width: "52px", height: "52px", borderRadius: "14px", background: "rgba(249, 115, 22, 0.1)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <Icon size={24} color="var(--color-primary)" />
                  </div>
                  <div>
                    <h3 style={{ fontSize: "1.15rem", fontWeight: "800", color: "var(--color-dark)", marginBottom: "6px" }}>{info.title}</h3>
                    <p style={{ color: "var(--color-mid)", fontSize: "0.95rem", lineHeight: "1.6", whiteSpace: "pre-line", margin: 0 }}>{info.desc}</p>
                  </div>
                </motion.div>
              );
            })}

            {/* WhatsApp CTA Card */}
            {whatsapp && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.7 }} className="whatsapp-card">
                <MessageSquare size={32} color="#fff" style={{ marginBottom: "16px" }} />
                <h3 style={{ fontSize: "1.4rem", fontWeight: "900", marginBottom: "8px", letterSpacing: "-0.02em" }}>{whatsapp.title}</h3>
                <p style={{ color: "rgba(255,255,255,0.9)", fontSize: "1rem", marginBottom: "24px", lineHeight: "1.6" }}>{whatsapp.desc}</p>
                <a href={whatsapp.link} target="_blank" rel="noreferrer" className="whatsapp-btn">{whatsapp.btn_text}</a>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .contact-hero {    background: linear-gradient(
      135deg,
      var(--color-primary, ${theme.primary}),
      var(--color-secondary, ${theme.primaryHover})
    ); padding: clamp(80px, 12vw, 100px) 24px 80px; text-align: center; position: relative; overflow: hidden; }
        .hero-badge { display: inline-block; background: rgba(18, 89, 255, 0.21); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 6px 16px; border-radius: 100px; font-size: 0.85rem; font-weight: 700; margin-bottom: 20px; letter-spacing: 0.05em; text-transform: uppercase; }
        .hero-title { color: #fff; font-size: clamp(2.4rem, 5vw, 3.6rem); font-weight: 900; margin-bottom: 16px; letter-spacing: -0.03em; line-height: 1.1; }
        .hero-desc { color: rgba(255,255,255,0.9); font-size: clamp(1rem, 2vw, 1.15rem); max-width: 600px; margin: 0 auto; line-height: 1.5; }
        .contact-grid { display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; }
        .contact-card { background: #fff; border-radius: 24px; padding: clamp(24px, 5vw, 40px); box-shadow: 0 10px 40px rgba(0,0,0,0.04); border: 1px solid var(--color-border); }
        .form-label { display: block; font-size: 0.9rem; font-weight: 700; color: var(--color-dark); margin-bottom: 8px; }
        .form-input { width: 100%; padding: 16px; border-radius: 12px; border: 1.5px solid var(--color-border); background: #F8FAFC; font-size: 1rem; color: var(--color-dark); outline: none; transition: all 0.2s ease; font-family: inherit; }
        .form-input:focus { border-color: var(--color-primary); background: #fff; box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1); }
        .form-input.has-error { border-color: #EF4444; background: #FEF2F2; }
        .error-text { display: flex; align-items: center; gap: 4px; color: #EF4444; font-size: 0.85rem; margin-top: 6px; font-weight: 600; }
        .submit-btn { width: 100%; padding: 18px; border-radius: 14px; background: var(--color-primary); color: #fff; border: none; font-size: 1.05rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.2s ease; box-shadow: 0 4px 14px rgba(249, 115, 22, 0.25); }
        .submit-btn:hover:not(:disabled) { background: var(--color-dark); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(249, 115, 22, 0.35); }
        .submit-btn:disabled { opacity: 0.7; cursor: not-allowed; }
        .info-card { background: #fff; padding: 28px; border-radius: 24px; display: flex; gap: 20px; align-items: flex-start; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border: 1px solid var(--color-border); transition: all 0.3s ease; }
        .info-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,0.08); border-color: #CBD5E1; }
        .whatsapp-card { background: linear-gradient(135deg, var(--color-primary), #DC2626); padding: 36px 32px; border-radius: 24px; color: #fff; margin-top: auto; display: flex; flex-direction: column; align-items: flex-start; box-shadow: 0 12px 32px rgba(249, 115, 22, 0.25); }
        .whatsapp-btn { background: #fff; color: #DC2626; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: 800; font-size: 1rem; transition: transform 0.2s; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .whatsapp-btn:hover { transform: translateY(-2px); }
        @media (max-width: 992px) { .contact-grid { grid-template-columns: 1fr; } }
        @media (max-width: 640px) { .contact-hero { padding: 80px 24px 60px; } .form-row { grid-template-columns: 1fr !important; gap: 16px !important; } }
      `}</style>
    </div>
  );
}

const RefreshSpinner = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
  </svg>
);