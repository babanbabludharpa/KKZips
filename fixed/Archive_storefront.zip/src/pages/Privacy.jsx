import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Lock, Database, Eye, ShieldCheck, CreditCard, UserCog, ChevronRight,
  AlertCircle, FileText, Users, Bell, MapPin, Mail, Phone, Shield, Cookie, Gift,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

// ═══════════════════════════════════════════════════════════════
// Icon map — maps string names (stored in admin) to Lucide components.
// Admin picks from this list via a dropdown; the customer portal
// resolves the string back to the actual icon component here.
// ═══════════════════════════════════════════════════════════════
const ICON_MAP = {
  Database,
  Eye,
  CreditCard,
  ShieldCheck,
  UserCog,
  AlertCircle,
  Lock,
  FileText,
  Users,
  Bell,
  MapPin,
  Mail,
  Phone,
  Shield,
  Cookie,
  Gift,
};

// Default data — used when the tenant hasn't configured their privacy page yet.
// Mirrors the original hardcoded content so nothing breaks on first load.
const DEFAULT_PRIVACY_DATA = {
  hero: {
    badge: "Privacy Policy",
    title: "How We Protect Your Data",
    subtitle: "Your trust is important to us. Learn how we collect, use, and safeguard your personal and payment information.",
    last_updated: "June 15, 2026",
  },
  intro: {
    title: "Commitment to Privacy",
    content: "We are committed to maintaining the confidentiality and security of your personal information. This Privacy Policy explains our practices regarding the collection, use, and disclosure of data when you use our daily subscription platform and related services.",
  },
  sections: [
    { id: "collection", icon: "Database", title: "1. Information We Collect", content: "To provide our daily subscription and delivery services, we collect the following types of information:\n\n• Personal Details: Full name, phone number, and email address when you register.\n• Delivery Data: Exact delivery address, GPS location (if permitted), and delivery instructions.\n• Usage Data: Order history, subscription preferences, and interaction with our app." },
    { id: "usage", icon: "Eye", title: "2. How We Use Your Data", content: "We use the information we collect primarily to ensure seamless morning deliveries and reliable service:\n\n• To process and deliver your daily subscriptions (milk, tiffin, etc.).\n• To manage your Wallet and process automated deductions.\n• To send important updates like delivery status, low wallet balance alerts, and OTPs for secure login.\n• To improve our app's performance and customer support." },
    { id: "security", icon: "CreditCard", title: "3. Data Security & Payments", content: "Your financial security is our top priority.\n\n• We do not store your Credit/Debit card numbers or UPI PINs on our servers.\n• All online payments and wallet recharges are securely processed through our PCI-DSS compliant payment gateway partner.\n• Your personal data is encrypted and stored on secure cloud servers with restricted access." },
    { id: "sharing", icon: "ShieldCheck", title: "4. Information Sharing", content: "We do not sell your personal data to third-party marketers. However, we may share specific information under the following circumstances:\n\n• Delivery Partners: We share your name, phone number, and address with our local delivery executives solely for the purpose of fulfilling your order.\n• Legal Compliance: If required by law, court order, or government regulation to protect the rights and safety of our users." },
    { id: "rights", icon: "UserCog", title: "5. Your Privacy Rights", content: "You have full control over your personal data:\n\n• Access & Update: You can update your phone number, addresses, and subscription details anytime from your Profile Dashboard.\n• Account Deletion: You can request account deletion by contacting our support team. Upon deletion, any remaining wallet balance will be refunded, and your personal data will be erased from our active database (subject to legal retention requirements)." },
    { id: "changes", icon: "AlertCircle", title: "6. Policy Updates", content: 'We may update this Privacy Policy periodically to reflect changes in our practices or legal requirements. The updated version will be indicated by an updated "Last Modified" date at the top of this page. We encourage you to review this policy regularly.' },
  ],
  contact: {
    heading: "Have Privacy Concerns?",
    text: "If you have any questions about how we handle your data, please reach out.",
    email: "privacy@example.com",
    btn_text: "Email Privacy Officer",
  },
};

const theme = {
  primary: "#F97316",
  primaryHover: "#EA580C",
  dark: "#002868",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
};

export default function Privacy() {
  const { sections, isLoading } = useTenant();

  // Read privacy data from tenant layout; fall back to defaults if empty.
  const data = sections.find((s) => s.page === "privacy")?.data || {};
  const finalData = Object.keys(data).length === 0 ? DEFAULT_PRIVACY_DATA : data;

  const hero = finalData.hero || {};
  const intro = finalData.intro || {};
  const privacySections = Array.isArray(finalData.sections) ? finalData.sections : [];
  const contact = finalData.contact || {};

  const [activeSection, setActiveSection] = useState(
    privacySections[0]?.id || "collection"
  );

  // Reset active section when data changes
  useEffect(() => {
    if (privacySections.length > 0 && !privacySections.find((s) => s.id === activeSection)) {
      setActiveSection(privacySections[0].id);
    }
  }, [privacySections]);

  // Smooth scroll to section
  const scrollToSection = (id) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -120;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  // Update active section based on scroll position
  useEffect(() => {
    if (privacySections.length === 0) return;
    const handleScroll = () => {
      const sectionEls = privacySections
        .map((s) => document.getElementById(s.id))
        .filter(Boolean);
      const scrollPosition = window.scrollY + 150;
      for (let i = sectionEls.length - 1; i >= 0; i--) {
        if (sectionEls[i].offsetTop <= scrollPosition) {
          setActiveSection(privacySections[i].id);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [privacySections]);

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
            <div style={{ color: theme.mid }}>Loading…</div>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />

      <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: "80px" }}>
        {/* ── Hero Header ──────────────────────────────────────── */}
        <section className="privacy-hero">
          <div
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
              backgroundSize: "30px 30px",
              pointerEvents: "none",
            }}
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            style={{ position: "relative", zIndex: 1, maxWidth: "800px", margin: "0 auto" }}
          >
            <div className="hero-badge">
              <Lock size={16} /> {hero.badge || "Privacy Policy"}
            </div>
            <h1 className="hero-title">{hero.title || "Privacy Policy"}</h1>
            <p className="hero-desc">
              {hero.subtitle || ""}
              {hero.last_updated && (
                <>
                  <br />
                  <span style={{ color: theme.primary, fontWeight: "700", display: "inline-block", marginTop: "12px" }}>
                    Last Updated: {hero.last_updated}
                  </span>
                </>
              )}
            </p>
          </motion.div>
        </section>

        {/* ── Main Content Layout ──────────────────────────────── */}
        <div style={{ maxWidth: "1200px", margin: "-40px auto 0", padding: "0 8px", position: "relative", zIndex: 10 }}>
          <div className="layout-grid">
            {/* LEFT: Sticky Navigation (Table of Contents) */}
            {privacySections.length > 0 && (
              <div className="sidebar-wrapper">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="toc-card"
                >
                  <h3 style={{ fontSize: "1.1rem", fontWeight: "900", color: theme.dark, marginBottom: "20px", letterSpacing: "-0.01em" }}>
                    Privacy Topics
                  </h3>
                  <nav style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                    {privacySections.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className={`toc-btn ${activeSection === item.id ? "active" : ""}`}
                      >
                        <span className="toc-text">{item.title}</span>
                        {activeSection === item.id && <ChevronRight size={16} />}
                      </button>
                    ))}
                  </nav>
                </motion.div>
              </div>
            )}

            {/* RIGHT: Privacy Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="content-card"
            >
              {/* Intro Section */}
              {(intro.title || intro.content) && (
                <div style={{ marginBottom: "40px", paddingBottom: "24px", borderBottom: `1px solid ${theme.border}` }}>
                  {intro.title && (
                    <h2 style={{ fontSize: "1.6rem", fontWeight: "900", color: theme.dark, marginBottom: "16px", letterSpacing: "-0.02em" }}>
                      {intro.title}
                    </h2>
                  )}
                  {intro.content && (
                    <p style={{ color: theme.mid, fontSize: "1.05rem", lineHeight: "1.7", margin: 0 }}>
                      {intro.content}
                    </p>
                  )}
                </div>
              )}

              {/* Privacy Sections */}
              {privacySections.length > 0 && (
                <div style={{ display: "flex", flexDirection: "column", gap: "48px" }}>
                  {privacySections.map((section) => {
                    const Icon = ICON_MAP[section.icon] || FileText;
                    return (
                      <section key={section.id} id={section.id} style={{ scrollMarginTop: "120px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "20px" }}>
                          <div className="section-icon">
                            <Icon size={24} color={theme.primary} />
                          </div>
                          <h2 style={{ fontSize: "1.4rem", fontWeight: "800", color: theme.dark, margin: 0 }}>
                            {section.title}
                          </h2>
                        </div>
                        <div className="section-body">
                          {(section.content || "").split("\n").map((paragraph, idx) => (
                            <p key={idx}>{paragraph}</p>
                          ))}
                        </div>
                      </section>
                    );
                  })}
                </div>
              )}

              {/* Empty state */}
              {privacySections.length === 0 && !intro.title && !intro.content && (
                <div style={{ textAlign: "center", padding: "60px 20px", color: theme.mid }}>
                  <FileText size={48} style={{ marginBottom: 16, opacity: 0.4 }} />
                  <p>This privacy page has no content yet.</p>
                </div>
              )}

              {/* Footer Contact Prompt */}
              {(contact.heading || contact.text || contact.email) && (
                <div style={{ marginTop: "60px", padding: "32px", background: "#F8FAFC", borderRadius: "20px", border: `1px solid ${theme.border}`, textAlign: "center" }}>
                  {contact.heading && (
                    <h3 style={{ fontSize: "1.25rem", fontWeight: "800", color: theme.dark, marginBottom: "12px" }}>
                      {contact.heading}
                    </h3>
                  )}
                  {contact.text && (
                    <p style={{ color: theme.mid, fontSize: "1rem", marginBottom: "20px" }}>
                      {contact.text}
                    </p>
                  )}
                  {contact.email && (
                    <a
                      href={`mailto:${contact.email}`}
                      style={{
                        display: "inline-block",
                        background: theme.primary,
                        color: "#fff",
                        padding: "12px 28px",
                        borderRadius: "12px",
                        textDecoration: "none",
                        fontWeight: "700",
                        transition: "all 0.2s",
                        boxShadow: "0 4px 14px rgba(249, 115, 22, 0.25)",
                      }}
                    >
                      {contact.btn_text || "Email Us"}
                    </a>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        </div>

        <style>{`
          .privacy-hero {
            background: linear-gradient(135deg, #001440 0%, #001440 100%);
            padding: 80px 24px 64px;
            text-align: center;
            position: relative;
            overflow: hidden;
          }
          .hero-badge {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(18, 89, 255, 0.21); border: 1px solid rgba(255,255,255,0.15);
            color: #fff; padding: 8px 18px; border-radius: 100px;
            font-size: 0.85rem; font-weight: 700; margin-bottom: 24px;
            letter-spacing: 0.05em; text-transform: uppercase;
          }
          .hero-title {
            color: #fff; font-size: clamp(2.4rem, 5vw, 3.8rem);
            font-weight: 900; margin-bottom: 16px; letter-spacing: -0.03em;
            line-height: 1.1;
          }
          .hero-desc {
            color: rgba(255,255,255,0.9); font-size: clamp(1rem, 2vw, 1.15rem);
            max-width: 600px; margin: 0 auto; line-height: 1.5;
          }
          .layout-grid {
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 40px;
            align-items: start;
          }
          .sidebar-wrapper { position: sticky; top: 100px; }
          .toc-card {
            background: #fff; border-radius: 24px; padding: 32px 24px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border};
          }
          .toc-btn {
            width: 100%; display: flex; align-items: center; justify-content: space-between;
            padding: 14px 16px; background: transparent; border: none; border-radius: 12px;
            color: ${theme.mid}; font-size: 0.95rem; font-weight: 600; cursor: pointer;
            text-align: left; transition: all 0.2s; font-family: inherit;
          }
          .toc-btn:hover { background: #F8FAFC; color: ${theme.dark}; }
          .toc-btn.active { background: #FFF7ED; color: ${theme.primary}; font-weight: 800; }
          .content-card {
            background: #fff; border-radius: 24px; padding: clamp(32px, 5vw, 56px);
            box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid ${theme.border};
          }
          .section-icon {
            width: 48px; height: 48px; border-radius: 14px; background: #FFF7ED;
            display: flex; align-items: center; justify-content: center; flex-shrink: 0;
          }
          .section-body p {
            color: ${theme.mid}; font-size: 1.05rem; line-height: 1.75;
            margin-bottom: 12px;
          }
          .section-body p:last-child { margin-bottom: 0; }
          @media (max-width: 992px) {
            .layout-grid { grid-template-columns: 1fr; }
            .sidebar-wrapper { position: static; }
            .toc-card { padding: 24px; }
            .toc-card nav {
              flex-direction: row; overflow-x: auto; padding-bottom: 10px;
              scrollbar-width: none;
            }
            .toc-card nav::-webkit-scrollbar { display: none; }
            .toc-btn { white-space: nowrap; width: auto; padding: 12px 20px; }
          }
          @media (max-width: 640px) {
            .privacy-hero { padding: 80px 24px 60px; }
            .content-card { padding: 32px 20px; }
            .section-icon { width: 40px; height: 40px; border-radius: 12px; }
            .section-icon svg { width: 20px; height: 20px; }
          }
        `}</style>
      </div>

      <Footer />
    </>
  );
}
