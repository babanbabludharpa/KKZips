import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Target, Eye, Award, Lightbulb, HeartHandshake, BadgeCheck, ArrowRight,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import YouTubeVideo from "../components/YouTubeVideo";
import SectionRenderer from "../components/SectionRenderer";

const whyUsIcons = [Award, Lightbulb, HeartHandshake, BadgeCheck];

const SectionLabel = ({ children }) => (
  <span style={{ display: "inline-block", padding: "6px 16px", borderRadius: "100px", background: "rgba(249, 115, 22, 0.1)", color: "var(--color-primary)", border: `1px solid rgba(249, 115, 22, 0.2)`, fontSize: "15px", fontWeight: "800", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "16px" }}>
    {children}
  </span>
);

// Default fallback image — used only if admin hasn't set story.image_url
let defaultStoryImage = "";
try {
  defaultStoryImage = new URL("../assets/happy_client.jpg", import.meta.url).href;
} catch (e) {
  defaultStoryImage = "";
}

// Helper: if URL is relative (starts with /), prefix with backend base URL
function resolveImageUrl(url) {
  if (!url) return null;
  if (url.startsWith("http") || url.startsWith("data:") || url.startsWith("blob:")) return url;
  const backendUrl = import.meta.env.VITE_API_URL || import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";
  return backendUrl + (url.startsWith("/") ? url : "/" + url);
}

// Built-in section keys — these have custom JSX rendering below.
// Everything else (custom-* keys) is passed to SectionRenderer.
const BUILTIN_SECTIONS = ['hero', 'story', 'mission', 'whyUs', 'cta', 'youtube_videos'];

const defaultAboutData = {
  hero: { badge: "Our Story", title: "About Shop Hub", subtitle: "We are dedicated to providing fresh products, seamless daily subscriptions, and an exceptional doorstep delivery experience." },
  story: {
    label: "Our Story", title: "Making Daily Essentials Simple & Reliable",
    desc1: "Welcome to our platform. We are committed to providing high-quality daily essentials and an excellent shopping experience to customers across the city. Our goal is to make daily routines simple, secure, and convenient by offering carefully selected products, competitive prices, and reliable morning deliveries.",
    desc2: "We believe that customer satisfaction is the foundation of a successful business. That's why we continuously work to improve our product range, service quality, and tech experience.",
    image_url: "",
    image_alt: "Happy customer",
    stats: [{ n: "5k+", l: "Happy Families" }, { n: "80+", l: "Local Vendors" }, { n: "99%", l: "On-Time Drops" }, { n: "55k+", l: "Deliveries Done" }]
  },
  mission: {
    label: "Our Purpose", title: "Our Mission & Vision",
    mission_title: "To become a trusted daily needs destination known for quality and satisfaction.",
    mission_desc: "Our mission is to provide customers with a convenient, secure, and enjoyable experience while maintaining high standards. We are committed to offering value-driven products, timely delivery, and responsive support.",
    vision_title: "To become a destination where customers discover local quality products.",
    vision_desc: "Our vision is to be the preferred subscription platform by delivering quality products, exceptional service, and a seamless digital experience. We aim to build long-term relationships through trust and transparency."
  },
  whyUs: {
    label: "Why Choose Us", title: "What sets us apart",
    subtitle: "Years of local delivery experience have taught us what households actually need from a daily service partner.",
    items: [
      { title: "Deep Experience", desc: "10+ years delivering reliable daily services across cities — we know the local logistics inside out." },
      { title: "Customer-First Thinking", desc: "We build systems around your convenience. Pause subscriptions, change quantities, and pay seamlessly." },
      { title: "Responsive Support", desc: "Dedicated communication channels and local support teams — your delivery issues get resolved fast." },
      { title: "Quality by Default", desc: "Verified vendors, strict hygiene checks, and fresh products daily — not optional extras, standard practice." }
    ]
  },
  cta: {
    label: "Get In Touch", title: "Let's simplify your life together",
    subtitle: "Whether you're looking to subscribe for daily needs or want to partner with us as a vendor, we'd love to connect.",
    btn1_text: "Partner with us", btn1_link: "/partner", btn2_text: "View Our Services", btn2_link: "/products"
  },
  youtube_videos: [],
  // ★ NEW: section_order allows admin to reorder sections + insert custom ones
  // (media_carousel, text_block, youtube_video, etc.) between built-in sections.
  section_order: ['hero', 'story', 'youtube_videos', 'mission', 'whyUs', 'cta'],
  section_visibility: {},
};

export default function About() {
  const { sections: tenantSections } = useTenant();
  const data = (Array.isArray(tenantSections) ? tenantSections : []).find((s) => s.page === "about")?.data || {};

  const theme = {
  primary: "#FF7132",
  primaryHover: "#EA580C",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
  success: "#22C55E",
  error: "#EF4444",
};

  const finalData = {
    ...defaultAboutData,
    ...data,
    hero:    { ...defaultAboutData.hero,    ...(data.hero || {}) },
    story:   { ...defaultAboutData.story,   ...(data.story || {}) },
    mission: { ...defaultAboutData.mission, ...(data.mission || {}) },
    whyUs:   { ...defaultAboutData.whyUs,   ...(data.whyUs || {}) },
    cta:     { ...defaultAboutData.cta,     ...(data.cta || {}) },
  };
  const hero = finalData.hero;
  const story = finalData.story;
  const mission = finalData.mission;
  const whyUs = finalData.whyUs;
  const cta = finalData.cta;
  const youtubeVideos = Array.isArray(finalData.youtube_videos) ? finalData.youtube_videos : [];

  const storyImageSrc = resolveImageUrl(story?.image_url) || defaultStoryImage;
  const storyImageAlt = story?.image_alt || "Happy customer";

  // ★ Read section_order — admin can reorder + insert custom sections
  const sectionOrder = finalData.section_order || defaultAboutData.section_order;
  const sectionVisibility = finalData.section_visibility || {};

  // Build the list of sections to render, respecting visibility + order
  const sectionsToRender = sectionOrder
    .filter(key => sectionVisibility[key] !== false)
    .map(key => {
      // Custom sections (admin-added: media_carousel, text_block, etc.)
      if (key.startsWith("custom-")) {
        const customData = finalData[key] || {};
        return { id: key, type: customData.type || "text_block", data: customData, visible: true, isCustom: true };
      }
      // Built-in sections
      return { id: key, type: key, data: finalData[key] || {}, visible: true, isCustom: false };
    });

  // ── Render functions for each built-in section ──────────────────
  const renderHero = () => hero && (
    <section className="about-hero" key="hero">
      <div className="hero-pattern" aria-hidden="true" />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{ position: "relative", zIndex: 1, maxWidth: "680px", margin: "0 auto" }}
      >
        <div className="hero-badge">
          <span style={{ color: "rgba(255,255,255,0.9)", fontSize: "15px", fontWeight: "700" }}>{hero.badge}</span>
        </div>
        <h1 className="hero-title">{hero.title}</h1>
        <p className="hero-desc">{hero.subtitle}</p>
      </motion.div>
    </section>
  );

  const renderStory = () => story && (
    <section className="section-padding" style={{ background: "#fff" }} key="story">
      <div className="about-story-grid">
        <motion.div
          initial={{ opacity: 0, x: -32 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="story-image-wrapper"
        >
          <img
            loading="lazy"
            src={storyImageSrc}
            alt={storyImageAlt}
            style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "24px", boxShadow: "0 20px 40px rgba(0,0,0,0.08)" }}
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="story-floating-card"
          >
            <div style={{ fontSize: "2rem", fontWeight: "900", color: "var(--color-primary)", letterSpacing: "-0.03em" }}>10+</div>
            <div style={{ fontSize: "0.85rem", color: "var(--color-mid)", fontWeight: "600" }}>Years of excellence</div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 32 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <SectionLabel>{story.label}</SectionLabel>
          <h2 className="section-title"><span style={{ color: "var(--color-primary)" }}>{story.title}</span></h2>
          <p className="section-desc">{story.desc1}</p>
          <p className="section-desc" style={{ marginBottom: "32px" }}>{story.desc2}</p>

          <div className="stats-grid">
            {(story.stats || []).map(({ n, l }) => (
              <div key={l} className="stat-box">
                <div className="stat-number">{n}</div>
                <div className="stat-label">{l}</div>
              </div>
            ))}
          </div>

          <Link to="/contact" className="btn-primary">Work with us <ArrowRight size={18} /></Link>
        </motion.div>
      </div>
    </section>
  );

  const renderYoutubeVideos = () => youtubeVideos.length > 0 && (
    <section className="section-padding" style={{ background: "#fff" }} key="youtube_videos">
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {youtubeVideos.map((video, i) => {
          const layout = video.layout || {};
          const isHalf = layout.width === "half";
          const isContained = layout.width === "contained";
          const wrapperStyle = isHalf ? {
            display: "inline-block", width: "calc(50% - 12px)", marginRight: 12,
            marginBottom: 24, verticalAlign: "top", boxSizing: "border-box", padding: "0 12px",
          } : {
            display: "block", width: "100%", boxSizing: "border-box",
            padding: isContained ? "0 24px" : "0", marginBottom: 24,
            textAlign: layout.content_align === "center" ? "center" : (layout.content_align === "right" ? "right" : "left"),
          };
          const innerStyle = isHalf ? { width: "100%", textAlign: layout.text_align || "left" } : {
            display: "inline-block", width: "100%", maxWidth: isContained ? "800px" : "100%",
            textAlign: layout.text_align || "left",
          };
          return (
            <div key={i} style={wrapperStyle}>
              <div style={innerStyle}>
                <YouTubeVideo data={video} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );

  const renderMission = () => mission && (
    <section className="section-padding" style={{ background: "var(--color-bg)" }} key="mission">
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          style={{ textAlign: "center", marginBottom: "56px" }}
        >
          <SectionLabel>{mission.label}</SectionLabel>
          <h2 className="section-title" style={{ textAlign: "center" }}>{mission.title}</h2>
        </motion.div>

        <div className="mission-grid">
          {[
            { icon: Target, label: "Mission", color: "var(--color-secondary)", bg: "rgba(0,20, 64, 0.1)", title: mission.mission_title, desc: mission.mission_desc },
            { icon: Eye, label: "Vision", color: "var(--color-secondary)", bg: "rgba(0, 20, 64, 0.1)", title: mission.vision_title, desc: mission.vision_desc },
          ].map(({ icon: Icon, label, color, bg, title, desc }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="mission-card"
            >
              <div className="mission-icon" style={{ background: bg }}><Icon size={26} color={color} /></div>
              <div style={{ fontSize: "21px", fontWeight: "800", letterSpacing: "0.5px", textTransform: "uppercase", color, marginBottom: "12px" }}>{label}</div>
              <h3 style={{ fontSize: "1.25rem", fontWeight: "800", color: "var(--color-dark)", marginBottom: "14px", lineHeight: "1.4" }}>{title}</h3>
              <p style={{ color: "#323232", lineHeight: "1.7", fontSize: "0.95rem" }}>{desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );

  const renderWhyUs = () => whyUs && (
    <section className="why-us-hero" key="whyUs">
      <div className="hero-pattern" />
      <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          style={{ textAlign: "center", marginBottom: "56px" }}
        >
          <span style={{ display: "inline-block", padding: "6px 16px", borderRadius: "100px", background: "rgba(255,255,255,0.15)", color: "#fff", fontSize: "0.8rem", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "16px" }}>{whyUs.label}</span>
          <h2 className="section-title" style={{ color: "#fff", textAlign: "center" }}>{whyUs.title}</h2>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: "1.05rem", maxWidth: "500px", margin: "0 auto" }}>{whyUs.subtitle}</p>
        </motion.div>

        <div className="why-us-grid">
          {(whyUs.items || []).map(({ title, desc }, i) => {
            const Icon = whyUsIcons[i % whyUsIcons.length];
            return (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="why-us-card"
              >
                <div className="why-us-icon" style={{ background: "var(--color-primary)" }}><Icon size={24} color="#fff" /></div>
                <h3 style={{ fontSize: "1.1rem", fontWeight: "800", color: "#fff", marginBottom: "10px" }}>{title}</h3>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.95rem", lineHeight: "1.65" }}>{desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );

  const renderCta = () => cta && (
    <section className="section-padding" style={{ background: "#fff" }} key="cta">
      <div style={{ maxWidth: "700px", margin: "0 auto", textAlign: "center" }}>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <SectionLabel>{cta.label}</SectionLabel>
          <h2 className="section-title" style={{ textAlign: "center", marginBottom: "16px" }}>{cta.title}</h2>
          <p style={{ color: "var(--color-mid)", fontSize: "1.05rem", marginBottom: "32px", lineHeight: "1.7" }}>{cta.subtitle}</p>
          <div className="cta-btn-group">
            <Link to={cta.btn1_link} className="btn-primary">{cta.btn1_text} <ArrowRight size={18} /></Link>
            <Link to={cta.btn2_link} className="btn-secondary">{cta.btn2_text}</Link>
          </div>
        </motion.div>
      </div>
    </section>
  );

  // Map built-in section keys to their render functions
  const builtinRenderers = {
    hero: renderHero,
    story: renderStory,
    youtube_videos: renderYoutubeVideos,
    mission: renderMission,
    whyUs: renderWhyUs,
    cta: renderCta,
  };

  return (
    <div style={{ background: "var(--color-bg)" }}>
      {/* ★ Dynamic section rendering — iterates section_order.
          Built-in sections (hero, story, mission, etc.) use custom JSX.
          Custom sections (media_carousel, text_block, etc.) use SectionRenderer. */}
      {sectionsToRender.map(section => {
        // Built-in section → use custom render function
        if (!section.isCustom && builtinRenderers[section.type]) {
          return builtinRenderers[section.type]();
        }
        // Custom section → pass to SectionRenderer (handles media_carousel,
        // youtube_video, text_block, image_block, spacer, divider, html_block)
        if (section.isCustom) {
          return <SectionRenderer key={section.id} section={section} />;
        }
        return null;
      })}

<style>{`
  .section-padding { padding: 96px 24px; }
  .section-title { font-size: clamp(1.8rem, 4vw, 2.6rem); font-weight: 900; color: var(--color-dark); letter-spacing: -0.02em; line-height: 1.2; margin-bottom: 20px; }
  .section-desc { color: var(--color-mid); line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
  .btn-primary { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 28px; border-radius: 12px; background: var(--color-primary); color: #fff; text-decoration: none; font-weight: 700; font-size: 1rem; transition: all 0.2s; border: 2px solid var(--color-primary); }
  .btn-primary:hover { background: var(--color-dark); border-color: var(--color-dark); transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
  .btn-secondary { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 28px; border-radius: 12px; background: transparent; color: var(--color-dark); text-decoration: none; font-weight: 700; font-size: 1rem; transition: all 0.2s; border: 2px solid var(--color-border); }
  .btn-secondary:hover { border-color: var(--color-primary); color: var(--color-primary); }
  .about-hero { background: linear-gradient(135deg, var(--color-primary, ${theme.primary}), var(--color-secondary, ${theme.primaryHover})); padding: clamp(60px, 12vw, 75px) 24px; position: relative; overflow: hidden; text-align: center; }
  .why-us-hero { background: var(--color-secondary, #1E293B); padding: 96px 24px; position: relative; overflow: hidden; }
  .hero-pattern { position: absolute; inset: 0; background-image: radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px); background-size: 28px 28px; pointer-events: none; }
  .hero-badge { display: inline-flex; align-items: center; background: rgba(255,255,255,0.15); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.15); border-radius: 100px; padding: 8px 20px; margin-bottom: 24px; }
  .hero-title { font-size: clamp(2.4rem, 6vw, 4rem); font-weight: 900; color: #fff; letter-spacing: -0.03em; margin-bottom: 20px; line-height: 1.1; }
  .hero-desc { color: rgb(255 255 255 / 90%); font-size: clamp(1.05rem, 2vw, 1.05rem); line-height: 1.5; max-width: 600px; margin: 0 auto; }
  .about-story-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; max-width: 1200px; margin: 0 auto; }
  .story-image-wrapper { position: relative; height: 460px; width: 100%; border-radius: 24px; }
  .story-floating-card { position: absolute; bottom: -24px; right: -24px; background: #fff; border-radius: 16px; padding: 24px 32px; box-shadow: 0 12px 40px rgba(0,0,0,0.08); border: 1px solid var(--color-border); min-width: 180px; }
  .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 32px; }
  .stat-box { padding: 20px; border-radius: 16px; background: var(--color-bg); border: 1px solid var(--color-border); }
  .stat-number { font-size: 1.8rem; font-weight: 900; color: var(--color-primary); letter-spacing: -0.02em; }
  .stat-label { font-size: 0.9rem; font-weight: 600; color: var(--color-mid); margin-top: 4px; }
  .mission-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 32px; }
  .mission-card { background: #fff; border-radius: 24px; padding: 40px; border: 1px solid var(--color-border); box-shadow: 0 4px 20px rgba(0,0,0,0.03); transition: transform 0.2s; }
  .mission-card:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(0,0,0,0.06); }
  .mission-icon { width: 64px; height: 64px; border-radius: 16px; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; }
  .why-us-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 24px; }
  .why-us-card { background: rgba(255,255,255,0.05); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 32px; transition: all 0.3s; }
  .why-us-card:hover { background: var(--color-primary); transform: translateY(-4px); }
  .why-us-icon { width: 56px; height: 56px; border-radius: 14px; background: rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; margin-bottom: 24px; }
  .cta-btn-group { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
  @media (max-width: 640px) { .stats-grid { grid-template-columns: 1fr; } }
  @media (max-width: 1024px) { .about-story-grid { gap: 40px; } .story-image-wrapper { height: 400px; } }
  @media (max-width: 768px) { .section-padding { padding: 64px 24px; } .about-hero { padding: 80px 24px; } .about-story-grid { grid-template-columns: 1fr; gap: 48px; } .story-image-wrapper { height: 350px; margin-bottom: 32px; } .story-floating-card { bottom: -16px; right: 16px; padding: 16px 24px; } .stats-grid { grid-template-columns: 1fr 1fr; } .cta-btn-group { flex-direction: column; width: 100%; } .cta-btn-group a { width: 100%; } }
  @media (max-width: 480px) { .section-padding { padding: 48px 16px; } .story-image-wrapper { height: 280px; } .stats-grid { grid-template-columns: 1fr; } }
`}</style>
    </div>
  );
}
