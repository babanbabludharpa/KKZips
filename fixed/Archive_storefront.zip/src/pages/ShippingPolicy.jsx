import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Truck, MapPin, Clock, Wallet, Package, BellRing, Info, ArrowRight,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";

/* ─────────────────────────────────────────────────────────────
   SHIPPING POLICY
   • Editable per-tenant via webbuilder (page key: shipping_policy)
   • Prefilled defaults — admin data overrides, never wipes
   • Icons stored as KEYS ("truck", "pin"...) — the ICONS map
     renders the lucide component, so the builder edits plain JSON
   ───────────────────────────────────────────────────────────── */

const ICONS = {
  truck: Truck, pin: MapPin, clock: Clock,
  wallet: Wallet, box: Package, bell: BellRing,
};

const DEFAULTS = {
  label: "Our Policy",
  title: "Shipping Policy",
  subtitle: "How your orders and subscriptions reach your doorstep — slots, charges and everything in between.",
  hero_icon: "truck",
  sections: [
    { icon: "pin", title: "Where We Deliver", desc: "We deliver across our active service cities and pincodes. Enter your address at checkout to confirm deliverability instantly." },
    { icon: "clock", title: "Order Cutoff Times", desc: "Place your order by 8:00 PM for next-morning delivery. Orders placed after cutoff roll over to the next available slot." },
    { icon: "truck", title: "Delivery Slots", desc: "Choose a morning or evening slot that fits your routine. Subscription deliveries follow the schedule you set — daily, alternate days or custom days." },
    { icon: "wallet", title: "Delivery Charges", desc: "A flat delivery fee applies on small carts; delivery is free above the minimum order value shown at checkout. No hidden handling fees." },
    { icon: "box", title: "Careful Packaging", desc: "Temperature-safe packaging for dairy and fresh items, tamper-proof sealing, and hygiene checks before every dispatch." },
    { icon: "bell", title: "Live Updates & Reattempts", desc: "Get notified at dispatch and on delivery. Missed a delivery? We reattempt or reschedule as per your instructions at no extra cost." },
  ],
  note: "Delivery timelines may vary during extreme weather or unforeseen disruptions — we'll always keep you informed.",
  cta: { title: "Questions about your delivery?", subtitle: "Track orders in real time from the Orders page, or reach out to support.", btn_text: "Contact Support", btn_link: "/contact" },
};

export default function ShippingPolicy() {
  const { sections: tenantSections } = useTenant();
  const data = (Array.isArray(tenantSections) ? tenantSections : []).find((s) => s.page === "shipping_policy")?.data || {};

  // Admin data wins; defaults prefill everything untouched
  const d = {
    ...DEFAULTS,
    ...data,
    sections: Array.isArray(data.sections) && data.sections.length ? data.sections : DEFAULTS.sections,
    cta: { ...DEFAULTS.cta, ...(data.cta || {}) },
  };

  const HeroIcon = ICONS[d.hero_icon] || Truck;
  const list = (d.sections || []).filter(Boolean);

  return (
    <div style={{ background: "var(--color-bg)" }}>
      {/* HERO */}
      <section className="sp-hero">
        <div className="sp-pattern" aria-hidden="true" />
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} style={{ position: "relative", zIndex: 1, maxWidth: 680, margin: "0 auto" }}>
          <div className="sp-hero-icon"><HeroIcon size={26} color="#fff" /></div>
          <div>
            <span className="sp-label">{d.label}</span>
            <h1 className="sp-title">{d.title}</h1>
            <p className="sp-subtitle">{d.subtitle}</p>
          </div>
        </motion.div>
      </section>

      {/* CARDS */}
      <section className="sp-section">
        <div className="sp-grid">
          {list.map((s, i) => {
            const Icon = ICONS[s.icon] || Truck;
            return (
              <motion.div key={i} className="sp-card" initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 3) * 0.08 }}>
                <div className="sp-card-icon"><Icon size={22} color="#fff" /></div>
                <h3 className="sp-card-title">{s.title}</h3>
                <p className="sp-card-desc">{s.desc}</p>
              </motion.div>
            );
          })}
        </div>

        {d.note && (
          <div className="sp-note">
            <Info size={18} style={{ flexShrink: 0, marginTop: 2 }} />
            <span>{d.note}</span>
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="sp-cta">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="sp-cta-title">{d.cta.title}</h2>
          <p className="sp-cta-subtitle">{d.cta.subtitle}</p>
          <Link to={d.cta.btn_link || "/contact"} className="sp-btn">{d.cta.btn_text} <ArrowRight size={18} /></Link>
        </motion.div>
      </section>

      <style>{`
        .sp-hero { background: linear-gradient(135deg, var(--color-primary, #FF7132), var(--color-secondary, #EA580C)); padding: clamp(64px, 10vw, 96px) 24px; position: relative; overflow: hidden; text-align: center; }
        .sp-pattern { position: absolute; inset: 0; background-image: radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px); background-size: 28px 28px; pointer-events: none; }
        .sp-hero-icon { width: 64px; height: 64px; border-radius: 18px; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.2); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px; backdrop-filter: blur(10px); }
        .sp-label { display: inline-block; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 6px 16px; border-radius: 100px; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 16px; }
        .sp-title { font-size: clamp(2.2rem, 5vw, 3.4rem); font-weight: 900; color: #fff; letter-spacing: -0.03em; margin: 0 0 16px; line-height: 1.15; }
        .sp-subtitle { color: rgba(255,255,255,0.92); font-size: clamp(1rem, 2vw, 1.15rem); line-height: 1.6; max-width: 560px; margin: 0 auto; }
        .sp-section { padding: 72px 24px; background: #fff; }
        .sp-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; max-width: 1200px; margin: 0 auto; }
        .sp-card { background: var(--color-bg, #F8FAFF); border: 1px solid var(--color-border, #E2E8F0); border-radius: 20px; padding: 28px; transition: transform 0.2s, box-shadow 0.2s; }
        .sp-card:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(0,0,0,0.06); }
        .sp-card-icon { width: 48px; height: 48px; border-radius: 12px; background: var(--color-primary, #FF7132); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }
        .sp-card-title { font-size: 1.05rem; font-weight: 800; color: var(--color-dark, #1E293B); margin: 0 0 8px; }
        .sp-card-desc { color: var(--color-mid, #64748B); font-size: 0.92rem; line-height: 1.65; margin: 0; }
        .sp-note { display: flex; align-items: flex-start; gap: 10px; max-width: 1200px; margin: 32px auto 0; padding: 16px 20px; border-radius: 14px; background: var(--color-bg, #F8FAFF); border: 1px dashed var(--color-border, #E2E8F0); color: var(--color-mid, #64748B); font-size: 0.9rem; line-height: 1.6; }
        .sp-cta { padding: 72px 24px; background: #fff; text-align: center; }
        .sp-cta-title { font-size: clamp(1.6rem, 3.5vw, 2.2rem); font-weight: 900; color: var(--color-dark, #1E293B); margin: 0 0 12px; }
        .sp-cta-subtitle { color: var(--color-mid, #64748B); font-size: 1.02rem; margin: 0 0 28px; }
        .sp-btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 28px; border-radius: 12px; background: var(--color-primary, #FF7132); color: #fff; text-decoration: none; font-weight: 700; font-size: 1rem; transition: all 0.2s; border: 2px solid var(--color-primary, #FF7132); }
        .sp-btn:hover { background: var(--color-dark, #1E293B); border-color: var(--color-dark, #1E293B); transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
        @media (max-width: 640px) { .sp-section { padding: 48px 16px; } .sp-cta { padding: 48px 16px; } .sp-card { padding: 22px; } }
      `}</style>
    </div>
  );
}