import { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, ShoppingCart, Heart, SlidersHorizontal, X, ChevronDown, Check, AlertCircle, Eye, LayoutGrid, List as ListIcon, MapPin, Navigation, Truck, User, Play, ChevronLeft, ChevronRight,
} from "lucide-react";
import { useTenant } from "../contexts/TenantProvider";
import { useCart } from "./CartContext";
import customerApi from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import CartDrawer from "../components/CartDrawer";

// ─────────────────────────────────────────────────────────────────────────
// Products.jsx — with delivery zone detection + stock validation
// ─────────────────────────────────────────────────────────────────────────

const DEFAULT_PRODUCT_DISPLAY = {
  default_view: "grid", products_per_row: 4,
  show_mrp: true, show_discount: true, show_rating: true, show_stock: true, show_unit: true,
  default_sort: "name_asc", card_style: "standard", quick_view: true,
  show_add_to_cart: true, show_wishlist: true, image_aspect: "square",
  out_of_stock_behavior: "dim",
};

const SORT_OPTIONS = [
  { value: "name_asc", label: "Name: A to Z" },
  { value: "name_desc", label: "Name: Z to A" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
];

const PER_PAGE = 12;

// ★ First image of a variant — new media arrays with legacy single-image fallback.
const firstImage = (v) => {
  if (!v) return null;
  if (v.image_url) return v.image_url;
  const u = (v.images || [])[0];
  return typeof u === "string" ? u : (u?.url || u?.image_url || null);
};

// ─────────────────────────────────────────────────────────────────────────
// ★ NEW — media gallery helpers (auto-rotating images + videos)
// ─────────────────────────────────────────────────────────────────────────

// All media of a variant in display order: images → videos. The legacy
// single image is used as the first slide when no gallery images exist.
const collectCardMedia = (v) => {
  if (!v) return [];
  const asUrl = (u) => (typeof u === "string" ? u : u?.url || u?.image_url || null);
  const out = [];
  const seen = new Set();
  const push = (type, u) => {
    const url = asUrl(u);
    if (url && !seen.has(url)) { seen.add(url); out.push({ type, url }); }
  };
  if (!(v.images || []).length && v.image_url) push("image", v.image_url);
  (v.images || []).forEach((u) => push("image", u));
  (v.videos || []).forEach((u) => push("video", u));
  return out;
};

// Auto-advance the gallery every ~3.5s. Pauses while the shopper hovers
// the image, and resets to the first slide whenever the variant changes.
const MEDIA_ROTATE_MS = 3500;
function useAutoRotate(media) {
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => { setIdx(0); }, [media]);
  useEffect(() => {
    if (paused || !media || media.length < 2) return undefined;
    const t = setInterval(() => setIdx((i) => (i + 1) % media.length), MEDIA_ROTATE_MS);
    return () => clearInterval(t);
  }, [media, paused]);
  return [idx, setIdx, paused, setPaused];
}

// One carousel slide — image, or a muted looping video that plays only
// while it is the active slide (key remount restarts/stops playback).
function MediaSlide({ item, alt = "" }) {
  if (!item) return null;
  if (item.type === "video") {
    return (
      <video
        key={item.url}
        src={item.url}
        muted
        playsInline
        autoPlay
        loop
        preload="metadata"
        style={{ maxWidth: "100%", maxHeight: "100%", width: "100%", height: "100%", objectFit: "contain" }}
      />
    );
  }
  return (
    <img
      key={item.url}
      src={item.url}
      alt={alt}
      loading="lazy"
      style={{ maxWidth: "100%", maxHeight: "100%", width: "auto", height: "auto", objectFit: "contain" }}
    />
  );
}

// Small "▶ VIDEO" tag shown on video slides.
function VideoBadge() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "rgba(15,23,42,0.85)", color: "#fff", padding: "2px 8px", borderRadius: 6, fontSize: "0.62rem", fontWeight: 800, letterSpacing: "0.04em" }}>
      <Play size={9} fill="#fff" /> VIDEO
    </span>
  );
}

// Dot pager under the card image — click a dot to jump to that slide.
function MediaDots({ media, idx, onPick }) {
  if (!media || media.length < 2) return null;
  return (
    <div style={{ position: "absolute", bottom: 6, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 4, zIndex: 2 }}>
      {media.map((m, i) => (
        <button
          key={i}
          onClick={(e) => { e.stopPropagation(); onPick(i); }}
          title={m.type === "video" ? "Video" : `Image ${i + 1}`}
          style={{ width: i === idx ? 16 : 6, height: 6, borderRadius: 3, border: "none", padding: 0, background: i === idx ? "#fff" : "rgba(255,255,255,0.75)", boxShadow: "0 1px 3px rgba(0,0,0,0.4)", cursor: "pointer", transition: "width 0.25s" }}
        />
      ))}
    </div>
  );
}

function extractLatLng(addr) {
  if (!addr) return null;
  const latCandidates = ["latitude", "lat", "Latitude"];
  const lngCandidates = ["longitude", "lng", "long", "Longitude"];
  let lat = null, lng = null;
  for (const f of latCandidates) {
    if (addr[f] !== undefined && addr[f] !== null && addr[f] !== "") {
      lat = parseFloat(addr[f]);
      if (!isNaN(lat)) break;
      lat = null;
    }
  }
  for (const f of lngCandidates) {
    if (addr[f] !== undefined && addr[f] !== null && addr[f] !== "") {
      lng = parseFloat(addr[f]);
      if (!isNaN(lng)) break;
      lng = null;
    }
  }
  if (lat === null || lng === null) return null;
  return { lat, lng };
}

export default function Products() {
  const { addToCart, cartCount, cartTotal, isCartOpen, setIsCartOpen } = useCart();
  const { isAuthenticated } = useCustomerAuth();
  const navigate = useNavigate();
  const { theme, productDisplayConfig } = useTenant() || {};
  const cfg = { ...DEFAULT_PRODUCT_DISPLAY, ...(productDisplayConfig || {}) };
  const t = {
    primary: theme?.primary_color || "#666666",
    dark: theme?.secondary_color || "#1E293B",
    mid: "#64748B", bg: "#F8FAFF", border: "#E2E8F0",
    radius: theme?.border_radius ?? 12,
  };

  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [customerLatLng, setCustomerLatLng] = useState(null);
  const [locationSource, setLocationSource] = useState(null);
  const [locationWarning, setLocationWarning] = useState(null);
  const [isDeliverable, setIsDeliverable] = useState(true);
  const [deliveryCheckDone, setDeliveryCheckDone] = useState(false);
  const [showLocationModal, setShowLocationModal] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState(cfg.default_sort || "name_asc");
  const [view, setView] = useState(cfg.default_view || "grid");
  const [wishlist, setWishlist] = useState(() => {
    try { return JSON.parse(localStorage.getItem("wishlist") || "[]"); } catch { return []; }
  });

  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const [toast, setToast] = useState(null);
  const [quickViewProduct, setQuickViewProduct] = useState(null);
    // ★ NEW — attribute filters: { Size: ['L','XL'], Color: ['Sky Blue'] }
  const [selectedAttrs, setSelectedAttrs] = useState({});

  useEffect(() => {
    if (!isAuthenticated) {
      requestBrowserLocation();
      return;
    }
    const fetchAddr = async () => {
      try {
        const res = await customerApi.get("/mobile/addresses");
        const addrs = res.data?.data || [];
        const def = addrs.find((a) => a.is_default) || addrs[0];
        const ll = extractLatLng(def);
        if (ll) {
          setCustomerLatLng(ll);
          setLocationSource("address");
          setLocationWarning(null);
        } else {
          requestBrowserLocation();
        }
      } catch (e) {
        requestBrowserLocation();
      }
    };
    fetchAddr();
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) return;
    requestBrowserLocation();
  }, [isAuthenticated]);

  const requestBrowserLocation = () => {
    if (!navigator.geolocation) {
      setLocationWarning("Your browser doesn't support geolocation. Please log in and add a default address to see stock availability.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const ll = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCustomerLatLng(ll);
        setLocationSource("geolocation");
        setLocationWarning(null);
      },
      (err) => {
        setLocationWarning(
          isAuthenticated
            ? "No default address with location found, and browser geolocation was denied. Please add a default address with your location, or allow location access."
            : "Browser geolocation was denied. Please allow location access, or log in and add a default address."
        );
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
    );
  };

  useEffect(() => {
    const timer = setTimeout(() => { setDebouncedSearch(searchQuery); setPage(1); }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
      setDeliveryCheckDone(false);
      try {
        const params = { channel: "order" };
        if (debouncedSearch) params.search = debouncedSearch;
        if (customerLatLng) {
          params.lat = customerLatLng.lat;
          params.lng = customerLatLng.lng;
        }
        const res = await customerApi.get("/mobile/products", { params });
        if (res.data?.status) {
          const list = Array.isArray(res.data.data) ? res.data.data : [];
          const processed = list.map((p) => ({
            id: p.id,
            name: p.name,
            description: p.description,
            category_id: Number(p.category_id),
            category_name: p.category_name || "General",
            variants: (p.variants || []).map((v) => ({
              id: v.id,
              sku: v.sku,
              mrp: Number(v.mrp || 0),
              selling_price: Number(v.selling_price || 0),
              final_price: Number(v.final_price || 0),
              discount_percent: Number(v.discount_percent || 0),
              has_discount: v.has_discount || false,
              unit_name: v.unit_name || "",
              unit_abbr: v.unit_abbr || "",
              image_url: firstImage(v),
              images: v.images || [],
              videos: v.videos || [],
              available_stock: v.available_stock,
              is_out_of_stock: v.is_out_of_stock || false,
              is_low_stock: v.is_low_stock || false,
              attributes: v.attributes || [],
            })),
            defaultVariant: (p.variants || [])[0] || null,
          }));

          setProducts(processed);

          if (customerLatLng && processed.length > 0) {
            const allVariants = processed.flatMap(p => p.variants || []);
            const variantsWithStockData = allVariants.filter(v =>
              v.available_stock !== null && v.available_stock !== undefined
            );
            if (allVariants.length > 0 && variantsWithStockData.length === 0) {
              setIsDeliverable(false);
            } else {
              setIsDeliverable(true);
            }
          } else {
            setIsDeliverable(true);
          }
          setDeliveryCheckDone(true);
        }
      } catch (e) {
        setError(e?.response?.data?.message || e.message || "Failed to load products");
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [debouncedSearch, customerLatLng]);

  useEffect(() => {
    const fetchCats = async () => {
      try {
        const res = await customerApi.get("/mobile/products/categories");
        if (res.data?.status) setCategories(Array.isArray(res.data.data) ? res.data.data : []);
      } catch (e) {}
    };
    fetchCats();
  }, []);
  // ★ NEW — collect attribute facets (Size / Color / Fabric / …) from all variants
  const attributeFacets = useMemo(() => {
    const map = {};
    products.forEach((p) => (p.variants || []).forEach((v) => (v.attributes || []).forEach((a) => {
      const name = a.attribute_name || "Attribute";
      if (!a.value) return;
      if (!map[name]) map[name] = new Set();
      map[name].add(a.value);
    })));
    return Object.entries(map).map(([name, values]) => ({ name, values: [...values].sort() }));
  }, [products]);

  const toggleAttrValue = (groupName, value) => {
    setSelectedAttrs((prev) => {
      const cur = prev[groupName] || [];
      const next = cur.includes(value) ? cur.filter((v) => v !== value) : [...cur, value];
      const out = { ...prev };
      if (next.length) out[groupName] = next; else delete out[groupName];
      return out;
    });
    setPage(1);
  };

  const filteredProducts = useMemo(() => {
    let list = [...products];
    if (selectedCategory) list = list.filter((p) => Number(p.category_id) === Number(selectedCategory));
    if (priceMin) list = list.filter((p) => (p.defaultVariant?.final_price || 0) >= Number(priceMin));
    if (priceMax) list = list.filter((p) => (p.defaultVariant?.final_price || 0) <= Number(priceMax));
        // ★ NEW — attribute filters (AND across groups, OR within a group)
    const activeAttrGroups = Object.entries(selectedAttrs).filter(([, vals]) => vals && vals.length > 0);
    if (activeAttrGroups.length > 0) {
      list = list.filter((p) => {
        const variantAttrs = (p.variants || []).map((v) => {
          const m = {};
          (v.attributes || []).forEach((a) => { if (a.attribute_name) m[a.attribute_name] = a.value; });
          return m;
        });
        return activeAttrGroups.every(([name, vals]) => variantAttrs.some((m) => vals.includes(m[name])));
      });
    }
    if (inStockOnly) {
      list = list.filter((p) => p.variants.some((v) => v.is_out_of_stock !== true && (v.available_stock === null || v.available_stock === undefined || v.available_stock > 0)));
    }
    if (cfg.out_of_stock_behavior === "hide") {
      list = list.filter((p) => p.variants.some((v) => v.is_out_of_stock !== true));
    }
    list.sort((a, b) => {
      const pa = a.defaultVariant?.final_price || 0;
      const pb = b.defaultVariant?.final_price || 0;
      switch (sortBy) {
        case "name_asc": return a.name.localeCompare(b.name);
        case "name_desc": return b.name.localeCompare(a.name);
        case "price_asc": return pa - pb;
        case "price_desc": return pb - pa;
        default: return 0;
      }
    });
    return list;
  }, [products, selectedCategory, priceMin, priceMax, inStockOnly, sortBy, cfg.out_of_stock_behavior, selectedAttrs]);

  const totalPages = Math.ceil(filteredProducts.length / PER_PAGE);
  const paginatedProducts = filteredProducts.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const cardBgs = [
    "linear-gradient(135deg,#DBEAFE,#EDE9FE)",
    "linear-gradient(135deg,#FEF3C7,#FDE68A)",
    "linear-gradient(135deg,#D1FAE5,#A7F3D0)",
    "linear-gradient(135deg,#EDE9FE,#DDD6FE)",
  ];

  const clearAllFilters = () => {
    setSelectedCategory(null); setPriceMin(""); setPriceMax("");
    setInStockOnly(false); setSortBy("name_asc"); setSelectedAttrs({}); setPage(1);
  };

    const hasActiveFilters = selectedCategory || priceMin || priceMax || inStockOnly || sortBy !== "name_asc" || Object.values(selectedAttrs).some((v) => v && v.length);

  const showToast = (msg, kind = "success") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 2500);
  };

  const toggleWishlist = (productId) => {
    setWishlist((prev) => {
      const next = prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId];
      localStorage.setItem("wishlist", JSON.stringify(next));
      return next;
    });
  };

  const handleAddToCart = (product, variant) => {
    if (!isDeliverable) {
      showToast("Delivery is not available at your location. Please set a deliverable location.", "error");
      return;
    }
    if (variant.is_out_of_stock === true) {
      showToast(`${product.name} is out of stock`, "error");
      return;
    }
    if (variant.available_stock !== null && variant.available_stock !== undefined && variant.available_stock <= 0) {
      showToast(`${product.name} is out of stock`, "error");
      return;
    }
    const result = addToCart({
      id: product.id, variant_id: variant.id, name: product.name,
      price: Number(variant.final_price || 0), unit: variant.unit_abbr || "",
      image_url: variant.image_url, quantity: 1,
      is_out_of_stock: variant.is_out_of_stock || false,
      available_stock: variant.available_stock ?? null,
      attributes: variant.attributes || [],   // ★ NEW — carries Size/Color/Fabric into the cart
    });
    if (result.success) showToast(`${product.name} added to cart`);
    else showToast(result.error || "Could not add to cart", "error");
  };

  const goToLogin = () => {
    setShowLocationModal(false);
    navigate("/login");
  };

  // ★ NEW — opens the product detail page
  const openProduct = (p) => navigate(`/products/${p.id}`);

  return (
    <div style={{ minHeight: "100vh", background: t.bg }}>
      {/* Hero */}
      <div
        style={{
          background: `linear-gradient(135deg, var(--color-primary, ${theme.primary}), var(--color-secondary, ${theme.primaryHover}))`,
          padding: "40px 24px 80px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
            backgroundSize: "30px 30px",
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "relative",
            zIndex: 1,
            maxWidth: 1100,
            margin: "50px auto",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            textAlign: "center",
          }}
        >
          <motion.span initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} style={{ display: "inline-block", background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "8px 20px", borderRadius: 100, fontSize: "0.85rem", fontWeight: 700, marginBottom: 16, backdropFilter: "blur(4px)" }}>
            Shop Products
          </motion.span>
          <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} style={{ color: "#fff", fontSize: "clamp(1.75rem, 4vw, 2.5rem)", fontWeight: 900, margin: "0 0 8px", textShadow: "0 4px 12px rgba(0,0,0,0.2)", letterSpacing: "-0.02em" }}>
            Browse Our Products
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} style={{ color: "rgba(255,255,255,0.95)", fontSize: "1rem", margin: 0 }}>
            Search and filter to find exactly what you need.
          </motion.p>
        </div>
      </div>

      {/* ★★ NOT DELIVERABLE BANNER ★★ */}
      {deliveryCheckDone && !isDeliverable && (
        <div style={{ background: "#FEF2F2", borderBottom: "2px solid #FECACA", padding: "16px 24px" }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: "#FEE2E2", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Truck size={20} color="#DC2626" />
            </div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <h3 style={{ margin: 0, fontSize: "0.95rem", fontWeight: 800, color: "#B91C1C" }}>
                Delivery not available at your location
              </h3>
              <p style={{ margin: "4px 0 0", fontSize: "0.82rem", color: "#991B1B" }}>
                We can't deliver to {customerLatLng ? `${customerLatLng.lat.toFixed(4)}, ${customerLatLng.lng.toFixed(4)}` : "your location"}.
                Please set a different location within our delivery zone.
              </p>
            </div>
            <button onClick={() => setShowLocationModal(true)} style={{ padding: "10px 20px", background: "#DC2626", color: "#fff", border: "none", borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
              <MapPin size={16} /> Set Different Location
            </button>
          </div>
        </div>
      )}

      {isDeliverable && customerLatLng && !locationWarning && (
        <div style={{ background: "#F0FDF4", borderBottom: "1px solid #BBF7D0", padding: "6px 24px", display: "flex", alignItems: "center", gap: 8, fontSize: "0.75rem", color: "#16A34A", flexWrap: "wrap" }}>
          <MapPin size={14} />
          <span>Showing stock for your location {locationSource === "address" ? "(saved address)" : "(browser)"}: {customerLatLng.lat.toFixed(4)}, {customerLatLng.lng.toFixed(4)}</span>
          <button onClick={() => setShowLocationModal(true)} style={{ marginLeft: "auto", padding: "2px 10px", background: "transparent", color: "#16A34A", border: "1px solid #16A34A", borderRadius: 4, cursor: "pointer", fontSize: "0.7rem", fontWeight: 600 }}>
            Change
          </button>
        </div>
      )}

      {locationWarning && (
        <div style={{ background: "#FEF3C7", borderBottom: "1px solid #FCD34D", padding: "10px 24px", display: "flex", alignItems: "center", gap: 8, fontSize: "0.85rem", color: "#92400E", flexWrap: "wrap" }}>
          <MapPin size={16} />
          <span style={{ flex: 1 }}>{locationWarning}</span>
          <button onClick={() => setShowLocationModal(true)} style={{ padding: "4px 12px", background: t.primary, color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", fontSize: "0.75rem", fontWeight: 600 }}>
            Set Location
          </button>
        </div>
      )}

      {/* Search bar with cart icon + view toggle */}
      <div style={{ background: "#fff", padding: "12px 24px", borderBottom: `1px solid ${t.border}`, position: "sticky", top: 0, zIndex: 20, boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ position: "relative", flex: 1 }}>
            <Search size={18} style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: t.mid }} />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search products by name…" style={{ width: "100%", padding: "12px 14px 12px 42px", borderRadius: 12, border: `1px solid ${t.border}`, fontSize: "0.95rem", outline: "none", backgroundColor: "#fff", boxSizing: "border-box" }} />
          </div>
          <button onClick={() => setIsCartOpen(true)} style={{ position: "relative", padding: "12px 18px", background: t.primary, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", whiteSpace: "nowrap", flexShrink: 0 }}>
            <ShoppingCart size={20} /><span className="hide-mobile">Cart</span>
            {cartCount > 0 && <span style={{ position: "absolute", top: -6, right: -6, background: "#16A34A", color: "#fff", borderRadius: "50%", minWidth: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.72rem", fontWeight: 800, border: "2px solid #fff" }}>{cartCount}</span>}
          </button>
          <div style={{ display: "flex", gap: 2, background: "#f1f5f9", padding: 4, borderRadius: 12, flexShrink: 0 }}>
            <button onClick={() => setView("grid")} title="Grid view" style={{ padding: "8px 10px", border: "none", background: view === "grid" ? t.primary : "transparent", color: view === "grid" ? "#fff" : t.mid, borderRadius: 8, cursor: "pointer", display: "flex", alignItems: "center" }}><LayoutGrid size={16} /></button>
            <button onClick={() => setView("list")} title="List view" style={{ padding: "8px 10px", border: "none", background: view === "list" ? t.primary : "transparent", color: view === "list" ? "#fff" : t.mid, borderRadius: 8, cursor: "pointer", display: "flex", alignItems: "center" }}><ListIcon size={16} /></button>
          </div>
            <select value={sortBy} onChange={(e) => { setSortBy(e.target.value); setPage(1); }} title="Sort products" style={{ padding: "10px 12px", borderRadius: 12, border: `1px solid ${t.border}`, background: "#fff", color: t.dark, fontSize: "0.85rem", fontWeight: 600, cursor: "pointer", outline: "none", flexShrink: 0, maxWidth: 180 }}>
            {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <button onClick={() => setShowFilters(!showFilters)} style={{ padding: "12px 16px", background: showFilters ? t.primary : "#fff", color: showFilters ? "#fff" : t.primary, border: `1px solid ${t.primary}`, borderRadius: 12, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: "0.9rem", whiteSpace: "nowrap" }}>
            <SlidersHorizontal size={16} /> <span className="hide-mobile">Filters</span>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "24px", display: "flex", gap: 24 }}>
        <aside className="filters-sidebar" style={{ width: 240, flexShrink: 0, background: "#fff", borderRadius: 16, padding: 20, border: `1px solid ${t.border}`, height: "fit-content", position: "sticky", top: 80 }}>
          <FilterPanel categories={categories} selectedCategory={selectedCategory} setSelectedCategory={(id) => { setSelectedCategory(id); setPage(1); }} priceMin={priceMin} setPriceMin={(v) => { setPriceMin(v); setPage(1); }} priceMax={priceMax} setPriceMax={(v) => { setPriceMax(v); setPage(1); }} inStockOnly={inStockOnly} setInStockOnly={(v) => { setInStockOnly(v); setPage(1); }} sortBy={sortBy} setSortBy={(v) => { setSortBy(v); setPage(1); }} clearAllFilters={clearAllFilters} hasActiveFilters={hasActiveFilters} theme={t} attributeFacets={attributeFacets} selectedAttrs={selectedAttrs} toggleAttrValue={toggleAttrValue} />
        </aside>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
            <p style={{ margin: 0, color: t.mid, fontSize: "0.9rem" }}>
              {loading ? "Loading…" : `${filteredProducts.length} product${filteredProducts.length !== 1 ? "s" : ""} found`}
              {debouncedSearch && <span> for "<strong>{debouncedSearch}</strong>"</span>}
            </p>
          </div>

          {loading ? (
            <div style={{ textAlign: "center", padding: "3rem", color: t.mid }}>
              <div style={{ width: 40, height: 40, border: `4px solid ${t.border}`, borderTopColor: t.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
              Loading products…
              <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            </div>
          ) : error ? (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12, padding: "1.5rem", color: "#b91c1c", textAlign: "center" }}>{error}</div>
          ) : paginatedProducts.length === 0 ? (
            <div style={{ background: "#fff", border: `1px dashed ${t.border}`, borderRadius: 14, padding: "3rem 1rem", textAlign: "center" }}>
              <div style={{ fontSize: "2.5rem", marginBottom: 16 }}>🔍</div>
              <h3 style={{ margin: "0 0 8px", color: t.dark }}>No products found</h3>
              <p style={{ color: t.mid, marginBottom: 16 }}>Try adjusting your filters or search query.</p>
              {hasActiveFilters && <button onClick={clearAllFilters} style={{ background: t.primary, color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>Clear all filters</button>}
            </div>
          ) : view === "grid" ? (
            <div style={{ display: "grid", gridTemplateColumns: `repeat(${cfg.products_per_row}, minmax(0, 1fr))`, gap: 16 }}>
              {paginatedProducts.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} cardBg={cardBgs[i % cardBgs.length]} onAddToCart={handleAddToCart} cfg={cfg} theme={t} wishlist={wishlist} toggleWishlist={toggleWishlist} onQuickView={setQuickViewProduct} isDeliverable={isDeliverable} onOpenProduct={openProduct} /> 
              ))}
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {paginatedProducts.map((product, i) => (
                <ProductListCard key={product.id} product={product} index={i} cardBg={cardBgs[i % cardBgs.length]} onAddToCart={handleAddToCart} cfg={cfg} theme={t} wishlist={wishlist} toggleWishlist={toggleWishlist} onQuickView={setQuickViewProduct} isDeliverable={isDeliverable} onOpenProduct={openProduct} />
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 8, marginTop: 32 }}>
              <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1} style={{ padding: "8px 14px", background: page === 1 ? "#F1F5F9" : "#fff", color: page === 1 ? "#94A3B8" : t.dark, border: `1px solid ${t.border}`, borderRadius: 8, cursor: page === 1 ? "not-allowed" : "pointer", fontWeight: 600, fontSize: "0.85rem" }}>Prev</button>
              {Array.from({ length: totalPages }).map((_, i) => (
                <button key={i} onClick={() => setPage(i + 1)} style={{ padding: "8px 12px", background: page === i + 1 ? t.primary : "#fff", color: page === i + 1 ? "#fff" : t.dark, border: `1px solid ${page === i + 1 ? t.primary : t.border}`, borderRadius: 8, cursor: "pointer", fontWeight: 600, fontSize: "0.85rem", minWidth: 36 }}>{i + 1}</button>
              ))}
              <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page === totalPages} style={{ padding: "8px 14px", background: page === totalPages ? "#F1F5F9" : "#fff", color: page === totalPages ? "#94A3B8" : t.dark, border: `1px solid ${t.border}`, borderRadius: 8, cursor: page === totalPages ? "not-allowed" : "pointer", fontWeight: 600, fontSize: "0.85rem" }}>Next</button>
            </div>
          )}
        </div>
      </div>

      {/* ★★ LOCATION MODAL ★★ */}
      {showLocationModal && (
        <div onClick={() => setShowLocationModal(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 16, maxWidth: 440, width: "100%", padding: 24, position: "relative" }}>
            <button onClick={() => setShowLocationModal(false)} style={{ position: "absolute", top: 12, right: 12, background: "none", border: "none", cursor: "pointer", color: t.mid }}><X size={20} /></button>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#FFF7ED", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
                <MapPin size={28} color={t.primary} />
              </div>
              <h3 style={{ fontSize: "1.15rem", fontWeight: 800, color: t.dark, margin: "0 0 4px" }}>Set your delivery location</h3>
              <p style={{ fontSize: "0.82rem", color: t.mid, margin: 0 }}>Allow location access to check delivery availability and stock, or log in and add a saved address.</p>
            </div>

            <button
              onClick={() => { setShowLocationModal(false); requestBrowserLocation(); }}
              style={{ width: "100%", padding: "12px", background: t.primary, color: "#fff", border: "none", borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 12 }}
            >
              <Navigation size={16} /> Use my current location
            </button>

            <div style={{ textAlign: "center", margin: "8px 0 12px", color: t.mid, fontSize: "0.75rem" }}>OR</div>

            {isAuthenticated ? (
              <button
                onClick={() => { setShowLocationModal(false); navigate("/addresses"); }}
                style={{ width: "100%", padding: "12px", background: "transparent", color: t.primary, border: `1px solid ${t.primary}`, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
              >
                <MapPin size={16} /> Manage saved addresses
              </button>
            ) : (
              <button
                onClick={goToLogin}
                style={{ width: "100%", padding: "12px", background: "transparent", color: t.primary, border: `1px solid ${t.primary}`, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
              >
                <User size={16} /> Login & Add Address
              </button>
            )}

            <p style={{ fontSize: "0.72rem", color: t.mid, textAlign: "center", marginTop: 12, margin: "12px 0 0", lineHeight: 1.5 }}>
              {isAuthenticated
                ? <Link to="/addresses" style={{ color: t.primary, fontWeight: 600 }}>Go to saved addresses →</Link>
                : "You'll be asked to log in first, then you can add a default address with your location."
              }
            </p>
          </motion.div>
        </div>
      )}

      {showFilters && (
        <div className="mobile-filter-drawer" style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 1000, display: "flex" }} onClick={() => setShowFilters(false)}>
          <div style={{ background: "#fff", width: "85%", maxWidth: 320, height: "100%", padding: 24, overflowY: "auto" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <h3 style={{ margin: 0, fontSize: "1.1rem", fontWeight: 800 }}>Filters</h3>
              <button onClick={() => setShowFilters(false)} style={{ background: "transparent", border: "none", cursor: "pointer" }}><X size={20} color={t.mid} /></button>
            </div>
            <FilterPanel categories={categories} selectedCategory={selectedCategory} setSelectedCategory={(id) => { setSelectedCategory(id); setPage(1); }} priceMin={priceMin} setPriceMin={(v) => { setPriceMin(v); setPage(1); }} priceMax={priceMax} setPriceMax={(v) => { setPriceMax(v); setPage(1); }} inStockOnly={inStockOnly} setInStockOnly={(v) => { setInStockOnly(v); setPage(1); }} sortBy={sortBy} setSortBy={(v) => { setSortBy(v); setPage(1); }} clearAllFilters={clearAllFilters} hasActiveFilters={hasActiveFilters} theme={t} attributeFacets={attributeFacets} selectedAttrs={selectedAttrs} toggleAttrValue={toggleAttrValue} />
          </div>
        </div>
      )}

      {toast && (
        <div style={{ position: "fixed", bottom: 90, right: 24, zIndex: 10000, background: toast.kind === "error" ? "#EF4444" : "#22C55E", color: "#fff", padding: "12px 20px", borderRadius: 10, boxShadow: "0 10px 30px rgba(0,0,0,0.3)", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: 8 }}>
          {toast.kind === "error" ? <AlertCircle size={16} /> : <Check size={16} />}
          {toast.msg}
        </div>
      )}

      {quickViewProduct && (
        <div onClick={() => setQuickViewProduct(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          {/* ★ Quick view is now a full media gallery + variant switcher */}
          <QuickViewModal
            key={quickViewProduct.id}
            product={quickViewProduct}
            theme={t}
            isDeliverable={isDeliverable}
            onAddToCart={handleAddToCart}
            onClose={() => setQuickViewProduct(null)}
          />
        </div>
      )}
      {/* ★ Floating cart */}
      {cartCount > 0 && !isCartOpen && (
        <button
          onClick={() => setIsCartOpen(true)}
          style={{
            position: "fixed", bottom: 24, right: 24, zIndex: 100,
            background: t.primary, color: "#fff", border: "none", borderRadius: 999,
            padding: "14px 24px", fontSize: "0.95rem", fontWeight: 700, cursor: "pointer",
            display: "flex", alignItems: "center", gap: 10,
            boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
          }}
        >
          <ShoppingCart size={20} />
          <span>{cartCount} item{cartCount !== 1 ? "s" : ""}</span>
          <span style={{ fontSize: "0.85rem", opacity: 0.9 }}>₹{Number(cartTotal || 0).toFixed(0)}</span>
          <span style={{ marginLeft: 4, fontSize: "0.8rem", opacity: 0.85 }}>View Cart →</span>
        </button>
      )}
      <CartDrawer />

      <style>{`
        @media (max-width: 768px) {
          .filters-sidebar { display: none !important; }
          .mobile-filter-drawer { display: flex !important; }
          .hide-mobile { display: none; }
        }
      `}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ★ QuickViewModal — the Eye-icon “glimpse”: full media gallery
// (every image + video), variant chips, live price, add to cart.
// ═══════════════════════════════════════════════════════════════════════
function QuickViewModal({ product, theme, isDeliverable, onAddToCart, onClose }) {
  const variants = product.variants || [];
  const [variantIdx, setVariantIdx] = useState(0);
  const selectedVariant = variants[variantIdx] || product.defaultVariant || {};
  const media = useMemo(() => collectCardMedia(selectedVariant), [selectedVariant]);
  const [mediaIdx, setMediaIdx] = useState(0);
  useEffect(() => { setMediaIdx(0); }, [media]);

  const prev = () => setMediaIdx((i) => (media.length ? (i - 1 + media.length) % media.length : 0));
  const next = () => setMediaIdx((i) => (media.length ? (i + 1) % media.length : 0));
  const current = media[mediaIdx];

  const isOutOfStock = !isDeliverable || selectedVariant.is_out_of_stock === true ||
    (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined && selectedVariant.available_stock <= 0);

  const arrowStyle = (side) => ({
    position: "absolute", top: "50%", transform: "translateY(-50%)",
    [side]: 6, width: 26, height: 26, borderRadius: "50%", border: "none",
    background: "rgba(255,255,255,0.92)", color: theme.dark,
    display: "flex", alignItems: "center", justifyContent: "center",
    cursor: "pointer", boxShadow: "0 1px 4px rgba(0,0,0,0.25)", zIndex: 3,
  });

  return (
    <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onClick={(e) => e.stopPropagation()}
      style={{ background: "#fff", borderRadius: 16, maxWidth: 640, width: "100%", padding: 24, position: "relative", maxHeight: "90vh", overflowY: "auto" }}>
      <button onClick={onClose} style={{ position: "absolute", top: 12, right: 12, background: "none", border: "none", cursor: "pointer", color: theme.mid, zIndex: 5 }}><X size={20} /></button>

      <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
        {/* ── Left: media gallery ── */}
        <div style={{ width: 240, maxWidth: "100%" }}>
          <div style={{ width: "100%", aspectRatio: "1 / 1", borderRadius: 12, overflow: "hidden", background: "#f1f5f9", position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {current ? (
              current.type === "video" ? (
                <video key={current.url} src={current.url} controls muted playsInline preload="metadata"
                  style={{ width: "100%", height: "100%", objectFit: "contain", background: "#000" }} />
              ) : (
                <img key={current.url} src={current.url} alt={product.name} style={{ maxWidth: "100%", maxHeight: "100%", width: "auto", height: "auto", objectFit: "contain" }} />
              )
            ) : (
              <div style={{ fontSize: 48 }}>📦</div>
            )}

            {media.length > 1 && (
              <>
                <button onClick={(e) => { e.stopPropagation(); prev(); }} style={arrowStyle("left")} title="Previous"><ChevronLeft size={14} /></button>
                <button onClick={(e) => { e.stopPropagation(); next(); }} style={arrowStyle("right")} title="Next"><ChevronRight size={14} /></button>
                <span style={{ position: "absolute", top: 8, left: 8, background: "rgba(15,23,42,0.75)", color: "#fff", fontSize: "0.65rem", fontWeight: 800, padding: "2px 8px", borderRadius: 6, zIndex: 3 }}>
                  {mediaIdx + 1} / {media.length}
                </span>
              </>
            )}
          </div>

          {/* Thumbnails — every image + video of the selected variant */}
          {media.length > 1 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
              {media.map((m, i) => (
                <button key={i} onClick={() => setMediaIdx(i)}
                  title={m.type === "video" ? "Video" : `Image ${i + 1}`}
                  style={{ width: 44, height: 44, padding: 0, borderRadius: 8, overflow: "hidden", border: `2px solid ${i === mediaIdx ? theme.primary : theme.border}`, cursor: "pointer", background: m.type === "video" ? "#0F172A" : "#F1F5F9", position: "relative", flexShrink: 0 }}>
                  {m.type === "video" ? (
                    <>
                      <video src={m.url} muted preload="metadata" playsInline style={{ width: "100%", height: "100%", objectFit: "cover", pointerEvents: "none" }} />
                      <span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.25)" }}><Play size={12} fill="#fff" color="#fff" /></span>
                    </>
                  ) : (
                    <img src={m.url} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Right: info ── */}
        <div style={{ flex: 1, minWidth: 220 }}>
          <h3 style={{ fontSize: "1.25rem", fontWeight: 800, color: theme.dark, marginBottom: 8 }}>{product.name}</h3>
          <p style={{ fontSize: "0.8rem", color: theme.primary, fontWeight: 700, textTransform: "uppercase", marginBottom: 8 }}>{product.category_name}</p>

          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <span style={{ fontSize: "1.5rem", fontWeight: 800, color: theme.primary }}>₹{Number(selectedVariant.final_price || 0).toFixed(0)}</span>
            {selectedVariant.has_discount && selectedVariant.mrp > selectedVariant.final_price && (
              <span style={{ textDecoration: "line-through", color: "#94a3b8", fontSize: "1rem" }}>₹{Number(selectedVariant.mrp || 0).toFixed(0)}</span>
            )}
            {selectedVariant.unit_abbr && <span style={{ fontSize: "0.8rem", color: theme.mid }}>/ {selectedVariant.unit_abbr}</span>}
          </div>

          {/* Variant chips — switch to browse each variant's media */}
          {variants.length > 1 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
              {variants.map((v, i) => {
                const active = i === variantIdx;
                const label = (v.attributes || []).map((a) => a.value).join(" · ") || v.unit_abbr || `Variant ${i + 1}`;
                return (
                  <button key={v.id || i} onClick={() => setVariantIdx(i)}
                    style={{ padding: "5px 12px", borderRadius: 999, border: `1px solid ${active ? theme.primary : theme.border}`, background: active ? theme.primary : "#fff", color: active ? "#fff" : theme.dark, fontSize: "0.75rem", fontWeight: 700, cursor: "pointer" }}>
                    {label}
                  </button>
                );
              })}
            </div>
          )}

          {product.description && <p style={{ fontSize: "0.85rem", color: theme.mid, marginBottom: 16, lineHeight: 1.5 }}>{product.description}</p>}

          <button onClick={() => { onAddToCart(product, selectedVariant); onClose(); }} disabled={!isDeliverable || isOutOfStock}
            style={{ background: (!isDeliverable || isOutOfStock) ? "#E2E8F0" : theme.primary, color: (!isDeliverable || isOutOfStock) ? "#94A3B8" : "#fff", border: "none", borderRadius: 12, padding: "10px 20px", fontWeight: 700, cursor: (!isDeliverable || isOutOfStock) ? "not-allowed" : "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}>
            <ShoppingCart size={16} /> {!isDeliverable ? "Not Deliverable" : isOutOfStock ? "Out of Stock" : "Add to Cart"}
          </button>

          <Link to={`/products/${product.id}`} onClick={onClose}
            style={{ display: "inline-flex", alignItems: "center", gap: 6, marginTop: 12, marginLeft: 12, color: theme.primary, fontWeight: 700, fontSize: "0.9rem", textDecoration: "none" }}>
            View Full Details →
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ProductCard (GRID view) — with delivery zone awareness + ★ click-to-detail
// ═══════════════════════════════════════════════════════════════════════
function ProductCard({ product, index, cardBg, onAddToCart, cfg, theme, wishlist, toggleWishlist, onQuickView, isDeliverable, onOpenProduct }) {
  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [showVariants, setShowVariants] = useState(false);
  const variants = product.variants || [];
  const selectedVariant = variants[selectedVariantIdx] || variants[0] || {};

  // ★ NEW — auto-rotating media (images + videos) of the selected variant
  const media = useMemo(() => collectCardMedia(selectedVariant), [selectedVariant]);
  const [mediaIdx, setMediaIdx, , setMediaPaused] = useAutoRotate(media);

  const isOutOfStock = !isDeliverable || selectedVariant.is_out_of_stock === true ||
    (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined && selectedVariant.available_stock <= 0);
  const isLowStock = isDeliverable && !isOutOfStock &&
    selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined &&
    selectedVariant.available_stock > 0 && selectedVariant.available_stock <= 5;
  const stockLabel = !isDeliverable ? "Not deliverable"
    : isOutOfStock ? "Out of stock"
    : isLowStock ? `Only ${selectedVariant.available_stock} left`
    : (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined) ? "In stock"
    : null;
  const hasMultipleVariants = variants.length > 1;
  const isWishlisted = wishlist.includes(product.id);
  const isDim = isOutOfStock && (cfg.out_of_stock_behavior === "dim" || !isDeliverable);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.03 }}
      whileHover={{ y: isOutOfStock ? 0 : -8 }}
      onClick={() => onOpenProduct && onOpenProduct(product)}
      style={{ background: "#fff", borderRadius: 16, overflow: "hidden", border: `1px solid ${theme.border}`, display: "flex", flexDirection: "column", opacity: isDim ? 0.55 : 1, position: "relative", cursor: "pointer" }}
    >
      {/* Image — ★ auto-rotating gallery (pauses on hover; dots jump slides) */}
      <div
        onMouseEnter={() => setMediaPaused(true)}
        onMouseLeave={() => setMediaPaused(false)}
        style={{ aspectRatio: "1 / 1", maxHeight: 280, background: cardBg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, position: "relative", padding: 8, boxSizing: "border-box" }}
      >
        {media.length > 0 ? <MediaSlide item={media[mediaIdx]} alt={product.name} /> : "📦"}
        {media[mediaIdx]?.type === "video" && (
          <span style={{ position: "absolute", bottom: 8, left: 8 }}><VideoBadge /></span>
        )}
        <MediaDots media={media} idx={mediaIdx} onPick={setMediaIdx} />
        {cfg.show_discount && !isOutOfStock && selectedVariant.has_discount && selectedVariant.discount_percent > 0 && (
          <span style={{ position: "absolute", top: 8, left: 8, background: "#16A34A", color: "#fff", padding: "2px 8px", borderRadius: 6, fontSize: "0.7rem", fontWeight: 700 }}>{selectedVariant.discount_percent}% OFF</span>
        )}
        {isOutOfStock && (
          <span style={{ position: "absolute", top: 8, left: 8, background: "#FEE2E2", color: "#B91C1C", padding: "2px 8px", borderRadius: 6, fontSize: "0.7rem", fontWeight: 700 }}>
            {!isDeliverable ? "NOT DELIVERABLE" : "OUT OF STOCK"}
          </span>
        )}
        {isLowStock && (
          <span style={{ position: "absolute", top: 8, left: 8, background: "#FEF3C7", color: "#92400E", padding: "2px 8px", borderRadius: 6, fontSize: "0.7rem", fontWeight: 700 }}>ONLY {selectedVariant.available_stock} LEFT</span>
        )}
        {cfg.show_wishlist && (
          <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }} style={{ position: "absolute", top: 8, right: 8, background: "#fff", border: "none", borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>
            <Heart size={14} fill={isWishlisted ? "#ef4444" : "none"} color={isWishlisted ? "#ef4444" : theme.mid} />
          </button>
        )}
        {cfg.quick_view && (
          <button onClick={(e) => { e.stopPropagation(); onQuickView(product); }} style={{ position: "absolute", bottom: 8, right: 8, background: "rgba(0,0,0,0.7)", color: "#fff", border: "none", borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
            <Eye size={14} />
          </button>
        )}
      </div>

      {/* Content — the exact order: category → name → attributes → variants → stock → price/unit → cart */}
      <div style={{ padding: 12, display: "flex", flexDirection: "column", flex: 1 }}>
        {/* 1. Category */}
        <p style={{ fontSize: "0.7rem", color: theme.primary, fontWeight: 800, marginBottom: 4, textTransform: "uppercase" }}>{product.category_name}</p>

        {/* 2. Name */}
        <h3 style={{ fontSize: "0.95rem", fontWeight: 800, color: theme.dark, marginBottom: 6, lineHeight: 1.25 }}>{product.name}</h3>

        {/* 3. Attributes (Size / Color / Fabric) */}
        {(selectedVariant.attributes || []).length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 6 }}>
            {(selectedVariant.attributes || []).map((a, ai) => (
              <span key={ai} style={{ fontSize: "0.65rem", fontWeight: 600, color: theme.dark, background: "#F1F5F9", border: `1px solid ${theme.border}`, borderRadius: 5, padding: "2px 6px", whiteSpace: "nowrap" }}>
                {a.attribute_name}: {a.value}
              </span>
            ))}
          </div>
        )}

        {/* 4. Variant dropdown (only when multiple variants) */}
        {hasMultipleVariants && (
          <div style={{ marginBottom: 8 }}>
            <button onClick={(e) => { e.stopPropagation(); setShowVariants(!showVariants); }} style={{ width: "100%", padding: "6px 10px", background: "#F8FAFF", border: `1px solid ${theme.border}`, borderRadius: 8, fontSize: "0.78rem", fontWeight: 600, color: theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>{selectedVariant.attributes?.length > 0 ? selectedVariant.attributes.map((a) => a.value).join(" · ") : selectedVariant.unit_abbr || `Variant ${selectedVariantIdx + 1}`}</span>
              <ChevronDown size={14} style={{ transform: showVariants ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
            </button>
            <AnimatePresence>
              {showVariants && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} style={{ overflow: "hidden" }}>
                  <div style={{ marginTop: 4, display: "flex", flexDirection: "column", gap: 4 }}>
                    {variants.map((v, idx) => {
                      const isSelected = idx === selectedVariantIdx;
                      const vOutOfStock = !isDeliverable || v.is_out_of_stock === true || (v.available_stock !== null && v.available_stock !== undefined && v.available_stock <= 0);
                      return (
                        <button key={v.id} onClick={(e) => { e.stopPropagation(); setSelectedVariantIdx(idx); setShowVariants(false); }} style={{ padding: "6px 10px", background: isSelected ? "#FFF7ED" : "#fff", border: `1px solid ${isSelected ? theme.primary : theme.border}`, borderRadius: 6, fontSize: "0.78rem", fontWeight: 600, color: vOutOfStock ? "#94A3B8" : theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", opacity: vOutOfStock ? 0.5 : 1 }}>
                          <span>{v.attributes?.length > 0 ? v.attributes.map((a) => a.value).join(" · ") : v.unit_abbr || `Variant ${idx + 1}`}</span>
                          <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                            ₹{Number(v.final_price || 0).toFixed(0)}
                            {isSelected && <Check size={12} color={theme.primary} />}
                            {vOutOfStock && <span style={{ fontSize: "0.65rem", color: "#EF4444" }}>{!isDeliverable ? "N/A" : "Out"}</span>}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* 5. Stock status */}
        {cfg.show_stock && stockLabel && (
          <div style={{ fontSize: "0.72rem", marginBottom: 6, fontWeight: 600, color: !isDeliverable ? "#DC2626" : isOutOfStock ? "#EF4444" : isLowStock ? "#F59E0B" : "#16A34A" }}>● {stockLabel}</div>
        )}

        {/* 6. Price / unit + Add to cart */}
        <div style={{ marginTop: "auto" }}>
          <div style={{ marginBottom: 8, display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
            <span style={{ fontSize: "1.1rem", fontWeight: 900, color: theme.dark }}>₹{Number(selectedVariant.final_price || 0).toFixed(2)}</span>
            {cfg.show_mrp && selectedVariant.has_discount && selectedVariant.mrp > selectedVariant.final_price && (
              <span style={{ fontSize: "0.75rem", color: "#94A3B8", textDecoration: "line-through" }}>₹{Number(selectedVariant.mrp || 0).toFixed(0)}</span>
            )}
            {cfg.show_unit && selectedVariant.unit_abbr && <span style={{ fontSize: "0.75rem", color: theme.mid }}> / {selectedVariant.unit_abbr}</span>}
          </div>
          {cfg.show_add_to_cart && (
            <button onClick={(e) => { e.stopPropagation(); onAddToCart(product, selectedVariant); }} disabled={isOutOfStock} style={{ width: "100%", padding: 8, borderRadius: 8, background: isOutOfStock ? "#E2E8F0" : theme.primary, color: isOutOfStock ? "#94A3B8" : "#fff", border: "none", fontWeight: 700, cursor: isOutOfStock ? "not-allowed" : "pointer", fontSize: "0.82rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
              <ShoppingCart size={12} /> {!isDeliverable ? "Not Deliverable" : isOutOfStock ? "Out of Stock" : "Add to Cart"}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ProductListCard (LIST view) — ★ click-to-detail
// (Your paste cut off inside this component — the tail is RECONSTRUCTED,
//  matching the grid card's patterns. Verify against your original.)
// ═══════════════════════════════════════════════════════════════════════
function ProductListCard({ product, index, cardBg, onAddToCart, cfg, theme, wishlist, toggleWishlist, onQuickView, isDeliverable, onOpenProduct }) {
  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [showVariants, setShowVariants] = useState(false);
  const variants = product.variants || [];
  const selectedVariant = variants[selectedVariantIdx] || variants[0] || {};

  // ★ NEW — auto-rotating media (images + videos) of the selected variant
  const media = useMemo(() => collectCardMedia(selectedVariant), [selectedVariant]);
  const [mediaIdx, setMediaIdx, , setMediaPaused] = useAutoRotate(media);

  const isOutOfStock = !isDeliverable || selectedVariant.is_out_of_stock === true ||
    (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined && selectedVariant.available_stock <= 0);
  const isLowStock = isDeliverable && !isOutOfStock && selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined && selectedVariant.available_stock > 0 && selectedVariant.available_stock <= 5;
  const hasMultipleVariants = variants.length > 1;
  const isWishlisted = wishlist.includes(product.id);
  const isDim = isOutOfStock && (cfg.out_of_stock_behavior === "dim" || !isDeliverable);

  return (
    <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.02 }}
      onClick={() => onOpenProduct && onOpenProduct(product)}
      style={{ background: "#fff", borderRadius: 12, padding: 12, display: "flex", gap: 16, border: `1px solid ${theme.border}`, opacity: isDim ? 0.55 : 1, cursor: "pointer" }}>
      <div
        onMouseEnter={() => setMediaPaused(true)}
        onMouseLeave={() => setMediaPaused(false)}
        style={{ width: 100, height: 100, flexShrink: 0, borderRadius: 8, overflow: "hidden", background: cardBg, position: "relative", padding: 6, boxSizing: "border-box" }}
      >
        {media.length > 0 ? <MediaSlide item={media[mediaIdx]} alt={product.name} /> : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32 }}>📦</div>}
        {media[mediaIdx]?.type === "video" && (
          <span style={{ position: "absolute", top: 4, right: 4 }}><VideoBadge /></span>
        )}
        <MediaDots media={media} idx={mediaIdx} onPick={setMediaIdx} />
        {cfg.show_discount && !isOutOfStock && selectedVariant.has_discount && selectedVariant.discount_percent > 0 && <span style={{ position: "absolute", top: 4, left: 4, background: "#16A34A", color: "#fff", fontSize: "0.6rem", fontWeight: 700, padding: "1px 6px", borderRadius: 3 }}>{selectedVariant.discount_percent}%</span>}
        {isOutOfStock && <span style={{ position: "absolute", top: 4, left: 4, background: "#FEE2E2", color: "#B91C1C", fontSize: "0.6rem", fontWeight: 700, padding: "1px 6px", borderRadius: 3 }}>{!isDeliverable ? "N/A" : "OUT"}</span>}
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", minWidth: 0 }}>
        <div>
          {/* 1. Category */}
          <div style={{ fontSize: "0.7rem", color: theme.primary, fontWeight: 800, textTransform: "uppercase", marginBottom: 2 }}>{product.category_name}</div>

          {/* 2. Name */}
          <div style={{ fontSize: "0.95rem", fontWeight: 800, color: theme.dark, marginBottom: 4 }}>{product.name}</div>

          {/* 3. Attributes */}
          {(selectedVariant.attributes || []).length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 4 }}>
              {(selectedVariant.attributes || []).map((a, ai) => (
                <span key={ai} style={{ fontSize: "0.65rem", fontWeight: 600, color: theme.dark, background: "#F1F5F9", border: `1px solid ${theme.border}`, borderRadius: 5, padding: "2px 6px", whiteSpace: "nowrap" }}>
                  {a.attribute_name}: {a.value}
                </span>
              ))}
            </div>
          )}

          {/* 4. Variant dropdown (multiple only) — same as grid card */}
          {hasMultipleVariants && (
            <div style={{ marginBottom: 6 }}>
              <button onClick={(e) => { e.stopPropagation(); setShowVariants(!showVariants); }} style={{ padding: "5px 10px", background: "#F8FAFF", border: `1px solid ${theme.border}`, borderRadius: 8, fontSize: "0.75rem", fontWeight: 600, color: theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, minWidth: 220 }}>
                <span>{selectedVariant.attributes?.length > 0 ? selectedVariant.attributes.map((a) => a.value).join(" · ") : selectedVariant.unit_abbr || `Variant ${selectedVariantIdx + 1}`}</span>
                <ChevronDown size={13} style={{ transform: showVariants ? "rotate(180deg)" : "none", transition: "transform 0.2s", flexShrink: 0 }} />
              </button>
              <AnimatePresence>
                {showVariants && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} style={{ overflow: "hidden" }}>
                    <div style={{ marginTop: 4, display: "flex", flexDirection: "column", gap: 4, maxWidth: 320 }}>
                      {variants.map((v, idx) => {
                        const isSelected = idx === selectedVariantIdx;
                        const vOutOfStock = !isDeliverable || v.is_out_of_stock === true || (v.available_stock !== null && v.available_stock !== undefined && v.available_stock <= 0);
                        return (
                          <button key={v.id} onClick={(e) => { e.stopPropagation(); setSelectedVariantIdx(idx); setShowVariants(false); }} style={{ padding: "6px 10px", background: isSelected ? "#FFF7ED" : "#fff", border: `1px solid ${isSelected ? theme.primary : theme.border}`, borderRadius: 6, fontSize: "0.75rem", fontWeight: 600, color: vOutOfStock ? "#94A3B8" : theme.dark, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", opacity: vOutOfStock ? 0.5 : 1 }}>
                            <span>{v.attributes?.length > 0 ? v.attributes.map((a) => a.value).join(" · ") : v.unit_abbr || `Variant ${idx + 1}`}</span>
                            <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                              ₹{Number(v.final_price || 0).toFixed(0)}
                              {isSelected && <Check size={12} color={theme.primary} />}
                              {vOutOfStock && <span style={{ fontSize: "0.65rem", color: "#EF4444" }}>{!isDeliverable ? "N/A" : "Out"}</span>}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* 5. Price + unit */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
            <span style={{ fontSize: "1rem", fontWeight: 800, color: theme.primary }}>₹{Number(selectedVariant.final_price || 0).toFixed(0)}</span>
            {cfg.show_mrp && selectedVariant.has_discount && selectedVariant.mrp > selectedVariant.final_price && <span style={{ fontSize: "0.75rem", textDecoration: "line-through", color: "#94a3b8" }}>₹{Number(selectedVariant.mrp || 0).toFixed(0)}</span>}
            {cfg.show_unit && selectedVariant.unit_abbr && <span style={{ fontSize: "0.75rem", color: theme.mid }}>/ {selectedVariant.unit_abbr}</span>}
          </div>

          {/* 6. Stock */}
          {cfg.show_stock && (
            <div style={{ fontSize: "0.7rem", fontWeight: 700, color: !isDeliverable ? "#DC2626" : isOutOfStock ? "#ef4444" : isLowStock ? "#f59e0b" : "#10b981" }}>
              {!isDeliverable ? "● Not deliverable" : isOutOfStock ? "● Out of Stock" : isLowStock ? `● Only ${selectedVariant.available_stock} left` : (selectedVariant.available_stock !== null && selectedVariant.available_stock !== undefined) ? "● In Stock" : ""}
            </div>
          )}
        </div>
      </div>

      {/* 7. Add to cart + wishlist/quick view */}
      <div style={{ display: "flex", flexDirection: "column", gap: 6, justifyContent: "center", alignItems: "flex-end" }}>
        {cfg.show_wishlist && <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }} style={{ background: "#fff", border: `1px solid ${theme.border}`, borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><Heart size={14} fill={isWishlisted ? "#ef4444" : "none"} color={isWishlisted ? "#ef4444" : theme.mid} /></button>}
        {cfg.quick_view && <button onClick={(e) => { e.stopPropagation(); onQuickView(product); }} style={{ background: "#fff", border: `1px solid ${theme.border}`, borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><Eye size={14} /></button>}
        {cfg.show_add_to_cart && (
          <button onClick={(e) => { e.stopPropagation(); onAddToCart(product, selectedVariant); }} disabled={isOutOfStock} style={{ padding: 8, borderRadius: 8, background: isOutOfStock ? "#E2E8F0" : theme.primary, color: isOutOfStock ? "#94A3B8" : "#fff", border: "none", fontWeight: 700, cursor: isOutOfStock ? "not-allowed" : "pointer", fontSize: "0.78rem", display: "flex", alignItems: "center", justifyContent: "center", gap: 4, whiteSpace: "nowrap" }}>
            <ShoppingCart size={12} /> {!isDeliverable ? "N/A" : isOutOfStock ? "Out" : "Add"}
          </button>
        )}
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ★ RECONSTRUCTED — your paste never included FilterPanel. This matches
// the exact props your page passes. If your original differs, keep yours —
// the new navigation functionality does NOT touch FilterPanel.
// ═══════════════════════════════════════════════════════════════════════
function FilterPanel({ categories, selectedCategory, setSelectedCategory, priceMin, setPriceMin, priceMax, setPriceMax, inStockOnly, setInStockOnly, sortBy, setSortBy, clearAllFilters, hasActiveFilters, theme, attributeFacets, selectedAttrs, toggleAttrValue }) {
  const label = (c) => c.name || c.category_name || c.title || `#${c.id}`;
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h3 style={{ margin: 0, fontSize: "1rem", fontWeight: 800, color: theme.dark }}>Filters</h3>
        {hasActiveFilters && (
          <button onClick={clearAllFilters} style={{ background: "transparent", border: "none", color: theme.primary, fontWeight: 700, fontSize: "0.8rem", cursor: "pointer" }}>Clear all</button>
        )}
      </div>

      <div style={{ marginBottom: 18 }}>
        <p style={{ fontSize: "0.8rem", fontWeight: 800, color: theme.dark, margin: "0 0 8px", textTransform: "uppercase", letterSpacing: "0.03em" }}>Category</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <button onClick={() => setSelectedCategory(null)}
            style={{ padding: "8px 10px", background: selectedCategory === null ? "#FFF7ED" : "#fff", border: `1px solid ${selectedCategory === null ? theme.primary : theme.border}`, borderRadius: 8, fontSize: "0.82rem", fontWeight: 600, color: theme.dark, cursor: "pointer", textAlign: "left" }}>
            All Categories
          </button>
          {(categories || []).map((c) => {
            const cid = c.id ?? c.category_id;
            const active = Number(selectedCategory) === Number(cid);
            return (
              <button key={cid} onClick={() => setSelectedCategory(cid)}
                style={{ padding: "8px 10px", background: active ? "#FFF7ED" : "#fff", border: `1px solid ${active ? theme.primary : theme.border}`, borderRadius: 8, fontSize: "0.82rem", fontWeight: 600, color: theme.dark, cursor: "pointer", textAlign: "left", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                {label(c)}
                {active && <Check size={12} color={theme.primary} />}
              </button>
            );
          })}
        </div>
      </div>

      {/* ★ attribute pills (Size / Color / Fabric / …) */}
      {(attributeFacets || []).map((group) => (
        <div key={group.name} style={{ marginBottom: 18 }}>
          <p style={{ fontSize: "0.8rem", fontWeight: 800, color: theme.dark, margin: "0 0 8px", textTransform: "uppercase", letterSpacing: "0.03em" }}>{group.name}</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {group.values.map((val) => {
              const active = (selectedAttrs?.[group.name] || []).includes(val);
              return (
                <button key={val} onClick={() => toggleAttrValue(group.name, val)}
                  style={{ padding: "5px 12px", borderRadius: 999, border: `1px solid ${active ? theme.primary : theme.border}`, background: active ? theme.primary : "#fff", color: active ? "#fff" : theme.dark, fontSize: "0.78rem", fontWeight: 600, cursor: "pointer" }}>
                  {val}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      <div style={{ marginBottom: 18 }}>
        <p style={{ fontSize: "0.8rem", fontWeight: 800, color: theme.dark, margin: "0 0 8px", textTransform: "uppercase", letterSpacing: "0.03em" }}>Price (₹)</p>
        <div style={{ display: "flex", gap: 8 }}>
          <input type="number" value={priceMin} onChange={(e) => setPriceMin(e.target.value)} placeholder="Min" style={{ width: "50%", padding: "8px 10px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.85rem", outline: "none" }} />
          <input type="number" value={priceMax} onChange={(e) => setPriceMax(e.target.value)} placeholder="Max" style={{ width: "50%", padding: "8px 10px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.85rem", outline: "none" }} />
        </div>
      </div>

      <div style={{ marginBottom: 18 }}>
        <p style={{ fontSize: "0.8rem", fontWeight: 800, color: theme.dark, margin: "0 0 8px", textTransform: "uppercase", letterSpacing: "0.03em" }}>Sort By</p>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={{ width: "100%", padding: "9px 10px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: "0.85rem", outline: "none", background: "#fff", color: theme.dark }}>
          {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>

      <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: "0.85rem", fontWeight: 600, color: theme.dark }}>
        <input type="checkbox" checked={inStockOnly} onChange={(e) => setInStockOnly(e.target.checked)} style={{ width: 16, height: 16, accentColor: theme.primary, cursor: "pointer" }} />
        In stock only
      </label>
    </div>
  );
}