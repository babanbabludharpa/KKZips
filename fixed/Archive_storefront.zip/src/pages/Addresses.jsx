import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Plus,
  MapPin,
  Edit3,
  Trash2,
  Star,
  Check,
  X,
  Navigation,
  Search,
} from "lucide-react";
import customerApi, { unwrap } from "../api/customerApi";
import { useCustomerAuth } from "../store/useCustomerAuth";
import { useTenant } from "../contexts/TenantProvider";

// Default content (used if admin hasn't configured this page)
const defaultAddrData = {
  hero: { alignment: "center", badge: "Saved Locations", title: "Manage Delivery Addresses", subtitle: "Pin your exact location on the map for accurate deliveries." },
  emptyState: { icon: "📍", title: "No addresses saved", message: "Add a delivery address with pinpoint location for accurate deliveries.", buttonText: "+ Add Address" },
  newButton: { text: "+ Add New Address" },
};

// ─────────────────────────────────────────────────────────────────────────
// Addresses.jsx — FIXED version
//
// Fixes:
//   1. Field name mismatch: backend expects address_line1 (no underscore),
//      we were sending address_line_1. Fixed all field names to match
//      backend validation.
//   2. Removed auto-fill from map click. Map now ONLY sets lat/long.
//      User manually types all address fields. No more pre-filled boxes.
// ─────────────────────────────────────────────────────────────────────────

const theme = {
  primary: "#FF7132",
  primaryHover: "#EA580C",
  dark: "#1E293B",
  mid: "#64748B",
  bg: "#F8FAFF",
  border: "#E2E8F0",
  success: "#22C55E",
  error: "#EF4444",
  warning: "#F59E0B",
};

const inputStyle = {
  width: "100%",
  padding: "12px 14px",
  borderRadius: 10,
  border: `1px solid ${theme.border}`,
  fontSize: "0.95rem",
  outline: "none",
  backgroundColor: "#fff",
  boxSizing: "border-box",
  fontFamily: "inherit",
};

export default function Addresses() {
  const navigate = useNavigate();
  const { isAuthenticated } = useCustomerAuth();
  const { sections } = useTenant();

  // ★ Read content from layout (admin-configurable)
  const safeSections = Array.isArray(sections) ? sections : [];
  const addrData = safeSections.find((s) => s.page === "addresses")?.data || defaultAddrData;
  const hero = addrData.hero || defaultAddrData.hero;
  const emptyState = addrData.emptyState || defaultAddrData.emptyState;
  const newButton = addrData.newButton || defaultAddrData.newButton;

  const [addresses, setAddresses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);

  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  // Form state — ★ FIXED field names to match backend (no underscore before number)
  const [form, setForm] = useState({
    label: "",
    flat_no: "",
    address_line1: "",       // ★ was address_line_1
    address_line2: "",       // ★ was address_line_2
    area: "",
    city: "",
    state: "",
    pincode: "",
    landmark: "",
    phone: "",
    latitude: null,
    longitude: null,
    is_default: false,
    is_active: true,
  });

  // Map state
  const [searchQuery, setSearchQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    if (!isAuthenticated) navigate("/", { replace: true });
  }, [isAuthenticated, navigate]);

  // ── Fetch addresses ────────────────────────────────────────────────────
  const fetchAddresses = async () => {
    if (!isAuthenticated) return;
    setLoading(true);
    setError(null);
    try {
      const data = await unwrap(await customerApi.get("/mobile/addresses"));
      // Normalize field names from backend (handle both address_line1 and address_line_1)
      const normalized = (Array.isArray(data) ? data : []).map(addr => ({
        ...addr,
        address_line1: addr.address_line1 || addr.address_line_1 || "",
        address_line2: addr.address_line2 || addr.address_line_2 || "",
      }));
      setAddresses(normalized);
    } catch (e) {
      setError(e?.response?.data?.message || e?.body?.message || e.message || "Failed to load addresses.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) fetchAddresses();
  }, [isAuthenticated]);

  // ── Initialize Leaflet map when modal opens ────────────────────────────
  useEffect(() => {
    if (!showModal) return;

    const initMap = async () => {
      const L = (await import("leaflet")).default;

      setTimeout(() => {
        if (!mapRef.current) return;
        if (mapInstanceRef.current) {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        }

        // Default center: Pune, India
        const initialLat = form.latitude || 18.5204;
        const initialLng = form.longitude || 73.8567;

        const map = L.map(mapRef.current).setView([initialLat, initialLng], 13);

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; OpenStreetMap contributors',
          maxZoom: 19,
        }).addTo(map);

        // Add initial marker if editing
        if (form.latitude && form.longitude) {
          markerRef.current = L.marker([form.latitude, form.longitude]).addTo(map);
        }

        // Click to set marker — ★ ONLY sets lat/long, does NOT auto-fill address
        map.on("click", (e) => {
          const { lat, lng } = e.latlng;
          setForm((prev) => ({ ...prev, latitude: lat, longitude: lng }));

          if (markerRef.current) {
            markerRef.current.setLatLng([lat, lng]);
          } else {
            markerRef.current = L.marker([lat, lng]).addTo(map);
          }
          // ★ REMOVED: reverseGeocode() call — user types address manually
        });

        mapInstanceRef.current = map;
      }, 100);
    };

    initMap();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
    };
  }, [showModal]);

  // ── Nominatim geocoding (search address → lat/long) ────────────────────
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    setSearchResults([]);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          searchQuery
        )}&limit=5&countrycodes=in`,
        { headers: { "Accept-Language": "en" } }
      );
      const data = await res.json();
      setSearchResults(data || []);
    } catch (e) {
      console.error("Search failed:", e);
    } finally {
      setSearching(false);
    }
  };

  // ── Select a search result → move map + set marker (NO address auto-fill) ─
  const handleSelectResult = (result) => {
    const lat = parseFloat(result.lat);
    const lng = parseFloat(result.lon);
    setForm((prev) => ({ ...prev, latitude: lat, longitude: lng }));

    if (mapInstanceRef.current && markerRef.current) {
      markerRef.current.setLatLng([lat, lng]);
      mapInstanceRef.current.setView([lat, lng], 16);
    } else if (mapInstanceRef.current) {
      import("leaflet").then((L) => {
        markerRef.current = L.default.marker([lat, lng]).addTo(mapInstanceRef.current);
        mapInstanceRef.current.setView([lat, lng], 16);
      });
    }

    setSearchResults([]);
    // ★ REMOVED: reverseGeocode() call — user types address manually
  };

  // ── Use browser geolocation — ONLY sets lat/long, NO address auto-fill ──
  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setToast({ msg: "Geolocation not supported by your browser", kind: "error" });
      setTimeout(() => setToast(null), 3000);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setForm((prev) => ({ ...prev, latitude, longitude }));

        if (mapInstanceRef.current && markerRef.current) {
          markerRef.current.setLatLng([latitude, longitude]);
          mapInstanceRef.current.setView([latitude, longitude], 16);
        } else if (mapInstanceRef.current) {
          import("leaflet").then((L) => {
            markerRef.current = L.default.marker([latitude, longitude]).addTo(mapInstanceRef.current);
            mapInstanceRef.current.setView([latitude, longitude], 16);
          });
        }
        // ★ REMOVED: reverseGeocode() call — user types address manually
      },
      (err) => {
        setToast({ msg: "Could not get your location: " + err.message, kind: "error" });
        setTimeout(() => setToast(null), 3000);
      },
      { enableHighAccuracy: true }
    );
  };

  // ── Save address ───────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!form.flat_no || !form.address_line1 || !form.city || !form.pincode) {
      setToast({ msg: "Please fill all required fields", kind: "error" });
      setTimeout(() => setToast(null), 3000);
      return;
    }

    if (!form.latitude || !form.longitude) {
      setToast({ msg: "Please select a location on the map", kind: "error" });
      setTimeout(() => setToast(null), 3000);
      return;
    }

    setSaving(true);
    // ★ Send with backend-expected field names + lat/long as NUMBERS (not strings)
    const payload = {
      label: form.label,
      flat_no: form.flat_no,
      address_line1: form.address_line1,    // matches backend
      address_line2: form.address_line2,    // matches backend
      area: form.area,
      city: form.city,
      state: form.state,
      pincode: form.pincode,
      landmark: form.landmark,
      phone: form.phone,
      latitude: form.latitude ? Number(form.latitude) : null,   // ★ NUMBER, not string
      longitude: form.longitude ? Number(form.longitude) : null, // ★ NUMBER, not string
      is_default: form.is_default,
      is_active: form.is_active,
    };

    try {
      if (editingId) {
        await unwrap(await customerApi.put(`/mobile/addresses/${editingId}`, payload));
        setToast({ msg: "Address updated", kind: "success" });
      } else {
        await unwrap(await customerApi.post("/mobile/addresses", payload));
        setToast({ msg: "Address added", kind: "success" });
      }
      setShowModal(false);
      setEditingId(null);
      fetchAddresses();
      setTimeout(() => setToast(null), 3000);
    } catch (e) {
      setToast({
        msg: e?.response?.data?.message || e?.body?.message || e.message || "Failed to save address",
        kind: "error",
      });
      setTimeout(() => setToast(null), 3000);
    } finally {
      setSaving(false);
    }
  };

  // ── Delete address ─────────────────────────────────────────────────────
  const handleDelete = async (id) => {
    if (!window.confirm("Delete this address?")) return;
    try {
      await unwrap(await customerApi.delete(`/mobile/addresses/${id}`));
      setToast({ msg: "Address deleted", kind: "success" });
      fetchAddresses();
      setTimeout(() => setToast(null), 3000);
    } catch (e) {
      setToast({
        msg: e?.response?.data?.message || e?.body?.message || e.message || "Failed to delete",
        kind: "error",
      });
      setTimeout(() => setToast(null), 3000);
    }
  };

  // ── Set default ────────────────────────────────────────────────────────
  const handleSetDefault = async (id) => {
    try {
      await unwrap(await customerApi.patch(`/mobile/addresses/${id}/default`));
      setToast({ msg: "Default address updated", kind: "success" });
      fetchAddresses();
      setTimeout(() => setToast(null), 3000);
    } catch (e) {
      setToast({
        msg: e?.response?.data?.message || e?.body?.message || e.message || "Failed to set default",
        kind: "error",
      });
      setTimeout(() => setToast(null), 3000);
    }
  };

  // ── Toggle active/inactive ─────────────────────────────────────────────
  const handleToggleActive = async (addr) => {
    try {
      await unwrap(
        await customerApi.put(`/mobile/addresses/${addr.id}`, {
          ...addr,
          // Send both field name variants to be safe
          address_line1: addr.address_line1 || addr.address_line_1 || "",
          address_line2: addr.address_line2 || addr.address_line_2 || "",
          is_active: !addr.is_active,
        })
      );
      fetchAddresses();
    } catch (e) {
      setToast({
        msg: e?.response?.data?.message || e?.body?.message || e.message || "Failed to update",
        kind: "error",
      });
      setTimeout(() => setToast(null), 3000);
    }
  };

  // ── Open add modal ─────────────────────────────────────────────────────
  const openAddModal = () => {
    setForm({
      label: "",
      flat_no: "",
      address_line1: "",
      address_line2: "",
      area: "",
      city: "",
      state: "",
      pincode: "",
      landmark: "",
      phone: "",
      latitude: null,
      longitude: null,
      is_default: addresses.length === 0,
      is_active: true,
    });
    setEditingId(null);
    setSearchQuery("");
    setSearchResults([]);
    setShowModal(true);
  };

  // ── Open edit modal ────────────────────────────────────────────────────
  const openEditModal = (addr) => {
    setForm({
      label: addr.label || "",
      flat_no: addr.flat_no || "",
      address_line1: addr.address_line1 || addr.address_line_1 || "",
      address_line2: addr.address_line2 || addr.address_line_2 || "",
      area: addr.area || "",
      city: addr.city || "",
      state: addr.state || "",
      pincode: addr.pincode || "",
      landmark: addr.landmark || "",
      phone: addr.phone || "",
      latitude: addr.latitude ? parseFloat(addr.latitude) : null,
      longitude: addr.longitude ? parseFloat(addr.longitude) : null,
      is_default: !!addr.is_default,
      is_active: addr.is_active !== false,
    });
    setEditingId(addr.id);
    setSearchQuery("");
    setSearchResults([]);
    setShowModal(true);
  };

  if (!isAuthenticated) {
    return <div style={{ padding: "3rem", textAlign: "center", color: theme.mid }}>Please log in to manage addresses.</div>;
  }

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, paddingBottom: 40 }}>
      {/* ── HERO HEADER ────────────────────────────────────────── */}
      <div
        style={{
          background: `linear-gradient(135deg, var(--color-primary, ${theme.primary}), var(--color-secondary, ${theme.primaryHover}))`,
          padding: "40px 24px 80px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
            backgroundSize: "30px 30px",
            pointerEvents: "none",
          }}
        />
        <div   style={{
    position: "relative",
    zIndex: 1,
    maxWidth: 1100,
    margin: "50px auto",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    textAlign: "center",
  }}>
          <motion.span
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
              display: "inline-block",
              background: "rgba(255,255,255,0.15)",
              border: "1px solid rgba(255,255,255,0.2)",
              color: "#fff",
              padding: "8px 20px",
              borderRadius: 100,
              fontSize: ".85rem",
              fontWeight: 700,
              marginBottom: 16,
              backdropFilter: "blur(4px)",
            }}
          >
            {hero.badge}
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            style={{
              color: "#fff",
              fontSize: "clamp(1.75rem, 4vw, 2.5rem)",
              fontWeight: 900,
              margin: "0 0 8px",
              textShadow: "0 4px 12px rgba(0,0,0,0.2)",
              letterSpacing: "-0.02em",
            }}
          >
            {hero.title}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            style={{ color: "rgba(255,255,255,0.95)", fontSize: "1rem", margin: 0 }}
          >
            {hero.subtitle}
          </motion.p>
        </div>
      </div>

      {/* ── Content ────────────────────────────────────────────── */}
      <div style={{ maxWidth: 1100, margin: "-48px auto 0", padding: "0 24px", position: "relative", zIndex: 10 }}>
        {/* Add button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={openAddModal}
          style={{
  width: "100%",
  background: "linear-gradient(135deg, #ffffff 0%, #fff7f2 100%)",
  color: "#000000",
  border: "1px solid rgba(255,113,50,0.25)",
  borderRadius: 18,
  padding: "20px",
  fontSize: "1rem",
  fontWeight: 800,
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 12,
  marginBottom: 24,
  //boxShadow: "0 12px 30px rgba(255,113,50,0.15)",
  transition: "all 0.25s ease",
}}
        >
          <Plus size={18} /> Add New Address
        </motion.button>

        {loading ? (
          <div style={{ textAlign: "center", padding: "3rem", color: theme.mid }}>
            <div style={{ width: 40, height: 40, border: `4px solid ${theme.border}`, borderTopColor: theme.primary, borderRadius: "50%", margin: "0 auto 16px", animation: "spin 0.8s linear infinite" }} />
            Loading addresses…
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        ) : error ? (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12, padding: "1.5rem", color: "#b91c1c", textAlign: "center" }}>
            {error}
            <div style={{ marginTop: "0.75rem" }}>
              <button onClick={fetchAddresses} style={{ padding: "0.5rem 1rem", background: theme.primary, color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}>Retry</button>
            </div>
          </div>
        ) : addresses.length === 0 ? (
          <div style={{ background: "#fff", border: `1px dashed ${theme.border}`, borderRadius: 14, padding: "3rem 1rem", textAlign: "center" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: 16 }}>{emptyState.icon}</div>
            <h3 style={{ margin: "0 0 8px", color: theme.dark }}>{emptyState.title}</h3>
            <p style={{ color: theme.mid, margin: "0 auto 24px", maxWidth: 420 }}>
              {emptyState.message}
            </p>
            <button
              onClick={openAddModal}
              style={{ background: theme.primary, color: "#fff", border: "none", borderRadius: 999, padding: "0.65rem 1.4rem", fontWeight: 600, cursor: "pointer" }}
            >
              {emptyState.buttonText}
            </button>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: "1rem" }}>
            {addresses.map((addr, i) => (
              <motion.div
                key={addr.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                style={{
                  background: "#fff",
                  border: `1px solid ${theme.border}`,
                  borderRadius: 14,
                  padding: 20,
                  boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
                  opacity: addr.is_active === false ? 0.6 : 1,
                }}
              >
                {/* Header */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 10,
                        background: addr.is_default ? "#FEF3C7" : "#FFF7ED",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <MapPin size={18} color={addr.is_default ? "#D97706" : theme.primary} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: theme.dark, fontSize: "0.95rem" }}>
                        {addr.label || "Address"} {addr.is_default && <span style={{ background: "#FEF3C7", color: "#92400E", padding: "2px 8px", borderRadius: 6, fontSize: "0.7rem", fontWeight: 700, marginLeft: 4 }}>DEFAULT</span>}
                      </div>
                      {addr.is_active === false && (
                        <span style={{ background: "#FEE2E2", color: "#B91C1C", padding: "2px 8px", borderRadius: 6, fontSize: "0.7rem", fontWeight: 700 }}>INACTIVE</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Address text */}
                <div style={{ fontSize: "0.88rem", color: theme.mid, lineHeight: 1.5, marginBottom: 12 }}>
                  {[addr.flat_no, addr.address_line1 || addr.address_line_1, addr.address_line2 || addr.address_line_2, addr.area, addr.city, addr.state, addr.pincode].filter(Boolean).join(", ")}
                </div>

                {/* Phone + Landmark */}
                <div style={{ fontSize: "0.82rem", color: theme.mid, marginBottom: 12 }}>
                  {addr.phone && <div>📞 {addr.phone}</div>}
                  {addr.landmark && <div>🗺️ {addr.landmark}</div>}
                  {addr.latitude && addr.longitude && (
                    <div style={{ color: "#94A3B8", fontSize: "0.75rem", marginTop: 4 }}>
                      📍 {Number(addr.latitude).toFixed(4)}, {Number(addr.longitude).toFixed(4)}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", borderTop: `1px solid ${theme.border}`, paddingTop: 12 }}>
                  {!addr.is_default && (
                    <button
                      onClick={() => handleSetDefault(addr.id)}
                      style={miniBtn("ghost")}
                      title="Set as default"
                    >
                      <Star size={14} /> Default
                    </button>
                  )}
                  <button
                    onClick={() => openEditModal(addr)}
                    style={miniBtn("ghost")}
                    title="Edit"
                  >
                    <Edit3 size={14} /> Edit
                  </button>
                  <button
                    onClick={() => handleToggleActive(addr)}
                    style={miniBtn(addr.is_active === false ? "success" : "ghost")}
                    title={addr.is_active === false ? "Activate" : "Deactivate"}
                  >
                    {addr.is_active === false ? <><Check size={14} /> Activate</> : <><X size={14} /> Deactivate</>}
                  </button>
                  <button
                    onClick={() => handleDelete(addr.id)}
                    style={miniBtn("danger")}
                    title="Delete"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* ── Add/Edit Modal ─────────────────────────────────────── */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.5)",
              backdropFilter: "blur(8px)",
              zIndex: 1000,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 24,
              overflowY: "auto",
            }}
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              style={{
                background: "#fff",
                borderRadius: 20,
                padding: 28,
                maxWidth: 720,
                width: "100%",
                maxHeight: "90vh",
                overflowY: "auto",
                position: "relative",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close */}
              <button
                onClick={() => setShowModal(false)}
                style={{
                  position: "absolute",
                  top: 16,
                  right: 16,
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  padding: 8,
                  color: theme.mid,
                }}
              >
                <X size={20} />
              </button>

              <h2 style={{ margin: "0 0 4px", fontSize: "1.5rem", fontWeight: 800, color: theme.dark }}>
                {editingId ? "Edit Address" : "Add New Address"}
              </h2>
              <p style={{ margin: "0 0 24px", color: theme.mid, fontSize: "0.9rem" }}>
                Search your location or click on the map to pin the exact delivery spot, then fill in your address details below.
              </p>

              {/* Search bar */}
              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Search area, landmark, or address…"
                  style={inputStyle}
                />
                <button
                  onClick={handleSearch}
                  disabled={searching}
                  style={{
                    padding: "0 16px",
                    background: theme.primary,
                    color: "#fff",
                    border: "none",
                    borderRadius: 10,
                    cursor: "pointer",
                    fontWeight: 600,
                    whiteSpace: "nowrap",
                  }}
                >
                  {searching ? "…" : <Search size={16} />}
                </button>
                <button
                  onClick={handleUseMyLocation}
                  title="Use my current location"
                  style={{
                    padding: "0 16px",
                    background: "#fff",
                    color: theme.primary,
                    border: `1px solid ${theme.primary}`,
                    borderRadius: 10,
                    cursor: "pointer",
                    fontWeight: 600,
                  }}
                >
                  <Navigation size={16} />
                </button>
              </div>

              {/* Search results */}
              {searchResults.length > 0 && (
                <div style={{ marginBottom: 12, border: `1px solid ${theme.border}`, borderRadius: 10, maxHeight: 180, overflowY: "auto" }}>
                  {searchResults.map((r, i) => (
                    <button
                      key={i}
                      onClick={() => handleSelectResult(r)}
                      style={{
                        display: "block",
                        width: "100%",
                        textAlign: "left",
                        padding: "10px 14px",
                        background: "transparent",
                        border: "none",
                        borderBottom: i < searchResults.length - 1 ? `1px solid ${theme.border}` : "none",
                        cursor: "pointer",
                        fontSize: "0.85rem",
                        color: theme.dark,
                      }}
                    >
                      <MapPin size={12} style={{ marginRight: 6, color: theme.primary }} />
                      {r.display_name}
                    </button>
                  ))}
                </div>
              )}

              {/* Map */}
              <div
                ref={mapRef}
                style={{
                  width: "100%",
                  height: 280,
                  borderRadius: 12,
                  marginBottom: 16,
                  border: `1px solid ${theme.border}`,
                }}
              />

              {/* Lat/Long display */}
              {form.latitude && form.longitude && (
                <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 10, padding: "8px 12px", marginBottom: 16, fontSize: "0.82rem", color: "#15803D", display: "flex", alignItems: "center", gap: 6 }}>
                  <Check size={14} />
                  Location pinned: {Number(form.latitude).toFixed(5)}, {Number(form.longitude).toFixed(5)}
                </div>
              )}

              {/* Form fields — ★ All empty, user types manually */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12, marginBottom: 16 }}>
                <div>
                  <label style={labelStyle}>Label *</label>
                  <input
                    type="text"
                    value={form.label}
                    onChange={(e) => setForm({ ...form, label: e.target.value })}
                    placeholder="Home, Work, etc."
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Flat / House No. *</label>
                  <input
                    type="text"
                    value={form.flat_no}
                    onChange={(e) => setForm({ ...form, flat_no: e.target.value })}
                    placeholder="Flat 101"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Address Line 1 *</label>
                  <input
                    type="text"
                    value={form.address_line1}
                    onChange={(e) => setForm({ ...form, address_line1: e.target.value })}
                    placeholder="Building, Street name"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Address Line 2</label>
                  <input
                    type="text"
                    value={form.address_line2}
                    onChange={(e) => setForm({ ...form, address_line2: e.target.value })}
                    placeholder="Apartment, suite (optional)"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Area</label>
                  <input
                    type="text"
                    value={form.area}
                    onChange={(e) => setForm({ ...form, area: e.target.value })}
                    placeholder="Area / Locality"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>City *</label>
                  <input
                    type="text"
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    placeholder="Pune"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>State</label>
                  <input
                    type="text"
                    value={form.state}
                    onChange={(e) => setForm({ ...form, state: e.target.value })}
                    placeholder="Maharashtra"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Pincode *</label>
                  <input
                    type="text"
                    value={form.pincode}
                    onChange={(e) => setForm({ ...form, pincode: e.target.value })}
                    placeholder="411043"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Landmark</label>
                  <input
                    type="text"
                    value={form.landmark}
                    onChange={(e) => setForm({ ...form, landmark: e.target.value })}
                    placeholder="Near metro station"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Phone</label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+91 98765 43210"
                    style={inputStyle}
                  />
                </div>
              </div>

              {/* Toggles */}
              <div style={{ display: "flex", gap: 20, marginBottom: 20, flexWrap: "wrap" }}>
                <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "0.9rem", color: theme.dark }}>
                  <input
                    type="checkbox"
                    checked={form.is_default}
                    onChange={(e) => setForm({ ...form, is_default: e.target.checked })}
                    style={{ width: 16, height: 16 }}
                  />
                  Set as default address
                </label>
                <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "0.9rem", color: theme.dark }}>
                  <input
                    type="checkbox"
                    checked={form.is_active}
                    onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                    style={{ width: 16, height: 16 }}
                  />
                  Active (available for deliveries)
                </label>
              </div>

              {/* Submit */}
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  style={{
                    padding: "12px 24px",
                    background: saving ? "#FFA37E" : theme.primary,
                    color: "#fff",
                    border: "none",
                    borderRadius: 10,
                    fontWeight: 600,
                    cursor: saving ? "not-allowed" : "pointer",
                    fontSize: "0.95rem",
                  }}
                >
                  {saving ? "Saving…" : editingId ? "Update Address" : "Save Address"}
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  style={{
                    padding: "12px 24px",
                    background: "transparent",
                    color: theme.mid,
                    border: `1px solid ${theme.border}`,
                    borderRadius: 10,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontSize: "0.95rem",
                  }}
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: "fixed",
            bottom: 24,
            right: 24,
            zIndex: 1100,
            background: toast.kind === "error" ? theme.error : theme.success,
            color: "#fff",
            padding: "12px 20px",
            borderRadius: 10,
            boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
            fontWeight: 500,
            fontSize: "0.9rem",
            maxWidth: 320,
          }}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}

const labelStyle = {
  display: "block",
  fontSize: "0.82rem",
  fontWeight: 600,
  color: "#1E293B",
  marginBottom: 6,
};

function miniBtn(kind) {
  const map = {
    primary: { background: "#FF7132", color: "#fff", border: "1px solid #FF7132" },
    ghost: { background: "#fff", color: "#64748B", border: "1px solid #E2E8F0" },
    danger: { background: "#fff", color: "#DC2626", border: "1px solid #FECACA" },
    success: { background: "#F0FDF4", color: "#16A34A", border: "1px solid #BBF7D0" },
  };
  const s = map[kind] || map.ghost;
  return {
    ...s,
    padding: "6px 10px",
    borderRadius: 8,
    fontSize: "0.78rem",
    fontWeight: 600,
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
  };
}
