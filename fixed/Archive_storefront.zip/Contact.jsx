import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  MapPin, Phone, Mail, Clock, Send, 
  CheckCircle2, AlertCircle, ArrowRight, MessageSquare 
} from 'lucide-react'

const contactInfo = [
  {
    icon: MapPin,
    title: 'Our Headquarters',
    desc: 'Shop Hub HQ, Tech Park Phase 2, Pune, Maharashtra 411057',
  },
  {
    icon: Phone,
    title: 'Call Us',
    desc: '+91 93734 23799 \n(For urgent delivery issues)',
  },
  {
    icon: Mail,
    title: 'Email Us',
    desc: 'support@shophub.com \nvendors@shophub.com',
  },
  {
    icon: Clock,
    title: 'Support Hours',
    desc: 'Monday - Sunday \n7:00 AM - 9:00 PM',
  }
]

// Section Label component matched from About.jsx
const SectionLabel = ({ children }) => (
  <span style={{
    display: 'inline-block', padding: '4px 14px', borderRadius: '100px',
    background: 'rgba(37,99,235,0.08)', color: 'var(--color-primary, #2563EB)',
    fontSize: '0.8rem', fontWeight: '700', letterSpacing: '0.06em',
    textTransform: 'uppercase', marginBottom: '16px',
  }}>
    {children}
  </span>
)

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: 'Daily Delivery Issue', message: '' })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm(p => ({ ...p, [name]: value }))
    if (errors[name]) setErrors(p => ({ ...p, [name]: '' }))
  }

  const validate = () => {
    const errs = {}
    if (!form.name.trim()) errs.name = 'Name is required'
    if (!form.email) errs.email = 'Email is required'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'Invalid email address'
    if (!form.message.trim()) errs.message = 'Message cannot be empty'
    return errs
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }
    
    setLoading(true)
    await new Promise(r => setTimeout(r, 1500))
    setLoading(false)
    setSuccess(true)
    setForm({ name: '', email: '', subject: 'Daily Delivery Issue', message: '' })
    setTimeout(() => setSuccess(false), 4000)
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--color-bg, #F8FAFF)' }}>
      
      {/* ── Hero Banner ──────────────── */}
      <section style={{
        background: 'linear-gradient(135deg, #0a1628 0%, #2563EB 55%, #1a2f6b 100%)',
        padding: 'clamp(72px, 12vw, 120px) 24px',
        position: 'relative', overflow: 'hidden', textAlign: 'center',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)',
          backgroundSize: '28px 28px', pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', width: '480px', height: '480px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(61,111,255,0.25) 0%, transparent 70%)',
          top: '-200px', right: '-80px', pointerEvents: 'none',
        }} />
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          style={{ position: 'relative', zIndex: 1, maxWidth: '680px', margin: '0 auto' }}
        >
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '8px',
            background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255,255,255,0.15)',
            borderRadius: '100px', padding: '6px 16px', marginBottom: '24px',
          }}>
            <span style={{ color: 'rgba(255,255,255,0.75)', fontSize: '0.82rem', fontWeight: '600' }}>
              24/7 Support
            </span>
          </div>
          <h1 style={{
            fontSize: 'clamp(2rem, 5vw, 3.4rem)', fontWeight: '900',
            color: '#fff', letterSpacing: '-0.03em', marginBottom: '20px', lineHeight: '1.1',
          }}>
            How can we help you?
          </h1>
          <p style={{
            color: 'rgba(255,255,255,0.7)', fontSize: 'clamp(1rem, 2vw, 1.15rem)',
            lineHeight: '1.7', maxWidth: '520px', margin: '0 auto',
          }}>
            Whether it's a question about your daily milk subscription, a missed tiffin delivery, or joining Shop Hub as a vendor, we're here for you.
          </p>
        </motion.div>
      </section>

      {/* ── Contact Layout ─────────────────────────────────────── */}
      <section style={{ padding: '96px 24px', background: '#fff', paddingBottom: '120px' }}>
        <div style={{
          maxWidth: '1200px', margin: '0 auto',
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '64px', alignItems: 'flex-start',
        }}>
          
          {/* Left: Contact Info & Chat Card */}
          <motion.div
            initial={{ opacity: 0, x: -32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionLabel>Contact Details</SectionLabel>
            <h2 style={{
              fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', fontWeight: '800',
              color: 'var(--color-dark, #1E293B)', letterSpacing: '-0.025em', marginBottom: '32px', lineHeight: '1.2',
            }}>
              Get in touch with the Shop Hub team
            </h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '24px', marginBottom: '40px' }}>
              {contactInfo.map(({ icon: Icon, title, desc }, i) => (
                <div key={title} style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
                  <div style={{
                    width: '48px', height: '48px', borderRadius: '12px',
                    background: 'rgba(37,99,235,0.06)', 
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
                  }}>
                    <Icon size={22} color="var(--color-primary, #2563EB)" />
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--color-dark, #1E293B)', marginBottom: '4px' }}>
                      {title}
                    </h3>
                    <p style={{ color: 'var(--color-mid, #64748B)', fontSize: '0.92rem', lineHeight: '1.6', whiteSpace: 'pre-line' }}>
                      {desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Instant WhatsApp Help Card */}
            <div style={{
              borderRadius: '20px',
              background: 'linear-gradient(135deg, #25D366 0%, #128C7E 100%)',
              padding: '32px', color: '#fff',
              boxShadow: '0 12px 32px rgba(37,211,102,0.2)',
            }}>
              <MessageSquare size={28} color="#fff" style={{ marginBottom: '16px' }} />
              <h3 style={{ fontSize: '1.2rem', fontWeight: '800', marginBottom: '8px' }}>Need instant resolution?</h3>
              <p style={{ color: 'rgba(255,255,255,0.9)', fontSize: '0.95rem', marginBottom: '24px', lineHeight: '1.6' }}>
                Skip the queue! Chat directly with our WhatsApp support team for live assistance with your orders.
              </p>
              <a href="https://wa.me/919373423799" target="_blank" rel="noreferrer" style={{
                display: 'inline-flex', alignItems: 'center', gap: '8px',
                background: '#fff', color: '#128C7E', padding: '12px 24px', 
                borderRadius: '10px', textDecoration: 'none', fontWeight: '700', fontSize: '0.95rem',
                transition: 'transform 0.2s'
              }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'none'}
              >
                Message on WhatsApp <ArrowRight size={16} />
              </a>
            </div>
          </motion.div>

          {/* Right: Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            style={{
              background: 'var(--color-bg, #fff)', borderRadius: '24px', padding: 'clamp(32px, 4vw, 48px)',
              border: '1px solid var(--color-border, #E2E8F0)', boxShadow: '0 8px 40px rgba(0,0,0,0.03)'
            }}
          >
            <h3 style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--color-dark, #1E293B)', marginBottom: '8px' }}>
              Send us a message
            </h3>
            <p style={{ color: 'var(--color-mid, #64748B)', fontSize: '0.95rem', marginBottom: '32px' }}>
              Fill out the form below and our team will get back to you within 24 hours.
            </p>

            <form onSubmit={handleSubmit} noValidate>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '20px' }}>
                {/* Name */}
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '600', color: 'var(--color-dark, #1E293B)', marginBottom: '8px' }}>Full Name</label>
                  <input 
                    type="text" name="name" value={form.name} onChange={handleChange} placeholder="Jane Doe" 
                    style={{
                      width: '100%', padding: '14px 16px', borderRadius: '12px',
                      border: `1.5px solid ${errors.name ? '#EF4444' : 'var(--color-border, #E2E8F0)'}`,
                      background: '#fff', fontSize: '0.95rem', color: 'var(--color-dark, #1E293B)', outline: 'none',
                      transition: 'border-color 0.2s', fontFamily: 'inherit'
                    }}
                    onFocus={e => { if (!errors.name) e.target.style.borderColor = 'var(--color-primary, #2563EB)' }}
                    onBlur={e => { if (!errors.name) e.target.style.borderColor = 'var(--color-border, #E2E8F0)' }}
                  />
                  {errors.name && <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#EF4444', fontSize: '0.8rem', marginTop: '6px', fontWeight: '500' }}><AlertCircle size={12}/> {errors.name}</span>}
                </div>
                {/* Email */}
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '600', color: 'var(--color-dark, #1E293B)', marginBottom: '8px' }}>Email Address</label>
                  <input 
                    type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@email.com" 
                    style={{
                      width: '100%', padding: '14px 16px', borderRadius: '12px',
                      border: `1.5px solid ${errors.email ? '#EF4444' : 'var(--color-border, #E2E8F0)'}`,
                      background: '#fff', fontSize: '0.95rem', color: 'var(--color-dark, #1E293B)', outline: 'none',
                      transition: 'border-color 0.2s', fontFamily: 'inherit'
                    }}
                    onFocus={e => { if (!errors.email) e.target.style.borderColor = 'var(--color-primary, #2563EB)' }}
                    onBlur={e => { if (!errors.email) e.target.style.borderColor = 'var(--color-border, #E2E8F0)' }}
                  />
                  {errors.email && <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#EF4444', fontSize: '0.8rem', marginTop: '6px', fontWeight: '500' }}><AlertCircle size={12}/> {errors.email}</span>}
                </div>
              </div>

              {/* Subject */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '600', color: 'var(--color-dark, #1E293B)', marginBottom: '8px' }}>How can we help?</label>
                <select 
                  name="subject" value={form.subject} onChange={handleChange} 
                  style={{
                    width: '100%', padding: '14px 16px', borderRadius: '12px',
                    border: '1.5px solid var(--color-border, #E2E8F0)', background: '#fff', 
                    fontSize: '0.95rem', color: 'var(--color-dark, #1E293B)', outline: 'none', cursor: 'pointer',
                    fontFamily: 'inherit'
                  }}
                  onFocus={e => e.target.style.borderColor = 'var(--color-primary, #2563EB)'}
                  onBlur={e => e.target.style.borderColor = 'var(--color-border, #E2E8F0)'}
                >
                  <option>Daily Delivery Issue</option>
                  <option>Subscription Modification</option>
                  <option>Vendor / Partner with us</option>
                  <option>Billing & Refunds</option>
                  <option>General Inquiry</option>
                </select>
              </div>

              {/* Message */}
              <div style={{ marginBottom: '32px' }}>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '600', color: 'var(--color-dark, #1E293B)', marginBottom: '8px' }}>Your Message</label>
                <textarea 
                  name="message" value={form.message} onChange={handleChange} 
                  placeholder="Provide details about your query..." 
                  style={{
                    width: '100%', padding: '14px 16px', borderRadius: '12px',
                    border: `1.5px solid ${errors.message ? '#EF4444' : 'var(--color-border, #E2E8F0)'}`,
                    background: '#fff', fontSize: '0.95rem', color: 'var(--color-dark, #1E293B)', outline: 'none',
                    minHeight: '140px', resize: 'vertical', transition: 'border-color 0.2s', fontFamily: 'inherit'
                  }}
                  onFocus={e => { if (!errors.message) e.target.style.borderColor = 'var(--color-primary, #2563EB)' }}
                  onBlur={e => { if (!errors.message) e.target.style.borderColor = 'var(--color-border, #E2E8F0)' }}
                />
                {errors.message && <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#EF4444', fontSize: '0.8rem', marginTop: '6px', fontWeight: '500' }}><AlertCircle size={12}/> {errors.message}</span>}
              </div>

              {/* Submit Button */}
              <button type="submit" disabled={loading} style={{
                width: '100%', padding: '16px', borderRadius: '12px',
                background: 'var(--color-primary, #2563EB)', color: '#fff', border: 'none',
                fontSize: '1rem', fontWeight: '700', cursor: loading ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
                transition: 'all 0.2s', boxShadow: '0 4px 16px rgba(37,99,235,0.25)'
              }}
              onMouseEnter={e => { if(!loading) { e.currentTarget.style.background = '#1E3A8A'; e.currentTarget.style.transform = 'translateY(-2px)'; } }}
              onMouseLeave={e => { if(!loading) { e.currentTarget.style.background = 'var(--color-primary, #2563EB)'; e.currentTarget.style.transform = 'none'; } }}
              >
                {loading ? (
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} style={{ display: 'flex' }}>
                    <RefreshSpinner />
                  </motion.div>
                ) : (
                  <><Send size={18} /> Send Message</>
                )}
              </button>

              {/* Success Message Overlay */}
              <AnimatePresence>
                {success && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, height: 0 }} animate={{ opacity: 1, y: 0, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                    style={{ marginTop: '20px', padding: '16px', background: '#F0FDF4', border: '1px solid #BBF7D0', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '12px', color: '#15803D' }}
                  >
                    <CheckCircle2 size={20} color="#22C55E" />
                    <span style={{ fontWeight: '600', fontSize: '0.95rem' }}>Message sent successfully! We'll reply shortly.</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </form>
          </motion.div>
        </div>
      </section>

    </div>
  )
}

// Simple Loading Spinner SVG for Button
const RefreshSpinner = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
  </svg>
)