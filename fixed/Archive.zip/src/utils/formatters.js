// src/utils/formatters.js

// Helper to safely extract Y, M, D, h, m, s from either "YYYY-MM-DD" or a full ISO timestamp.
const extractParts = (input) => {
  if (!input) return null;
  const d = input instanceof Date ? input : new Date(input);
  if (isNaN(d.getTime())) return null;

  let hour = d.getHours();
  const ampm = hour >= 12 ? 'pm' : 'am';
  hour = hour % 12;
  if (hour === 0) hour = 12;

  return {
    day: String(d.getDate()).padStart(2, '0'),
    month: String(d.getMonth() + 1).padStart(2, '0'),
    year: d.getFullYear(),
    hour: String(hour).padStart(2, '0'),
    minute: String(d.getMinutes()).padStart(2, '0'),
    second: String(d.getSeconds()).padStart(2, '0'),
    ampm
  };
};

// Output: "21-08-2026"
export const formatDate = (input) => {
  const p = extractParts(input);
  if (!p) return '';
  return `${p.day}-${p.month}-${p.year}`;
};

// Output: "21-08-2026 09:18:47 pm"
export const formatDateTime = (input) => {
  const p = extractParts(input);
  if (!p) return '';
  return `${p.day}-${p.month}-${p.year} ${p.hour}:${p.minute}:${p.second} ${p.ampm}`;
};

// Output: "21-08-2026 09:18:47 pm" (Alias for backwards compatibility)
export const formatIsoDateTime = (input) => {
  return formatDateTime(input);
};

// Output: "Aug-2026" (For the Bills Tab)
export const formatMonth = (input) => {
  const p = extractParts(input);
  if (!p) return '';
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const mIndex = parseInt(p.month, 10) - 1;
  return `${monthNames[mIndex]}-${p.year}`;
};