// Generates a complete, self-contained HTML document for the invoice.
// Deliberately NOT relying on the parent app's stylesheet (CoreUI/Bootstrap)
// at all -- that's what caused the unstyled render before. This function
// returns a full <html>...</html> string with its own inline <style>,
// meant to be rendered inside an <iframe srcDoc={...}> so it gets its own
// isolated CSSOM, immune to whatever cascade/specificity exists in the
// rest of the admin panel.

const sumField = (items, field) =>
  (items ?? []).reduce((acc, item) => acc + Number(item[field] ?? 0), 0)

export function generateInvoiceHtml(order) {
  if (!order) return '<html><body>No order data.</body></html>'

  const items = order.items ?? []
  const address = order.delivery_address ?? {}
  const branch = order.branch ?? {}
  const customer = order.customer ?? {}

  const totalTax  = sumField(items, 'tax_amount')
  const totalCgst = sumField(items, 'cgst_amount')
  const totalSgst = sumField(items, 'sgst_amount')
  const totalIgst = sumField(items, 'igst_amount')
  const taxType   = items[0]?.tax_type ?? null
  const taxableValue = (Number(order.subtotal) - totalTax).toFixed(2)

  const itemRows = items.map((item) => `
    <tr>
      <td>
        ${item.variant?.product?.name ?? 'Item'}
        ${Number(item.discount_percent) > 0
          ? `<span class="disc"> (-${item.discount_percent}%)</span>`
          : ''}
      </td>
      <td class="c">${item.quantity}</td>
      <td class="r">
        ${Number(item.discount_percent) > 0
          ? `<span class="strike">₹${item.mrp}</span> ₹${item.unit_price}`
          : `₹${item.unit_price}`}
      </td>
      <td class="r">₹${item.line_total}</td>
    </tr>
  `).join('')

  const taxRows = totalTax > 0 ? `
    <div class="dashed"></div>
    <div class="row"><span>Taxable Value</span><span>₹${taxableValue}</span></div>
    ${taxType === 'igst'
      ? `<div class="row"><span>IGST</span><span>₹${totalIgst.toFixed(2)}</span></div>`
      : `<div class="row"><span>CGST</span><span>₹${totalCgst.toFixed(2)}</span></div>
         <div class="row"><span>SGST</span><span>₹${totalSgst.toFixed(2)}</span></div>`}
  ` : ''

  const couponRow = Number(order.coupon_discount) > 0 ? `
    <div class="row">
      <span>Coupon${order.coupon_code ? ` (${order.coupon_code})` : ''}</span>
      <span>-₹${order.coupon_discount}</span>
    </div>
  ` : ''

  return `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
  * { box-sizing: border-box; }
  body {
    font-family: 'Courier New', monospace;
    font-size: 12px;
    line-height: 1.5;
    color: #111;
    margin: 0;
    padding: 16px;
  }
  .slip { width: 300px; margin: 0 auto; }
  .center { text-align: center; }
  .brand { font-weight: bold; font-size: 15px; }
  .title {
    text-align: center; font-weight: bold; margin: 10px 0;
    letter-spacing: 1px; font-size: 13px;
  }
  .row { display: flex; justify-content: space-between; gap: 8px; margin: 2px 0; }
  .dashed { border-top: 1px dashed #999; margin: 8px 0; }
  .addr { font-size: 11px; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; margin: 4px 0; }
  th, td { padding: 3px 0; text-align: left; }
  .c { text-align: center; }
  .r { text-align: right; }
  .strike { text-decoration: line-through; color: #888; margin-right: 4px; }
  .disc { color: #888; font-size: 10px; }
  .total { font-weight: bold; font-size: 15px; margin-top: 6px; }
  .footer { margin-top: 14px; font-size: 11px; color: #555; }
  @media print {
    body { padding: 0; }
  }
</style>
</head>
<body>
  <div class="slip">
    <div class="center">
      <div class="brand">${branch.name ?? 'Branch'}</div>
      ${branch.address ? `<div>${branch.address}</div>` : ''}
      ${(branch.phone || branch.contact_email)
        ? `<div>${[branch.phone, branch.contact_email].filter(Boolean).join(' · ')}</div>`
        : ''}
      ${branch.gst_no ? `<div>GSTIN: ${branch.gst_no}</div>` : ''}
      ${branch.fssai_no ? `<div>FSSAI: ${branch.fssai_no}</div>` : ''}
    </div>

    <div class="title">TAX INVOICE</div>

    <div class="row"><span>${order.order_number ?? `Order #${order.id}`}</span><span>${order.created_at ? new Date(order.created_at).toLocaleString() : '—'}</span></div>
    <div class="row"><span>${customer.name ?? '—'}</span><span>${order.payment_mode === 'cod' ? 'COD' : 'Online'}</span></div>
    ${customer.phone ? `<div class="row"><span>${customer.phone}</span></div>` : ''}

    <div class="dashed"></div>

    <div class="addr">
      ${address.name ? `<div>${address.name}</div>` : ''}
      ${address.phone ? `<div>${address.phone}</div>` : ''}
      ${address.line1 ? `<div>${address.line1}</div>` : ''}
      ${(address.city || address.pincode) ? `<div>${address.city ?? ''}${address.pincode ? ` - ${address.pincode}` : ''}</div>` : ''}
    </div>

    <div class="dashed"></div>

    <table>
      <thead>
        <tr><th>Item</th><th class="c">Qty</th><th class="r">Rate</th><th class="r">Amt</th></tr>
      </thead>
      <tbody>
        ${itemRows}
      </tbody>
    </table>

    <div class="dashed"></div>

    <div class="row"><span>Subtotal</span><span>₹${order.subtotal}</span></div>
    ${couponRow}
    <div class="row"><span>Delivery Charge</span><span>₹${order.delivery_charge}</span></div>

    ${taxRows}

    <div class="dashed"></div>

    <div class="row total"><span>TOTAL</span><span>₹${order.total}</span></div>

    <div class="center footer">Thank you for your order!</div>
  </div>
</body>
</html>
  `
}