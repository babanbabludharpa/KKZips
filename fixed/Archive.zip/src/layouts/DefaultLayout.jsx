import { AppContent, AppSidebar, AppHeader } from '../components/index'
import useUiStore from '../store/uiStore'
import AppToaster from '../components/AppToaster'
import useIsMobile from '../hooks/useIsMobile'

const DefaultLayout = () => {
  const sidebarVisible = useUiStore(s => s.sidebarVisible)
  const isMobile = useIsMobile()

    return (
    <div className="app-shell">
      <AppSidebar />
      <div className="app-shell__backdrop" />
      <div
        className="wrapper app-shell__main d-flex flex-column"
        style={{
          marginLeft: isMobile
            ? 0
            : sidebarVisible
              ? 'var(--sidebar-width)'
              : 'var(--sidebar-collapsed)',
          transition: 'margin-left 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)',
        }}
      >
        <AppHeader />
        <div className="body flex-grow-1 app-shell__content">
          <AppContent />
        </div>
      </div>
      <AppToaster />
    </div>
  )
}

export default DefaultLayout