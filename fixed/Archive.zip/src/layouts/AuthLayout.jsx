import { CContainer } from '@coreui/react'

const AuthLayout = ({ children }) => {
  return (
    <div className="auth-shell min-vh-100 d-flex flex-row align-items-center">
      <div className="auth-shell__orb auth-shell__orb--one" />
      <div className="auth-shell__orb auth-shell__orb--two" />
      <div className="auth-shell__mesh" />
      <CContainer className="position-relative">
        {children}
      </CContainer>
    </div>
  )
}

export default AuthLayout
