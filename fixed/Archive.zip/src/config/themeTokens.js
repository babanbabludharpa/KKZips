// src/config/themeTokens.js
//
// Theme list is fetched from the backend (config/themes.php) at runtime.
// This file only caches + exposes them for the picker.

import api from '../api/api'

const DEFAULT_TEMPLATE = 'crimson'

let _cache  = null   // resolved array of { key, label, description, preview }
let _promise = null  // in-flight request

export async function fetchThemes() {
  if (_cache) return _cache
  if (_promise) return _promise

  _promise = api
    .get('/themes')
    .then((res) => {
      const list = res.data?.data ?? []
      _cache = list
      return list
    })
    .catch((err) => {
      console.error('[themeTokens] Failed to fetch themes:', err)
      // Fallback so the picker doesn't render empty if the API fails
      _cache = [
        { key: 'crimson', label: 'Crimson', description: 'Default', preview: '#dc2626' },
      ]
      return _cache
    })
    .finally(() => {
      _promise = null
    })

  return _promise
}

export function getCachedThemes() {
  return _cache ?? []
}

export function getDefaultTemplate() {
  return DEFAULT_TEMPLATE
}

export { DEFAULT_TEMPLATE }