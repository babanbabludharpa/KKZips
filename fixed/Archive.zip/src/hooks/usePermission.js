import useAuthStore from '../store/authStore'

const usePermission = () => {
  const hasPermission    = useAuthStore((s) => s.hasPermission)
  const hasRole          = useAuthStore((s) => s.hasRole)
  const hasAnyPermission = useAuthStore((s) => s.hasAnyPermission)
  const role             = useAuthStore((s) => s.role)
  const permissions      = useAuthStore((s) => s.permissions)

  return { hasPermission, hasRole, hasAnyPermission, role, permissions }
}

export default usePermission
