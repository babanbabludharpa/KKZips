import { useState, useEffect } from 'react'

/**
 * Reactive mobile/desktop breakpoint check.
 * Unlike a plain `window.innerWidth < 992` read at render time,
 * this updates automatically on resize/orientation change so the
 * sidebar/backdrop never get stuck with a stale value.
 */
export default function useIsMobile(breakpoint = 992) {
  const [isMobile, setIsMobile] = useState(
    () => window.innerWidth < breakpoint
  )

  useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${breakpoint - 0.02}px)`)
    const handleChange = (e) => setIsMobile(e.matches)
    handleChange(mql)
    mql.addEventListener('change', handleChange)
    return () => mql.removeEventListener('change', handleChange)
  }, [breakpoint])

  return isMobile
}