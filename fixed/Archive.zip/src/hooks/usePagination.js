import { useState, useCallback } from 'react'

export const usePagination = (initialPerPage = 25) => {
  const [meta, setMeta] = useState({
    current_page: 1,
    last_page: 1,
    total: 0,
    per_page: initialPerPage,
    from: 0,
    to: 0
  })
  const [perPage, setPerPage] = useState(initialPerPage)
  const [pageLoading, setPageLoading] = useState(false)

  const updatePagination = useCallback((data) => {
    setMeta({
      current_page: data.current_page || 1,
      last_page: data.last_page || 1,
      total: data.total || 0,
      per_page: data.per_page || perPage,
      from: data.from || 0,
      to: data.to || 0,
    })
  }, [perPage])

  const goToPage = useCallback((page, fetchData) => {
    if (page === meta.current_page || page < 1 || page > meta.last_page) return
    setPageLoading(true)
    fetchData({ page })
  }, [meta])

  const handlePerPageChange = useCallback((e, fetchData) => {
    const val = Number(e.target.value)
    setPerPage(val)
    setPageLoading(true)
    fetchData({ page: 1, perPageOverride: val })
  }, [])

  return {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
    setPerPage
  }
}