import api from '../api/api'

const supportReportApi = {
  async conversations(params = {}) {
    const { data } = await api.get('/reports/support/conversations', { params })
    return { items: data.data, meta: data.meta }
  },

  async conversationDetail(id) {
    const { data } = await api.get(`/reports/support/conversations/${id}`)
    return data.data
  },

  async customers(params = {}) {
    const { data } = await api.get('/reports/support/customers', { params })
    return { items: data.data, meta: data.meta }
  },

  async unmatched(params = {}) {
    const { data } = await api.get('/reports/support/unmatched', { params })
    return { items: data.data, meta: data.meta }
  },
}

export default supportReportApi