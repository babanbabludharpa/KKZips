import api from '../api/api'

/**
 * Admin FAQ management API client.
 *
 * All endpoints require the `faq.manage` permission. Tenant scoping
 * is handled server-side by the tenant middleware — no explicit
 * tenant header needed here (api.js already handles auth).
 */
const faqApi = {
  // ── Collections ────────────────────────────────────────────
  async listCollections() {
    const { data } = await api.get('/settings/faq/collections')
    return data.data
  },

  // ── Collections (write) ────────────────────────────────────
  async createCollection(payload) {
    const { data } = await api.post('/settings/faq/collections', payload)
    return data.data
  },

  async updateCollection(id, payload) {
    const { data } = await api.put(`/settings/faq/collections/${id}`, payload)
    return data.data
  },

  async deleteCollection(id) {
    await api.delete(`/settings/faq/collections/${id}`)
  },

  // ── FAQ items ──────────────────────────────────────────────
  async listItems(params = {}) {
    const { data } = await api.get('/settings/faq/items', { params })
    return { items: data.data, meta: data.meta }
  },

  async getItem(id) {
    const { data } = await api.get(`/settings/faq/items/${id}`)
    return data.data
  },

  async createItem(payload) {
    const { data } = await api.post('/settings/faq/items', payload)
    return data.data
  },

  async updateItem(id, payload) {
    const { data } = await api.put(`/settings/faq/items/${id}`, payload)
    return data.data
  },

  async deleteItem(id) {
    await api.delete(`/settings/faq/items/${id}`)
  },

  // ── Unmatched ──────────────────────────────────────────────
  async listUnmatched(params = {}) {
    const { data } = await api.get('/settings/faq/unmatched', { params })
    return { items: data.data, meta: data.meta }
  },

  async convertUnmatched(id, payload) {
    const { data } = await api.post(`/settings/faq/unmatched/${id}/convert`, payload)
    return data.data
  },

  async dismissUnmatched(id) {
    await api.delete(`/settings/faq/unmatched/${id}`)
  },

  // ── Test bot ───────────────────────────────────────────────
  async testQuestion(question) {
    const { data } = await api.post('/settings/faq/test', { question })
    return data.data
  },
}

export default faqApi