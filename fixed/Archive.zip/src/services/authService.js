const API_URL = import.meta.env.VITE_API_URL;
console.log('Auth API URL:', API_URL);

export const loginUser = async (data) => {
    console.log('Auth login request', data, `${API_URL}/auth/login`);
    const response = await fetch(
        `${API_URL}/auth/login`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(data)
        }
    );

    const json = await response.json();

    if (response.ok && json.data && json.data.token) {
        localStorage.setItem('token', json.data.token);
    }

    return json;
};

export const logoutUser = async () => {
    const token = localStorage.getItem('token');

    if (!token) return { status: false, message: 'Not logged in' };

    const response = await fetch(
        `${API_URL}/auth/logout`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            }
        }
    );

    try {
        const json = await response.json();
        localStorage.removeItem('token');
        return json;
    } catch (err) {
        localStorage.removeItem('token');
        return { status: true, message: 'Logged out' };
    }
};