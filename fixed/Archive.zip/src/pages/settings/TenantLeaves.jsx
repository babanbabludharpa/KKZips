import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CButton, CSpinner, CAlert, CForm,
  CFormLabel, CFormInput, CFormSelect, CFormTextarea, CBadge,
  CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilPencil, cilX, cilCheck, cilReload } from '@coreui/icons'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import { formatDate, formatDateTime } from '../../utils/formatters'

const LEAVES_API   = '/settings/leaves'
const BRANCHES_API = '/settings/branches'
const SLOTS_API    = '/settings/slots'

const WEEKDAYS = [
  { value: 0, label: 'Sunday' },
  { value: 1, label: 'Monday' },
  { value: 2, label: 'Tuesday' },
  { value: 3, label: 'Wednesday' },
  { value: 4, label: 'Thursday' },
  { value: 5, label: 'Friday' },
  { value: 6, label: 'Saturday' },
]

const ordinal = (n) => {
  const s = ['th', 'st', 'nd', 'rd']
  const v = n % 100
  return n + (s[(v - 20) % 10] || s[v] || s[0])
}

const MONTH_DAYS = Array.from({ length: 31 }, (_, i) => ({ value: i + 1, label: ordinal(i + 1) }))

const todayISO = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

// Extract the LOCAL calendar date as "YYYY-MM-DD" from any input
// (ISO string, date string, Date object). Never slices the raw string —
// slicing a UTC ISO of an IST midnight would return the wrong day.
const toLocalISODate = (input) => {
  if (!input) return ''
  const d = new Date(input)
  if (isNaN(d.getTime())) return ''
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const toArray = (resp, nestedKey = null) => {
  const d = resp?.data?.data
  if (Array.isArray(d)) return d
  if (nestedKey && Array.isArray(d?.[nestedKey])) return d[nestedKey]
  if (Array.isArray(d?.data)) return d.data
  return []
}

const emptyForm = () => ({
  title: '', date_mode: 'single', start_date: '', end_date: '',
  branch_ids: [], slot_ids: [], reason: '',
  recur_type: '', recur_weekdays: [], recur_month_day: '',
  recur_nth_week: '', recur_nth_weekday: '',
})

const serializeRecurrence = (form) => {
  switch (form.recur_type) {
    case 'daily':        return 'daily'
    case 'weekly':       return form.recur_weekdays.length ? `weekly:${form.recur_weekdays.join(',')}` : null
    case 'monthly_day':  return form.recur_month_day ? `monthly:${form.recur_month_day}` : null
    case 'monthly_last': return 'monthly:last'
    case 'monthly_nth':  return (form.recur_nth_week && form.recur_nth_weekday !== '')
      ? `monthly_nth:${form.recur_nth_week}:${form.recur_nth_weekday}` : null
    default:             return null
  }
}

const deserializeRecurrence = (rule) => {
  const base = { recur_type: '', recur_weekdays: [], recur_month_day: '', recur_nth_week: '', recur_nth_weekday: '' }
  if (!rule) return base
  const parts = rule.split(':')
  const freq = parts[0]
  if (freq === 'daily') return { ...base, recur_type: 'daily' }
  if (freq === 'weekly') return { ...base, recur_type: 'weekly', recur_weekdays: (parts[1] ?? '').split(',').filter(Boolean).map(Number) }
  if (freq === 'monthly') return parts[1] === 'last'
    ? { ...base, recur_type: 'monthly_last' }
    : { ...base, recur_type: 'monthly_day', recur_month_day: parts[1] ?? '' }
  if (freq === 'monthly_nth') return { ...base, recur_type: 'monthly_nth', recur_nth_week: parts[1] ?? '', recur_nth_weekday: parts[2] ?? '' }
  return base
}

const buildDeliveryBoardUrl = (preview) => {
  if (!preview?.date_from || !preview?.date_to) return '#'
  const params = new URLSearchParams()
  params.set('date_from', preview.date_from)
  params.set('date_to',   preview.date_to)
  params.set('status',    'scheduled,assigned')
  if (Array.isArray(preview.branch_ids) && preview.branch_ids.length === 1) {
    params.set('branch_id', preview.branch_ids[0])
  }
  return `/subscriptions/delivery-assignment?${params.toString()}`
}

const LinkBtn = ({ onClick, disabled, children, className = '', style }) => (
  <button
    type="button"
    onClick={(e) => { e.preventDefault(); e.stopPropagation(); onClick?.(e) }}
    disabled={disabled}
    className={`btn btn-link btn-sm p-0 text-decoration-none ${className}`}
    style={style}
  >
    {children}
  </button>
)

const GhostBtn = ({ onClick, disabled, children, className = '' }) => (
  <button
    type="button"
    onClick={(e) => { e.preventDefault(); e.stopPropagation(); onClick?.(e) }}
    disabled={disabled}
    className={`filter-btn filter-btn--ghost ${className}`}
  >
    {children}
  </button>
)

const TenantLeaves = () => {
  const [leaves, setLeaves]               = useState([])
  const [loadingLeaves, setLoadingLeaves] = useState(true)
  const [leavesError, setLeavesError]     = useState(null)

  const [branches, setBranches]           = useState([])
  const [slots, setSlots]                 = useState([])
  const [loadingMasters, setLoadingMasters] = useState(true)
  const [mastersError, setMastersError]   = useState(null)

  const [error, setError]                 = useState(null)
  const [success, setSuccess]             = useState(null)

  const [modalOpen, setModalOpen]         = useState(false)
  const [editing, setEditing]             = useState(null)
  const [form, setForm]                   = useState(emptyForm())
  const [formError, setFormError]         = useState(null)
  const [preview, setPreview]             = useState(null)
  const [previewing, setPreviewing]       = useState(false)
  const [submitting, setSubmitting]       = useState(false)

  useEffect(() => { fetchLeaves(); fetchMasters() }, [])

  const fetchLeaves = async () => {
    setLoadingLeaves(true); setLeavesError(null)
    try {
      const res = await api.get(LEAVES_API)
      setLeaves(toArray(res))
    } catch (err) {
      console.error('Failed to load leaves', err?.response?.status, err?.response?.data)
      setLeavesError(err?.response?.data?.message ?? 'Failed to load leaves.')
    } finally {
      setLoadingLeaves(false)
    }
  }

  const fetchMasters = async () => {
    setLoadingMasters(true); setMastersError(null)
    try {
      const [bRes, sRes] = await Promise.all([
        api.get(BRANCHES_API, { params: { per_page: 100 } }),
        api.get(SLOTS_API),
      ])
      setBranches(toArray(bRes))
      setSlots(toArray(sRes).filter(s => s.is_active !== false))
    } catch (err) {
      console.error('Failed to load master data', err?.response?.status, err?.response?.data)
      setMastersError('Failed to load branches or slots. You can still create a leave without them.')
    } finally {
      setLoadingMasters(false)
    }
  }

  const openCreate = () => {
    setEditing(null); setForm(emptyForm())
    setPreview(null); setFormError(null); setModalOpen(true)
  }

  const openEdit = (leave) => {
    setEditing(leave)
    const recur = deserializeRecurrence(leave.recurrence_rule)
    setForm({
      title:      leave.title ?? '',
      date_mode:  leave.date_mode ?? 'single',
      start_date: toLocalISODate(leave.start_date),
      end_date:   toLocalISODate(leave.end_date),
      branch_ids: Array.isArray(leave.branch_ids) ? leave.branch_ids : [],
      slot_ids:   Array.isArray(leave.slot_ids)   ? leave.slot_ids   : [],
      reason:     leave.reason ?? '',
      ...recur,
    })
    setPreview(null); setFormError(null); setModalOpen(true)
  }

  const closeModal = () => {
    setModalOpen(false); setEditing(null)
    setForm(emptyForm()); setPreview(null); setFormError(null)
  }

  const buildPayload = () => ({
    title:           form.title?.trim(),
    date_mode:       form.date_mode,
    start_date:      form.start_date,
    end_date:        form.date_mode === 'single' ? form.start_date : form.end_date,
    recurrence_rule: form.date_mode === 'recurring' ? serializeRecurrence(form) : null,
    branch_ids:      form.branch_ids.length ? form.branch_ids : null,
    slot_ids:        form.slot_ids.length ? form.slot_ids : null,
    reason:          form.reason?.trim(),
  })

  const clientValidate = () => {
    const p = buildPayload()
    if (!p.title || p.title.length < 2) return 'Title must be at least 2 characters.'
    if (!p.start_date) return 'Start date is required.'
    if (p.start_date < todayISO()) return 'Leave cannot start in the past.'
    if (p.date_mode !== 'single') {
      if (!p.end_date) return 'End date is required.'
      if (p.date_mode === 'range' && p.end_date < p.start_date) return 'End date must be on or after start date.'
      if (p.date_mode === 'recurring' && p.end_date <= p.start_date) return 'Recurring leaves must span more than one day.'
    }
    if (p.date_mode === 'recurring' && !p.recurrence_rule) return 'Pick a recurrence for a recurring leave.'
    if (!p.reason || p.reason.length < 3) return 'Reason must be at least 3 characters.'
    return null
  }

  const doPreview = async () => {
    const v = clientValidate()
    if (v) { setFormError(v); return }
    setPreviewing(true); setFormError(null)
    try {
      const res = await api.post(`${LEAVES_API}/preview`, buildPayload())
      setPreview(res.data?.data ?? null)
    } catch (err) {
      const msg = err.response?.data?.message || 'Preview failed.'
      const errors = err.response?.data?.errors
      setFormError(errors ? Object.values(errors).flat().join(' ') : msg)
    } finally {
      setPreviewing(false)
    }
  }

  const doSave = async (e) => {
    e.preventDefault()
    const v = clientValidate()
    if (v) { setFormError(v); return }
    setSubmitting(true); setFormError(null)
    try {
      const payload = buildPayload()
      const res = editing
        ? await api.put(`${LEAVES_API}/${editing.id}`, payload)
        : await api.post(LEAVES_API, payload)
      const counts = res.data?.data?.counts ?? {}
      setSuccess(`Leave saved. Cancelled: ${counts.cancelled ?? 0}, reactivated: ${counts.reactivated ?? 0}, skipped (already in progress): ${counts.skipped_status ?? 0}.`)
      closeModal()
      fetchLeaves()
    } catch (err) {
      const msg = err.response?.data?.message || 'Save failed.'
      const errors = err.response?.data?.errors
      setFormError(errors ? Object.values(errors).flat().join(' ') : msg)
    } finally {
      setSubmitting(false)
    }
  }

  const doCancelLeave = async (leave) => {
    if (!window.confirm(`Cancel "${leave.title}"? Deliveries it cancelled will be restored if no other leave covers them.`)) return
    try {
      const res = await api.post(`${LEAVES_API}/${leave.id}/cancel`)
      const counts = res.data?.data?.counts ?? {}
      setSuccess(`Leave cancelled. Reactivated: ${counts.reactivated ?? 0} deliveries.`)
      fetchLeaves()
    } catch (err) {
      setError(err.response?.data?.message || 'Cancel failed.')
    }
  }

  const toggleBranch = (id) => setForm(f => ({
    ...f,
    branch_ids: f.branch_ids.includes(id) ? f.branch_ids.filter(x => x !== id) : [...f.branch_ids, id],
  }))

  const toggleSlot = (id) => setForm(f => ({
    ...f,
    slot_ids: f.slot_ids.includes(id) ? f.slot_ids.filter(x => x !== id) : [...f.slot_ids, id],
  }))

  const branchLabel = (ids) => {
    if (!ids || ids.length === 0) return 'All branches'
    if (ids.length > 3) return `${ids.length} branches`
    return ids.map(id => branches.find(b => b.id === id)?.name ?? `#${id}`).join(', ')
  }

  const slotLabel = (ids) => {
    if (!ids || ids.length === 0) return 'All slots (full day)'
    if (ids.length > 3) return `${ids.length} slots`
    return ids.map(id => slots.find(s => s.id === id)?.name ?? `#${id}`).join(', ')
  }

  const recurrenceLabel = (rule) => {
    if (!rule) return '—'
    if (rule === 'daily') return 'Every day'
    if (rule === 'monthly:last') return 'Last day of every month'
    if (rule.startsWith('weekly:')) {
      const days = rule.slice(7).split(',').map(Number)
      return 'Every ' + days.map(d => WEEKDAYS[d]?.label ?? d).join(', ')
    }
    if (rule.startsWith('monthly_nth:')) {
      const [, w, d] = rule.split(':')
      return `${ordinal(Number(w))} ${WEEKDAYS[Number(d)]?.label ?? d} of every month`
    }
    if (rule.startsWith('monthly:')) return `${ordinal(Number(rule.split(':')[1]))} of every month`
    return rule
  }

  const dateModeLabel = (l) => {
    if (l.date_mode === 'recurring') return 'Recurring'
    if (l.date_mode === 'range') return 'Range'
    if (l.date_mode === 'single') return 'Single day'
    return '—'
  }

  // Format the raw API value via formatDate (which normalizes timezones),
  // never via a naive .slice(0, 10) on a UTC ISO string.
  const dateLabel = (l) => {
    const s = l?.start_date ? formatDate(l.start_date) : ''
    const e = l?.end_date   ? formatDate(l.end_date)   : ''
    if (!s) return '—'
    if (l.date_mode === 'single') return s
    if (!e || s === e) return s
    return `${s} → ${e}`
  }

  const createdLabel = (l) => {
    if (!l?.created_at) return '—'
    return formatDateTime(l.created_at)
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Tenant Leaves</h4>
          <div className="d-flex gap-2">
            <CButton type="button" size="sm" className="report-shell__export" onClick={fetchLeaves} disabled={loadingLeaves}>
              <CIcon icon={cilReload} className="me-1" />Reload
            </CButton>
            <PermissionGate permission="profile.leaves_edit">
              <CButton type="button" size="sm" className="report-shell__export" onClick={openCreate}>
                <CIcon icon={cilPlus} className="me-2" />Add Leave
              </CButton>
            </PermissionGate>
          </div>
        </div>

        {error && <div className="report-shell__error"><CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert></div>}
        {success && <div className="report-shell__error"><CAlert color="success" dismissible onClose={() => setSuccess(null)}>{success}</CAlert></div>}
        {leavesError && (
          <div className="report-shell__error">
            <CAlert color="danger">
              {leavesError}
              <CButton type="button" size="sm" color="danger" variant="ghost" className="ms-2" onClick={fetchLeaves}>Retry</CButton>
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loadingLeaves ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading leaves...</div>
            </div>
          ) : (
            <CTable hover responsive bordered className="admin-data-table">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Title</CTableHeaderCell>
                  <CTableHeaderCell>Type</CTableHeaderCell>
                  <CTableHeaderCell>Dates</CTableHeaderCell>
                  <CTableHeaderCell>Branches</CTableHeaderCell>
                  <CTableHeaderCell>Slots</CTableHeaderCell>
                  <CTableHeaderCell>Recurrence</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                  <CTableHeaderCell>Created On</CTableHeaderCell>
                  <CTableHeaderCell style={{ width: 150 }}>Actions</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {leaves.length === 0 ? (
                  <CTableRow>
                    <CTableDataCell colSpan={9} className="text-center text-muted py-4">No leaves defined yet.</CTableDataCell>
                  </CTableRow>
                ) : leaves.map(l => (
                  <CTableRow key={l.id}>
                    <CTableDataCell>{l.title}</CTableDataCell>
                    <CTableDataCell><CBadge color="info" shape="rounded-pill">{dateModeLabel(l)}</CBadge></CTableDataCell>
                    <CTableDataCell>{dateLabel(l)}</CTableDataCell>
                    <CTableDataCell>{branchLabel(l.branch_ids)}</CTableDataCell>
                    <CTableDataCell>{slotLabel(l.slot_ids)}</CTableDataCell>
                    <CTableDataCell>{recurrenceLabel(l.recurrence_rule)}</CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={l.status === 'active' ? 'success' : 'secondary'} shape="rounded-pill">{l.status}</CBadge>
                    </CTableDataCell>
                    <CTableDataCell className="text-muted small">{createdLabel(l)}</CTableDataCell>
                    <CTableDataCell>
                      {l.status === 'active' && (
                        <div className="d-flex gap-1">
                          <PermissionGate permission="profile.leaves_edit">
                            <CButton type="button" size="sm" color="warning" variant="outline" onClick={() => openEdit(l)} title="Edit">
                              <CIcon icon={cilPencil} />
                            </CButton>
                          </PermissionGate>
                          <PermissionGate permission="profile.leaves_edit">
                            <CButton type="button" size="sm" color="danger" variant="outline" onClick={() => doCancelLeave(l)} title="Cancel leave">
                              <CIcon icon={cilX} />
                            </CButton>
                          </PermissionGate>
                        </div>
                      )}
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          )}
        </CCardBody>
      </CCard>

      <CModal visible={modalOpen} onClose={closeModal} backdrop="static" size="lg">
        <CModalHeader>
          <CModalTitle>{editing ? 'Edit Leave' : 'Add Leave'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={doSave} noValidate>
          <CModalBody style={{ maxHeight: '75vh', overflowY: 'auto' }}>
            {formError && <CAlert color="danger">{formError}</CAlert>}

            <div className="mb-3">
              <CFormLabel className="filter-label">Title <span className="text-danger">*</span></CFormLabel>
              <CFormInput className="filter-input" value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Diwali Holiday, Weekly Sunday Off" maxLength={120} />
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">Date Type <span className="text-danger">*</span></CFormLabel>
              <div className="d-flex gap-4">
                {[
                  { v: 'single',    l: 'Single Day' },
                  { v: 'range',     l: 'Date Range' },
                  { v: 'recurring', l: 'Recurring' },
                ].map(opt => (
                  <div className="form-check" key={opt.v}>
                    <input type="radio" className="form-check-input" id={`mode-${opt.v}`}
                      name="date_mode" value={opt.v} checked={form.date_mode === opt.v}
                      onChange={() => setForm({ ...form, date_mode: opt.v })} />
                    <label className="form-check-label" htmlFor={`mode-${opt.v}`}>{opt.l}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="row g-3">
              <div className={form.date_mode === 'single' ? 'col-md-6' : 'col-md-4'}>
                <CFormLabel className="filter-label">
                  {form.date_mode === 'single' ? 'Date' : 'From Date'} <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput className="filter-input" type="date" min={todayISO()} value={form.start_date}
                  onChange={e => setForm({
                    ...form,
                    start_date: e.target.value,
                    end_date: form.date_mode === 'single' ? e.target.value : form.end_date,
                  })} />
              </div>
              {form.date_mode !== 'single' && (
                <div className="col-md-4">
                  <CFormLabel className="filter-label">
                    {form.date_mode === 'recurring' ? 'Horizon End Date' : 'To Date'} <span className="text-danger">*</span>
                  </CFormLabel>
                  <CFormInput className="filter-input" type="date" min={form.start_date || todayISO()} value={form.end_date}
                    onChange={e => setForm({ ...form, end_date: e.target.value })} />
                </div>
              )}
            </div>

            {form.date_mode === 'recurring' && (
              <div className="mt-3 p-3 border rounded bg-light">
                <CFormLabel className="filter-label">Recurrence <span className="text-danger">*</span></CFormLabel>
                <CFormSelect className="filter-input mb-2" value={form.recur_type}
                  onChange={e => setForm({ ...form, recur_type: e.target.value })}>
                  <option value="">— select a pattern —</option>
                  <option value="daily">Every day</option>
                  <option value="weekly">Every week on specific day(s)</option>
                  <option value="monthly_day">Every month on a specific day</option>
                  <option value="monthly_last">Every month on the last day</option>
                  <option value="monthly_nth">Every month on the Nth weekday</option>
                </CFormSelect>

                {form.recur_type === 'weekly' && (
                  <div className="d-flex flex-wrap gap-3">
                    {WEEKDAYS.map(d => (
                      <div className="form-check" key={d.value}>
                        <input type="checkbox" className="form-check-input" id={`wd-${d.value}`}
                          checked={form.recur_weekdays.includes(d.value)}
                          onChange={() => setForm({
                            ...form,
                            recur_weekdays: form.recur_weekdays.includes(d.value)
                              ? form.recur_weekdays.filter(x => x !== d.value)
                              : [...form.recur_weekdays, d.value],
                          })} />
                        <label className="form-check-label" htmlFor={`wd-${d.value}`}>{d.label}</label>
                      </div>
                    ))}
                  </div>
                )}

                {form.recur_type === 'monthly_day' && (
                  <CFormSelect className="filter-input" value={form.recur_month_day}
                    onChange={e => setForm({ ...form, recur_month_day: e.target.value })}>
                    <option value="">— pick day —</option>
                    {MONTH_DAYS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
                  </CFormSelect>
                )}

                {form.recur_type === 'monthly_nth' && (
                  <div className="row g-2">
                    <div className="col-md-6">
                      <CFormSelect className="filter-input" value={form.recur_nth_week}
                        onChange={e => setForm({ ...form, recur_nth_week: e.target.value })}>
                        <option value="">— which occurrence —</option>
                        <option value="1">1st</option><option value="2">2nd</option>
                        <option value="3">3rd</option><option value="4">4th</option>
                      </CFormSelect>
                    </div>
                    <div className="col-md-6">
                      <CFormSelect className="filter-input" value={form.recur_nth_weekday}
                        onChange={e => setForm({ ...form, recur_nth_weekday: e.target.value })}>
                        <option value="">— which day —</option>
                        {WEEKDAYS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
                      </CFormSelect>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="row g-3 mt-2">
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Branches
                  <span className="tenant-hint-inline">
                    {form.branch_ids.length === 0 ? ' · all branches' : ` · ${form.branch_ids.length} selected`}
                  </span>
                </CFormLabel>
                <div className="d-flex gap-3 mb-2 small">
                  <LinkBtn onClick={() => setForm(f => ({ ...f, branch_ids: branches.map(b => b.id) }))}
                    disabled={loadingMasters || branches.length === 0}>Select all</LinkBtn>
                  <LinkBtn className="text-muted"
                    onClick={() => setForm(f => ({ ...f, branch_ids: [] }))}
                    disabled={form.branch_ids.length === 0}>Clear</LinkBtn>
                </div>
                <div className="border rounded p-2" style={{ maxHeight: 180, overflowY: 'auto', background: '#fff' }}>
                  {loadingMasters ? (
                    <div className="text-center py-2"><CSpinner size="sm" /><span className="text-muted small ms-2">Loading branches…</span></div>
                  ) : mastersError ? (
                    <span className="text-danger small">{mastersError}</span>
                  ) : branches.length === 0 ? (
                    <span className="text-muted small">No branches configured.</span>
                  ) : branches.map(b => (
                    <div className="form-check" key={b.id}>
                      <input type="checkbox" className="form-check-input" id={`branch-${b.id}`}
                        checked={form.branch_ids.includes(b.id)} onChange={() => toggleBranch(b.id)} />
                      <label className="form-check-label" htmlFor={`branch-${b.id}`}>{b.name}</label>
                    </div>
                  ))}
                </div>
                <div className="tenant-hint mt-1">Leave empty to apply to <strong>all branches</strong>.</div>
              </div>

              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Slots
                  <span className="tenant-hint-inline">
                    {form.slot_ids.length === 0 ? ' · all slots (full day)' : ` · ${form.slot_ids.length} selected`}
                  </span>
                </CFormLabel>
                <div className="d-flex gap-3 mb-2 small">
                  <LinkBtn onClick={() => setForm(f => ({ ...f, slot_ids: slots.map(s => s.id) }))}
                    disabled={loadingMasters || slots.length === 0}>Select all</LinkBtn>
                  <LinkBtn className="text-muted"
                    onClick={() => setForm(f => ({ ...f, slot_ids: [] }))}
                    disabled={form.slot_ids.length === 0}>Clear</LinkBtn>
                </div>
                <div className="border rounded p-2" style={{ maxHeight: 180, overflowY: 'auto', background: '#fff' }}>
                  {loadingMasters ? (
                    <div className="text-center py-2"><CSpinner size="sm" /><span className="text-muted small ms-2">Loading slots…</span></div>
                  ) : mastersError ? (
                    <span className="text-danger small">{mastersError}</span>
                  ) : slots.length === 0 ? (
                    <span className="text-muted small">No active slots configured.</span>
                  ) : slots.map(s => (
                    <div className="form-check" key={s.id}>
                      <input type="checkbox" className="form-check-input" id={`slot-${s.id}`}
                        checked={form.slot_ids.includes(s.id)} onChange={() => toggleSlot(s.id)} />
                      <label className="form-check-label" htmlFor={`slot-${s.id}`}>
                        {s.name}<span className="text-muted small ms-1">({s.start_time}–{s.end_time})</span>
                      </label>
                    </div>
                  ))}
                </div>
                <div className="tenant-hint mt-1">Leave empty for a <strong>full-day leave</strong> (all slots closed).</div>
              </div>
            </div>

            <div className="mt-3">
              <CFormLabel className="filter-label">Reason (shown to customer) <span className="text-danger">*</span></CFormLabel>
              <CFormTextarea className="filter-input" rows={3} value={form.reason}
                onChange={e => setForm({ ...form, reason: e.target.value })}
                placeholder="e.g. Store closed for Diwali. Deliveries resume from 15 Nov."
                maxLength={500} />
            </div>

            <div className="mt-3">
              <GhostBtn onClick={doPreview} disabled={previewing}>
                {previewing ? <CSpinner size="sm" className="me-2" /> : null}
                Preview impact
              </GhostBtn>
            </div>

            {preview && (
              <CAlert color="info" className="mt-3 small">
                <strong>Impact preview:</strong>
                <br />Dates affected: {preview.dates?.length ?? 0}
                {(preview.dates?.length ?? 0) > 0 && (
                  <> ({preview.dates.slice(0, 5).join(', ')}{preview.dates.length > 5 ? '…' : ''})</>
                )}
                <br />Subscription occurrences affected: <strong>{preview.occurrences ?? 0}</strong>

                {preview.date_from && preview.date_to && (
                  <div className="mt-2 pt-2 border-top">
                    <a
                      href={buildDeliveryBoardUrl(preview)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="fw-bold"
                      style={{ fontSize: '0.85rem' }}
                    >
                      View affected deliveries in Delivery Board →
                    </a>
                    <div className="text-muted mt-1" style={{ fontSize: '0.72rem' }}>
                      Opens a new tab filtered to these dates
                      {preview.branch_ids?.length ? `, ${preview.branch_ids.length} branch(es)` : ', all branches'}
                      {preview.slot_ids?.length ? `, ${preview.slot_ids.length} slot(s)` : ', all slots'}.
                    </div>
                  </div>
                )}
              </CAlert>
            )}
          </CModalBody>
          <CModalFooter>
            <GhostBtn onClick={closeModal} disabled={submitting}>Cancel</GhostBtn>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : <CIcon icon={cilCheck} className="me-2" />}
              {editing ? 'Save Changes' : 'Create Leave'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>
    </div>
  )
}

export default TenantLeaves