import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CSpinner, CAlert, CBadge,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CForm, CFormLabel, CFormInput, CFormCheck,
  CTable, CTableHead, CTableRow, CTableHeaderCell,
  CTableBody, CTableDataCell, CBreadcrumb, CBreadcrumbItem,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilPencil, cilTrash } from '@coreui/icons'
import { MapContainer, TileLayer, Polygon, Tooltip, useMap } from 'react-leaflet'
import '@geoman-io/leaflet-geoman-free'
import L from 'leaflet'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'

const DEFAULT_CENTER = [20.5937, 78.9629]
const DEFAULT_ZOOM   = 5
const ZONE_COLORS    = ['#3388ff', '#ff6b35', '#28a745', '#ffc107', '#dc3545', '#6f42c1']

const MapInitializer = ({ center, zoom }) => {
  const map = useMap()
  useEffect(() => {
    if (center) map.setView(center, zoom, { animate: false })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return null
}

const MapFlyTo = ({ selectedZone }) => {
  const map = useMap()
  useEffect(() => {
    if (!selectedZone?.coordinates?.length) return
    const bounds = L.latLngBounds(selectedZone.coordinates.map(c => L.latLng(c[0], c[1])))
    map.flyToBounds(bounds, { padding: [40, 40], duration: 0.6 })
  }, [selectedZone, map])
  return null
}

const GeomanControl = ({ drawMode, onPolygonDrawn, onCancel }) => {
  const map = useMap()

  useEffect(() => {
    if (!map.pm) return

    if (drawMode) {
      map.pm.enableDraw('Polygon', { snappable: true, snapDistance: 20 })

      const handleCreate = (e) => {
        const latlngs = e.layer.getLatLngs()[0].map(p => [p.lat, p.lng])
        map.removeLayer(e.layer)
        map.pm.disableDraw()
        onPolygonDrawn(latlngs)
      }

      map.on('pm:create', handleCreate)

      const handleKeydown = (e) => {
        if (e.key === 'Escape') { map.pm.disableDraw(); onCancel() }
      }
      window.addEventListener('keydown', handleKeydown)

      return () => {
        map.off('pm:create', handleCreate)
        window.removeEventListener('keydown', handleKeydown)
        map.pm.disableDraw()
      }
    }
  }, [drawMode, map, onPolygonDrawn, onCancel])

  return null
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.zones)) return inner.zones
  if (Array.isArray(inner?.data)) return inner.data
  return []
}

const BranchZones = () => {
  const { branchId } = useParams()

  const [branch, setBranch] = useState(null)
  const [zones, setZones] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, zone: null, drawnCoords: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, zone: null })
  const [submitting, setSubmitting] = useState(false)
  const [drawMode, setDrawMode] = useState(false)
  const [selectedZone, setSelectedZone] = useState(null)
  const [mapCenter, setMapCenter] = useState(DEFAULT_CENTER)
  const [mapZoom, setMapZoom] = useState(DEFAULT_ZOOM)

  useEffect(() => {
    fetchBranch()
    fetchZones()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [branchId])

  useEffect(() => {
    if (branch?.latitude && branch?.longitude) {
      setMapCenter([parseFloat(branch.latitude), parseFloat(branch.longitude)])
      setMapZoom(17)
    }
  }, [branch])

  const fetchBranch = async () => {
    try {
      const res = await api.get(`/settings/branches/${branchId}`)
      setBranch(res.data?.data?.branch ?? res.data?.data)
    } catch {
      setError('Failed to load branch.')
    }
  }

  const fetchZones = async () => {
    try {
      setLoading(true)
      const res = await api.get(`/settings/branches/${branchId}/zones`)
      setZones(res.data?.data?.zones ?? [])
    } catch {
      setError('Failed to load zones.')
    } finally {
      setLoading(false)
    }
  }

  const onPolygonDrawn = (latlngs) => {
    setDrawMode(false)
    setModal({ open: true, zone: null, drawnCoords: latlngs })
    setModalError(null)
  }

  const onDrawCancel = () => setDrawMode(false)

  const toggleSelectZone = (zone) => {
    setSelectedZone(prev => prev?.id === zone.id ? null : zone)
  }

  const openEdit = (zone) => {
    setModal({ open: true, zone, drawnCoords: zone.coordinates })
    setModalError(null)
  }

  const closeModal = () => {
    setModal({ open: false, zone: null, drawnCoords: null })
    setModalError(null)
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    const formData = new FormData(e.target)
    const name     = formData.get('name')?.trim()
    const isActive = formData.get('is_active') === 'on'

    if (!name) { setModalError('Zone name is required.'); return }
    if (!modal.drawnCoords || modal.drawnCoords.length < 3) {
      setModalError('Invalid polygon coordinates.')
      return
    }

    setSubmitting(true)
    try {
      const payload = { name, is_active: isActive, coordinates: modal.drawnCoords }
      if (modal.zone) {
        await api.put(`/settings/branches/${branchId}/zones/${modal.zone.id}`, payload)
      } else {
        await api.post(`/settings/branches/${branchId}/zones`, payload)
      }
      closeModal()
      fetchZones()
    } catch (err) {
      setModalError(err.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/settings/branches/${branchId}/zones/${deleteModal.zone.id}`)
      setDeleteModal({ open: false, zone: null })
      fetchZones()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Delete failed.')
    }
  }

  const handleToggle = async (zone) => {
    try {
      await api.patch(`/settings/branches/${branchId}/zones/${zone.id}/toggle`)
      fetchZones()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Status update failed.')
    }
  }

  const handleToggleOrders = async () => {
    try {
      await api.patch(`/settings/branches/${branchId}/toggle-orders`)
      fetchBranch()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Failed to update order status.')
    }
  }

  if (loading) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading zones...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  return (
    <div className="report-page">
      <CBreadcrumb className="mb-2">
        <CBreadcrumbItem><Link to="/settings/branches">Branches</Link></CBreadcrumbItem>
        <CBreadcrumbItem active>{branch?.name ?? 'Branch'} — Service Zones</CBreadcrumbItem>
      </CBreadcrumb>

      <CCard className="report-shell">
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">
              {branch?.name} — Service Zones
            </h4>
            <div className="report-shell__price-summary" style={{ marginTop: 4 }}>
              <span>
                <strong>Status</strong>{' '}
                <span className={branch?.is_accepting_orders ? 'value' : 'value'}>
                  {branch?.is_accepting_orders ? 'Accepting Orders' : 'Orders Paused'}
                </span>
              </span>
              {branch?.opens_at && branch?.closes_at && (
                <>
                  <span className="sep">·</span>
                  <span>
                    <strong>Hours</strong>{' '}
                    <span className="value">{branch.opens_at} – {branch.closes_at}</span>
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="d-flex gap-2 flex-wrap">
            <PermissionGate permission="branch.edit">
              <CButton
                size="sm"
                className={branch?.is_accepting_orders ? 'filter-btn filter-btn--danger' : 'filter-btn filter-btn--primary'}
                onClick={handleToggleOrders}
              >
                {branch?.is_accepting_orders ? 'Pause Orders' : 'Resume Orders'}
              </CButton>
            </PermissionGate>
            <PermissionGate permission="branch.edit">
              <CButton
                size="sm"
                className="report-shell__export"
                onClick={() => setDrawMode(true)}
                disabled={drawMode}
              >
                <CIcon icon={cilPlus} className="me-2" />
                {drawMode ? 'Drawing…' : 'Draw New Zone'}
              </CButton>
            </PermissionGate>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {branch && !branch.latitude && (
          <div className="report-info-strip">
            <span>
              This branch has no coordinates set. Edit the branch to add latitude/longitude so the map centers correctly.
            </span>
          </div>
        )}

        {drawMode && (
          <div className="report-info-strip">
            <span>
              Click on the map to place polygon points. Click the first point to close
              the shape, or press <strong>Escape</strong> to cancel.
            </span>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost ms-auto"
              onClick={() => setDrawMode(false)}
            >
              Cancel Drawing
            </CButton>
          </div>
        )}

        {/* Map */}
        <CCardBody className="p-0">
          <div style={{ height: 480, width: '100%' }}>
            <MapContainer
              center={DEFAULT_CENTER}
              zoom={DEFAULT_ZOOM}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <MapInitializer center={mapCenter} zoom={mapZoom} />
              <GeomanControl drawMode={drawMode} onPolygonDrawn={onPolygonDrawn} onCancel={onDrawCancel} />
              <MapFlyTo selectedZone={selectedZone} />

              {zones.map((zone, idx) => {
                const isSelected = selectedZone?.id === zone.id
                const color = ZONE_COLORS[idx % ZONE_COLORS.length]
                return (
                  <Polygon
                    key={zone.id}
                    positions={zone.coordinates}
                    pathOptions={{
                      color,
                      weight:      isSelected ? 4 : 2,
                      fillOpacity: isSelected ? 0.45 : (zone.is_active ? 0.25 : 0.05),
                      opacity:     isSelected ? 1   : (zone.is_active ? 1 : 0.4),
                      dashArray:   zone.is_active ? null : '6 4',
                    }}
                  >
                    <Tooltip sticky>{zone.name}{!zone.is_active ? ' (inactive)' : ''}</Tooltip>
                  </Polygon>
                )
              })}
            </MapContainer>
          </div>

          {/* Zones Table */}
          <CTable hover responsive bordered className="admin-data-table">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                <CTableHeaderCell>Zone Name</CTableHeaderCell>
                <CTableHeaderCell>Points</CTableHeaderCell>
                <CTableHeaderCell>Status</CTableHeaderCell>
                <CTableHeaderCell>Actions</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {zones.length === 0 ? (
                <CTableRow>
                  <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                    No zones yet. Click "Draw New Zone" to define a service area on the map.
                  </CTableDataCell>
                </CTableRow>
              ) : (
                zones.map((zone, i) => {
                  const isSelected = selectedZone?.id === zone.id
                  return (
                    <CTableRow
                      key={zone.id}
                      onClick={() => toggleSelectZone(zone)}
                      className={isSelected ? 'zone-selected' : ''}
                      style={{ cursor: 'pointer' }}
                    >
                      <CTableDataCell>
                        <span
                          style={{
                            display: 'inline-block',
                            width: 12,
                            height: 12,
                            borderRadius: 2,
                            backgroundColor: ZONE_COLORS[i % ZONE_COLORS.length],
                            marginRight: 8,
                          }}
                        />
                        {i + 1}
                      </CTableDataCell>
                      <CTableDataCell>{zone.name}</CTableDataCell>
                      <CTableDataCell>
                        <CBadge color="secondary" shape="rounded-pill">
                          {zone.coordinates?.length ?? 0} pts
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <CBadge
                          color={zone.is_active ? 'success' : 'secondary'}
                          shape="rounded-pill"
                          style={{ cursor: 'pointer' }}
                          onClick={(e) => { e.stopPropagation(); handleToggle(zone) }}
                          title="Click to toggle"
                        >
                          {zone.is_active ? 'Active' : 'Inactive'}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <div className="d-flex gap-1 justify-content-center">
                          <PermissionGate permission="branch.edit">
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={(e) => { e.stopPropagation(); openEdit(zone) }}
                              title="Edit"
                            >
                              <CIcon icon={cilPencil} />
                            </CButton>
                          </PermissionGate>
                          <PermissionGate permission="branch.edit">
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={(e) => { e.stopPropagation(); setDeleteModal({ open: true, zone }) }}
                              title="Delete"
                            >
                              <CIcon icon={cilTrash} />
                            </CButton>
                          </PermissionGate>
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  )
                })
              )}
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT ZONE MODAL ==================== */}
      <CModal
        visible={modal.open}
        onClose={closeModal}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {modal.zone ? 'Edit Zone' : 'Name This Zone'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={onSubmit}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="mb-3">
              <CFormLabel className="filter-label">
                Zone Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                name="name"
                defaultValue={modal.zone?.name ?? ''}
                placeholder="e.g. Andheri West, Zone 1"
                autoFocus
              />
            </div>
            <div>
              <CFormCheck
                name="is_active"
                label="Active (customers can order from this zone)"
                defaultChecked={modal.zone ? modal.zone.is_active : true}
              />
            </div>
            {modal.drawnCoords && (
              <div className="text-muted small mt-2">
                Polygon: {modal.drawnCoords.length} points
              </div>
            )}
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {modal.zone ? 'Update' : 'Save Zone'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE ZONE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, zone: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Delete Zone</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Delete zone <strong>{deleteModal.zone?.name}</strong>? Customers in this
          area will no longer see this branch.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, zone: null })}
          >
            Cancel
          </CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default BranchZones