import {
  CBadge,
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CRow,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilUser, cilBell, cilSettings } from '@coreui/icons'
import useAuthStore from '../../store/authStore'
import useUiStore from '../../store/uiStore'

const Settings = () => {
  const { user, role } = useAuthStore()
  const themeKey = useUiStore(s => s.themeKey)
  const lastLogin = new Date().toLocaleString()

  return (
    <div className="settings-page">
      <div className="page-hero glass-panel mb-4">
        <div className="page-hero__copy">
          <div className="eyebrow">Settings</div>
          <h1>Personalize the workspace</h1>
          <p>
            Fine-tune your profile and notification preferences.
          </p>
        </div>
        <div className="page-hero__pill">
          <CIcon icon={cilSettings} />
          <span>UI Preferences</span>
        </div>
      </div>

      <CRow className="g-4">
        <CCol lg={7}>
          <CCard className="glass-card mb-4">
            <CCardHeader className="glass-card__header">
              <span>Profile</span>
              <CIcon icon={cilUser} />
            </CCardHeader>
            <CCardBody className="settings-form">
              <div>
                <CFormLabel>Name</CFormLabel>
                <CFormInput value={user?.name ?? ''} readOnly />
              </div>
              <div>
                <CFormLabel>Email</CFormLabel>
                <CFormInput value={user?.email ?? ''} readOnly />
              </div>
              <div>
                <CFormLabel>Role</CFormLabel>
                <div className="d-flex align-items-center gap-2">
                  <CBadge color="primary" className="text-uppercase">
                    {role ?? 'member'}
                  </CBadge>
                  <span className="text-body-secondary small">Presentation only.</span>
                </div>
              </div>
            </CCardBody>
          </CCard>

          <CCard className="glass-card">
            <CCardHeader className="glass-card__header">
              <span>Notifications</span>
              <CIcon icon={cilBell} />
            </CCardHeader>
            <CCardBody className="settings-toggles">
              {['Stock alerts', 'New orders', 'Security notices', 'Weekly digest'].map((label) => (
                <div key={label} className="settings-toggle">
                  <div>
                    <div className="fw-semibold">{label}</div>
                    <div className="text-body-secondary small">Purely visual toggle.</div>
                  </div>
                  <CFormCheck switch defaultChecked />
                </div>
              ))}
            </CCardBody>
          </CCard>
        </CCol>

        <CCol lg={5}>
          <CCard className="glass-card">
            <CCardHeader className="glass-card__header">
              <span>Security</span>
              <CIcon icon={cilUser} />
            </CCardHeader>
            <CCardBody className="security-panel">
              <div className="security-row">
                <span>Last login</span>
                <strong>{lastLogin}</strong>
              </div>
              <div className="security-row">
                <span>Active Theme</span>
                <strong className="text-capitalize">{themeKey}</strong>
              </div>
              <div className="security-row">
                <span>Connection</span>
                <strong className="text-capitalize">
                  {useAuthStore.getState().connection ?? '—'}
                </strong>
              </div>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </div>
  )
}

export default Settings