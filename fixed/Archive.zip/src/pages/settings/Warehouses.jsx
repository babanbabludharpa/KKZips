import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormCheck, CInputGroup, CInputGroupText, CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilSearch } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'

const schema = yup.object({
  name:          yup.string().required('Name is required'),
  code:          yup.string().required('Warehouse code is required'),
  address:       yup.string().nullable().optional(),
  state:         yup.string().required('State is required'),
  city:          yup.string().required('City is required'),
  pincode:       yup.string().nullable().optional(),
  phone:         yup.string().nullable().optional(),
  contact_email: yup.string().email('Invalid email').nullable().optional(),
  is_primary:    yup.boolean().optional(),
})

const Warehouses = () => {
  const [warehouses, setWarehouses]   = useState([])
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  // CHANGE 1: Added modalError state — separate from page-level error
  const [modalError, setModalError]   = useState(null)
  const [modal, setModal]             = useState({ open: false, warehouse: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, warehouse: null })
  const [search, setSearch]           = useState('')
  const [submitting, setSubmitting]   = useState(false)
  const [meta, setMeta]               = useState({ current_page: 1, last_page: 1 })
  const [page, setPage]               = useState(1)

  const [statesList, setStatesList]       = useState([])
  const [citiesList, setCitiesList]       = useState([])
  const [loadingCities, setLoadingCities] = useState(false)

  const isEdit = !!modal.warehouse

  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { is_primary: false, state: '', city: '' },
  })

  const selectedState = watch('state')

  useEffect(() => {
    fetchStates()
    fetchWarehouses()
  }, [])

  useEffect(() => {
    if (selectedState) {
      fetchCities(selectedState)
    } else {
      setCitiesList([])
      setValue('city', '')
    }
  }, [selectedState])

  const fetchStates = async () => {
    try {
      const tenantHost = window.location.hostname
      const res = await api.get(`http://${tenantHost}:8080/api/v1/masters/states`, {
        params: { country_id: 1 }
      })
      setStatesList(res.data.data?.states ?? [])
    } catch (err) {
      console.error("States Fetch Error:", err)
      setError('Failed to load states master data.')
    }
  }

  const fetchCities = async (stateId) => {
    try {
      setLoadingCities(true)
      const tenantHost = window.location.hostname
      const res = await api.get(`http://${tenantHost}:8080/api/v1/masters/cities`, {
        params: { state_id: stateId }
      })
      setCitiesList(res.data.data?.cities ?? res.data.data ?? [])
    } catch (err) {
      console.error("Cities Fetch Error:", err)
      setError('Failed to load cities for selected state.')
    } finally {
      setLoadingCities(false)
    }
  }

  const fetchWarehouses = async (p = page) => {
    try {
      setLoading(true)
      const res = await api.get('/settings/warehouses', { params: { search, page: p } })
      const targetData = res.data?.data
      setWarehouses(Array.isArray(targetData) ? targetData : (targetData?.data ?? []))
      if (targetData?.meta) setMeta(targetData.meta)
    } catch (err) {
      console.error("Warehouse fetch error:", err)
      setError('Failed to load warehouses.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const t = setTimeout(() => { setPage(1); fetchWarehouses(1) }, 400)
    return () => clearTimeout(t)
  }, [search])

  const openCreate = () => {
    reset({
      name: '', code: '', address: '', state: '', city: '', pincode: '',
      phone: '', contact_email: '', is_primary: false,
    })
    setModal({ open: true, warehouse: null })
  }

  const openEdit = async (warehouse) => {
    reset({
      name:          warehouse.name          ?? '',
      code:          warehouse.code          ?? '',
      address:       warehouse.address       ?? '',
      state:         warehouse.state_id      ?? warehouse.state ?? '',
      pincode:       warehouse.pincode       ?? '',
      phone:         warehouse.phone         ?? '',
      contact_email: warehouse.contact_email ?? '',
      is_primary:    warehouse.is_primary    ?? false,
    })
    if (warehouse.state_id || warehouse.state) {
      await fetchCities(warehouse.state_id ?? warehouse.state)
      setValue('city', warehouse.city_id ?? warehouse.city ?? '')
    }
    setModal({ open: true, warehouse })
  }

  // CHANGE 2: closeModal now clears modalError too
  const closeModal = () => {
    setModal({ open: false, warehouse: null })
    setCitiesList([])
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (isEdit) {
        await api.put(`/settings/warehouses/${modal.warehouse.id}`, data)
      } else {
        await api.post('/settings/warehouses', data)
      }
      closeModal()
      fetchWarehouses()
    } catch (e) {
      // CHANGE 3: Validation/submit errors go to modalError, not page-level error
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/settings/warehouses/${deleteModal.warehouse.id}`)
      setDeleteModal({ open: false, warehouse: null })
      fetchWarehouses()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (warehouse) => {
    try {
      await api.put(`/settings/warehouses/${warehouse.id}`, { is_active: !warehouse.is_active })
      fetchWarehouses()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  return (
    <>
      <div className="admin-page-shell">
        <div className="admin-page-shell__heading">
          <div>
            <h4>Warehouses</h4>
            <small className="admin-page-note">Manage inventory storage locations</small>
          </div>
          <PermissionGate permission="warehouse.create">
            <CButton color="primary" size="sm" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />Add Warehouse
            </CButton>
          </PermissionGate>
        </div>
      </div>

      {error && (
        <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
      )}

      <CCard className="glass-card admin-page-card">
        <CCardHeader className="glass-card__header">
          <CInputGroup className="admin-table-toolbar">
            <CInputGroupText><CIcon icon={cilSearch} /></CInputGroupText>
            <CFormInput
              placeholder="Search warehouses..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </CInputGroup>
        </CCardHeader>
        <CCardBody className="p-0">
          {loading ? (
            <div className="text-center py-5"><CSpinner color="primary" /></div>
          ) : (
            <>
              <CTable hover responsive className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>#</CTableHeaderCell>
                    <CTableHeaderCell>Code</CTableHeaderCell>
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>City</CTableHeaderCell>
                    <CTableHeaderCell>State</CTableHeaderCell>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Primary</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {warehouses.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No warehouses found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : warehouses.map((warehouse, i) => (
                    <CTableRow key={warehouse.id}>
                      <CTableDataCell>
                        {(meta.current_page - 1) * 15 + i + 1}
                      </CTableDataCell>
                      <CTableDataCell><CBadge color="dark" className="text-uppercase">{warehouse.code}</CBadge></CTableDataCell>
                      <CTableDataCell>{warehouse.name}</CTableDataCell>
                      <CTableDataCell>{warehouse.city_name ?? warehouse.city ?? '—'}</CTableDataCell>
                      <CTableDataCell>{warehouse.state_name ?? warehouse.state ?? '—'}</CTableDataCell>
                      <CTableDataCell>{warehouse.phone ?? '—'}</CTableDataCell>
                      <CTableDataCell>
                        {warehouse.is_primary ? (
                          <CBadge color="success">Primary</CBadge>
                        ) : '—'}
                      </CTableDataCell>
                      <CTableDataCell>
                        <CBadge
                          color={warehouse.is_active ? 'success' : 'secondary'}
                          style={{ cursor: 'pointer' }}
                          onClick={() => toggleActive(warehouse)}
                          title="Click to toggle"
                        >
                          {warehouse.is_active ? 'Active' : 'Inactive'}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <div className="admin-action-stack">
                          <PermissionGate permission="warehouse.edit">
                            <CButton
                              size="sm" color="warning" variant="outline"
                              onClick={() => openEdit(warehouse)}
                            >
                              <CIcon icon={cilPencil} />
                            </CButton>
                          </PermissionGate>
                          <PermissionGate permission="warehouse.delete">
                            <CButton
                              size="sm" color="danger" variant="outline"
                              onClick={() => setDeleteModal({ open: true, warehouse })}
                              disabled={warehouse.is_primary}
                              title={warehouse.is_primary ? 'Cannot delete primary warehouse' : ''}
                            >
                              <CIcon icon={cilTrash} />
                            </CButton>
                          </PermissionGate>
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>

              {meta.last_page > 1 && (
                <div className="d-flex justify-content-end align-items-center gap-2 p-3">
                  <CButton
                    size="sm" color="secondary" variant="outline"
                    disabled={meta.current_page === 1}
                    onClick={() => { setPage(p => p - 1); fetchWarehouses(page - 1) }}
                  >
                    Prev
                  </CButton>
                  <span className="small text-muted">
                    Page {meta.current_page} of {meta.last_page}
                  </span>
                  <CButton
                    size="sm" color="secondary" variant="outline"
                    disabled={meta.current_page === meta.last_page}
                    onClick={() => { setPage(p => p + 1); fetchWarehouses(page + 1) }}
                  >
                    Next
                  </CButton>
                </div>
              )}
            </>
          )}
        </CCardBody>
      </CCard>

      {/* Create / Edit Modal */}
      <CModal size="lg" visible={modal.open} onClose={closeModal} backdrop="static">
        <CModalHeader className="glass-card__header">
          <CModalTitle>{isEdit ? 'Edit Warehouse' : 'Add Warehouse'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody>
            {/* CHANGE 4: modalError alert inside modal body — shows validation errors in popup */}
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel>Warehouse Name <span className="text-danger">*</span></CFormLabel>
                <CFormInput invalid={!!errors.name} {...register('name')} />
                {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel>Warehouse Code <span className="text-danger">*</span></CFormLabel>
                <CFormInput invalid={!!errors.code} {...register('code')} placeholder="e.g. WH-MAIN" />
                {errors.code && <div className="text-danger small mt-1">{errors.code.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel>Phone</CFormLabel>
                <CFormInput {...register('phone')} />
              </div>
              <div className="col-md-6">
                <CFormLabel>Contact Email</CFormLabel>
                <CFormInput
                  type="email"
                  invalid={!!errors.contact_email}
                  {...register('contact_email')}
                />
                {errors.contact_email && (
                  <div className="text-danger small mt-1">{errors.contact_email.message}</div>
                )}
              </div>
              <div className="col-md-12">
                <CFormLabel>Address</CFormLabel>
                <CFormInput {...register('address')} />
              </div>
              <div className="col-md-4">
                <CFormLabel>State <span className="text-danger">*</span></CFormLabel>
                <CFormSelect invalid={!!errors.state} {...register('state')}>
                  <option value="">Select State</option>
                  {Array.isArray(statesList) && statesList.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </CFormSelect>
                {errors.state && <div className="text-danger small mt-1">{errors.state.message}</div>}
              </div>
              <div className="col-md-4">
                <CFormLabel>
                  City <span className="text-danger">*</span>
                  {loadingCities && <CSpinner size="sm" variant="grow" className="ms-2" style={{ width: '10px', height: '10px' }} />}
                </CFormLabel>
                <CFormSelect
                  invalid={!!errors.city}
                  {...register('city')}
                  disabled={!selectedState || loadingCities}
                >
                  <option value="">Select City</option>
                  {Array.isArray(citiesList) && citiesList.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </CFormSelect>
                {errors.city && <div className="text-danger small mt-1">{errors.city.message}</div>}
              </div>
              <div className="col-md-4">
                <CFormLabel>Pincode</CFormLabel>
                <CFormInput {...register('pincode')} />
              </div>
              <div className="col-md-12 d-flex align-items-end mt-4">
                <CFormCheck
                  {...register('is_primary')}
                  label="Set as Primary Warehouse Location"
                  id="is_primary"
                />
              </div>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton color="secondary" onClick={closeModal} disabled={submitting}>Cancel</CButton>
            <CButton type="submit" color="primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* Delete Modal */}
      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, warehouse: null })}>
        <CModalHeader className="glass-card__header">
          <CModalTitle>Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody>
          Are you sure you want to delete <strong>{deleteModal.warehouse?.name}</strong>?
          Inventory assignments associated with this warehouse might be affected.
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setDeleteModal({ open: false, warehouse: null })}>
            Cancel
          </CButton>
          <CButton color="danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default Warehouses
