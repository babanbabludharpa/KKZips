import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CButton, CSpinner, CAlert,
  CForm, CFormLabel, CFormInput, CFormSwitch, CFormSelect, CBadge,
  CNav, CNavItem, CNavLink, CTabContent, CTabPane,
  CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPencil, cilSave, cilX, cilBuilding, cilCreditCard,
  cilClock, cilLayers, cilBell, cilShieldAlt, cilPhone, cilPlus,
  cilEnvelopeClosed, cilChatBubble, cilMoney,
} from '@coreui/icons'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import { ChannelToggleCard } from '../../components/tenant/ChannelToggleCard'
import { InstructionManager } from '../../components/tenant/InstructionManager'
import { schema } from '../../validation/tenantProfileSchema'

const CUTOFF_TIME_OPTIONS = [
  { value: '19:00', label: '7:00 PM' },
  { value: '19:30', label: '7:30 PM' },
  { value: '20:00', label: '8:00 PM' },
  { value: '20:30', label: '8:30 PM' },
  { value: '21:00', label: '9:00 PM' },
  { value: '21:30', label: '9:30 PM' },
  { value: '22:00', label: '10:00 PM' },
  { value: '22:30', label: '10:30 PM' },
  { value: '23:00', label: '11:00 PM' },
  { value: '23:30', label: '11:30 PM' },
]

const DEFAULT_COD_ENABLED = false
const DEFAULT_ONLINE_ENABLED = true

const Field = ({ label, required, hint, error, children, width }) => (
  <div className="mb-3" style={width ? { maxWidth: width } : undefined}>
    <CFormLabel className="filter-label">
      {label}
      {required && <span className="text-danger"> *</span>}
      {hint && <span className="tenant-hint-inline"> · {hint}</span>}
    </CFormLabel>
    {children}
    {error && <div className="text-danger small mt-1">{error}</div>}
  </div>
)

const ValueRow = ({ label, value, badge }) => (
  <div className="tenant-value-row">
    <span className="tenant-value-label">{label}</span>
    {badge ? value : <span className="tenant-value-text">{value || '—'}</span>}
  </div>
)

const StatusBadge = ({ enabled, onLabel = 'Enabled', offLabel = 'Disabled' }) => (
  <CBadge color={enabled ? 'success' : 'secondary'} shape="rounded-pill">
    {enabled ? onLabel : offLabel}
  </CBadge>
)

const TenantProfile = () => {
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [activeTab, setActiveTab] = useState('company')

  const [slots, setSlots] = useState([])
  const [slotModal, setSlotModal] = useState(false)
  const [slotEditing, setSlotEditing] = useState(null)
  const [slotForm, setSlotForm] = useState({
    name: '', start_time: '', end_time: '', cutoff_time: '',
  })
  const [slotError, setSlotError] = useState(null)
  const [slotSubmitting, setSlotSubmitting] = useState(false)

  const {
    register, handleSubmit, reset, control, watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      company_name: '', pan_no: '',
      has_orders: true, use_order_slots: false,
      has_subscriptions: true, has_wallet: true,
      order_start_policy: 'next_day_only',
      order_same_day_lead_time_minutes: 120,
      slot_wise_cutoff_enabled: false,
      slot_cutoff_offset_minutes: 120,
      cod_enabled: DEFAULT_COD_ENABLED,
      online_payment_enabled: DEFAULT_ONLINE_ENABLED,
      razorpay_key_id: '', razorpay_key_secret: '', razorpay_webhook_secret: '', razorpay_is_live: false,
      pusher_app_id: '', pusher_key: '', pusher_secret: '', pusher_cluster: '',
      subscription_cutoff_time: '', subscription_cutoff_restrict_admin: false,
      subscription_start_policy: 'next_day_only',
      same_day_lead_time_minutes: 120,
      rider_assignment_time: '21:00',
      order_stock_check_enabled: false, subscription_stock_check_enabled: false,
      sms_username: '', sms_password: '', sms_sender_id: '', sms_enabled: true,
      sms_channel_enabled: false,
      notification_channel_enabled: true,
      whatsapp_channel_enabled: false,
      whatsapp_api_key: '', whatsapp_phone_number: '',
      email_channel_enabled: true,
      wallet_warning_limit: -500,
      wallet_suspension_limit: -5000,
      delivery_note_min_days: 3,
      delivery_note_max_days: 7,
      delivery_note_text: '',
      support_phone: '', support_email: '', support_hours: '',
    },
  })

  const orderPolicyWatch = watch('order_start_policy')
  const useOrderSlotsWatch = watch('use_order_slots')
  const hasOrdersWatch = watch('has_orders')

  useEffect(() => { fetchProfile(); fetchSlots() }, [])

  const fetchSlots = async () => {
    try {
      const res = await api.get('/settings/slots')
      setSlots(res.data?.data || [])
    } catch { /* noop */ }
  }

  const buildResetShape = (data) => ({
    company_name: data?.company_name ?? '',
    pan_no: data?.pan_no ?? '',
    has_orders: data?.has_orders ?? true,
    use_order_slots: data?.use_order_slots ?? false,
    has_subscriptions: data?.has_subscriptions ?? true,
    has_wallet: data?.has_wallet ?? true,
    order_start_policy: data?.order_start_policy ?? 'next_day_only',
    order_same_day_lead_time_minutes: data?.order_same_day_lead_time_minutes ?? 120,
    slot_wise_cutoff_enabled: data?.slot_wise_cutoff_enabled ?? false,
    slot_cutoff_offset_minutes: data?.slot_cutoff_offset_minutes ?? 120,
    cod_enabled: data?.cod_enabled ?? DEFAULT_COD_ENABLED,
    online_payment_enabled: data?.online_payment_enabled ?? DEFAULT_ONLINE_ENABLED,
    razorpay_key_id: data?.razorpay_key_id ?? '',
    razorpay_key_secret: '', razorpay_webhook_secret: '',
    razorpay_is_live: data?.razorpay_is_live ?? false,
    pusher_app_id: data?.pusher_app_id ?? '',
    pusher_key: data?.pusher_key ?? '',
    pusher_secret: '',
    pusher_cluster: data?.pusher_cluster ?? '',
    subscription_cutoff_time: data?.subscription_cutoff_time ?? '',
    subscription_cutoff_restrict_admin: data?.subscription_cutoff_restrict_admin ?? false,
    subscription_start_policy: data?.subscription_start_policy ?? 'next_day_only',
    same_day_lead_time_minutes: data?.same_day_lead_time_minutes ?? 120,
    rider_assignment_time: data?.rider_assignment_time ?? '21:00',
    order_stock_check_enabled: data?.order_stock_check_enabled ?? false,
    subscription_stock_check_enabled: data?.subscription_stock_check_enabled ?? false,
    sms_username: data?.sms_username ?? '',
    sms_password: '',
    sms_sender_id: data?.sms_sender_id ?? '',
    sms_enabled: data?.sms_enabled ?? true,
    sms_channel_enabled: data?.sms_channel_enabled ?? false,
    notification_channel_enabled: data?.notification_channel_enabled ?? true,
    whatsapp_channel_enabled: data?.whatsapp_channel_enabled ?? false,
    whatsapp_api_key: '',
    whatsapp_phone_number: data?.whatsapp_phone_number ?? '',
    email_channel_enabled: data?.email_channel_enabled ?? true,
    wallet_warning_limit: data?.wallet_warning_limit ?? -500,
    wallet_suspension_limit: data?.wallet_suspension_limit ?? -5000,
    delivery_note_min_days: data?.delivery_note_min_days ?? 3,
    delivery_note_max_days: data?.delivery_note_max_days ?? 7,
    delivery_note_text: data?.delivery_note_text ?? '',
    support_phone: data?.support_phone ?? '',
    support_email: data?.support_email ?? '',
    support_hours: data?.support_hours ?? '',
  })

  const fetchProfile = async () => {
    try {
      setLoading(true)
      const res = await api.get('/settings/profile')
      const data = res.data?.data ?? null
      setProfile(data)
      if (data) reset(buildResetShape(data))
    } catch {
      setError('Failed to load tenant profile.')
    } finally {
      setLoading(false)
    }
  }

  const onSubmit = async (data) => {
    if (!data.cod_enabled && !data.online_payment_enabled) {
      setError('At least one payment method must remain enabled.')
      setActiveTab('payments'); return
    }

    if (data.use_order_slots && !data.has_orders) {
      setError('Order slots can only be enabled when the Orders module is on.')
      setActiveTab('modules'); return
    }

    if (data.use_order_slots && data.order_start_policy === 'same_day_slot_wise'
        && (data.order_same_day_lead_time_minutes == null || data.order_same_day_lead_time_minutes < 30)) {
      setError('Order same-day lead time must be at least 30 minutes.')
      setActiveTab('scheduling'); return
    }

    if (data.wallet_suspension_limit >= data.wallet_warning_limit) {
      setError('Wallet suspension limit must be more negative than warning limit.')
      setActiveTab('wallet'); return
    }

    if (data.delivery_note_max_days < data.delivery_note_min_days) {
      setError('Delivery note max days must be at least min days.')
      setActiveTab('delivery-note'); return
    }

    setSubmitting(true); setError(null); setSuccess(null)
    try {
      const payload = { ...data }
      if (!payload.subscription_cutoff_time) delete payload.subscription_cutoff_time

      const res = await api.put('/settings/profile', payload)
      const updated = res.data?.data ?? null
      setProfile(updated)
      reset(buildResetShape(updated))
      setEditing(false)
      setSuccess('Profile saved successfully.')
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to save profile.')
    } finally {
      setSubmitting(false)
    }
  }

  const cancelEdit = () => {
    reset(buildResetShape(profile))
    setEditing(false); setError(null)
  }

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!profile) { setError('Save company profile details before uploading a logo.'); e.target.value = ''; return }
    const formData = new FormData()
    formData.append('logo', file)
    setUploading(true); setError(null); setSuccess(null)
    try {
      const res = await api.post('/settings/profile/logo', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setProfile(prev => ({ ...prev, logo: res.data?.data?.logo, logo_url: res.data?.data?.logo_url }))
      setSuccess('Logo uploaded successfully.')
    } catch (e) {
      setError(e.response?.data?.message ?? 'Logo upload failed.')
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  const openSlotCreate = () => {
    setSlotEditing(null)
    setSlotForm({ name: '', start_time: '', end_time: '', cutoff_time: '' })
    setSlotError(null)
    setSlotModal(true)
  }

  const openSlotEdit = (slot) => {
    setSlotEditing(slot)
    setSlotForm({
      name:        slot.name ?? '',
      start_time:  slot.start_time?.slice(0, 5) ?? '',
      end_time:    slot.end_time?.slice(0, 5) ?? '',
      cutoff_time: slot.cutoff_time?.slice(0, 5) ?? '',
    })
    setSlotError(null)
    setSlotModal(true)
  }

  const handleSaveSlot = async (e) => {
    e.preventDefault()
    setSlotSubmitting(true); setSlotError(null)
    try {
      const payload = { ...slotForm }
      if (!payload.cutoff_time) payload.cutoff_time = null

      // Client-side guard — cutoff must be earlier than the slot start.
      if (payload.cutoff_time && payload.start_time && payload.cutoff_time >= payload.start_time) {
        setSlotError('Cutoff time must be earlier than the slot start time.')
        setSlotSubmitting(false)
        return
      }

      if (slotEditing) {
        // Never send start/end on a locked slot — the backend rejects it.
        if (slotEditing.is_locked) {
          delete payload.start_time
          delete payload.end_time
        }
        await api.put(`/settings/slots/${slotEditing.id}`, payload)
      } else {
        await api.post('/settings/slots', payload)
      }

      setSlotModal(false)
      setSlotEditing(null)
      setSlotForm({ name: '', start_time: '', end_time: '', cutoff_time: '' })
      fetchSlots()
    } catch (err) {
      setSlotError(err.response?.data?.message ?? 'Failed to save slot.')
    } finally {
      setSlotSubmitting(false)
    }
  }

  const handleToggleSlot = async (slot) => {
    try {
      await api.patch(`/settings/slots/${slot.id}/toggle`)
      fetchSlots()
    } catch (err) {
      alert(err.response?.data?.message ?? 'Failed to toggle slot.')
    }
  }

  if (loading) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading tenant profile...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  const TABS = [
    { key: 'company',       label: 'Company',        icon: cilBuilding },
    { key: 'modules',       label: 'Modules',        icon: cilLayers },
    { key: 'channels',      label: 'Channels',       icon: cilBell },
    { key: 'slots',         label: 'Delivery Slots', icon: cilClock },
    { key: 'payments',      label: 'Payments',       icon: cilCreditCard },
    { key: 'scheduling',    label: 'Scheduling',     icon: cilClock },
    { key: 'instructions',  label: 'Instructions',   icon: cilChatBubble },
    { key: 'wallet',        label: 'Wallet',         icon: cilMoney },
    { key: 'delivery-note', label: 'Delivery Note',  icon: cilEnvelopeClosed },
    { key: 'stock',         label: 'Stock',          icon: cilLayers },
    { key: 'razorpay',      label: 'Razorpay',       icon: cilShieldAlt, permission: 'profile.razorpay_edit' },
    { key: 'pusher',        label: 'Realtime',       icon: cilBell,      permission: 'profile.pusher_edit' },
    { key: 'sms',           label: 'SMS',            icon: cilPhone,     permission: 'profile.sms_edit' },
  ]

  return (
    <div className="report-page tenant-profile">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <div><h4 className="report-shell__title">Tenant Profile</h4></div>
          <PermissionGate permission="profile.edit">
            {!editing && (
              <CButton size="sm" className="report-shell__export" onClick={() => setEditing(true)}>
                <CIcon icon={cilPencil} className="me-2" />Edit
              </CButton>
            )}
          </PermissionGate>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}
        {success && (
          <div className="report-shell__error">
            <CAlert color="success" dismissible onClose={() => setSuccess(null)}>{success}</CAlert>
          </div>
        )}

        <CForm onSubmit={handleSubmit(onSubmit)}>
          <div className="tenant-hero">
            <div className="tenant-hero__brand">
              {profile?.logo_url ? (
                <img src={profile.logo_url} alt="Company Logo" className="tenant-hero__logo" />
              ) : (
                <div className="tenant-hero__logo tenant-hero__logo--empty">
                  <CIcon icon={cilBuilding} width={28} height={28} />
                </div>
              )}
              <div className="tenant-hero__meta">
                <div className="tenant-hero__name">
                  {profile?.company_name || 'Unnamed Tenant'}
                </div>
                <div className="tenant-hero__sub">
                  {profile?.pan_no && (<span className="tenant-hero__chip"><strong>PAN</strong> {profile.pan_no}</span>)}
                  {profile?.has_orders && <span className="tenant-hero__chip">Orders</span>}
                  {profile?.has_subscriptions && <span className="tenant-hero__chip">Subscriptions</span>}
                  {profile?.has_wallet && <span className="tenant-hero__chip">Wallet</span>}
                  {profile?.has_orders && (
                    <span className="tenant-hero__chip">
                      Slots: {profile?.use_order_slots ? 'Orders + Subs' : 'Subs only'}
                    </span>
                  )}
                  <span className="tenant-hero__chip">
                    <strong>Payments</strong>{' '}
                    {profile?.cod_enabled && profile?.online_payment_enabled ? 'COD + Online'
                      : profile?.cod_enabled ? 'COD only'
                      : profile?.online_payment_enabled ? 'Online only' : 'Disabled'}
                  </span>
                  {profile?.razorpay_configured && <span className="tenant-hero__chip tenant-hero__chip--ok">Razorpay</span>}
                  {profile?.pusher_configured && <span className="tenant-hero__chip tenant-hero__chip--ok">Realtime</span>}
                  {profile?.sms_configured && (
                    <span className={'tenant-hero__chip ' + (profile.sms_enabled ? 'tenant-hero__chip--ok' : 'tenant-hero__chip--warn')}>
                      SMS {profile.sms_enabled ? 'on' : 'paused'}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <PermissionGate permission="profile.edit">
              <div className="tenant-hero__logo-actions">
                <label
                  htmlFor="logo-upload"
                  className={`filter-btn filter-btn--ghost ${!profile ? 'disabled' : ''}`}
                  style={{ cursor: !profile ? 'not-allowed' : 'pointer', marginBottom: 0 }}
                  title={!profile ? 'Save profile details first' : 'Upload logo'}
                >
                  {uploading ? <CSpinner size="sm" className="me-1" /> : null}
                  {uploading ? 'Uploading…' : 'Change logo'}
                </label>
                <input
                  id="logo-upload" type="file"
                  accept="image/jpeg,image/png,image/jpg,image/webp"
                  style={{ display: 'none' }}
                  onChange={handleLogoUpload}
                  disabled={!profile || uploading}
                />
                <div className="tenant-hero__hint">JPG/PNG/WEBP · Max 2MB</div>
              </div>
            </PermissionGate>
          </div>

          <CNav variant="tabs" role="tablist" className="tenant-tabs">
            {TABS.map(t => {
              const nav = (
                <CNavItem key={t.key}>
                  <CNavLink
                    active={activeTab === t.key}
                    onClick={() => setActiveTab(t.key)}
                    style={{ cursor: 'pointer' }}
                    className="tenant-tab-link d-flex align-items-center gap-2"
                  >
                    <CIcon icon={t.icon} width={15} height={15} />
                    <span>{t.label}</span>
                  </CNavLink>
                </CNavItem>
              )
              return t.permission
                ? <PermissionGate key={t.key} permission={t.permission}>{nav}</PermissionGate>
                : nav
            })}
          </CNav>

          <CCardBody className="tenant-content">
            <CTabContent>

              {/* ── COMPANY ─────────────────────────────── */}
              <CTabPane visible={activeTab === 'company'}>
                {editing ? (
                  <>
                    <div className="row g-3">
                      <div className="col-md-7">
                        <Field label="Company name" required error={errors.company_name?.message}>
                          <CFormInput className="filter-input" invalid={!!errors.company_name} {...register('company_name')} placeholder="Enter company name" />
                        </Field>
                      </div>
                      <div className="col-md-5">
                        <Field label="PAN number" hint="e.g. ABCDE1234F" error={errors.pan_no?.message}>
                          <CFormInput className="filter-input" invalid={!!errors.pan_no} {...register('pan_no')} style={{ textTransform: 'uppercase' }} maxLength={10} />
                        </Field>
                      </div>
                    </div>
                    <div className="row g-3 mt-1">
                      <div className="col-md-4">
                        <Field label="Support phone" error={errors.support_phone?.message}>
                          <CFormInput className="filter-input" {...register('support_phone')} placeholder="e.g. +91 98765 43210" />
                        </Field>
                      </div>
                      <div className="col-md-4">
                        <Field label="Support email" error={errors.support_email?.message}>
                          <CFormInput className="filter-input" {...register('support_email')} invalid={!!errors.support_email} placeholder="e.g. support@yourcompany.com" />
                        </Field>
                      </div>
                      <div className="col-md-4">
                        <Field label="Support hours" hint="Free text" error={errors.support_hours?.message}>
                          <CFormInput className="filter-input" {...register('support_hours')} placeholder="e.g. 9 AM – 9 PM, all days" />
                        </Field>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <ValueRow label="Company name" value={profile?.company_name} />
                    <ValueRow label="PAN number" badge value={profile?.pan_no ? <CBadge color="primary" shape="rounded-pill">{profile.pan_no}</CBadge> : '—'} />
                    <ValueRow label="Support phone" value={profile?.support_phone} />
                    <ValueRow label="Support email" value={profile?.support_email} />
                    <ValueRow label="Support hours" value={profile?.support_hours} />
                  </>
                )}
              </CTabPane>

              {/* ── MODULES ─────────────────────────────── */}
              <CTabPane visible={activeTab === 'modules'}>
                <p className="tenant-note">
                  Control which business modules this tenant sees. Disabling a module hides its UI —
                  existing data is preserved.
                </p>
                {editing ? (
                  <PermissionGate permission="profile.modules_edit"
                    fallback={<p className="tenant-note text-warning mb-0">You don't have permission to change module availability.</p>}>
                    <div className="d-flex flex-column gap-2">
                      <Controller name="has_orders" control={control} render={({ field }) => (
                        <CFormSwitch id="has_orders" label="Orders — customer places one-off orders" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />

                      {hasOrdersWatch && (
                        <div className="tenant-suboption">
                          <Controller name="use_order_slots" control={control} render={({ field }) => (
                            <CFormSwitch
                              id="use_order_slots"
                              label="Require delivery slot on order checkout"
                              checked={!!field.value}
                              onChange={e => field.onChange(e.target.checked)}
                            />
                          )} />
                          <div className="tenant-hint">
                            Off — order without slot selection (clothing, electronics).
                            On — customer must pick a delivery slot at checkout (groceries).
                          </div>
                        </div>
                      )}

                      <Controller name="has_subscriptions" control={control} render={({ field }) => (
                        <CFormSwitch id="has_subscriptions" label="Subscriptions — recurring delivery plans" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />
                      <Controller name="has_wallet" control={control} render={({ field }) => (
                        <CFormSwitch id="has_wallet" label="Wallet — prepaid balance for subs and orders" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />
                    </div>
                  </PermissionGate>
                ) : (
                  <>
                    <ValueRow label="Orders" badge value={<StatusBadge enabled={!!profile?.has_orders} />} />
                    <ValueRow label="Order slots" badge value={
                      profile?.has_orders
                        ? <StatusBadge enabled={!!profile?.use_order_slots} onLabel="Required" offLabel="Not used" />
                        : <CBadge color="secondary" shape="rounded-pill">N/A</CBadge>
                    } />
                    <ValueRow label="Subscriptions" badge value={<StatusBadge enabled={!!profile?.has_subscriptions} />} />
                    <ValueRow label="Wallet" badge value={<StatusBadge enabled={!!profile?.has_wallet} />} />
                  </>
                )}
              </CTabPane>

              {/* ── CHANNELS ────────────────────────────── */}
              <CTabPane visible={activeTab === 'channels'}>
                <p className="tenant-note">
                  Turn customer communication channels on or off. Disabling a channel
                  stops all outgoing messages for this tenant.
                </p>
                <div className="channels-grid">
                  <Controller name="sms_channel_enabled" control={control} render={({ field }) => (
                    <ChannelToggleCard
                      id="sms_channel_enabled"
                      icon={cilPhone}
                      title="SMS"
                      description="Transactional SMS via your gateway."
                      configured={!!profile?.sms_configured}
                      requiredHint="Configure SMS credentials under the SMS tab — the switch is saved but no SMS will send until configured."
                      enabled={!!field.value}
                      disabled={!editing}
                      onChange={field.onChange}
                    />
                  )} />

                  <Controller name="notification_channel_enabled" control={control} render={({ field }) => (
                    <ChannelToggleCard
                      id="notification_channel_enabled"
                      icon={cilBell}
                      title="In-app notifications"
                      description="Push updates via Pusher."
                      configured={!!profile?.pusher_configured}
                      requiredHint="Configure Pusher under the Realtime tab — no notifications will push until configured."
                      enabled={!!field.value}
                      disabled={!editing}
                      onChange={field.onChange}
                    />
                  )} />

                  <Controller name="whatsapp_channel_enabled" control={control} render={({ field }) => (
                    <ChannelToggleCard
                      id="whatsapp_channel_enabled"
                      icon={cilChatBubble}
                      title="WhatsApp"
                      description="Order confirmations and delivery reminders."
                      configured={!!profile?.whatsapp_configured}
                      requiredHint="Enter WhatsApp API key and phone number below — nothing will be sent until configured."
                      enabled={!!field.value}
                      disabled={!editing}
                      onChange={field.onChange}
                    />
                  )} />

                  <Controller name="email_channel_enabled" control={control} render={({ field }) => (
                    <ChannelToggleCard
                      id="email_channel_enabled"
                      icon={cilEnvelopeClosed}
                      title="Email"
                      description="Invoices and receipts to customer email."
                      configured={!!profile?.support_email}
                      requiredHint="Set a support email under the Company tab — nothing will be sent until configured."
                      enabled={!!field.value}
                      disabled={!editing}
                      onChange={field.onChange}
                    />
                  )} />
                </div>

                {editing && (
                  <div className="row g-3 mt-3">
                    <div className="col-md-6">
                      <Field label="WhatsApp API key">
                        <CFormInput className="filter-input" type="password" {...register('whatsapp_api_key')} placeholder={profile?.whatsapp_configured ? 'Leave blank to keep existing' : 'Enter API key'} />
                      </Field>
                    </div>
                    <div className="col-md-6">
                      <Field label="WhatsApp phone number" error={errors.whatsapp_phone_number?.message}>
                        <CFormInput className="filter-input" {...register('whatsapp_phone_number')} placeholder="e.g. +919876543210" />
                      </Field>
                    </div>
                  </div>
                )}
              </CTabPane>

              {/* ── DELIVERY SLOTS ──────────────────────── */}
              <CTabPane visible={activeTab === 'slots'}>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <p className="tenant-note mb-0">
                    Define the time windows customers can choose. Each slot has its own
                    cutoff time — the clock time after which that slot cannot be booked.
                    Once a slot has been used by an order, its start/end times are frozen
                    to protect order history — only the name, cutoff, and active status
                    stay editable.
                  </p>
                  <CButton size="sm" className="filter-btn filter-btn--primary" onClick={openSlotCreate}>
                    <CIcon icon={cilPlus} className="me-2" /> Add Slot
                  </CButton>
                </div>
                <CTable hover responsive bordered className="admin-data-table">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Name</CTableHeaderCell>
                      <CTableHeaderCell>Start Time</CTableHeaderCell>
                      <CTableHeaderCell>End Time</CTableHeaderCell>
                      <CTableHeaderCell>Cutoff</CTableHeaderCell>
                      <CTableHeaderCell>Status</CTableHeaderCell>
                      <CTableHeaderCell style={{ width: 110 }}>Actions</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {slots.length === 0 ? (
                      <CTableRow>
                        <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                          No delivery slots created yet.
                        </CTableDataCell>
                      </CTableRow>
                    ) : slots.map(slot => (
                      <CTableRow key={slot.id}>
                        <CTableDataCell>
                          {slot.name}
                          {slot.is_locked && (
                            <CBadge color="info" shape="rounded-pill" className="ms-2" title="Time window is frozen because orders reference this slot">
                              Locked
                            </CBadge>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>{slot.start_time}</CTableDataCell>
                        <CTableDataCell>{slot.end_time}</CTableDataCell>
                        <CTableDataCell>{slot.cutoff_time ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={slot.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => handleToggleSlot(slot)}
                            title="Click to toggle active status"
                          >
                            {slot.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="filter-btn filter-btn--ghost"
                            onClick={() => openSlotEdit(slot)}
                          >
                            <CIcon icon={cilPencil} width={12} className="me-1" />
                            Edit
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              </CTabPane>

              {/* ── PAYMENTS ────────────────────────────── */}
              <CTabPane visible={activeTab === 'payments'}>
                <p className="tenant-note">At least one method must stay enabled.</p>
                {editing ? (
                  <div className="d-flex flex-column gap-2">
                    <Controller name="cod_enabled" control={control} render={({ field }) => (
                      <CFormSwitch id="cod_enabled" label="Cash on delivery" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                    )} />
                    <Controller name="online_payment_enabled" control={control} render={({ field }) => (
                      <CFormSwitch id="online_payment_enabled" label="Online payment (UPI / cards / netbanking)" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                    )} />
                  </div>
                ) : (
                  <>
                    <ValueRow label="Cash on delivery" badge value={<StatusBadge enabled={!!profile?.cod_enabled} />} />
                    <ValueRow label="Online payment" badge value={<StatusBadge enabled={!!profile?.online_payment_enabled} />} />
                  </>
                )}
              </CTabPane>

              {/* ── SCHEDULING ──────────────────────────── */}
              <CTabPane visible={activeTab === 'scheduling'}>
                <h6 className="mb-3">Order Scheduling</h6>
                <p className="tenant-note">
                  Applies only when <strong>Require delivery slot on order checkout</strong> is enabled under Modules.
                </p>

                {editing ? (
                  <PermissionGate permission="profile.order_slots_edit"
                    fallback={<p className="tenant-note text-warning mb-0">You don't have permission to change order scheduling.</p>}>
                    <div className={useOrderSlotsWatch ? '' : 'opacity-50'}>
                      <Field label="Order start policy" width={360} error={errors.order_start_policy?.message}>
                        <Controller name="order_start_policy" control={control} render={({ field }) => (
                          <CFormSelect className="filter-input" value={field.value} disabled={!useOrderSlotsWatch} onChange={e => field.onChange(e.target.value)}>
                            <option value="next_day_only">Next day only</option>
                            <option value="same_day_slot_wise">Same day allowed (slot-wise)</option>
                          </CFormSelect>
                        )} />
                      </Field>
                      {orderPolicyWatch === 'same_day_slot_wise' && (
                        <Field label="Order same-day lead time (minutes)" width={360} error={errors.order_same_day_lead_time_minutes?.message}>
                          <Controller name="order_same_day_lead_time_minutes" control={control} render={({ field }) => (
                            <CFormInput className="filter-input" type="number" min={30} max={720} disabled={!useOrderSlotsWatch} value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                          )} />
                        </Field>
                      )}
                    </div>
                  </PermissionGate>
                ) : (
                  <>
                    <ValueRow label="Order start policy" badge value={
                      !profile?.use_order_slots
                        ? <CBadge color="secondary" shape="rounded-pill">Not used</CBadge>
                        : <CBadge color={profile?.order_start_policy === 'same_day_slot_wise' ? 'info' : 'secondary'} shape="rounded-pill">
                            {profile.order_start_policy === 'same_day_slot_wise' ? 'Same day allowed' : 'Next day only'}
                          </CBadge>
                    } />
                    {profile?.use_order_slots && profile?.order_start_policy === 'same_day_slot_wise' && (
                      <ValueRow label="Order same-day lead time" value={`${profile?.order_same_day_lead_time_minutes ?? 120} minutes`} />
                    )}
                  </>
                )}

                <hr className="my-4" />
                <h6 className="mb-3">Slot Cutoff</h6>
                <p className="tenant-note">
                  Each slot can carry its own cutoff time (set per-slot in the Delivery Slots tab).
                  When a slot has no cutoff, the profile-level offset below is used as fallback.
                  Applies to both orders and subscriptions.
                </p>

                {editing ? (
                  <PermissionGate permission="profile.cutoff_edit">
                    <Controller name="slot_wise_cutoff_enabled" control={control} render={({ field }) => (
                      <CFormSwitch id="slot_wise_cutoff_enabled" label="Use profile-level cutoff as fallback" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                    )} />
                    <Field label="Fallback cutoff offset (minutes)" hint="e.g. 120 = slot closes 2h before it starts, when the slot has no cutoff_time" width={300} error={errors.slot_cutoff_offset_minutes?.message}>
                      <Controller name="slot_cutoff_offset_minutes" control={control} render={({ field }) => (
                        <CFormInput className="filter-input" type="number" min={15} max={720} value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                      )} />
                    </Field>
                  </PermissionGate>
                ) : (
                  <ValueRow label="Fallback cutoff" badge value={
                    <StatusBadge
                      enabled={!!profile?.slot_wise_cutoff_enabled}
                      onLabel={`${profile?.slot_cutoff_offset_minutes ?? 120} min before slot start`}
                      offLabel="Using legacy global cutoff"
                    />
                  } />
                )}

                <hr className="my-4" />
                <h6 className="mb-3">Subscription Edit Cutoff</h6>
                {editing ? (
                  <Field label="Cutoff time" error={errors.subscription_cutoff_time?.message} width={260}>
                    <Controller name="subscription_cutoff_time" control={control} render={({ field }) => (
                      <CFormSelect className="filter-input" value={field.value ?? ''} onChange={e => field.onChange(e.target.value)}>
                        <option value="">Not set</option>
                        {CUTOFF_TIME_OPTIONS.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </CFormSelect>
                    )} />
                  </Field>
                ) : (
                  <ValueRow label="Cutoff time" value={profile?.subscription_cutoff_time
                    ? (CUTOFF_TIME_OPTIONS.find(o => o.value === profile.subscription_cutoff_time)?.label ?? profile.subscription_cutoff_time)
                    : 'Not set'} />
                )}
                <ValueRow label="Applies to admin panel" badge value={<StatusBadge enabled={!!profile?.subscription_cutoff_restrict_admin} onLabel="Enforced" offLabel="Not enforced" />} />

                {editing && (
                  <PermissionGate permission="profile.cutoff_edit">
                    <div className="mt-2">
                      <Controller name="subscription_cutoff_restrict_admin" control={control} render={({ field }) => (
                        <CFormSwitch id="subscription_cutoff_restrict_admin" label="Enforce cutoff on admin panel too" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />
                    </div>
                  </PermissionGate>
                )}

                <hr className="my-4" />
                <h6 className="mb-3">Subscription Start Policy</h6>
                {editing ? (
                  <PermissionGate permission="profile.cutoff_edit">
                    <Field label="Start policy" width={360} error={errors.subscription_start_policy?.message}>
                      <Controller name="subscription_start_policy" control={control} render={({ field }) => (
                        <CFormSelect className="filter-input" value={field.value} onChange={e => field.onChange(e.target.value)}>
                          <option value="next_day_only">Next day only</option>
                          <option value="same_day_slot_wise">Same day allowed (slot-wise)</option>
                        </CFormSelect>
                      )} />
                    </Field>
                    {watch('subscription_start_policy') === 'same_day_slot_wise' && (
                      <Field label="Same-day lead time (minutes)" width={360} error={errors.same_day_lead_time_minutes?.message}>
                        <Controller name="same_day_lead_time_minutes" control={control} render={({ field }) => (
                          <CFormInput className="filter-input" type="number" min={30} max={720} value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                        )} />
                      </Field>
                    )}
                  </PermissionGate>
                ) : (
                  <>
                    <ValueRow label="Start policy" badge value={
                      <CBadge color={profile?.subscription_start_policy === 'same_day_slot_wise' ? 'info' : 'secondary'} shape="rounded-pill">
                        {profile?.subscription_start_policy === 'same_day_slot_wise' ? 'Same day allowed' : 'Next day only'}
                      </CBadge>
                    } />
                  </>
                )}

                <hr className="my-4" />
                <h6 className="mb-3">Rider Assignment</h6>
                {editing ? (
                  <PermissionGate permission="profile.cutoff_edit">
                    <Field label="Assignment time" width={220} error={errors.rider_assignment_time?.message}>
                      <Controller name="rider_assignment_time" control={control} render={({ field }) => (
                        <CFormInput className="filter-input" type="time" value={field.value} onChange={e => field.onChange(e.target.value)} />
                      )} />
                    </Field>
                  </PermissionGate>
                ) : (
                  <ValueRow label="Assignment time" value={profile?.rider_assignment_time ?? '21:00'} />
                )}
              </CTabPane>

              {/* ── INSTRUCTIONS ────────────────────────── */}
              <CTabPane visible={activeTab === 'instructions'}>
                <p className="tenant-note">
                  A catalog of delivery instructions customers can pick at checkout
                  (e.g. "Don't ring the bell"). Customers can also add a free-text note
                  on individual orders.
                </p>
                <InstructionManager canEdit={editing} />
              </CTabPane>

              {/* ── WALLET ──────────────────────────────── */}
              <CTabPane visible={activeTab === 'wallet'}>
                <p className="tenant-note">
                  Amounts are in <strong>rupees</strong>. Limits are negative — a wallet
                  balance below the warning limit triggers a nudge; below the suspension
                  limit is blocked from placing orders.
                </p>
                {editing ? (
                  <PermissionGate permission="profile.edit">
                    <div className="row g-3">
                      <div className="col-md-6">
                        <Field label="Warning limit (₹)" hint="Balance below this shows a nudge" error={errors.wallet_warning_limit?.message}>
                          <Controller name="wallet_warning_limit" control={control} render={({ field }) => (
                            <CFormInput className="filter-input" type="number" step="1" value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                          )} />
                        </Field>
                      </div>
                      <div className="col-md-6">
                        <Field label="Suspension limit (₹)" hint="Balance below this blocks new orders" error={errors.wallet_suspension_limit?.message}>
                          <Controller name="wallet_suspension_limit" control={control} render={({ field }) => (
                            <CFormInput className="filter-input" type="number" step="1" value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                          )} />
                        </Field>
                      </div>
                    </div>
                  </PermissionGate>
                ) : (
                  <>
                    <ValueRow label="Warning limit" value={profile?.wallet_warning_limit != null ? `₹ ${profile.wallet_warning_limit}` : '—'} />
                    <ValueRow label="Suspension limit" value={profile?.wallet_suspension_limit != null ? `₹ ${profile.wallet_suspension_limit}` : '—'} />
                  </>
                )}
              </CTabPane>

              {/* ── DELIVERY NOTE ───────────────────────── */}
              <CTabPane visible={activeTab === 'delivery-note'}>
                <p className="tenant-note">
                  The delivery estimate customers see at checkout. Free-text overrides
                  the min–max range when set.
                </p>
                {editing ? (
                  <PermissionGate permission="profile.edit">
                    <div className="row g-3">
                      <div className="col-md-3">
                        <Field label="Min days" error={errors.delivery_note_min_days?.message}>
                          <Controller name="delivery_note_min_days" control={control} render={({ field }) => (
                            <CFormInput className="filter-input" type="number" min={0} max={60} value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                          )} />
                        </Field>
                      </div>
                      <div className="col-md-3">
                        <Field label="Max days" error={errors.delivery_note_max_days?.message}>
                          <Controller name="delivery_note_max_days" control={control} render={({ field }) => (
                            <CFormInput className="filter-input" type="number" min={0} max={90} value={field.value} onChange={e => field.onChange(e.target.value === '' ? '' : Number(e.target.value))} />
                          )} />
                        </Field>
                      </div>
                      <div className="col-md-6">
                        <Field label="Custom text (optional)" hint="Overrides the min–max range">
                          <CFormInput className="filter-input" {...register('delivery_note_text')} placeholder="e.g. Delivered within 3–7 working days" maxLength={255} />
                        </Field>
                      </div>
                    </div>
                  </PermissionGate>
                ) : (
                  <>
                    <ValueRow label="Estimated delivery" value={
                      profile?.delivery_note_text
                        || (profile?.delivery_note_min_days != null
                            ? `${profile.delivery_note_min_days}–${profile.delivery_note_max_days} days`
                            : '—')
                    } />
                  </>
                )}
              </CTabPane>

              {/* ── STOCK ───────────────────────────────── */}
              <CTabPane visible={activeTab === 'stock'}>
                <p className="tenant-note">Normally managed by the platform team.</p>
                <ValueRow label="Order stock check" badge value={<StatusBadge enabled={!!profile?.order_stock_check_enabled} />} />
                <ValueRow label="Subscription stock check" badge value={<StatusBadge enabled={!!profile?.subscription_stock_check_enabled} />} />
                {editing && (
                  <PermissionGate permission="profile.stock_check_edit">
                    <div className="d-flex flex-column gap-2 mt-2">
                      <Controller name="order_stock_check_enabled" control={control} render={({ field }) => (
                        <CFormSwitch id="order_stock_check_enabled" label="Enforce on orders" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />
                      <Controller name="subscription_stock_check_enabled" control={control} render={({ field }) => (
                        <CFormSwitch id="subscription_stock_check_enabled" label="Enforce on subscriptions" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                      )} />
                    </div>
                  </PermissionGate>
                )}
              </CTabPane>

              {/* ── RAZORPAY ────────────────────────────── */}
              <PermissionGate permission="profile.razorpay_edit">
                <CTabPane visible={activeTab === 'razorpay'}>
                  <div className="tenant-section-head">
                    <p className="tenant-note mb-0">Key ID, Key Secret, and Webhook Secret must all be set together, or all cleared.</p>
                    {!editing && <StatusBadge enabled={!!profile?.razorpay_configured} onLabel="Configured" offLabel="Not configured" />}
                  </div>
                  {editing ? (
                    <div className="row g-3">
                      <div className="col-md-4">
                        <Field label="Mode">
                          <Controller name="razorpay_is_live" control={control} render={({ field }) => (
                            <CFormSwitch id="razorpay_is_live" label={field.value ? 'Live' : 'Test'} checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />
                          )} />
                        </Field>
                      </div>
                      <div className="col-md-8">
                        <Field label="Key ID" error={errors.razorpay_key_id?.message}>
                          <CFormInput className="filter-input" {...register('razorpay_key_id')} placeholder="rzp_test_... or rzp_live_..." />
                        </Field>
                      </div>
                      <div className="col-md-6">
                        <Field label="Key secret">
                          <CFormInput className="filter-input" type="password" {...register('razorpay_key_secret')} placeholder={profile?.razorpay_configured ? 'Leave blank to keep existing' : 'Enter secret'} />
                        </Field>
                      </div>
                      <div className="col-md-6">
                        <Field label="Webhook secret">
                          <CFormInput className="filter-input" type="password" {...register('razorpay_webhook_secret')} placeholder={profile?.razorpay_configured ? 'Leave blank to keep existing' : 'Enter secret'} />
                        </Field>
                      </div>
                    </div>
                  ) : (
                    <>
                      <ValueRow label="Mode" badge value={<CBadge color={profile?.razorpay_is_live ? 'warning' : 'secondary'} shape="rounded-pill">{profile?.razorpay_is_live ? 'Live' : 'Test'}</CBadge>} />
                      <ValueRow label="Key ID" value={profile?.razorpay_key_id} />
                      <ValueRow label="Key secret" value={profile?.razorpay_configured ? '••••••••' : '—'} />
                    </>
                  )}
                </CTabPane>
              </PermissionGate>

              {/* ── PUSHER ──────────────────────────────── */}
              <PermissionGate permission="profile.pusher_edit">
                <CTabPane visible={activeTab === 'pusher'}>
                  <div className="tenant-section-head">
                    <p className="tenant-note mb-0">Powers live order updates. All four fields together, or all cleared.</p>
                    {!editing && <StatusBadge enabled={!!profile?.pusher_configured} onLabel="Configured" offLabel="Not configured" />}
                  </div>
                  {editing ? (
                    <div className="row g-3">
                      <div className="col-md-6"><Field label="App ID"><CFormInput className="filter-input" {...register('pusher_app_id')} /></Field></div>
                      <div className="col-md-6"><Field label="Key"><CFormInput className="filter-input" {...register('pusher_key')} /></Field></div>
                      <div className="col-md-6"><Field label="Secret"><CFormInput className="filter-input" type="password" {...register('pusher_secret')} placeholder={profile?.pusher_configured ? 'Leave blank to keep existing' : 'Enter secret'} /></Field></div>
                      <div className="col-md-6"><Field label="Cluster"><CFormInput className="filter-input" {...register('pusher_cluster')} /></Field></div>
                    </div>
                  ) : (
                    <>
                      <ValueRow label="App ID" value={profile?.pusher_app_id} />
                      <ValueRow label="Key" value={profile?.pusher_key} />
                      <ValueRow label="Cluster" value={profile?.pusher_cluster} />
                    </>
                  )}
                </CTabPane>
              </PermissionGate>

              {/* ── SMS ─────────────────────────────────── */}
              <PermissionGate permission="profile.sms_edit">
                <CTabPane visible={activeTab === 'sms'}>
                  <div className="tenant-section-head">
                    <p className="tenant-note mb-0">Username, Password, and Sender ID together, or all cleared.</p>
                    {!editing && <StatusBadge enabled={!!profile?.sms_configured} onLabel="Configured" offLabel="Not configured" />}
                  </div>
                  {editing && (
                    <div className="tenant-sms-switch mb-3">
                      <Controller name="sms_enabled" control={control} render={({ field }) => (
                        <CFormSwitch id="sms_enabled" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} label={field.value ? 'SMS credential is active' : 'SMS credential paused'} />
                      )} />
                    </div>
                  )}
                  {editing ? (
                    <div className="row g-3">
                      <div className="col-md-4"><Field label="Username"><CFormInput className="filter-input" {...register('sms_username')} /></Field></div>
                      <div className="col-md-4"><Field label="Password"><CFormInput className="filter-input" type="password" {...register('sms_password')} placeholder={profile?.sms_configured ? 'Leave blank to keep existing' : 'Enter password'} /></Field></div>
                      <div className="col-md-4"><Field label="Sender ID" hint="e.g. KUTMBK" error={errors.sms_sender_id?.message}><CFormInput className="filter-input" {...register('sms_sender_id')} style={{ textTransform: 'uppercase' }} maxLength={10} /></Field></div>
                    </div>
                  ) : (
                    <>
                      <ValueRow label="Username" value={profile?.sms_username} />
                      <ValueRow label="Sender ID" value={profile?.sms_sender_id} />
                    </>
                  )}
                </CTabPane>
              </PermissionGate>

            </CTabContent>
          </CCardBody>

          {editing && (
            <div className="tenant-footer">
              <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
                {submitting ? <CSpinner size="sm" className="me-2" /> : <CIcon icon={cilSave} className="me-2" />}
                {profile ? 'Save changes' : 'Create profile'}
              </CButton>
              <CButton type="button" className="filter-btn filter-btn--ghost" onClick={cancelEdit} disabled={submitting}>
                <CIcon icon={cilX} className="me-2" />Cancel
              </CButton>
            </div>
          )}

          {!editing && !profile && (
            <div className="tenant-footer tenant-footer--plain">
              <PermissionGate permission="profile.edit">
                <p className="tenant-note mb-0">No profile configured yet. Click <strong>Edit</strong> to get started.</p>
              </PermissionGate>
            </div>
          )}
        </CForm>
      </CCard>

      <CModal visible={slotModal} onClose={() => { setSlotModal(false); setSlotEditing(null) }} backdrop="static">
        <CModalHeader>
          <CModalTitle>{slotEditing ? 'Edit Delivery Slot' : 'Add Delivery Slot'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSaveSlot}>
          <CModalBody>
            {slotError && <CAlert color="danger">{slotError}</CAlert>}

            {slotEditing?.is_locked && (
              <CAlert color="info" className="small">
                Start and end times are locked because past orders reference this slot.
                You can still change the name, cutoff, or active status.
              </CAlert>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">Slot Name <span className="text-danger">*</span></CFormLabel>
              <CFormInput
                className="filter-input"
                value={slotForm.name}
                onChange={e => setSlotForm({ ...slotForm, name: e.target.value })}
                placeholder="e.g. Morning, Evening"
                required
              />
            </div>
            <div className="row g-3">
              <div className="col-6">
                <CFormLabel className="filter-label">Start Time <span className="text-danger">*</span></CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="time"
                  value={slotForm.start_time}
                  onChange={e => setSlotForm({ ...slotForm, start_time: e.target.value })}
                  required
                  disabled={!!slotEditing?.is_locked}
                  title={slotEditing?.is_locked ? 'Locked — past orders reference this slot' : ''}
                />
              </div>
              <div className="col-6">
                <CFormLabel className="filter-label">End Time <span className="text-danger">*</span></CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="time"
                  value={slotForm.end_time}
                  onChange={e => setSlotForm({ ...slotForm, end_time: e.target.value })}
                  required
                  disabled={!!slotEditing?.is_locked}
                  title={slotEditing?.is_locked ? 'Locked — past orders reference this slot' : ''}
                />
              </div>
            </div>
            <div className="mt-3">
              <CFormLabel className="filter-label">
                Cutoff time
                <span className="tenant-hint-inline"> · must be earlier than the slot start time</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="time"
                max={slotForm.start_time || undefined}
                value={slotForm.cutoff_time || ''}
                onChange={e => setSlotForm({ ...slotForm, cutoff_time: e.target.value })}
              />
              <div className="tenant-hint mt-1">
                Example: for a 07:00–08:00 slot, cutoff 02:00 is valid (customers cannot book after 02:00).
                For a 10:00–12:00 slot, cutoff 09:00 is valid. Cutoff must be earlier than the start time.
              </div>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton
              type="button"
              className="filter-btn filter-btn--ghost"
              onClick={() => { setSlotModal(false); setSlotEditing(null) }}
              disabled={slotSubmitting}
            >
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={slotSubmitting}>
              {slotSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
              {slotEditing ? 'Save Changes' : 'Save Slot'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>
    </div>
  )
}

export default TenantProfile