/**
 * ThemePreview.jsx
 *
 * Admin component — lets admins preview and assign color schemas to tenants.
 * Drop this into your tenant management / settings page.
 *
 * Usage:
 *   <ThemePreview
 *     currentThemeKey="navyCrimson"
 *     onSelect={(key) => saveTenantTheme(tenantId, key)}
 *   />
 */

import { useState } from 'react'
import { CCard, CCardBody, CButton, CBadge, CRow, CCol } from '@coreui/react'
import { THEMES } from '../../config/themeTokens'
import useUiStore from '../../store/uiStore'

export default function ThemePreview({ currentThemeKey, onSelect }) {
  const { setTheme, themeKey: activeKey } = useUiStore()
  const [previewing, setPreviewing] = useState(null)

  const handlePreview = (key) => {
    setPreviewing(key)
    setTheme(key)  // live preview — applies instantly across all pages
  }

  const handleSelect = (key) => {
    onSelect?.(key)
    setPreviewing(null)
  }

  const handleCancel = () => {
    setPreviewing(null)
    setTheme(currentThemeKey)  // revert to saved theme
  }

  return (
    <div className="page-wrapper">
      <div className="page-header">
        <div>
          <h1 className="page-title">Color Schemas</h1>
          <p className="page-subtitle">
            Preview applies live across the entire app. Save to assign to this tenant.
          </p>
        </div>
        {previewing && previewing !== currentThemeKey && (
          <div className="d-flex gap-2">
            <CButton
              size="sm"
              style={{ background: 'var(--color-bg-hover)', border: '1px solid var(--color-border-color)', color: 'var(--color-text-secondary)' }}
              onClick={handleCancel}
            >
              Cancel Preview
            </CButton>
            <CButton
              size="sm"
              style={{ background: 'var(--color-primary)', border: 'none', color: '#fff', fontWeight: 600 }}
              onClick={() => handleSelect(previewing)}
            >
              Save Schema
            </CButton>
          </div>
        )}
      </div>

      <CRow className="g-3">
        {Object.entries(THEMES).map(([key, theme]) => {
          const isCurrent  = key === currentThemeKey
          const isActive   = key === activeKey
          const isPreviewed = key === previewing

          return (
            <CCol md={6} xl={4} key={key}>
              <CCard
                className="t-card"
                style={{
                  cursor: 'pointer',
                  outline: isActive ? `2px solid ${theme.tokens.primary}` : '2px solid transparent',
                  outlineOffset: 2,
                  transition: 'outline 0.2s',
                }}
                onClick={() => handlePreview(key)}
              >
                <CCardBody className="t-card-body">

                  {/* Color swatches */}
                  <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
                    {theme.preview.map((color, i) => (
                      <div key={i} style={{
                        flex: i === 0 ? 2 : 1,
                        height: 36,
                        background: color,
                        borderRadius: 6,
                        border: '1px solid rgba(255,255,255,0.08)',
                      }} />
                    ))}
                  </div>

                  {/* Label row */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span className="text-primary-color fw-700" style={{ fontSize: 14 }}>
                      {theme.label}
                    </span>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {isCurrent && (
                        <CBadge style={{
                          background: `${theme.tokens.primary}20`,
                          color: theme.tokens.primary,
                          border: `1px solid ${theme.tokens.primary}40`,
                          fontSize: 10, padding: '2px 8px', borderRadius: 20,
                        }}>
                          Saved
                        </CBadge>
                      )}
                      {isPreviewed && !isCurrent && (
                        <CBadge style={{
                          background: `${theme.tokens.success}20`,
                          color: theme.tokens.success,
                          border: `1px solid ${theme.tokens.success}40`,
                          fontSize: 10, padding: '2px 8px', borderRadius: 20,
                        }}>
                          Previewing
                        </CBadge>
                      )}
                    </div>
                  </div>

                  <p className="text-muted-color" style={{ fontSize: 12, margin: 0 }}>
                    {theme.description}
                  </p>

                  {/* Mini UI preview */}
                  <div style={{
                    marginTop: 14,
                    background: theme.tokens.bgBase,
                    borderRadius: 8,
                    padding: 10,
                    border: `1px solid ${theme.tokens.borderColor}`,
                  }}>
                    <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                      {['Revenue', 'Orders', 'Stock'].map((label, i) => (
                        <div key={label} style={{
                          flex: 1,
                          background: theme.tokens.bgCard,
                          border: `1px solid ${theme.tokens.borderColor}`,
                          borderLeft: `2px solid ${i === 0 ? theme.tokens.primary : i === 1 ? theme.tokens.info : theme.tokens.success}`,
                          borderRadius: 6,
                          padding: '6px 8px',
                        }}>
                          <div style={{ color: theme.tokens.textMuted, fontSize: 8, marginBottom: 3 }}>{label}</div>
                          <div style={{ color: theme.tokens.textPrimary, fontWeight: 700, fontSize: 11 }}>
                            {i === 0 ? '₹71k' : i === 1 ? '356' : '4.8k'}
                          </div>
                        </div>
                      ))}
                    </div>
                    {/* Mini bar chart */}
                    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 28 }}>
                      {[40, 64, 52, 82, 66, 94, 71].map((h, i) => (
                        <div key={i} style={{
                          flex: 1,
                          height: `${h}%`,
                          background: i === 5
                            ? theme.tokens.primary
                            : `${theme.tokens.primary}50`,
                          borderRadius: '2px 2px 0 0',
                        }} />
                      ))}
                    </div>
                  </div>

                </CCardBody>
              </CCard>
            </CCol>
          )
        })}
      </CRow>
    </div>
  )
}
