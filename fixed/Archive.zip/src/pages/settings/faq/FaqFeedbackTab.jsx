import { useEffect, useRef, useState } from 'react'
import {
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilThumbUp, cilThumbDown, cilLowVision } from '@coreui/icons'
import faqApi from '../../../services/faqApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const RANGE_OPTIONS = [
  { value: 'all',   label: 'All time' },
  { value: 'worst', label: 'Needs review (👎 > 👍)' },
  { value: 'best',  label: 'Best rated (👍 ≥ 80%)' },
]

const healthColor = (ratio) => {
  if (ratio === null || ratio === undefined) return 'secondary'
  if (ratio >= 0.8) return 'success'
  if (ratio >= 0.5) return 'warning'
  return 'danger'
}

const healthLabel = (ratio) => {
  if (ratio === null || ratio === undefined) return 'No votes'
  return `${Math.round(ratio * 100)}% helpful`
}

const FaqFeedbackTab = () => {
  const [rows, setRows] = useState([])
  const [collections, setCollections] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [collectionFilter, setCollectionFilter] = useState('')
  const [range, setRange] = useState('worst')

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchCollections = async () => {
    try {
      const list = await faqApi.listCollections()
      setCollections(list)
    } catch { /* silent */ }
  }

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    collectionOverride = collectionFilter,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = {
        page,
        per_page: perPageOverride,
        status: 'all',
        sort: 'feedback',
      }
      if (searchOverride) params.search = searchOverride
      if (collectionOverride) params.collection_id = collectionOverride

      const res = await faqApi.listItems(params)
      if (mySeq !== requestSeq.current) return

      let filtered = res.items
      if (range === 'worst') {
        filtered = filtered.filter((r) => {
          const total = r.helpful_count + r.not_helpful_count
          if (total < 3) return false
          return r.not_helpful_count > r.helpful_count
        })
      } else if (range === 'best') {
        filtered = filtered.filter((r) => (r.helpful_ratio ?? 0) >= 0.8 && r.helpful_count > 0)
      }

      setRows(filtered)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load feedback data.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCollections()
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  useEffect(() => {
    setPageLoading(true)
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionFilter, range])

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm"
            className="filter-input"
            placeholder="Search questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Collection</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={collectionFilter}
            onChange={(e) => setCollectionFilter(e.target.value)}
          >
            <option value="">All collections</option>
            {collections.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Show</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={range}
            onChange={(e) => setRange(e.target.value)}
          >
            {RANGE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading feedback...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">👍</div>
            <div className="faq-empty__title">No FAQs in this view</div>
            <div className="faq-empty__sub">
              {range === 'worst'
                ? 'Nothing is currently getting more 👎 than 👍.'
                : range === 'best'
                  ? 'No FAQs have 80%+ helpful ratings yet.'
                  : 'No data yet.'}
            </div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => {
              const total = row.helpful_count + row.not_helpful_count
              const upPct = total > 0 ? (row.helpful_count / total) * 100 : 0
              const downPct = total > 0 ? (row.not_helpful_count / total) * 100 : 0

              return (
                <div key={row.id} className="faq-card">
                  <div className="faq-card__title">{row.question}</div>
                  <div className="faq-card__meta">
                    {row.collection && (
                      <CBadge color="info" shape="rounded-pill">{row.collection.name}</CBadge>
                    )}
                    <span className="faq-card__meta-item">
                      <CIcon icon={cilLowVision} size="sm" /> {row.view_count} views
                    </span>
                    <CBadge color={healthColor(row.helpful_ratio)} shape="rounded-pill">
                      {healthLabel(row.helpful_ratio)}
                    </CBadge>
                  </div>

                  {total > 0 && (
                    <div className="faq-progress">
                      <div className="faq-progress__up" style={{ width: `${upPct}%` }} />
                      <div className="faq-progress__down" style={{ width: `${downPct}%` }} />
                    </div>
                  )}

                  <div className="d-flex gap-3 mt-3" style={{ fontSize: '0.88rem', fontWeight: 700 }}>
                    <span className="d-flex align-items-center gap-1" style={{ color: '#059669' }}>
                      <CIcon icon={cilThumbUp} size="sm" /> {row.helpful_count}
                    </span>
                    <span className="d-flex align-items-center gap-1" style={{ color: '#dc2626' }}>
                      <CIcon icon={cilThumbDown} size="sm" /> {row.not_helpful_count}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />
    </>
  )
}

export default FaqFeedbackTab