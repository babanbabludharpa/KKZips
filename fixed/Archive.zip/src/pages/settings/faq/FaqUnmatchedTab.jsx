import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CFormTextarea, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilTrash, cilArrowRight } from '@coreui/icons'
import faqApi from '../../../services/faqApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const timeAgo = (iso) => {
  if (!iso) return '—'
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

const languageLabel = (code) => {
  if (code === 'dev')  return 'Devanagari'
  if (code === 'latn') return 'Latin'
  return '—'
}

const FaqUnmatchedTab = () => {
  const [rows, setRows] = useState([])
  const [collections, setCollections] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [status, setStatus] = useState('pending')

  const [convertModal, setConvertModal] = useState({ open: false, row: null })
  const [dismissModal, setDismissModal] = useState({ open: false, row: null })
  const [submitting, setSubmitting] = useState(false)
  const [modalError, setModalError] = useState(null)

  const [form, setForm] = useState({
    collection_id: '',
    question: '',
    answer: '',
    alternatives: '',
    keywords: '',
  })

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchCollections = async () => {
    try {
      const list = await faqApi.listCollections()
      setCollections(list)
    } catch { /* silent */ }
  }

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    statusOverride = status,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = { page, per_page: perPageOverride, status: statusOverride }
      if (searchOverride) params.search = searchOverride

      const res = await faqApi.listUnmatched(params)
      if (mySeq !== requestSeq.current) return

      setRows(res.items)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load unmatched questions.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCollections()
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  useEffect(() => {
    setPageLoading(true)
    fetchData({ page: 1, statusOverride: status })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status])

  const openConvert = (row) => {
    const humanized = row.question.charAt(0).toUpperCase() + row.question.slice(1)
    setForm({
      collection_id: '',
      question: humanized.match(/[?!.]$/) ? humanized : humanized + '?',
      answer: '',
      alternatives: row.question,
      keywords: '',
    })
    setModalError(null)
    setConvertModal({ open: true, row })
  }

  const submitConvert = async () => {
    if (!form.collection_id) { setModalError('Collection is required.'); return }
    if (!form.answer.trim()) { setModalError('Answer is required.'); return }

    setSubmitting(true)
    setModalError(null)
    try {
      await faqApi.convertUnmatched(convertModal.row.id, {
        collection_id: parseInt(form.collection_id, 10),
        question: form.question.trim(),
        answer: form.answer.trim(),
        alternatives: form.alternatives
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        keywords: form.keywords
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
      })
      setConvertModal({ open: false, row: null })
      fetchData()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Failed to convert.')
    } finally {
      setSubmitting(false)
    }
  }

  const confirmDismiss = async () => {
    setSubmitting(true)
    try {
      await faqApi.dismissUnmatched(dismissModal.row.id)
      setDismissModal({ open: false, row: null })
      fetchData()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to dismiss.')
    } finally {
      setSubmitting(false)
    }
  }

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm"
            className="filter-input"
            placeholder="Search questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Status</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="pending">Pending</option>
            <option value="converted">Converted</option>
            <option value="all">All</option>
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading unmatched questions...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">✓</div>
            <div className="faq-empty__title">No unmatched questions</div>
            <div className="faq-empty__sub">
              {status === 'pending'
                ? 'Every customer question has been answered by an existing FAQ.'
                : 'Nothing to show for this filter.'}
            </div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.id}
                className="faq-card"
                style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="faq-card__title">{row.question}</div>
                  <div className="faq-card__meta">
                    <CBadge color="warning" shape="rounded-pill">
                      Asked {row.hit_count} {row.hit_count === 1 ? 'time' : 'times'}
                    </CBadge>
                    <span className="faq-card__meta-item">{languageLabel(row.language_guess)}</span>
                    <span className="faq-card__meta-item">{timeAgo(row.last_asked_at)}</span>
                    {row.converted_faq_id && (
                      <CBadge color="success" shape="rounded-pill">Converted</CBadge>
                    )}
                  </div>
                </div>

                <div className="faq-card__actions">
                  {!row.converted_faq_id && (
                    <>
                      <CButton
                        size="sm"
                        className="filter-btn filter-btn--primary"
                        onClick={() => openConvert(row)}
                      >
                        <CIcon icon={cilArrowRight} className="me-1" />
                        Convert
                      </CButton>
                      <CButton
                        size="sm"
                        className="filter-btn filter-btn--ghost"
                        onClick={() => setDismissModal({ open: true, row })}
                        title="Dismiss without converting"
                      >
                        <CIcon icon={cilTrash} />
                      </CButton>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />

      {/* ── Convert modal ── */}
      <CModal
        visible={convertModal.open}
        onClose={() => setConvertModal({ open: false, row: null })}
        size="lg"
        backdrop="static"
      >
        <CModalHeader>
          <CModalTitle>Convert to FAQ</CModalTitle>
        </CModalHeader>
        <CModalBody>
          {modalError && (
            <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
              {modalError}
            </CAlert>
          )}

          <div className="mb-3 p-2 rounded" style={{ background: '#f8fafc', border: '1px solid #e2e8f0', fontSize: '0.85rem' }}>
            <strong>Original question:</strong> {convertModal.row?.question}
            <div className="text-muted mt-1" style={{ fontSize: '0.78rem' }}>
              Asked {convertModal.row?.hit_count} {convertModal.row?.hit_count === 1 ? 'time' : 'times'}
            </div>
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Collection *</CFormLabel>
            <CFormSelect
              className="filter-input"
              value={form.collection_id}
              onChange={(e) => setForm((f) => ({ ...f, collection_id: e.target.value }))}
            >
              <option value="">Select collection</option>
              {collections.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Question *</CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.question}
              onChange={(e) => setForm((f) => ({ ...f, question: e.target.value }))}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Answer *</CFormLabel>
            <CFormTextarea
              className="filter-input"
              rows={5}
              value={form.answer}
              onChange={(e) => setForm((f) => ({ ...f, answer: e.target.value }))}
              placeholder="Write the answer the customer should receive..."
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">
              Alternative questions
              <span className="tenant-hint-inline"> · one per line</span>
            </CFormLabel>
            <CFormTextarea
              className="filter-input"
              rows={4}
              value={form.alternatives}
              onChange={(e) => setForm((f) => ({ ...f, alternatives: e.target.value }))}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">
              Keywords
              <span className="tenant-hint-inline"> · comma-separated</span>
            </CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.keywords}
              onChange={(e) => setForm((f) => ({ ...f, keywords: e.target.value }))}
              placeholder="e.g. order, cancel, refund"
            />
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setConvertModal({ open: false, row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitConvert}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Create FAQ
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ── Dismiss modal ── */}
      <CModal
        visible={dismissModal.open}
        onClose={() => setDismissModal({ open: false, row: null })}
      >
        <CModalHeader>
          <CModalTitle>Dismiss Question</CModalTitle>
        </CModalHeader>
        <CModalBody>
          Dismiss <strong>{dismissModal.row?.question}</strong>? It will be removed from the
          unmatched list. This does not create a FAQ.
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDismissModal({ open: false, row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={confirmDismiss}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Dismiss
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default FaqUnmatchedTab