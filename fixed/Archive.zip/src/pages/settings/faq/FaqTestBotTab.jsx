import { useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilSend, cilCheckCircle, cilXCircle, cilSearch } from '@coreui/icons'
import faqApi from '../../../services/faqApi'

const LAYER_COLORS = {
  exact:    'success',
  keyword:  'info',
  semantic: 'primary',
  fallback: 'secondary',
}

const CONFIDENCE_COLORS = {
  high:   'success',
  medium: 'warning',
  low:    'danger',
}

const FaqTestBotTab = () => {
  const [question, setQuestion] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [history, setHistory] = useState([])

  const runTest = async () => {
    const q = question.trim()
    if (q.length < 2) {
      setError('Please enter at least 2 characters.')
      return
    }

    setLoading(true)
    setError(null)
    try {
      const res = await faqApi.testQuestion(q)
      setResult(res)
      setHistory((h) => [
        { question: q, result: res, at: new Date() },
        ...h.slice(0, 9),
      ])
    } catch (e) {
      setError(e.response?.data?.message ?? 'Test failed.')
    } finally {
      setLoading(false)
    }
  }

  const runAgain = (q) => {
    setQuestion(q)
    setTimeout(runTest, 0)
  }

  return (
    <div className="p-3">
      <div className="mb-3 p-3 rounded" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
        <div style={{ fontSize: '0.88rem', color: '#475569', lineHeight: 1.5 }}>
          <strong>Test Bot</strong> runs your question through the exact same matcher the customer
          app uses — exact → keyword → semantic → fallback. Use it to check whether a phrasing
          matches an FAQ, and which layer caught it.
        </div>
      </div>

      {error && (
        <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
      )}

      <div className="mb-3 d-flex gap-2 faq-filters">
        <CFormInput
          className="filter-input"
          placeholder="Type a question, e.g. delivery kab hogi"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !loading && runTest()}
          disabled={loading}
        />
        <CButton
          className="filter-btn filter-btn--primary"
          onClick={runTest}
          disabled={loading || question.trim().length < 2}
        >
          {loading ? <CSpinner size="sm" /> : <CIcon icon={cilSend} className="me-1" />}
          {loading ? 'Running…' : 'Test'}
        </CButton>
      </div>

      {result && (
        <div className="faq-test-result mb-3">
          <div className="d-flex align-items-center gap-2 mb-3 flex-wrap">
            {result.matched ? (
              <CBadge color="success" shape="rounded-pill">
                <CIcon icon={cilCheckCircle} size="sm" className="me-1" />
                Matched
              </CBadge>
            ) : (
              <CBadge color="danger" shape="rounded-pill">
                <CIcon icon={cilXCircle} size="sm" className="me-1" />
                No match
              </CBadge>
            )}
            <CBadge color={LAYER_COLORS[result.layer] ?? 'secondary'} shape="rounded-pill">
              Layer: {result.layer}
            </CBadge>
            {result.confidence && (
              <CBadge color={CONFIDENCE_COLORS[result.confidence] ?? 'secondary'} shape="rounded-pill">
                Confidence: {result.confidence}
              </CBadge>
            )}
            {result.score != null && (
              <CBadge color="dark" shape="rounded-pill">
                Score: {result.score.toFixed(4)}
              </CBadge>
            )}
          </div>

          {result.faq ? (
            <>
              <div className="mb-3">
                <div className="faq-test-meta-label">Matched FAQ</div>
                <div style={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a', marginTop: 6 }}>
                  {result.faq.question}
                </div>
                {result.faq.collection && (
                  <div style={{ fontSize: '0.85rem', color: '#475569', marginTop: 4, fontWeight: 500 }}>
                    Collection: {result.faq.collection}
                  </div>
                )}
              </div>

              <div>
                <div className="faq-test-meta-label">Answer</div>
                <div className="faq-test-answer">{result.faq.answer}</div>
              </div>
            </>
          ) : (
            <div style={{ color: '#475569', fontSize: '0.92rem', lineHeight: 1.5 }}>
              The matcher would return the fallback message. Check the "Top candidates" below if any came close.
            </div>
          )}

          {result.suggestions?.length > 0 && (
            <div className="mt-3">
              <div className="faq-test-meta-label mb-2">Top candidates</div>
              <div className="d-flex flex-column gap-1">
                {result.suggestions.map((s) => (
                  <div
                    key={s.id}
                    className="d-flex align-items-center justify-content-between"
                    style={{
                      padding: '10px 14px',
                      background: '#fff',
                      border: '1px solid #e2e8f0',
                      borderRadius: 8,
                      fontSize: '0.88rem',
                      fontWeight: 500,
                    }}
                  >
                    <span>{s.question}</span>
                    <CBadge color="secondary" shape="rounded-pill">
                      {s.score?.toFixed(4)}
                    </CBadge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {Object.keys(result.metadata ?? {}).length > 0 && (
            <details className="mt-3" style={{ fontSize: '0.82rem', color: '#64748b' }}>
              <summary style={{ cursor: 'pointer', fontWeight: 600 }}>Metadata</summary>
              <pre style={{ marginTop: 6, fontSize: '0.75rem', whiteSpace: 'pre-wrap' }}>
                {JSON.stringify(result.metadata, null, 2)}
              </pre>
            </details>
          )}
        </div>
      )}

      {history.length > 0 && (
        <div>
          <div className="faq-test-meta-label mb-2">Recent tests</div>
          <div className="d-flex flex-column gap-1">
            {history.map((h, idx) => (
              <button
                key={idx}
                type="button"
                className="text-start"
                onClick={() => runAgain(h.question)}
                style={{
                  padding: '10px 14px',
                  background: '#fff',
                  border: '1px solid #e2e8f0',
                  borderRadius: 8,
                  fontSize: '0.88rem',
                  fontWeight: 500,
                  cursor: 'pointer',
                }}
              >
                <div className="d-flex align-items-center gap-2">
                  <CIcon icon={cilSearch} size="sm" style={{ color: '#64748b' }} />
                  <span style={{ flex: 1 }}>{h.question}</span>
                  <CBadge
                    color={h.result.matched ? 'success' : 'secondary'}
                    shape="rounded-pill"
                  >
                    {h.result.matched ? 'Matched' : 'Miss'}
                  </CBadge>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default FaqTestBotTab

