import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CFormTextarea, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilList } from '@coreui/icons'
import faqApi from '../../../services/faqApi'

const FaqCollectionsTab = () => {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [editor, setEditor] = useState({ open: false, mode: 'create', row: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, row: null })
  const [submitting, setSubmitting] = useState(false)
  const [modalError, setModalError] = useState(null)

  const [form, setForm] = useState({
    name: '',
    description: '',
    icon: '',
    sort_order: 0,
    is_active: true,
  })

  const requestSeq = useRef(0)

  const fetchData = async () => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const list = await faqApi.listCollections()
      if (mySeq !== requestSeq.current) return
      setRows(list)
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load collections.')
    } finally {
      if (mySeq === requestSeq.current) setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const openCreate = () => {
    setForm({ name: '', description: '', icon: '', sort_order: rows.length + 1, is_active: true })
    setModalError(null)
    setEditor({ open: true, mode: 'create', row: null })
  }

  const openEdit = (row) => {
    setForm({
      name: row.name ?? '',
      description: row.description ?? '',
      icon: row.icon ?? '',
      sort_order: row.sort_order ?? 0,
      is_active: row.is_active ?? true,
    })
    setModalError(null)
    setEditor({ open: true, mode: 'edit', row })
  }

  const submitEditor = async () => {
    if (!form.name.trim()) { setModalError('Name is required.'); return }

    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      icon: form.icon.trim() || null,
      sort_order: parseInt(form.sort_order, 10) || 0,
      is_active: form.is_active,
    }

    setSubmitting(true)
    setModalError(null)
    try {
      if (editor.mode === 'edit') {
        await faqApi.updateCollection(editor.row.id, payload)
      } else {
        await faqApi.createCollection(payload)
      }
      setEditor({ open: false, mode: 'create', row: null })
      fetchData()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Failed to save collection.')
    } finally {
      setSubmitting(false)
    }
  }

  const confirmDelete = async () => {
    setSubmitting(true)
    try {
      await faqApi.deleteCollection(deleteModal.row.id)
      setDeleteModal({ open: false, row: null })
      fetchData()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to delete collection.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--buttons ms-auto">
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={openCreate}
          >
            <CIcon icon={cilPlus} className="me-1" />
            Add Collection
          </CButton>
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading collections...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">📁</div>
            <div className="faq-empty__title">No collections yet</div>
            <div className="faq-empty__sub">Click "Add Collection" to create your first one.</div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.id}
                className="faq-card"
                style={{ display: 'flex', alignItems: 'center', gap: 16 }}
              >
                <div className={`faq-icon-chip${row.is_active ? '' : ' faq-icon-chip--muted'}`}>
                  <CIcon icon={cilList} />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="d-flex align-items-center gap-2 mb-1">
                    <span className="faq-card__title" style={{ marginBottom: 0 }}>{row.name}</span>
                    <CBadge color="secondary" shape="rounded-pill">
                      {row.items_count ?? 0} FAQ{(row.items_count ?? 0) === 1 ? '' : 's'}
                    </CBadge>
                    {!row.is_active && (
                      <CBadge color="warning" shape="rounded-pill">Inactive</CBadge>
                    )}
                  </div>
                  {row.description && (
                    <div style={{ fontSize: '0.88rem', color: '#475569', marginTop: 4, fontWeight: 500 }}>
                      {row.description}
                    </div>
                  )}
                  <div style={{ fontSize: '0.78rem', color: '#94a3b8', marginTop: 6, fontWeight: 500 }}>
                    slug: {row.slug} · sort: {row.sort_order}
                  </div>
                </div>

                <div className="faq-card__actions">
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => openEdit(row)}
                    title="Edit"
                  >
                    <CIcon icon={cilPencil} />
                  </CButton>
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => setDeleteModal({ open: true, row })}
                    title="Delete"
                  >
                    <CIcon icon={cilTrash} />
                  </CButton>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Create / Edit modal ── */}
      <CModal
        visible={editor.open}
        onClose={() => setEditor({ open: false, mode: 'create', row: null })}
        backdrop="static"
      >
        <CModalHeader>
          <CModalTitle>{editor.mode === 'edit' ? 'Edit Collection' : 'Add Collection'}</CModalTitle>
        </CModalHeader>
        <CModalBody>
          {modalError && (
            <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
              {modalError}
            </CAlert>
          )}

          <div className="mb-3">
            <CFormLabel className="filter-label">Name *</CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="e.g. Delivery, Payments"
              maxLength={100}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Description</CFormLabel>
            <CFormTextarea
              className="filter-input"
              rows={2}
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              placeholder="Short description shown under the collection name"
              maxLength={255}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">
              Icon
              <span className="tenant-hint-inline"> · optional · e.g. truck, wallet</span>
            </CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.icon}
              onChange={(e) => setForm((f) => ({ ...f, icon: e.target.value }))}
              placeholder="truck"
              maxLength={50}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Sort order</CFormLabel>
            <CFormInput
              className="filter-input"
              type="number"
              min={0}
              value={form.sort_order}
              onChange={(e) => setForm((f) => ({ ...f, sort_order: e.target.value }))}
            />
          </div>

          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              id="collection-active"
              checked={form.is_active}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
            />
            <label className="form-check-label" htmlFor="collection-active">
              Active — visible in the customer app
            </label>
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setEditor({ open: false, mode: 'create', row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitEditor}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            {editor.mode === 'edit' ? 'Save changes' : 'Create'}
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ── Delete confirm ── */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, row: null })}
      >
        <CModalHeader>
          <CModalTitle>Delete Collection</CModalTitle>
        </CModalHeader>
        <CModalBody>
          Delete <strong>{deleteModal.row?.name}</strong>? This is only possible if the
          collection has no FAQs. Move or delete its FAQs first.
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={confirmDelete}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default FaqCollectionsTab