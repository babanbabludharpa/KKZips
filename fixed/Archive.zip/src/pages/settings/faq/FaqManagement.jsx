import { useState } from 'react'
import { CCard, CCardBody, CNav, CNavItem, CNavLink, CTabContent, CTabPane } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilList, cilWarning, cilChartLine, cilCog, cilLayers } from '@coreui/icons'
import FaqUnmatchedTab from './FaqUnmatchedTab'
import FaqItemsTab from './FaqItemsTab'
import FaqTestBotTab from './FaqTestBotTab'
import FaqFeedbackTab from './FaqFeedbackTab'
import FaqCollectionsTab from './FaqCollectionsTab'

const TABS = [
  { key: 'items',       label: 'FAQs',        icon: cilList },
  { key: 'unmatched',   label: 'Unmatched',   icon: cilWarning },
  { key: 'test',        label: 'Test Bot',    icon: cilCog },
  { key: 'feedback',    label: 'Feedback',    icon: cilChartLine },
  { key: 'collections', label: 'Collections', icon: cilLayers },
]

const FaqManagement = () => {
  const [activeTab, setActiveTab] = useState('items')

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">FAQ Management</h4>
        </div>

        <CNav variant="tabs" role="tablist" className="tenant-tabs">
          {TABS.map((t) => (
            <CNavItem key={t.key}>
              <CNavLink
                active={activeTab === t.key}
                onClick={() => setActiveTab(t.key)}
                style={{ cursor: 'pointer' }}
                className="tenant-tab-link d-flex align-items-center gap-2"
              >
                <CIcon icon={t.icon} width={15} height={15} />
                <span>{t.label}</span>
              </CNavLink>
            </CNavItem>
          ))}
        </CNav>

        <CCardBody className="tenant-content p-0">
          <CTabContent>
            <CTabPane visible={activeTab === 'items'}>
              <FaqItemsTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'unmatched'}>
              <FaqUnmatchedTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'test'}>
              <FaqTestBotTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'feedback'}>
              <FaqFeedbackTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'collections'}>
              <FaqCollectionsTab />
            </CTabPane>
          </CTabContent>
        </CCardBody>
      </CCard>
    </div>
  )
}

export default FaqManagement