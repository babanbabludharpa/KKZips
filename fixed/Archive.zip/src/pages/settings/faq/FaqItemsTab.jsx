import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CFormTextarea, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPencil, cilTrash, cilPlus, cilThumbUp, cilThumbDown, cilLowVision,
} from '@coreui/icons'
import faqApi from '../../../services/faqApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const SORT_OPTIONS = [
  { value: 'recent',   label: 'Recently updated' },
  { value: 'views',    label: 'Most viewed' },
  { value: 'feedback', label: 'Needs attention (most 👎)' },
  { value: 'question', label: 'Question A–Z' },
]

const STATUS_OPTIONS = [
  { value: 'active',   label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'all',      label: 'All' },
]

const healthColor = (ratio) => {
  if (ratio === null || ratio === undefined) return 'secondary'
  if (ratio >= 0.8) return 'success'
  if (ratio >= 0.5) return 'warning'
  return 'danger'
}

const healthLabel = (ratio) => {
  if (ratio === null || ratio === undefined) return 'No feedback'
  if (ratio >= 0.8) return 'Healthy'
  if (ratio >= 0.5) return 'Mixed'
  return 'Needs review'
}

const FaqItemsTab = () => {
  const [rows, setRows] = useState([])
  const [collections, setCollections] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [collectionFilter, setCollectionFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('active')
  const [sort, setSort] = useState('recent')

  const [editor, setEditor] = useState({ open: false, mode: 'create', row: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, row: null })
  const [submitting, setSubmitting] = useState(false)
  const [modalError, setModalError] = useState(null)

  const [form, setForm] = useState({
    collection_id: '',
    question: '',
    answer: '',
    alternatives: '',
    keywords: '',
    is_active: true,
  })

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchCollections = async () => {
    try {
      const list = await faqApi.listCollections()
      setCollections(list)
    } catch { /* silent */ }
  }

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    collectionOverride = collectionFilter,
    statusOverride = statusFilter,
    sortOverride = sort,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = {
        page,
        per_page: perPageOverride,
        status: statusOverride,
        sort: sortOverride,
      }
      if (searchOverride) params.search = searchOverride
      if (collectionOverride) params.collection_id = collectionOverride

      const res = await faqApi.listItems(params)
      if (mySeq !== requestSeq.current) return

      setRows(res.items)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load FAQs.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCollections()
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  useEffect(() => {
    setPageLoading(true)
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionFilter, statusFilter, sort])

  const openCreate = () => {
    setForm({
      collection_id: collections[0]?.id?.toString() ?? '',
      question: '',
      answer: '',
      alternatives: '',
      keywords: '',
      is_active: true,
    })
    setModalError(null)
    setEditor({ open: true, mode: 'create', row: null })
  }

  const openEdit = async (row) => {
    setModalError(null)
    try {
      const detail = await faqApi.getItem(row.id)
      setForm({
        collection_id: detail.collection_id?.toString() ?? '',
        question: detail.question ?? '',
        answer: detail.answer ?? '',
        alternatives: (detail.alternative_questions ?? []).join('\n'),
        keywords: (detail.keywords ?? []).join(', '),
        is_active: detail.is_active ?? true,
      })
      setEditor({ open: true, mode: 'edit', row: detail })
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to load FAQ.')
    }
  }

  const submitEditor = async () => {
    if (!form.collection_id) { setModalError('Collection is required.'); return }
    if (!form.question.trim()) { setModalError('Question is required.'); return }
    if (!form.answer.trim()) { setModalError('Answer is required.'); return }

    const payload = {
      collection_id: parseInt(form.collection_id, 10),
      question: form.question.trim(),
      answer: form.answer.trim(),
      alternative_questions: form.alternatives
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
      keywords: form.keywords
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      is_active: form.is_active,
    }

    setSubmitting(true)
    setModalError(null)
    try {
      if (editor.mode === 'edit') {
        await faqApi.updateItem(editor.row.id, payload)
      } else {
        await faqApi.createItem(payload)
      }
      setEditor({ open: false, mode: 'create', row: null })
      fetchData()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Failed to save FAQ.')
    } finally {
      setSubmitting(false)
    }
  }

  const toggleActive = async (row) => {
    try {
      await faqApi.updateItem(row.id, { is_active: !row.is_active })
      fetchData()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to update status.')
    }
  }

  const confirmDelete = async () => {
    setSubmitting(true)
    try {
      await faqApi.deleteItem(deleteModal.row.id)
      setDeleteModal({ open: false, row: null })
      fetchData()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to delete.')
    } finally {
      setSubmitting(false)
    }
  }

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm"
            className="filter-input"
            placeholder="Search question or answer..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Collection</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={collectionFilter}
            onChange={(e) => setCollectionFilter(e.target.value)}
          >
            <option value="">All collections</option>
            {collections.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Status</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            {STATUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Sort</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>

        <div className="filter-field filter-field--buttons">
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={openCreate}
            disabled={collections.length === 0}
          >
            <CIcon icon={cilPlus} className="me-1" />
            Add FAQ
          </CButton>
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading FAQs...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">📚</div>
            <div className="faq-empty__title">No FAQs found</div>
            <div className="faq-empty__sub">
              {search || collectionFilter
                ? 'Try adjusting your filters.'
                : 'Click "Add FAQ" to create your first one.'}
            </div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.id}
                className={`faq-card${row.is_active ? '' : ' faq-card--dim'}`}
                style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="faq-card__title">{row.question}</div>
                  <div className="faq-card__meta">
                    {row.collection && (
                      <CBadge color="info" shape="rounded-pill">{row.collection.name}</CBadge>
                    )}
                    <span className="faq-card__meta-item">
                      <CIcon icon={cilLowVision} size="sm" /> {row.view_count} views
                    </span>
                    <span className="faq-card__meta-item" style={{ color: '#059669' }}>
                      <CIcon icon={cilThumbUp} size="sm" /> {row.helpful_count}
                    </span>
                    <span className="faq-card__meta-item" style={{ color: '#dc2626' }}>
                      <CIcon icon={cilThumbDown} size="sm" /> {row.not_helpful_count}
                    </span>
                    <CBadge color={healthColor(row.helpful_ratio)} shape="rounded-pill">
                      {healthLabel(row.helpful_ratio)}
                    </CBadge>
                    {row.customized_at && (
                      <CBadge color="warning" shape="rounded-pill" title="Manually edited by admin">
                        Customized
                      </CBadge>
                    )}
                    {!row.is_active && (
                      <CBadge color="secondary" shape="rounded-pill">Inactive</CBadge>
                    )}
                  </div>
                </div>

                <div className="faq-card__actions">
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => toggleActive(row)}
                  >
                    {row.is_active ? 'Deactivate' : 'Activate'}
                  </CButton>
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => openEdit(row)}
                    title="Edit"
                  >
                    <CIcon icon={cilPencil} />
                  </CButton>
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => setDeleteModal({ open: true, row })}
                    title="Delete"
                  >
                    <CIcon icon={cilTrash} />
                  </CButton>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />

      {/* ── Create / Edit modal ── */}
      <CModal
        visible={editor.open}
        onClose={() => setEditor({ open: false, mode: 'create', row: null })}
        size="lg"
        backdrop="static"
      >
        <CModalHeader>
          <CModalTitle>{editor.mode === 'edit' ? 'Edit FAQ' : 'Add FAQ'}</CModalTitle>
        </CModalHeader>
        <CModalBody>
          {modalError && (
            <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
              {modalError}
            </CAlert>
          )}

          <div className="mb-3">
            <CFormLabel className="filter-label">Collection *</CFormLabel>
            <CFormSelect
              className="filter-input"
              value={form.collection_id}
              onChange={(e) => setForm((f) => ({ ...f, collection_id: e.target.value }))}
            >
              <option value="">Select collection</option>
              {collections.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Question *</CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.question}
              onChange={(e) => setForm((f) => ({ ...f, question: e.target.value }))}
              placeholder="e.g. How do I place an order?"
              maxLength={500}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">Answer *</CFormLabel>
            <CFormTextarea
              className="filter-input"
              rows={6}
              value={form.answer}
              onChange={(e) => setForm((f) => ({ ...f, answer: e.target.value }))}
              placeholder="Write the answer the customer should receive..."
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">
              Alternative questions
              <span className="tenant-hint-inline"> · one per line · how customers might phrase this</span>
            </CFormLabel>
            <CFormTextarea
              className="filter-input"
              rows={4}
              value={form.alternatives}
              onChange={(e) => setForm((f) => ({ ...f, alternatives: e.target.value }))}
              placeholder={'How to order\norder kaise kare\norder karu kase'}
            />
          </div>

          <div className="mb-3">
            <CFormLabel className="filter-label">
              Keywords
              <span className="tenant-hint-inline"> · comma-separated · used for fast pre-filtering</span>
            </CFormLabel>
            <CFormInput
              className="filter-input"
              value={form.keywords}
              onChange={(e) => setForm((f) => ({ ...f, keywords: e.target.value }))}
              placeholder="e.g. order, place, buy"
            />
          </div>

          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              id="faq-is-active"
              checked={form.is_active}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
            />
            <label className="form-check-label" htmlFor="faq-is-active">
              Active — visible to customers
            </label>
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setEditor({ open: false, mode: 'create', row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitEditor}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            {editor.mode === 'edit' ? 'Save changes' : 'Create FAQ'}
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ── Delete confirm ── */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, row: null })}
      >
        <CModalHeader>
          <CModalTitle>Delete FAQ</CModalTitle>
        </CModalHeader>
        <CModalBody>
          Delete <strong>{deleteModal.row?.question}</strong>? This removes it permanently
          along with its embeddings. The customer will no longer get this answer.
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, row: null })}
            disabled={submitting}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={confirmDelete}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default FaqItemsTab