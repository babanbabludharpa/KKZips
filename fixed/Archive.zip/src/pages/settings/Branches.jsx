import { useEffect, useRef, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilMap, cilLocationPin } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet'
import L from 'leaflet'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

const INDIA_CENTER = [20.5937, 78.9629]

const MapMover = ({ center }) => {
  const map = useMap()
  useEffect(() => {
    if (center) map.flyTo(center, 15, { duration: 0.8 })
  }, [center, map])
  return null
}

const MapClickHandler = ({ onMapClick }) => {
  useMapEvents({
    click(e) { onMapClick(e.latlng.lat, e.latlng.lng) },
  })
  return null
}

const schema = yup.object({
  name:          yup.string().required('Name is required'),
  code: yup.string()
    .required('Branch code is required')
    .length(4, 'Code must be exactly 4 characters')
    .matches(/^[A-Z0-9]{4}$/, 'Code must be 4 uppercase letters/numbers, e.g. HO01')
    .transform(val => val ? val.toUpperCase() : val),
  type:          yup.string().required('Type is required'),
  parent_id:     yup.string().nullable().optional(),
  address:       yup.string().nullable().optional(),
  state_id:      yup.string().required('State is required'),
  city_id:       yup.string().required('City is required'),
  pincode:       yup.string().nullable().optional(),
  gst_no:        yup.string().nullable().optional(),
  fssai_no:      yup.string().nullable().optional(),
  phone:         yup.string().nullable().optional(),
  contact_email: yup.string().email('Invalid email').nullable().optional(),
  latitude:      yup.number().typeError('Must be a number').min(-90).max(90).nullable().optional(),
  longitude:     yup.number().typeError('Must be a number').min(-180).max(180).nullable().optional(),
  opens_at:      yup.string().nullable().optional(),
  closes_at:     yup.string().nullable().optional(),
})

const TYPE_LABELS = {
  head_office:  'Head Office',
  state_office: 'State Office',
  branch:       'Branch',
}

const TYPE_COLORS = {
  head_office:  'danger',
  state_office: 'warning',
  branch:       'info',
}

const SORT_KEY_MAP = {
  code:       'code',
  name:       'name',
  type:       'type',
  city:       'city',
  state:      'state',
  is_active:  'is_active',
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

const FORM_ID = 'branch-form'

const Branches = () => {
  const navigate = useNavigate()

  const [branches, setBranches] = useState([])
  const [allBranches, setAllBranches] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, branch: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, branch: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [statesList, setStatesList] = useState([])
  const [citiesList, setCitiesList] = useState([])
  const [loadingCities, setLoadingCities] = useState(false)
  const [markerPos, setMarkerPos] = useState(null)
  const [flyToPos, setFlyToPos] = useState(null)
  const [geocoding, setGeocoding] = useState(false)
  const [geocodeError, setGeocodeError] = useState(null)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const requestSeq = useRef(0)

  const isEdit = !!modal.branch

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, watch, setValue, getValues, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      type: '', parent_id: '', state_id: '', city_id: '',
      latitude: '', longitude: '', opens_at: '', closes_at: '',
    },
  })

  const selectedType  = watch('type')
  const selectedState = watch('state_id')
  const watchedLat    = watch('latitude')
  const watchedLng    = watch('longitude')

  const validParents = allBranches.filter(b => {
    if (selectedType === 'state_office') return b.type === 'head_office'
    if (selectedType === 'branch') return ['head_office', 'state_office'].includes(b.type)
    return false
  })

  const showParentField = ['state_office', 'branch'].includes(selectedType)

  useEffect(() => {
    const lat = parseFloat(watchedLat)
    const lng = parseFloat(watchedLng)
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      setMarkerPos([lat, lng])
    }
  }, [watchedLat, watchedLng])

  useEffect(() => {
    fetchStates()
    fetchBranches({ page: 1 })
    fetchAllBranches()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (selectedState) {
      fetchCities(selectedState)
    } else {
      setCitiesList([])
      setValue('city_id', '')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedState])

  useEffect(() => { setValue('parent_id', '') }, [selectedType, setValue])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchBranches({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const fetchStates = async () => {
    try {
      const res = await api.get('/masters/states', { params: { country_id: 1 } })
      setStatesList(res.data.data?.states ?? [])
    } catch {
      setError('Failed to load states.')
    }
  }

  const fetchCities = async (stateId) => {
    try {
      setLoadingCities(true)
      const res = await api.get('/masters/cities', {
  params: {
    state_id: stateId,
    per_page: 100,
  },
})
      setCitiesList(res.data.data?.cities ?? res.data.data ?? [])
    } catch {
      setError('Failed to load cities.')
    } finally {
      setLoadingCities(false)
    }
  }

  const buildParams = (useSearch, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchBranches = async ({
    page = 1,
    searchOverride = appliedSearch,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)

    try {
      const params = {
        page,
        ...buildParams(searchOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/settings/branches', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.data?.meta ?? res.data?.meta ?? {}

      setBranches(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch {
      if (mySeq !== requestSeq.current) return
      setError('Failed to load branches.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const fetchAllBranches = async () => {
    try {
      const res = await api.get('/settings/branches', {
  params: { per_page: 100 }
})
      setAllBranches(extractArray(res))
    } catch { /* silent */ }
  }

  const handlePageChange = (page) => {
    goToPage(page, fetchBranches)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchBranches)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchBranches({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleMapClick = useCallback((lat, lng) => {
    const rLat = parseFloat(lat.toFixed(7))
    const rLng = parseFloat(lng.toFixed(7))
    setMarkerPos([rLat, rLng])
    setValue('latitude',  rLat, { shouldValidate: true })
    setValue('longitude', rLng, { shouldValidate: true })
    setGeocodeError(null)
  }, [setValue])

  const handleMarkerDrag = useCallback((e) => {
    const { lat, lng } = e.target.getLatLng()
    const rLat = parseFloat(lat.toFixed(7))
    const rLng = parseFloat(lng.toFixed(7))
    setMarkerPos([rLat, rLng])
    setValue('latitude',  rLat, { shouldValidate: true })
    setValue('longitude', rLng, { shouldValidate: true })
  }, [setValue])

  const handleGeocode = async () => {
    const values = getValues()
    const cityName  = citiesList.find(c => String(c.id) === String(values.city_id))?.name ?? ''
    const stateName = statesList.find(s => String(s.id) === String(values.state_id))?.name ?? ''
    const parts     = [values.address, cityName, stateName, 'India'].filter(Boolean)
    if (parts.length < 2) { setGeocodeError('Fill in at least city and state before searching.'); return }
    setGeocoding(true); setGeocodeError(null)
    try {
      const query = encodeURIComponent(parts.join(', '))
      const res   = await fetch(`https://nominatim.openstreetmap.org/search?q=${query}&format=json&limit=1`, { headers: { 'Accept-Language': 'en' } })
      const data  = await res.json()
      if (!data.length) { setGeocodeError('Location not found. Try adding more address detail or click the map manually.'); return }
      const lat = parseFloat(parseFloat(data[0].lat).toFixed(7))
      const lng = parseFloat(parseFloat(data[0].lon).toFixed(7))
      setMarkerPos([lat, lng]); setFlyToPos([lat, lng])
      setValue('latitude', lat, { shouldValidate: true })
      setValue('longitude', lng, { shouldValidate: true })
    } catch { setGeocodeError('Geocoding failed. Click the map to set location manually.') }
    finally { setGeocoding(false) }
  }

  const openCreate = () => {
    reset({ name: '', code: '', type: '', parent_id: '', address: '', state_id: '', city_id: '', pincode: '', gst_no: '', fssai_no: '', phone: '', contact_email: '', latitude: '', longitude: '', opens_at: '', closes_at: '' })
    setMarkerPos(null); setFlyToPos(null); setGeocodeError(null); setModalError(null)
    setModal({ open: true, branch: null })
  }

  const openEdit = async (branch) => {
    reset({
      name: branch.name ?? '', code: branch.code ?? '', type: branch.type ?? '',
      parent_id: branch.parent_id ? String(branch.parent_id) : '',
      address: branch.address ?? '', state_id: String(branch.state_id ?? ''),
      pincode: branch.pincode ?? '', gst_no: branch.gst_no ?? '', fssai_no: branch.fssai_no ?? '',
      phone: branch.phone ?? '', contact_email: branch.contact_email ?? '',
      latitude: branch.latitude ?? '', longitude: branch.longitude ?? '',
      opens_at: branch.opens_at ?? '', closes_at: branch.closes_at ?? '',
    })
    if (branch.latitude && branch.longitude) {
      const pos = [parseFloat(branch.latitude), parseFloat(branch.longitude)]
      setMarkerPos(pos); setFlyToPos(pos)
    } else { setMarkerPos(null); setFlyToPos(null) }
    setGeocodeError(null)
    if (branch.state_id) { await fetchCities(branch.state_id); setValue('city_id', String(branch.city_id ?? '')) }
    setModalError(null)
    setModal({ open: true, branch })
  }

  const closeModal = () => {
    setModal({ open: false, branch: null })
    setCitiesList([]); setMarkerPos(null); setFlyToPos(null); setGeocodeError(null); setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = {
        ...data,
        parent_id: data.parent_id ? parseInt(data.parent_id) : null,
        latitude:  data.latitude  !== '' ? parseFloat(data.latitude)  : null,
        longitude: data.longitude !== '' ? parseFloat(data.longitude) : null,
        opens_at:  data.opens_at  || null,
        closes_at: data.closes_at || null,
      }
      if (isEdit) { await api.put(`/settings/branches/${modal.branch.id}`, payload) }
      else        { await api.post('/settings/branches', payload) }
      closeModal()
      fetchBranches()
      fetchAllBranches()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/settings/branches/${deleteModal.branch.id}`)
      setDeleteModal({ open: false, branch: null })
      fetchBranches()
      fetchAllBranches()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (branch) => {
    try {
      await api.put(`/settings/branches/${branch.id}`, { is_active: !branch.is_active })
      fetchBranches()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const toggleAcceptingOrders = async (branch) => {
    try {
      await api.patch(`/settings/branches/${branch.id}/toggle-orders`)
      fetchBranches()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to update order acceptance.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Branches</h4>
          <PermissionGate permission="branch.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Branch
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Name, code, or phone"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading branches...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="code">Code</SortableHeader>
                    <SortableHeader colKey="name">Name</SortableHeader>
                    <SortableHeader colKey="type">Type</SortableHeader>
                    <CTableHeaderCell>Parent</CTableHeaderCell>
                    <SortableHeader colKey="city">City</SortableHeader>
                    <SortableHeader colKey="state">State</SortableHeader>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Hours</CTableHeaderCell>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Orders</CTableHeaderCell>
                    <CTableHeaderCell>Zones</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {branches.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={13} className="text-center text-muted py-4">
                        No branches found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    branches.map((branch, i) => (
                      <CTableRow key={branch.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          {branch.code
                            ? <CBadge color="primary" shape="rounded-pill">{branch.code}</CBadge>
                            : '—'}
                        </CTableDataCell>
                        <CTableDataCell>{branch.name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={TYPE_COLORS[branch.type] ?? 'secondary'} shape="rounded-pill">
                            {TYPE_LABELS[branch.type] ?? branch.type}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{branch.parent_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{branch.city_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{branch.state_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{branch.phone ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          {branch.opens_at && branch.closes_at
                            ? <span className="small text-muted">{branch.opens_at} – {branch.closes_at}</span>
                            : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={branch.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(branch)}
                            title="Click to toggle"
                          >
                            {branch.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <PermissionGate permission="branch.edit">
                            <CBadge
                              color={branch.is_accepting_orders ? 'success' : 'danger'}
                              shape="rounded-pill"
                              style={{ cursor: 'pointer' }}
                              onClick={() => toggleAcceptingOrders(branch)}
                              title="Click to pause/resume orders"
                            >
                              {branch.is_accepting_orders ? 'Open' : 'Paused'}
                            </CBadge>
                          </PermissionGate>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => navigate(`/settings/branches/${branch.id}/zones`)}
                            title="Manage service zones"
                          >
                            <CIcon icon={cilMap} className="me-1" />
                            {branch.zone_count?.total ?? 0}
                            {branch.zone_count?.active != null && branch.zone_count.active !== branch.zone_count.total
                              ? ` (${branch.zone_count.active})`
                              : ''}
                          </CButton>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="branch.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(branch)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="branch.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, branch })}
                                disabled={branch.type === 'head_office'}
                                title={branch.type === 'head_office' ? 'Cannot delete head office' : 'Delete'}
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal
        size="lg"
        visible={modal.open}
        onClose={closeModal}
        backdrop="static"
        scrollable
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Branch' : 'Add Branch'}
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          <CForm id={FORM_ID} onSubmit={handleSubmit(onSubmit)}>
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Branch Name <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.name} {...register('name')} />
                {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Branch Code <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  invalid={!!errors.code}
                  {...register('code')}
                  placeholder="e.g. HO01"
                  maxLength={4}
                  style={{ textTransform: 'uppercase' }}
                />
                {errors.code && <div className="text-danger small mt-1">{errors.code.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Type <span className="text-danger">*</span>
                </CFormLabel>
                <CFormSelect className="filter-input" invalid={!!errors.type} {...register('type')}>
                  <option value="">Select Type</option>
                  <option value="head_office">Head Office</option>
                  <option value="state_office">State Office</option>
                  <option value="branch">Branch</option>
                </CFormSelect>
                {errors.type && <div className="text-danger small mt-1">{errors.type.message}</div>}
              </div>

              {showParentField && (
                <div className="col-md-6">
                  <CFormLabel className="filter-label">
                    Parent Branch <span className="text-danger">*</span>
                  </CFormLabel>
                  <CFormSelect className="filter-input" invalid={!!errors.parent_id} {...register('parent_id')}>
                    <option value="">Select Parent</option>
                    {validParents.map(b => (
                      <option key={b.id} value={b.id}>{b.name} ({TYPE_LABELS[b.type]})</option>
                    ))}
                  </CFormSelect>
                  {errors.parent_id && <div className="text-danger small mt-1">{errors.parent_id.message}</div>}
                  {validParents.length === 0 && (
                    <div className="text-warning small mt-1">
                      {selectedType === 'state_office'
                        ? 'No head office found. Create head office first.'
                        : 'No head office or state office found.'}
                    </div>
                  )}
                </div>
              )}

              <div className="col-md-6">
                <CFormLabel className="filter-label">Phone</CFormLabel>
                <CFormInput className="filter-input" {...register('phone')} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Contact Email</CFormLabel>
                <CFormInput className="filter-input" type="email" invalid={!!errors.contact_email} {...register('contact_email')} />
                {errors.contact_email && <div className="text-danger small mt-1">{errors.contact_email.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">GST No</CFormLabel>
                <CFormInput className="filter-input" {...register('gst_no')} placeholder="e.g. 27AAPFU0939F1ZV" />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">FSSAI No</CFormLabel>
                <CFormInput className="filter-input" {...register('fssai_no')} />
              </div>
              <div className="col-md-12">
                <CFormLabel className="filter-label">Address</CFormLabel>
                <CFormInput className="filter-input" {...register('address')} />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  State <span className="text-danger">*</span>
                </CFormLabel>
                <CFormSelect className="filter-input" invalid={!!errors.state_id} {...register('state_id')}>
                  <option value="">Select State</option>
                  {statesList.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </CFormSelect>
                {errors.state_id && <div className="text-danger small mt-1">{errors.state_id.message}</div>}
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  City <span className="text-danger">*</span>
                  {loadingCities && <CSpinner size="sm" className="ms-2" />}
                </CFormLabel>
                <CFormSelect className="filter-input" invalid={!!errors.city_id} {...register('city_id')} disabled={!selectedState || loadingCities}>
                  <option value="">Select City</option>
                  {citiesList.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </CFormSelect>
                {errors.city_id && <div className="text-danger small mt-1">{errors.city_id.message}</div>}
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Pincode</CFormLabel>
                <CFormInput className="filter-input" {...register('pincode')} />
              </div>

              <div className="col-md-6">
                <CFormLabel className="filter-label">Opens At</CFormLabel>
                <CFormInput className="filter-input" type="time" invalid={!!errors.opens_at} {...register('opens_at')} />
                {errors.opens_at && <div className="text-danger small mt-1">{errors.opens_at.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Closes At</CFormLabel>
                <CFormInput className="filter-input" type="time" invalid={!!errors.closes_at} {...register('closes_at')} />
                {errors.closes_at && <div className="text-danger small mt-1">{errors.closes_at.message}</div>}
              </div>

              <div className="col-12">
                <hr className="my-1" />
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <small className="text-muted">Pin the branch location on the map.</small>
                  <CButton
                    type="button"
                    className="filter-btn filter-btn--ghost"
                    size="sm"
                    onClick={handleGeocode}
                    disabled={geocoding}
                    title="Find location from filled address fields"
                  >
                    {geocoding
                      ? <><CSpinner size="sm" className="me-1" />Searching…</>
                      : <><CIcon icon={cilLocationPin} className="me-1" />Find from Address</>}
                  </CButton>
                </div>
                {geocodeError && <CAlert color="warning" className="py-2 mb-2 small">{geocodeError}</CAlert>}
              </div>

              {modal.open && (
                <div className="col-12">
                  <div style={{ height: 300, flexShrink: 0, borderRadius: 8, overflow: 'hidden', border: '1px solid var(--rep-border)' }}>
                    <MapContainer
                      center={markerPos ?? INDIA_CENTER}
                      zoom={markerPos ? 14 : 5}
                      style={{ height: '100%', width: '100%' }}
                      key={modal.open ? 'open' : 'closed'}
                      scrollWheelZoom={false}
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <MapClickHandler onMapClick={handleMapClick} />
                      <MapMover center={flyToPos} />
                      {markerPos && (
                        <Marker position={markerPos} draggable eventHandlers={{ dragend: handleMarkerDrag }} />
                      )}
                    </MapContainer>
                  </div>
                  <small className="text-muted d-block mt-1">
                    Click anywhere on the map to place the pin, or drag the pin to adjust.
                  </small>
                </div>
              )}

              <div className="col-md-6">
                <CFormLabel className="filter-label">Latitude</CFormLabel>
                <CFormInput className="filter-input" type="number" step="any" placeholder="Auto-filled by map" invalid={!!errors.latitude} {...register('latitude')} />
                {errors.latitude && <div className="text-danger small mt-1">{errors.latitude.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Longitude</CFormLabel>
                <CFormInput className="filter-input" type="number" step="any" placeholder="Auto-filled by map" invalid={!!errors.longitude} {...register('longitude')} />
                {errors.longitude && <div className="text-danger small mt-1">{errors.longitude.message}</div>}
              </div>
            </div>
          </CForm>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
            Cancel
          </CButton>
          <CButton
            type="submit"
            form={FORM_ID}
            className="filter-btn filter-btn--primary"
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            {isEdit ? 'Update' : 'Create'}
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, branch: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.branch?.name}</strong>?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, branch: null })}
          >
            Cancel
          </CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Branches