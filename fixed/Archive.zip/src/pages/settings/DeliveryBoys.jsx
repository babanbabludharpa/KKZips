import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell,
  CTableBody, CTableDataCell, CBadge, CSpinner, CAlert, CModal, CModalHeader,
  CModalTitle, CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect, CFormCheck,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilCalendar } from '@coreui/icons'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

const DELIVERY_BOYS_API = '/settings/delivery-boys'

const DOC_FIELDS = [
  { key: 'adhar_doc', label: 'Aadhaar Copy', short: 'Aadhaar', required: true },
  { key: 'pan_doc', label: 'PAN Copy', short: 'PAN', required: false },
  { key: 'driving_licence_doc', label: 'Driving Licence', short: 'Licence', required: true },
]

const MAX_DOC_BYTES = 5 * 1024 * 1024
const ALLOWED_DOC_EXT = ['jpg', 'jpeg', 'png', 'pdf']

const todayISO = () => {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const emptyForm = () => ({
  name: '', email: '', username: '', mobile_number: '', password: '',
  branch_id: '', vehicle_type: 'bike', max_daily_deliveries: 30,
  zone_ids: [], slots: [],
  adhar_no: '', pan_no: '', emergency_contact_no: '',
  bank_account_holder: '', bank_name: '', bank_account_no: '', bank_ifsc: '', upi_id: '',
})

const emptyDocs = () => ({ adhar_doc: null, pan_doc: null, driving_licence_doc: null })

const isKycComplete = (rider) =>
  !!rider.documents?.adhar_doc && !!rider.documents?.driving_licence_doc

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0]
const VEHICLE_LABELS = { bike: 'Bike', cycle: 'Cycle', ev: 'EV', van: 'Van' }

const dash = (v) => (v === null || v === undefined || v === '' ? '—' : v)
const formatDate = (v) => (v ? new Date(v).toLocaleDateString('en-IN') : '—')

// [{slot_id, name, day_of_week}, ...] -> [{slotId, name, days: ['Mon', ...]}, ...]
const groupSlots = (slots = []) => {
  const map = new Map()
  slots.forEach((s) => {
    if (!map.has(s.slot_id)) map.set(s.slot_id, { slotId: s.slot_id, name: s.name, days: [] })
    map.get(s.slot_id).days.push(s.day_of_week)
  })
  return [...map.values()].map((g) => ({
    ...g,
    days: DAY_ORDER.filter((d) => g.days.includes(d)).map((d) => DAY_LABELS[d]),
  }))
}

const buildParams = ({ search, branchId }) => {
  const params = {}
  if (search) params.search = search
  if (branchId) params.branch_id = branchId
  return params
}

const DeliveryBoys = () => {
  const [riders, setRiders]   = useState([])
  const [branches, setBranches] = useState([])
  const [zones, setZones]     = useState([])
  const [slots, setSlots]     = useState([])

  const [loading, setLoading]   = useState(true)
  const [error, setError]       = useState(null)
  const [modal, setModal]       = useState({ open: false, rider: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, rider: null })
  const [submitting, setSubmitting]   = useState(false)

  const [leavesModal, setLeavesModal] = useState({ open: false, rider: null })
  const [leaves, setLeaves]           = useState([])
  const [leavesLoading, setLeavesLoading] = useState(false)
  const [leavesError, setLeavesError] = useState(null)
  const [newLeave, setNewLeave]       = useState({ mode: 'full_day', slot_id: '', start_date: '', end_date: '', reason: '' })
  const [leaveSubmitting, setLeaveSubmitting] = useState(false)

  const [formData, setFormData] = useState(emptyForm())
  const [docFiles, setDocFiles] = useState(emptyDocs())

  const [search, setSearch] = useState('')
  const [branchFilter, setBranchFilter] = useState('')
  const [exporting, setExporting] = useState(false)

  const requestSeq = useRef(0)
  const skipFirstEffectRef = useRef(true)

  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  useEffect(() => {
    fetchRiders({ page: 1 })
    fetchMasters()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced refetch when search or branch changes. Skips the mount run.
  useEffect(() => {
    if (skipFirstEffectRef.current) {
      skipFirstEffectRef.current = false
      return
    }
    const t = setTimeout(() => {
      setPageLoading(true)
      fetchRiders({ page: 1, searchOverride: search, branchOverride: branchFilter })
    }, 300)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, branchFilter])

  const fetchRiders = async ({
    page = 1,
    searchOverride = search,
    branchOverride = branchFilter,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)

    try {
      const res = await api.get(DELIVERY_BOYS_API, {
        params: {
          page,
          per_page: perPageOverride,
          ...buildParams({ search: searchOverride, branchId: branchOverride }),
        },
      })

      if (mySeq !== requestSeq.current) return

      const data = res.data?.data
      const list = Array.isArray(data?.users) ? data.users : []
      const m = data?.meta ?? {}

      setRiders(list)
      updatePagination({
        current_page: m.current_page ?? 1,
        last_page:    m.last_page    ?? 1,
        per_page:     m.per_page     ?? perPageOverride,
        total:        m.total        ?? list.length,
        from:         m.from         ?? null,
        to:           m.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRiders([])
      setError(err.response?.data?.message ?? 'Failed to load delivery boys.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  // Re-fetch the page the user is on after create / edit / delete / leave changes.
  const refresh = () => fetchRiders({ page: meta.current_page })

  const handlePageChange = (page) => goToPage(page, fetchRiders)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchRiders)

  const handleClear = () => {
    setSearch('')
    setBranchFilter('')
    // the debounced effect fires the fetch
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const res = await api.get(DELIVERY_BOYS_API, {
        params: { ...buildParams({ search, branchId: branchFilter }), export: 'csv' },
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data], { type: 'text/csv;charset=utf-8' }))
      const a = document.createElement('a')
      a.href = url
      a.download = `delivery_boys_${todayISO()}.csv`
      a.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (err) {
      setError('Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const fetchMasters = async () => {
    try {
      const [bRes, sRes] = await Promise.all([
        api.get('/settings/branches', { params: { per_page: 100 } }),
        api.get('/settings/slots'),
      ])
      setBranches(bRes.data?.data?.data || [])
      // Only active slots appear in the slot picker, per the is_active rule.
      setSlots((sRes.data?.data || []).filter(s => s.is_active))
    } catch (err) {
      console.error('Failed to load master data', err)
    }
  }

  const fetchZones = async (branchId) => {
    if (!branchId) { setZones([]); return }
    try {
      const res = await api.get(`/settings/branches/${branchId}/zones`)
      setZones(res.data?.data?.zones || [])
    } catch (err) {
      console.error('Failed to load zones', err)
    }
  }

  const handleBranchChange = (e) => {
    const branchId = e.target.value
    setFormData(prev => ({ ...prev, branch_id: branchId, zone_ids: [] }))
    fetchZones(branchId)
  }

  const handleZoneToggle = (zoneId) => {
    setFormData(prev => {
      const exists = prev.zone_ids.includes(zoneId)
      return {
        ...prev,
        zone_ids: exists
          ? prev.zone_ids.filter(id => id !== zoneId)
          : [...prev.zone_ids, zoneId],
      }
    })
  }

  const handleSlotToggle = (slotId, day) => {
    setFormData(prev => {
      const exists = prev.slots.some(s => s.slot_id === slotId && s.day_of_week === day)
      return {
        ...prev,
        slots: exists
          ? prev.slots.filter(s => !(s.slot_id === slotId && s.day_of_week === day))
          : [...prev.slots, { slot_id: slotId, day_of_week: day }],
      }
    })
  }

  const setField = (key) => (e) => setFormData(prev => ({ ...prev, [key]: e.target.value }))

  const handleDocChange = (key, e) => {
    const file = e.target.files?.[0] || null
    if (file) {
      const ext = file.name.split('.').pop().toLowerCase()
      if (!ALLOWED_DOC_EXT.includes(ext)) {
        setError('Documents must be jpg, png or pdf.')
        e.target.value = ''
        return
      }
      if (file.size > MAX_DOC_BYTES) {
        setError('Each document must be 5 MB or smaller.')
        e.target.value = ''
        return
      }
    }
    setError(null)
    setDocFiles(prev => ({ ...prev, [key]: file }))
  }

  // Documents live on a private disk, so they are fetched through the
  // authenticated API as a blob rather than opened by URL.
  

  const openCreate = () => {
    setFormData(emptyForm())
    setDocFiles(emptyDocs())
    setZones([])
    setError(null)
    setModal({ open: true, rider: null })
  }

  const openEdit = (rider) => {
    setFormData({
      ...emptyForm(),
      name: rider.name,
      email: rider.email || '',
      username: rider.username,
      mobile_number: rider.mobile_number,
      branch_id: rider.branch_id || '',
      vehicle_type: rider.vehicle_type || 'bike',
      max_daily_deliveries: rider.max_daily_deliveries || 30,
      zone_ids: rider.zones?.map(z => z.id) || [],
      slots: rider.slots?.map(s => ({ slot_id: s.slot_id, day_of_week: s.day_of_week })) || [],
      emergency_contact_no: rider.emergency_contact_no || '',
      bank_account_holder: rider.bank_account_holder || '',
      bank_name: rider.bank_name || '',
      bank_ifsc: rider.bank_ifsc || '',
      upi_id: rider.upi_id || '',
      // adhar_no, pan_no, bank_account_no stay blank: the API never returns them in full.
    })
    setDocFiles(emptyDocs())
    fetchZones(rider.branch_id)
    setError(null)
    setModal({ open: true, rider })
  }

  const closeModal = () => {
    setModal({ open: false, rider: null })
    setError(null)
  }

  const buildFormData = () => {
    const f = formData
    const fd = new FormData()

    const plainKeys = [
      'name', 'email', 'username', 'mobile_number', 'branch_id', 'vehicle_type',
      'max_daily_deliveries', 'emergency_contact_no', 'bank_account_holder',
      'bank_name', 'upi_id',
    ]
    plainKeys.forEach(k => fd.append(k, f[k] ?? ''))
    fd.append('bank_ifsc', f.bank_ifsc.trim().toUpperCase())

    // Sensitive values are omitted when blank so the stored value is kept on edit.
    const adhar = f.adhar_no.replace(/\s+/g, '')
    const pan = f.pan_no.trim().toUpperCase()
    const account = f.bank_account_no.replace(/\s+/g, '')
    if (adhar) fd.append('adhar_no', adhar)
    if (pan) fd.append('pan_no', pan)
    if (account) fd.append('bank_account_no', account)
    if (f.password) fd.append('password', f.password)

    f.zone_ids.forEach(id => fd.append('zone_ids[]', id))
    f.slots.forEach((s, i) => {
      fd.append(`slots[${i}][slot_id]`, s.slot_id)
      fd.append(`slots[${i}][day_of_week]`, s.day_of_week)
    })

    DOC_FIELDS.forEach(({ key }) => {
      if (docFiles[key]) fd.append(key, docFiles[key])
    })

    return fd
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    setError(null)
    try {
      const fd = buildFormData()
      const config = { headers: { 'Content-Type': 'multipart/form-data' } }

      if (modal.rider) {
        // PHP does not parse multipart bodies on PUT, so spoof it.
        fd.append('_method', 'PUT')
        await api.post(`${DELIVERY_BOYS_API}/${modal.rider.id}`, fd, config)
      } else {
        await api.post(DELIVERY_BOYS_API, fd, config)
      }
      closeModal()
      refresh()
    } catch (err) {
      const msg = err.response?.data?.message || 'Operation failed.'
      const errors = err.response?.data?.errors
      setError(errors ? Object.values(errors).flat().join(' ') : msg)
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`${DELIVERY_BOYS_API}/${deleteModal.rider.id}`)
      setDeleteModal({ open: false, rider: null })
      const lastOnPage = riders.length === 1 && meta.current_page > 1
      fetchRiders({ page: lastOnPage ? meta.current_page - 1 : meta.current_page })
    } catch (err) {
      setError(err.response?.data?.message || 'Delete failed.')
    }
  }

  const openLeaves = async (rider) => {
    setLeavesModal({ open: true, rider })
    setLeaves([])
    setLeavesError(null)
    setNewLeave({ mode: 'full_day', slot_id: '', start_date: '', end_date: '', reason: '' })
    setLeavesLoading(true)
    try {
      const res = await api.get(`${DELIVERY_BOYS_API}/${rider.id}/leaves`)
      setLeaves(res.data?.data || [])
    } catch (err) {
      setLeavesError(err.response?.data?.message || 'Failed to load leaves.')
    } finally {
      setLeavesLoading(false)
    }
  }

  const closeLeaves = () => {
    setLeavesModal({ open: false, rider: null })
    setLeaves([])
    setNewLeave({ mode: 'full_day', slot_id: '', start_date: '', end_date: '', reason: '' })
    setLeavesError(null)
  }

  const handleCreateLeave = async (e) => {
    e.preventDefault()
    setLeaveSubmitting(true)
    setLeavesError(null)
    try {
      const payload = {
        start_date: newLeave.start_date,
        end_date: newLeave.mode === 'slot' ? newLeave.start_date : newLeave.end_date,
        reason: newLeave.reason || null,
      }
      if (newLeave.mode === 'slot') {
        payload.slot_id = Number(newLeave.slot_id)
      }
      await api.post(`${DELIVERY_BOYS_API}/${leavesModal.rider.id}/leaves`, payload)
      setNewLeave({ mode: 'full_day', slot_id: '', start_date: '', end_date: '', reason: '' })
      const res = await api.get(`${DELIVERY_BOYS_API}/${leavesModal.rider.id}/leaves`)
      setLeaves(res.data?.data || [])
      refresh()
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to create leave.'
      const errors = err.response?.data?.errors
      setLeavesError(errors ? Object.values(errors).flat().join(' ') : msg)
    } finally {
      setLeaveSubmitting(false)
    }
  }

  const handleDeleteLeave = async (leaveId) => {
    if (!window.confirm('Delete this leave? Future non-finalized occurrences in the leave range will be reassigned back to this rider if they are eligible. The leave will be preserved in the audit trail.')) {
      return
    }
    setLeavesError(null)
    try {
      await api.delete(`${DELIVERY_BOYS_API}/${leavesModal.rider.id}/leaves/${leaveId}`)
      const res = await api.get(`${DELIVERY_BOYS_API}/${leavesModal.rider.id}/leaves`)
      setLeaves(res.data?.data || [])
      refresh()
    } catch (err) {
      setLeavesError(err.response?.data?.message || 'Failed to delete leave.')
    }
  }

  const renderDocField = ({ key, label, required }) => {
    const existing = !!modal.rider?.documents?.[key]
    const file = docFiles[key]
    return (
      <div className="col-md-4" key={key}>
        <CFormLabel className="filter-label">
          {label} {required && <span className="text-danger">*</span>}
        </CFormLabel>
        <CFormInput
          className="filter-input"
          type="file"
          size="sm"
          accept=".jpg,.jpeg,.png,.pdf"
          required={required && !existing}
          onChange={e => handleDocChange(key, e)}
        />
        <small className="text-muted d-block mt-1" style={{ fontSize: '0.7rem', lineHeight: 1.2 }}>
          {file ? (
            <>Selected: <strong>{file.name}</strong></>
          ) : existing ? (
            <>
              On file —{' '}
              <a
                href={modal.rider.documents[key]} // <-- Use the direct URL from backend
                target="_blank"
                rel="noreferrer"
                className="text-decoration-none"
              >
                View
              </a>
            </>
          ) : (
            'jpg / png / pdf, max 5 MB'
          )}
        </small>
      </div>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Delivery Boys</h4>
          <div className="d-flex gap-2">
            <PermissionGate permission="delivery_boy.view">
              <CButton
                size="sm"
                className="report-shell__export"
                onClick={handleExport}
                disabled={exporting || !riders.length || loading}
              >
                {exporting ? <CSpinner size="sm" className="me-2" /> : null}
                Export CSV
              </CButton>
            </PermissionGate>
            <PermissionGate permission="delivery_boy.create">
              <CButton size="sm" className="report-shell__export" onClick={openCreate}>
                <CIcon icon={cilPlus} className="me-2" />Add Delivery Boy
              </CButton>
            </PermissionGate>
          </div>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Name, username, email or mobile"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Branch</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
            >
              <option value="">All Branches</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && !modal.open && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading delivery boys...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>Username</CTableHeaderCell>
                    <CTableHeaderCell>Mobile</CTableHeaderCell>
                    <CTableHeaderCell>Emergency Contact</CTableHeaderCell>
                    <CTableHeaderCell>Email</CTableHeaderCell>
                    <CTableHeaderCell>Branch</CTableHeaderCell>
                    <CTableHeaderCell>Vehicle</CTableHeaderCell>
                    <CTableHeaderCell>Capacity</CTableHeaderCell>
                    <CTableHeaderCell>Zones</CTableHeaderCell>
                    <CTableHeaderCell>Slots</CTableHeaderCell>
                    <CTableHeaderCell>Aadhaar No</CTableHeaderCell>
                    <CTableHeaderCell>PAN No</CTableHeaderCell>
                    <CTableHeaderCell>Documents</CTableHeaderCell>
                    <CTableHeaderCell>Account Holder</CTableHeaderCell>
                    <CTableHeaderCell>Bank</CTableHeaderCell>
                    <CTableHeaderCell>Account No</CTableHeaderCell>
                    <CTableHeaderCell>IFSC</CTableHeaderCell>
                    <CTableHeaderCell>UPI ID</CTableHeaderCell>
                    <CTableHeaderCell>Online</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Created At</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {riders.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={23} className="text-center text-muted py-4">
                        No delivery boys found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    riders.map((rider, i) => (
                      <CTableRow key={rider.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{rider.name}</CTableDataCell>
                        <CTableDataCell>{dash(rider.username)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.mobile_number)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.emergency_contact_no)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.email)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.branch_name)}</CTableDataCell>
                        <CTableDataCell>{VEHICLE_LABELS[rider.vehicle_type] ?? dash(rider.vehicle_type)}</CTableDataCell>
                        <CTableDataCell>{rider.max_daily_deliveries ?? '—'} / day</CTableDataCell>
                        <CTableDataCell style={{ minWidth: 140 }}>
                          {rider.zones?.length ? (
                            rider.zones.map(z => (
                              <CBadge key={z.id} color="info" className="me-1">{z.name}</CBadge>
                            ))
                          ) : (
                            <span className="text-muted">—</span>
                          )}
                        </CTableDataCell>
                        <CTableDataCell style={{ minWidth: 180 }}>
                          {rider.slots?.length ? (
                            groupSlots(rider.slots).map(g => (
                              <div key={g.slotId} className="small">
                                <strong>{g.name}</strong>: {g.days.join(', ')}
                              </div>
                            ))
                          ) : (
                            <span className="text-muted">—</span>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>{dash(rider.adhar_no_masked)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.pan_no_masked)}</CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex flex-wrap gap-1 align-items-center" style={{ minWidth: 150 }}>
                            <PermissionGate permission="delivery_boy.view">
                              {DOC_FIELDS.filter(d => rider.documents?.[d.key]).map(d => (
                                <a
                                  key={d.key}
                                  href={rider.documents[d.key]} // <-- Use the direct URL from backend
                                  target="_blank"
                                  rel="noreferrer"
                                  className="badge text-bg-light border text-decoration-none"
                                  title={`View ${d.label}`}
                                >
                                  {d.short}
                                </a>
                              ))}
                            </PermissionGate>
                            {!isKycComplete(rider) && <CBadge color="warning">KYC incomplete</CBadge>}
                          </div>
                        </CTableDataCell>
                        <CTableDataCell>{dash(rider.bank_account_holder)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.bank_name)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.bank_account_no_masked)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.bank_ifsc)}</CTableDataCell>
                        <CTableDataCell>{dash(rider.upi_id)}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={rider.is_online ? 'success' : 'secondary'} shape="rounded-pill">
                            {rider.is_online ? 'Online' : 'Offline'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={rider.is_active ? 'success' : 'secondary'} shape="rounded-pill">
                            {rider.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{formatDate(rider.created_at)}</CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1">
                            <PermissionGate permission="delivery_boy.view">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openLeaves(rider)}
                                title="Manage leaves"
                                aria-label="Manage leaves"
                              >
                                <CIcon icon={cilCalendar} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="delivery_boy.edit">
                              <CButton size="sm" className="table-action-btn" onClick={() => openEdit(rider)} title="Edit" aria-label="Edit">
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="delivery_boy.delete">
                              <CButton size="sm" className="table-action-btn" onClick={() => setDeleteModal({ open: true, rider })} title="Delete" aria-label="Delete">
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* CREATE / EDIT MODAL */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" size="lg">
        <CModalHeader>
          <CModalTitle>{modal.rider ? 'Edit Delivery Boy' : 'Add Delivery Boy'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={onSubmit}>
          <CModalBody style={{ maxHeight: '75vh', overflowY: 'auto' }}>
            {error && <CAlert color="danger">{error}</CAlert>}

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Name <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" value={formData.name} onChange={setField('name')} required />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Mobile <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" value={formData.mobile_number} onChange={setField('mobile_number')} required />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Email <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" type="email" value={formData.email} onChange={setField('email')} required />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Username <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" value={formData.username} onChange={setField('username')} required />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  {modal.rider ? 'New Password (optional)' : 'Password'} {!modal.rider && <span className="text-danger">*</span>}
                </CFormLabel>
                <CFormInput className="filter-input" type="password" value={formData.password} onChange={setField('password')} required={!modal.rider} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Emergency Contact No.</CFormLabel>
                <CFormInput
                  className="filter-input"
                  inputMode="numeric"
                  maxLength={10}
                  placeholder="10-digit mobile"
                  value={formData.emergency_contact_no}
                  onChange={setField('emergency_contact_no')}
                />
              </div>
            </div>

            <hr />
            <h6 className="mb-3">Operational Details</h6>

            <div className="row g-3 mb-3">
              <div className="col-md-4">
                <CFormLabel className="filter-label">Branch / Hub <span className="text-danger">*</span></CFormLabel>
                <CFormSelect className="filter-input" value={formData.branch_id} onChange={handleBranchChange} required>
                  <option value="">Select Branch</option>
                  {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </CFormSelect>
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Vehicle Type <span className="text-danger">*</span></CFormLabel>
                <CFormSelect className="filter-input" value={formData.vehicle_type} onChange={setField('vehicle_type')}>
                  <option value="bike">Bike</option>
                  <option value="cycle">Cycle</option>
                  <option value="ev">EV</option>
                  <option value="van">Van</option>
                </CFormSelect>
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Max Daily Deliveries <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" type="number" min={1} max={200} value={formData.max_daily_deliveries} onChange={setField('max_daily_deliveries')} required />
              </div>
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">Assigned Zones <span className="text-danger">*</span></CFormLabel>
              <div className="border rounded p-2" style={{ maxHeight: '150px', overflowY: 'auto' }}>
                {zones.length === 0 ? (
                  <span className="text-muted small">Select a branch first to load zones.</span>
                ) : zones.map(z => (
                  <CFormCheck
                    key={z.id}
                    id={`zone-${z.id}`}
                    label={z.name}
                    checked={formData.zone_ids.includes(z.id)}
                    onChange={() => handleZoneToggle(z.id)}
                  />
                ))}
              </div>
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">Slot Availability <span className="text-danger">*</span></CFormLabel>
              <div className="border rounded p-2" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                {slots.length === 0 ? (
                  <span className="text-muted small">No active slots configured.</span>
                ) : slots.map(slot => (
                  <div key={slot.id} className="mb-2 pb-2 border-bottom">
                    <div className="fw-bold small">{slot.name} ({slot.start_time} - {slot.end_time})</div>
                    <div className="d-flex gap-3 flex-wrap mt-1">
                      {[1, 2, 3, 4, 5, 6, 0].map(day => (
                        <CFormCheck
                          key={day}
                          id={`slot-${slot.id}-day-${day}`}
                          label={['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][day]}
                          checked={formData.slots.some(s => s.slot_id === slot.id && s.day_of_week === day)}
                          onChange={() => handleSlotToggle(slot.id, day)}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <hr />
            <h6 className="mb-1">Identity &amp; Documents</h6>
            {modal.rider && (
              <p className="text-muted small mb-3">
                Saved ID numbers are not shown in full. Leave a number blank to keep the stored value.
              </p>
            )}

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Aadhaar No. <span className="text-danger">*</span></CFormLabel>
                <CFormInput
                  className="filter-input"
                  inputMode="numeric"
                  maxLength={14}
                  autoComplete="off"
                  placeholder={modal.rider?.adhar_no_masked ? `${modal.rider.adhar_no_masked} (blank = keep)` : '12-digit number'}
                  value={formData.adhar_no}
                  onChange={setField('adhar_no')}
                  required={!modal.rider?.adhar_no_masked}
                />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">PAN No.</CFormLabel>
                <CFormInput
                  className="filter-input"
                  maxLength={10}
                  autoComplete="off"
                  placeholder={modal.rider?.pan_no_masked ? `${modal.rider.pan_no_masked} (blank = keep)` : 'e.g. ABCDE1234F'}
                  value={formData.pan_no}
                  onChange={e => setFormData(prev => ({ ...prev, pan_no: e.target.value.toUpperCase() }))}
                />
              </div>
            </div>

            <div className="row g-3 mb-3">
              {DOC_FIELDS.map(renderDocField)}
            </div>

            <hr />
            <h6 className="mb-3">Bank Details</h6>

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Account Holder Name</CFormLabel>
                <CFormInput className="filter-input" value={formData.bank_account_holder} onChange={setField('bank_account_holder')} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Bank Name</CFormLabel>
                <CFormInput className="filter-input" value={formData.bank_name} onChange={setField('bank_name')} />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Account No.</CFormLabel>
                <CFormInput
                  className="filter-input"
                  inputMode="numeric"
                  maxLength={18}
                  autoComplete="off"
                  placeholder={modal.rider?.bank_account_no_masked ? `${modal.rider.bank_account_no_masked} (blank = keep)` : ''}
                  value={formData.bank_account_no}
                  onChange={setField('bank_account_no')}
                />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">IFSC</CFormLabel>
                <CFormInput
                  className="filter-input"
                  maxLength={11}
                  placeholder="e.g. HDFC0001234"
                  value={formData.bank_ifsc}
                  onChange={e => setFormData(prev => ({ ...prev, bank_ifsc: e.target.value.toUpperCase() }))}
                />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">UPI ID</CFormLabel>
                <CFormInput
                  className="filter-input"
                  placeholder="name@bank"
                  value={formData.upi_id}
                  onChange={setField('upi_id')}
                />
              </div>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton type="button" className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null} Save
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* DELETE MODAL */}
      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, rider: null })}>
        <CModalHeader><CModalTitle>Confirm Delete</CModalTitle></CModalHeader>
        <CModalBody>
          Are you sure you want to delete <strong>{deleteModal.rider?.name}</strong>? Their uploaded documents are deleted too. This cannot be undone.
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setDeleteModal({ open: false, rider: null })}>Cancel</CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>

      {/* LEAVES MODAL */}
      <CModal visible={leavesModal.open} onClose={closeLeaves} backdrop="static" size="lg">
        <CModalHeader>
          <CModalTitle>Leaves — {leavesModal.rider?.name}</CModalTitle>
        </CModalHeader>
        <CModalBody style={{ maxHeight: '75vh', overflowY: 'auto' }}>
          {leavesError && (
            <CAlert color="danger" dismissible onClose={() => setLeavesError(null)}>
              {leavesError}
            </CAlert>
          )}

          <h6 className="mb-3">Active &amp; Upcoming Leaves</h6>

          {leavesLoading ? (
            <div className="text-center py-3">
              <CSpinner size="sm" />
            </div>
          ) : leaves.length === 0 ? (
            <p className="text-muted small mb-3">No leaves recorded for this rider.</p>
          ) : (
            <CTable hover responsive bordered size="sm" className="mb-3">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>From</CTableHeaderCell>
                  <CTableHeaderCell>To</CTableHeaderCell>
                  <CTableHeaderCell>Slot</CTableHeaderCell>
                  <CTableHeaderCell>Reason</CTableHeaderCell>
                  <CTableHeaderCell>Actions</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {leaves.map(leave => (
                  <CTableRow key={leave.id}>
                    <CTableDataCell>{leave.start_date}</CTableDataCell>
                    <CTableDataCell>{leave.end_date}</CTableDataCell>
                    <CTableDataCell>
                      {leave.slot_name ? (
                        <CBadge color="info">
                          {leave.slot_name}
                          {leave.slot_start_time && leave.slot_end_time
                            ? ` (${leave.slot_start_time}–${leave.slot_end_time})`
                            : ''}
                        </CBadge>
                      ) : (
                        <CBadge color="secondary">Full day</CBadge>
                      )}
                    </CTableDataCell>
                    <CTableDataCell>{leave.reason || '—'}</CTableDataCell>
                    <CTableDataCell>
                      <PermissionGate permission="delivery_boy.edit">
                        <CButton size="sm" color="danger" variant="outline" onClick={() => handleDeleteLeave(leave.id)}>
                          <CIcon icon={cilTrash} />
                        </CButton>
                      </PermissionGate>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          )}

          <hr />
          <h6 className="mb-3">Add Leave</h6>

          <PermissionGate
            permission="delivery_boy.edit"
            fallback={
              <p className="text-warning small mb-0">
                You do not have permission to create leaves for this rider.
              </p>
            }
          >
            <CForm onSubmit={handleCreateLeave}>
              <div className="mb-3">
                <CFormLabel className="filter-label">Leave Type</CFormLabel>
                <div className="d-flex gap-3">
                  <CFormCheck
                    type="radio"
                    name="leave_mode"
                    id="leave_mode_full"
                    label="Full day (all slots)"
                    checked={newLeave.mode === 'full_day'}
                    onChange={() => setNewLeave({ ...newLeave, mode: 'full_day', slot_id: '', end_date: newLeave.start_date })}
                  />
                  <CFormCheck
                    type="radio"
                    name="leave_mode"
                    id="leave_mode_slot"
                    label="Specific slot (single day)"
                    checked={newLeave.mode === 'slot'}
                    onChange={() => setNewLeave({ ...newLeave, mode: 'slot', end_date: newLeave.start_date })}
                  />
                </div>
              </div>

              <div className="row g-3 mb-3">
                <div className="col-md-4">
                  <CFormLabel className="filter-label">
                    {newLeave.mode === 'slot' ? 'Date' : 'Start Date'}
                    <span className="text-danger"> *</span>
                  </CFormLabel>
                  <CFormInput
                    className="filter-input"
                    type="date"
                    min={todayISO()}
                    value={newLeave.start_date}
                    onChange={e => setNewLeave({
                      ...newLeave,
                      start_date: e.target.value,
                      end_date: newLeave.mode === 'slot' ? e.target.value : newLeave.end_date,
                    })}
                    required
                  />
                </div>

                {newLeave.mode === 'full_day' && (
                  <div className="col-md-4">
                    <CFormLabel className="filter-label">End Date <span className="text-danger">*</span></CFormLabel>
                    <CFormInput
                      className="filter-input"
                      type="date"
                      min={newLeave.start_date || todayISO()}
                      value={newLeave.end_date}
                      onChange={e => setNewLeave({ ...newLeave, end_date: e.target.value })}
                      required
                    />
                  </div>
                )}

                {newLeave.mode === 'slot' && (
                  <div className="col-md-4">
                    <CFormLabel className="filter-label">Slot <span className="text-danger">*</span></CFormLabel>
                    <CFormSelect
                      className="filter-input"
                      value={newLeave.slot_id}
                      onChange={e => setNewLeave({ ...newLeave, slot_id: e.target.value })}
                      required
                    >
                      <option value="">Select slot</option>
                      {slots.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.start_time} - {s.end_time})</option>
                      ))}
                    </CFormSelect>
                  </div>
                )}

                <div className="col-md-4">
                  <CFormLabel className="filter-label">Reason</CFormLabel>
                  <CFormInput
                    className="filter-input"
                    value={newLeave.reason}
                    onChange={e => setNewLeave({ ...newLeave, reason: e.target.value })}
                    placeholder="Optional"
                    maxLength={255}
                  />
                </div>
              </div>

              <div className="text-end">
                <CButton type="submit" className="filter-btn filter-btn--primary" disabled={leaveSubmitting}>
                  {leaveSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
                  Create Leave
                </CButton>
              </div>
            </CForm>
          </PermissionGate>
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={closeLeaves}>Close</CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default DeliveryBoys