/**
 * TenantThemeSettings.jsx
 *
 * Tenant self-service page — tenant admin picks their own schema.
 * Route:  /settings/appearance  (or wherever you mount it)
 *
 * Restrictions vs platform admin:
 *   - Only preset themes visible (no custom tokens)
 *   - Cannot change other tenants' themes
 *   - Calls a different endpoint: /tenant/settings/theme
 */

import { useState, useEffect } from 'react'
import { CCard, CCardBody, CCardHeader, CButton, CSpinner } from '@coreui/react'
import ThemePicker from '../../components/ThemePicker'
import useAuthStore from '../../store/authStore'
import useUiStore from '../../store/uiStore'
import api from '../../api/api'

export default function TenantThemeSettings() {
  const user         = useAuthStore((s) => s.user)
  const updateUser   = useAuthStore((s) => s.updateUser)
  const setTemplate  = useUiStore((s) => s.setTemplate)

  const [selected, setSelected] = useState(user?.themeKey ?? 'crimson')
  const [saving,   setSaving]   = useState(false)
  const [saved,    setSaved]    = useState(false)
  const [error,    setError]    = useState(null)

  // Sync if user object updates (e.g. after page refresh / login)
  useEffect(() => {
    if (user?.themeKey) setSelected(user.themeKey)
  }, [user?.themeKey])

  const handleChange = (key) => {
    setSelected(key)
    setSaved(false)
    setError(null)
  }

  const handleSave = async () => {
    setSaving(true)
    setError(null)
    try {
      await api.patch('/tenant/settings/theme', {
        theme_key: selected,
      })

      // Update persisted auth user so rehydrateTheme works on next refresh
      updateUser({ ...user, themeKey: selected })

      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (err) {
      setError(err?.response?.data?.message ?? 'Failed to save. Please try again.')
      // Revert to previously saved theme on error
      const previous = user?.themeKey ?? 'crimson'
      setSelected(previous)
      setTemplate(previous)
    } finally {
      setSaving(false)
    }
  }

  const hasChanges = selected !== (user?.themeKey ?? 'crimson')

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Appearance</h4>
          <div className="d-flex align-items-center gap-2">
            {error && (
              <span className="text-danger small" style={{ maxWidth: 220 }}>
                {error}
              </span>
            )}
            {saved && !hasChanges && (
              <span className="report-pagination__page-badge">✓ Schema saved</span>
            )}
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              disabled={saving || !hasChanges}
              onClick={handleSave}
            >
              {saving ? <CSpinner size="sm" className="me-2" /> : null}
              Save Changes
            </CButton>
          </div>
        </div>

        {/* ==================== INFO BANNER ==================== */}
        <div className="report-shell__filters" style={{ paddingTop: '0.85rem', paddingBottom: '0.85rem' }}>
          <div className="report-info-strip" style={{ width: '100%', margin: 0, border: 'none', background: 'transparent', padding: 0 }}>
            <span style={{ fontSize: 18 }}>🎨</span>
            <span>
              The selected schema applies to <strong style={{ color: 'var(--text-strong)' }}>all users</strong>{' '}
              in your store — not just your account. Hover any card below to preview before saving.
            </span>
          </div>
        </div>

        {/* ==================== PICKER ==================== */}
        <CCardBody>
          <ThemePicker
            value={selected}
            onChange={handleChange}
            previewLive={true}
          />
        </CCardBody>
      </CCard>
    </div>
  )
}