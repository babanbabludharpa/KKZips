import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  CButton,
  CCard,
  CCardBody,
  CForm,
  CFormInput,
  CFormLabel,
  CInputGroup,
  CInputGroupText,
  CSpinner,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilLockLocked, cilUser, cilUserFollow } from '@coreui/icons'
import {
  Eye, EyeOff, ShieldCheck,
  ShoppingCart, CalendarClock, Package, Users, TrendingUp,
  Sun, Moon,
} from 'lucide-react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import useUiStore from '../../store/uiStore'
import './Login.css'
import kutumbkartLogo from '../../assets/images/kutumbkart_logo.png'

const loginSchema = yup.object({
  username: yup.string().trim().required('Username is required'),
  password: yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  remember: yup.boolean().default(true),
})

const forgotSchema = yup.object({
  username: yup.string().trim().required('Username is required'),
  mobile_number: yup
    .string()
    .trim()
    .matches(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number')
    .required('Mobile number is required'),
})

const FEATURES = [
  { icon: ShoppingCart,  label: 'Orders' },
  { icon: CalendarClock, label: 'Subscriptions' },
  { icon: Package,       label: 'Inventory' },
  { icon: Users,         label: 'Multi-Branch' },
  { icon: TrendingUp,    label: 'Reports' },
]

const FALLBACK_MESSAGES = {
  loginSuccess: 'Login successful!',
  loginFailed: 'Login failed. Please try again.',
  network: 'Network error. Please check your connection and try again.',
}

const TOAST_DURATION_MS = 4000

const Login = () => {
  const navigate = useNavigate()
  const setAuth = useAuthStore((s) => s.setAuth)
  const { theme, setTemplate, toggleTheme } = useUiStore()
  const [mode, setMode] = useState('login')
  const [showPassword, setShowPassword] = useState(false)

  const [toasts, setToasts] = useState([])
  const toastTimers = useRef({})

  const dismissToast = useCallback((id) => {
    clearTimeout(toastTimers.current[id])
    delete toastTimers.current[id]
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  const showToast = useCallback((type, message) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    setToasts((prev) => [...prev, { id, type, message }])
    toastTimers.current[id] = setTimeout(() => dismissToast(id), TOAST_DURATION_MS)
  }, [dismissToast])

  useEffect(() => {
    const timers = toastTimers.current
    return () => Object.values(timers).forEach(clearTimeout)
  }, [])

  // ── Branding: initial state from pre-paint cache, then refresh from API ──
 const hasToken = (() => {
    try {
      const raw = localStorage.getItem('auth-storage') || sessionStorage.getItem('auth-storage')
      if (!raw) return false
      const parsed = JSON.parse(raw)
      const state = parsed && parsed.state ? parsed.state : parsed
      return !!(state && state.token)
    } catch (e) { return false }
  })()

  const boot = hasToken && typeof window !== 'undefined' && window.__BOOT_BRANDING__
    ? window.__BOOT_BRANDING__
    : null

  const [companyLogo, setCompanyLogo] = useState(
    boot ? (boot.tenant_slug ? (boot.logo_url || null) : kutumbkartLogo) : null
  )
  const [companyName, setCompanyName] = useState(boot ? (boot.brand_name || null) : null)
  const [brandingReady, setBrandingReady] = useState(!!boot)

  useEffect(() => {
    api.get('/branding')
      .then((res) => {
        const data = res.data?.data || {}
        const logo = data.tenant_slug ? (data.logo_url || null) : kutumbkartLogo
        const name = data.brand_name || null

        setCompanyLogo(logo)
        setCompanyName(name)
        if (data.theme_key) setTemplate(data.theme_key)
        document.title = name ? `${name} — Login` : 'Kutumbkart — Login'

        try {
          localStorage.setItem('branding-cache', JSON.stringify({
            brand_name:  name,
            logo_url:    logo === kutumbkartLogo ? null : (data.logo_url || null),
            tenant_slug: data.tenant_slug || null,
            theme_key:   data.theme_key || null,
          }))
        } catch (e) {}
      })
      .catch(() => {
        if (!boot) {
          setCompanyLogo(kutumbkartLogo)
          document.title = 'Kutumbkart — Login'
        }
      })
      .finally(() => {
        setBrandingReady(true)
      })
  }, [setTemplate])

  const {
    register: formRegister,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: yupResolver(loginSchema),
    shouldUnregister: true,
    mode: 'onBlur',
    reValidateMode: 'onChange',
    defaultValues: { remember: true },
  })

  const {
    register: forgotRegister,
    handleSubmit: handleForgotSubmit,
    formState: { errors: forgotErrors, isSubmitting: isForgotSubmitting },
    reset: resetForgotForm,
  } = useForm({
    resolver: yupResolver(forgotSchema),
    mode: 'onBlur',
    reValidateMode: 'onChange',
  })

  const onLogin = async (data) => {
    try {
      const res = await api.post('/auth/login', data)
      const payload = res.data ?? {}
      if (payload.status === false) {
        showToast('error', payload.message || FALLBACK_MESSAGES.loginFailed)
        return
      }
      const inner = payload.data ?? {}
      const { token, user, connection } = Array.isArray(inner) ? {} : inner
      if (!token) {
        showToast('error', payload.message || FALLBACK_MESSAGES.loginFailed)
        return
      }
      setAuth(token, user, connection, { remember: data.remember })
      showToast('success', payload.message || FALLBACK_MESSAGES.loginSuccess)
      navigate('/dashboard', { replace: true })
    } catch (err) {
      const apiMessage = err.response?.data?.message
      const message = apiMessage || (err.response ? FALLBACK_MESSAGES.loginFailed : FALLBACK_MESSAGES.network)
      showToast('error', message)
    }
  }

  const onForgotPassword = async (data) => {
    try {
      const res = await api.post('/auth/forgot-password', data)
      const payload = res.data ?? {}
      showToast('success', payload.message || 'If the details match an account, a new password has been sent by SMS.')
      resetForgotForm()
      setMode('login')
    } catch (err) {
      const apiMessage = err.response?.data?.message
      showToast('error', apiMessage || FALLBACK_MESSAGES.network)
    }
  }

  const displayName = companyName || 'KutumbKart'

  return (
    <div className={`auth-page-shell ${brandingReady ? 'is-ready' : 'is-loading'}`}>
      <div className="toast-stack" aria-live="polite" aria-atomic="true">
        {toasts.map((t) => (
          <div key={t.id} className={`toast-item toast-item--${t.type}`} role="status">
            <span className="toast-item__icon" aria-hidden="true">
              {t.type === 'success' ? '✓' : '!'}
            </span>
            <span className="toast-item__message">{t.message}</span>
            <button
              type="button"
              className="toast-item__close"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss notification"
            >
              ×
            </button>
          </div>
        ))}
      </div>

      <div className="auth-shell-card">
        {/* ═══════════ LEFT — BRAND PANEL ═══════════ */}
        <div className="auth-brand-panel">
          <div className="auth-brand-panel__header">
            <div className="auth-brand-panel__logo-wrap">
              {companyLogo ? (
                <img
                  src={companyLogo}
                  alt={companyName ?? 'Company logo'}
                  className="auth-brand-panel__logo-img"
                  onError={(e) => { e.target.style.display = 'none' }}
                />
              ) : (
                <div className="auth-brand-panel__logo-placeholder" />
              )}
            </div>
            <div className="auth-brand-panel__brand-block">
              <p className="auth-brand-name">{displayName}</p>
              <p className="auth-brand-tagline">Order | Subscribe | Grow</p>
            </div>
          </div>

          <div className="auth-brand-panel__marketing">
            <span className="auth-brand-panel__eyebrow">
              Welcome to {displayName} Admin Panel
            </span>
            <h1 className="auth-brand-panel__headline">
              Smarter Business.<br />
              <span className="auth-brand-panel__headline-accent">Happier Communities.</span>
            </h1>
            <p className="auth-brand-panel__subline">
              Manage orders, subscriptions, inventory and customers — all in one place.
              Build, grow and scale your business with ease.
            </p>
          </div>

          <div className="auth-brand-panel__features">
            {FEATURES.map(({ icon: Icon, label }) => (
              <div key={label} className="auth-brand-panel__feature">
                <div className="auth-brand-panel__feature-icon">
                  <Icon strokeWidth={2} />
                </div>
                <p className="auth-brand-panel__feature-label">{label}</p>
              </div>
            ))}
          </div>

          <div className="auth-brand-panel__footer">
            <span className="auth-brand-panel__footer-status">Live</span>
            <span>Multi-Tenant SaaS Platform</span>
          </div>
        </div>

        {/* ═══════════ RIGHT — FORM PANEL ═══════════ */}
        <CCard className="auth-form-panel">
          <button
            type="button"
            className="auth-theme-toggle"
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <CCardBody>
            <div className="auth-mobile-logo">
              {companyLogo ? (
                <img
                  src={companyLogo}
                  alt={companyName ?? 'Company logo'}
                  className="auth-mobile-logo__img"
                  onError={(e) => { e.target.style.display = 'none' }}
                />
              ) : null}
              <strong>{displayName}</strong>
            </div>

            <div className="auth-mode-tabs">
              {[
                { key: 'login', label: 'Login', icon: cilUser },
                { key: 'forgot', label: 'Forgot', icon: cilUserFollow },
              ].map((item) => (
                <button
                  key={item.key}
                  type="button"
                  className={`auth-mode-tab ${mode === item.key ? 'active' : ''}`}
                  onClick={() => setMode(item.key)}
                >
                  <CIcon icon={item.icon} />
                  {item.label}
                </button>
              ))}
            </div>

            <div className="auth-copy">
              <h2>{mode === 'login' ? 'Welcome back' : 'Reset access'}</h2>
              <p>
                {mode === 'login'
                  ? 'Sign in to your admin account to continue.'
                  : 'Enter your username and registered mobile number. We will text you a new password.'}
              </p>
            </div>

            {mode === 'login' ? (
              <CForm onSubmit={handleSubmit(onLogin)} noValidate className="auth-form auth-form--login">
                <div className="auth-form__field">
                  <CFormLabel>Username</CFormLabel>
                  <CInputGroup className={errors.username ? 'is-invalid' : ''}>
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput
                      type="text"
                      placeholder="Enter your username"
                      {...formRegister('username')}
                    />
                  </CInputGroup>
                  {errors.username && (
                    <div className="auth-form__error">{errors.username.message}</div>
                  )}
                </div>

                <div className="auth-form__field">
                  <CFormLabel>Password</CFormLabel>
                  <CInputGroup className={`auth-password-group ${errors.password ? 'is-invalid' : ''}`}>
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      {...formRegister('password')}
                    />
                    <button
                      type="button"
                      className="auth-password-toggle"
                      onClick={() => setShowPassword((v) => !v)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </CInputGroup>
                  {errors.password && (
                    <div className="auth-form__error">{errors.password.message}</div>
                  )}
                </div>

                <div className="auth-inline auth-inline--single">
                  <label className="auth-checkbox">
                    <input type="checkbox" {...formRegister('remember')} />
                    <span className="auth-checkbox__box" aria-hidden="true">
                      <svg viewBox="0 0 16 16" fill="none">
                        <path d="M3.5 8.5L6.5 11.5L12.5 5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </span>
                    <span className="auth-checkbox__label">Remember me</span>
                  </label>
                </div>

                <CButton type="submit" className="w-100 auth-submit" disabled={isSubmitting}>
                  {isSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
                  {isSubmitting ? 'Signing in...' : 'Sign in'}
                </CButton>
              </CForm>
            ) : (
              <CForm onSubmit={handleForgotSubmit(onForgotPassword)} noValidate className="auth-form auth-form--forgot">
                <div className="auth-form__field">
                  <CFormLabel>Username</CFormLabel>
                  <CInputGroup className={forgotErrors.username ? 'is-invalid' : ''}>
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput
                      type="text"
                      placeholder="Enter your username"
                      {...forgotRegister('username')}
                    />
                  </CInputGroup>
                  {forgotErrors.username && (
                    <div className="auth-form__error">{forgotErrors.username.message}</div>
                  )}
                </div>

                <div className="auth-form__field">
                  <CFormLabel>Mobile number</CFormLabel>
                  <CInputGroup className={forgotErrors.mobile_number ? 'is-invalid' : ''}>
                    <CInputGroupText><CIcon icon={cilUserFollow} /></CInputGroupText>
                    <CFormInput
                      type="tel"
                      maxLength={10}
                      placeholder="10-digit mobile number"
                      {...forgotRegister('mobile_number')}
                    />
                  </CInputGroup>
                  {forgotErrors.mobile_number ? (
                    <div className="auth-form__error">{forgotErrors.mobile_number.message}</div>
                  ) : (
                    <div className="auth-form__hint">
                      We'll text a new password to this number if it matches your account.
                    </div>
                  )}
                </div>

                <CButton type="submit" className="w-100 auth-submit" disabled={isForgotSubmitting}>
                  {isForgotSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
                  Send new password by SMS
                </CButton>
              </CForm>
            )}

            <div className="auth-form-panel__footer">
              <ShieldCheck strokeWidth={2} />
              <span>Secure Access</span>
              <span className="auth-form-panel__footer-dot">·</span>
              <span>Your Data is Safe With Us</span>
            </div>
          </CCardBody>
        </CCard>
      </div>
    </div>
  )
}

export default Login