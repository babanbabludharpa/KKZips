import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

const STATUS_COLORS = {
  preparing:        'info',
  picked_up:        'primary',
  out_for_delivery: 'primary',
}

const STATUS_LABELS = {
  preparing:        'Preparing',
  picked_up:        'Picked Up',
  out_for_delivery: 'Out for Delivery',
}

const SORT_KEY_MAP = {
  order_number: 'order_number',
  status:       'status',
  delivery_boy: 'delivery_boy',
  customer:     'customer',
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

const DeliveryQueue = () => {
  const navigate = useNavigate()

  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('asc')

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const buildParams = (usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchQueue = async ({
    page = 1,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/orders/delivery-queue', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.data?.meta ?? res.data?.meta ?? {}

      setOrders(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setOrders([])
      setError(err.response?.data?.message ?? 'Failed to load delivery queue.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchQueue({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchQueue)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchQueue)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchQueue({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">Delivery Assignment</h4>
          </div>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading queue...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="order_number">Order #</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="delivery_boy">Delivery Boy</SortableHeader>
                    <SortableHeader colKey="customer">Customer</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {orders.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                        Nothing awaiting delivery right now.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    orders.map((order, i) => (
                      <CTableRow key={order.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          {order.order_number ?? `#${order.id}`}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLORS[order.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {STATUS_LABELS[order.status] ?? order.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {order.delivery_boy?.name ?? (
                            <span className="text-muted">Unassigned</span>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>{order.customer?.name ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => navigate(`/orders/${order.id}`)}
                          >
                            {order.delivery_boy_id ? 'Manage' : 'Assign'}
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default DeliveryQueue