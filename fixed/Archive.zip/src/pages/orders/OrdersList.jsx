import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormSelect, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatIsoDateTime } from '../../utils/formatters'

const STATUS_COLORS = {
  pending_payment:   'warning',
  confirmed:         'info',
  preparing:         'info',
  out_for_delivery:  'primary',
  picked_up:         'primary',
  delivered:         'success',
  packaging:         'info',
  payment_failed:    'danger',
  cancelled:         'secondary',
  expired:           'secondary',
}

const STATUS_LABELS = {
  pending_payment:   'Awaiting Payment',
  confirmed:         'Confirmed',
  preparing:         'Preparing',
  packaging:         'Packaging',
  out_for_delivery:  'Out for Delivery',
  picked_up:         'Picked Up',
  delivered:         'Delivered',
  payment_failed:    'Payment Failed',
  cancelled:         'Cancelled',
  expired:           'Expired',
}

const STATUS_FILTER_OPTIONS = Object.keys(STATUS_LABELS)

const SORT_KEY_MAP = {
  order_number: 'order_number',
  customer:     'customer',
  status:       'status',
  total:        'total',
  created_at:   'created_at',
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

const OrdersList = () => {
  const navigate = useNavigate()

  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [statusFilter, setStatusFilter] = useState('confirmed')
  const [appliedStatus, setAppliedStatus] = useState('confirmed')
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const buildParams = (useStatus, useSearch, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useStatus) params.status = useStatus
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchOrders = async ({
    page = 1,
    statusOverride = appliedStatus,
    searchOverride = appliedSearch,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(statusOverride, searchOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/orders', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.data?.meta ?? res.data?.meta ?? {}

      setOrders(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setOrders([])
      setError(err.response?.data?.message ?? 'Failed to load orders.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchOrders({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Refetch when status changes
  useEffect(() => {
    setAppliedStatus(statusFilter)
    setPageLoading(true)
    fetchOrders({ page: 1, statusOverride: statusFilter })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchOrders({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => {
    goToPage(page, fetchOrders)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchOrders)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchOrders({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">All Orders</h4>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Order #, customer, phone"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              {STATUS_FILTER_OPTIONS.map((status) => (
                <option key={status} value={status}>
                  {STATUS_LABELS[status]}
                </option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading orders...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="order_number">Order #</SortableHeader>
                    <SortableHeader colKey="customer">Customer</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <CTableHeaderCell>Payment</CTableHeaderCell>
                    <SortableHeader colKey="total">Total</SortableHeader>
                    <SortableHeader colKey="created_at">Placed</SortableHeader>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {orders.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No orders found for this filter.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    orders.map((order, i) => (
                      <CTableRow
                        key={order.id}
                        style={{ cursor: 'pointer' }}
                        onClick={() => navigate(`/orders/${order.id}`)}
                      >
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          {order.order_number ?? `#${order.id}`}
                        </CTableDataCell>
                        <CTableDataCell>{order.customer?.name ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLORS[order.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {STATUS_LABELS[order.status] ?? order.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {order.payment_mode === 'cod' ? 'COD' : 'Online'}
                        </CTableDataCell>
                        <CTableDataCell>₹{order.total}</CTableDataCell>
                        <CTableDataCell>{formatIsoDateTime(order.created_at)}</CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default OrdersList