import { useState } from 'react'
import { CCard, CCardBody, CNav, CNavItem, CNavLink, CTabContent, CTabPane } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilChatBubble, cilPeople, cilWarning } from '@coreui/icons'
import SupportConversationsTab from './support/SupportConversationsTab'
import SupportCustomerActivityTab from './support/SupportCustomerActivityTab'
import SupportUnmatchedTab from './support/SupportUnmatchedTab'

const TABS = [
  { key: 'conversations', label: 'Conversations', icon: cilChatBubble },
  { key: 'customers',     label: 'Customer Activity', icon: cilPeople },
  { key: 'unmatched',     label: 'Unmatched Messages', icon: cilWarning },
]

const SupportReport = () => {
  const [activeTab, setActiveTab] = useState('conversations')

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Support Reports</h4>
        </div>

        <CNav variant="tabs" role="tablist" className="tenant-tabs">
          {TABS.map((t) => (
            <CNavItem key={t.key}>
              <CNavLink
                active={activeTab === t.key}
                onClick={() => setActiveTab(t.key)}
                style={{ cursor: 'pointer' }}
                className="tenant-tab-link d-flex align-items-center gap-2"
              >
                <CIcon icon={t.icon} width={15} height={15} />
                <span>{t.label}</span>
              </CNavLink>
            </CNavItem>
          ))}
        </CNav>

        <CCardBody className="tenant-content p-0">
          <CTabContent>
            <CTabPane visible={activeTab === 'conversations'}>
              <SupportConversationsTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'customers'}>
              <SupportCustomerActivityTab />
            </CTabPane>
            <CTabPane visible={activeTab === 'unmatched'}>
              <SupportUnmatchedTab />
            </CTabPane>
          </CTabContent>
        </CCardBody>
      </CCard>
    </div>
  )
}

export default SupportReport