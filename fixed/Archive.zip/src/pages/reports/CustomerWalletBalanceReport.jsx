import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'

const today = new Date().toISOString().slice(0, 10)

// ★ HO roles — all three see the Branch dropdown. Everyone else is
//   branch-bound and the backend forces their own branch.
const ADMIN_ROLES = ['staff_headoffice', 'admin', 'superadmin']
const PAGE_SIZE = 25

const CustomerWalletBalanceReport = () => {
  const [rows, setRows]       = useState([])
  const [branches, setBranches] = useState([])
  const [branchError, setBranchError] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)
  const [meta, setMeta]       = useState({ current_page: 1, last_page: 1, total: 0 })
  const [page, setPage]       = useState(1)
  const [serverPaginated, setServerPaginated] = useState(true)
  const [exporting, setExporting] = useState(false)

  const role = useAuthStore(s => s.role)
  const isAdmin = ADMIN_ROLES.includes(role)

  const [filters, setFilters] = useState({
    search: '', branch_id: '', balance_min: '', balance_max: '', sort: 'balance_desc',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  useEffect(() => {
    if (isAdmin) fetchBranches()
    fetchData(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const fetchBranches = async () => {
    setBranchError(null)
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      setBranches(Array.isArray(d) ? d : (d?.data ?? []))
    } catch {
      setBranches([])
      setBranchError("Couldn't load branch list.")
    }
  }

  const fetchData = async (p = 1, useFilters = appliedFilters) => {
    setLoading(true); setError(null)
    try {
      const params = { page: p, per_page: PAGE_SIZE, sort: useFilters.sort }
      if (useFilters.search)      params.search = useFilters.search
      if (useFilters.balance_min) params.balance_min = useFilters.balance_min
      if (useFilters.balance_max) params.balance_max = useFilters.balance_max
      if (isAdmin && useFilters.branch_id) params.branch_id = useFilters.branch_id

      const res = await api.get('/reports/wallet-balances', { params })
      const d = res.data?.data
      const list = Array.isArray(d) ? d : (d?.data ?? [])
      const hasServerMeta = !Array.isArray(d) && !!d?.meta

      setRows(list)
      setServerPaginated(hasServerMeta)
      setMeta(hasServerMeta
        ? d.meta
        : { current_page: 1, last_page: Math.max(1, Math.ceil(list.length / PAGE_SIZE)), total: list.length, per_page: PAGE_SIZE })
      setPage(hasServerMeta ? p : 1)
    } catch (err) {
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load wallet balances.')
    } finally {
      setLoading(false)
    }
  }

  const goToPage = (p) => {
    if (serverPaginated) fetchData(p, appliedFilters)
    else setPage(p)
  }

  const handleSearch = () => {
    setAppliedFilters(filters)
    fetchData(1, filters)
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = { export: 'csv', sort: appliedFilters.sort }
      if (appliedFilters.search)      params.search = appliedFilters.search
      if (appliedFilters.balance_min) params.balance_min = appliedFilters.balance_min
      if (appliedFilters.balance_max) params.balance_max = appliedFilters.balance_max
      if (isAdmin && appliedFilters.branch_id) params.branch_id = appliedFilters.branch_id

      const res = await api.get('/reports/wallet-balances', { params, responseType: 'blob' })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a'); a.href = url
      a.download = `customer_wallet_balances_${today}.csv`
      a.click(); URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const displayRows = serverPaginated ? rows : rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)
  const currentPage = serverPaginated ? meta.current_page : page

  return (
    <>
      <div className="admin-title-row p-1">
        <div>
          <h4>Customer Wallet Balance Report</h4>
          <span className="admin-page-note">{isAdmin ? 'All branches' : 'Your branch'}</span>
        </div>
        <CButton size="sm" color="primary" variant="outline" onClick={handleExport} disabled={exporting || !rows.length}>
          {exporting ? <CSpinner size="sm" className="me-2" /> : null}Export CSV
        </CButton>
      </div>

      {error && <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>}

      <div className="d-flex flex-wrap gap-3 align-items-end admin-filter-bar">
        <div>
          <CFormLabel className="small mb-1">Search</CFormLabel>
          <CFormInput size="sm" style={{ width: 200 }} placeholder="Name or phone"
            value={filters.search}
            onChange={e => setFilters(f => ({ ...f, search: e.target.value }))} />
        </div>
        <div>
          <CFormLabel className="small mb-1">Min Balance</CFormLabel>
          <CFormInput size="sm" type="number" style={{ width: 120 }} value={filters.balance_min}
            onChange={e => setFilters(f => ({ ...f, balance_min: e.target.value }))} />
        </div>
        <div>
          <CFormLabel className="small mb-1">Max Balance</CFormLabel>
          <CFormInput size="sm" type="number" style={{ width: 120 }} value={filters.balance_max}
            onChange={e => setFilters(f => ({ ...f, balance_max: e.target.value }))} />
        </div>
        <div>
          <CFormLabel className="small mb-1">Sort</CFormLabel>
          <CFormSelect size="sm" style={{ width: 160 }} value={filters.sort}
            onChange={e => setFilters(f => ({ ...f, sort: e.target.value }))}>
            <option value="balance_desc">Balance: High to Low</option>
            <option value="balance_asc">Balance: Low to High</option>
            <option value="name_asc">Name: A to Z</option>
          </CFormSelect>
        </div>

        {isAdmin && (
          <div>
            <CFormLabel className="small mb-1">Branch</CFormLabel>
            <CFormSelect size="sm" style={{ width: 180 }} value={filters.branch_id}
              onChange={e => setFilters(f => ({ ...f, branch_id: e.target.value }))}>
              <option value="">All Branches</option>
              {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
            </CFormSelect>
            {branchError && <div className="small text-danger mt-1">{branchError}</div>}
          </div>
        )}

        <CButton size="sm" color="primary" onClick={handleSearch}>Search</CButton>
        {meta.total > 0 && <small className="admin-record-count">{meta.total} records</small>}
      </div>

      <CCard className="glass-card admin-page-card">
        <CCardBody className="p-0">
          {loading ? (
            <div className="text-center py-5"><CSpinner color="primary" /></div>
          ) : (
            <>
              <CTable hover responsive className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No</CTableHeaderCell>
                    <CTableHeaderCell>Customer</CTableHeaderCell>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    {isAdmin && <CTableHeaderCell>Branch</CTableHeaderCell>}
                    <CTableHeaderCell>Balance</CTableHeaderCell>
                    <CTableHeaderCell>Last Updated</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && displayRows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={isAdmin ? 7 : 6} className="text-center text-muted py-4">
                        No wallets found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : displayRows.map((r, i) => (
                    <CTableRow key={r.customer_id}>
                      <CTableDataCell>{(currentPage - 1) * PAGE_SIZE + i + 1}</CTableDataCell>
                      <CTableDataCell>{r.customer_name}</CTableDataCell>
                      <CTableDataCell>{r.phone ?? '—'}</CTableDataCell>
                      <CTableDataCell>
                        <CBadge color={r.customer_status === 'active' ? 'success' : r.customer_status === 'suspended' ? 'danger' : 'secondary'}>
                          {r.customer_status}
                        </CBadge>
                      </CTableDataCell>
                      {isAdmin && <CTableDataCell>{r.branch_name ?? '—'}</CTableDataCell>}
                      <CTableDataCell className={r.balance < 0 ? 'text-danger fw-semibold' : 'fw-semibold'}>
                        ₹{Number(r.balance).toFixed(2)}
                      </CTableDataCell>
                      <CTableDataCell>{r.balance_updated_at ?? '—'}</CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
              {meta.last_page > 1 && (
                <div className="d-flex justify-content-end align-items-center gap-2 p-3">
                  <CButton size="sm" color="secondary" variant="outline"
                    disabled={currentPage === 1}
                    onClick={() => goToPage(currentPage - 1)}>Prev</CButton>
                  <span className="small text-muted">Page {currentPage} of {meta.last_page}</span>
                  <CButton size="sm" color="secondary" variant="outline"
                    disabled={currentPage === meta.last_page}
                    onClick={() => goToPage(currentPage + 1)}>Next</CButton>
                </div>
              )}
            </>
          )}
        </CCardBody>
      </CCard>
    </>
  )
}

export default CustomerWalletBalanceReport