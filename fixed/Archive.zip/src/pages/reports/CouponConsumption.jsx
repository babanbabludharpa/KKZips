import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import useAuthStore from '../../store/authStore'
import { formatDateTime } from '../../utils/formatters'

const today    = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const ADMIN_ROLES = ['admin', 'superadmin']

// Header column key -> backend sort key (must match COUPON_CONSUMPTION_SORTABLE)
const SORT_KEY_MAP = {
  order_number:     'order_number',
  used_at:          'used_at',
  delivered_at:     'delivered_at',
  coupon_code:      'coupon_code',
  discount_applied: 'discount_applied',
  customer_name:    'customer_name',
  branch_name:      'branch_name',
  order_total:      'order_total',
}

const CouponConsumption = () => {
  const [rows, setRows]               = useState([])
  const [branches, setBranches]       = useState([])
  const [coupons, setCoupons]         = useState([])
  const [loading, setLoading]         = useState(false)
  const [error, setError]             = useState(null)
  const [exporting, setExporting]     = useState(false)

  const [sortKey, setSortKey]         = useState(null)
  const [sortDir, setSortDir]         = useState('desc')

  const role    = useAuthStore((s) => s.role)
  const isAdmin = ADMIN_ROLES.includes(role)

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date:   today,
    coupon_id: '',
    branch_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchBranches = async () => {
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      setBranches(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  // Includes coupons whose row is gone entirely (hard-deleted) — the
  // endpoint sources its list from coupon_usages, so any coupon that was
  // ever redeemed shows up here, even if the coupon row no longer exists.
  const fetchCoupons = async () => {
    try {
      const res = await api.get('/reports/coupon-consumption/coupons')
      setCoupons(res.data?.data ?? [])
    } catch { /* silent */ }
  }

  useEffect(() => {
    if (isAdmin) fetchBranches()
    fetchCoupons()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page:  usePerPage,
      from_date: useFilters.from_date,
      to_date:   useFilters.to_date,
    }
    if (isAdmin && useFilters.branch_id) params.branch_id = useFilters.branch_id
    if (useFilters.coupon_id)            params.coupon_id = useFilters.coupon_id
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, data: { data: [...rows], meta: {...} } }
  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/coupon-consumption', { params })

      if (mySeq !== requestSeq.current) return

      const responseData   = res.data?.data
      const dataArray      = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load report.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (!filters.from_date || !filters.to_date) {
      setError('Date range is required.')
      return
    }
    if (filters.from_date > filters.to_date) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleReset = () => {
    const empty = {
      from_date: monthAgo,
      to_date:   today,
      coupon_id: '',
      branch_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/coupon-consumption', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `coupon_consumption_${appliedFilters.from_date}_${appliedFilters.to_date}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  // Sr.No + Order# + Used At + Delivered + Coupon + Type + Value +
  // Discount + Customer + [Branch] + Order Total
  const colCount = isAdmin ? 11 : 10

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Coupon Consumption</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, from_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, to_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Coupon</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.coupon_id}
              onChange={(e) =>
                setFilters((f) => ({ ...f, coupon_id: e.target.value }))
              }
            >
              <option value="">All Coupons</option>
              {coupons.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code}{c.deleted ? ' (deleted)' : ''}
                </option>
              ))}
            </CFormSelect>
          </div>

          {isAdmin && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, branch_id: e.target.value }))
                }
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleReset}
              disabled={loading}
            >
              Reset
            </CButton>
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading coupon consumption...
              </div>
            </div>
          ) : (
            <>
              <div className="report-table-scroll">
                <CTable
                  hover
                  bordered
                  className="admin-data-table admin-data-table--wide"
                >
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                      <SortableHeader colKey="order_number">Order #</SortableHeader>
                      <SortableHeader colKey="used_at">Used At</SortableHeader>
                      <SortableHeader colKey="delivered_at">Delivered</SortableHeader>
                      <SortableHeader colKey="coupon_code">Coupon</SortableHeader>
                      <CTableHeaderCell>Type</CTableHeaderCell>
                      <CTableHeaderCell>Value</CTableHeaderCell>
                      <SortableHeader colKey="discount_applied">Discount Given</SortableHeader>
                      <SortableHeader colKey="customer_name">Customer</SortableHeader>
                      {isAdmin && (
                        <SortableHeader colKey="branch_name">Branch</SortableHeader>
                      )}
                      <SortableHeader colKey="order_total">Order Total</SortableHeader>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {!error && rows.length === 0 ? (
                      <CTableRow>
                        <CTableDataCell
                          colSpan={colCount}
                          className="text-center text-muted py-4"
                        >
                          No coupon redemptions found for this range.
                        </CTableDataCell>
                      </CTableRow>
                    ) : (
                      rows.map((r, i) => (
                        <CTableRow key={r.id}>
                          <CTableDataCell>
                            {(meta.current_page - 1) * perPage + i + 1}
                          </CTableDataCell>
                          <CTableDataCell>#{r.order_number}</CTableDataCell>
                          <CTableDataCell>{formatDateTime(r.used_at)}</CTableDataCell>
                          <CTableDataCell>
                            {r.delivered_at
                              ? formatDateTime(r.delivered_at)
                              : <span className="text-muted">Not delivered</span>}
                          </CTableDataCell>
                          <CTableDataCell>
                            <CBadge
                              color={r.coupon_state === 0 ? 'primary' : 'secondary'}
                              shape="rounded-pill"
                              className="font-monospace"
                            >
                              {r.coupon_code ?? `#${r.coupon_id}`}
                            </CBadge>
                            {r.coupon_state === 1 && (
                              <CBadge color="dark" shape="rounded-pill" className="ms-1">
                                deleted
                              </CBadge>
                            )}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.coupon_type ? (
                              <CBadge
                                color={r.coupon_type === 'flat' ? 'secondary' : 'warning'}
                                shape="rounded-pill"
                              >
                                {r.coupon_type === 'flat' ? 'Flat ₹' : 'Percent %'}
                              </CBadge>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.coupon_type ? (
                              r.coupon_type === 'flat'
                                ? `₹${r.coupon_value}`
                                : `${r.coupon_value}%`
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </CTableDataCell>
                          <CTableDataCell>
                            <strong>₹{r.discount_applied}</strong>
                          </CTableDataCell>
                          <CTableDataCell>{r.customer_name ?? '—'}</CTableDataCell>
                          {isAdmin && (
                            <CTableDataCell>{r.branch_name}</CTableDataCell>
                          )}
                          <CTableDataCell>₹{r.order_total}</CTableDataCell>
                        </CTableRow>
                      ))
                    )}
                  </CTableBody>
                </CTable>
              </div>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default CouponConsumption