import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import useAuthStore from '../../store/authStore'

const today = new Date().toISOString().slice(0, 10)

// ★ HO roles — all three see the Branch dropdown. Everyone else is
//   branch-bound and the backend forces their own branch.
const ADMIN_ROLES = ['staff_headoffice', 'admin', 'superadmin']

const STATUS_BADGE_COLOR = {
  active: 'success',
  suspended: 'danger',
  inactive: 'secondary',
}

const getStatusBadge = (status) =>
  STATUS_BADGE_COLOR[String(status ?? '').toLowerCase()] || 'secondary'

const CustomerAddressReport = () => {
  const [rows, setRows] = useState([])
  const [branches, setBranches] = useState([])
  const [branchError, setBranchError] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const role = useAuthStore((s) => s.role)
  const isAdmin = ADMIN_ROLES.includes(role)

  const [filters, setFilters] = useState({
    search: '',
    city: '',
    state: '',
    is_serviceable: '',
    branch_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchBranches = async () => {
    setBranchError(null)
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      setBranches(Array.isArray(d) ? d : (d?.data ?? []))
    } catch {
      setBranches([])
      setBranchError("Couldn't load branch list.")
    }
  }

  const buildParams = (useFilters, usePerPage) => {
    const params = { per_page: usePerPage }
    if (useFilters.search) params.search = useFilters.search
    if (useFilters.city) params.city = useFilters.city
    if (useFilters.state) params.state = useFilters.state
    if (useFilters.is_serviceable !== '') params.is_serviceable = useFilters.is_serviceable
    if (isAdmin && useFilters.branch_id) params.branch_id = useFilters.branch_id
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride),
      }
      const res = await api.get('/reports/customer-addresses', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load customer addresses.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    if (isAdmin) fetchBranches()
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSearch = () => {
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleClear = () => {
    const empty = {
      search: '',
      city: '',
      state: '',
      is_serviceable: '',
      branch_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: empty })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        export: 'csv',
        ...buildParams(appliedFilters, perPage),
      }
      delete params.per_page

      const res = await api.get('/reports/customer-addresses', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `customer_addresses_${today}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Customer Address Report</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Name, phone, city, pincode"
              value={filters.search}
              onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">City</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              value={filters.city}
              onChange={(e) => setFilters((f) => ({ ...f, city: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">State</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              value={filters.state}
              onChange={(e) => setFilters((f) => ({ ...f, state: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Serviceable</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.is_serviceable}
              onChange={(e) =>
                setFilters((f) => ({ ...f, is_serviceable: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="1">Yes</option>
              <option value="0">No</option>
            </CFormSelect>
          </div>

          {isAdmin && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, branch_id: e.target.value }))
                }
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
              {branchError && (
                <div className="small text-danger mt-1">{branchError}</div>
              )}
            </div>
          )}

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading customer addresses...
              </div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Customer</CTableHeaderCell>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Cust. Status</CTableHeaderCell>
                    <CTableHeaderCell>Label</CTableHeaderCell>
                    <CTableHeaderCell>Address</CTableHeaderCell>
                    <CTableHeaderCell>City</CTableHeaderCell>
                    <CTableHeaderCell>State</CTableHeaderCell>
                    <CTableHeaderCell>Pincode</CTableHeaderCell>
                    <CTableHeaderCell>Default</CTableHeaderCell>
                    {isAdmin && <CTableHeaderCell>Branch</CTableHeaderCell>}
                    <CTableHeaderCell>Serviceable</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell
                        colSpan={isAdmin ? 12 : 11}
                        className="text-center text-muted py-4"
                      >
                        No addresses found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={r.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{r.customer_name}</CTableDataCell>
                        <CTableDataCell>{r.phone ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={getStatusBadge(r.customer_status)}
                            shape="rounded-pill"
                          >
                            {r.customer_status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.label}</CTableDataCell>
                        <CTableDataCell>
                          {r.address_line1}
                          {r.address_line2 ? `, ${r.address_line2}` : ''}
                        </CTableDataCell>
                        <CTableDataCell>{r.city}</CTableDataCell>
                        <CTableDataCell>{r.state}</CTableDataCell>
                        <CTableDataCell>{r.pincode}</CTableDataCell>
                        <CTableDataCell>{r.is_default ? 'Yes' : '—'}</CTableDataCell>
                        {isAdmin && (
                          <CTableDataCell>{r.branch_name ?? '—'}</CTableDataCell>
                        )}
                        <CTableDataCell>
                          {r.is_serviceable ? 'Yes' : 'No'}
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default CustomerAddressReport