import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDateTime } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const STATUS_COLOR = {
  pending: 'warning',
  approved: 'info',
  fulfilled: 'success',
  cancelled: 'secondary',
}

const SORT_KEY_MAP = {
  created_at:         'created_at',
  from_branch:        'from_branch',
  to_branch:          'to_branch',
  status:             'status',
  product_name:       'product_name',
  sku:                'sku',
  quantity_requested: 'quantity_requested',
  quantity_approved:  'quantity_approved',
  quantity_fulfilled: 'quantity_fulfilled',
  mrp:                'mrp',
  selling_price:      'selling_price',
  purchase_price:     'purchase_price',
}

const StockRequestDetail = () => {
  const authRole = useAuthStore((s) => s.role)

  // ★ HO users (admin, superadmin, staff_headoffice) can filter by
  //   From / To Branch. Everyone else is branch-bound — the backend
  //   forces from_branch_id to their own branch.
  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const [rows, setRows] = useState([])
  // ★ From Branch uses ALL branches — any branch can raise a stock request.
  const [branches, setBranches] = useState([])
  // ★ To Branch uses Head Office + State Office only — stock requests
  //   never go to another regular branch.
  const [toBranches, setToBranches] = useState([])
  const [products, setProducts] = useState([])
  const [variants, setVariants] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date: today,
    from_branch_id: '',
    to_branch_id: '',
    status: '',
    product_id: '',
    variant_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  // ★ Fetch all branches once, then split:
  //   - branches   → all branches (for From Branch dropdown)
  //   - toBranches → head_office + state_office only (for To Branch dropdown)
  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      const all = Array.isArray(d) ? d : (d?.data ?? [])
      setBranches(all)
      setToBranches(
        all.filter(b => b.type === 'head_office' || b.type === 'state_office')
      )
    } catch { /* silent */ }
  }

  const fetchProducts = async () => {
    try {
      const res = await api.get('/masters/products', { params: { per_page: 500, is_active: 1 } })
      const d = res.data?.data
      setProducts(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchVariants = async (productId) => {
    try {
      const res = await api.get(`/masters/products/${productId}`)
      const product = res.data?.data?.product
      setVariants(product?.variants ?? [])
    } catch { /* silent */ }
  }

  useEffect(() => {
    fetchBranches()
    fetchProducts()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHeadOffice])

  useEffect(() => {
    if (filters.product_id) {
      fetchVariants(filters.product_id)
    } else {
      setVariants([])
    }
    setFilters((f) => ({ ...f, variant_id: '' }))
  }, [filters.product_id])

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page: usePerPage,
      from_date: useFilters.from_date,
      to_date: useFilters.to_date,
    }
    if (isHeadOffice && useFilters.from_branch_id) {
      params.from_branch_id = useFilters.from_branch_id
    }
    if (isHeadOffice && useFilters.to_branch_id) {
      params.to_branch_id = useFilters.to_branch_id
    }
    if (useFilters.status) params.status = useFilters.status
    if (useFilters.product_id) params.product_id = useFilters.product_id
    if (useFilters.variant_id) params.variant_id = useFilters.variant_id
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/stock-request-detail', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load stock request details.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (!filters.from_date || !filters.to_date) {
      setError('Date range is required.')
      return
    }
    if (filters.from_date > filters.to_date) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleReset = () => {
    const empty = {
      from_date: monthAgo,
      to_date: today,
      from_branch_id: '',
      to_branch_id: '',
      status: '',
      product_id: '',
      variant_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setVariants([])
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/stock-request-detail', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `stock_request_detail_${appliedFilters.from_date}_${appliedFilters.to_date}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Stock Request Detail</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, from_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, to_date: e.target.value }))
              }
            />
          </div>

          {/* ★ From Branch — HO only. Shows ALL branches (any branch can
              raise a stock request). */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">From Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.from_branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, from_branch_id: e.target.value }))
                }
              >
                <option value="">All</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          {/* ★ To Branch — HO only. Shows only Head Office + State Office
              (stock requests never go to another regular branch). */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">To Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.to_branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, to_branch_id: e.target.value }))
                }
              >
                <option value="">All</option>
                {toBranches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.status}
              onChange={(e) =>
                setFilters((f) => ({ ...f, status: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="fulfilled">Fulfilled</option>
              <option value="cancelled">Cancelled</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Product</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.product_id}
              onChange={(e) =>
                setFilters((f) => ({ ...f, product_id: e.target.value }))
              }
            >
              <option value="">All Products</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Variant</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.variant_id}
              disabled={!filters.product_id || variants.length === 0}
              onChange={(e) =>
                setFilters((f) => ({ ...f, variant_id: e.target.value }))
              }
            >
              <option value="">All Variants</option>
              {variants.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.sku}
                  {v.attributes?.length
                    ? ' — ' + v.attributes.map((a) => a.value).join(', ')
                    : ''}
                </option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleReset}
              disabled={loading}
            >
              Reset
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading stock request details...
              </div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Date</SortableHeader>
                    <SortableHeader colKey="from_branch">From Branch</SortableHeader>
                    <SortableHeader colKey="to_branch">To Branch</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="product_name">Product</SortableHeader>
                    <SortableHeader colKey="sku">SKU</SortableHeader>
                    <CTableHeaderCell>Variant</CTableHeaderCell>
                    <SortableHeader colKey="quantity_requested">Requested</SortableHeader>
                    <SortableHeader colKey="quantity_approved">Approved</SortableHeader>
                    <SortableHeader colKey="quantity_fulfilled">Fulfilled</SortableHeader>
                    <SortableHeader colKey="mrp">MRP</SortableHeader>
                    <SortableHeader colKey="selling_price">Selling</SortableHeader>
                    <SortableHeader colKey="purchase_price">Purchase</SortableHeader>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={14} className="text-center text-muted py-4">
                        No records found for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={`${r.sku}-${r.created_at}-${i}`}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{formatDateTime(r.created_at)}</CTableDataCell>
                        <CTableDataCell>{r.from_branch}</CTableDataCell>
                        <CTableDataCell>{r.to_branch}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLOR[r.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {r.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.product_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill">{r.sku}</CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.variant_attributes ?? '—'}</CTableDataCell>
                        <CTableDataCell>{r.quantity_requested}</CTableDataCell>
                        <CTableDataCell>{r.quantity_approved ?? '—'}</CTableDataCell>
                        <CTableDataCell>{r.quantity_fulfilled ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          {r.mrp != null ? `₹${r.mrp}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          {r.selling_price != null ? `₹${r.selling_price}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          {r.purchase_price != null ? `₹${r.purchase_price}` : '—'}
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default StockRequestDetail