import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDateTime } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const STATUS_COLOR = {
  pending: 'warning',
  approved: 'info',
  fulfilled: 'success',
  cancelled: 'secondary',
}

const SORT_KEY_MAP = {
  created_at:      'created_at',
  from_branch:     'from_branch',
  to_branch:       'to_branch',
  status:          'status',
  item_count:      'item_count',
  total_requested: 'total_requested',
  total_approved:  'total_approved',
  total_fulfilled: 'total_fulfilled',
}

const StockRequestsReport = () => {
  const authRole = useAuthStore((s) => s.role)

  // ★ HO users (admin, superadmin, staff_headoffice) can filter by
  //   From / To Branch. Everyone else is branch-bound.
  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const [rows, setRows] = useState([])
  // ★ From Branch uses ALL branches — any branch can raise a stock request.
  const [branches, setBranches] = useState([])
  // ★ To Branch uses Head Office + State Office only.
  const [toBranches, setToBranches] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date: today,
    from_branch_id: '',
    to_branch_id: '',
    status: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  // ★ Fetch all branches once, then split:
  //   branches   → all branches (From Branch dropdown)
  //   toBranches → head_office + state_office only (To Branch dropdown)
  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      const all = Array.isArray(d) ? d : (d?.data ?? [])
      setBranches(all)
      setToBranches(
        all.filter(b => b.type === 'head_office' || b.type === 'state_office')
      )
    } catch { /* silent */ }
  }

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page: usePerPage,
      from_date: useFilters.from_date,
      to_date: useFilters.to_date,
    }
    // ★ Branch filters only sent by HO users.
    if (isHeadOffice && useFilters.from_branch_id) {
      params.from_branch_id = useFilters.from_branch_id
    }
    if (isHeadOffice && useFilters.to_branch_id) {
      params.to_branch_id = useFilters.to_branch_id
    }
    if (useFilters.status) params.status = useFilters.status
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/stock-requests', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load stock requests.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => { fetchBranches() }, [isHeadOffice])

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (!filters.from_date || !filters.to_date) {
      setError('Date range is required.')
      return
    }
    if (filters.from_date > filters.to_date) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleClear = () => {
    const empty = {
      from_date: monthAgo,
      to_date: today,
      from_branch_id: '',
      to_branch_id: '',
      status: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/stock-requests', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `stock_requests_${appliedFilters.from_date}_${appliedFilters.to_date}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Stock Request Summary</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, from_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, to_date: e.target.value }))
              }
            />
          </div>

          {/* ★ From Branch — HO only. All branches (any branch can raise). */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">From Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.from_branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, from_branch_id: e.target.value }))
                }
              >
                <option value="">All</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          {/* ★ To Branch — HO only. Head Office + State Office only. */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">To Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.to_branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, to_branch_id: e.target.value }))
                }
              >
                <option value="">All</option>
                {toBranches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.status}
              onChange={(e) =>
                setFilters((f) => ({ ...f, status: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="fulfilled">Fulfilled</option>
              <option value="cancelled">Cancelled</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading stock requests...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Date</SortableHeader>
                    <SortableHeader colKey="from_branch">From Branch</SortableHeader>
                    <SortableHeader colKey="to_branch">To Branch</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="item_count">Items</SortableHeader>
                    <SortableHeader colKey="total_requested">Requested</SortableHeader>
                    <SortableHeader colKey="total_approved">Approved</SortableHeader>
                    <SortableHeader colKey="total_fulfilled">Fulfilled</SortableHeader>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No records found for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={r.id ?? i}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{formatDateTime(r.created_at)}</CTableDataCell>
                        <CTableDataCell>{r.from_branch}</CTableDataCell>
                        <CTableDataCell>{r.to_branch}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLOR[r.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {r.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.item_count}</CTableDataCell>
                        <CTableDataCell>{r.total_requested}</CTableDataCell>
                        <CTableDataCell>{r.total_approved ?? '—'}</CTableDataCell>
                        <CTableDataCell>{r.total_fulfilled ?? '—'}</CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default StockRequestsReport