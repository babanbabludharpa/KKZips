import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPeople, cilWarning } from '@coreui/icons'
import supportReportApi from '../../../services/supportReportApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const fmtDateTime = (iso) => {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}

const SORT_OPTIONS = [
  { value: 'last_contact',       label: 'Most recent contact' },
  { value: 'conversation_count', label: 'Most conversations' },
  { value: 'message_count',      label: 'Most messages' },
  { value: 'unmatched_count',    label: 'Most unmatched (worst experience)' },
  { value: 'customer_name',      label: 'Customer A–Z' },
]

const SupportCustomerActivityTab = () => {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [sortKey, setSortKey] = useState('last_contact')
  const [filters, setFilters] = useState({ from_date: monthAgo, to_date: today })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    sortOverride = sortKey,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = {
        page,
        per_page: perPageOverride,
        from_date: filtersOverride.from_date,
        to_date: filtersOverride.to_date,
        sort_key: sortOverride,
      }
      if (searchOverride) params.search = searchOverride

      const res = await supportReportApi.customers(params)
      if (mySeq !== requestSeq.current) return

      setRows(res.items)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load customer activity.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  useEffect(() => {
    setPageLoading(true)
    fetchData({ page: 1, sortOverride: sortKey })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortKey])

  const applyDates = () => {
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm"
            className="filter-input"
            placeholder="Customer name or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">From</CFormLabel>
          <CFormInput
            size="sm"
            type="date"
            className="filter-input"
            value={filters.from_date}
            onChange={(e) => setFilters((f) => ({ ...f, from_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">To</CFormLabel>
          <CFormInput
            size="sm"
            type="date"
            className="filter-input"
            value={filters.to_date}
            onChange={(e) => setFilters((f) => ({ ...f, to_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Sort</CFormLabel>
          <CFormSelect
            size="sm"
            className="filter-input"
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value)}
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>

        <div className="filter-field filter-field--buttons">
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={applyDates}
            disabled={loading}
          >
            Apply
          </CButton>
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>
            {error}
          </CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading customer activity...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">👥</div>
            <div className="faq-empty__title">No customer activity</div>
            <div className="faq-empty__sub">No support chats in this date range.</div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.customer_id}
                className="faq-card"
                style={{ display: 'flex', alignItems: 'center', gap: 16 }}
              >
                <div className="faq-icon-chip">
                  <CIcon icon={cilPeople} />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="faq-card__title">
                    {row.customer_name ?? 'Unknown'}{' '}
                    <span style={{ color: '#94a3b8', fontWeight: 500 }}>
                      · {row.customer_phone ?? '—'}
                    </span>
                  </div>
                  <div className="faq-card__meta" style={{ marginTop: 6 }}>
                    <CBadge color="info" shape="rounded-pill">
                      {row.conversation_count} chat{row.conversation_count === 1 ? '' : 's'}
                    </CBadge>
                    <span className="faq-card__meta-item">{row.questions_asked} questions</span>
                    <span className="faq-card__meta-item">{row.message_count} messages</span>
                    {row.unmatched_count > 0 && (
                      <CBadge color="warning" shape="rounded-pill">
                        <CIcon icon={cilWarning} size="sm" className="me-1" />
                        {row.unmatched_count} unanswered
                      </CBadge>
                    )}
                  </div>
                  <div
                    className="faq-card__meta"
                    style={{ marginTop: 6, fontSize: '0.78rem', color: '#94a3b8' }}
                  >
                    <span>First: {fmtDateTime(row.first_contact)}</span>
                    <span>·</span>
                    <span>Last: {fmtDateTime(row.last_contact)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />
    </>
  )
}

export default SupportCustomerActivityTab