import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWarning } from '@coreui/icons'
import supportReportApi from '../../../services/supportReportApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const fmtDateTime = (iso) => {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

const SupportUnmatchedTab = () => {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [filters, setFilters] = useState({ from_date: monthAgo, to_date: today })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = {
        page,
        per_page: perPageOverride,
        from_date: filtersOverride.from_date,
        to_date: filtersOverride.to_date,
      }
      if (searchOverride) params.search = searchOverride

      const res = await supportReportApi.unmatched(params)
      if (mySeq !== requestSeq.current) return

      setRows(res.items)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load unmatched messages.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const applyDates = () => {
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm" className="filter-input"
            placeholder="Customer or message text..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">From</CFormLabel>
          <CFormInput
            size="sm" type="date" className="filter-input"
            value={filters.from_date}
            onChange={(e) => setFilters((f) => ({ ...f, from_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">To</CFormLabel>
          <CFormInput
            size="sm" type="date" className="filter-input"
            value={filters.to_date}
            onChange={(e) => setFilters((f) => ({ ...f, to_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>

        <div className="filter-field filter-field--buttons">
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={applyDates}
            disabled={loading}
          >
            Apply
          </CButton>
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading unmatched messages...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">✓</div>
            <div className="faq-empty__title">No unmatched messages</div>
            <div className="faq-empty__sub">
              Every question in this date range got an answer.
            </div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.id}
                className="faq-card"
                style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}
              >
                <div className="faq-icon-chip faq-icon-chip--warning">
                  <CIcon icon={cilWarning} />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="faq-card__title">
                    {row.customer_name ?? 'Unknown'}{' '}
                    <span style={{ color: '#94a3b8', fontWeight: 500 }}>· {row.customer_phone ?? '—'}</span>
                  </div>

                  {row.customer_question && (
                    <div
                      style={{
                        fontSize: '0.92rem',
                        color: '#0f172a',
                        marginTop: 6,
                        padding: '8px 12px',
                        background: '#f8fafc',
                        border: '1px solid #e2e8f0',
                        borderRadius: 8,
                        lineHeight: 1.5,
                      }}
                    >
                      <strong style={{ color: '#64748b', fontWeight: 600 }}>Asked:</strong> {row.customer_question}
                    </div>
                  )}

                  <div className="faq-card__meta" style={{ marginTop: 8 }}>
                    <span className="faq-card__meta-item">
                      Conversation #{row.conversation_id}
                    </span>
                    <span className="faq-card__meta-item">{fmtDateTime(row.created_at)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />
    </>
  )
}

export default SupportUnmatchedTab