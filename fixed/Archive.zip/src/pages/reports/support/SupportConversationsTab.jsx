import { useEffect, useRef, useState } from 'react'
import {
  CButton, CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CBadge,
  CModal, CModalHeader, CModalTitle, CModalBody,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilArrowRight, cilChatBubble } from '@coreui/icons'
import supportReportApi from '../../../services/supportReportApi'
import Pagination from '../../../components/Pagination'
import PerPageSelector from '../../../components/PerPageSelector'
import { usePagination } from '../../../hooks/usePagination'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const STATUS_COLORS = {
  open:       'info',
  resolved:   'success',
  escalated:  'warning',
}

const fmtDateTime = (iso) => {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

const SupportConversationsTab = () => {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [status, setStatus] = useState('')
  const [filters, setFilters] = useState({ from_date: monthAgo, to_date: today })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const [detail, setDetail] = useState({ open: false, id: null, data: null, loading: false })

  const requestSeq = useRef(0)
  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const fetchData = async ({
    page = 1,
    searchOverride = appliedSearch,
    statusOverride = status,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = {
        page,
        per_page: perPageOverride,
        from_date: filtersOverride.from_date,
        to_date: filtersOverride.to_date,
      }
      if (searchOverride) params.search = searchOverride
      if (statusOverride) params.status = statusOverride

      const res = await supportReportApi.conversations(params)
      if (mySeq !== requestSeq.current) return

      setRows(res.items)
      updatePagination({
        current_page: res.meta?.current_page ?? 1,
        last_page:    res.meta?.last_page    ?? 1,
        per_page:     res.meta?.per_page     ?? perPageOverride,
        total:        res.meta?.total        ?? res.items.length,
        from:         res.meta?.from         ?? null,
        to:           res.meta?.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(e.response?.data?.message ?? 'Failed to load conversations.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  useEffect(() => {
    setPageLoading(true)
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status])

  const applyDates = () => {
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const openDetail = async (id) => {
    setDetail({ open: true, id, data: null, loading: true })
    try {
      const data = await supportReportApi.conversationDetail(id)
      setDetail({ open: true, id, data, loading: false })
    } catch (e) {
      setDetail({ open: false, id: null, data: null, loading: false })
      setError(e.response?.data?.message ?? 'Failed to load conversation.')
    }
  }

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  return (
    <>
      <div className="report-shell__filters faq-filters">
        <div className="filter-field filter-field--customer">
          <CFormLabel className="filter-label">Search</CFormLabel>
          <CFormInput
            size="sm"
            className="filter-input"
            placeholder="Customer name or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">From</CFormLabel>
          <CFormInput
            size="sm" type="date" className="filter-input"
            value={filters.from_date}
            onChange={(e) => setFilters((f) => ({ ...f, from_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--date">
          <CFormLabel className="filter-label">To</CFormLabel>
          <CFormInput
            size="sm" type="date" className="filter-input"
            value={filters.to_date}
            onChange={(e) => setFilters((f) => ({ ...f, to_date: e.target.value }))}
          />
        </div>

        <div className="filter-field filter-field--type">
          <CFormLabel className="filter-label">Status</CFormLabel>
          <CFormSelect
            size="sm" className="filter-input"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">All statuses</option>
            <option value="open">Open</option>
            <option value="resolved">Resolved</option>
            <option value="escalated">Escalated</option>
          </CFormSelect>
        </div>

        <div className="filter-field filter-field--perpage">
          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>

        <div className="filter-field filter-field--buttons">
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={applyDates}
            disabled={loading}
          >
            Apply
          </CButton>
        </div>
      </div>

      {error && (
        <div className="report-shell__error">
          <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
        </div>
      )}

      <div className="p-3">
        {loading ? (
          <div className="report-shell__loading">
            <CSpinner />
            <div className="report-shell__loading-text">Loading conversations...</div>
          </div>
        ) : rows.length === 0 ? (
          <div className="faq-empty">
            <div className="faq-empty__icon">💬</div>
            <div className="faq-empty__title">No conversations</div>
            <div className="faq-empty__sub">No customer chats in this date range.</div>
          </div>
        ) : (
          <div className="faq-list">
            {rows.map((row) => (
              <div
                key={row.id}
                className="faq-card"
                style={{ display: 'flex', alignItems: 'flex-start', gap: 16, cursor: 'pointer' }}
                onClick={() => openDetail(row.id)}
              >
                <div className="faq-icon-chip">
                  <CIcon icon={cilChatBubble} />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="faq-card__title">
                    {row.customer_name ?? 'Unknown'} <span style={{ color: '#94a3b8', fontWeight: 500 }}>· {row.customer_phone ?? '—'}</span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.92rem',
                      color: '#475569',
                      marginTop: 4,
                      marginBottom: 8,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    "{row.first_question ?? '—'}"
                  </div>
                  <div className="faq-card__meta">
                    <CBadge color={STATUS_COLORS[row.status] ?? 'secondary'} shape="rounded-pill">
                      {row.status}
                    </CBadge>
                    <span className="faq-card__meta-item">{row.message_count} messages</span>
                    {row.unmatched_count > 0 && (
                      <CBadge color="warning" shape="rounded-pill">
                        {row.unmatched_count} unmatched
                      </CBadge>
                    )}
                    <span className="faq-card__meta-item">Last: {fmtDateTime(row.last_message_at)}</span>
                  </div>
                </div>

                <div className="faq-card__actions">
                  <CIcon icon={cilArrowRight} style={{ color: '#94a3b8' }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Pagination
        meta={meta}
        onPageChange={handlePageChange}
        loading={pageLoading}
        variant="bold"
        showPageJumper={true}
        showRecordInfo={true}
      />

      {/* ── Conversation thread drawer ── */}
      <CModal
        visible={detail.open}
        onClose={() => setDetail({ open: false, id: null, data: null, loading: false })}
        size="lg"
        alignment="center"
      >
        <CModalHeader>
          <CModalTitle>
            Conversation {detail.data ? `#${detail.data.id}` : ''}
          </CModalTitle>
        </CModalHeader>
        <CModalBody style={{ maxHeight: '70vh', overflowY: 'auto' }}>
          {detail.loading ? (
            <div className="text-center py-5">
              <CSpinner />
            </div>
          ) : detail.data ? (
            <div className="d-flex flex-column gap-2">
              {detail.data.messages.map((m) => {
                const isCustomer = m.sender_type === 'customer'
                const isFallback = m.metadata?.layer === 'fallback'
                return (
                  <div
                    key={m.id}
                    style={{
                      display: 'flex',
                      justifyContent: isCustomer ? 'flex-end' : 'flex-start',
                    }}
                  >
                    <div
                      style={{
                        maxWidth: '75%',
                        padding: '10px 14px',
                        borderRadius: 12,
                        background: isCustomer
                          ? '#1e40af'
                          : isFallback
                            ? '#fef3c7'
                            : '#f1f5f9',
                        color: isCustomer ? '#ffffff' : '#0f172a',
                        fontSize: '0.9rem',
                        lineHeight: 1.5,
                      }}
                    >
                      <div>{m.message}</div>
                      <div
                        style={{
                          fontSize: '0.7rem',
                          marginTop: 6,
                          opacity: 0.7,
                          display: 'flex',
                          gap: 8,
                          flexWrap: 'wrap',
                        }}
                      >
                        <span>{fmtDateTime(m.created_at)}</span>
                        {m.faq_id && <span>· FAQ #{m.faq_id}</span>}
                        {m.confidence != null && <span>· {m.confidence}</span>}
                        {m.metadata?.layer && <span>· {m.metadata.layer}</span>}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : null}
        </CModalBody>
      </CModal>
    </>
  )
}

export default SupportConversationsTab