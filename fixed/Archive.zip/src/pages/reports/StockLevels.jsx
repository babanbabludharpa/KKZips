import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormCheck, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

const today = new Date().toISOString().slice(0, 10)

const SORT_KEY_MAP = {
  sku:           'sku',
  product_name:  'product_name',
  branch_name:   'branch_name',
  quantity:      'quantity',
  min_order_qty: 'min_order_qty',
}

const StockLevels = () => {
  const user = useAuthStore((s) => s.user)

  const isHeadOffice = !!user && (
    user.role === 'staff_headoffice' ||
    user.role === 'superadmin' ||
    user.role === 'admin'
  )

  const [rows, setRows] = useState([])
  const [branches, setBranches] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('asc')

  const [search, setSearch] = useState('')
  const [filters, setFilters] = useState({ branch_id: '', low_stock: false })

  const requestSeq = useRef(0)

  // ★ Guards to prevent duplicate fetches.
  const initialFetchedRef = useRef(false)
  const skipFirstEffectRef = useRef(true)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      setBranches(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const buildParams = (
    useFilters,
    usePerPage,
    useSortKey,
    useSortDir,
    useSearch,
  ) => {
    const params = { per_page: usePerPage }

    if (isHeadOffice && useFilters.branch_id) {
      params.branch_id = useFilters.branch_id
    }

    if (useFilters.low_stock) params.low_stock = 1
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = filters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
    searchOverride = search,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(
          filtersOverride,
          perPageOverride,
          sortKeyOverride,
          sortDirOverride,
          searchOverride,
        ),
      }

      const res = await api.get('/reports/stock-levels', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load stock levels.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  // ★ Fetch branches once, and only for HO users
  useEffect(() => {
    fetchBranches()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHeadOffice])

  // ★ ONE-TIME initial fetch on mount
  useEffect(() => {
    if (initialFetchedRef.current) return
    initialFetchedRef.current = true
    fetchData({ page: 1, perPageOverride: 25 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ★ ONE debounced effect for any filter / search / sort change.
  //   Skips the first run because the mount effect above already fetched.
  useEffect(() => {
    if (skipFirstEffectRef.current) {
      skipFirstEffectRef.current = false
      return
    }

    const t = setTimeout(() => {
      setPageLoading(true)
      fetchData({
        page: 1,
        searchOverride:  search,
        filtersOverride: filters,
        sortKeyOverride: sortKey,
        sortDirOverride: sortDir,
      })
    }, 300)

    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, filters, sortKey, sortDir])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    // The debounced effect above will fire the fetch.
  }

  const handleClear = () => {
    setSearch('')
    setFilters({ branch_id: '', low_stock: false })
    setSortKey(null)
    setSortDir('asc')
    // The debounced effect fires the fetch after state settles.
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(filters, perPage, sortKey, sortDir, search),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/stock-levels', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `stock_levels_${today}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Stock Levels</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Product or SKU"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, branch_id: e.target.value }))
                }
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field">
            <CFormLabel className="filter-label">&nbsp;</CFormLabel>
            <div className="d-flex align-items-center gap-2" style={{ height: 34 }}>
              <CFormCheck
                id="low_stock"
                checked={filters.low_stock}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, low_stock: e.target.checked }))
                }
              />
              <label
                htmlFor="low_stock"
                className="mb-0"
                style={{ cursor: 'pointer', fontSize: '0.85rem', color: '#334155' }}
              >
                Low stock only
              </label>
            </div>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading stock levels...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="sku">SKU</SortableHeader>
                    <SortableHeader colKey="product_name">Product</SortableHeader>
                    <CTableHeaderCell>Variant</CTableHeaderCell>
                    <SortableHeader colKey="branch_name">Branch</SortableHeader>
                    <SortableHeader colKey="quantity">Quantity</SortableHeader>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No records found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={`${r.sku}-${r.branch_id ?? 'x'}-${i}`}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill">{r.sku}</CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.product_name}</CTableDataCell>
                        <CTableDataCell>
                          {r.variant_attributes ? r.variant_attributes : '—'}
                        </CTableDataCell>
                        <CTableDataCell>{r.branch_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <span className="fw-semibold">{r.quantity}</span>
                        </CTableDataCell>
                        <CTableDataCell>
                          {Number(r.quantity) <= Number(r.min_order_qty ?? 0) ? (
                            <CBadge color="danger" shape="rounded-pill">Low Stock</CBadge>
                          ) : (
                            <CBadge color="success" shape="rounded-pill">OK</CBadge>
                          )}
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default StockLevels