import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDate } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const SOURCE_COLOR = {
  manual: 'warning',
  schedule: 'info',
}

const SORT_KEY_MAP = {
  changed_at:          'changed_at',
  sku:                 'sku',
  product_name:        'product_name',
  source:              'source',
  prev_mrp:            'prev_mrp',
  new_mrp:             'new_mrp',
  prev_selling_price:  'prev_selling_price',
  new_selling_price:   'new_selling_price',
  prev_purchase_price: 'prev_purchase_price',
  new_purchase_price:  'new_purchase_price',
  changed_by_name:     'changed_by_name',
}

const PriceHistory = () => {
  const [rows, setRows] = useState([])
  const [products, setProducts] = useState([])
  const [variants, setVariants] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date: today,
    source: '',
    product_id: '',
    variant_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchProducts = async () => {
    try {
      // ★ is_active must be 1 or 0 — sending `true` serializes to the
      // string "true" in the query string, which Laravel's `boolean`
      // validation rule rejects with a 422. Use 1 for true, 0 for false.
      const res = await api.get('/masters/products', {
        params: { per_page: 500, is_active: 1 },
      })
      const d = res.data?.data
      setProducts(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchVariants = async (productId) => {
    try {
      const res = await api.get(`/masters/products/${productId}`)
      setVariants(res.data?.data?.product?.variants ?? [])
    } catch { /* silent */ }
  }

  useEffect(() => {
    fetchProducts()
  }, [])

  useEffect(() => {
    if (filters.product_id) {
      fetchVariants(filters.product_id)
    } else {
      setVariants([])
    }
    setFilters((f) => ({ ...f, variant_id: '' }))
  }, [filters.product_id])

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page: usePerPage,
      from_date: useFilters.from_date,
      to_date: useFilters.to_date,
    }
    if (useFilters.source) params.source = useFilters.source
    if (useFilters.product_id) params.product_id = useFilters.product_id
    if (useFilters.variant_id) params.variant_id = useFilters.variant_id
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/price-history', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load price history.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (!filters.from_date || !filters.to_date) {
      setError('Date range is required.')
      return
    }
    if (filters.from_date > filters.to_date) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleReset = () => {
    const empty = {
      from_date: monthAgo,
      to_date: today,
      source: '',
      product_id: '',
      variant_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setVariants([])
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/price-history', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `price_history_${appliedFilters.from_date}_${appliedFilters.to_date}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Price Change History</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, from_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, to_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Source</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.source}
              onChange={(e) =>
                setFilters((f) => ({ ...f, source: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="manual">Manual</option>
              <option value="schedule">Schedule</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Product</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.product_id}
              onChange={(e) =>
                setFilters((f) => ({ ...f, product_id: e.target.value }))
              }
            >
              <option value="">All Products</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Variant</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.variant_id}
              disabled={!filters.product_id || variants.length === 0}
              onChange={(e) =>
                setFilters((f) => ({ ...f, variant_id: e.target.value }))
              }
            >
              <option value="">All Variants</option>
              {variants.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.sku}
                  {v.attributes?.length
                    ? ' — ' + v.attributes.map((a) => a.value).join(', ')
                    : ''}
                </option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleReset}
              disabled={loading}
            >
              Reset
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading price history...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="changed_at">Date</SortableHeader>
                    <SortableHeader colKey="sku">SKU</SortableHeader>
                    <SortableHeader colKey="product_name">Product</SortableHeader>
                    <SortableHeader colKey="source">Source</SortableHeader>
                    <SortableHeader colKey="prev_mrp">Prev MRP</SortableHeader>
                    <SortableHeader colKey="new_mrp">New MRP</SortableHeader>
                    <SortableHeader colKey="prev_selling_price">Prev Selling</SortableHeader>
                    <SortableHeader colKey="new_selling_price">New Selling</SortableHeader>
                    <SortableHeader colKey="prev_purchase_price">Prev Purchase</SortableHeader>
                    <SortableHeader colKey="new_purchase_price">New Purchase</SortableHeader>
                    <SortableHeader colKey="changed_by_name">Changed By</SortableHeader>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={12} className="text-center text-muted py-4">
                        No records found for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={`${r.sku}-${r.changed_at}-${i}`}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{formatDate(r.changed_at)}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill">{r.sku}</CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{r.product_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={SOURCE_COLOR[r.source] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {r.source}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell className="text-muted">
                          {r.prev_mrp != null ? `₹${r.prev_mrp}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          {r.new_mrp != null ? `₹${r.new_mrp}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell className="text-muted">
                          {r.prev_selling_price != null ? `₹${r.prev_selling_price}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          {r.new_selling_price != null ? `₹${r.new_selling_price}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell className="text-muted">
                          {r.prev_purchase_price != null ? `₹${r.prev_purchase_price}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          {r.new_purchase_price != null ? `₹${r.new_purchase_price}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>{r.changed_by_name ?? 'System'}</CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default PriceHistory