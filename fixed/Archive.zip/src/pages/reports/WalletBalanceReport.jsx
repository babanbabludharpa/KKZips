import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWallet } from '@coreui/icons'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import WalletModal from '../../components/WalletModal'

const today = new Date().toISOString().slice(0, 10)

// Sortable columns map UI key -> backend sort param
const SORT_KEY_TO_PARAM = {
  customer_name: 'name',
  balance: 'balance',
}

const STATUS_BADGE_COLOR = {
  active: 'success',
  suspended: 'danger',
  inactive: 'secondary',
}

const getStatusBadge = (status) =>
  STATUS_BADGE_COLOR[String(status ?? '').toLowerCase()] || 'secondary'

const WalletBalanceReport = () => {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    customer_id: '',
    balance_min: '',
    balance_max: '',
    sort: 'balance_desc',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  // Customer picker state
  const [customerQuery, setCustomerQuery] = useState('')
  const [customerResults, setCustomerResults] = useState([])
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false)

  // Wallet modal
  const [walletCustomer, setWalletCustomer] = useState(null)
  const [walletOpen, setWalletOpen] = useState(false)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  // ---------- Helpers ----------
  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }

    if (useFilters.customer_id) params.customer_id = useFilters.customer_id
    if (useFilters.balance_min) params.balance_min = useFilters.balance_min
    if (useFilters.balance_max) params.balance_max = useFilters.balance_max

    // Header sort takes precedence over dropdown sort
    if (useSortKey) {
      const sortParam = SORT_KEY_TO_PARAM[useSortKey]
      if (sortParam) params.sort = `${sortParam}_${useSortDir}`
    } else if (useFilters.sort) {
      params.sort = useFilters.sort
    }

    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/wallet-balances', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData ?? {}

      setRows(dataArray)
      updatePagination(paginationMeta)
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load wallet balances.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  // ---------- Effects ----------
  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!customerQuery || selectedCustomer?.name === customerQuery) {
      setCustomerResults([])
      return
    }
    const t = setTimeout(() => {
      api.get('/masters/customers', { params: { search: customerQuery, per_page: 15 } })
        .then((res) => {
          const customerData = res.data?.data?.data ?? res.data?.data ?? []
          setCustomerResults(customerData)
        })
        .catch(() => setCustomerResults([]))
    }, 300)
    return () => clearTimeout(t)
  }, [customerQuery, selectedCustomer])

  // ---------- Actions ----------
  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    // Clear the dropdown-based sort so header sort wins
    setFilters((f) => ({ ...f, sort: '' }))
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (
      filters.balance_min !== '' &&
      filters.balance_max !== '' &&
      Number(filters.balance_min) > Number(filters.balance_max)
    ) {
      setError('"Min Balance" cannot be greater than "Max Balance".')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        export: 'csv',
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
      }
      delete params.per_page

      const res = await api.get('/reports/wallet-balances', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `customer_wallet_balances_${today}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const handleClear = () => {
    const empty = {
      customer_id: '',
      balance_min: '',
      balance_max: '',
      sort: 'balance_desc',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSelectedCustomer(null)
    setCustomerQuery('')
    setCustomerResults([])
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const pickCustomer = (c) => {
    setSelectedCustomer(c)
    setCustomerQuery(c.name)
    setFilters((f) => ({ ...f, customer_id: c.id }))
    setShowCustomerDropdown(false)
  }

  const openWallet = (row) => {
    setWalletCustomer({ id: row.customer_id, name: row.customer_name })
    setWalletOpen(true)
  }

  const closeWallet = () => setWalletOpen(false)

  // ---------- Sortable header ----------
  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'

    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Customer Wallet Balance Report</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Customer</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Name or phone"
              value={customerQuery}
              onChange={(e) => {
                setCustomerQuery(e.target.value)
                setSelectedCustomer(null)
                setFilters((f) => ({ ...f, customer_id: '' }))
                setShowCustomerDropdown(true)
              }}
              onFocus={() => setShowCustomerDropdown(true)}
              onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 150)}
            />
            {showCustomerDropdown && customerResults.length > 0 && (
              <div className="filter-dropdown">
                {customerResults.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className="dropdown-item"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => pickCustomer(c)}
                  >
                    {c.name} — {c.phone ?? 'no phone'}
                  </button>
                ))}
                {customerResults.length === 15 && (
                  <div className="dropdown-item-text small">
                    Keep typing to narrow results…
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">Min Balance</CFormLabel>
            <CFormInput
              size="sm"
              type="number"
              className="filter-input"
              value={filters.balance_min}
              onChange={(e) => setFilters((f) => ({ ...f, balance_min: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">Max Balance</CFormLabel>
            <CFormInput
              size="sm"
              type="number"
              className="filter-input"
              value={filters.balance_max}
              onChange={(e) => setFilters((f) => ({ ...f, balance_max: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Sort</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.sort}
              onChange={(e) => {
                setFilters((f) => ({ ...f, sort: e.target.value }))
                // Clear header sort when dropdown sort is used
                setSortKey(null)
                setSortDir('desc')
              }}
            >
              <option value="balance_desc">Balance: High to Low</option>
              <option value="balance_asc">Balance: Low to High</option>
              <option value="name_asc">Name: A to Z</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading wallet balances...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="customer_name">Customer</SortableHeader>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <SortableHeader colKey="balance">Balance</SortableHeader>
                    <CTableHeaderCell>Last Updated</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No wallets found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={r.customer_id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{r.customer_name}</CTableDataCell>
                        <CTableDataCell>{r.phone ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={getStatusBadge(r.customer_status)}
                            shape="rounded-pill"
                          >
                            {r.customer_status ?? '—'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell
                          className={Number(r.balance) < 0 ? 'text-danger' : 'text-success'}
                        >
                          ₹{Number(r.balance).toFixed(2)}
                        </CTableDataCell>
                        <CTableDataCell>{r.balance_updated_at ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => openWallet(r)}
                          >
                            <CIcon icon={cilWallet} className="me-1" />
                            Wallet
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      <WalletModal open={walletOpen} customer={walletCustomer} onClose={closeWallet} />
    </div>
  )
}

export default WalletBalanceReport