import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDateTime } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)

// ★ HO roles — all three see the Branch dropdown. Everyone else is
//   branch-bound and the backend forces their own branch.
const ADMIN_ROLES = ['staff_headoffice', 'admin', 'superadmin']

const TYPE_OPTIONS = [
  { value: '', label: 'All Types' },
  { value: 'deposit', label: 'Deposit' },
  { value: 'invoice_payment', label: 'Invoice Payment' },
  { value: 'refund', label: 'Refund' },
  { value: 'manual_adjustment', label: 'Manual Adjustment' },
]

const SORT_KEY_TO_PARAM = {
  created_at: 'date',
  customer_name: 'customer',
  type: 'type',
  amount: 'amount',
  balance_after: 'balance',
}

const normalizeType = (t) =>
  String(t ?? '').trim().toLowerCase().replace(/\s+/g, '_')

const TYPE_BADGE_COLOR = {
  deposit: 'success',
  invoice_payment: 'primary',
  refund: 'danger',
  manual_adjustment: 'warning',
  adjustment: 'warning',
}

const getTypeBadge = (type) => TYPE_BADGE_COLOR[normalizeType(type)] || 'secondary'

const prettyType = (type) =>
  normalizeType(type).replace(/_/g, ' ') || '—'

const isCredit = (signedDelta) => Number(signedDelta) >= 0

const WalletTransactionReport = () => {
  const authRole = useAuthStore((s) => s.role)

  // ★ HO users (admin, superadmin, staff_headoffice) can filter by branch.
  //   Everyone else is branch-bound — the backend forces their own branch.
  const isHeadOffice = ADMIN_ROLES.includes(authRole)

  const [rows, setRows] = useState([])
  const [branches, setBranches] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)
  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')
  const [filters, setFilters] = useState({
    customer_id: '', type: '', date_from: '', date_to: '', branch_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)
  const [customerQuery, setCustomerQuery] = useState('')
  const [customerResults, setCustomerResults] = useState([])
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  // ★ Branches — only fetched for HO users.
  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      const all = Array.isArray(d) ? d : (d?.data ?? [])
      setBranches(all)
    } catch { /* silent */ }
  }

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {}
    if (useFilters.customer_id) params.customer_id = useFilters.customer_id
    if (useFilters.type) params.type = useFilters.type
    if (useFilters.date_from) params.date_from = useFilters.date_from
    if (useFilters.date_to) params.date_to = useFilters.date_to
    // ★ Only HO users send branch_id. Non-HO users' branch is forced by backend.
    if (isHeadOffice && useFilters.branch_id) params.branch_id = useFilters.branch_id
    params.per_page = usePerPage
    if (useSortKey) {
      const sortParam = SORT_KEY_TO_PARAM[useSortKey]
      if (sortParam) params.sort = `${sortParam}_${useSortDir}`
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/wallet-transactions', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data || res.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData ?? {}

      setRows(dataArray)
      updatePagination(paginationMeta)
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load wallet transactions.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => { fetchBranches() }, [isHeadOffice])

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!customerQuery || selectedCustomer?.name === customerQuery) {
      setCustomerResults([])
      return
    }
    const t = setTimeout(() => {
      api.get('/masters/customers', { params: { search: customerQuery, per_page: 15 } })
        .then((res) => {
          const customerData = res.data?.data?.data ?? res.data?.data ?? []
          setCustomerResults(customerData)
        })
        .catch(() => setCustomerResults([]))
    }, 300)
    return () => clearTimeout(t)
  }, [customerQuery, selectedCustomer])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (filters.date_from && filters.date_to && filters.date_from > filters.date_to) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        export: 'csv',
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
      }
      delete params.per_page
      const res = await api.get('/reports/wallet-transactions', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `wallet_transactions_${today}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const handleClear = () => {
    const empty = { customer_id: '', type: '', date_from: '', date_to: '', branch_id: '' }
    setFilters(empty)
    setSelectedCustomer(null)
    setCustomerQuery('')
    setCustomerResults([])
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const pickCustomer = (c) => {
    setSelectedCustomer(c)
    setCustomerQuery(c.name)
    setFilters((f) => ({ ...f, customer_id: c.id }))
    setShowCustomerDropdown(false)
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'

    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Wallet Transaction Report</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Customer</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Name or phone"
              value={customerQuery}
              onChange={(e) => {
                setCustomerQuery(e.target.value)
                setSelectedCustomer(null)
                setFilters((f) => ({ ...f, customer_id: '' }))
                setShowCustomerDropdown(true)
              }}
              onFocus={() => setShowCustomerDropdown(true)}
              onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 150)}
            />
            {showCustomerDropdown && customerResults.length > 0 && (
              <div className="filter-dropdown">
                {customerResults.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className="dropdown-item"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => pickCustomer(c)}
                  >
                    {c.name} — {c.phone ?? 'no phone'}
                  </button>
                ))}
                {customerResults.length === 15 && (
                  <div className="dropdown-item-text small">
                    Keep typing to narrow results…
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ★ Branch — HO only */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) => setFilters((f) => ({ ...f, branch_id: e.target.value }))}
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Type</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.type}
              onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value }))}
            >
              {TYPE_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">From</CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.date_from}
              onChange={(e) => setFilters((f) => ({ ...f, date_from: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">To</CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.date_to}
              onChange={(e) => setFilters((f) => ({ ...f, date_to: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading transactions...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Date</SortableHeader>
                    <SortableHeader colKey="customer_name">Customer</SortableHeader>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <SortableHeader colKey="type">Type</SortableHeader>
                    <SortableHeader colKey="amount">Amount</SortableHeader>
                    <SortableHeader colKey="balance_after">Balance After</SortableHeader>
                    <CTableHeaderCell>Reference</CTableHeaderCell>
                    <CTableHeaderCell>Remark</CTableHeaderCell>
                    <CTableHeaderCell>Added By</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={10} className="text-center text-muted py-4">
                        No transactions found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((r, i) => (
                      <CTableRow key={r.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{formatDateTime(r.created_at)}</CTableDataCell>
                        <CTableDataCell>{r.customer_name}</CTableDataCell>
                        <CTableDataCell>{r.phone ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={getTypeBadge(r.type)}
                            shape="rounded-pill"
                            className={`type-${normalizeType(r.type)}`}
                          >
                            {prettyType(r.type)}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell
                          className={isCredit(r.signed_delta) ? 'text-success' : 'text-danger'}
                        >
                          {isCredit(r.signed_delta) ? '+' : ''}₹{Number(r.signed_delta).toFixed(2)}
                        </CTableDataCell>
                        <CTableDataCell>₹{Number(r.balance_after).toFixed(2)}</CTableDataCell>
                        <CTableDataCell>
                          {r.reference_type ? `${r.reference_type} #${r.reference_id}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>{r.remark ?? '—'}</CTableDataCell>
                        <CTableDataCell>{r.added_by_name ?? 'System'}</CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default WalletTransactionReport