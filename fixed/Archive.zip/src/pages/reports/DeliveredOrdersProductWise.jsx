import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
} from '@coreui/react'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import useAuthStore from '../../store/authStore'
import { formatDateTime } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const ADMIN_ROLES = ['admin', 'superadmin']

// Header column key -> backend sort key (must match DELIVERED_ORDER_ITEMS_SORTABLE in service)
const SORT_KEY_MAP = {
  order_number:      'order_number',
  delivered_at:      'delivered_at',
  customer_name:     'customer_name',
  branch_name:       'branch_name',
  delivery_boy_name: 'delivery_boy_name',
  sku:               'sku',
  product_name:      'product_name',
  quantity:          'quantity',
  mrp:               'mrp',
  unit_price:        'unit_price',
  discount_percent:  'discount_percent',
  final_price:       'final_price',
  tax_rate_percent:  'tax_rate_percent',
  tax_amount:        'tax_amount',
  cgst_amount:       'cgst_amount',
  sgst_amount:       'sgst_amount',
  igst_amount:       'igst_amount',
  line_total:        'line_total',
  coupon_discount:   'coupon_discount',
}

const DeliveredOrdersProductWiseReport = () => {
  const [rows, setRows] = useState([])
  const [branches, setBranches] = useState([])
  const [deliveryBoys, setDeliveryBoys] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const role = useAuthStore((s) => s.role)
  const isAdmin = ADMIN_ROLES.includes(role)

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date: today,
    branch_id: '',
    delivery_boy_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchBranches = async () => {
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      setBranches(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchDeliveryBoys = async () => {
    try {
      const params = {}
      if (isAdmin && filters.branch_id) params.branch_id = filters.branch_id
      const res = await api.get('/settings/delivery-boys', { params })
      const d = res.data?.data
      setDeliveryBoys(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  useEffect(() => {
    if (isAdmin) fetchBranches()
    fetchDeliveryBoys()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    fetchDeliveryBoys()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.branch_id])

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page: usePerPage,
      from_date: useFilters.from_date,
      to_date: useFilters.to_date,
    }
    if (isAdmin && useFilters.branch_id) params.branch_id = useFilters.branch_id
    if (useFilters.delivery_boy_id) params.delivery_boy_id = useFilters.delivery_boy_id
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, data: { data: [...rows], meta: { current_page, last_page, per_page, total } } }
  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/delivered-orders/product-wise', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load report.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (!filters.from_date || !filters.to_date) {
      setError('Date range is required.')
      return
    }
    if (filters.from_date > filters.to_date) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleReset = () => {
    const empty = {
      from_date: monthAgo,
      to_date: today,
      branch_id: '',
      delivery_boy_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const params = {
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
        export: 'csv',
      }
      delete params.per_page

      const res = await api.get('/reports/delivered-orders/product-wise', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `delivered_orders_product_wise_${appliedFilters.from_date}_${appliedFilters.to_date}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  // Total column count for the empty-state row
  // Sr.No + (Order #, Delivered, Customer, [Branch], DeliveryBoy, SKU, Product,
  //          Qty, MRP, Unit, Disc%, Final, Tax%, TaxAmt, CGST, SGST, IGST,
  //          Line Total, Coupon, CouponDisc)
  const colCount = isAdmin ? 21 : 20

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Delivered Orders — Product Wise</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, from_date: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) =>
                setFilters((f) => ({ ...f, to_date: e.target.value }))
              }
            />
          </div>

          {isAdmin && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, branch_id: e.target.value }))
                }
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Delivery Boy</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.delivery_boy_id}
              onChange={(e) =>
                setFilters((f) => ({ ...f, delivery_boy_id: e.target.value }))
              }
            >
              <option value="">All</option>
              {deliveryBoys.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleReset}
              disabled={loading}
            >
              Reset
            </CButton>
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading product-wise orders...
              </div>
            </div>
          ) : (
            <>
              {/* Wide table — horizontal scroll wrapper keeps columns readable */}
              <div className="report-table-scroll">
                <CTable
                  hover
                  bordered
                  className="admin-data-table admin-data-table--wide"
                >
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                      <SortableHeader colKey="order_number">Order #</SortableHeader>
                      <SortableHeader colKey="delivered_at">Delivered</SortableHeader>
                      <SortableHeader colKey="customer_name">Customer</SortableHeader>
                      {isAdmin && (
                        <SortableHeader colKey="branch_name">Branch</SortableHeader>
                      )}
                      <SortableHeader colKey="delivery_boy_name">Delivery Boy</SortableHeader>
                      <SortableHeader colKey="sku">SKU</SortableHeader>
                      <SortableHeader colKey="product_name">Product</SortableHeader>
                      <SortableHeader colKey="quantity">Qty</SortableHeader>
                      <SortableHeader colKey="mrp">MRP</SortableHeader>
                      <SortableHeader colKey="unit_price">Unit Price</SortableHeader>
                      <SortableHeader colKey="discount_percent">Disc %</SortableHeader>
                      <SortableHeader colKey="final_price">Final Price</SortableHeader>
                      <SortableHeader colKey="tax_rate_percent">Tax %</SortableHeader>
                      <SortableHeader colKey="tax_amount">Tax Amt</SortableHeader>
                      <SortableHeader colKey="cgst_amount">CGST</SortableHeader>
                      <SortableHeader colKey="sgst_amount">SGST</SortableHeader>
                      <SortableHeader colKey="igst_amount">IGST</SortableHeader>
                      <SortableHeader colKey="line_total">Line Total</SortableHeader>
                      <CTableHeaderCell>Coupon</CTableHeaderCell>
                      <SortableHeader colKey="coupon_discount">
                        Coupon Disc (Order)
                      </SortableHeader>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {!error && rows.length === 0 ? (
                      <CTableRow>
                        <CTableDataCell
                          colSpan={colCount}
                          className="text-center text-muted py-4"
                        >
                          No records found for this range.
                        </CTableDataCell>
                      </CTableRow>
                    ) : (
                      rows.map((r, i) => (
                        <CTableRow key={`${r.order_id}-${r.sku}-${i}`}>
                          <CTableDataCell>
                            {(meta.current_page - 1) * perPage + i + 1}
                          </CTableDataCell>
                          <CTableDataCell>#{r.order_number}</CTableDataCell>
                          <CTableDataCell>{formatDateTime(r.delivered_at)}</CTableDataCell>
                          <CTableDataCell>{r.customer_name}</CTableDataCell>
                          {isAdmin && (
                            <CTableDataCell>{r.branch_name}</CTableDataCell>
                          )}
                          <CTableDataCell>{r.delivery_boy_name ?? '—'}</CTableDataCell>
                          <CTableDataCell>{r.sku}</CTableDataCell>
                          <CTableDataCell>{r.product_name}</CTableDataCell>
                          <CTableDataCell>{r.quantity}</CTableDataCell>
                          <CTableDataCell>
                            {r.mrp != null ? `₹${r.mrp}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.unit_price != null ? `₹${r.unit_price}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.discount_percent != null ? `${r.discount_percent}%` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.final_price != null ? `₹${r.final_price}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.tax_rate_percent != null ? `${r.tax_rate_percent}%` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.tax_amount != null ? `₹${r.tax_amount}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.cgst_amount != null ? `₹${r.cgst_amount}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.sgst_amount != null ? `₹${r.sgst_amount}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.igst_amount != null ? `₹${r.igst_amount}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {r.line_total != null ? `₹${r.line_total}` : '—'}
                          </CTableDataCell>
                          <CTableDataCell>{r.coupon_code ?? '—'}</CTableDataCell>
                          <CTableDataCell>
                            {r.coupon_discount != null ? `₹${r.coupon_discount}` : '—'}
                          </CTableDataCell>
                        </CTableRow>
                      ))
                    )}
                  </CTableBody>
                </CTable>
              </div>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default DeliveredOrdersProductWiseReport