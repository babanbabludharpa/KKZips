import { useEffect, useMemo, useState, useRef } from 'react'
import {
  CCard, CCardBody, CFormLabel, CFormInput, CFormSelect,
  CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody,
  CTableDataCell, CAlert, CBadge, CSpinner, CModal, CModalHeader,
  CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import { useNavigate } from 'react-router-dom'
import { subscriptionApi } from '../../api/subscriptionApi'
import api from '../../api/api'

// ── Date helpers ──────────────────────────────────────────────────
const iso = (d) => {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}
const parseIso = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d) }
const dayOnly = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate())
const diffDays = (a, b) => Math.round((dayOnly(a) - dayOnly(b)) / 86400000)
const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const WEEKDAYS = [
  { value: 0, label: 'Sun' }, { value: 1, label: 'Mon' }, { value: 2, label: 'Tue' },
  { value: 3, label: 'Wed' }, { value: 4, label: 'Thu' }, { value: 5, label: 'Fri' },
  { value: 6, label: 'Sat' },
]
const distanceKm = (lat1, lon1, lat2, lon2) => {
  if ([lat1, lon1, lat2, lon2].some((v) => v === null || v === undefined || Number.isNaN(Number(v)))) return null
  const R = 6371, toRad = (v) => (v * Math.PI) / 180
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

function describeApiError(err) {
  const status = err?.response?.status
  if (!err?.response) return 'Network error — check your connection.'
  if (status === 401) return 'Session expired. Please log in again.'
  if (status === 403) return "You don't have permission to do this."
  if (status === 419) return 'Session expired. Please refresh and log in again.'
  if (status === 422) {
    const errors = err.response.data?.errors
    if (errors) return Object.values(errors).flat().join(' ')
    return err.response.data?.message ?? 'Invalid request.'
  }
  if (status >= 500) return 'Server error. Try again in a moment.'
  return err.response.data?.message ?? `Request failed (${status}).`
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

// ★ Whether a blocked-date entry applies to a given slot.
const blockedAppliesToSlot = (block, slotId) => {
  if (!block) return false
  if (block.all_slots) return true
  if (!slotId) return false
  return Array.isArray(block.slot_ids) && block.slot_ids.includes(Number(slotId))
}

// ★ Expand an item's schedule into the concrete dates it will generate.
// Excludes dates the admin explicitly removed via the calendar (excludedDates).
const expandItemPattern = (item, startDateStr, endDateStr) => {
  if (!startDateStr) return []
  if (item.schedule_type === 'custom_dates') {
    return (item.schedule_dates || []).filter(
      (d) => d >= startDateStr && (!endDateStr || d <= endDateStr),
    )
  }
  const start = parseIso(startDateStr)
  const end = endDateStr ? parseIso(endDateStr) : new Date(start.getTime() + 120 * 86400000)
  const out = []
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const key = iso(d)
    if (item.excludedDates?.includes(key)) continue
    let match = false
    switch (item.schedule_type) {
      case 'daily':       match = true; break
      case 'alternate':   match = diffDays(d, start) % 2 === 0; break
      case 'weekly':      match = item.schedule_days.length === 1 && d.getDay() === item.schedule_days[0]; break
      case 'custom_days': match = item.schedule_days.includes(d.getDay()); break
    }
    if (match) out.push(key)
  }
  return out
}

const emptyItem = () => ({
  product: null,
  variant: null,
  product_variant_id: '',
  default_qty: 1,
  slot_id: '',
  schedule_type: 'daily',
  schedule_days: [],
  schedule_dates: [],
  excludedDates: [],
  focusedMonth: new Date(),
})

// ── Debounced async search ───────────────────────────────────────
function useDebouncedSearch(fetcher, delay = 350) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [error, setError] = useState(null)
  const timer = useRef(null)

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current)
    if (!query || query.length < 2) { setResults([]); setError(null); setOpen(false); return }
    timer.current = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await fetcher(query)
        setResults(res)
        setError(null)
        setOpen(true)
      } catch (err) {
        setResults([])
        setError(describeApiError(err))
        setOpen(true)
      } finally {
        setLoading(false)
      }
    }, delay)
    return () => clearTimeout(timer.current)
  }, [query])

  return { query, setQuery, results, loading, open, setOpen, error }
}

function CustomerPicker({ selected, onSelect }) {
  const search = useDebouncedSearch(async (q) => {
    const res = await api.get('/masters/customers', { params: { search: q, per_page: 10 } })
    return extractArray(res)
  })

  return (
    <div style={{ position: 'relative' }}>
      <CFormInput
        size="sm"
        className="filter-input"
        placeholder="Search by name, phone, or email"
        value={selected ? `${selected.name} (${selected.phone ?? selected.email})` : search.query}
        onChange={(e) => { onSelect(null); search.setQuery(e.target.value) }}
        onFocus={() => (search.results.length || search.error) && search.setOpen(true)}
      />
      {search.loading && <CSpinner size="sm" style={{ position: 'absolute', right: 10, top: 8 }} />}
      {search.open && !selected && (
        <div className="filter-dropdown" style={{ maxHeight: 260, minWidth: '100%' }}>
          {search.error ? (
            <div className="dropdown-item-text small text-danger">{search.error}</div>
          ) : search.results.length === 0 ? (
            <div className="dropdown-item-text small text-muted">No customers found.</div>
          ) : (
            search.results.map((c) => (
              <button
                key={c.id}
                type="button"
                className="dropdown-item"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => { onSelect(c); search.setOpen(false); search.setQuery('') }}
              >
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <strong>{c.name}</strong>{' '}
                    <CBadge
                      color={c.status === 'active' ? 'success' : c.status === 'suspended' ? 'danger' : 'secondary'}
                      shape="rounded-pill"
                      className="ms-1"
                    >
                      {c.status}
                    </CBadge>
                  </div>
                  <small className="text-muted">{c.phone ?? c.email}</small>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  )
}

function AddressPicker({ customerId, selectedId, onSelect }) {
  const [addresses, setAddresses] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!customerId) { setAddresses([]); return }
    setLoading(true); setError(null)
    api.get(`/masters/customers/${customerId}/addresses`)
      .then((res) => setAddresses(extractArray(res)))
      .catch((err) => setError(describeApiError(err)))
      .finally(() => setLoading(false))
  }, [customerId])

  if (!customerId) return <div className="text-muted small">Select a customer first.</div>
  if (loading) return <CSpinner size="sm" />
  if (error) return <CAlert color="danger" className="py-2 mb-0">{error}</CAlert>
  if (addresses.length === 0) return <div className="text-muted small">This customer has no saved addresses.</div>

  return (
    <div className="d-flex flex-column gap-2">
      {addresses.map((a) => (
        <div
          key={a.id}
          onClick={() => onSelect(a)}
          className={`p-2 border rounded ${selectedId === a.id ? 'border-primary bg-light' : ''}`}
          style={{ cursor: 'pointer' }}
        >
          <div className="d-flex justify-content-between">
            <strong>{a.label}</strong>
            <div>
              {a.is_default ? <CBadge color="info" shape="rounded-pill" className="me-1">Default</CBadge> : null}
              {a.is_serviceable
                ? <CBadge color="success" shape="rounded-pill">Serviceable</CBadge>
                : <CBadge color="warning" shape="rounded-pill">Not serviceable</CBadge>}
            </div>
          </div>
          <div className="small text-muted">
            {a.address_line1}{a.address_line2 ? `, ${a.address_line2}` : ''}, {a.city}, {a.state} {a.pincode}
          </div>
          <div className="small text-muted">Branch on file: {a.branch_name ?? '— none assigned —'}</div>
        </div>
      ))}
    </div>
  )
}

function BranchResolver({ address, branches, branchId, onChange }) {
  const sorted = useMemo(() => {
    if (!address) return branches
    return [...branches]
      .map((b) => ({ ...b, _distance: distanceKm(address.latitude, address.longitude, b.latitude, b.longitude) }))
      .sort((a, b) => (a._distance ?? Infinity) - (b._distance ?? Infinity))
  }, [address, branches])

  const [overriding, setOverriding] = useState(false)

  if (!address) return null

  const currentBranch = branches.find((b) => String(b.id) === String(branchId))

  if (!overriding) {
    return (
      <div>
        {currentBranch ? (
          <div className="d-flex align-items-center gap-2">
            <CBadge color="secondary" shape="rounded-pill">
              Branch: {currentBranch.name}
            </CBadge>
            <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setOverriding(true)}>
              Change
            </CButton>
          </div>
        ) : (
          <CAlert color="warning" className="py-2 mb-1">
            This address has no branch on file. Pick one to continue.
          </CAlert>
        )}
        {!currentBranch && (
          <CFormSelect
            size="sm"
            className="filter-input"
            value={branchId}
            onChange={(e) => onChange(e.target.value)}
            style={{ maxWidth: 260 }}
          >
            <option value="">Select branch…</option>
            {sorted.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}{b._distance != null ? ` (${b._distance.toFixed(1)} km)` : ''}
              </option>
            ))}
          </CFormSelect>
        )}
      </div>
    )
  }

  return (
    <div className="d-flex align-items-center gap-2">
      <CFormSelect
        size="sm"
        className="filter-input"
        value={branchId}
        onChange={(e) => onChange(e.target.value)}
        style={{ maxWidth: 280 }}
      >
        <option value="">Select branch…</option>
        {sorted.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}{b._distance != null ? ` (${b._distance.toFixed(1)} km)` : ''}
          </option>
        ))}
      </CFormSelect>
      <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setOverriding(false)}>
        Done
      </CButton>
    </div>
  )
}

function ProductPickerModal({ visible, onClose, onSelectVariant }) {
  const [step, setStep] = useState('product')

  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [meta, setMeta] = useState({ current_page: 1, last_page: 1 })
  const [page, setPage] = useState(1)
  const [loadingProducts, setLoadingProducts] = useState(false)
  const [productError, setProductError] = useState(null)

  const [selectedProduct, setSelectedProduct] = useState(null)
  const [variants, setVariants] = useState([])
  const [loadingVariants, setLoadingVariants] = useState(false)
  const [variantError, setVariantError] = useState(null)

  useEffect(() => {
    if (!visible) return
    setStep('product')
    setSearch('')
    setCategoryFilter('')
    setSelectedProduct(null)
    setVariants([])
    setVariantError(null)
    setPage(1)
    fetchCategories()
    fetchProducts(1, '', '')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible])

  useEffect(() => {
    if (!visible || step !== 'product') return
    const t = setTimeout(() => { setPage(1); fetchProducts(1, search, categoryFilter) }, 350)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, categoryFilter])

  const fetchCategories = async () => {
    try {
      const res = await api.get('/masters/categories', { params: { per_page: 200, is_active: 1 } })
      setCategories(extractArray(res))
    } catch { /* silent */ }
  }

  const fetchProducts = async (p, s = search, c = categoryFilter) => {
    setLoadingProducts(true); setProductError(null)
    try {
      const res = await api.get('/masters/products', {
        params: { search: s || undefined, category_id: c || undefined, page: p, per_page: 20 },
      })
      setProducts(extractArray(res))
      const paginationMeta = res.data?.meta ?? res.data?.data?.meta
      if (paginationMeta) setMeta(paginationMeta)
    } catch (err) {
      setProductError(describeApiError(err))
    } finally {
      setLoadingProducts(false)
    }
  }

  const pickProduct = async (product) => {
    setSelectedProduct(product)
    setStep('variant')
    setLoadingVariants(true); setVariantError(null); setVariants([])
    try {
      const res = await api.get(`/masters/products/${product.id}`)
      const p = res.data?.data?.product
      setVariants(p?.variants ?? [])
    } catch (err) {
      setVariantError(describeApiError(err))
    } finally {
      setLoadingVariants(false)
    }
  }

  const backToProducts = () => {
    setStep('product')
    setSelectedProduct(null)
    setVariants([])
    setVariantError(null)
  }

  return (
    <CModal
      visible={visible}
      onClose={onClose}
      size="lg"
      backdrop="static"
      scrollable
      className="wallet-modal"
    >
      <CModalHeader className="wallet-modal__header">
        <CModalTitle className="wallet-modal__title">
          {step === 'product' ? 'Choose a Product' : `${selectedProduct?.name ?? ''} — Choose Variant`}
        </CModalTitle>
      </CModalHeader>
      <CModalBody className="wallet-modal__body">
        {step === 'product' ? (
          <>
            <div className="d-flex gap-2 mb-3">
              <CFormInput
                size="sm"
                className="filter-input"
                placeholder="Search products…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
              />
              <CFormSelect
                size="sm"
                className="filter-input"
                style={{ maxWidth: 220, flexShrink: 0 }}
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </CFormSelect>
            </div>

            {loadingProducts ? (
              <div className="report-shell__loading">
                <CSpinner />
              </div>
            ) : productError ? (
              <CAlert color="danger">{productError}</CAlert>
            ) : products.length === 0 ? (
              <div className="text-muted small text-center py-5">No products found.</div>
            ) : (
              <>
                <div className="report-frame">
                  <CTable hover responsive size="sm" className="admin-data-table admin-data-table--preview mb-0">
                    <CTableBody>
                      {products.map((p) => (
                        <CTableRow
                          key={p.id}
                          role="button"
                          style={{ cursor: 'pointer' }}
                          onClick={() => pickProduct(p)}
                        >
                          <CTableDataCell className="text-start">
                            <strong>{p.name}</strong>{' '}
                            <span className="text-muted small">{p.category_name ?? '—'}</span>
                          </CTableDataCell>
                          <CTableDataCell className="text-end">
                            <CBadge color={p.variants?.length ? 'info' : 'secondary'} shape="rounded-pill">
                              {p.variants?.length ?? 0} variant(s)
                            </CBadge>
                            {!p.is_active && (
                              <CBadge color="secondary" shape="rounded-pill" className="ms-1">
                                Inactive
                              </CBadge>
                            )}
                          </CTableDataCell>
                        </CTableRow>
                      ))}
                    </CTableBody>
                  </CTable>
                </div>
                {meta.last_page > 1 && (
                  <div className="d-flex justify-content-end align-items-center gap-2 pt-3">
                    <CButton
                      size="sm"
                      className="filter-btn filter-btn--ghost"
                      disabled={meta.current_page === 1}
                      onClick={() => { const np = page - 1; setPage(np); fetchProducts(np) }}
                    >
                      Prev
                    </CButton>
                    <span className="small text-muted">
                      Page {meta.current_page} of {meta.last_page}
                    </span>
                    <CButton
                      size="sm"
                      className="filter-btn filter-btn--ghost"
                      disabled={meta.current_page === meta.last_page}
                      onClick={() => { const np = page + 1; setPage(np); fetchProducts(np) }}
                    >
                      Next
                    </CButton>
                  </div>
                )}
              </>
            )}
          </>
        ) : (
          <>
            <CButton size="sm" className="filter-btn filter-btn--ghost mb-2" onClick={backToProducts}>
              ‹ Back to products
            </CButton>

            {loadingVariants ? (
              <div className="report-shell__loading">
                <CSpinner />
              </div>
            ) : variantError ? (
              <CAlert color="danger">{variantError}</CAlert>
            ) : variants.length === 0 ? (
              <div className="text-muted small text-center py-5">
                This product has no variants yet.
              </div>
            ) : (
              <div className="d-flex flex-column gap-2">
                {variants.map((v) => (
                  <div
                    key={v.id}
                    onClick={() => v.is_active && onSelectVariant(selectedProduct, v)}
                    className={`p-2 border rounded ${v.is_active ? '' : 'opacity-50'}`}
                    style={{ cursor: v.is_active ? 'pointer' : 'not-allowed' }}
                    title={v.is_active ? '' : 'Inactive — cannot be added to a subscription'}
                  >
                    <div className="d-flex align-items-start gap-2">
                      {v.image_url ? (
                        <img
                          src={v.image_url}
                          alt={v.sku}
                          style={{ width: 48, height: 48, objectFit: 'cover', borderRadius: 4, flexShrink: 0 }}
                        />
                      ) : (
                        <div
                          style={{
                            width: 48, height: 48, borderRadius: 4,
                            background: '#f1f3f5', display: 'flex',
                            alignItems: 'center', justifyContent: 'center',
                            fontSize: '0.7rem', color: '#adb5bd',
                          }}
                        >
                          No image
                        </div>
                      )}
                      <div className="flex-grow-1">
                        <div className="d-flex justify-content-between align-items-center">
                          <strong>{v.sku}</strong>
                          <div>
                            {v.is_discount_active ? (
                              <>
                                <span className="text-decoration-line-through text-muted small me-1">
                                  ₹{v.mrp}
                                </span>
                                <span className="fw-bold me-1">₹{v.final_price}</span>
                                <CBadge color="warning" shape="rounded-pill">
                                  {v.active_discount_percent}% off
                                </CBadge>
                              </>
                            ) : (
                              <span className="fw-bold">₹{v.selling_price}</span>
                            )}
                          </div>
                        </div>
                        {v.attributes?.length > 0 && (
                          <div className="text-muted small">
                            {v.attributes.map((a) => `${a.attribute_name}: ${a.value}`).join(', ')}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </CModalBody>
      <CModalFooter className="wallet-modal__footer">
        <CButton className="filter-btn filter-btn--ghost" onClick={onClose}>
          Cancel
        </CButton>
      </CModalFooter>
    </CModal>
  )
}

function ProductVariantPicker({ item, onChange }) {
  const [modalOpen, setModalOpen] = useState(false)

  const handleSelectVariant = (product, variant) => {
    onChange({ ...item, product, variant, product_variant_id: variant.id })
    setModalOpen(false)
  }

  return (
    <div>
      {item.variant ? (
        <div className="d-flex align-items-start gap-2">
          {item.variant.image_url ? (
            <img
              src={item.variant.image_url}
              alt={item.variant.sku}
              style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 4, flexShrink: 0 }}
            />
          ) : null}
          <div className="flex-grow-1">
            <div className="fw-semibold small">{item.product?.name}</div>
            <div className="text-muted" style={{ fontSize: '0.78rem' }}>
              {item.variant.sku}
              {item.variant.attributes?.length > 0
                ? ` — ${item.variant.attributes.map((a) => a.value).join(', ')}`
                : ''}
              {' — ₹'}{item.variant.selling_price}
            </div>
            <button
              type="button"
              className="btn btn-link p-0"
              style={{ fontSize: '0.78rem' }}
              onClick={() => setModalOpen(true)}
            >
              Change
            </button>
          </div>
        </div>
      ) : (
        <CButton
          size="sm"
          className="filter-btn filter-btn--ghost"
          onClick={() => setModalOpen(true)}
        >
          Choose product…
        </CButton>
      )}

      <ProductPickerModal
        visible={modalOpen}
        onClose={() => setModalOpen(false)}
        onSelectVariant={handleSelectVariant}
      />
    </div>
  )
}

function MonthCalendar({ item, startDate, onToggleDay, onMonthChange, color = '#2563EB', blockedDates, slotId }) {
  const month = item.focusedMonth
  const year = month.getFullYear(), mo = month.getMonth()
  const firstOfMonth = new Date(year, mo, 1)
  const daysInMonth = new Date(year, mo + 1, 0).getDate()
  const leadingBlanks = firstOfMonth.getDay()

  const inPattern = (d) => {
    if (!startDate) return false
    const start = dayOnly(startDate)
    if (dayOnly(d) < start) return false
    switch (item.schedule_type) {
      case 'daily': return true
      case 'alternate': return diffDays(d, start) % 2 === 0
      case 'weekly': return item.schedule_days.length === 1 && d.getDay() === item.schedule_days[0]
      case 'custom_days': return item.schedule_days.includes(d.getDay())
      default: return false
    }
  }
  const isSelected = (d) => {
    if (item.schedule_type === 'custom_dates') return item.schedule_dates.includes(iso(d))
    return inPattern(d) && !item.excludedDates.includes(iso(d))
  }
  const isRemoved = (d) => item.schedule_type !== 'custom_dates' && inPattern(d) && !isSelected(d)
  const beforeStart = (d) => !startDate || dayOnly(d) < dayOnly(startDate)

  const cells = []
  for (let i = 0; i < leadingBlanks; i++) cells.push(null)
  for (let day = 1; day <= daysInMonth; day++) cells.push(new Date(year, mo, day))

  return (
    <div className="border rounded p-2" style={{ maxWidth: 320 }}>
      <div className="d-flex justify-content-between align-items-center mb-1">
        <CButton
          size="sm"
          className="filter-btn filter-btn--ghost"
          onClick={() => onMonthChange(new Date(year, mo - 1, 1))}
        >
          ‹
        </CButton>
        <strong className="small">{MONTH_NAMES[mo]} {year}</strong>
        <CButton
          size="sm"
          className="filter-btn filter-btn--ghost"
          onClick={() => onMonthChange(new Date(year, mo + 1, 1))}
        >
          ›
        </CButton>
      </div>
      <div className="d-grid" style={{ gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
          <div key={i} className="text-center small text-muted fw-bold">{d}</div>
        ))}
        {cells.map((d, i) => {
          if (!d) return <div key={i} />
          const key = iso(d)
          const block = blockedDates?.get(key)
          const blocked = blockedAppliesToSlot(block, slotId)
          const selected = isSelected(d)
          const removed = isRemoved(d)
          const disabled = beforeStart(d) || blocked

          return (
            <div
              key={i}
              onClick={() => !disabled && onToggleDay(d)}
              className="text-center small rounded"
              title={blocked ? `Store closed: ${block.reason}` : ''}
              style={{
                cursor: disabled ? 'not-allowed' : 'pointer',
                padding: '5px 0',
                background: blocked
                  ? '#FEE2E2'
                  : selected
                  ? color
                  : removed
                  ? '#f3f4f6'
                  : 'transparent',
                color: blocked
                  ? '#B91C1C'
                  : disabled
                  ? '#ced4da'
                  : selected
                  ? '#fff'
                  : removed
                  ? '#adb5bd'
                  : '#212529',
                textDecoration: blocked || removed ? 'line-through' : 'none',
                fontWeight: selected || blocked ? 700 : 400,
                border: blocked
                  ? '1px solid #FCA5A5'
                  : removed
                  ? '1px solid #dee2e6'
                  : '1px solid transparent',
                position: 'relative',
              }}
            >
              {d.getDate()}
              {blocked && (
                <span
                  style={{
                    position: 'absolute',
                    bottom: 2,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    width: 4,
                    height: 4,
                    borderRadius: '50%',
                    background: '#DC2626',
                  }}
                />
              )}
            </div>
          )
        })}
      </div>
      {blockedDates && blockedDates.size > 0 && (
        <div
          className="small mt-2"
          style={{ color: '#991B1B', background: '#FEF2F2', padding: '6px 8px', borderRadius: 6, fontSize: '0.7rem' }}
        >
          Red days with dot = store closed. Hover for reason.
        </div>
      )}
    </div>
  )
}

function ScheduleBuilder({ item, startDate, onChange, blockedDates }) {
  const setType = (schedule_type) =>
    onChange({ ...item, schedule_type, schedule_days: [], schedule_dates: [], excludedDates: [] })

  const toggleWeekday = (day, multi) => {
    if (multi) {
      const days = item.schedule_days.includes(day)
        ? item.schedule_days.filter((d) => d !== day)
        : [...item.schedule_days, day].sort()
      onChange({ ...item, schedule_days: days, excludedDates: [] })
    } else {
      onChange({ ...item, schedule_days: [day], excludedDates: [] })
    }
  }

  const toggleDay = (d) => {
    const key = iso(d)
    if (item.schedule_type === 'custom_dates') {
      const dates = item.schedule_dates.includes(key)
        ? item.schedule_dates.filter((x) => x !== key)
        : [...item.schedule_dates, key].sort()
      onChange({ ...item, schedule_dates: dates })
    } else {
      const excluded = item.excludedDates.includes(key)
        ? item.excludedDates.filter((x) => x !== key)
        : [...item.excludedDates, key]
      onChange({ ...item, excludedDates: excluded })
    }
  }

  return (
    <div>
      <CFormSelect
        size="sm"
        className="filter-input mb-2"
        value={item.schedule_type}
        onChange={(e) => setType(e.target.value)}
      >
        <option value="daily">Daily</option>
        <option value="alternate">Alternate Days</option>
        <option value="weekly">Weekly (1 fixed day)</option>
        <option value="custom_days">Custom Days (recurring, pick weekdays)</option>
        <option value="custom_dates">Custom Dates (one-off dates only)</option>
      </CFormSelect>

      {(item.schedule_type === 'weekly' || item.schedule_type === 'custom_days') && (
        <div className="d-flex gap-1 flex-wrap mb-2">
          {WEEKDAYS.map((d) => {
            const isSelected = item.schedule_days.includes(d.value)
            return (
              <button
                key={d.value}
                type="button"
                className={
                  isSelected
                    ? 'filter-btn filter-btn--primary filter-btn--pill'
                    : 'filter-btn filter-btn--ghost filter-btn--pill'
                }
                onClick={() => toggleWeekday(d.value, item.schedule_type === 'custom_days')}
              >
                {d.label}
              </button>
            )
          })}
        </div>
      )}

      {!startDate ? (
        <small className="text-muted d-block mb-2">
          Pick a start date above to preview the calendar.
        </small>
      ) : (
        <>
          <small className="text-muted d-block mb-1">
            Tap a highlighted day to skip it
            {item.schedule_type === 'custom_dates' ? '' : ' (creates a pause for that date)'}.
          </small>
          <MonthCalendar
            item={item}
            startDate={startDate}
            onToggleDay={toggleDay}
            onMonthChange={(m) => onChange({ ...item, focusedMonth: m })}
            blockedDates={blockedDates}
            slotId={item.slot_id}
          />
        </>
      )}
    </div>
  )
}

export default function SubscriptionForm() {
  const navigate = useNavigate()

  const [customer, setCustomer] = useState(null)
  const [address, setAddress] = useState(null)
  const [branchId, setBranchId] = useState('')
  const [branches, setBranches] = useState([])
  const [branchLoadError, setBranchLoadError] = useState(null)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [items, setItems] = useState([emptyItem()])
  const [slots, setSlots] = useState([])
  const [slotLoadError, setSlotLoadError] = useState(null)
  const [errors, setErrors] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [warnings, setWarnings] = useState(null)

  // ★ Blocked dates — keyed by iso, refreshed whenever the branch changes.
  const [blockedDates, setBlockedDates] = useState(new Map())
  const [blockedLoaded, setBlockedLoaded] = useState(false)

  useEffect(() => {
    api.get('/settings/branches', { params: { per_page: 200 } })
      .then((res) => setBranches(extractArray(res)))
      .catch((err) => setBranchLoadError(describeApiError(err)))

    api.get('/settings/slots')
      .then((res) => setSlots((extractArray(res)).filter((s) => s.is_active)))
      .catch((err) => setSlotLoadError(describeApiError(err)))
  }, [])

  useEffect(() => {
    if (!branchId) {
      setBlockedDates(new Map())
      return
    }
    setBlockedLoaded(false)
    subscriptionApi.blockedDates({ branch_id: branchId, horizon_days: 120 })
      .then((res) => {
        const map = new Map()
        ;(res.data?.data ?? []).forEach((b) => map.set(b.date, b))
        setBlockedDates(map)
      })
      .catch((err) => {
        console.warn('Failed to load blocked dates', err?.response?.status, err?.response?.data)
      })
      .finally(() => setBlockedLoaded(true))
  }, [branchId])

  const selectCustomer = (c) => {
    setCustomer(c); setAddress(null); setBranchId('')
  }
  const selectAddress = (a) => {
    setAddress(a); setBranchId(a.branch_id ? String(a.branch_id) : '')
  }

  const updateItem = (index, updated) => {
    setItems((prev) => prev.map((it, i) => (i === index ? updated : it)))
  }

  const validate = () => {
    if (!customer) return 'Select a customer.'
    if (!address) return 'Select a delivery address.'
    if (!branchId) return 'Select a branch for this address.'
    if (!startDate) return 'Select a start date.'
    for (let i = 0; i < items.length; i++) {
      const it = items[i]
      if (!it.product_variant_id) return `Item ${i + 1}: choose a product and variant.`
      if (!it.slot_id) return `Item ${i + 1}: choose a delivery slot.`
      if (it.schedule_type === 'weekly' && it.schedule_days.length !== 1) return `Item ${i + 1}: pick exactly one day for Weekly.`
      if (it.schedule_type === 'custom_days' && it.schedule_days.length === 0) return `Item ${i + 1}: pick at least one day for Custom Days.`
      if (it.schedule_type === 'custom_dates' && it.schedule_dates.length === 0) return `Item ${i + 1}: add at least one date for Custom Dates.`
    }
    return null
  }

  // ★ Cross-check each item's concrete generated dates against blocked dates.
  const collectBlockedWarnings = () => {
    if (!blockedDates.size) return []
    const warningsList = []
    items.forEach((it, idx) => {
      if (!it.slot_id || !startDate) return
      const dates = expandItemPattern(it, startDate, endDate)
      dates.forEach((date) => {
        const block = blockedDates.get(date)
        if (blockedAppliesToSlot(block, it.slot_id)) {
          warningsList.push(`Item ${idx + 1} • ${date}: ${block.reason}`)
        }
      })
    })
    return warningsList
  }

  const submit = async (e) => {
    e.preventDefault()
    const validationError = validate()
    if (validationError) { setErrors({ general: [validationError] }); return }

    // ★ Pre-flight: warn the admin that some occurrences will land as 'holiday_skipped'.
    const blockedWarnings = collectBlockedWarnings()
    if (blockedWarnings.length > 0) {
      const shown = blockedWarnings.slice(0, 6).join('\n')
      const extra = blockedWarnings.length > 6 ? `\n(+${blockedWarnings.length - 6} more)` : ''
      const ok = window.confirm(
        `Some selected dates are on store leaves:\n\n${shown}${extra}\n\n` +
        `Those occurrences will be created as "skipped" with the reason stored. Continue?`
      )
      if (!ok) return
    }

    setSubmitting(true); setErrors(null); setWarnings(null)

    const payloadItems = items.map((it) => {
      const base = {
        product_variant_id: it.product_variant_id,
        default_qty: it.default_qty,
        slot_id: Number(it.slot_id),
        schedule_type: it.schedule_type,
      }
      if (it.schedule_type === 'weekly' || it.schedule_type === 'custom_days') base.schedule_days = it.schedule_days
      if (it.schedule_type === 'custom_dates') base.schedule_dates = it.schedule_dates
      return base
    })

    let created
    try {
      const { data } = await subscriptionApi.create({
        customer_id: customer.id,
        branch_id: branchId,
        delivery_address_id: address.id,
        start_date: startDate,
        end_date: endDate || undefined,
        items: payloadItems,
      })
      created = data.data
    } catch (err) {
      setErrors(err.response?.data?.errors ?? { general: [describeApiError(err)] })
      setSubmitting(false)
      return
    }

    const skippedItems = []
    const failedExclusions = []
    for (let i = 0; i < items.length; i++) {
      const draft = items[i]
      if (i >= (created.items?.length ?? 0)) {
        skippedItems.push(draft.product?.name ?? `Item ${i + 1}`)
        continue
      }
      if (!draft.excludedDates.length) continue
      const createdItemId = created.items[i].id
      for (const date of draft.excludedDates) {
        try {
          await subscriptionApi.createPause(createdItemId, {
            date_from: date, date_to: date, reason: 'Excluded at subscription creation',
          })
        } catch (err) {
          failedExclusions.push(`${date}: ${describeApiError(err)}`)
        }
      }
    }

    setSubmitting(false)

    if (skippedItems.length || failedExclusions.length) {
      setWarnings([
        ...(skippedItems.length ? [`These items weren't created: ${skippedItems.join(', ')}`] : []),
        ...(failedExclusions.length ? [`Some excluded dates couldn't be applied: ${failedExclusions.join('; ')}`] : []),
      ])
    } else {
      navigate(`/subscriptions/${created.id}`)
    }
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">New Subscription</h4>
        </div>

        <CCardBody className="wallet-modal__body">
          {errors && (
            <CAlert color="danger">
              {Object.values(errors).flat().map((msg, i) => <div key={i}>{msg}</div>)}
            </CAlert>
          )}
          {branchLoadError && (
            <CAlert color="danger">Couldn't load branches: {branchLoadError}</CAlert>
          )}
          {slotLoadError && (
            <CAlert color="danger">Couldn't load delivery slots: {slotLoadError}</CAlert>
          )}

          {blockedLoaded && blockedDates.size > 0 && (
            <CAlert color="warning" className="py-2 mb-3">
              <strong>
                Store closed on {blockedDates.size} upcoming date{blockedDates.size > 1 ? 's' : ''}:
              </strong>{' '}
              {[...blockedDates.values()].slice(0, 5).map((b, i) => (
                <span key={b.date}>
                  {b.date} ({b.reason}){i < Math.min(5, blockedDates.size) - 1 ? ', ' : ''}
                </span>
              ))}
              {blockedDates.size > 5 && <span> +{blockedDates.size - 5} more</span>}
              <div className="small text-muted mt-1">
                Occurrences on these dates will be created as <code>holiday_skipped</code> with the reason preserved.
              </div>
            </CAlert>
          )}

          {warnings && (
            <CAlert color="warning">
              {warnings.map((w, i) => <div key={i}>{w}</div>)}
              <div className="mt-2">
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--primary"
                  onClick={() => navigate(`/subscriptions`)}
                >
                  Go to Subscriptions
                </CButton>
              </div>
            </CAlert>
          )}

          <div className="row g-3 mb-3">
            <div className="col-md-4">
              <CFormLabel className="filter-label">Customer</CFormLabel>
              <CustomerPicker selected={customer} onSelect={selectCustomer} />
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">Start Date</CFormLabel>
              <CFormInput
                type="date"
                size="sm"
                className="filter-input"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">End Date (optional)</CFormLabel>
              <CFormInput
                type="date"
                size="sm"
                className="filter-input"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>

          <div className="row g-3 mb-3">
            <div className="col-md-6">
              <CFormLabel className="filter-label">Delivery Address</CFormLabel>
              <AddressPicker customerId={customer?.id} selectedId={address?.id} onSelect={selectAddress} />
            </div>
            <div className="col-md-6">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <BranchResolver address={address} branches={branches} branchId={branchId} onChange={setBranchId} />
            </div>
          </div>

          <hr />

          <h6 className="filter-label">Items</h6>
          <CTable bordered responsive className="admin-data-table mb-2">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell style={{ minWidth: 220 }}>Product / Variant</CTableHeaderCell>
                <CTableHeaderCell>Default Qty</CTableHeaderCell>
                <CTableHeaderCell>Slot</CTableHeaderCell>
                <CTableHeaderCell style={{ minWidth: 340 }}>Schedule</CTableHeaderCell>
                <CTableHeaderCell></CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {items.map((item, i) => (
                <CTableRow key={i}>
                  <CTableDataCell>
                    <ProductVariantPicker item={item} onChange={(updated) => updateItem(i, updated)} />
                  </CTableDataCell>
                  <CTableDataCell>
                    <CFormInput
                      type="number"
                      min={1}
                      size="sm"
                      className="filter-input"
                      value={item.default_qty}
                      onChange={(e) => updateItem(i, { ...item, default_qty: Number(e.target.value) })}
                    />
                  </CTableDataCell>
                  <CTableDataCell>
                    <CFormSelect
                      size="sm"
                      className="filter-input"
                      value={item.slot_id}
                      onChange={(e) => updateItem(i, { ...item, slot_id: e.target.value })}
                    >
                      <option value="">Select slot…</option>
                      {slots.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({s.start_time} – {s.end_time})
                        </option>
                      ))}
                    </CFormSelect>
                  </CTableDataCell>
                  <CTableDataCell>
                    <ScheduleBuilder
                      item={item}
                      startDate={startDate ? parseIso(startDate) : null}
                      onChange={(updated) => updateItem(i, updated)}
                      blockedDates={blockedDates}
                    />
                  </CTableDataCell>
                  <CTableDataCell>
                    <CButton
                      size="sm"
                      className="filter-btn filter-btn--danger"
                      disabled={items.length === 1}
                      onClick={() => setItems((prev) => prev.filter((_, idx) => idx !== i))}
                    >
                      Remove
                    </CButton>
                  </CTableDataCell>
                </CTableRow>
              ))}
            </CTableBody>
          </CTable>

          <CButton
            size="sm"
            className="filter-btn filter-btn--ghost"
            onClick={() => setItems((prev) => [...prev, emptyItem()])}
          >
            + Add Item
          </CButton>

          <div className="mt-4">
            <CButton
              className="filter-btn filter-btn--primary"
              disabled={submitting}
              onClick={submit}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {submitting ? 'Creating…' : 'Create Subscription'}
            </CButton>
          </div>
        </CCardBody>
      </CCard>
    </div>
  )
}