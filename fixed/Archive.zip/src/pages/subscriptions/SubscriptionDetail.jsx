import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CBadge, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CModal, CModalHeader,
  CModalTitle, CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CAlert, CSpinner,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWallet } from '@coreui/icons'
import { subscriptionApi, invoiceApi } from '../../api/subscriptionApi'
import { formatDate } from '../../utils/formatters'
import WalletModal from '../../components/WalletModal'

const STATUS_BADGE = {
  active: 'success',
  paused: 'warning',
  cancelled: 'danger',
  expired: 'secondary',
}

export default function SubscriptionDetail() {
  const { id } = useParams()
  const navigate = useNavigate()

  const [subscription, setSubscription] = useState(null)
  const [modal, setModal] = useState(null)
  const [modalForm, setModalForm] = useState({ date_from: '', date_to: '', qty: '', reason: '' })
  const [invoiceModal, setInvoiceModal] = useState(false)
  const [invoiceForm, setInvoiceForm] = useState({
    start_date: '', end_date: '', manual_adjustment_amount: '', manual_adjustment_reason: '',
  })
  const [preview, setPreview] = useState(null)
  const [previewLoading, setPreviewLoading] = useState(false)
  const [previewError, setPreviewError] = useState(null)
  const [error, setError] = useState(null)
  const [walletOpen, setWalletOpen] = useState(false)

  const load = async () => {
    const { data } = await subscriptionApi.show(id)
    setSubscription(data.data)
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const openModal = (type, itemId) => {
    setModal({ type, itemId })
    setModalForm({ date_from: '', date_to: '', qty: '', reason: '' })
    setError(null)
  }

  const submitModal = async () => {
    try {
      if (modal.type === 'pause') {
        await subscriptionApi.createPause(modal.itemId, {
          date_from: modalForm.date_from,
          date_to: modalForm.date_to,
          reason: modalForm.reason,
        })
      } else {
        await subscriptionApi.createQtyOverride(modal.itemId, {
          date_from: modalForm.date_from,
          date_to: modalForm.date_to,
          qty: Number(modalForm.qty),
          reason: modalForm.reason,
        })
      }
      setModal(null)
      load()
    } catch (err) {
      setError(err.response?.data?.errors ?? err.response?.data?.message ?? 'Something went wrong.')
    }
  }

  const cancelSubscription = async () => {
    if (!window.confirm('Cancel this subscription and all its items?')) return
    setError(null)
    try {
      await subscriptionApi.cancel(id)
      load()
    } catch (err) {
      setError(err.response?.data?.errors ?? err.response?.data?.message ?? 'Failed to cancel subscription.')
    }
  }

  const pauseSubscription = async () => {
    const reason = window.prompt('Reason for pausing (optional):') ?? undefined
    setError(null)
    try {
      await subscriptionApi.pause(id, reason)
      load()
    } catch (err) {
      setError(err.response?.data?.errors ?? err.response?.data?.message ?? 'Failed to pause subscription.')
    }
  }

  const resumeSubscription = async () => {
    setError(null)
    try {
      await subscriptionApi.resume(id)
      load()
    } catch (err) {
      setError(err.response?.data?.errors ?? err.response?.data?.message ?? 'Failed to resume subscription.')
    }
  }

  const openInvoiceModal = () => {
    const nextStart = subscription.last_billed_occurrence_date
      ? new Date(new Date(subscription.last_billed_occurrence_date).getTime() + 86400000)
          .toISOString()
          .slice(0, 10)
      : subscription.start_date
    setInvoiceForm({
      start_date: nextStart,
      end_date: '',
      manual_adjustment_amount: '',
      manual_adjustment_reason: '',
    })
    setPreview(null)
    setPreviewError(null)
    setInvoiceModal(true)
    setError(null)
  }

  const handleEndDateChange = async (e) => {
    const endDate = e.target.value
    setInvoiceForm((f) => ({ ...f, end_date: endDate }))
    setPreview(null)
    setPreviewError(null)
    if (!endDate) return

    setPreviewLoading(true)
    try {
      const { data } = await invoiceApi.preview(subscription.customer_id, {
        branch_id: subscription.branch_id,
        start_date: invoiceForm.start_date,
        end_date: endDate,
      })
      setPreview(data.data)
    } catch (err) {
      setPreviewError(err.response?.data?.message ?? 'Could not compute preview for this range.')
    } finally {
      setPreviewLoading(false)
    }
  }

  const generateInvoice = async () => {
    setError(null)
    try {
      const { data } = await invoiceApi.generate(subscription.customer_id, {
        branch_id: subscription.branch_id,
        start_date: invoiceForm.start_date,
        end_date: invoiceForm.end_date,
        manual_adjustment_amount: invoiceForm.manual_adjustment_amount || undefined,
        manual_adjustment_reason: invoiceForm.manual_adjustment_reason || undefined,
      })
      navigate(`/subscriptions/invoices/${data.data.id}`)
    } catch (err) {
      setError(err.response?.data?.message ?? 'No unbilled delivered occurrences found for this customer.')
    }
  }

  const errorText = (e) => (typeof e === 'string' ? e : Object.values(e).flat().join(', '))

  if (!subscription) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading subscription...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  const statusBadgeColor = STATUS_BADGE[subscription.status] ?? 'secondary'

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">
              {subscription.customer_name}{' '}
              <CBadge color={statusBadgeColor} shape="rounded-pill">
                {subscription.status}
              </CBadge>
            </h4>
            <div className="report-shell__price-summary">
              <span className="text-muted" style={{ fontSize: '0.85rem' }}>
                {subscription.branch_name}
              </span>
            </div>
          </div>
          <div className="d-flex gap-2 flex-wrap">
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={() => setWalletOpen(true)}
            >
              <CIcon icon={cilWallet} className="me-1" />
              Wallet
            </CButton>

            {subscription.status === 'active' && (
              <>
                <CButton
                  size="sm"
                  className="report-shell__export"
                  onClick={openInvoiceModal}
                >
                  Generate Invoice
                </CButton>
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--ghost"
                  onClick={pauseSubscription}
                >
                  Pause Subscription
                </CButton>
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--danger"
                  onClick={cancelSubscription}
                >
                  Cancel Subscription
                </CButton>
              </>
            )}

            {subscription.status === 'paused' && (
              <>
                <CButton
                  size="sm"
                  className="report-shell__export"
                  onClick={resumeSubscription}
                >
                  Resume Subscription
                </CButton>
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--danger"
                  onClick={cancelSubscription}
                >
                  Cancel Subscription
                </CButton>
              </>
            )}
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          </div>
        )}

        {/* ==================== SUMMARY ==================== */}
        <div className="report-shell__filters" style={{ paddingTop: '0.75rem', paddingBottom: '0.75rem' }}>
          <div className="filter-field">
            <span className="filter-label">Last Invoiced Through</span>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--rep-title)' }}>
              {subscription.last_billed_occurrence_date
                ? formatDate(subscription.last_billed_occurrence_date)
                : 'Never billed'}
            </div>
          </div>
          <div className="filter-field">
            <span className="filter-label">Delivery Address</span>
            <div style={{ fontSize: '0.88rem', color: 'var(--rep-text)' }}>
              {subscription.delivery_address?.address_line1}, {subscription.delivery_address?.city}
            </div>
          </div>
          <div className="filter-field">
            <span className="filter-label">Period</span>
            <div style={{ fontSize: '0.88rem', color: 'var(--rep-text)' }}>
              {formatDate(subscription.start_date)}
              {subscription.end_date && ` — ${formatDate(subscription.end_date)}`}
            </div>
          </div>
        </div>

        {/* ==================== ITEMS ==================== */}
        <CCardBody className="p-0">
          <CTable hover responsive bordered className="admin-data-table">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Product</CTableHeaderCell>
                <CTableHeaderCell>Default Qty</CTableHeaderCell>
                <CTableHeaderCell>Slot</CTableHeaderCell>
                <CTableHeaderCell>Schedule</CTableHeaderCell>
                <CTableHeaderCell>Status</CTableHeaderCell>
                <CTableHeaderCell>Actions</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {(subscription.items?.length ?? 0) === 0 ? (
                <CTableRow>
                  <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                    No items on this subscription.
                  </CTableDataCell>
                </CTableRow>
              ) : (
                subscription.items.map((item) => (
                  <CTableRow key={item.id}>
                    <CTableDataCell>
                      {item.product_name}{' '}
                      <small className="text-muted">({item.variant_sku})</small>
                    </CTableDataCell>
                    <CTableDataCell>{item.default_qty}</CTableDataCell>
                    <CTableDataCell>
                      {item.slot
                        ? `${item.slot.name} (${item.slot.start_time?.slice(0, 5)}–${item.slot.end_time?.slice(0, 5)})`
                        : '—'}
                    </CTableDataCell>
                    <CTableDataCell>{item.schedule_type}</CTableDataCell>
                    <CTableDataCell>
                      <CBadge
                        color={item.status === 'active' ? 'success' : 'secondary'}
                        shape="rounded-pill"
                      >
                        {item.status}
                      </CBadge>
                    </CTableDataCell>
                    <CTableDataCell>
                      <div className="d-flex gap-1 justify-content-center">
                        <CButton
                          size="sm"
                          className="table-action-btn"
                          onClick={() => openModal('pause', item.id)}
                        >
                          Pause
                        </CButton>
                        <CButton
                          size="sm"
                          className="table-action-btn"
                          onClick={() => openModal('qty_override', item.id)}
                        >
                          Change Qty
                        </CButton>
                      </div>
                    </CTableDataCell>
                  </CTableRow>
                ))
              )}
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>

      {/* ==================== PAUSE / QTY OVERRIDE MODAL ==================== */}
      <CModal
        visible={!!modal}
        onClose={() => setModal(null)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {modal?.type === 'pause' ? 'Pause Item' : 'Change Quantity'}
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {error && (
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          )}
          <CForm>
            <div className="mb-3">
              <CFormLabel className="filter-label">From</CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={modalForm.date_from}
                onChange={(e) => setModalForm({ ...modalForm, date_from: e.target.value })}
              />
            </div>
            <div className="mb-3">
              <CFormLabel className="filter-label">To</CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={modalForm.date_to}
                onChange={(e) => setModalForm({ ...modalForm, date_to: e.target.value })}
              />
            </div>
            {modal?.type === 'qty_override' && (
              <div className="mb-3">
                <CFormLabel className="filter-label">Quantity</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  min={0}
                  value={modalForm.qty}
                  onChange={(e) => setModalForm({ ...modalForm, qty: e.target.value })}
                />
              </div>
            )}
            <div className="mb-3">
              <CFormLabel className="filter-label">Reason</CFormLabel>
              <CFormInput
                className="filter-input"
                value={modalForm.reason}
                onChange={(e) => setModalForm({ ...modalForm, reason: e.target.value })}
              />
            </div>
          </CForm>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setModal(null)}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitModal}
          >
            Save
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== GENERATE INVOICE MODAL ==================== */}
      <CModal
        visible={invoiceModal}
        onClose={() => setInvoiceModal(false)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Generate Invoice</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {error && (
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          )}
          <CAlert color="info" className="py-2 small">
            Pulls every delivered, unbilled occurrence for this customer across ALL
            their subscriptions in this branch, within the selected range.
          </CAlert>
          <CForm>
            <div className="mb-3">
              <CFormLabel className="filter-label">Billing from</CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={invoiceForm.start_date}
                disabled
              />
            </div>
            <div className="mb-3">
              <CFormLabel className="filter-label">Bill up to (inclusive)</CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={invoiceForm.end_date}
                min={invoiceForm.start_date}
                onChange={handleEndDateChange}
              />
            </div>

            {previewLoading && (
              <div className="mb-2">
                <CSpinner size="sm" className="me-2" />
                Calculating…
              </div>
            )}
            {previewError && (
              <CAlert color="warning" className="py-2 small">
                {previewError}
              </CAlert>
            )}
            {preview && (
              <div className="report-help-box mb-3">
                <div className="d-flex justify-content-between">
                  <span>Occurrences</span>
                  <strong>{preview.occurrence_count}</strong>
                </div>
                <div className="d-flex justify-content-between">
                  <span>Tax</span>
                  <strong>₹{preview.tax_total}</strong>
                </div>
                <div className="d-flex justify-content-between">
                  <span>Total</span>
                  <strong>₹{preview.total}</strong>
                </div>
              </div>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Manual Adjustment (₹, optional)
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                min={0}
                max={preview?.total}
                disabled={!preview}
                value={invoiceForm.manual_adjustment_amount}
                onChange={(e) =>
                  setInvoiceForm({ ...invoiceForm, manual_adjustment_amount: e.target.value })
                }
              />
            </div>
            {invoiceForm.manual_adjustment_amount && (
              <div className="mb-3">
                <CFormLabel className="filter-label">Adjustment Reason</CFormLabel>
                <CFormInput
                  className="filter-input"
                  value={invoiceForm.manual_adjustment_reason}
                  onChange={(e) =>
                    setInvoiceForm({ ...invoiceForm, manual_adjustment_reason: e.target.value })
                  }
                  required
                />
              </div>
            )}
          </CForm>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setInvoiceModal(false)}
          >
            Close
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={generateInvoice}
            disabled={!preview}
          >
            Generate
          </CButton>
        </CModalFooter>
      </CModal>

      <WalletModal
        open={walletOpen}
        customer={{ id: subscription.customer_id, name: subscription.customer_name }}
        onClose={() => setWalletOpen(false)}
      />
    </div>
  )
}