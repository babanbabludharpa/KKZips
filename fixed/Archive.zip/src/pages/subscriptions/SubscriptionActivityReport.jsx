import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel, CBadge,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDate, formatDateTime } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)

const EVENT_COLORS = {
  paused: 'warning',
  resumed: 'success',
  qty_changed: 'info',
  created: 'primary',
  cancelled: 'dark',
  invoice_generated: 'secondary',
  invoice_cancelled: 'danger',
  payment_recorded: 'success',
}

const ACTOR_COLORS = { customer: 'info', admin: 'primary', system: 'secondary' }

const prettyLabel = (v) => String(v ?? '').replace(/_/g, ' ')

const SORT_KEY_MAP = {
  created_at:      'created_at',
  customer_name:   'customer_name',
  branch_name:     'branch_name',
  product_name:    'product_name',
  event_type:      'event_type',
  actor_type:      'actor_type',
  occurrence_date: 'occurrence_date',
}

const SubscriptionActivityReport = () => {
  const authRole = useAuthStore((s) => s.role)

  // ★ HO users (admin, superadmin, staff_headoffice) can filter by branch.
  //   Everyone else is branch-bound — the backend forces branch_id.
  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const [rows, setRows] = useState([])
  const [branches, setBranches] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    date_from: today,
    date_to: today,
    event_type: '',
    actor_type: '',
    branch_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  // ★ Branches — only fetched for HO users.
  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      const all = Array.isArray(d) ? d : (d?.data ?? [])
      setBranches(all)
    } catch { /* silent */ }
  }

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }

    if (useFilters.date_from) params.date_from = useFilters.date_from
    if (useFilters.date_to) params.date_to = useFilters.date_to
    if (useFilters.event_type) params.event_type = useFilters.event_type
    if (useFilters.actor_type) params.actor_type = useFilters.actor_type
    // ★ Only HO users send branch_id. Non-HO users' branch is forced by backend.
    if (isHeadOffice && useFilters.branch_id) {
      params.branch_id = useFilters.branch_id
    }

    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }

    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/subscription-activity', { params })

      if (mySeq !== requestSeq.current) return

      const dataArray = Array.isArray(res.data?.data) ? res.data.data : []
      const paginationMeta = res.data?.meta ?? {}

      setRows(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load activity report.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => { fetchBranches() }, [isHeadOffice])

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return

    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleApply = () => {
    if (
      filters.date_from &&
      filters.date_to &&
      filters.date_from > filters.date_to
    ) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleClear = () => {
    const empty = {
      date_from: today,
      date_to: today,
      event_type: '',
      actor_type: '',
      branch_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({
      page: 1,
      filtersOverride: empty,
      sortKeyOverride: null,
      sortDirOverride: 'desc',
    })
  }

  const handleExport = async () => {
    setExporting(true)
    setError(null)
    try {
      const params = {
        ...appliedFilters,
        export: 'csv',
        ...buildParams(appliedFilters, perPage, sortKey, sortDir),
      }
      delete params.per_page
      // ★ Only HO users send branch_id in export too.
      if (!isHeadOffice) delete params.branch_id

      const res = await api.get('/reports/subscription-activity', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `subscription_activity_${appliedFilters.date_from}_to_${appliedFilters.date_to}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'

    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">
            Subscription Activity Report
          </h4>
          <CButton
            size="sm"
            className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">From</CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.date_from}
              onChange={(e) =>
                setFilters((f) => ({ ...f, date_from: e.target.value }))
              }
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">To</CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.date_to}
              onChange={(e) =>
                setFilters((f) => ({ ...f, date_to: e.target.value }))
              }
            />
          </div>

          {/* ★ Branch — HO only */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.branch_id}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, branch_id: e.target.value }))
                }
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Event</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.event_type}
              onChange={(e) =>
                setFilters((f) => ({ ...f, event_type: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="paused">Paused</option>
              <option value="resumed">Resumed</option>
              <option value="qty_changed">Qty Changed</option>
              <option value="created">Created</option>
              <option value="cancelled">Cancelled</option>
              <option value="invoice_generated">Invoice Generated</option>
              <option value="invoice_cancelled">Invoice Cancelled</option>
              <option value="payment_recorded">Payment Recorded</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Actor</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.actor_type}
              onChange={(e) =>
                setFilters((f) => ({ ...f, actor_type: e.target.value }))
              }
            >
              <option value="">All</option>
              <option value="customer">Customer</option>
              <option value="admin">Admin</option>
              <option value="system">System</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleApply}
              disabled={loading}
            >
              Apply
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading activity...
              </div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Date/Time</SortableHeader>
                    <SortableHeader colKey="customer_name">Customer</SortableHeader>
                    <SortableHeader colKey="branch_name">Branch</SortableHeader>
                    <SortableHeader colKey="product_name">Product</SortableHeader>
                    <SortableHeader colKey="event_type">Event</SortableHeader>
                    <SortableHeader colKey="actor_type">Actor</SortableHeader>
                    <SortableHeader colKey="occurrence_date">Occurrence Date</SortableHeader>
                    <CTableHeaderCell>Description</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell
                        colSpan={9}
                        className="text-center text-muted py-4"
                      >
                        No activity for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((row, idx) => (
                      <CTableRow key={row.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + idx + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          {formatDateTime(row.created_at)}
                        </CTableDataCell>
                        <CTableDataCell>{row.customer_name}</CTableDataCell>
                        <CTableDataCell>{row.branch_name}</CTableDataCell>
                        <CTableDataCell>{row.product_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={EVENT_COLORS[row.event_type] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {prettyLabel(row.event_type)}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={ACTOR_COLORS[row.actor_type] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {prettyLabel(row.actor_type)}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {formatDate(row.occurrence_date) ?? '—'}
                        </CTableDataCell>
                        <CTableDataCell>{row.description}</CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default SubscriptionActivityReport