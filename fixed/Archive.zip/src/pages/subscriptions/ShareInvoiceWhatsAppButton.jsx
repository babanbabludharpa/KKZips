import React, { useState } from 'react'
import { CButton, CSpinner } from '@coreui/react'
import api from '../../api/api'

// ASSUMPTIONS confirmed:
// 1. customers.phone stores 10-digit numbers WITHOUT country code
//    (confirmed). Prefixed with 91 below — safe default given this is an
//    India-only deployment (GST/CGST/SGST/IGST throughout the codebase).
//    If this tenant ever serves non-Indian customers, COUNTRY_CODE needs
//    to become per-customer/per-tenant configurable instead of a constant.
// 2. wa.me links can only pre-fill TEXT, not attach the PDF itself — this
//    button sends a message with a link to the signed PDF URL, which the
//    customer opens/downloads on their own device. This is a WhatsApp
//    click-to-chat platform limitation, not something this code can work
//    around.
const COUNTRY_CODE = '91'

export default function ShareInvoiceWhatsAppButton({ invoiceId, customerName, customerPhone, invoiceTotal }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const shareOnWhatsApp = async () => {
    if (!customerPhone) {
      setError('No phone number on file for this customer.')
      return
    }

    setLoading(true)
    setError(null)

    try {
      const { data } = await api.get(`/invoices/${invoiceId}/pdf-link`)
      const pdfUrl = data.data.url

      const digitsOnly = String(customerPhone).replace(/\D/g, '')

      if (digitsOnly.length !== 10) {
        setError(`Customer phone number looks invalid (${digitsOnly.length} digits, expected 10). Check the customer record before sharing.`)
        setLoading(false)
        return
      }

      const fullNumber = `${COUNTRY_CODE}${digitsOnly}`

      const message =
        `Hi ${customerName}, your invoice (₹${invoiceTotal}) is ready. ` +
        `You can view/download it here: ${pdfUrl}\n\n` +
        `This link is valid for 7 days.`

      const waUrl = `https://wa.me/${fullNumber}?text=${encodeURIComponent(message)}`
      window.open(waUrl, '_blank')
    } catch (err) {
      setError(err.response?.data?.message ?? 'Could not generate invoice link.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <CButton size="sm" color="success" variant="outline" onClick={shareOnWhatsApp} disabled={loading}>
        {loading ? <CSpinner size="sm" /> : 'Share on WhatsApp'}
      </CButton>
      {error && <div className="text-danger small mt-1">{error}</div>}
    </>
  )
}
