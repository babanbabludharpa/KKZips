import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import {
  CCard, CCardBody, CBadge, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CModal, CModalHeader,
  CModalTitle, CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect, CAlert, CSpinner,
} from '@coreui/react'
import { invoiceApi } from '../../api/subscriptionApi'
import { handleDownloadInvoicePdf, handlePrintInvoicePdf } from './InvoicePdfActions'
import ShareInvoiceWhatsAppButton from './ShareInvoiceWhatsAppButton'
import { formatDate } from '../../utils/formatters'

const STATUS_COLORS = {
  draft: 'secondary',
  generated: 'info',
  partially_paid: 'warning',
  paid: 'success',
  overdue: 'danger',
  cancelled: 'dark',
}

export default function InvoiceDetail() {
  const { id } = useParams()
  const [invoice, setInvoice] = useState(null)
  const [paymentModal, setPaymentModal] = useState(false)
  const [cancelModal, setCancelModal] = useState(false)
  const [paymentForm, setPaymentForm] = useState({ amount: '', payment_mode: 'cash', note: '' })
  const [cancelReason, setCancelReason] = useState('')
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const load = async () => {
    const { data } = await invoiceApi.show(id)
    setInvoice(data.data)
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const recordPayment = async () => {
    setError(null)
    setSubmitting(true)
    try {
      await invoiceApi.recordPayment(id, {
        ...paymentForm,
        amount: Number(paymentForm.amount),
      })
      setPaymentModal(false)
      setPaymentForm({ amount: '', payment_mode: 'cash', note: '' })
      load()
    } catch (err) {
      setError(err.response?.data?.errors ?? err.response?.data?.message ?? 'Payment failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const cancelInvoice = async () => {
    setError(null)
    setSubmitting(true)
    try {
      await invoiceApi.cancel(id, cancelReason)
      setCancelModal(false)
      load()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Cancellation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const errorText = (e) => (typeof e === 'string' ? e : Object.values(e).flat().join(', '))

  if (!invoice) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading invoice...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  const canRecordPayment = !['paid', 'cancelled'].includes(invoice.status)
  const canCancel = invoice.status !== 'cancelled'

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">
              Invoice #{invoice.id} — {invoice.customer_name}{' '}
              <CBadge color={STATUS_COLORS[invoice.status] ?? 'secondary'} shape="rounded-pill">
                {invoice.status}
              </CBadge>
            </h4>
            <div className="report-shell__price-summary">
              <span>
                <strong>Period</strong>{' '}
                <span className="value">
                  {formatDate(invoice.period_start)} – {formatDate(invoice.period_end)}
                </span>
              </span>
              <span className="sep">·</span>
              <span>
                <strong>Total</strong>{' '}
                <span className="value">₹{invoice.total}</span>
              </span>
              <span className="sep">·</span>
              <span>
                <strong>Paid</strong>{' '}
                <span className="value">₹{invoice.amount_paid}</span>
              </span>
              <span className="sep">·</span>
              <span>
                <strong>Due</strong>{' '}
                <span className="value--primary">₹{invoice.amount_due}</span>
              </span>
            </div>
          </div>

          <div className="d-flex gap-2 flex-wrap">
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={() => handleDownloadInvoicePdf(invoice.id, setError)}
            >
              Download PDF
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={() => handlePrintInvoicePdf(invoice.id, setError)}
            >
              Print
            </CButton>
            <ShareInvoiceWhatsAppButton
              invoiceId={invoice.id}
              customerName={invoice.customer_name}
              customerPhone={invoice.customer_phone}
              invoiceTotal={invoice.total}
            />
            {canRecordPayment && (
              <CButton
                size="sm"
                className="report-shell__export"
                onClick={() => setPaymentModal(true)}
              >
                Record Payment
              </CButton>
            )}
            {canCancel && (
              <CButton
                size="sm"
                className="filter-btn filter-btn--danger"
                onClick={() => setCancelModal(true)}
              >
                Cancel Invoice
              </CButton>
            )}
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          </div>
        )}

        {/* ==================== SUMMARY ==================== */}
        <div
          className="report-shell__filters"
          style={{ paddingTop: '0.75rem', paddingBottom: '0.75rem' }}
        >
          <div className="filter-field">
            <span className="filter-label">Subtotal (tax-inclusive)</span>
            <div style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--rep-title)' }}>
              ₹{invoice.subtotal}
            </div>
          </div>
          <div className="filter-field">
            <span className="filter-label">CGST</span>
            <div style={{ fontSize: '1rem', fontWeight: 600 }}>₹{invoice.cgst_total}</div>
          </div>
          <div className="filter-field">
            <span className="filter-label">SGST</span>
            <div style={{ fontSize: '1rem', fontWeight: 600 }}>₹{invoice.sgst_total}</div>
          </div>
          <div className="filter-field">
            <span className="filter-label">IGST</span>
            <div style={{ fontSize: '1rem', fontWeight: 600 }}>₹{invoice.igst_total}</div>
          </div>
          {invoice.manual_adjustment_amount > 0 && (
            <div className="filter-field">
              <span className="filter-label">Manual Adjustment</span>
              <div style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--rep-red)' }}>
                −₹{invoice.manual_adjustment_amount}
              </div>
              <small className="text-muted">{invoice.manual_adjustment_reason}</small>
            </div>
          )}
        </div>

        {invoice.status === 'cancelled' && (
          <div className="report-info-strip">
            <span>
              <strong>Cancelled:</strong> {invoice.cancellation_reason}
            </span>
          </div>
        )}

        {/* ==================== LINE ITEMS ==================== */}
        <CCardBody className="p-0">
          <div style={{ padding: '0.85rem 1.15rem 0.35rem' }}>
            <span className="filter-label">Line Items</span>
          </div>
          <div className="report-table-scroll">
            <CTable
              hover
              responsive
              bordered
              className="admin-data-table admin-data-table--wide"
            >
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Description</CTableHeaderCell>
                  <CTableHeaderCell>Qty</CTableHeaderCell>
                  <CTableHeaderCell>Unit Price</CTableHeaderCell>
                  <CTableHeaderCell>Taxable Value</CTableHeaderCell>
                  <CTableHeaderCell>Tax Type</CTableHeaderCell>
                  <CTableHeaderCell>CGST</CTableHeaderCell>
                  <CTableHeaderCell>SGST</CTableHeaderCell>
                  <CTableHeaderCell>IGST</CTableHeaderCell>
                  <CTableHeaderCell>Line Total</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {invoice.items?.map((item) => (
                  <CTableRow key={item.id}>
                    <CTableDataCell>{item.description}</CTableDataCell>
                    <CTableDataCell>{item.qty}</CTableDataCell>
                    <CTableDataCell>₹{item.unit_price}</CTableDataCell>
                    <CTableDataCell>₹{item.taxable_value}</CTableDataCell>
                    <CTableDataCell>{item.tax_type}</CTableDataCell>
                    <CTableDataCell>₹{item.cgst_amount}</CTableDataCell>
                    <CTableDataCell>₹{item.sgst_amount}</CTableDataCell>
                    <CTableDataCell>₹{item.igst_amount}</CTableDataCell>
                    <CTableDataCell>₹{item.line_total}</CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          </div>

          {/* ==================== PAYMENTS ==================== */}
          <div style={{ padding: '1.15rem 1.15rem 0.35rem' }}>
            <span className="filter-label">Payments</span>
          </div>
          <CTable hover responsive bordered className="admin-data-table">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Amount</CTableHeaderCell>
                <CTableHeaderCell>Mode</CTableHeaderCell>
                <CTableHeaderCell>Received At</CTableHeaderCell>
                <CTableHeaderCell>Note</CTableHeaderCell>
                <CTableHeaderCell></CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {invoice.payments?.length === 0 ? (
                <CTableRow>
                  <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                    No payments recorded yet.
                  </CTableDataCell>
                </CTableRow>
              ) : (
                invoice.payments?.map((p) => (
                  <CTableRow key={p.id}>
                    <CTableDataCell className={p.amount < 0 ? 'text-danger' : ''}>
                      ₹{p.amount}
                    </CTableDataCell>
                    <CTableDataCell>{p.payment_mode}</CTableDataCell>
                    <CTableDataCell>{p.received_at}</CTableDataCell>
                    <CTableDataCell>{p.note ?? '—'}</CTableDataCell>
                    <CTableDataCell>
                      {p.is_reversal && (
                        <CBadge color="dark" shape="rounded-pill">Reversal</CBadge>
                      )}
                    </CTableDataCell>
                  </CTableRow>
                ))
              )}
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>

      {/* ==================== PAYMENT MODAL ==================== */}
      <CModal
        visible={paymentModal}
        onClose={() => setPaymentModal(false)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Record Payment</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {error && (
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          )}
          <CForm>
            <div className="mb-3">
              <CFormLabel className="filter-label">Amount</CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                min={0.01}
                step={0.01}
                value={paymentForm.amount}
                onChange={(e) =>
                  setPaymentForm({ ...paymentForm, amount: e.target.value })
                }
              />
            </div>
            <div className="mb-3">
              <CFormLabel className="filter-label">Mode</CFormLabel>
              <CFormSelect
                className="filter-input"
                value={paymentForm.payment_mode}
                onChange={(e) =>
                  setPaymentForm({ ...paymentForm, payment_mode: e.target.value })
                }
              >
                <option value="cash">Cash</option>
                <option value="online">Online</option>
                <option value="upi">UPI</option>
              </CFormSelect>
            </div>
            <div className="mb-3">
              <CFormLabel className="filter-label">Note</CFormLabel>
              <CFormInput
                className="filter-input"
                value={paymentForm.note}
                onChange={(e) =>
                  setPaymentForm({ ...paymentForm, note: e.target.value })
                }
              />
            </div>
          </CForm>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setPaymentModal(false)}
            disabled={submitting}
          >
            Close
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={recordPayment}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Save Payment
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== CANCEL MODAL ==================== */}
      <CModal
        visible={cancelModal}
        onClose={() => setCancelModal(false)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Cancel Invoice</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {error && (
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {errorText(error)}
            </CAlert>
          )}
          <CAlert color="warning">
            This reverses any payments already collected and un-bills all
            occurrences so they can be re-invoiced. This cannot be undone.
          </CAlert>
          <CFormLabel className="filter-label">Reason</CFormLabel>
          <CFormInput
            className="filter-input"
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            required
          />
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setCancelModal(false)}
            disabled={submitting}
          >
            Close
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            disabled={!cancelReason || submitting}
            onClick={cancelInvoice}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            Confirm Cancellation
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}