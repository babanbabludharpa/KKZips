// Add to the invoice detail page's action row (next to Record Payment /
// Cancel Invoice, per the screenshot). Not yet wired into an actual file
// -- InvoiceDetail.jsx (or whatever renders /subscriptions/invoices/:id)
// hasn't been shared, so this is the logic to paste into it, not a
// complete standalone component.
//
// Both handlers hit the SAME authenticated backend route
// (GET /invoices/{invoice}/pdf) added to InvoiceController above --
// distinct from the public signed route used by ShareInvoiceWhatsAppButton.
// Can't use a plain <a href> here: browser navigation doesn't carry the
// axios instance's auth header, so this has to fetch as a blob first.

import api from '../../api/api'

async function fetchInvoicePdfBlob(invoiceId) {
  try {
    const response = await api.get(`/invoices/${invoiceId}/pdf`, {
      responseType: 'blob',
    })
    return new Blob([response.data], { type: 'application/pdf' })
  } catch (err) {
    // With responseType: 'blob', an error response body (JSON) also comes
    // back as a Blob, not parsed JSON -- err.response.data.message is
    // undefined even though the server sent a real error message. Read it
    // back out as text so the actual backend error surfaces instead of a
    // generic "could not open" string.
    if (err.response?.data instanceof Blob) {
      try {
        const text = await err.response.data.text()
        const parsed = JSON.parse(text)
        throw new Error(parsed.message || text || `Server returned ${err.response.status}`)
      } catch (parseErr) {
        throw new Error(`Server returned ${err.response?.status ?? 'an error'} while generating the PDF.`)
      }
    }
    throw err
  }
}

// "Download PDF" button onClick handler
export async function handleDownloadInvoicePdf(invoiceId, setError) {
  try {
    const blob = await fetchInvoicePdfBlob(invoiceId)
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `invoice-${invoiceId}.pdf`
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)
  } catch (err) {
    console.error('Invoice PDF download failed:', err)
    setError?.(err.message || 'Could not download invoice PDF.')
  }
}

// "Print" button onClick handler — opens the PDF in a new tab using the
// browser's native PDF viewer, which has its own print control. Simpler
// and more reliable across browsers than trying to trigger window.print()
// on injected content directly.
export async function handlePrintInvoicePdf(invoiceId, setError) {
  try {
    const blob = await fetchInvoicePdfBlob(invoiceId)
    const url = window.URL.createObjectURL(blob)
    const printWindow = window.open(url, '_blank')
    if (!printWindow) {
      setError?.('Pop-up blocked — allow pop-ups for this site to print.')
    }
  } catch (err) {
    console.error('Invoice PDF print failed:', err)
    setError?.(err.message || 'Could not open invoice for printing.')
  }
}

// "Print Selected" — combined PDF, one page-break per invoice, one print
// dialog for all of them instead of N separate tabs.
export async function handleBulkPrintInvoices(invoiceIds, setError) {
  if (!invoiceIds || invoiceIds.length === 0) return

  try {
    const response = await api.post(
      '/invoices/bulk-pdf',
      { invoice_ids: invoiceIds },
      { responseType: 'blob' }
    )
    const blob = new Blob([response.data], { type: 'application/pdf' })
    const url = window.URL.createObjectURL(blob)
    const printWindow = window.open(url, '_blank')
    if (!printWindow) {
      setError?.('Pop-up blocked — allow pop-ups for this site to print.')
    }
  } catch (err) {
    let message = 'Could not open selected invoices for printing.'
    if (err.response?.data instanceof Blob) {
      try {
        const text = await err.response.data.text()
        const parsed = JSON.parse(text)
        message = parsed.message || message
      } catch { /* fall through to default message */ }
    }
    console.error('Bulk invoice print failed:', err)
    setError?.(message)
  }
}

/* Example usage inside the header action row:

<CButton size="sm" color="primary" variant="outline"
  onClick={() => handleDownloadInvoicePdf(invoice.id, setError)}>
  Download PDF
</CButton>
<CButton size="sm" color="primary" variant="outline"
  onClick={() => handlePrintInvoicePdf(invoice.id, setError)}>
  Print
</CButton>
<ShareInvoiceWhatsAppButton
  invoiceId={invoice.id}
  customerName={invoice.customer_name}
  customerPhone={invoice.customer_phone}
  invoiceTotal={invoice.total}
/>

*/
