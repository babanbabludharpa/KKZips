import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilCalculator, cilLayers, cilInfo } from '@coreui/icons'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'

const tomorrow = () => {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  return d.toISOString().slice(0, 10)
}

const SubscriptionDemandReport = () => {
  const authRole = useAuthStore((s) => s.role)
  const userBranchId = useAuthStore((s) => s.user?.branch_id)

  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const [date, setDate] = useState(tomorrow())
  const [branchId, setBranchId] = useState('')
  const [zoneId, setZoneId] = useState('')
  const [slotId, setSlotId] = useState('')
  const [categoryId, setCategoryId] = useState('')

  const [branches, setBranches] = useState([])
  const [zones, setZones] = useState([])
  const [slots, setSlots] = useState([])
  const [categories, setCategories] = useState([])

  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)

  const [page, setPage] = useState(1)
  const [perPage, setPerPage] = useState(25)

  const requestSeq = useRef(0)

  // Branches (HO only)
  useEffect(() => {
    if (!isHeadOffice) return
    api.get('/settings/branches', { params: { per_page: 200 } })
      .then((res) => {
        const d = res.data?.data
        setBranches(Array.isArray(d) ? d : (d?.data ?? []))
      })
      .catch(() => setBranches([]))
  }, [isHeadOffice])

  // Zones (branch-scoped)
  useEffect(() => {
    const effectiveBranch = branchId || userBranchId
    if (!effectiveBranch) { setZones([]); return }
    api.get(`/settings/branches/${effectiveBranch}/zones`)
      .then((res) => setZones(res.data?.data?.zones || []))
      .catch(() => setZones([]))
  }, [branchId, userBranchId])

  // Slots (tenant-wide, active only)
  useEffect(() => {
    api.get('/settings/slots')
      .then((res) => {
        const all = res.data?.data || []
        setSlots(all.filter((s) => s.is_active))
      })
      .catch(() => setSlots([]))
  }, [])

  // Categories
  useEffect(() => {
    api.get('/masters/categories', { params: { per_page: 200, is_active: 1 } })
      .then((res) => {
        const d = res.data?.data
        setCategories(Array.isArray(d) ? d : (d?.data ?? []))
      })
      .catch(() => setCategories([]))
  }, [])

  const load = async () => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    setPage(1)
    try {
      const params = { date }
      if (isHeadOffice && branchId) params.branch_id = branchId
      if (zoneId) params.zone_id = zoneId
      if (slotId) params.slot_id = slotId
      if (categoryId) params.category_id = categoryId

      const { data } = await api.get('/reports/subscription-demand', { params })
      if (mySeq !== requestSeq.current) return
      setReport(data.data)
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setReport(null)
      setError(err.response?.data?.message ?? 'Failed to load demand report.')
    } finally {
      if (mySeq === requestSeq.current) setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, branchId, zoneId, slotId, categoryId])

  const rows = report?.rows ?? []
  const total = rows.length
  const totalPages = Math.max(1, Math.ceil(total / perPage))
  const rangeStart = total === 0 ? 0 : (page - 1) * perPage + 1
  const rangeEnd = total === 0 ? 0 : Math.min(page * perPage, total)
  const pageRows = rows.slice((page - 1) * perPage, page * perPage)

  const meta = {
    current_page: page,
    last_page: totalPages,
    per_page: perPage,
    total,
    from: rangeStart || null,
    to: rangeEnd || null,
  }

  const handlePageChange = (p) => {
    if (p === page || p < 1 || p > totalPages) return
    setPage(p)
  }

  const handlePerPageChange = (e) => {
    const v = Number(e?.target?.value ?? e)
    setPerPage(v)
    setPage(1)
  }

  const buildExportParams = (format) => {
    const params = { date, export: format }
    if (isHeadOffice && branchId) params.branch_id = branchId
    if (zoneId) params.zone_id = zoneId
    if (slotId) params.slot_id = slotId
    if (categoryId) params.category_id = categoryId
    return params
  }

  const handleExport = async (format) => {
    setExporting(true)
    setError(null)
    try {
      const res = await api.get('/reports/subscription-demand', {
        params: buildExportParams(format),
        responseType: 'blob',
      })
      const ext = format === 'excel' ? 'xls' : 'csv'
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `subscription_demand_${date}.${ext}`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const isProjection = report && report.source !== 'generated'

  const slotLabel = (row) => {
    if (!row.slot_name) return '—'
    if (row.slot_start_time && row.slot_end_time) {
      return `${row.slot_name} (${row.slot_start_time}–${row.slot_end_time})`
    }
    return row.slot_name
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Subscription Demand Report</h4>

          <div className="d-flex gap-2 align-items-center">
            {!loading && report && (
              <CBadge
                color={report.source === 'generated' ? 'success' : 'warning'}
                shape="rounded-pill"
                style={{ fontSize: '0.78rem', padding: '0.4em 0.9em' }}
              >
                {report.source === 'generated' ? '✓ Confirmed' : '◷ Projection'}
              </CBadge>
            )}
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={() => handleExport('csv')}
              disabled={exporting || rows.length === 0 || loading}
            >
              {exporting ? <CSpinner size="sm" className="me-2" /> : null}
              CSV
            </CButton>
            <CButton
              size="sm"
              className="report-shell__export"
              onClick={() => handleExport('excel')}
              disabled={exporting || rows.length === 0 || loading}
            >
              Excel
            </CButton>
          </div>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">Date</CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={branchId}
                onChange={(e) => {
                  setBranchId(e.target.value)
                  setZoneId('')
                }}
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Zone</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={zoneId}
              onChange={(e) => setZoneId(e.target.value)}
              disabled={isHeadOffice && !branchId}
            >
              <option value="">
                {isHeadOffice && !branchId ? 'Select branch first' : 'All Zones'}
              </option>
              {zones.map((z) => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Slot</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={slotId}
              onChange={(e) => setSlotId(e.target.value)}
            >
              <option value="">All Slots</option>
              {slots.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({String(s.start_time).slice(0, 5)}–{String(s.end_time).slice(0, 5)})
                </option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Category</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChange}
              label="Per Page"
              disabled={loading}
            />
          </div>

          {!loading && report && (
            <div className="filter-field">
              <CFormLabel className="filter-label">&nbsp;</CFormLabel>
              <div className="report-kpi report-kpi--info">
                <div className="report-kpi__icon"><CIcon icon={cilCalculator} /></div>
                <div className="report-kpi__body">
                  <div className="report-kpi__value">{report.grand_total_qty ?? 0}</div>
                  <div className="report-kpi__label">Units Needed</div>
                </div>
              </div>
            </div>
          )}

          {!loading && report && (
            <div className="filter-field">
              <CFormLabel className="filter-label">&nbsp;</CFormLabel>
              <div className="report-kpi report-kpi--neutral">
                <div className="report-kpi__icon"><CIcon icon={cilLayers} /></div>
                <div className="report-kpi__body">
                  <div className="report-kpi__value">{rows.length}</div>
                  <div className="report-kpi__label">Lines</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {isProjection && (
          <div className="report-info-strip">
            <CIcon icon={cilInfo} />
            <span>
              Occurrences for this date haven't been generated yet — numbers are provisional until the nightly job runs.
            </span>
          </div>
        )}

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading demand report...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Product</CTableHeaderCell>
                    <CTableHeaderCell>SKU</CTableHeaderCell>
                    <CTableHeaderCell>Category</CTableHeaderCell>
                    <CTableHeaderCell>Branch</CTableHeaderCell>
                    <CTableHeaderCell>Zone</CTableHeaderCell>
                    <CTableHeaderCell>Slot</CTableHeaderCell>
                    <CTableHeaderCell>Deliveries</CTableHeaderCell>
                    <CTableHeaderCell>Total Qty</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No demand for these filters.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    pageRows.map((row, idx) => (
                      <CTableRow key={`${row.variant_sku}-${row.branch_id ?? 0}-${row.zone_id ?? 0}-${row.slot_id ?? 0}-${idx}`}>
                        <CTableDataCell>{(page - 1) * perPage + idx + 1}</CTableDataCell>
                        <CTableDataCell>{row.product_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill">{row.variant_sku}</CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{row.category_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{row.branch_name}</CTableDataCell>
                        <CTableDataCell>{row.zone_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{slotLabel(row)}</CTableDataCell>
                        <CTableDataCell>{row.delivery_count}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="info" shape="rounded-pill">{row.total_qty}</CBadge>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={loading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

export default SubscriptionDemandReport