import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDate } from '../../utils/formatters'

const STATUS_COLORS = {
  active: 'success',
  paused: 'warning',
  cancelled: 'danger',
  expired: 'secondary',
  bill_pending: 'info',
}

const emptyFilters = {
  customer_id: '',
  status: '',
  branch_id: '',
  date_from: '',
  date_to: '',
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

const SubscriptionsList = () => {
  const user = useAuthStore((s) => s.user)

  const isHeadOffice = user?.branch_id === null || user?.role === 'superadmin'

  const [branches, setBranches] = useState([])
  const [filters, setFilters] = useState(emptyFilters)
  const [appliedFilters, setAppliedFilters] = useState(emptyFilters)
  const [subscriptions, setSubscriptions] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [searched, setSearched] = useState(false)

  const [customerQuery, setCustomerQuery] = useState('')
  const [customerResults, setCustomerResults] = useState([])
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  useEffect(() => {
    if (!isHeadOffice) return
    api.get('/settings/branches', { params: { per_page: 500 } })
      .then((res) => setBranches(extractArray(res)))
      .catch(() => setBranches([]))
  }, [isHeadOffice])

  useEffect(() => {
    if (!customerQuery || selectedCustomer?.name === customerQuery) {
      setCustomerResults([])
      return
    }
    const t = setTimeout(() => {
      api.get('/masters/customers', { params: { search: customerQuery, per_page: 15 } })
        .then((res) => setCustomerResults(extractArray(res)))
        .catch(() => setCustomerResults([]))
    }, 300)
    return () => clearTimeout(t)
  }, [customerQuery, selectedCustomer])

  const pickCustomer = (c) => {
    setSelectedCustomer(c)
    setCustomerQuery(c.name)
    setFilters((f) => ({ ...f, customer_id: c.id }))
    setShowCustomerDropdown(false)
  }

  const clearCustomer = () => {
    setSelectedCustomer(null)
    setCustomerQuery('')
    setFilters((f) => ({ ...f, customer_id: '' }))
    setCustomerResults([])
  }

  const hasAnyFilter = Object.values(appliedFilters).some((v) => v !== '')

  const buildParams = (useFilters, usePerPage) => {
    const params = { per_page: usePerPage }
    if (useFilters.customer_id) params.customer_id = useFilters.customer_id
    if (useFilters.status) params.status = useFilters.status
    if (isHeadOffice && useFilters.branch_id) params.branch_id = useFilters.branch_id
    if (useFilters.date_from) params.date_from = useFilters.date_from
    if (useFilters.date_to) params.date_to = useFilters.date_to
    return params
  }

  const fetchSubscriptions = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
  } = {}) => {
    const activeFilters = filtersOverride
    const anyFilter = Object.values(activeFilters).some((v) => v !== '')
    if (!anyFilter) {
      setError('Enter at least one filter to search.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    setSearched(true)

    try {
      const params = {
        page,
        ...buildParams(activeFilters, perPageOverride),
      }
      const res = await api.get('/subscriptions', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.meta ?? {}

      setSubscriptions(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setSubscriptions([])
      setError(err.response?.data?.message ?? 'Failed to load subscriptions.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const handlePageChange = (page) => {
    goToPage(page, fetchSubscriptions)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchSubscriptions)
  }

  const handleFilterChange = (key) => (e) =>
    setFilters((f) => ({ ...f, [key]: e.target.value }))

  const handleSearch = (e) => {
    e.preventDefault()
    if (
      filters.date_from &&
      filters.date_to &&
      filters.date_from > filters.date_to
    ) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchSubscriptions({ page: 1, filtersOverride: filters })
  }

  const handleClear = () => {
    setFilters(emptyFilters)
    setAppliedFilters(emptyFilters)
    setSubscriptions([])
    setSearched(false)
    setError(null)
    clearCustomer()
    updatePagination({
      current_page: 1,
      last_page: 1,
      per_page: perPage,
      total: 0,
      from: null,
      to: null,
    })
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Subscriptions</h4>
          <CButton
            size="sm"
            className="report-shell__export"
            as={Link}
            to="/subscriptions/new"
          >
            + New Subscription
          </CButton>
        </div>

        {/* ==================== FILTERS ==================== */}
        <form onSubmit={handleSearch}>
          <div className="report-shell__filters">
            <div className="filter-field filter-field--customer">
              <CFormLabel className="filter-label">Customer</CFormLabel>
              <div style={{ position: 'relative' }}>
                <CFormInput
                  size="sm"
                  className="filter-input"
                  placeholder="Name or phone"
                  value={customerQuery}
                  onChange={(e) => {
                    setCustomerQuery(e.target.value)
                    setSelectedCustomer(null)
                    setFilters((f) => ({ ...f, customer_id: '' }))
                    setShowCustomerDropdown(true)
                  }}
                  onFocus={() => setShowCustomerDropdown(true)}
                  onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 150)}
                />
                {showCustomerDropdown && customerResults.length > 0 && (
                  <div className="filter-dropdown">
                    {customerResults.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        className="dropdown-item"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => pickCustomer(c)}
                      >
                        {c.name} — {c.phone ?? 'no phone'}
                      </button>
                    ))}
                    {customerResults.length === 15 && (
                      <div className="dropdown-item-text small">
                        Keep typing to narrow results…
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Status</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={filters.status}
                onChange={handleFilterChange('status')}
              >
                <option value="">Any status</option>
                <option value="active">Active</option>
                <option value="paused">Paused</option>
                <option value="cancelled">Cancelled</option>
                <option value="expired">Expired</option>
                <option value="bill_pending">Bill Pending</option>
              </CFormSelect>
            </div>

            {isHeadOffice && (
              <div className="filter-field filter-field--type">
                <CFormLabel className="filter-label">Branch</CFormLabel>
                <CFormSelect
                  size="sm"
                  className="filter-input"
                  value={filters.branch_id}
                  onChange={handleFilterChange('branch_id')}
                >
                  <option value="">All branches</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </CFormSelect>
              </div>
            )}

            <div className="filter-field filter-field--date">
              <CFormLabel className="filter-label">Start From</CFormLabel>
              <CFormInput
                type="date"
                size="sm"
                className="filter-input"
                value={filters.date_from}
                onChange={handleFilterChange('date_from')}
              />
            </div>

            <div className="filter-field filter-field--date">
              <CFormLabel className="filter-label">Start To</CFormLabel>
              <CFormInput
                type="date"
                size="sm"
                className="filter-input"
                value={filters.date_to}
                onChange={handleFilterChange('date_to')}
              />
            </div>

            <div className="filter-field filter-field--perpage">
              <PerPageSelector
                value={perPage}
                onChange={handlePerPageChangeWrapper}
                label="Per Page"
                disabled={loading}
              />
            </div>

            <div className="filter-field filter-field--buttons">
              <CButton
                size="sm"
                className="filter-btn filter-btn--primary"
                type="submit"
                disabled={loading}
              >
                Search
              </CButton>
              <CButton
                size="sm"
                className="filter-btn filter-btn--ghost"
                type="button"
                onClick={handleClear}
              >
                Clear
              </CButton>
            </div>
          </div>
        </form>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        {searched ? (
          <CCardBody className="p-0">
            {loading ? (
              <div className="report-shell__loading">
                <CSpinner />
                <div className="report-shell__loading-text">
                  Loading subscriptions...
                </div>
              </div>
            ) : (
              <>
                <CTable hover responsive bordered className="admin-data-table">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>#</CTableHeaderCell>
                      <CTableHeaderCell>Customer</CTableHeaderCell>
                      <CTableHeaderCell>Branch</CTableHeaderCell>
                      <CTableHeaderCell>Items</CTableHeaderCell>
                      <CTableHeaderCell>Start Date</CTableHeaderCell>
                      <CTableHeaderCell>Status</CTableHeaderCell>
                      <CTableHeaderCell>Actions</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {!error && subscriptions.length === 0 ? (
                      <CTableRow>
                        <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                          No subscriptions match these filters.
                        </CTableDataCell>
                      </CTableRow>
                    ) : (
                      subscriptions.map((sub, i) => (
                        <CTableRow key={sub.id}>
                          <CTableDataCell>
                            {(meta.current_page - 1) * perPage + i + 1}
                          </CTableDataCell>
                          <CTableDataCell>{sub.customer_name}</CTableDataCell>
                          <CTableDataCell>{sub.branch_name}</CTableDataCell>
                          <CTableDataCell>{sub.items?.length ?? 0}</CTableDataCell>
                          <CTableDataCell>{formatDate(sub.start_date)}</CTableDataCell>
                          <CTableDataCell>
                            <CBadge
                              color={STATUS_COLORS[sub.status] ?? 'secondary'}
                              shape="rounded-pill"
                            >
                              {sub.status}
                            </CBadge>
                          </CTableDataCell>
                          <CTableDataCell>
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              as={Link}
                              to={`/subscriptions/${sub.id}`}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              View
                            </CButton>
                          </CTableDataCell>
                        </CTableRow>
                      ))
                    )}
                  </CTableBody>
                </CTable>

                <Pagination
                  meta={meta}
                  onPageChange={handlePageChange}
                  loading={pageLoading}
                  variant="bold"
                  showPageJumper={true}
                  showRecordInfo={true}
                />
              </>
            )}
          </CCardBody>
        ) : (
          <CCardBody>
            <div className="text-center text-muted py-5">
              Enter at least one filter above to search subscriptions.
            </div>
          </CCardBody>
        )}
      </CCard>
    </div>
  )
}

export default SubscriptionsList