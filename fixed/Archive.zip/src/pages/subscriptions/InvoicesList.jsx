import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormSelect, CFormLabel, CFormCheck,
} from '@coreui/react'
import api from '../../api/api'
import { invoiceApi } from '../../api/subscriptionApi'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { handleDownloadInvoicePdf, handlePrintInvoicePdf, handleBulkPrintInvoices } from './InvoicePdfActions'
import ShareInvoiceWhatsAppButton from './ShareInvoiceWhatsAppButton'
import { formatDate } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)
const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

const STATUS_COLORS = {
  draft: 'secondary',
  generated: 'info',
  partially_paid: 'warning',
  paid: 'success',
  overdue: 'danger',
  cancelled: 'dark',
}

// Header column key -> backend sort key (must match InvoiceController::SORTABLE)
const SORT_KEY_MAP = {
  customer:      'customer',
  period_start:  'period_start',
  total:         'total',
  amount_paid:   'amount_paid',
  amount_due:    'amount_due',
  status:        'status',
  generated_at:  'generated_at',
}

// Robust extraction
const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

export default function InvoicesList() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [hasSearched, setHasSearched] = useState(false)
  const [selected, setSelected] = useState(new Set())
  const [bulkPrinting, setBulkPrinting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    from_date: monthAgo,
    to_date: today,
    search: '',
    status: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const [customerResults, setCustomerResults] = useState([])
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false)
  const [lastPicked, setLastPicked] = useState('')

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  useEffect(() => {
    if (!filters.search || filters.search === lastPicked) {
      setCustomerResults([])
      return
    }
    const t = setTimeout(() => {
      api.get('/masters/customers', { params: { search: filters.search, per_page: 10 } })
        .then((res) => setCustomerResults(extractArray(res)))
        .catch(() => setCustomerResults([]))
    }, 300)
    return () => clearTimeout(t)
  }, [filters.search, lastPicked])

  const pickCustomer = (c) => {
    setFilters((f) => ({ ...f, search: c.name }))
    setLastPicked(c.name)
    setShowCustomerDropdown(false)
  }

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = {
      per_page: usePerPage,
      date_from: useFilters.from_date,
      date_to: useFilters.to_date,
    }
    if (useFilters.search) params.search = useFilters.search
    if (useFilters.status) params.status = useFilters.status
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    if (!filtersOverride.from_date || !filtersOverride.to_date) {
      setError('Date range is required.')
      return
    }

    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await invoiceApi.list(params)

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.meta ?? {}

      setRows(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
      setSelected(new Set())
      setHasSearched(true)
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setError(err.response?.data?.message ?? 'Failed to load invoices.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const handlePageChange = (page) => {
    goToPage(page, fetchData)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchData)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleSearch = () => {
    if (
      filters.from_date &&
      filters.to_date &&
      filters.from_date > filters.to_date
    ) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleClear = () => {
    const empty = {
      from_date: monthAgo,
      to_date: today,
      search: '',
      status: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setLastPicked('')
    setCustomerResults([])
    setSortKey(null)
    setSortDir('desc')
    setRows([])
    setSelected(new Set())
    setHasSearched(false)
    setError(null)
  }

  const toggleRow = (id) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const toggleAllOnPage = () => {
    setSelected((prev) => {
      const allSelected = rows.every((r) => prev.has(r.id))
      if (allSelected) return new Set()
      return new Set(rows.map((r) => r.id))
    })
  }

  const allOnPageSelected = rows.length > 0 && rows.every((r) => selected.has(r.id))

  const printSelected = async () => {
    setBulkPrinting(true)
    try {
      await handleBulkPrintInvoices(Array.from(selected), setError)
    } finally {
      setBulkPrinting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Invoices</h4>
          {selected.size > 0 && (
            <CButton
              size="sm"
              className="report-shell__export"
              onClick={printSelected}
              disabled={bulkPrinting}
            >
              {bulkPrinting ? <CSpinner size="sm" className="me-2" /> : null}
              Print Selected ({selected.size})
            </CButton>
          )}
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              From <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.from_date}
              onChange={(e) => setFilters((f) => ({ ...f, from_date: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">
              To <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              size="sm"
              type="date"
              className="filter-input"
              value={filters.to_date}
              onChange={(e) => setFilters((f) => ({ ...f, to_date: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Customer</CFormLabel>
            <div style={{ position: 'relative' }}>
              <CFormInput
                size="sm"
                className="filter-input"
                placeholder="Name or phone"
                value={filters.search}
                onChange={(e) => {
                  setFilters((f) => ({ ...f, search: e.target.value }))
                  setShowCustomerDropdown(true)
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 150)}
              />
              {showCustomerDropdown && customerResults.length > 0 && (
                <div className="filter-dropdown">
                  {customerResults.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      className="dropdown-item"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => pickCustomer(c)}
                    >
                      {c.name} — {c.phone ?? 'no phone'}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filters.status}
              onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
            >
              <option value="">All statuses</option>
              <option value="generated">Generated</option>
              <option value="partially_paid">Partially Paid</option>
              <option value="paid">Paid</option>
              <option value="overdue">Overdue</option>
              <option value="cancelled">Cancelled</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              onClick={handleSearch}
              disabled={loading}
            >
              Search
            </CButton>
            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={handleClear}
              disabled={loading}
            >
              Clear
            </CButton>
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {!hasSearched ? (
            <div className="text-center text-muted py-5">
              Set a date range and click Search to view invoices.
            </div>
          ) : loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading invoices...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell style={{ width: 36 }}>
                      <CFormCheck
                        checked={allOnPageSelected}
                        onChange={toggleAllOnPage}
                      />
                    </CTableHeaderCell>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="customer">Customer</SortableHeader>
                    <SortableHeader colKey="period_start">Period</SortableHeader>
                    <SortableHeader colKey="total">Total</SortableHeader>
                    <SortableHeader colKey="amount_paid">Paid</SortableHeader>
                    <SortableHeader colKey="amount_due">Due</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No invoices found for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((inv, i) => (
                      <CTableRow key={inv.id}>
                        <CTableDataCell>
                          <CFormCheck
                            checked={selected.has(inv.id)}
                            onChange={() => toggleRow(inv.id)}
                          />
                        </CTableDataCell>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{inv.customer_name}</CTableDataCell>
                        <CTableDataCell>
                          {formatDate(inv.period_start)} – {formatDate(inv.period_end)}
                        </CTableDataCell>
                        <CTableDataCell>₹{inv.total}</CTableDataCell>
                        <CTableDataCell>₹{inv.amount_paid}</CTableDataCell>
                        <CTableDataCell>₹{inv.amount_due}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLORS[inv.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {inv.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center flex-wrap">
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              as={Link}
                              to={`/subscriptions/invoices/${inv.id}`}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              View
                            </CButton>
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => handleDownloadInvoicePdf(inv.id, setError)}
                            >
                              PDF
                            </CButton>
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => handlePrintInvoicePdf(inv.id, setError)}
                            >
                              Print
                            </CButton>
                            <ShareInvoiceWhatsAppButton
                              invoiceId={inv.id}
                              customerName={inv.customer_name}
                              customerPhone={inv.customer_phone}
                              invoiceTotal={inv.total}
                            />
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}