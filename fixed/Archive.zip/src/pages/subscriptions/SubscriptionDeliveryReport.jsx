import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormSelect, CFormInput, CFormLabel,
  CModal, CModalHeader, CModalTitle, CModalBody,
} from '@coreui/react'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import { formatDate } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)

const STATUS_COLORS = {
  delivered: 'success',
  not_delivered: 'danger',
  customer_paused: 'secondary',
  admin_paused: 'secondary',
  holiday_skipped: 'dark',
  scheduled: 'info',
  assigned: 'primary',
  out_for_delivery: 'warning',
  billed: 'primary',
}

const ASSIGNMENT_TYPE_COLORS = {
  preferred: 'success',
  substitute: 'warning',
  manual_override: 'info',
}

const SORT_KEY_MAP = {
  occurrence_date:       'occurrence_date',
  qty:                   'qty',
  status:                'status',
  not_delivered_reason:  'not_delivered_reason',
}

const prettyLabel = (v) => String(v ?? '').replace(/_/g, ' ')

const SubscriptionDeliveryReport = () => {
  const authRole = useAuthStore((s) => s.role)
  const userBranchId = useAuthStore((s) => s.user?.branch_id)

  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const [rows, setRows] = useState([])
  const [summary, setSummary] = useState(null)
  const [branches, setBranches] = useState([])
  const [zones, setZones] = useState([])
  const [riders, setRiders] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [exporting, setExporting] = useState(false)
  const [photoModal, setPhotoModal] = useState({ open: false, url: null })

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [filters, setFilters] = useState({
    date_from: today,
    date_to: today,
    status: '',
    not_delivered_reason: '',
    branch_id: '',
    zone_id: '',
    delivery_boy_id: '',
  })
  const [appliedFilters, setAppliedFilters] = useState(filters)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const fetchBranches = async () => {
    if (!isHeadOffice) return
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const d = res.data?.data
      const all = Array.isArray(d) ? d : (d?.data ?? [])
      setBranches(all)
    } catch { /* silent */ }
  }

  const fetchRiders = async (branchId) => {
    if (!branchId) { setRiders([]); return }
    try {
      const res = await api.get('/settings/delivery-boys', {
        params: { per_page: 200, branch_id: branchId },
      })
      setRiders(res.data?.data?.users ?? [])
    } catch { setRiders([]) }
  }

  useEffect(() => { fetchBranches() }, [isHeadOffice])

  useEffect(() => {
    const branchId = filters.branch_id || userBranchId
    if (!branchId) { setZones([]); return }
    api.get(`/settings/branches/${branchId}/zones`)
      .then((res) => setZones(res.data?.data?.zones || []))
      .catch(() => setZones([]))
  }, [filters.branch_id, userBranchId])

  useEffect(() => {
    const branchId = filters.branch_id || userBranchId
    if (!branchId) {
      setRiders([])
      setFilters((f) => ({ ...f, delivery_boy_id: '' }))
      return
    }
    setFilters((f) => ({ ...f, delivery_boy_id: '' }))
    fetchRiders(branchId)
  }, [filters.branch_id, userBranchId])

  const buildParams = (useFilters, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useFilters.date_from) params.date_from = useFilters.date_from
    if (useFilters.date_to) params.date_to = useFilters.date_to
    if (useFilters.status) params.status = useFilters.status
    if (useFilters.not_delivered_reason) params.not_delivered_reason = useFilters.not_delivered_reason
    if (isHeadOffice && useFilters.branch_id) params.branch_id = useFilters.branch_id
    if (useFilters.zone_id) params.zone_id = useFilters.zone_id
    if (useFilters.delivery_boy_id) params.delivery_boy_id = useFilters.delivery_boy_id
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    filtersOverride = appliedFilters,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(filtersOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/reports/subscription-delivery', { params })

      if (mySeq !== requestSeq.current) return

      const dataArray = Array.isArray(res.data?.data) ? res.data.data : []
      const paginationMeta = res.data?.meta ?? {}
      const summaryData = res.data?.summary ?? null

      setRows(dataArray)
      setSummary(summaryData)

      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRows([])
      setSummary(null)
      setError(err.response?.data?.message ?? 'Failed to load delivery report.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchData({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleApply = () => {
    if (filters.date_from && filters.date_to && filters.date_from > filters.date_to) {
      setError('"From" date must be before "To" date.')
      return
    }
    setAppliedFilters(filters)
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: filters })
  }

  const handleReset = () => {
    const empty = {
      date_from: today,
      date_to: today,
      status: '',
      not_delivered_reason: '',
      branch_id: '',
      zone_id: '',
      delivery_boy_id: '',
    }
    setFilters(empty)
    setAppliedFilters(empty)
    setSortKey(null)
    setSortDir('desc')
    setPageLoading(true)
    fetchData({ page: 1, filtersOverride: empty, sortKeyOverride: null, sortDirOverride: 'desc' })
  }

  const handleExport = async () => {
    setExporting(true)
    setError(null)
    try {
      const params = { ...appliedFilters, export: 'csv' }
      if (!isHeadOffice) delete params.branch_id
      const res = await api.get('/reports/subscription-delivery', {
        params,
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `subscription_delivery_${appliedFilters.date_from}_to_${appliedFilters.date_to}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.response?.data?.message ?? 'Export failed.')
    } finally {
      setExporting(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span className={
          'sort-icon' +
          (active ? ' sort-icon--active' : '') +
          (isDesc ? ' sort-icon--desc' : '')
        } />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Subscription Delivery Report</h4>
          <CButton
            size="sm" className="report-shell__export"
            onClick={handleExport}
            disabled={exporting || !rows.length || loading}
          >
            {exporting ? <CSpinner size="sm" className="me-2" /> : null}
            Export CSV
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">From</CFormLabel>
            <CFormInput
              size="sm" type="date" className="filter-input"
              value={filters.date_from}
              onChange={(e) => setFilters((f) => ({ ...f, date_from: e.target.value }))}
            />
          </div>

          <div className="filter-field filter-field--date">
            <CFormLabel className="filter-label">To</CFormLabel>
            <CFormInput
              size="sm" type="date" className="filter-input"
              value={filters.date_to}
              onChange={(e) => setFilters((f) => ({ ...f, date_to: e.target.value }))}
            />
          </div>

          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect
                size="sm" className="filter-input"
                value={filters.branch_id}
                onChange={(e) => setFilters((f) => ({
                  ...f,
                  branch_id: e.target.value,
                  zone_id: '',
                  delivery_boy_id: '',
                }))}
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Zone</CFormLabel>
            <CFormSelect
              size="sm" className="filter-input"
              value={filters.zone_id}
              onChange={(e) => setFilters((f) => ({ ...f, zone_id: e.target.value }))}
              disabled={isHeadOffice && !filters.branch_id}
            >
              <option value="">
                {isHeadOffice && !filters.branch_id ? 'Select a branch first' : 'All Zones'}
              </option>
              {zones.map((z) => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Rider</CFormLabel>
            <CFormSelect
              size="sm" className="filter-input"
              value={filters.delivery_boy_id}
              onChange={(e) => setFilters((f) => ({ ...f, delivery_boy_id: e.target.value }))}
              disabled={isHeadOffice && !filters.branch_id}
            >
              <option value="">
                {isHeadOffice && !filters.branch_id ? 'Select a branch first' : 'All Riders'}
              </option>
              {riders.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm" className="filter-input"
              value={filters.status}
              onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
            >
              <option value="">All</option>
              <option value="scheduled">Scheduled (unassigned)</option>
              <option value="assigned">Assigned</option>
              <option value="out_for_delivery">Out for Delivery</option>
              <option value="delivered">Delivered</option>
              <option value="not_delivered">Not Delivered</option>
              <option value="customer_paused">Customer Paused</option>
              <option value="admin_paused">Admin Paused</option>
              <option value="holiday_skipped">Holiday Skipped</option>
              <option value="billed">Billed</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Not Delivered Reason</CFormLabel>
            <CFormSelect
              size="sm" className="filter-input"
              value={filters.not_delivered_reason}
              onChange={(e) => setFilters((f) => ({ ...f, not_delivered_reason: e.target.value }))}
            >
              <option value="">All</option>
              <option value="customer_unavailable">Customer Unavailable</option>
              <option value="customer_refused">Customer Refused</option>
              <option value="stockout">Stockout</option>
              <option value="vehicle_breakdown">Vehicle Breakdown</option>
              <option value="address_not_found">Address Not Found</option>
              <option value="other">Other</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>

          <div className="filter-field filter-field--buttons">
            <CButton
              size="sm" className="filter-btn filter-btn--primary"
              onClick={handleApply} disabled={loading}
            >
              Apply
            </CButton>
            <CButton
              size="sm" className="filter-btn filter-btn--ghost"
              onClick={handleReset} disabled={loading}
            >
              Reset
            </CButton>
          </div>
        </div>

        {summary && (
          <div className="report-summary-strip">
            <SummaryCard label="Total" value={summary.total} />
            {Object.entries(summary.by_status || {}).map(([status, count]) => (
              <SummaryCard
                key={status}
                label={prettyLabel(status)}
                value={count}
                color={STATUS_COLORS[status] ?? 'secondary'}
              />
            ))}
          </div>
        )}

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading delivery report...
              </div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="occurrence_date">Date</SortableHeader>
                    <CTableHeaderCell>Customer</CTableHeaderCell>
                    <CTableHeaderCell>Branch</CTableHeaderCell>
                    <CTableHeaderCell>Zone</CTableHeaderCell>
                    <CTableHeaderCell>Slot</CTableHeaderCell>
                    <CTableHeaderCell>Product</CTableHeaderCell>
                    <SortableHeader colKey="qty">Qty</SortableHeader>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="not_delivered_reason">Reason</SortableHeader>
                    <CTableHeaderCell>Rider</CTableHeaderCell>
                    <CTableHeaderCell>Assigned Type</CTableHeaderCell>
                    <CTableHeaderCell>Photo</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && rows.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={13} className="text-center text-muted py-4">
                        No records for this range.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    rows.map((row, idx) => {
                      const slotLabel = row.slot_name
                        ? `${row.slot_name}${row.slot_start_time && row.slot_end_time ? ` (${row.slot_start_time}–${row.slot_end_time})` : ''}`
                        : '—'

                      return (
                        <CTableRow key={row.id}>
                          <CTableDataCell>
                            {(meta.current_page - 1) * perPage + idx + 1}
                          </CTableDataCell>
                          <CTableDataCell>{formatDate(row.occurrence_date)}</CTableDataCell>
                          <CTableDataCell>{row.customer_name}</CTableDataCell>
                          <CTableDataCell>{row.branch_name}</CTableDataCell>
                          <CTableDataCell>{row.zone_name ?? '—'}</CTableDataCell>
                          <CTableDataCell>{slotLabel}</CTableDataCell>
                          <CTableDataCell>{row.product_name}</CTableDataCell>
                          <CTableDataCell>{row.qty}</CTableDataCell>
                          <CTableDataCell>
                            <CBadge color={STATUS_COLORS[row.status] ?? 'secondary'} shape="rounded-pill">
                              {prettyLabel(row.status)}
                            </CBadge>
                          </CTableDataCell>
                          <CTableDataCell>
                            {row.not_delivered_reason ? prettyLabel(row.not_delivered_reason) : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {row.delivery_boy_name ? (
                              <>
                                <div>{row.delivery_boy_name}</div>
                                {row.rider_mobile && <div className="text-muted small">{row.rider_mobile}</div>}
                              </>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </CTableDataCell>
                          <CTableDataCell>
                            {row.assignment_type ? (
                              <CBadge color={ASSIGNMENT_TYPE_COLORS[row.assignment_type] ?? 'secondary'} shape="rounded-pill">
                                {prettyLabel(row.assignment_type)}
                              </CBadge>
                            ) : '—'}
                          </CTableDataCell>
                          <CTableDataCell>
                            {row.delivery_photo_url ? (
                              <img
                                src={row.delivery_photo_url}
                                alt="Delivery proof"
                                style={{
                                  width: 40, height: 40,
                                  objectFit: 'cover', borderRadius: 4,
                                  cursor: 'pointer', border: '1px solid #cbd5e1',
                                }}
                                onClick={() => setPhotoModal({ open: true, url: row.delivery_photo_url })}
                              />
                            ) : '—'}
                          </CTableDataCell>
                        </CTableRow>
                      )
                    })
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      <CModal
        visible={photoModal.open}
        onClose={() => setPhotoModal({ open: false, url: null })}
        size="lg" alignment="center"
      >
        <CModalHeader><CModalTitle>Delivery Photo</CModalTitle></CModalHeader>
        <CModalBody className="text-center">
          {photoModal.url && (
            <img
              src={photoModal.url}
              alt="Delivery proof"
              style={{ maxWidth: '100%', maxHeight: '70vh', borderRadius: 6 }}
            />
          )}
        </CModalBody>
      </CModal>
    </div>
  )
}

function SummaryCard({ label, value, color = 'secondary' }) {
  return (
    <div className={`report-summary-card report-summary-card--${color}`}>
      <div className="report-summary-card__value">{value}</div>
      <div className="report-summary-card__label">{label}</div>
    </div>
  )
}

export default SubscriptionDeliveryReport