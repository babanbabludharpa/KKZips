import { useEffect, useRef, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormSelect, CFormLabel, CFormCheck,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import api from '../../api/api'
import { subscriptionApi } from '../../api/subscriptionApi'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

function describeApiError(err) {
  const status = err?.response?.status
  if (!err?.response) return 'Network error — check your connection.'
  if (status === 401) return 'Session expired. Please log in again.'
  if (status === 403) return err.response.data?.message ?? "You don't have permission to do this."
  if (status === 419) return 'Session expired. Please refresh and log in again.'
  if (status === 422) {
    const errors = err.response.data?.errors
    if (errors) return Object.values(errors).flat().join(' ')
    return err.response.data?.message ?? 'Invalid request.'
  }
  if (status >= 500) return 'Server error. Try again in a moment.'
  return err.response.data?.message ?? `Request failed (${status}).`
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  if (Array.isArray(inner?.users)) return inner.users
  return []
}

const todayISO = () => {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const DEFAULT_STATUS = 'scheduled,assigned'

const STATUS_OPTIONS = [
  { value: '',                    label: 'Any status' },
  { value: 'scheduled,assigned',  label: 'Scheduled + Assigned' },
  { value: 'scheduled',           label: 'Scheduled (unassigned)' },
  { value: 'assigned',            label: 'Assigned' },
  { value: 'out_for_delivery',    label: 'Out for delivery' },
  { value: 'delivered',           label: 'Delivered' },
  { value: 'not_delivered',       label: 'Not delivered' },
]

const ASSIGNMENT_TYPE_LABEL = {
  preferred:       'Preferred',
  substitute:      'Substitute',
  manual_override: 'Manual Override',
}

const STATUS_BADGE = {
  scheduled:        'secondary',
  assigned:         'primary',
  out_for_delivery: 'warning',
  delivered:        'success',
  not_delivered:    'danger',
  customer_paused:  'secondary',
  admin_paused:     'secondary',
  holiday_skipped:  'secondary',
}

const ASSIGNMENT_BADGE = {
  preferred:       'success',
  substitute:      'warning',
  manual_override: 'info',
}

const slotLabel = (slot) => {
  if (!slot) return '—'
  const s = slot.start_time ? slot.start_time.slice(0, 5) : ''
  const e = slot.end_time ? slot.end_time.slice(0, 5) : ''
  return s && e ? `${slot.name} (${s}–${e})` : slot.name
}

const zoneLabel = (occ) => occ.zone_name ?? occ.zone?.name ?? '—'

function RiderPicker({ value, onChange, branchId, zoneId, disabled }) {
  const [riders, setRiders] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!branchId) { setRiders([]); return }
    let cancelled = false
    setLoading(true); setError(null)
    api.get('/settings/delivery-boys', { params: { per_page: 200, branch_id: branchId } })
      .then((res) => { if (!cancelled) setRiders(extractArray(res)) })
      .catch((err) => { if (!cancelled) setError(describeApiError(err)) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [branchId])

  const filtered = useMemo(() => {
    if (!zoneId) return riders
    const zid = Number(zoneId)
    return riders.filter((r) =>
      Array.isArray(r.zones) && r.zones.some((z) => Number(z.id) === zid)
    )
  }, [riders, zoneId])

  if (error) return <CAlert color="danger" className="py-2 mb-0 small">{error}</CAlert>

  return (
    <CFormSelect
      size="sm"
      className="filter-input"
      value={value}
      disabled={disabled || loading || !branchId}
      onChange={(e) => {
        const v = e.target.value
        const rider = riders.find((r) => String(r.id) === String(v)) ?? null
        onChange(v, rider)
      }}
    >
      <option value="">
        {!branchId
          ? 'Select a branch first'
          : loading
            ? 'Loading riders…'
            : 'Select rider…'}
      </option>
      {filtered.map((r) => (
        <option key={r.id} value={r.id}>{r.name}</option>
      ))}
      {!loading && branchId && zoneId && filtered.length === 0 && (
        <option value="" disabled>No riders cover this zone</option>
      )}
    </CFormSelect>
  )
}

const DeliveryAssignmentBoard = () => {
  const authRole = useAuthStore((s) => s.role)
  const userBranchId = useAuthStore((s) => s.user?.branch_id)

  const isHeadOffice =
    authRole === 'staff_headoffice' ||
    authRole === 'superadmin' ||
    authRole === 'admin'

  const effectiveBranch = (selected) => selected || userBranchId

  // ── URL param support for external deep-links (e.g. Tenant Leaves preview) ──
  const [searchParams] = useSearchParams()

  const initialFrom = searchParams.get('date_from') || todayISO()
  const initialTo   = searchParams.get('date_to')   || initialFrom

  // ── Search filters ────────────────────────────────────────────
  const [dateFrom, setDateFrom] = useState(initialFrom)
  const [dateTo,   setDateTo]   = useState(initialTo)
  const [branchId, setBranchId] = useState(searchParams.get('branch_id') || '')
  const [zoneId, setZoneId] = useState('')
  const [riderFilterId, setRiderFilterId] = useState('')
  const [riderFilterName, setRiderFilterName] = useState('')
  const [slotFilter, setSlotFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState(
    searchParams.get('status') || DEFAULT_STATUS
  )
  const [assignmentTypeFilter, setAssignmentTypeFilter] = useState('')
  const [showOnlyUnassigned, setShowOnlyUnassigned] = useState(false)

  const [filtersOpen, setFiltersOpen] = useState(isHeadOffice)

  const [branches, setBranches] = useState([])
  const [zones, setZones] = useState([])
  const [slots, setSlots] = useState([])

  const [occurrences, setOccurrences] = useState([])
  const [selected, setSelected] = useState(new Set())
  const [message, setMessage] = useState(null)
  const [loading, setLoading] = useState(false)
  const [loadError, setLoadError] = useState(null)

  const [riderId, setRiderId] = useState('')
  const [scope, setScope] = useState('this_only')

  const [reassignModal, setReassignModal] = useState({ open: false, occurrence: null })
  const [modalRiderId, setModalRiderId] = useState('')
  const [modalScope, setModalScope] = useState('this_only')

  const requestSeq = useRef(0)

  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  // Branches, zones, slots — same as before
  useEffect(() => {
    if (!isHeadOffice) return
    api.get('/settings/branches', { params: { per_page: 200 } })
      .then((res) => {
        const d = res.data?.data
        setBranches(Array.isArray(d) ? d : (d?.data ?? []))
      })
      .catch(() => setBranches([]))
  }, [isHeadOffice])

  useEffect(() => {
    const branch = effectiveBranch(branchId)
    if (!branch) { setZones([]); return }
    api.get(`/settings/branches/${branch}/zones`)
      .then((res) => setZones(res.data?.data?.zones || []))
      .catch(() => setZones([]))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [branchId, userBranchId])

  useEffect(() => {
    api.get('/settings/slots')
      .then((res) => setSlots(extractArray(res).filter((s) => s.is_active)))
      .catch(() => setSlots([]))
  }, [])

  // ── Load occurrences ──────────────────────────────────────────
  const load = async ({ page = 1, perPageOverride = perPage } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setSelected(new Set())
    setLoadError(null)

    try {
      const params = { per_page: perPageOverride, page }

      // Send date_from / date_to so the backend can filter by range.
      // (The existing backend occurrencesReport already supports date;
      //  it should accept date_from / date_to — if not, see the note below.)
      params.date_from = dateFrom
      params.date_to   = dateTo

      if (isHeadOffice && !branchId) {
        setOccurrences([])
        updatePagination({ current_page: 1, last_page: 1, per_page: perPageOverride, total: 0, from: null, to: null })
        setLoading(false)
        setPageLoading(false)
        return
      }
      const branch = effectiveBranch(branchId)
      if (branch) params.branch_id = branch

      if (zoneId)                 params.zone_id = zoneId
      if (riderFilterId)          params.delivery_boy_id = riderFilterId
      if (slotFilter)             params.slot_id = slotFilter
      if (statusFilter)           params.status = statusFilter
      if (assignmentTypeFilter)   params.assignment_type = assignmentTypeFilter
      if (showOnlyUnassigned && !riderFilterId) params.delivery_boy_id = 'null'

      const res = await subscriptionApi.occurrencesReport(params)
      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta = res.data?.meta ?? res.data?.data?.meta ?? {}

      setOccurrences(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setOccurrences([])
      setLoadError(describeApiError(err))
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    load({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    dateFrom, dateTo, branchId, zoneId, riderFilterId, slotFilter,
    statusFilter, assignmentTypeFilter, showOnlyUnassigned,
  ])

  const handlePageChange = (page) => goToPage(page, (p) => load(p))
  const handlePerPageChangeWrapper = (e) =>
    handlePerPageChange(e, (perPageOverride) => load({ page: 1, perPageOverride }))

  const toggle = (id) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const allSelected = occurrences.length > 0 && occurrences.every((o) => selected.has(o.id))
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(occurrences.map((o) => o.id)))

  const canBulkAssign = !!riderId && selected.size > 0

  const actionZoneId = useMemo(() => {
    if (zoneId) return zoneId
    const selZoneIds = occurrences
      .filter((o) => selected.has(o.id))
      .map((o) => o.zone_id)
      .filter(Boolean)
    const unique = [...new Set(selZoneIds)]
    return unique.length === 1 ? unique[0] : ''
  }, [zoneId, occurrences, selected])

  // ── Active filter chips ───────────────────────────────────────
  const activeChips = useMemo(() => {
    const chips = []
    if (dateFrom !== todayISO() || dateTo !== todayISO()) {
      const range = dateFrom === dateTo ? dateFrom : `${dateFrom} → ${dateTo}`
      chips.push({
        key: 'date',
        label: `Date: ${range}`,
        clear: () => { setDateFrom(todayISO()); setDateTo(todayISO()) },
      })
    }
    if (isHeadOffice && branchId) {
      const b = branches.find((x) => String(x.id) === String(branchId))
      chips.push({
        key: 'branch',
        label: `Branch: ${b?.name ?? branchId}`,
        clear: () => {
          setBranchId(''); setZoneId(''); setRiderFilterId(''); setRiderFilterName(''); setRiderId('')
        },
      })
    }
    if (zoneId) {
      const z = zones.find((x) => String(x.id) === String(zoneId))
      chips.push({
        key: 'zone',
        label: `Zone: ${z?.name ?? zoneId}`,
        clear: () => { setZoneId(''); setRiderId('') },
      })
    }
    if (riderFilterId) {
      chips.push({
        key: 'rider',
        label: `Rider: ${riderFilterName || `#${riderFilterId}`}`,
        clear: () => { setRiderFilterId(''); setRiderFilterName('') },
      })
    }
    if (slotFilter) {
      const s = slots.find((x) => String(x.id) === String(slotFilter))
      chips.push({
        key: 'slot',
        label: `Slot: ${s?.name ?? slotFilter}`,
        clear: () => setSlotFilter(''),
      })
    }
    if (statusFilter !== DEFAULT_STATUS) {
      const st = STATUS_OPTIONS.find((o) => o.value === statusFilter)
      chips.push({
        key: 'status',
        label: `Status: ${st?.label ?? statusFilter}`,
        clear: () => setStatusFilter(DEFAULT_STATUS),
      })
    }
    if (assignmentTypeFilter) {
      chips.push({
        key: 'atype',
        label: `Type: ${ASSIGNMENT_TYPE_LABEL[assignmentTypeFilter] ?? assignmentTypeFilter}`,
        clear: () => setAssignmentTypeFilter(''),
      })
    }
    if (showOnlyUnassigned) {
      chips.push({
        key: 'unassigned',
        label: 'Only unassigned',
        clear: () => setShowOnlyUnassigned(false),
      })
    }
    return chips
  }, [
    dateFrom, dateTo, branchId, zoneId, riderFilterId, riderFilterName, slotFilter,
    statusFilter, assignmentTypeFilter, showOnlyUnassigned,
    branches, zones, slots, isHeadOffice,
  ])

  const bulkAssign = async () => {
    if (!canBulkAssign) return
    setMessage(null)
    try {
      const { data } = await subscriptionApi.bulkReassignOccurrences({
        delivery_boy_id: Number(riderId),
        scope,
        occurrence_ids: Array.from(selected),
      })

      const results = data.data || {}
      const counts = {
        assigned: results.assigned?.length ?? 0,
        rejected: results.rejected?.length ?? 0,
        skipped:  results.skipped?.length ?? 0,
      }
      const reasons = (results.rejected || []).map(
        (r) => `#${r.occurrence_id}: ${r.reason}`
      )
      setMessage({
        type: counts.rejected > 0 || counts.skipped > 0 ? 'warning' : 'success',
        text: `${counts.assigned} assigned, ${counts.rejected} rejected, ${counts.skipped} skipped.` +
              (reasons.length ? ' ' + reasons.join(' | ') : ''),
      })
      load({ page: 1 })
    } catch (err) {
      setMessage({ type: 'danger', text: describeApiError(err) })
    }
  }

  const openRowReassign = (occurrence) => {
    setReassignModal({ open: true, occurrence })
    setModalRiderId('')
    setModalScope('this_only')
  }

  const submitRowReassign = async () => {
    if (!modalRiderId || !reassignModal.occurrence) return
    try {
      const { data } = await subscriptionApi.reassignOccurrence(
        reassignModal.occurrence.id,
        { delivery_boy_id: Number(modalRiderId), scope: modalScope }
      )

      if (data.status) {
        setMessage({ type: 'success', text: 'Occurrence reassigned.' })
      } else {
        setMessage({
          type: 'warning',
          text: data.data?.current_reason
            ? `Rejected: ${data.data.current_reason}`
            : data.message,
        })
      }
      setReassignModal({ open: false, occurrence: null })
      load({ page: meta.current_page })
    } catch (err) {
      setMessage({ type: 'danger', text: describeApiError(err) })
      setReassignModal({ open: false, occurrence: null })
    }
  }

  const modalBranchId = reassignModal.occurrence?.branch_id || effectiveBranch(branchId)
  const modalZoneId = reassignModal.occurrence?.zone_id || ''

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ── TOOLBAR ─────────────────────────────────────── */}
        <div className="report-toolbar">
          <span className="report-toolbar__title">Delivery Assignment</span>

          <div className="report-filter-chips">
            {activeChips.map((c) => (
              <span key={c.key} className="report-filter-chip">
                {c.label}
                <button type="button" aria-label={`Clear ${c.label}`} onClick={c.clear}>×</button>
              </span>
            ))}
          </div>

          <div className="report-toolbar__spacer" />

          <CButton
            size="sm"
            className="filter-btn filter-btn--ghost"
            onClick={() => setFiltersOpen((v) => !v)}
          >
            Filters
            {activeChips.length > 0 && (
              <CBadge color="primary" shape="rounded-pill" className="ms-1">
                {activeChips.length}
              </CBadge>
            )}
            <span className="ms-1">{filtersOpen ? '▴' : '▾'}</span>
          </CButton>

          <PerPageSelector
            value={perPage}
            onChange={handlePerPageChangeWrapper}
            label="Per Page"
            disabled={loading}
          />
        </div>

        {/* ── FILTERS ──────────────────────────────────────── */}
        {filtersOpen && (
          <div className="report-filters">
            <div className="filter-field">
              <CFormLabel className="filter-label">Date From</CFormLabel>
              <CFormInput
                size="sm"
                type="date"
                className="filter-input"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">Date To</CFormLabel>
              <CFormInput
                size="sm"
                type="date"
                className="filter-input"
                value={dateTo}
                min={dateFrom}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>

            {isHeadOffice && (
              <div className="filter-field">
                <CFormLabel className="filter-label">Branch</CFormLabel>
                <CFormSelect
                  size="sm"
                  className="filter-input"
                  value={branchId}
                  onChange={(e) => {
                    setBranchId(e.target.value)
                    setZoneId('')
                    setRiderFilterId('')
                    setRiderFilterName('')
                    setRiderId('')
                  }}
                >
                  <option value="">Select a branch…</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </CFormSelect>
              </div>
            )}

            <div className="filter-field">
              <CFormLabel className="filter-label">Zone</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={zoneId}
                onChange={(e) => { setZoneId(e.target.value); setRiderId('') }}
                disabled={isHeadOffice && !branchId}
              >
                <option value="">
                  {isHeadOffice && !branchId ? 'Select branch first' : 'All Zones'}
                </option>
                {zones.map((z) => (
                  <option key={z.id} value={z.id}>{z.name}</option>
                ))}
              </CFormSelect>
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">Rider</CFormLabel>
              <RiderPicker
                value={riderFilterId}
                onChange={(v, rider) => {
                  setRiderFilterId(v)
                  setRiderFilterName(rider?.name ?? '')
                }}
                branchId={effectiveBranch(branchId)}
                zoneId={zoneId}
                disabled={isHeadOffice && !branchId}
              />
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">Slot</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={slotFilter}
                onChange={(e) => setSlotFilter(e.target.value)}
              >
                <option value="">All slots</option>
                {slots.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.start_time?.slice(0, 5)}–{s.end_time?.slice(0, 5)})
                  </option>
                ))}
              </CFormSelect>
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">Status</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                {STATUS_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </CFormSelect>
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">Assignment Type</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={assignmentTypeFilter}
                onChange={(e) => setAssignmentTypeFilter(e.target.value)}
              >
                <option value="">Any</option>
                <option value="preferred">Preferred</option>
                <option value="substitute">Substitute</option>
                <option value="manual_override">Manual Override</option>
              </CFormSelect>
            </div>

            <div className="filter-field">
              <CFormLabel className="filter-label">&nbsp;</CFormLabel>
              <CFormCheck
                id="only-unassigned"
                label="Only unassigned"
                checked={showOnlyUnassigned}
                disabled={!!riderFilterId}
                onChange={(e) => setShowOnlyUnassigned(e.target.checked)}
              />
            </div>
          </div>
        )}

        {/* ── ACTION BAR ────────────────────────────────────── */}
        {selected.size > 0 && (
          <div className="report-actions">
            <span className="report-actions__hint">{selected.size} selected</span>

            <div className="report-actions__field">
              <label>Assign to Rider</label>
              <RiderPicker
                value={riderId}
                onChange={(v) => setRiderId(v)}
                branchId={effectiveBranch(branchId)}
                zoneId={actionZoneId}
                disabled={isHeadOffice && !branchId}
              />
            </div>

            <div className="report-actions__field">
              <label>Scope</label>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={scope}
                onChange={(e) => setScope(e.target.value)}
              >
                <option value="this_only">This occurrence only</option>
                <option value="this_and_future">This + future occurrences</option>
              </CFormSelect>
            </div>

            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              disabled={!canBulkAssign}
              onClick={bulkAssign}
            >
              Assign Selected ({selected.size})
            </CButton>

            <CButton
              size="sm"
              className="filter-btn filter-btn--ghost"
              onClick={() => setSelected(new Set())}
            >
              Clear
            </CButton>
          </div>
        )}

        {message && (
          <div className="report-shell__error">
            <CAlert color={message.type} dismissible onClose={() => setMessage(null)}>
              {message.text}
            </CAlert>
          </div>
        )}
        {loadError && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setLoadError(null)}>
              Couldn't load occurrences: {loadError}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading occurrences...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell style={{ width: 40 }}>
                      <CFormCheck checked={allSelected} onChange={toggleAll} />
                    </CTableHeaderCell>
                    <CTableHeaderCell style={{ width: 56 }}>#</CTableHeaderCell>
                    <CTableHeaderCell>Customer</CTableHeaderCell>
                    <CTableHeaderCell>Product</CTableHeaderCell>
                    <CTableHeaderCell>Qty</CTableHeaderCell>
                    <CTableHeaderCell>Slot</CTableHeaderCell>
                    <CTableHeaderCell>Zone</CTableHeaderCell>
                    <CTableHeaderCell>Address</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Rider</CTableHeaderCell>
                    <CTableHeaderCell>Type</CTableHeaderCell>
                    <CTableHeaderCell>Action</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!loadError && occurrences.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={12} className="text-center text-muted py-4">
                        {isHeadOffice && !branchId
                          ? 'Select a branch to load occurrences.'
                          : 'No occurrences match these filters.'}
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    occurrences.map((occ, idx) => (
                      <CTableRow key={occ.id}>
                        <CTableDataCell>
                          <CFormCheck
                            checked={selected.has(occ.id)}
                            onChange={() => toggle(occ.id)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="text-muted">
                          {(meta.current_page - 1) * perPage + idx + 1}
                        </CTableDataCell>
                        <CTableDataCell>{occ.customer_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{occ.product_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>{occ.qty}</CTableDataCell>
                        <CTableDataCell>{slotLabel(occ.slot)}</CTableDataCell>
                        <CTableDataCell>{zoneLabel(occ)}</CTableDataCell>
                        <CTableDataCell>
                          <span className="text-muted small">{occ.delivery_address ?? '—'}</span>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={STATUS_BADGE[occ.status] ?? 'secondary'} shape="rounded-pill">
                            {occ.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {occ.delivery_boy_id
                            ? <CBadge color="primary" shape="rounded-pill">
                                {occ.delivery_boy_name ?? `Rider #${occ.delivery_boy_id}`}
                              </CBadge>
                            : <CBadge color="danger" shape="rounded-pill">Unassigned</CBadge>}
                        </CTableDataCell>
                        <CTableDataCell>
                          {occ.assignment_type
                            ? <CBadge color={ASSIGNMENT_BADGE[occ.assignment_type] ?? 'secondary'} shape="rounded-pill">
                                {occ.assignment_type}
                              </CBadge>
                            : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="filter-btn filter-btn--ghost"
                            onClick={() => openRowReassign(occ)}
                          >
                            Reassign
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      <CModal
        visible={reassignModal.open}
        onClose={() => setReassignModal({ open: false, occurrence: null })}
        backdrop="static"
      >
        <CModalHeader><CModalTitle>Reassign Occurrence</CModalTitle></CModalHeader>
        <CModalBody>
          {reassignModal.occurrence && (
            <>
              <p className="mb-2">
                <strong>Customer:</strong> {reassignModal.occurrence.customer_name ?? '—'}<br />
                <strong>Date:</strong> {reassignModal.occurrence.occurrence_date}<br />
                <strong>Slot:</strong> {slotLabel(reassignModal.occurrence.slot)}
              </p>

              <CFormLabel className="filter-label">New Rider</CFormLabel>
              <RiderPicker
                value={modalRiderId}
                onChange={(v) => setModalRiderId(v)}
                branchId={modalBranchId}
                zoneId={modalZoneId}
              />

              <CFormLabel className="filter-label mt-3">Scope</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={modalScope}
                onChange={(e) => setModalScope(e.target.value)}
              >
                <option value="this_only">This occurrence only</option>
                <option value="this_and_future">This + all future occurrences of this item</option>
              </CFormSelect>

              <CAlert color="info" className="mt-3 mb-0 py-2 small">
                The engine validates the rider against zone, slot, leave, and capacity.
                Ineligible riders will be rejected with a reason.
              </CAlert>
            </>
          )}
        </CModalBody>
        <CModalFooter>
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setReassignModal({ open: false, occurrence: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            disabled={!modalRiderId}
            onClick={submitRowReassign}
          >
            Reassign
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default DeliveryAssignmentBoard