import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CFormInput, CFormLabel, CRow, CCol, CSpinner, CAlert, CFormTextarea, CFormSelect, CFormSwitch, CNav, CNavItem, CNavLink, CTabContent, CTabPane
} from '@coreui/react'
import { Plus, Trash2, ChevronUp, ChevronDown, X, Eye, EyeOff } from 'lucide-react'
import api from '../../api/api'

// ─────────────────────────────────────────────────────────────────────────
// WebBuilder.jsx — FINAL version with Preview Tab
// ─────────────────────────────────────────────────────────────────────────

const SectionCard = ({ title, children, onDelete }) => (
  <div className="p-3 mb-3 border rounded" style={{ background: '#fff' }}>
    <div className="d-flex justify-content-between mb-2">
      <h6 className="text-uppercase text-primary mb-0">{title}</h6>
      {onDelete && <CButton color="danger" size="sm" variant="ghost" onClick={onDelete}>Delete</CButton>}
    </div>
    {children}
  </div>
)

const defaultPages = {
  home: {
    carousel: { images: [] },
    hero: { alignment: 'center', badge: 'Hyperlocal & Daily', title: 'Daily Needs, Delivered Fresh', subtitle: 'Subscribe to milk, tiffin, and daily essentials.', primary_btn_text: 'Get Started', primary_btn_link: '/register', secondary_btn_text: 'Explore Services', secondary_btn_link: '/products' },
    mission: { title: 'Our Mission & Vision', mission_text: 'To provide customers with a convenient, secure, and enjoyable experience.', vision_text: 'To be the preferred subscription platform by delivering quality products.' },
    products: { title: 'Popular Products', view_all_text: 'View All', max_products: 20 }, // ★ ADDED
    categories: { title: 'Shop by Category' }, // ★ ADDED
    testimonials: { title: 'What our customers say', items: [{ name: 'Rahul S.', text: 'Best daily delivery service!', rating: 5 }] },
    cta: { title: 'Ready to simplify your life?', btn1_text: 'View Products', btn1_link: '/products', btn2_text: 'Order Now', btn2_link: '/subscription' },
    section_order: ['hero', 'carousel', 'mission', 'products', 'categories', 'testimonials', 'cta'], // ★ ADDED 'categories'
    section_visibility: {},
  },
  about: {
    hero: { alignment: 'center', badge: 'Our Story', title: 'About Us', subtitle: 'We are dedicated to providing fresh products, seamless daily subscriptions, and an exceptional doorstep delivery experience.' },
    story: { label: 'Our Story', title: 'Making Daily Essentials Simple & Reliable', desc1: 'Welcome to our platform.', desc2: "We believe that customer satisfaction is the foundation of a successful business.", stats: [{ n: '5k+', l: 'Happy Families' }, { n: '80+', l: 'Local Vendors' }] },
    mission: { label: 'Our Purpose', title: 'Our Mission & Vision', mission_title: 'To become a trusted daily needs destination.', mission_desc: 'Our mission is to provide customers with a convenient experience.', vision_title: 'To become a destination where customers discover local quality products.', vision_desc: 'Our vision is to be the preferred subscription platform.' },
    whyUs: { label: 'Why Choose Us', title: 'What sets us apart', subtitle: 'Years of local delivery experience.', items: [{ title: 'Deep Experience', desc: '10+ years delivering reliable daily services.' }] },
    cta: { label: 'Get In Touch', title: "Let's simplify your life together", subtitle: "Whether you're looking to subscribe or partner with us, we'd love to connect.", btn1_text: 'Partner with us', btn1_link: '/partner', btn2_text: 'View Our Services', btn2_link: '/products' },
    youtube_videos: [],
    section_order: ['hero', 'story', 'mission', 'whyUs', 'cta'],
    section_visibility: {},
  },
  contact: {
    hero: { alignment: 'center', badge: "We're Here to Help", title: 'Get in Touch with Us', subtitle: 'Have a question about your daily subscriptions or a recent order?' },
    info: { address: '', phone: '', email: '', hours: '' },
    whatsapp: { title: 'Need instant help?', desc: 'Skip the form and chat directly with our WhatsApp support team.', btn_text: 'Chat on WhatsApp', link: '' },
    section_order: ['hero', 'info', 'whatsapp'],
    section_visibility: {},
  },
  profile: {
    hero: { alignment: 'center', badge: 'My Account', title: 'Your Profile', subtitle: 'Manage your account, orders, and subscriptions in one place.' },
    banner: { enabled: true, text: 'Welcome back!', bg_color: '#FFF7ED', text_color: '#9A3412' },
    quickLinks: { title: 'Quick Links', show_orders: true, orders_label: 'My Orders', orders_desc: 'View order history', show_subscriptions: true, subscriptions_label: 'My Subscriptions', subscriptions_desc: 'Manage subscriptions', show_addresses: true, addresses_label: 'Addresses', addresses_desc: 'Saved delivery addresses' },
    customSection: { enabled: false, title: '', content: '' },
    cta: { enabled: false, title: 'Need help?', btn_text: 'Contact Support', btn_link: '/contact' },
    section_order: ['hero', 'banner', 'quickLinks', 'customSection', 'cta'],
    section_visibility: {},
  },
  subscriptions: {
    hero: { alignment: 'center', badge: 'My Subscriptions', title: 'Manage Your Subscriptions', subtitle: 'Pause, resume, or cancel your recurring deliveries here.' },
    emptyState: { icon: '🔁', title: 'No subscriptions yet', message: 'Subscribe to your favourite products and have them delivered on a schedule that works for you.', buttonText: 'Create your first subscription' },
    newButton: { text: '+ New Subscription' },
  },
  addresses: {
    hero: { alignment: 'center', badge: 'Saved Locations', title: 'Manage Delivery Addresses', subtitle: 'Pin your exact location on the map for accurate deliveries.' },
    emptyState: { icon: '📍', title: 'No addresses saved', message: 'Add a delivery address with pinpoint location for accurate deliveries.', buttonText: '+ Add Address' },
    newButton: { text: '+ Add New Address' },
  },
  privacy: {
    hero: {
      badge: 'Privacy Policy',
      title: 'How We Protect Your Data',
      subtitle: 'Your trust is important to us. Learn how we collect, use, and safeguard your personal and payment information.',
      last_updated: 'June 15, 2026',
    },
    intro: {
      title: 'Commitment to Privacy',
      content: 'We are committed to maintaining the confidentiality and security of your personal information. This Privacy Policy explains our practices regarding the collection, use, and disclosure of data when you use our daily subscription platform and related services.',
    },
    sections: [
      { id: 'collection', icon: 'Database', title: '1. Information We Collect', content: 'To provide our daily subscription and delivery services, we collect the following types of information:\n\n• Personal Details: Full name, phone number, and email address when you register.\n• Delivery Data: Exact delivery address, GPS location (if permitted), and delivery instructions.\n• Usage Data: Order history, subscription preferences, and interaction with our app.' },
      { id: 'usage', icon: 'Eye', title: '2. How We Use Your Data', content: 'We use the information we collect primarily to ensure seamless morning deliveries and reliable service:\n\n• To process and deliver your daily subscriptions (milk, tiffin, etc.).\n• To manage your Wallet and process automated deductions.\n• To send important updates like delivery status, low wallet balance alerts, and OTPs for secure login.\n• To improve our app\'s performance and customer support.' },
      { id: 'security', icon: 'CreditCard', title: '3. Data Security & Payments', content: 'Your financial security is our top priority.\n\n• We do not store your Credit/Debit card numbers or UPI PINs on our servers.\n• All online payments and wallet recharges are securely processed through our PCI-DSS compliant payment gateway partner.\n• Your personal data is encrypted and stored on secure cloud servers with restricted access.' },
      { id: 'sharing', icon: 'ShieldCheck', title: '4. Information Sharing', content: 'We do not sell your personal data to third-party marketers. However, we may share specific information under the following circumstances:\n\n• Delivery Partners: We share your name, phone number, and address with our local delivery executives solely for the purpose of fulfilling your order.\n• Legal Compliance: If required by law, court order, or government regulation to protect the rights and safety of our users.' },
      { id: 'rights', icon: 'UserCog', title: '5. Your Privacy Rights', content: 'You have full control over your personal data:\n\n• Access & Update: You can update your phone number, addresses, and subscription details anytime from your Profile Dashboard.\n• Account Deletion: You can request account deletion by contacting our support team. Upon deletion, any remaining wallet balance will be refunded, and your personal data will be erased from our active database (subject to legal retention requirements).' },
      { id: 'changes', icon: 'AlertCircle', title: '6. Policy Updates', content: 'We may update this Privacy Policy periodically to reflect changes in our practices or legal requirements. The updated version will be indicated by an updated "Last Modified" date at the top of this page. We encourage you to review this policy regularly.' },
    ],
    contact: {
      heading: 'Have Privacy Concerns?',
      text: 'If you have any questions about how we handle your data, please reach out.',
      email: 'privacy@example.com',
      btn_text: 'Email Privacy Officer',
    },

  },
    terms: {
    hero: { badge: 'Legal Information', title: 'Terms & Conditions', subtitle: 'Please read these terms and conditions carefully before using our platform.', last_updated: 'June 15, 2026' },
    intro: { title: 'Agreement to Terms', content: 'These Terms and Conditions constitute a legally binding agreement made between you, whether personally or on behalf of an entity ("you") and us ("we," "us" or "our"), concerning your access to and use of our platform and daily subscription services.' },
    sections: [
      { id: 'acceptance', icon: 'CheckCircle2', title: '1. Acceptance of Terms', content: 'By accessing and using our website and mobile application (collectively, the "Platform"), you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you must not use our services. These terms apply to all visitors, users, and others who access or use the Service.' },
      { id: 'accounts', icon: 'Shield', title: '2. User Accounts & Security', content: 'To use certain features like Subscriptions and Wallet, you must register for an account. You are responsible for safeguarding the password and OTPs that you use to access the Service. We reserve the right to suspend or terminate accounts if any information provided is proven to be inaccurate, false, or in violation of these Terms.' },
      { id: 'wallet', icon: 'Wallet', title: '3. Wallet & Auto-Pay', content: 'We operate on a prepaid wallet model for daily subscriptions. \n\n• Users must maintain a minimum balance to ensure uninterrupted daily deliveries.\n• Auto-pay will automatically deduct the daily service charge (e.g., milk, tiffin) from your wallet upon successful delivery.\n• Wallet balances are non-transferable but can be refunded to the original payment source upon account closure, subject to a processing time of 5-7 business days.' },
      { id: 'deliveries', icon: 'Truck', title: '4. Subscriptions & Deliveries', content: '• Morning deliveries (Milk, Newspaper, Flowers) are typically completed between 5:00 AM and 7:30 AM. \n• Users can pause or modify their daily subscription up until 9:00 PM the previous day. Changes made after the cutoff time will reflect on the subsequent day.\n• We act as an aggregator. While we strictly vet our local vendors for hygiene and quality, the respective vendors are ultimately responsible for the specific product quality.' },
      { id: 'cancellation', icon: 'RefreshCcw', title: '5. Refunds & Cancellations', content: '• If an order is not delivered or delivered in a damaged/spoiled condition, users must raise a complaint within 12 hours of the delivery schedule.\n• Verified complaints will result in a direct refund to the Wallet within 24 hours.\n• One-time orders (non-subscription) cannot be cancelled once they are out for delivery.' },
      { id: 'liability', icon: 'Scale', title: '6. Limitation of Liability', content: 'In no event shall we, nor our directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.' },
      { id: 'changes', icon: 'AlertCircle', title: '7. Changes to Terms', content: 'We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will notify users of any material changes via email or platform notifications. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.' },
    ],
    contact: { heading: 'Still have questions?', text: 'Our legal and support teams are here to help you understand our policies.', btn_text: 'Contact Support', btn_link: '/contact' },
  },
  orders: {
    hero: { alignment: 'center', badge: 'Order History', title: 'My Orders', subtitle: 'Track your orders and view past purchases.' },
    emptyState: { icon: '🛍️', title: 'No orders yet', message: 'When you place your first order, it will appear here.', buttonText: 'Browse Products' },
    section_order: ['hero', 'order_list'],
    section_visibility: {},
  },
    refund_policy: {
    label: 'Our Policy',
    title: 'Refunds & Cancellations',
    subtitle: 'Flexible cancellations and honest refunds — no fine-print surprises.',
    hero_icon: 'rotate',
    sections: [
      { icon: 'clock',  title: 'Cancel Before Cutoff',      desc: 'Pause or cancel any subscription till 9:00 PM the previous day. Changes made after cutoff apply from the next cycle.' },
      { icon: 'rotate', title: 'Full Subscription Control', desc: 'Skip a delivery, pause for a week, or cancel anytime from your dashboard — no calls, no emails needed.' },
      { icon: 'shield', title: 'Damaged or Missing Items',  desc: 'Report a damaged, spoiled, or missing item and we verify it with the vendor instantly.' },
      { icon: 'ban',    title: '24-Hour Reporting Window',  desc: 'Raise a complaint within 24 hours of the delivery slot so we can resolve it fairly.' },
      { icon: 'card',   title: '5–7 Day Refunds',           desc: 'Approved refunds are credited to your original payment method or wallet within 5–7 business days.' },
      { icon: 'chat',   title: 'How to Request a Refund',   desc: 'Open the order in Order History → Report Issue, or reach us on WhatsApp. Keep a photo handy for damaged items.' },
    ],
    note: 'Wallet refunds are instant once approved; bank/UPI refunds may take 5–7 business days depending on your bank.',
    cta: { title: 'Still need help with a refund?', subtitle: 'Our support team usually replies within a few hours.', btn_text: 'Contact Support', btn_link: '/contact' },
  },
  shipping_policy: {
    label: 'Delivery Info',
    title: 'Shipping Policy',
    subtitle: 'Fresh deliveries on your schedule — here is exactly how shipping works.',
    hero_icon: 'truck',
    sections: [
      { icon: 'pin',    title: 'Where We Deliver',            desc: 'We deliver across our serviceable hyperlocal zones. Enter your PIN at checkout to confirm availability.' },
      { icon: 'clock',  title: 'Order Cutoff Times',          desc: 'Orders placed before 9:00 PM are scheduled for the next delivery slot. After cutoff, they move to the following slot.' },
      { icon: 'truck',  title: 'Morning & Evening Slots',     desc: 'Morning essentials (milk, tiffin, newspaper) arrive 5:00–7:30 AM. Evening orders arrive 5:00–8:00 PM.' },
      { icon: 'wallet', title: 'Delivery Charges',            desc: 'Delivery is free above the minimum order value for your zone. Below it, a small flat fee applies — shown at checkout.' },
      { icon: 'box',    title: 'Fresh Packaging',             desc: 'Temperature-safe pouches for dairy, sealed tiffin boxes, and tamper-evident bags for groceries.' },
      { icon: 'bell',   title: 'Live Updates & Reattempts',   desc: 'Get notified when your order is out for delivery. Missed deliveries are automatically reattempted.' },
    ],
    note: 'Delivery timings may shift by 30–45 minutes on festival days and heavy-rain days.',
    cta: { title: 'Questions about your delivery?', subtitle: 'Track live orders in Order History or talk to us directly.', btn_text: 'Contact Support', btn_link: '/contact' },
  },

}

const DEFAULT_FOOTER = {
  enabled: true, bg_color: '#1E293B',
  // ★ NEW: media background fields
  bg_type: 'color',
  bg_image_url: '',
  bg_video_url: '',
  bg_overlay: 0.75,
  bg_video_poster: '',
  bg_video_loop: true,
  bg_video_mute: true,
  // ★ NEW: Text & Colors
  heading_color: '#FFFFFF',
  text_color: '#94A3B8',
  link_hover_color: '',
  copyright_color: '',
  border_color: '',
  // ★ NEW: Placement
  text_align: 'left',
  heading_align: '',
  heading_text_transform: 'uppercase',
  // ★ NEW: Social
  social_bg_color: '',
  social_hover_bg_color: '',
  social_icon_color: '#FFFFFF',
  columns: [
    { id: 'col1', title: '', type: 'text', content: '' },
    { id: 'col2', title: 'Quick Links', type: 'links', links: [{ label: 'Home', url: '/' }, { label: 'Products', url: '/products' }, { label: 'About', url: '/about' }] },
    { id: 'col3', title: 'Contact', type: 'links', links: [{ label: 'Contact Us', url: '/contact' }] },
  ],
  copyright: '',
  show_payment_badges: true, show_app_links: false,
}

const DEFAULT_NAVIGATION = {
  links: [
    { id: 'home', label: 'Home', url: '/', visible: true, order: 1 },
    { id: 'about', label: 'About Us', url: '/about', visible: true, order: 2 },
    { id: 'products', label: 'Products', url: '/products', visible: true, order: 3 },
    { id: 'subscription', label: 'Order Now', url: '/subscription', visible: true, order: 4 },
    { id: 'contact', label: 'Contact', url: '/contact', visible: true, order: 5 },
  ],
  navbar_style: 'solid', mobile_menu_style: 'drawer',
}
const DEFAULT_CART_SUGGESTIONS = {
  enabled: true,
  show_on_pdp: false,   // ★ NEW — also power the PDP "You May Also Like" section
  mode: 'auto',            // 'auto' = recently added | 'manual' = admin-picked
  max_items: 5,
  title: '',               // empty = default "You may also like"
  fill_with_recent: true,  // manual mode: top up empty slots with recent products
  items: [],               // manual: [{ product_id, variant_id (nullable) }]
}

const DEFAULT_PRODUCT_DISPLAY = {
  default_view: 'grid', products_per_row: 4,
  show_mrp: true, show_discount: true, show_rating: true, show_stock: true, show_unit: true,
  default_sort: 'name_asc', card_style: 'standard', quick_view: true,
  show_add_to_cart: true, show_wishlist: true, image_aspect: 'square', out_of_stock_behavior: 'dim',
}

const WebBuilder = () => {
  const [theme, setTheme] = useState({
    primary_color: '#666666', secondary_color: '#1E293B', font_family: 'Inter, sans-serif', logo_url: '', brand_name: '',
    border_radius: 12, shadow_style: 'medium', button_style: 'rounded', card_style: 'shadowed', typography_scale: 'normal', hero_style: 'solid', background_pattern: 'dotted',
  })
  const [pagesData, setPagesData] = useState(defaultPages)
  const [activePage, setActivePage] = useState('home')
  const [activeTab, setActiveTab] = useState('content')
  const [versionName, setVersionName] = useState('Multi-Page V1.0')
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [navigationConfig, setNavigationConfig] = useState(null)
  const [footerConfig, setFooterConfig] = useState(null)
  const [customPages, setCustomPages] = useState([])
  const [productDisplayConfig, setProductDisplayConfig] = useState(null)
  const [cartConfig, setCartConfig] = useState(null)
  const [productsList, setProductsList] = useState(null)
  const [productsLoading, setProductsLoading] = useState(false)
  const [productSearch, setProductSearch] = useState('')
  const [productExtras, setProductExtras] = useState({})   // ★ { [productId]: { reviews: [...] } }
  const [reviewProduct, setReviewProduct] = useState(null)
  const [reviewSearch, setReviewSearch] = useState('')
  const [productCategory, setProductCategory] = useState('')
  const [categoriesList, setCategoriesList] = useState(null)
useEffect(() => {
  if (!['cart', 'reviews'].includes(activeTab) || productsList || productsLoading) return   // ← keep YOUR existing trigger line
  setProductsLoading(true)
  api.get('masters/products', { params: { limit: 100, per_page: 100 } })   // ★ the route your drawer already uses
    .then(res => {
      const d = res.data?.data
      // handles: plain array, Laravel pagination ({data: {data: [...]}}), or {products: [...]}
      const list = Array.isArray(d) ? d : Array.isArray(d?.data) ? d.data : (res.data?.products || [])
      setProductsList(list)
    })
    .catch(() => setProductsList([]))
    .finally(() => setProductsLoading(false))
}, [activeTab])

  // ★ Categories for the cart picker
  useEffect(() => {
    if (activeTab !== 'cart' || categoriesList) return
    api.get('masters/categories')
      .then(res => {
        const d = res.data?.data
        const list = Array.isArray(d) ? d : Array.isArray(d?.data) ? d.data : (res.data?.categories || [])
        setCategoriesList(list)
      })
      .catch(() => setCategoriesList([]))
  }, [activeTab])

  useEffect(() => { fetchActiveLayout() }, [])

  const fetchActiveLayout = async () => {
    try {
      const res = await api.get('appsettings/web/layouts')
      const data = res.data?.data?.[0]
      if (data) {
        setTheme(prev => ({ ...prev, ...(data.theme_config || {}) }))
        setVersionName(data.version_name || 'Multi-Page V1.0')
        setNavigationConfig(data.navigation_config || null)
        setFooterConfig(data.footer_config || null)
        setCustomPages(data.custom_pages || [])
        setProductDisplayConfig(data.product_display_config || null)
        setCartConfig(data.product_display_config?.cart_suggestions || null)   
        if (data.layout_components && data.layout_components.length > 0) {
          const loadedPages = { ...defaultPages }
          data.layout_components.forEach(comp => {
            if (comp.page === 'product_extras') return   // ★ handled separately below
            if (loadedPages[comp.page]) loadedPages[comp.page] = { ...loadedPages[comp.page], ...comp.data }
            else loadedPages[comp.page] = comp.data
          })
          setPagesData(loadedPages)
          const extrasComp = data.layout_components.find(c => c.page === 'product_extras')   // ★ NEW
          if (extrasComp?.data) setProductExtras(extrasComp.data)                            // ★ NEW
        }
      }
    } catch (err) {} finally { setLoading(false) }
  }

  const handleSave = async (isDraft = false) => {
    setSaving(true); setError(null); setSuccess(null)
    try {
      const payload = {
        version_name: versionName, theme_config: theme,
        layout_components: [
          ...Object.keys(pagesData).map(pageName => ({ page: pageName, data: pagesData[pageName] })),
          { page: 'product_extras', data: productExtras || {} },   // ★ reviews ride here
        ],
        navigation_config: navigationConfig,
        footer_config: footerConfig,
        custom_pages: customPages,
        product_display_config: productDisplayConfig,
        product_display_config: {
          ...DEFAULT_PRODUCT_DISPLAY,
          ...(productDisplayConfig || {}),
          cart_suggestions: { ...DEFAULT_CART_SUGGESTIONS, ...(cartConfig || {}) },   // ★ cart settings ride inside here
        },
        is_draft: isDraft,
      }
      // ★ DIAGNOSTIC: log the payload to verify custom sections are included
      console.log('=== SAVE PAYLOAD ===');
      console.log('layout_components:', payload.layout_components);
      const homePage = payload.layout_components.find(c => c.page === 'home');
      if (homePage) {
        console.log('home section_order:', homePage.data.section_order);
        console.log('home custom sections:', Object.keys(homePage.data).filter(k => k.startsWith('custom-')));
      }
      console.log('Full payload size:', JSON.stringify(payload).length, 'bytes');
      await api.post('appsettings/web/layouts/save', payload)
      setSuccess(isDraft ? 'Draft saved!' : 'Published! Web portal updated.')
    } catch (err) { setError(err.response?.data?.message || 'Failed to save layout.') }
    finally { setSaving(false) }
  }

  const handleThemeChange = (field, value) => setTheme(prev => ({ ...prev, [field]: value }))
  const handleSectionChange = (page, section, field, value) => {
    setPagesData(prev => {
      const updatedPage = { ...prev[page] }
      if (field === null) delete updatedPage[section]
      else updatedPage[section] = { ...updatedPage[section], [field]: value }
      return { ...prev, [page]: updatedPage }
    })
  }
  const handleRestoreSections = () => setPagesData(prev => ({ ...prev, [activePage]: defaultPages[activePage] }))
  const handleImageUpload = async (e) => {
    const file = e.target.files[0]; if (!file) return
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const imageUrl = res.data?.data?.url
      if (imageUrl) setPagesData(prev => ({ ...prev, home: { ...prev.home, carousel: { ...prev.home.carousel, images: [...(prev.home.carousel?.images || []), imageUrl] } } }))
    } catch (err) { setError('Image upload failed.') }
  }

  // ★ Upload image for the About → Story section.
  // Accepts a File (from input or drop event), uploads it to the same
  // media endpoint, and stores the returned URL in pagesData.about.story.image_url.
    // ★ Hero background images — dedicated to the hero (separate from the carousel)
  const [heroImageUploading, setHeroImageUploading] = useState(false)
  const uploadHeroImage = async (e) => {
    const file = e.target.files[0]; if (!file) return
    if (!file.type.startsWith('image/')) { setError('Please choose an image file.'); return }
    setHeroImageUploading(true); setError(null)
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const imageUrl = res.data?.data?.url
      if (imageUrl) handleSectionChange('home', 'hero', 'images', [...(pagesData.home.hero?.images || []), imageUrl])
      else setError('Upload succeeded but no URL returned.')
    } catch (err) { setError('Hero image upload failed: ' + (err.response?.data?.message || err.message)) }
    finally { setHeroImageUploading(false) }
  }
  const removeHeroImage = (i) => {
    const imgs = [...(pagesData.home.hero?.images || [])]
    imgs.splice(i, 1)
    handleSectionChange('home', 'hero', 'images', imgs)
  }
    // ★ HERO BANNER SLIDES — per-slide image + text + color
  const heroSlideList = () => pagesData.home.hero?.slides || (pagesData.home.hero?.images || []).map((u) => ({ image_url: u }))
  const updateHeroSlides = (updater) => setPagesData(prev => {
    const slides = heroSlideList()
    return { ...prev, home: { ...prev.home, hero: { ...prev.home.hero, slides: updater(slides) } } }
  })
  const addHeroSlide = () => updateHeroSlides(list => [...list, { image_url: '', badge: '', title: '', subtitle: '', btn_text: '', btn_link: '', text_color: '' }])
  const updateHeroSlide = (index, field, value) => updateHeroSlides(list => list.map((s, i) => (i === index ? { ...s, [field]: value } : s)))
  const removeHeroSlide = (index) => updateHeroSlides(list => list.filter((_, i) => i !== index))
  const moveHeroSlide = (index, dir) => updateHeroSlides(list => {
    const ni = index + dir
    if (ni < 0 || ni >= list.length) return list
    const copy = [...list]
    ;[copy[index], copy[ni]] = [copy[ni], copy[index]]
    return copy
  })
  const [heroSlideUploading, setHeroSlideUploading] = useState(false)
  const uploadHeroSlideImage = async (index, file) => {
    if (!file) return
    if (!file.type.startsWith('image/')) { setError('Please choose an image file.'); return }
    setHeroSlideUploading(true); setError(null)
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const url = res.data?.data?.url
      if (url) updateHeroSlide(index, 'image_url', url)
      else setError('Upload succeeded but no URL returned.')
    } catch (err) { setError('Slide image upload failed: ' + (err.response?.data?.message || err.message)) }
    finally { setHeroSlideUploading(false) }
  }
  const [storyImageUploading, setStoryImageUploading] = useState(false)
  const uploadStoryImage = async (file) => {
    if (!file) return
    if (!file.type.startsWith('image/')) { setError('Please choose an image file.'); return }
    setStoryImageUploading(true); setError(null)
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const imageUrl = res.data?.data?.url
      if (imageUrl) handleSectionChange('about', 'story', 'image_url', imageUrl)
      else setError('Upload succeeded but no URL returned.')
    } catch (err) { setError('Story image upload failed: ' + (err.response?.data?.message || err.message)) }
    finally { setStoryImageUploading(false) }
  }

  // ★ Upload image/video for the footer background.
  const [footerMediaUploading, setFooterMediaUploading] = useState(false)
  const uploadFooterMedia = async (file, field) => {
    if (!file) return
    if (field === 'bg_image_url' && !file.type.startsWith('image/')) {
      setError('Please select an image file.'); return
    }
    if (field === 'bg_video_url' && !file.type.startsWith('video/')) {
      setError('Please select a video file.'); return
    }
    setFooterMediaUploading(true); setError(null)
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const url = res.data?.data?.url
      if (url) setFooterConfig(prev => ({ ...(prev || DEFAULT_FOOTER), [field]: url }))
      else setError('Upload succeeded but no URL returned.')
    } catch (err) { setError('Footer media upload failed: ' + (err.response?.data?.message || err.message)) }
    finally { setFooterMediaUploading(false) }
  }

  const handleAddTestimonial = () => { const items = [...(pagesData.home.testimonials?.items || [])]; items.push({ name: 'New Customer', text: 'Review text here...', rating: 5 }); handleSectionChange('home', 'testimonials', 'items', items) }
  const handleUpdateTestimonial = (index, field, value) => { const items = [...(pagesData.home.testimonials?.items || [])]; items[index] = { ...items[index], [field]: value }; handleSectionChange('home', 'testimonials', 'items', items) }
  const handleDeleteTestimonial = (index) => { const items = [...(pagesData.home.testimonials?.items || [])]; items.splice(index, 1); handleSectionChange('home', 'testimonials', 'items', items) }
  const handleMoveTestimonial = (index, direction) => { const items = [...(pagesData.home.testimonials?.items || [])]; const newIndex = index + direction; if (newIndex < 0 || newIndex >= items.length) return; [items[index], items[newIndex]] = [items[newIndex], items[index]]; handleSectionChange('home', 'testimonials', 'items', items) }

  // ★ About page — YouTube videos array management
  const addAboutVideo = () => {
    const videos = [...(pagesData.about?.youtube_videos || [])]
    videos.push({ youtube_url: '', title: '', caption: '', autoplay: false, loop: false, start_time: 0, alignment: 'left', layout: { width: 'contained', content_align: 'center', text_align: 'left' } })
    handleSectionChange('about', 'youtube_videos', null, null) // touch
    setPagesData(prev => ({ ...prev, about: { ...prev.about, youtube_videos: videos } }))
  }
  const updateAboutVideo = (index, field, value) => {
    const videos = [...(pagesData.about?.youtube_videos || [])]
    videos[index] = { ...videos[index], [field]: value }
    setPagesData(prev => ({ ...prev, about: { ...prev.about, youtube_videos: videos } }))
  }
  const updateAboutVideoLayout = (index, field, value) => {
    const videos = [...(pagesData.about?.youtube_videos || [])]
    videos[index] = { ...videos[index], layout: { ...(videos[index].layout || {}), [field]: value } }
    setPagesData(prev => ({ ...prev, about: { ...prev.about, youtube_videos: videos } }))
  }
  const deleteAboutVideo = (index) => {
    const videos = [...(pagesData.about?.youtube_videos || [])]
    videos.splice(index, 1)
    setPagesData(prev => ({ ...prev, about: { ...prev.about, youtube_videos: videos } }))
  }
  const moveAboutVideo = (index, direction) => {
    const videos = [...(pagesData.about?.youtube_videos || [])]
    const newIndex = index + direction
    if (newIndex < 0 || newIndex >= videos.length) return
    [videos[index], videos[newIndex]] = [videos[newIndex], videos[index]]
    setPagesData(prev => ({ ...prev, about: { ...prev.about, youtube_videos: videos } }))
  }

  // ★ Privacy page — sections array management
  const addPrivacySection = () => {
    const sections = [...(pagesData.privacy?.sections || [])]
    sections.push({ id: 'sec-' + Date.now(), icon: 'FileText', title: 'New Section', content: 'Enter your privacy policy content here...' })
    setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, sections } }))
  }
  const updatePrivacySection = (index, field, value) => {
    const sections = [...(pagesData.privacy?.sections || [])]
    sections[index] = { ...sections[index], [field]: value }
    setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, sections } }))
  }
  const deletePrivacySection = (index) => {
    const sections = [...(pagesData.privacy?.sections || [])]
    sections.splice(index, 1)
    setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, sections } }))
  }
  const movePrivacySection = (index, direction) => {
    const sections = [...(pagesData.privacy?.sections || [])]
    const newIndex = index + direction
    if (newIndex < 0 || newIndex >= sections.length) return
    [sections[index], sections[newIndex]] = [sections[newIndex], sections[index]]
    setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, sections } }))
  }

    // ★ Terms page — sections array management
  const addTermsSection = () => {
    const sections = [...(pagesData.terms?.sections || [])]
    sections.push({ id: 'terms-' + Date.now(), icon: 'FileText', title: 'New Section', content: 'Enter your terms content here...' })
    setPagesData(prev => ({ ...prev, terms: { ...prev.terms, sections } }))
  }
  const updateTermsSection = (index, field, value) => {
    const sections = [...(pagesData.terms?.sections || [])]
    sections[index] = { ...sections[index], [field]: value }
    setPagesData(prev => ({ ...prev, terms: { ...prev.terms, sections } }))
  }
  const deleteTermsSection = (index) => {
    const sections = [...(pagesData.terms?.sections || [])]
    sections.splice(index, 1)
    setPagesData(prev => ({ ...prev, terms: { ...prev.terms, sections } }))
  }
  const moveTermsSection = (index, direction) => {
    const sections = [...(pagesData.terms?.sections || [])]
    const newIndex = index + direction
    if (newIndex < 0 || newIndex >= sections.length) return
    ;[sections[index], sections[newIndex]] = [sections[newIndex], sections[index]]
    setPagesData(prev => ({ ...prev, terms: { ...prev.terms, sections } }))
  }
    // ★ Policy pages (Refunds / Shipping) — flat field editor + sections array management
  const handlePageFieldChange = (page, field, value) =>
    setPagesData(prev => ({ ...prev, [page]: { ...prev[page], [field]: value } }))

  const addPolicySection = (pageKey, defaultIcon) => setPagesData(prev => ({
    ...prev, [pageKey]: { ...prev[pageKey], sections: [...(prev[pageKey]?.sections || []), { icon: defaultIcon, title: 'New Section', desc: 'Enter your content here...' }] },
  }))
  const updatePolicySection = (pageKey, index, field, value) => setPagesData(prev => {
    const sections = [...(prev[pageKey]?.sections || [])]
    sections[index] = { ...sections[index], [field]: value }
    return { ...prev, [pageKey]: { ...prev[pageKey], sections } }
  })
  const deletePolicySection = (pageKey, index) => setPagesData(prev => {
    const sections = [...(prev[pageKey]?.sections || [])]
    sections.splice(index, 1)
    return { ...prev, [pageKey]: { ...prev[pageKey], sections } }
  })
  const movePolicySection = (pageKey, index, direction) => setPagesData(prev => {
    const sections = [...(prev[pageKey]?.sections || [])]
    const newIndex = index + direction
    if (newIndex < 0 || newIndex >= sections.length) return prev
    ;[sections[index], sections[newIndex]] = [sections[newIndex], sections[index]]
    return { ...prev, [pageKey]: { ...prev[pageKey], sections } }
  })

  const handleAddSection = () => {
    const sectionTypes = [
      { type: 'text_block', label: 'Text Block', data: { title: 'New Section', content: 'Enter your content here...', alignment: 'left', bg_color: '#fff' } },
      { type: 'image_block', label: 'Image Block (Carousel/Full-width)', data: { image_url: [], alt_text: '', bg_color: '#fff' } },
      { type: 'spacer', label: 'Spacer', data: { height: 40 } },
      { type: 'divider', label: 'Divider', data: { color: '#E2E8F0', thickness: 1 } },
      { type: 'html_block', label: 'HTML Block', data: { html: '<p>Custom HTML</p>' } },
      { type: 'subscription_products', label: 'Subscription Products', data: { title: 'Subscribe & Save', subtitle: 'Daily essentials, delivered on your schedule', limit: 8, button_text: 'Subscribe', view_all_link: '/subscription/products' } },      { type: 'youtube_video', label: 'YouTube Video', data: { youtube_url: '', title: '', caption: '', autoplay: false, loop: false, start_time: 0, alignment: 'left' }, layout: { width: 'full', content_align: 'center', text_align: 'left' } },
      { type: 'media_carousel', label: 'Media Carousel (Images + Videos)', data: { items: [], height: 'medium', object_fit: 'cover', interval_seconds: 5 }, layout: { width: 'full', content_align: 'center', text_align: 'left' } },
    ]
    const options = sectionTypes.map((s, i) => `${i + 1}. ${s.label}`).join('\n')
    const choice = prompt(`Add new section:\n\n${options}\n\nEnter number (1-${sectionTypes.length}):`, '1')
    const idx = parseInt(choice) - 1
    if (idx < 0 || idx >= sectionTypes.length) return
    const newSection = sectionTypes[idx]
    const sectionId = 'custom-' + Date.now()
    setPagesData(prev => {
      const pageData = { ...prev[activePage] }
      pageData[sectionId] = { ...newSection.data, type: newSection.type }
      pageData.section_order = [...(pageData.section_order || []), sectionId]
      pageData.section_visibility = { ...(pageData.section_visibility || {}), [sectionId]: true }
      return { ...prev, [activePage]: pageData }
    })
  }

  const handleMoveSection = (index, direction) => {
    setPagesData(prev => {
      const pageData = { ...prev[activePage] }
      const order = [...(pageData.section_order || [])]
      const newIndex = index + direction
      if (newIndex < 0 || newIndex >= order.length) return prev
        ;[order[index], order[newIndex]] = [order[newIndex], order[index]]
      pageData.section_order = order
      return { ...prev, [activePage]: pageData }
    })
  }

  const handleToggleSectionVisibility = (sectionKey) => {
    setPagesData(prev => {
      const pageData = { ...prev[activePage] }
      const visibility = { ...(pageData.section_visibility || {}) }
      visibility[sectionKey] = visibility[sectionKey] === false ? true : false
      pageData.section_visibility = visibility
      return { ...prev, [activePage]: pageData }
    })
  }

  const handleDeleteSection = (sectionKey) => {
    if (!confirm('Delete this section?')) return
    setPagesData(prev => {
      const pageData = { ...prev[activePage] }
      delete pageData[sectionKey]
      pageData.section_order = (pageData.section_order || []).filter(k => k !== sectionKey)
      if (pageData.section_visibility) delete pageData.section_visibility[sectionKey]
      return { ...prev, [activePage]: pageData }
    })
  }

  const handleCustomSectionChange = (sectionKey, field, value) => {
    setPagesData(prev => {
      const pageData = { ...prev[activePage] }
      pageData[sectionKey] = { ...pageData[sectionKey], [field]: value }
      return { ...prev, [activePage]: pageData }
    })
  }

  const updateProductDisplay = (field, value) => setProductDisplayConfig(prev => ({ ...(prev || DEFAULT_PRODUCT_DISPLAY), [field]: value }))
  const updateCartConfig = (field, value) => setCartConfig(prev => ({ ...(prev || DEFAULT_CART_SUGGESTIONS), [field]: value }))
const toggleCartProduct = (productId) => setCartConfig(prev => {
  const cfg = { ...(prev || DEFAULT_CART_SUGGESTIONS) }
  const items = [...(cfg.items || [])]
  const idx = items.findIndex(i => i.product_id === productId)
  if (idx >= 0) items.splice(idx, 1); else items.push({ product_id: productId, variant_id: null })
  cfg.items = items
  return cfg
})
const setCartVariant = (productId, variantId) => setCartConfig(prev => ({
  ...(prev || DEFAULT_CART_SUGGESTIONS),
  items: (prev?.items || []).map(i => i.product_id === productId ? { ...i, variant_id: variantId } : i),
}))
const moveCartItem = (index, dir) => setCartConfig(prev => {
  const items = [...(prev?.items || [])]
  const ni = index + dir
  if (ni < 0 || ni >= items.length) return prev
  ;[items[index], items[ni]] = [items[ni], items[index]]
  return { ...(prev || DEFAULT_CART_SUGGESTIONS), items }
})
const removeCartItem = (productId) => setCartConfig(prev => ({
  ...(prev || DEFAULT_CART_SUGGESTIONS),
  items: (prev?.items || []).filter(i => i.product_id !== productId),
}))
  // ★ Product reviews helpers
  const reviewsFor = (pid) => (productExtras[pid]?.reviews || [])
  const updateReviews = (productId, updater) => setProductExtras(prev => ({
    ...prev,
    [productId]: { ...(prev[productId] || {}), reviews: updater(prev[productId]?.reviews || []) },
  }))
  const addReview = (productId) => updateReviews(productId, (list) => [...list, { name: 'New Customer', rating: 5, text: '' }])
  const updateReview = (productId, index, field, value) => updateReviews(productId, (list) => list.map((r, i) => (i === index ? { ...r, [field]: value } : r)))
  const deleteReview = (productId, index) => updateReviews(productId, (list) => list.filter((_, i) => i !== index))
  const moveReview = (productId, index, dir) => updateReviews(productId, (list) => {
    const ni = index + dir
    if (ni < 0 || ni >= list.length) return list
    const copy = [...list]
    ;[copy[index], copy[ni]] = [copy[ni], copy[index]]
    return copy
  })
    // ★ Review photos — upload via the same media endpoint as carousel/footer
  const [reviewImgUploading, setReviewImgUploading] = useState(false)
  const uploadReviewImage = async (productId, index, file) => {
    if (!file) return
    if (!file.type.startsWith('image/')) { setError('Please choose an image file.'); return }
    setReviewImgUploading(true); setError(null)
    const formData = new FormData(); formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const url = res.data?.data?.url
      if (url) updateReviews(productId, (list) => list.map((r, i) => (i === index ? { ...r, images: [...(r.images || []), url] } : r)))
      else setError('Upload succeeded but no URL returned.')
    } catch (err) { setError('Review image upload failed: ' + (err.response?.data?.message || err.message)) }
    finally { setReviewImgUploading(false) }
  }
  const removeReviewImage = (productId, index, imgIdx) => updateReviews(productId, (list) =>
    list.map((r, i) => (i === index ? { ...r, images: (r.images || []).filter((_, j) => j !== imgIdx) } : r))
  )

  if (loading) return <div className="text-center py-5"><CSpinner color="primary" /></div>

  const p = pagesData[activePage] || {}
  const hero = p.hero || {}
  const carouselImages = p.carousel?.images || []
  const mission = p.mission || {}
  const testimonials = p.testimonials || {}
  const cta = p.cta || {}
  const info = p.info || {}
  const whatsapp = p.whatsapp || {}
  const story = p.story || {}
  const whyUs = p.whyUs || {}
  const banner = p.banner || {}
  const quickLinks = p.quickLinks || {}
  const customSection = p.customSection || {}
  const emptyState = p.emptyState || {}
  const newButton = p.newButton || {}

  const sectionLabels = {
    hero: 'Hero Section', carousel: 'Carousel', mission: 'Mission & Vision', testimonials: 'Testimonials',
    cta: 'Call to Action', story: 'Story', whyUs: 'Why Choose Us', info: 'Contact Info',
    whatsapp: 'WhatsApp CTA', banner: 'Welcome Banner', quickLinks: 'Quick Links', customSection: 'Custom Section',
    products: 'Products Grid',
    categories: 'Category Tiles',
  }

  const renderAlignButtons = (page, section, current) =>
    ['left', 'center', 'right'].map(align => (<CButton key={align} color={current === align ? 'primary' : 'outline-secondary'} size="sm" onClick={() => handleSectionChange(page, section, 'alignment', align)}>{align.charAt(0).toUpperCase() + align.slice(1)}</CButton>))

  const renderCustomSectionEditor = (sectionKey) => {
    const sectionData = p[sectionKey] || {}
    const sectionType = sectionData.type || 'text_block'
    return (
      <SectionCard
        title={`Custom: ${sectionData.title || sectionType}`}
        onDelete={() => handleDeleteSection(sectionKey)}
      >
        <CFormLabel>Type</CFormLabel>
        <CFormSelect value={sectionType} onChange={(e) => handleCustomSectionChange(sectionKey, 'type', e.target.value)} className="mb-2">
          <option value="text_block">Text Block</option>
          <option value="image_block">Image Block (Carousel/Full-width)</option>
          <option value="spacer">Spacer</option>
          <option value="divider">Divider</option>
          <option value="html_block">HTML Block</option>
          <option value="subscription_products">Subscription Products</option>
          <option value="youtube_video">YouTube Video</option>
          <option value="media_carousel">Media Carousel (Images + Videos)</option>
        </CFormSelect>

        {sectionType === 'text_block' && (
          <>
            <CFormLabel>Title</CFormLabel>
            <CFormInput value={sectionData.title || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'title', e.target.value)} className="mb-2" />
            <CFormLabel>Content</CFormLabel>
            <CFormTextarea value={sectionData.content || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'content', e.target.value)} rows={3} className="mb-2" />
            <CFormLabel>Alignment</CFormLabel>
            <div className="d-flex gap-2 mb-2">{renderAlignButtons(activePage, sectionKey, sectionData.alignment)}</div>
            <CFormLabel>Background Color</CFormLabel>
            <div className="d-flex gap-2"><input type="color" value={sectionData.bg_color || '#fff'} onChange={(e) => handleCustomSectionChange(sectionKey, 'bg_color', e.target.value)} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={sectionData.bg_color || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'bg_color', e.target.value)} /></div>
          </>
        )}

        {sectionType === 'image_block' && (
          <>
            <CFormLabel>Image URLs (one per line for carousel, or single for full-width)</CFormLabel>
            <CFormTextarea
              value={Array.isArray(sectionData.image_url) ? sectionData.image_url.join('\n') : (sectionData.image_url || '')}
              onChange={(e) => {
                const urls = e.target.value.split('\n').filter(Boolean);
                handleCustomSectionChange(sectionKey, 'image_url', urls.length === 1 ? urls[0] : urls);
              }}
              rows={3}
              className="mb-2"
              placeholder="https://image1.jpg&#10;https://image2.jpg"
            />
            <small className="text-muted d-block mb-2">Enter multiple URLs (one per line) to create a carousel. Enter one URL for a full-width image.</small>
            <CFormLabel>Alt Text</CFormLabel>
            <CFormInput value={sectionData.alt_text || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'alt_text', e.target.value)} className="mb-2" />
          </>
        )}

        {sectionType === 'spacer' && (
          <>
            <CFormLabel>Height (px)</CFormLabel>
            <CFormInput type="number" value={sectionData.height || 40} onChange={(e) => handleCustomSectionChange(sectionKey, 'height', parseInt(e.target.value))} style={{ width: 120 }} />
          </>
        )}

        {sectionType === 'divider' && (
          <div className="d-flex gap-2">
            <div><CFormLabel>Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={sectionData.color || '#E2E8F0'} onChange={(e) => handleCustomSectionChange(sectionKey, 'color', e.target.value)} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={sectionData.color || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'color', e.target.value)} /></div></div>
            <div><CFormLabel>Thickness</CFormLabel><CFormInput type="number" value={sectionData.thickness || 1} onChange={(e) => handleCustomSectionChange(sectionKey, 'thickness', parseInt(e.target.value))} style={{ width: 100 }} /></div>
          </div>
        )}

        {sectionType === 'html_block' && (
          <>
            <CFormLabel>HTML Code</CFormLabel>
            <CFormTextarea value={sectionData.html || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'html', e.target.value)} rows={5} style={{ fontFamily: 'monospace', fontSize: '0.85rem' }} />
          </>
        )}

        {sectionType === 'subscription_products' && (
  <>
    <CFormLabel>Title</CFormLabel>
    <CFormInput value={sectionData.title || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'title', e.target.value)} className="mb-2" />
    <CFormLabel>Subtitle</CFormLabel>
    <CFormInput value={sectionData.subtitle || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'subtitle', e.target.value)} className="mb-2" />
    <CFormLabel>Max Products</CFormLabel>
    <CFormInput type="number" value={sectionData.limit ?? 8} onChange={(e) => handleCustomSectionChange(sectionKey, 'limit', parseInt(e.target.value) || 8)} className="mb-2" style={{ width: 120 }} />
    <CFormLabel>Button Text</CFormLabel>
    <CFormInput value={sectionData.button_text || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'button_text', e.target.value)} className="mb-2" placeholder="Subscribe" />
    <CFormLabel>View All Link</CFormLabel>
    <CFormInput value={sectionData.view_all_link || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'view_all_link', e.target.value)} className="mb-2" placeholder="/subscription/products" />
    <small className="text-muted d-block">Products are pulled automatically from the subscription channel of your catalog — no manual picking needed.</small>
  </>
)}

        {sectionType === 'media_carousel' && (
          <>
            <small className='text-muted d-block mb-2'>Add images and/or videos. Image slides show text overlay; video slides show just the video and auto-advance when it ends.</small>
            <CFormLabel>Items ({(sectionData.items || []).length})</CFormLabel>
            <CButton color='success' size='sm' variant='outline' className='mb-2 ms-2' onClick={() => handleCustomSectionChange(sectionKey, 'items', [...(sectionData.items || []), { id: 'item-' + Date.now(), type: 'image', url: '', title: '', subtitle: '', badge: '', btn_text: '', btn_link: '' }])}><Plus size={12} className='me-1' /> Add Item</CButton>
            {(sectionData.items || []).map((item, itemIdx) => (
              <div key={itemIdx} className='p-3 mb-2 border rounded bg-light'>
                <div className='d-flex justify-content-between align-items-center mb-2'>
                  <span className='badge bg-secondary'>Item {itemIdx + 1}: {item.type || 'image'}</span>
                  <div className='d-flex gap-1'>
                    <CButton color='light' size='sm' disabled={itemIdx === 0} onClick={() => { const items = [...(sectionData.items || [])]; [items[itemIdx - 1], items[itemIdx]] = [items[itemIdx], items[itemIdx - 1]]; handleCustomSectionChange(sectionKey, 'items', items); }}><ChevronUp size={12} /></CButton>
                    <CButton color='light' size='sm' disabled={itemIdx === (sectionData.items || []).length - 1} onClick={() => { const items = [...(sectionData.items || [])]; [items[itemIdx], items[itemIdx + 1]] = [items[itemIdx + 1], items[itemIdx]]; handleCustomSectionChange(sectionKey, 'items', items); }}><ChevronDown size={12} /></CButton>
                    <CButton color='danger' size='sm' variant='ghost' onClick={() => { const items = (sectionData.items || []).filter((_, i) => i !== itemIdx); handleCustomSectionChange(sectionKey, 'items', items); }}><Trash2 size={12} /></CButton>
                  </div>
                </div>
                <CRow className='mb-2'>
                  <CCol xs={4}><CFormLabel className='small mb-0'>Type</CFormLabel><CFormSelect size='sm' value={item.type || 'image'} onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, type: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }}><option value='image'>Image</option><option value='video'>Video</option></CFormSelect></CCol>
                  <CCol xs={8}><CFormLabel className='small mb-0'>URL</CFormLabel><CFormInput value={item.url || ''} size='sm' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, url: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} placeholder='https://...' /></CCol>
                </CRow>
                {item.type === 'image' && (
                  <>
                    <CRow className='mb-1'>
                      <CCol xs={6}><CFormInput value={item.badge || ''} size='sm' className='mb-1' placeholder='Badge (optional)' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, badge: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} /></CCol>
                      <CCol xs={6}><CFormInput value={item.title || ''} size='sm' className='mb-1' placeholder='Title (optional)' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, title: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} /></CCol>
                    </CRow>
                    <CFormTextarea value={item.subtitle || ''} size='sm' className='mb-1' placeholder='Subtitle (optional)' rows={1} onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, subtitle: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} />
                    <CRow>
                      <CCol xs={6}><CFormInput value={item.btn_text || ''} size='sm' placeholder='Button text' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, btn_text: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} /></CCol>
                      <CCol xs={6}><CFormInput value={item.btn_link || ''} size='sm' placeholder='Button link (e.g. /products)' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, btn_link: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} /></CCol>
                    </CRow>
                  </>
                )}
                {item.type === 'video' && (
                  <CFormInput value={item.poster || ''} size='sm' placeholder='Poster image URL (optional — shown before video loads)' onChange={(e) => { const items = [...(sectionData.items || [])]; items[itemIdx] = { ...item, poster: e.target.value }; handleCustomSectionChange(sectionKey, 'items', items); }} />
                )}
              </div>
            ))}
            <CRow className='mt-2'>
              <CCol xs={4}><CFormLabel className='small mb-0'>Height</CFormLabel><CFormSelect size='sm' value={sectionData.height || 'medium'} onChange={(e) => handleCustomSectionChange(sectionKey, 'height', e.target.value)}><option value='small'>Small (300px)</option><option value='medium'>Medium (450px)</option><option value='large'>Large (600px)</option><option value='full'>Full (100vh)</option></CFormSelect></CCol>
              <CCol xs={4}><CFormLabel className='small mb-0'>Object Fit</CFormLabel><CFormSelect size='sm' value={sectionData.object_fit || 'cover'} onChange={(e) => handleCustomSectionChange(sectionKey, 'object_fit', e.target.value)}><option value='cover'>Cover (crop)</option><option value='contain'>Contain (no crop)</option><option value='fill'>Fill (stretch)</option></CFormSelect></CCol>
              <CCol xs={4}><CFormLabel className='small mb-0'>Interval (sec)</CFormLabel><CFormInput type='number' size='sm' value={sectionData.interval_seconds || 5} onChange={(e) => handleCustomSectionChange(sectionKey, 'interval_seconds', parseInt(e.target.value) || 5)} /></CCol>
            </CRow>
          </>
        )}

        {sectionType === 'youtube_video' && (
          <>
            <CFormLabel>YouTube URL</CFormLabel>
            <CFormInput value={sectionData.youtube_url || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'youtube_url', e.target.value)} className="mb-2" placeholder="https://www.youtube.com/watch?v=..." />
            <small className="text-muted d-block mb-2">Paste any YouTube link — watch?v=, youtu.be/, /embed/, /shorts/, /live/ all work.</small>
            <CFormLabel>Title (optional)</CFormLabel>
            <CFormInput value={sectionData.title || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'title', e.target.value)} className="mb-2" placeholder="Video title shown above the player" />
            <CFormLabel>Caption (optional)</CFormLabel>
            <CFormInput value={sectionData.caption || ''} onChange={(e) => handleCustomSectionChange(sectionKey, 'caption', e.target.value)} className="mb-2" placeholder="Short text below the video" />
            <CFormLabel>Title / Caption Alignment</CFormLabel>
            <div className="d-flex gap-2 mb-2">{renderAlignButtons(activePage, sectionKey, sectionData.alignment)}</div>
            <CRow className="mb-2">
              <CCol xs={4}><div className="d-flex align-items-center gap-2"><CFormSwitch checked={sectionData.autoplay || false} onChange={(e) => handleCustomSectionChange(sectionKey, 'autoplay', e.target.checked)} /><small>Autoplay</small></div></CCol>
              <CCol xs={4}><div className="d-flex align-items-center gap-2"><CFormSwitch checked={sectionData.loop || false} onChange={(e) => handleCustomSectionChange(sectionKey, 'loop', e.target.checked)} /><small>Loop</small></div></CCol>
              <CCol xs={4}><CFormLabel className="mb-0 small">Start at (sec)</CFormLabel><CFormInput type="number" value={sectionData.start_time || 0} onChange={(e) => handleCustomSectionChange(sectionKey, 'start_time', parseInt(e.target.value) || 0)} size="sm" style={{ width: 90 }} /></CCol>
            </CRow>
            <div className="p-2 mt-2 border rounded bg-light"><small className="fw-bold text-muted d-block mb-2">🎨 Video Placement</small><CRow className="mb-2"><CCol xs={12}><CFormLabel className="mb-0 small">Width</CFormLabel><CFormSelect size="sm" value={sectionData.layout?.width || "full"} onChange={(e) => handleCustomSectionChange(sectionKey, 'layout', { ...(sectionData.layout || {}), width: e.target.value })}><option value="full">Full Width (100%)</option><option value="contained">Contained Block (800px)</option><option value="half">Half Width (50% — side-by-side)</option></CFormSelect></CCol></CRow><CRow className="mb-2"><CCol xs={6}><CFormLabel className="mb-0 small">Video Position</CFormLabel><CFormSelect size="sm" value={sectionData.layout?.content_align || "center"} onChange={(e) => handleCustomSectionChange(sectionKey, 'layout', { ...(sectionData.layout || {}), content_align: e.target.value })}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol><CCol xs={6}><CFormLabel className="mb-0 small">Title/Caption Align</CFormLabel><CFormSelect size="sm" value={sectionData.alignment || "left"} onChange={(e) => handleCustomSectionChange(sectionKey, 'alignment', e.target.value)}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol></CRow><small className="text-muted d-block mt-1">Tip: Set Width=Half + Position=Left to place the video on the left half of the page. Two consecutive Half sections sit side-by-side.</small></div>
            {sectionData.youtube_url && (
              <div className="p-2 mt-2 bg-light rounded border">
                <small className="text-muted d-block mb-1">Preview (16:9):</small>
                <div style={{ position: 'relative', paddingTop: '56.25%', background: '#000', borderRadius: 6, overflow: 'hidden' }}>
                  <iframe src={'https://www.youtube.com/embed/' + ((m) => (m ? m[1] : ''))((sectionData.youtube_url.match(/(?:youtu\.be\/|[?&]v=|youtube\.com\/(?:embed|shorts|live)\/)([A-Za-z0-9_-]{6,})/))) + (sectionData.autoplay ? '?autoplay=1&mute=1' : '')} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0 }} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title="preview" />
                </div>
              </div>
            )}
          </>
        )}
      </SectionCard>
    )
  }

  const pdCfg = { ...DEFAULT_PRODUCT_DISPLAY, ...(productDisplayConfig || {}) }
  const cartCfg = { ...DEFAULT_CART_SUGGESTIONS, ...(cartConfig || {}) }
  const categoryOptions = (categoriesList && categoriesList.length)
    ? categoriesList.map(c => ({ id: c.id, name: c.name || c.category_name || c.title || `#${c.id}` }))
    : [...new Set((productsList || []).map(p => p.category_name).filter(Boolean))].sort().map(n => ({ id: n, name: n }))  

  return (
    <>
      <div className="admin-page-shell__heading mb-4 p-1">
        <div><h4 className="mb-0">Web Portal Customizer</h4><small className="admin-page-note">Edit content for all customer-facing pages.</small></div>
        <div className="d-flex gap-2">
          <CButton color="secondary" size="sm" onClick={() => handleSave(true)} disabled={saving}>Save Draft</CButton>
          <CButton color="success" size="sm" onClick={() => handleSave(false)} disabled={saving}>{saving ? <CSpinner size="sm" className="me-2" /> : 'Publish Live'}</CButton>
        </div>
      </div>

      {error && <CAlert color="danger" dismissible onClose={() => setError(null)} className="mb-4">{error}</CAlert>}
      {success && <CAlert color="success" dismissible onClose={() => setSuccess(null)} className="mb-4">{success}</CAlert>}

      <CNav variant="tabs" className="mb-3">
        <CNavItem><CNavLink active={activeTab === 'content'} onClick={() => setActiveTab('content')}>📄 Content</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'theme'} onClick={() => setActiveTab('theme')}>🎨 Theme</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'nav'} onClick={() => setActiveTab('nav')}>🧭 Navigation</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'footer'} onClick={() => setActiveTab('footer')}>🦶 Footer</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'products'} onClick={() => setActiveTab('products')}>📦 Products</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'cart'} onClick={() => setActiveTab('cart')}>🛒 Cart</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'reviews'} onClick={() => setActiveTab('reviews')}>⭐ Reviews</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'pages'} onClick={() => setActiveTab('pages')}>📋 Custom Pages</CNavLink></CNavItem>
        <CNavItem><CNavLink active={activeTab === 'preview'} onClick={() => setActiveTab('preview')}>🖥️ Preview</CNavLink></CNavItem>
      </CNav>

      <CTabContent>
        <CTabPane visible={activeTab === 'content'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center">
              <strong>Page Content</strong>
              <div className="d-flex gap-2 align-items-center">
                <CFormSelect value={activePage} onChange={(e) => setActivePage(e.target.value)} style={{ width: 'auto' }}>
                  <option value="home">Home Page</option><option value="about">About Page</option><option value="contact">Contact Page</option><option value="profile">Profile Page</option><option value="subscriptions">Subscriptions Page</option><option value="addresses">Addresses Page</option><option value="orders">Orders Page</option><option value="privacy">Privacy Page</option><option value="terms">T&C Page</option><option value="refund_policy">Refunds Policy Page</option><option value="shipping_policy">Shipping Policy Page</option>
                </CFormSelect>
                <CButton color="warning" size="sm" variant="outline" onClick={handleRestoreSections}>Restore</CButton>
              </div>
            </CCardHeader>
            <CCardBody>
              {['home', 'about', 'contact', 'profile'].includes(activePage) && (
                <div className="p-3 mb-3 border rounded" style={{ background: '#f0f7ff', borderColor: '#93c5fd' }}>
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h6 className="text-uppercase text-primary mb-0">📋 Section Order & Visibility</h6>
                    <CButton color="success" size="sm" onClick={handleAddSection}><Plus size={14} className="me-1" /> Add Section</CButton>
                  </div>
                  {(p.section_order || []).map((sectionKey, index) => {
                    const label = sectionLabels[sectionKey] || (sectionKey.startsWith('custom-') ? `Custom: ${p[sectionKey]?.title || p[sectionKey]?.type || 'Section'}` : sectionKey)
                    const isVisible = (p.section_visibility || {})[sectionKey] !== false
                    return (
                      <div key={sectionKey} className="d-flex align-items-center justify-content-between p-2 mb-1 bg-white rounded" style={{ border: '1px solid #e2e8f0' }}>
                        <div className="d-flex align-items-center gap-2">
                          <span className="badge bg-secondary">{index + 1}</span>
                          <span style={{ fontSize: '0.85rem', fontWeight: 600, color: isVisible ? '#1E293B' : '#94A3B8', textDecoration: isVisible ? 'none' : 'line-through' }}>{label}</span>
                        </div>
                        <div className="d-flex gap-1">
                          <CButton color="light" size="sm" disabled={index === 0} onClick={() => handleMoveSection(index, -1)} title="Move up"><ChevronUp size={14} /></CButton>
                          <CButton color="light" size="sm" disabled={index === (p.section_order || []).length - 1} onClick={() => handleMoveSection(index, 1)} title="Move down"><ChevronDown size={14} /></CButton>
                          <CButton color="light" size="sm" onClick={() => handleToggleSectionVisibility(sectionKey)} title={isVisible ? 'Hide' : 'Show'}>{isVisible ? <Eye size={14} /> : <EyeOff size={14} />}</CButton>
                          {sectionKey.startsWith('custom-') && <CButton color="danger" size="sm" variant="ghost" onClick={() => handleDeleteSection(sectionKey)} title="Delete"><Trash2 size={14} /></CButton>}
                        </div>
                      </div>
                    )
                  })}
                  <small className="text-muted d-block mt-2">↑ Reorder sections. Click eye to show/hide. Custom sections can be deleted.</small>
                </div>
              )}
                            {activePage === 'terms' && (
                <>
                  <SectionCard title="Hero Section">
              
                    <CFormLabel>Badge Text</CFormLabel>
                    <CFormInput value={p.hero?.badge || ''} onChange={(e) => handleSectionChange('terms', 'hero', 'badge', e.target.value)} className="mb-2" />
                    <CFormLabel>Title</CFormLabel>
                    <CFormInput value={p.hero?.title || ''} onChange={(e) => handleSectionChange('terms', 'hero', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Subtitle</CFormLabel>
                    <CFormTextarea value={p.hero?.subtitle || ''} onChange={(e) => handleSectionChange('terms', 'hero', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                    <CFormLabel>Last Updated</CFormLabel>
                    <CFormInput value={p.hero?.last_updated || ''} onChange={(e) => handleSectionChange('terms', 'hero', 'last_updated', e.target.value)} />
                  </SectionCard>

                  <SectionCard title="Intro (Agreement Block)">
                    <CFormLabel>Title</CFormLabel>
                    <CFormInput value={p.intro?.title || ''} onChange={(e) => handleSectionChange('terms', 'intro', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Content</CFormLabel>
                    <CFormTextarea value={p.intro?.content || ''} onChange={(e) => handleSectionChange('terms', 'intro', 'content', e.target.value)} rows={3} />
                  </SectionCard>

                  <SectionCard title="Terms Sections">
                    <CButton color="success" size="sm" onClick={addTermsSection} className="mb-3"><Plus size={14} className="me-1" /> Add Section</CButton>
                    {(p.sections || []).map((section, index) => (
                      <div key={section.id || index} className="p-3 mb-2 border rounded bg-light">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <span className="badge bg-secondary">Section {index + 1}</span>
                          <div className="d-flex gap-1">
                            <CButton color="light" size="sm" disabled={index === 0} onClick={() => moveTermsSection(index, -1)}><ChevronUp size={12} /></CButton>
                            <CButton color="light" size="sm" disabled={index === (p.sections || []).length - 1} onClick={() => moveTermsSection(index, 1)}><ChevronDown size={12} /></CButton>
                            <CButton color="danger" size="sm" variant="ghost" onClick={() => deleteTermsSection(index)}><Trash2 size={12} /></CButton>
                          </div>
                        </div>
                        <CRow className="mb-2">
                          <CCol xs={4}>
                            <CFormLabel className="small mb-0">Icon</CFormLabel>
                            <CFormSelect size="sm" value={section.icon || 'FileText'} onChange={(e) => updateTermsSection(index, 'icon', e.target.value)}>
                              <option value="FileText">File</option>
                              <option value="CheckCircle2">Check Circle</option>
                              <option value="Shield">Shield</option>
                              <option value="Wallet">Wallet</option>
                              <option value="Truck">Truck</option>
                              <option value="RefreshCcw">Refresh</option>
                              <option value="Scale">Scale</option>
                              <option value="AlertCircle">Alert Circle</option>
                            </CFormSelect>
                          </CCol>
                          <CCol xs={8}>
                            <CFormLabel className="small mb-0">Title</CFormLabel>
                            <CFormInput size="sm" value={section.title || ''} onChange={(e) => updateTermsSection(index, 'title', e.target.value)} />
                          </CCol>
                        </CRow>
                        <CFormLabel className="small mb-0">Content</CFormLabel>
                        <CFormTextarea size="sm" value={section.content || ''} onChange={(e) => updateTermsSection(index, 'content', e.target.value)} rows={4} />
                      </div>
                    ))}
                  </SectionCard>

                  <SectionCard title="Contact CTA">
                    <CFormLabel>Heading</CFormLabel>
                    <CFormInput value={p.contact?.heading || ''} onChange={(e) => handleSectionChange('terms', 'contact', 'heading', e.target.value)} className="mb-2" />
                    <CFormLabel>Text</CFormLabel>
                    <CFormTextarea value={p.contact?.text || ''} onChange={(e) => handleSectionChange('terms', 'contact', 'text', e.target.value)} rows={2} className="mb-2" />
                    <CRow>
                      <CCol xs={6}><CFormLabel>Button Text</CFormLabel><CFormInput value={p.contact?.btn_text || ''} onChange={(e) => handleSectionChange('terms', 'contact', 'btn_text', e.target.value)} /></CCol>
                      <CCol xs={6}><CFormLabel>Button Link</CFormLabel><CFormInput value={p.contact?.btn_link || ''} onChange={(e) => handleSectionChange('terms', 'contact', 'btn_link', e.target.value)} /></CCol>
                    </CRow>
                  </SectionCard>
                </>
              )}
              {activePage === 'refund_policy' && (
                <>
                  <SectionCard title="Hero Section">
                    <CFormLabel>Badge Text</CFormLabel>
                    <CFormInput value={p.label || ''} onChange={(e) => handlePageFieldChange('refund_policy', 'label', e.target.value)} className="mb-2" />
                    <CFormLabel>Page Title</CFormLabel>
                    <CFormInput value={p.title || ''} onChange={(e) => handlePageFieldChange('refund_policy', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Subtitle</CFormLabel>
                    <CFormTextarea value={p.subtitle || ''} onChange={(e) => handlePageFieldChange('refund_policy', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                    <CFormLabel>Hero Icon</CFormLabel>
                    <CFormSelect value={p.hero_icon || 'rotate'} onChange={(e) => handlePageFieldChange('refund_policy', 'hero_icon', e.target.value)}>
                      <option value="rotate">Rotate Arrows (default)</option>
                      <option value="ban">Ban</option>
                      <option value="clock">Clock</option>
                      <option value="card">Credit Card</option>
                      <option value="shield">Shield Check</option>
                      <option value="chat">Chat Bubble</option>
                    </CFormSelect>
                  </SectionCard>

                  <SectionCard title="Policy Sections">
                    <CButton color="success" size="sm" onClick={() => addPolicySection('refund_policy', 'clock')} className="mb-3"><Plus size={14} className="me-1" /> Add Section</CButton>
                    {(p.sections || []).map((section, index) => (
                      <div key={index} className="p-3 mb-2 border rounded bg-light">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <span className="badge bg-secondary">Section {index + 1}</span>
                          <div className="d-flex gap-1">
                            <CButton color="light" size="sm" disabled={index === 0} onClick={() => movePolicySection('refund_policy', index, -1)}><ChevronUp size={12} /></CButton>
                            <CButton color="light" size="sm" disabled={index === (p.sections || []).length - 1} onClick={() => movePolicySection('refund_policy', index, 1)}><ChevronDown size={12} /></CButton>
                            <CButton color="danger" size="sm" variant="ghost" onClick={() => deletePolicySection('refund_policy', index)}><Trash2 size={12} /></CButton>
                          </div>
                        </div>
                        <CRow className="mb-2">
                          <CCol xs={4}>
                            <CFormLabel className="small mb-0">Icon</CFormLabel>
                            <CFormSelect size="sm" value={section.icon || 'clock'} onChange={(e) => updatePolicySection('refund_policy', index, 'icon', e.target.value)}>
                              <option value="rotate">Rotate Arrows</option>
                              <option value="ban">Ban</option>
                              <option value="clock">Clock</option>
                              <option value="card">Credit Card</option>
                              <option value="shield">Shield Check</option>
                              <option value="chat">Chat Bubble</option>
                            </CFormSelect>
                          </CCol>
                          <CCol xs={8}>
                            <CFormLabel className="small mb-0">Title</CFormLabel>
                            <CFormInput size="sm" value={section.title || ''} onChange={(e) => updatePolicySection('refund_policy', index, 'title', e.target.value)} />
                          </CCol>
                        </CRow>
                        <CFormLabel className="small mb-0">Description</CFormLabel>
                        <CFormTextarea size="sm" value={section.desc || ''} onChange={(e) => updatePolicySection('refund_policy', index, 'desc', e.target.value)} rows={3} />
                      </div>
                    ))}
                  </SectionCard>

                  <SectionCard title="Note Box (dashed strip under cards)">
                    <CFormTextarea value={p.note || ''} onChange={(e) => handlePageFieldChange('refund_policy', 'note', e.target.value)} rows={2} />
                  </SectionCard>

                  <SectionCard title="Contact CTA">
                    <CFormLabel>Title</CFormLabel>
                    <CFormInput value={p.cta?.title || ''} onChange={(e) => handleSectionChange('refund_policy', 'cta', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Subtitle</CFormLabel>
                    <CFormTextarea value={p.cta?.subtitle || ''} onChange={(e) => handleSectionChange('refund_policy', 'cta', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                    <CRow>
                      <CCol xs={6}><CFormLabel>Button Text</CFormLabel><CFormInput value={p.cta?.btn_text || ''} onChange={(e) => handleSectionChange('refund_policy', 'cta', 'btn_text', e.target.value)} /></CCol>
                      <CCol xs={6}><CFormLabel>Button Link</CFormLabel><CFormInput value={p.cta?.btn_link || ''} onChange={(e) => handleSectionChange('refund_policy', 'cta', 'btn_link', e.target.value)} /></CCol>
                    </CRow>
                  </SectionCard>
                </>
              )}

              {activePage === 'shipping_policy' && (
                <>
                  <SectionCard title="Hero Section">
                    <CFormLabel>Badge Text</CFormLabel>
                    <CFormInput value={p.label || ''} onChange={(e) => handlePageFieldChange('shipping_policy', 'label', e.target.value)} className="mb-2" />
                    <CFormLabel>Page Title</CFormLabel>
                    <CFormInput value={p.title || ''} onChange={(e) => handlePageFieldChange('shipping_policy', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Subtitle</CFormLabel>
                    <CFormTextarea value={p.subtitle || ''} onChange={(e) => handlePageFieldChange('shipping_policy', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                    <CFormLabel>Hero Icon</CFormLabel>
                    <CFormSelect value={p.hero_icon || 'truck'} onChange={(e) => handlePageFieldChange('shipping_policy', 'hero_icon', e.target.value)}>
                      <option value="truck">Truck (default)</option>
                      <option value="pin">Map Pin</option>
                      <option value="clock">Clock</option>
                      <option value="wallet">Wallet</option>
                      <option value="box">Package Box</option>
                      <option value="bell">Bell / Notifications</option>
                    </CFormSelect>
                  </SectionCard>

                  <SectionCard title="Policy Sections">
                    <CButton color="success" size="sm" onClick={() => addPolicySection('shipping_policy', 'truck')} className="mb-3"><Plus size={14} className="me-1" /> Add Section</CButton>
                    {(p.sections || []).map((section, index) => (
                      <div key={index} className="p-3 mb-2 border rounded bg-light">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <span className="badge bg-secondary">Section {index + 1}</span>
                          <div className="d-flex gap-1">
                            <CButton color="light" size="sm" disabled={index === 0} onClick={() => movePolicySection('shipping_policy', index, -1)}><ChevronUp size={12} /></CButton>
                            <CButton color="light" size="sm" disabled={index === (p.sections || []).length - 1} onClick={() => movePolicySection('shipping_policy', index, 1)}><ChevronDown size={12} /></CButton>
                            <CButton color="danger" size="sm" variant="ghost" onClick={() => deletePolicySection('shipping_policy', index)}><Trash2 size={12} /></CButton>
                          </div>
                        </div>
                        <CRow className="mb-2">
                          <CCol xs={4}>
                            <CFormLabel className="small mb-0">Icon</CFormLabel>
                            <CFormSelect size="sm" value={section.icon || 'truck'} onChange={(e) => updatePolicySection('shipping_policy', index, 'icon', e.target.value)}>
                              <option value="truck">Truck</option>
                              <option value="pin">Map Pin</option>
                              <option value="clock">Clock</option>
                              <option value="wallet">Wallet</option>
                              <option value="box">Package Box</option>
                              <option value="bell">Bell / Notifications</option>
                            </CFormSelect>
                          </CCol>
                          <CCol xs={8}>
                            <CFormLabel className="small mb-0">Title</CFormLabel>
                            <CFormInput size="sm" value={section.title || ''} onChange={(e) => updatePolicySection('shipping_policy', index, 'title', e.target.value)} />
                          </CCol>
                        </CRow>
                        <CFormLabel className="small mb-0">Description</CFormLabel>
                        <CFormTextarea size="sm" value={section.desc || ''} onChange={(e) => updatePolicySection('shipping_policy', index, 'desc', e.target.value)} rows={3} />
                      </div>
                    ))}
                  </SectionCard>

                  <SectionCard title="Note Box (dashed strip under cards)">
                    <CFormTextarea value={p.note || ''} onChange={(e) => handlePageFieldChange('shipping_policy', 'note', e.target.value)} rows={2} />
                  </SectionCard>

                  <SectionCard title="Contact CTA">
                    <CFormLabel>Title</CFormLabel>
                    <CFormInput value={p.cta?.title || ''} onChange={(e) => handleSectionChange('shipping_policy', 'cta', 'title', e.target.value)} className="mb-2" />
                    <CFormLabel>Subtitle</CFormLabel>
                    <CFormTextarea value={p.cta?.subtitle || ''} onChange={(e) => handleSectionChange('shipping_policy', 'cta', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                    <CRow>
                      <CCol xs={6}><CFormLabel>Button Text</CFormLabel><CFormInput value={p.cta?.btn_text || ''} onChange={(e) => handleSectionChange('shipping_policy', 'cta', 'btn_text', e.target.value)} /></CCol>
                      <CCol xs={6}><CFormLabel>Button Link</CFormLabel><CFormInput value={p.cta?.btn_link || ''} onChange={(e) => handleSectionChange('shipping_policy', 'cta', 'btn_link', e.target.value)} /></CCol>
                    </CRow>
                  </SectionCard>
                </>
              )}
              {activePage === 'home' && (
                <>
                  {pagesData.home.carousel && (<SectionCard title="Carousel Section (Full-Width Banners)" onDelete={() => handleSectionChange('home', 'carousel', null, null)}><CFormLabel>Upload Image — these appear as the full-width banner carousel (separate from the hero)</CFormLabel><input type="file" accept="image/*" onChange={handleImageUpload} style={{ marginBottom: '15px', display: 'block' }} />{carouselImages.length > 0 && (<div className="d-flex flex-wrap gap-2 mb-3">{carouselImages.map((img, i) => (<div key={i} style={{ position: 'relative', width: 120, height: 70 }}><img src={img} alt={`slide-${i}`} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 4 }} /><CButton color="danger" size="sm" style={{ position: 'absolute', top: 2, right: 2, padding: '0 4px' }} onClick={() => handleSectionChange('home', 'carousel', 'images', carouselImages.filter((_, idx) => idx !== i))}>X</CButton></div>))}</div>)}</SectionCard>)}

                  {pagesData.home.hero && (
                    <SectionCard title="Hero Section" onDelete={() => handleSectionChange('home', 'hero', null, null)}>
                      <CFormLabel>Text Alignment</CFormLabel>
                      <div className="d-flex gap-2 mb-3">{renderAlignButtons('home', 'hero', hero.alignment)}</div>

                      {/* ★ NEW — hero background images (separate from the carousel) */}
                      <CFormLabel>Banner Slides (image + text + color per slide)</CFormLabel>
                      <small className="text-muted d-block mb-2">Each slide shows its own image with its own text and color. Empty text fields fall back to the hero text below. Your existing hero images appear here automatically.</small>
                      <CButton color="success" size="sm" onClick={addHeroSlide} className="mb-2"><Plus size={14} className="me-1" /> Add Slide</CButton>
                      {heroSlideList().map((s, i) => (
                        <div key={i} className="p-3 mb-2 border rounded bg-light">
                          <div className="d-flex justify-content-between align-items-center mb-2">
                            <span className="badge bg-secondary">Slide {i + 1}</span>
                            <div className="d-flex gap-1">
                              <CButton color="light" size="sm" disabled={i === 0} onClick={() => moveHeroSlide(i, -1)}><ChevronUp size={12} /></CButton>
                              <CButton color="light" size="sm" disabled={i === heroSlideList().length - 1} onClick={() => moveHeroSlide(i, 1)}><ChevronDown size={12} /></CButton>
                              <CButton color="danger" size="sm" variant="ghost" onClick={() => removeHeroSlide(i)}><Trash2 size={12} /></CButton>
                            </div>
                          </div>
                          <div className="d-flex gap-2 mb-2">
                            <div style={{ width: 100, height: 60, background: '#F1F5F9', borderRadius: 6, overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>
                              {s.image_url ? <img src={s.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🖼️'}
                            </div>
                            <div style={{ flex: 1 }}>
                              <label style={{ display: 'block', border: '1px dashed #94A3B8', borderRadius: 6, padding: '6px 8px', fontSize: '0.75rem', cursor: 'pointer', textAlign: 'center', color: '#64748B' }}>
                                {heroSlideUploading ? 'Uploading…' : 'Upload image'}
                                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => { uploadHeroSlideImage(i, e.target.files[0]); e.target.value = '' }} />
                              </label>
                            </div>
                          </div>
                            <div className="d-flex align-items-center gap-2 mb-1">
                            <CFormSwitch id={`slideHide-${i}`} checked={s.hide_text === true} onChange={(e) => updateHeroSlide(i, 'hide_text', e.target.checked)} />
                            <CFormLabel htmlFor={`slideHide-${i}`} className="mb-0"><small>Pure image — hide text on this slide</small></CFormLabel>
                          </div>
                          <CFormInput size="sm" value={s.badge || ''} onChange={(e) => updateHeroSlide(i, 'badge', e.target.value)} placeholder="Badge (optional)" className="mb-1" />
                          <CFormInput size="sm" value={s.title || ''} onChange={(e) => updateHeroSlide(i, 'title', e.target.value)} placeholder="Title (optional)" className="mb-1" />
                          <CFormTextarea size="sm" value={s.subtitle || ''} onChange={(e) => updateHeroSlide(i, 'subtitle', e.target.value)} placeholder="Subtitle (optional)" rows={2} className="mb-1" />
                          <CRow className="mb-1">
                            <CCol xs={6}><CFormInput size="sm" value={s.btn_text || ''} onChange={(e) => updateHeroSlide(i, 'btn_text', e.target.value)} placeholder="Button text" /></CCol>
                            <CCol xs={6}><CFormInput size="sm" value={s.btn_link || ''} onChange={(e) => updateHeroSlide(i, 'btn_link', e.target.value)} placeholder="Button link (/products)" /></CCol>
                          </CRow>
                          <div className="d-flex align-items-center gap-2">
                            <CFormLabel className="small mb-0">Text color:</CFormLabel>
                            <input type="color" value={s.text_color || '#ffffff'} onChange={(e) => updateHeroSlide(i, 'text_color', e.target.value)} style={{ width: 36, height: 28, border: 'none', cursor: 'pointer' }} />
                            {s.text_color && <CButton color="light" size="sm" onClick={() => updateHeroSlide(i, 'text_color', '')}>Reset</CButton>}
                          </div>
                        </div>
                      ))}


{/* ★ NEW — hero text & brightness controls */}
<div className="d-flex align-items-center gap-2 mb-3">
  <CFormSwitch id="heroShowText" checked={hero.show_text !== false} onChange={(e) => handleSectionChange('home', 'hero', 'show_text', e.target.checked)} />
  <CFormLabel htmlFor="heroShowText" className="mb-0">Show hero text (badge, title, buttons)</CFormLabel>
</div>
<CFormLabel>Image dim / overlay: {hero.overlay_opacity ?? 50}%</CFormLabel>
<CFormInput type="range" min={0} max={100} value={hero.overlay_opacity ?? 50} onChange={(e) => handleSectionChange('home', 'hero', 'overlay_opacity', parseInt(e.target.value))} />
<small className="text-muted d-block mb-3">0% = bright full-color images · higher = darker image (better text readability)</small>
                      <CFormLabel>Text style on image</CFormLabel>
                      <CFormSelect value={hero.text_style || 'light'} onChange={(e) => handleSectionChange('home', 'hero', 'text_style', e.target.value)} className="mb-3">
                        <option value="light">Light text — white (for darker images)</option>
                        <option value="dark">Dark text (for white / light images)</option>
                        <option value="glass">Frosted glass panel behind text (works on any image)</option>
                      </CFormSelect>
                      <CFormLabel>Common Hero Text — used by every slide without its own text</CFormLabel>
                      <small className="text-muted d-block mb-2">A slide shows its own text when filled; empty slide fields fall back to this. Flip "Pure image" on a slide to show only the image.</small>
                      <CFormLabel>Badge Text</CFormLabel>
                      <CFormInput value={hero.badge || ''} onChange={(e) => handleSectionChange('home', 'hero', 'badge', e.target.value)} className="mb-2" />
                      <CFormLabel>Title</CFormLabel>
                      <CFormInput value={hero.title || ''} onChange={(e) => handleSectionChange('home', 'hero', 'title', e.target.value)} className="mb-2" />
                      <CFormLabel>Subtitle</CFormLabel>
                      <CFormTextarea value={hero.subtitle || ''} onChange={(e) => handleSectionChange('home', 'hero', 'subtitle', e.target.value)} rows={2} className="mb-2" />
                      <CRow>
                        <CCol xs={6}><CFormLabel>Btn 1 Text</CFormLabel><CFormInput value={hero.primary_btn_text || ''} onChange={(e) => handleSectionChange('home', 'hero', 'primary_btn_text', e.target.value)} /></CCol>
                        <CCol xs={6}><CFormLabel>Btn 1 Link</CFormLabel><CFormInput value={hero.primary_btn_link || ''} onChange={(e) => handleSectionChange('home', 'hero', 'primary_btn_link', e.target.value)} /></CCol>
                      </CRow>
                    </SectionCard>
                  )}

                  {pagesData.home.mission && (<SectionCard title="Mission & Vision" onDelete={() => handleSectionChange('home', 'mission', null, null)}><CFormLabel>Section Title</CFormLabel><CFormInput value={mission.title || ''} onChange={(e) => handleSectionChange('home', 'mission', 'title', e.target.value)} className="mb-2" /><CFormLabel>Mission Text</CFormLabel><CFormTextarea value={mission.mission_text || ''} onChange={(e) => handleSectionChange('home', 'mission', 'mission_text', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Vision Text</CFormLabel><CFormTextarea value={mission.vision_text || ''} onChange={(e) => handleSectionChange('home', 'mission', 'vision_text', e.target.value)} rows={2} /></SectionCard>)}
                  {pagesData.home.testimonials && (<SectionCard title="Testimonials / Reviews" onDelete={() => handleSectionChange('home', 'testimonials', null, null)}><CFormLabel>Section Title</CFormLabel><CFormInput value={testimonials.title || ''} onChange={(e) => handleSectionChange('home', 'testimonials', 'title', e.target.value)} className="mb-3" /><div className="d-flex justify-content-between align-items-center mb-2"><small className="fw-bold text-muted">Review Cards ({(testimonials.items || []).length})</small><CButton color="success" size="sm" onClick={handleAddTestimonial}><Plus size={14} className="me-1" /> Add Review</CButton></div>{(testimonials.items || []).map((item, i) => (<div key={i} className="p-3 mb-2 border rounded bg-light"><div className="d-flex justify-content-between align-items-center mb-2"><span className="badge bg-primary">Review #{i + 1}</span><div className="d-flex gap-1"><CButton color="light" size="sm" disabled={i === 0} onClick={() => handleMoveTestimonial(i, -1)}><ChevronUp size={14} /></CButton><CButton color="light" size="sm" disabled={i === (testimonials.items || []).length - 1} onClick={() => handleMoveTestimonial(i, 1)}><ChevronDown size={14} /></CButton><CButton color="danger" size="sm" variant="ghost" onClick={() => handleDeleteTestimonial(i)}><Trash2 size={14} /></CButton></div></div><CFormLabel>Customer Name</CFormLabel><CFormInput value={item.name || ''} onChange={(e) => handleUpdateTestimonial(i, 'name', e.target.value)} className="mb-2" /><CFormLabel>Review Text</CFormLabel><CFormTextarea value={item.text || ''} onChange={(e) => handleUpdateTestimonial(i, 'text', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Rating</CFormLabel><CFormSelect value={item.rating || 5} onChange={(e) => handleUpdateTestimonial(i, 'rating', parseInt(e.target.value))} size="sm" style={{ width: '120px' }}><option value={5}>5 stars</option><option value={4}>4 stars</option><option value={3}>3 stars</option><option value={2}>2 stars</option><option value={1}>1 star</option></CFormSelect></div>))}</SectionCard>)}
                  {pagesData.home.cta && (<SectionCard title="Call to Action (CTA)" onDelete={() => handleSectionChange('home', 'cta', null, null)}><CFormLabel>Title</CFormLabel><CFormInput value={cta.title || ''} onChange={(e) => handleSectionChange('home', 'cta', 'title', e.target.value)} className="mb-2" /><CRow><CCol xs={6}><CFormLabel>Btn 1 Text</CFormLabel><CFormInput value={cta.btn1_text || ''} onChange={(e) => handleSectionChange('home', 'cta', 'btn1_text', e.target.value)} /></CCol><CCol xs={6}><CFormLabel>Btn 1 Link</CFormLabel><CFormInput value={cta.btn1_link || ''} onChange={(e) => handleSectionChange('home', 'cta', 'btn1_link', e.target.value)} /></CCol></CRow></SectionCard>)}
                  {(p.section_order || []).filter(k => k.startsWith('custom-')).map(k => renderCustomSectionEditor(k))}
                </>
              )}

              {activePage === 'about' && (
                <>
                  {pagesData.about.hero && (<SectionCard title="Hero Section" onDelete={() => handleSectionChange('about', 'hero', null, null)}><CFormLabel>Badge Text</CFormLabel><CFormInput value={hero.badge || ''} onChange={(e) => handleSectionChange('about', 'hero', 'badge', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={hero.title || ''} onChange={(e) => handleSectionChange('about', 'hero', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={hero.subtitle || ''} onChange={(e) => handleSectionChange('about', 'hero', 'subtitle', e.target.value)} rows={2} /></SectionCard>)}
                  {pagesData.about.story && (<SectionCard title="Story Section" onDelete={() => handleSectionChange('about', 'story', null, null)}><CFormLabel>Label</CFormLabel><CFormInput value={story.label || ''} onChange={(e) => handleSectionChange('about', 'story', 'label', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={story.title || ''} onChange={(e) => handleSectionChange('about', 'story', 'title', e.target.value)} className="mb-2" /><CFormLabel>Paragraph 1</CFormLabel><CFormTextarea value={story.desc1 || ''} onChange={(e) => handleSectionChange('about', 'story', 'desc1', e.target.value)} rows={3} className="mb-2" /><CFormLabel>Paragraph 2</CFormLabel><CFormTextarea value={story.desc2 || ''} onChange={(e) => handleSectionChange('about', 'story', 'desc2', e.target.value)} rows={3} className="mb-2" /><div className="p-2 mb-2 border rounded bg-light"><CFormLabel className="mb-1 small fw-bold">📷 Story Image</CFormLabel><small className="text-muted d-block mb-2">Set via URL or upload. Same size and box as the default image.</small><CFormInput value={story.image_url || ''} placeholder="Paste image URL (https://...)" size="sm" className="mb-2" onChange={(e) => handleSectionChange('about', 'story', 'image_url', e.target.value)} /><div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) uploadStoryImage(f); }} style={{ border: '2px dashed #cbd5e1', borderRadius: 8, padding: 16, textAlign: 'center', background: '#fff', cursor: 'pointer', marginBottom: 8 }} onClick={() => document.getElementById('story-image-input').click()}>{storyImageUploading ? <><CSpinner size="sm" className="me-2" /><span className="small">Uploading…</span></> : <><span className="small text-muted">📎 Drop image here or click to choose</span></>}<input id="story-image-input" type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadStoryImage(f); e.target.value = ''; }} /></div>{story.image_url && (<div className="d-flex gap-2 align-items-center mt-2"><img src={story.image_url} alt="Story preview" style={{ width: 80, height: 60, objectFit: 'cover', borderRadius: 6, border: '1px solid #e2e8f0' }} onError={(e) => { e.target.style.display = 'none' }} /><div className="flex-grow-1"><small className="text-muted text-break d-block" style={{ maxHeight: 32, overflow: 'hidden' }}>{story.image_url}</small></div><CButton color="danger" size="sm" variant="ghost" onClick={() => handleSectionChange('about', 'story', 'image_url', '')}>Clear</CButton></div>)}<CFormLabel className="small mt-2 mb-0">Alt Text (optional, for accessibility)</CFormLabel><CFormInput value={story.image_alt || ''} placeholder="Happy customer" size="sm" onChange={(e) => handleSectionChange('about', 'story', 'image_alt', e.target.value)} /></div><CFormLabel>Stats (Format: Number,Label - One per line)</CFormLabel><CFormTextarea value={(story.stats || []).map(s => `${s.n},${s.l}`).join('\n')} onChange={(e) => { const stats = e.target.value.split('\n').filter(Boolean).map(line => { const parts = line.split(','); return { n: parts[0]?.trim(), l: parts[1]?.trim() }; }); handleSectionChange('about', 'story', 'stats', stats); }} rows={4} /></SectionCard>)}
                  <SectionCard title="YouTube Videos (optional)"><small className="text-muted d-block mb-2">Add one or more YouTube videos to your About page. They render between the Story and Mission sections.</small><CButton color="success" size="sm" className="mb-3" onClick={addAboutVideo}><Plus size={12} className="me-1" /> Add Video</CButton>{(pagesData.about?.youtube_videos || []).length === 0 && <div className="text-center text-muted py-3"><small>No videos added yet.</small></div>}{(pagesData.about?.youtube_videos || []).map((video, vIdx) => (<div key={vIdx} className="p-3 mb-3 border rounded bg-light"><div className="d-flex justify-content-between align-items-center mb-2"><span className="badge bg-secondary">Video {vIdx + 1}</span><div className="d-flex gap-1"><CButton color="light" size="sm" disabled={vIdx === 0} onClick={() => moveAboutVideo(vIdx, -1)}><ChevronUp size={12} /></CButton><CButton color="light" size="sm" disabled={vIdx === (pagesData.about?.youtube_videos || []).length - 1} onClick={() => moveAboutVideo(vIdx, 1)}><ChevronDown size={12} /></CButton><CButton color="danger" size="sm" variant="ghost" onClick={() => deleteAboutVideo(vIdx)}><Trash2 size={12} /></CButton></div></div><CFormLabel className="small mb-0">YouTube URL</CFormLabel><CFormInput value={video.youtube_url || ''} placeholder="https://www.youtube.com/watch?v=..." size="sm" className="mb-2" onChange={(e) => updateAboutVideo(vIdx, 'youtube_url', e.target.value)} /><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-0">Title (optional)</CFormLabel><CFormInput value={video.title || ''} placeholder="Video title" size="sm" onChange={(e) => updateAboutVideo(vIdx, 'title', e.target.value)} /></CCol><CCol xs={6}><CFormLabel className="small mb-0">Caption (optional)</CFormLabel><CFormInput value={video.caption || ''} placeholder="Short text below" size="sm" onChange={(e) => updateAboutVideo(vIdx, 'caption', e.target.value)} /></CCol></CRow><CRow className="mb-2"><CCol xs={4}><div className="d-flex align-items-center gap-1 mt-2"><CFormSwitch checked={video.autoplay || false} onChange={(e) => updateAboutVideo(vIdx, 'autoplay', e.target.checked)} /><small>Autoplay</small></div></CCol><CCol xs={4}><div className="d-flex align-items-center gap-1 mt-2"><CFormSwitch checked={video.loop || false} onChange={(e) => updateAboutVideo(vIdx, 'loop', e.target.checked)} /><small>Loop</small></div></CCol><CCol xs={4}><CFormLabel className="small mb-0">Start (sec)</CFormLabel><CFormInput type="number" value={video.start_time || 0} size="sm" style={{ width: 90 }} onChange={(e) => updateAboutVideo(vIdx, 'start_time', parseInt(e.target.value) || 0)} /></CCol></CRow><div className="p-2 mt-2 border rounded bg-white"><small className="fw-bold text-muted d-block mb-2">🎨 Video Placement</small><CRow className="mb-2"><CCol xs={12}><CFormLabel className="small mb-0">Width</CFormLabel><CFormSelect size="sm" value={video.layout?.width || 'contained'} onChange={(e) => updateAboutVideoLayout(vIdx, 'width', e.target.value)}><option value="full">Full Width (100%)</option><option value="contained">Contained Block (800px)</option><option value="half">Half Width (50% — side-by-side)</option></CFormSelect></CCol></CRow><CRow><CCol xs={6}><CFormLabel className="small mb-0">Video Position</CFormLabel><CFormSelect size="sm" value={video.layout?.content_align || 'center'} onChange={(e) => updateAboutVideoLayout(vIdx, 'content_align', e.target.value)}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol><CCol xs={6}><CFormLabel className="small mb-0">Title/Caption Align</CFormLabel><CFormSelect size="sm" value={video.alignment || 'left'} onChange={(e) => updateAboutVideo(vIdx, 'alignment', e.target.value)}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol></CRow></div>{video.youtube_url && (<div className="p-2 mt-2 bg-white border rounded"><small className="text-muted d-block mb-1">Preview (16:9):</small><div style={{ position: 'relative', paddingTop: '56.25%', background: '#000', borderRadius: 6, overflow: 'hidden' }}><iframe src={'https://www.youtube.com/embed/' + ((m) => (m ? m[1] : ''))((video.youtube_url.match(/(?:youtu\.be\/|[?&]v=|youtube\.com\/(?:embed|shorts|live)\/)([A-Za-z0-9_-]{6,})/))) + (video.autoplay ? '?autoplay=1&mute=1' : '')} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0 }} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title="preview" /></div></div>)}</div>))}</SectionCard>{pagesData.about.mission && (<SectionCard title="Mission & Vision" onDelete={() => handleSectionChange('about', 'mission', null, null)}><CFormLabel>Label</CFormLabel><CFormInput value={mission.label || ''} onChange={(e) => handleSectionChange('about', 'mission', 'label', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={mission.title || ''} onChange={(e) => handleSectionChange('about', 'mission', 'title', e.target.value)} className="mb-2" /><CFormLabel>Mission Title</CFormLabel><CFormInput value={mission.mission_title || ''} onChange={(e) => handleSectionChange('about', 'mission', 'mission_title', e.target.value)} className="mb-2" /><CFormLabel>Mission Desc</CFormLabel><CFormTextarea value={mission.mission_desc || ''} onChange={(e) => handleSectionChange('about', 'mission', 'mission_desc', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Vision Title</CFormLabel><CFormInput value={mission.vision_title || ''} onChange={(e) => handleSectionChange('about', 'mission', 'vision_title', e.target.value)} className="mb-2" /><CFormLabel>Vision Desc</CFormLabel><CFormTextarea value={mission.vision_desc || ''} onChange={(e) => handleSectionChange('about', 'mission', 'vision_desc', e.target.value)} rows={2} /></SectionCard>)}
                  {pagesData.about.whyUs && (<SectionCard title="Why Choose Us" onDelete={() => handleSectionChange('about', 'whyUs', null, null)}><CFormLabel>Label</CFormLabel><CFormInput value={whyUs.label || ''} onChange={(e) => handleSectionChange('about', 'whyUs', 'label', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={whyUs.title || ''} onChange={(e) => handleSectionChange('about', 'whyUs', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormInput value={whyUs.subtitle || ''} onChange={(e) => handleSectionChange('about', 'whyUs', 'subtitle', e.target.value)} className="mb-2" /><CFormLabel>Items (Format: Title,Desc - One per line)</CFormLabel><CFormTextarea value={(whyUs.items || []).map(i => `${i.title},${i.desc}`).join('\n')} onChange={(e) => { const items = e.target.value.split('\n').filter(Boolean).map(line => { const parts = line.split(','); return { title: parts[0]?.trim(), desc: parts[1]?.trim() }; }); handleSectionChange('about', 'whyUs', 'items', items); }} rows={4} /></SectionCard>)}
                  {pagesData.about.cta && (<SectionCard title="Call to Action (CTA)" onDelete={() => handleSectionChange('about', 'cta', null, null)}><CFormLabel>Label</CFormLabel><CFormInput value={cta.label || ''} onChange={(e) => handleSectionChange('about', 'cta', 'label', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={cta.title || ''} onChange={(e) => handleSectionChange('about', 'cta', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={cta.subtitle || ''} onChange={(e) => handleSectionChange('about', 'cta', 'subtitle', e.target.value)} rows={2} className="mb-2" /><CRow><CCol xs={6}><CFormLabel>Btn 1 Text</CFormLabel><CFormInput value={cta.btn1_text || ''} onChange={(e) => handleSectionChange('about', 'cta', 'btn1_text', e.target.value)} /></CCol><CCol xs={6}><CFormLabel>Btn 1 Link</CFormLabel><CFormInput value={cta.btn1_link || ''} onChange={(e) => handleSectionChange('about', 'cta', 'btn1_link', e.target.value)} /></CCol></CRow></SectionCard>)}
                  {(p.section_order || []).filter(k => k.startsWith('custom-')).map(k => renderCustomSectionEditor(k))}
                </>
              )}

              {pagesData.home.products && (
                <SectionCard title="Products Section">
                  <CFormLabel>Section Title</CFormLabel>
                  <CFormInput
                    value={pagesData.home.products.title || ''}
                    onChange={(e) => handleSectionChange('home', 'products', 'title', e.target.value)}
                    className="mb-2" placeholder="Popular Products"
                  />
                  <CFormLabel>View All Link Text</CFormLabel>
                  <CFormInput
                    value={pagesData.home.products.view_all_text || ''}
                    onChange={(e) => handleSectionChange('home', 'products', 'view_all_text', e.target.value)}
                    className="mb-2" placeholder="View All"
                  />
                  <CFormLabel>Max Products Shown (0 = all)</CFormLabel>
                  <CFormInput
                    type="number" style={{ width: 140 }}
                    value={pagesData.home.products.max_products ?? 0}
                    onChange={(e) => handleSectionChange('home', 'products', 'max_products', parseInt(e.target.value) || 0)}
                  />
                  <small className="text-muted d-block mt-2">
                    Products, prices & stock come from the catalog. Position & visibility are controlled in Section Order above.
                  </small>
                </SectionCard>
              )}

              {pagesData.home.categories && (
                <SectionCard title="Categories Section">
                  <CFormLabel>Section Title</CFormLabel>
                  <CFormInput
                    value={pagesData.home.categories.title || ''}
                    onChange={(e) => handleSectionChange('home', 'categories', 'title', e.target.value)}
                    className="mb-2" placeholder="Shop by Category"
                  />
                  <CFormLabel>Max Category Tiles (0 = all)</CFormLabel>
                  <CFormInput
                    type="number" style={{ width: 140 }}
                    value={pagesData.home.categories.max_categories ?? 0}
                    onChange={(e) => handleSectionChange('home', 'categories', 'max_categories', parseInt(e.target.value) || 0)}
                  />
                  <small className="text-muted d-block mt-2">
                    Tiles & images come from catalog categories. Position & visibility are controlled in Section Order above.
                  </small>
                </SectionCard>
              )}

              {activePage === 'contact' && (
                <>
                  {pagesData.contact.hero && (<SectionCard title="Hero Section" onDelete={() => handleSectionChange('contact', 'hero', null, null)}><CFormLabel>Badge Text</CFormLabel><CFormInput value={hero.badge || ''} onChange={(e) => handleSectionChange('contact', 'hero', 'badge', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={hero.title || ''} onChange={(e) => handleSectionChange('contact', 'hero', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={hero.subtitle || ''} onChange={(e) => handleSectionChange('contact', 'hero', 'subtitle', e.target.value)} rows={2} /></SectionCard>)}
                  {pagesData.contact.info && (<SectionCard title="Contact Info" onDelete={() => handleSectionChange('contact', 'info', null, null)}><CFormLabel>Address</CFormLabel><CFormInput value={info.address || ''} onChange={(e) => handleSectionChange('contact', 'info', 'address', e.target.value)} className="mb-2" /><CFormLabel>Phone</CFormLabel><CFormInput value={info.phone || ''} onChange={(e) => handleSectionChange('contact', 'info', 'phone', e.target.value)} className="mb-2" /><CFormLabel>Email</CFormLabel><CFormInput value={info.email || ''} onChange={(e) => handleSectionChange('contact', 'info', 'email', e.target.value)} className="mb-2" /><CFormLabel>Hours</CFormLabel><CFormTextarea value={info.hours || ''} onChange={(e) => handleSectionChange('contact', 'info', 'hours', e.target.value)} rows={2} /></SectionCard>)}
                  {pagesData.contact.whatsapp && (<SectionCard title="WhatsApp CTA" onDelete={() => handleSectionChange('contact', 'whatsapp', null, null)}><CFormLabel>Title</CFormLabel><CFormInput value={whatsapp.title || ''} onChange={(e) => handleSectionChange('contact', 'whatsapp', 'title', e.target.value)} className="mb-2" /><CFormLabel>Description</CFormLabel><CFormTextarea value={whatsapp.desc || ''} onChange={(e) => handleSectionChange('contact', 'whatsapp', 'desc', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Button Text</CFormLabel><CFormInput value={whatsapp.btn_text || ''} onChange={(e) => handleSectionChange('contact', 'whatsapp', 'btn_text', e.target.value)} className="mb-2" /><CFormLabel>WhatsApp Link</CFormLabel><CFormInput value={whatsapp.link || ''} onChange={(e) => handleSectionChange('contact', 'whatsapp', 'link', e.target.value)} /></SectionCard>)}
                  {(p.section_order || []).filter(k => k.startsWith('custom-')).map(k => renderCustomSectionEditor(k))}
                </>
              )}
              {activePage === 'profile' && (
                <>
                  <SectionCard title="Profile Header"><CFormLabel>Badge Text</CFormLabel><CFormInput value={pagesData.profile?.hero?.badge || ''} onChange={(e) => handleSectionChange('profile', 'hero', 'badge', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={pagesData.profile?.hero?.title || ''} onChange={(e) => handleSectionChange('profile', 'hero', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={pagesData.profile?.hero?.subtitle || ''} onChange={(e) => handleSectionChange('profile', 'hero', 'subtitle', e.target.value)} rows={2} /></SectionCard>                  <SectionCard title="Welcome Banner"><div className="d-flex justify-content-between align-items-center mb-2"><small>Enabled</small><CFormSwitch checked={banner.enabled !== false} onChange={(e) => handleSectionChange('profile', 'banner', 'enabled', e.target.checked)} /></div><CFormLabel>Banner Text</CFormLabel><CFormInput value={banner.text || ''} onChange={(e) => handleSectionChange('profile', 'banner', 'text', e.target.value)} className="mb-2" /><CRow><CCol xs={6}><CFormLabel>BG Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={banner.bg_color || '#FFF7ED'} onChange={(e) => handleSectionChange('profile', 'banner', 'bg_color', e.target.value)} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={banner.bg_color || ''} onChange={(e) => handleSectionChange('profile', 'banner', 'bg_color', e.target.value)} /></div></CCol><CCol xs={6}><CFormLabel>Text Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={banner.text_color || '#9A3412'} onChange={(e) => handleSectionChange('profile', 'banner', 'text_color', e.target.value)} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={banner.text_color || ''} onChange={(e) => handleSectionChange('profile', 'banner', 'text_color', e.target.value)} /></div></CCol></CRow></SectionCard>
                  <SectionCard title="Quick Links Section"><CFormLabel>Section Title</CFormLabel><CFormInput value={quickLinks.title || 'Quick Links'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'title', e.target.value)} className="mb-3" /><div className="p-2 mb-2 border rounded"><div className="d-flex justify-content-between align-items-center"><div><strong>My Orders</strong></div><CFormSwitch checked={quickLinks.show_orders !== false} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'show_orders', e.target.checked)} /></div><CRow className="mt-2"><CCol xs={6}><CFormLabel>Label</CFormLabel><CFormInput value={quickLinks.orders_label || 'My Orders'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'orders_label', e.target.value)} /></CCol><CCol xs={6}><CFormLabel>Description</CFormLabel><CFormInput value={quickLinks.orders_desc || 'View order history'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'orders_desc', e.target.value)} /></CCol></CRow></div><div className="p-2 mb-2 border rounded"><div className="d-flex justify-content-between align-items-center"><div><strong>My Subscriptions</strong></div><CFormSwitch checked={quickLinks.show_subscriptions !== false} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'show_subscriptions', e.target.checked)} /></div><CRow className="mt-2"><CCol xs={6}><CFormLabel>Label</CFormLabel><CFormInput value={quickLinks.subscriptions_label || 'My Subscriptions'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'subscriptions_label', e.target.value)} /></CCol><CCol xs={6}><CFormLabel>Description</CFormLabel><CFormInput value={quickLinks.subscriptions_desc || 'Manage subscriptions'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'subscriptions_desc', e.target.value)} /></CCol></CRow></div><div className="p-2 mb-2 border rounded"><div className="d-flex justify-content-between align-items-center"><div><strong>Addresses</strong></div><CFormSwitch checked={quickLinks.show_addresses !== false} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'show_addresses', e.target.checked)} /></div><CRow className="mt-2"><CCol xs={6}><CFormLabel>Label</CFormLabel><CFormInput value={quickLinks.addresses_label || 'Addresses'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'addresses_label', e.target.value)} /></CCol><CCol xs={6}><CFormLabel>Description</CFormLabel><CFormInput value={quickLinks.addresses_desc || 'Saved delivery addresses'} onChange={(e) => handleSectionChange('profile', 'quickLinks', 'addresses_desc', e.target.value)} /></CCol></CRow></div></SectionCard>
                  <SectionCard title="Custom Section"><div className="d-flex justify-content-between align-items-center mb-2"><small>Enabled</small><CFormSwitch checked={customSection.enabled === true} onChange={(e) => handleSectionChange('profile', 'customSection', 'enabled', e.target.checked)} /></div><CFormLabel>Title</CFormLabel><CFormInput value={customSection.title || ''} onChange={(e) => handleSectionChange('profile', 'customSection', 'title', e.target.value)} className="mb-2" /><CFormLabel>Content</CFormLabel><CFormTextarea value={customSection.content || ''} onChange={(e) => handleSectionChange('profile', 'customSection', 'content', e.target.value)} rows={3} /></SectionCard>
                  <SectionCard title="Call to Action (CTA)"><div className="d-flex justify-content-between align-items-center mb-2"><small>Enabled</small><CFormSwitch checked={cta.enabled === true} onChange={(e) => handleSectionChange('profile', 'cta', 'enabled', e.target.checked)} /></div><CFormLabel>Title</CFormLabel><CFormInput value={cta.title || ''} onChange={(e) => handleSectionChange('profile', 'cta', 'title', e.target.value)} className="mb-2" /><CFormLabel>Button Text</CFormLabel><CFormInput value={cta.btn_text || ''} onChange={(e) => handleSectionChange('profile', 'cta', 'btn_text', e.target.value)} className="mb-2" /><CFormLabel>Button Link</CFormLabel><CFormInput value={cta.btn_link || ''} onChange={(e) => handleSectionChange('profile', 'cta', 'btn_link', e.target.value)} /></SectionCard>
                  {(p.section_order || []).filter(k => k.startsWith('custom-')).map(k => renderCustomSectionEditor(k))}
                </>
              )}

              {activePage === 'subscriptions' && (<><SectionCard title="Hero Section"><CFormLabel>Badge Text</CFormLabel><CFormInput value={hero.badge || ''} onChange={(e) => handleSectionChange('subscriptions', 'hero', 'badge', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={hero.title || ''} onChange={(e) => handleSectionChange('subscriptions', 'hero', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={hero.subtitle || ''} onChange={(e) => handleSectionChange('subscriptions', 'hero', 'subtitle', e.target.value)} rows={2} /></SectionCard><SectionCard title="Empty State"><CFormLabel>Icon (emoji)</CFormLabel><CFormInput value={emptyState.icon || ''} onChange={(e) => handleSectionChange('subscriptions', 'emptyState', 'icon', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={emptyState.title || ''} onChange={(e) => handleSectionChange('subscriptions', 'emptyState', 'title', e.target.value)} className="mb-2" /><CFormLabel>Message</CFormLabel><CFormTextarea value={emptyState.message || ''} onChange={(e) => handleSectionChange('subscriptions', 'emptyState', 'message', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Button Text</CFormLabel><CFormInput value={emptyState.buttonText || ''} onChange={(e) => handleSectionChange('subscriptions', 'emptyState', 'buttonText', e.target.value)} /></SectionCard><SectionCard title="New Button"><CFormLabel>Button Text</CFormLabel><CFormInput value={newButton.text || ''} onChange={(e) => handleSectionChange('subscriptions', 'newButton', 'text', e.target.value)} /></SectionCard></>)}

              {activePage === 'addresses' && (<><SectionCard title="Hero Section"><CFormLabel>Badge Text</CFormLabel><CFormInput value={hero.badge || ''} onChange={(e) => handleSectionChange('addresses', 'hero', 'badge', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={hero.title || ''} onChange={(e) => handleSectionChange('addresses', 'hero', 'title', e.target.value)} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={hero.subtitle || ''} onChange={(e) => handleSectionChange('addresses', 'hero', 'subtitle', e.target.value)} rows={2} /></SectionCard><SectionCard title="Empty State"><CFormLabel>Icon (emoji)</CFormLabel><CFormInput value={emptyState.icon || ''} onChange={(e) => handleSectionChange('addresses', 'emptyState', 'icon', e.target.value)} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={emptyState.title || ''} onChange={(e) => handleSectionChange('addresses', 'emptyState', 'title', e.target.value)} className="mb-2" /><CFormLabel>Message</CFormLabel><CFormTextarea value={emptyState.message || ''} onChange={(e) => handleSectionChange('addresses', 'emptyState', 'message', e.target.value)} rows={2} className="mb-2" /><CFormLabel>Button Text</CFormLabel><CFormInput value={emptyState.buttonText || ''} onChange={(e) => handleSectionChange('addresses', 'emptyState', 'buttonText', e.target.value)} /></SectionCard><SectionCard title="New Button"><CFormLabel>Button Text</CFormLabel><CFormInput value={newButton.text || ''} onChange={(e) => handleSectionChange('addresses', 'newButton', 'text', e.target.value)} /></SectionCard></>)}

              {activePage === 'privacy' && (<><SectionCard title="Hero Section"><CFormLabel>Badge Text</CFormLabel><CFormInput value={pagesData.privacy?.hero?.badge || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, hero: { ...prev.privacy?.hero, badge: e.target.value } } }))} className="mb-2" /><CFormLabel>Title</CFormLabel><CFormInput value={pagesData.privacy?.hero?.title || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, hero: { ...prev.privacy?.hero, title: e.target.value } } }))} className="mb-2" /><CFormLabel>Subtitle</CFormLabel><CFormTextarea value={pagesData.privacy?.hero?.subtitle || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, hero: { ...prev.privacy?.hero, subtitle: e.target.value } } }))} rows={2} className="mb-2" /><CFormLabel>Last Updated Date</CFormLabel><CFormInput value={pagesData.privacy?.hero?.last_updated || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, hero: { ...prev.privacy?.hero, last_updated: e.target.value } } }))} placeholder="e.g. June 15, 2026" /></SectionCard><SectionCard title="Intro Section"><CFormLabel>Intro Title</CFormLabel><CFormInput value={pagesData.privacy?.intro?.title || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, intro: { ...prev.privacy?.intro, title: e.target.value } } }))} className="mb-2" /><CFormLabel>Intro Content</CFormLabel><CFormTextarea value={pagesData.privacy?.intro?.content || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, intro: { ...prev.privacy?.intro, content: e.target.value } } }))} rows={3} /></SectionCard><SectionCard title="Privacy Sections"><small className="text-muted d-block mb-2">Add, edit, reorder, or remove privacy policy sections. Each section appears in the table of contents on the customer page.</small><CButton color="success" size="sm" className="mb-3" onClick={addPrivacySection}><Plus size={12} className="me-1" /> Add Section</CButton>{(pagesData.privacy?.sections || []).map((sec, sIdx) => (<div key={sIdx} className="p-3 mb-3 border rounded bg-light"><div className="d-flex justify-content-between align-items-center mb-2"><span className="badge bg-secondary">Section {sIdx + 1}</span><div className="d-flex gap-1"><CButton color="light" size="sm" disabled={sIdx === 0} onClick={() => movePrivacySection(sIdx, -1)}><ChevronUp size={12} /></CButton><CButton color="light" size="sm" disabled={sIdx === (pagesData.privacy?.sections || []).length - 1} onClick={() => movePrivacySection(sIdx, 1)}><ChevronDown size={12} /></CButton><CButton color="danger" size="sm" variant="ghost" onClick={() => deletePrivacySection(sIdx)}><Trash2 size={12} /></CButton></div></div><CRow className="mb-2"><CCol xs={4}><CFormLabel className="small mb-0">Icon</CFormLabel><CFormSelect size="sm" value={sec.icon || "FileText"} onChange={(e) => updatePrivacySection(sIdx, "icon", e.target.value)}><option value="Database">Database</option><option value="Eye">Eye</option><option value="CreditCard">Credit Card</option><option value="ShieldCheck">Shield Check</option><option value="UserCog">User Cog</option><option value="AlertCircle">Alert Circle</option><option value="Lock">Lock</option><option value="FileText">File Text</option><option value="Users">Users</option><option value="Bell">Bell</option><option value="MapPin">Map Pin</option><option value="Mail">Mail</option><option value="Phone">Phone</option><option value="Shield">Shield</option><option value="Cookie">Cookie</option><option value="Gift">Gift</option></CFormSelect></CCol><CCol xs={8}><CFormLabel className="small mb-0">Section Title</CFormLabel><CFormInput value={sec.title || ""} size="sm" onChange={(e) => updatePrivacySection(sIdx, "title", e.target.value)} /></CCol></CRow><CFormLabel className="small mb-0 mt-2">Content (use \n for line breaks, • for bullets)</CFormLabel><CFormTextarea value={sec.content || ""} onChange={(e) => updatePrivacySection(sIdx, "content", e.target.value)} rows={5} style={{ fontFamily: "monospace", fontSize: "0.85rem" }} /></div>))}</SectionCard><SectionCard title="Contact Prompt (Footer of Privacy Page)"><CFormLabel>Heading</CFormLabel><CFormInput value={pagesData.privacy?.contact?.heading || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, contact: { ...prev.privacy?.contact, heading: e.target.value } } }))} className="mb-2" /><CFormLabel>Text</CFormLabel><CFormTextarea value={pagesData.privacy?.contact?.text || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, contact: { ...prev.privacy?.contact, text: e.target.value } } }))} rows={2} className="mb-2" /><CRow><CCol xs={6}><CFormLabel>Email Address</CFormLabel><CFormInput value={pagesData.privacy?.contact?.email || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, contact: { ...prev.privacy?.contact, email: e.target.value } } }))} /></CCol><CCol xs={6}><CFormLabel>Button Text</CFormLabel><CFormInput value={pagesData.privacy?.contact?.btn_text || ""} onChange={(e) => setPagesData(prev => ({ ...prev, privacy: { ...prev.privacy, contact: { ...prev.privacy?.contact, btn_text: e.target.value } } }))} /></CCol></CRow></SectionCard></>)}
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'cart'}>
  <CCard className="glass-card admin-page-card">
    <CCardHeader className="glass-card__header"><strong>🛒 Cart Drawer — Suggested Products</strong></CCardHeader>
    <CCardBody>
      <div className="d-flex align-items-center gap-2 mb-3">
        <CFormSwitch id="cartSuggestEnabled" checked={cartCfg.enabled} onChange={(e) => updateCartConfig('enabled', e.target.checked)} />
        <CFormLabel htmlFor="cartSuggestEnabled" className="mb-0">Show product suggestions in the cart drawer</CFormLabel>
      </div>

      <div className="d-flex align-items-center gap-2 mb-3">
        <CFormSwitch id="pdpSuggest" checked={cartCfg.show_on_pdp === true} onChange={(e) => updateCartConfig('show_on_pdp', e.target.checked)} />
        <CFormLabel htmlFor="pdpSuggest" className="mb-0"><small>Also use these suggestions in the "You May Also Like" section on product pages</small></CFormLabel>
      </div>

      {cartCfg.enabled && (
        <>
          <CRow className="mb-3">
            <CCol md={6}>
              <CFormLabel>Section Title (optional)</CFormLabel>
              <CFormInput value={cartCfg.title || ''} placeholder="You may also like" onChange={(e) => updateCartConfig('title', e.target.value)} />
              <small className="text-muted">Empty = "You may also like" (or "Popular right now" on an empty cart).</small>
            </CCol>
            <CCol md={3}>
              <CFormLabel>Max items</CFormLabel>
              <CFormInput type="number" min={1} max={10} value={cartCfg.max_items} onChange={(e) => updateCartConfig('max_items', Math.max(1, Math.min(10, parseInt(e.target.value) || 5)))} />
            </CCol>
            <CCol md={3}>
              <CFormLabel>Source</CFormLabel>
              <CFormSelect value={cartCfg.mode} onChange={(e) => updateCartConfig('mode', e.target.value)}>
                <option value="auto">Automatic — recently added</option>
                <option value="manual">Manual — pick products</option>
              </CFormSelect>
            </CCol>
          </CRow>

          {cartCfg.mode === 'auto' && (
            <CAlert color="info" className="mb-0">
              The cart drawer automatically shows up to {cartCfg.max_items} most recently added in-stock products. Items already in the customer's cart are hidden automatically.
            </CAlert>
          )}

          {cartCfg.mode === 'manual' && (
            <>
              <CFormLabel className="fw-bold">1. Choose products</CFormLabel>
              <CRow className="mb-2">
                <CCol xs={7}>
                  <CFormInput placeholder="Search by name…" value={productSearch} onChange={(e) => setProductSearch(e.target.value)} />
                </CCol>
                <CCol xs={5}>
                  <CFormSelect value={productCategory} onChange={(e) => setProductCategory(e.target.value)}>
                    <option value="">All categories</option>
                    {categoryOptions.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </CFormSelect>
                </CCol>
              </CRow>              <div className="border rounded mb-3" style={{ maxHeight: 280, overflowY: 'auto' }}>
                {productsLoading && <div className="text-center py-4"><CSpinner size="sm" /></div>}
                {!productsLoading && (productsList || []).length === 0 && <div className="p-3 text-muted">No products found.</div>}
                {(productsList || [])
                  .filter(p => {
                    if (productCategory) {
                      const byId = String(p.category_id ?? p.category?.id ?? '') === String(productCategory)
                      const byName = (p.category_name || p.category?.name || '').toLowerCase() === String(productCategory).toLowerCase()
                      if (!byId && !byName) return false
                    }
                    if (!productSearch) return true
                    const q = productSearch.toLowerCase()
                    return (p.name || '').toLowerCase().includes(q) || (p.category_name || '').toLowerCase().includes(q)
                  })
                  .map(p => {
                    const picked = (cartCfg.items || []).some(i => i.product_id === p.id)
                    const v0 = (p.variants || [])[0] || {}
                    const minPrice = (p.variants || []).length
                      ? Math.min(...(p.variants || []).map(v => v.final_price ?? v.selling_price ?? v.mrp ?? 0)) : 0
                    return (
                      <div key={p.id} className="d-flex align-items-center gap-2 p-2" style={{ borderBottom: '1px solid #f1f5f9', cursor: 'pointer', background: picked ? '#f0fdf4' : 'transparent' }} onClick={() => toggleCartProduct(p.id)}>
                        <input type="checkbox" checked={picked} onChange={() => toggleCartProduct(p.id)} onClick={e => e.stopPropagation()} />
                        {v0.image_url && <img src={v0.image_url} alt="" style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 6 }} />}
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>{p.name}</div>
                          <small className="text-muted">{p.category_name} · {(p.variants || []).length} variant{(p.variants || []).length !== 1 ? 's' : ''} · from ₹{Number(minPrice).toFixed(0)}</small>
                        </div>
                      </div>
                    )
                  })}
              </div>

              {(cartCfg.items || []).length > 0 && (
                <div className="p-3 border rounded" style={{ background: '#f0f7ff', borderColor: '#93c5fd' }}>
                  <h6 className="text-uppercase text-primary mb-2">2. Selected — shown in this order</h6>
                  {(cartCfg.items || []).map((it, idx) => {
                    const p = (productsList || []).find(x => x.id === it.product_id)
                    return (
                      <div key={it.product_id} className="d-flex align-items-center justify-content-between p-2 mb-1 bg-white rounded" style={{ border: '1px solid #e2e8f0' }}>
                        <div className="d-flex align-items-center gap-2 flex-wrap">
                          <span className="badge bg-secondary">{idx + 1}</span>
                          <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>{p ? p.name : `Product #${it.product_id}`}</span>
                          {p && (p.variants || []).length > 1 && (
                            <CFormSelect size="sm" style={{ width: 'auto', maxWidth: 240 }} value={it.variant_id ?? ''} onChange={(e) => setCartVariant(it.product_id, e.target.value === '' ? null : parseInt(e.target.value))}>
                              <option value="">Auto (first in stock)</option>
                              {(p.variants || []).map(v => (
                                <option key={v.id} value={v.id}>{(v.attributes || []).map(a => a.value).join(' · ') || v.sku} — ₹{v.final_price}</option>
                              ))}
                            </CFormSelect>
                          )}
                        </div>
                        <div className="d-flex gap-1">
                          <CButton color="light" size="sm" disabled={idx === 0} onClick={() => moveCartItem(idx, -1)}><ChevronUp size={14} /></CButton>
                          <CButton color="light" size="sm" disabled={idx === (cartCfg.items || []).length - 1} onClick={() => moveCartItem(idx, 1)}><ChevronDown size={14} /></CButton>
                          <CButton color="danger" size="sm" variant="ghost" onClick={() => removeCartItem(it.product_id)}><Trash2 size={14} /></CButton>
                        </div>
                      </div>
                    )
                  })}
                  <div className="d-flex align-items-center gap-2 mt-2">
                    <CFormSwitch id="fillRecent" checked={cartCfg.fill_with_recent !== false} onChange={(e) => updateCartConfig('fill_with_recent', e.target.checked)} />
                    <CFormLabel htmlFor="fillRecent" className="mb-0"><small>Fill empty slots with recently added products (when picked items are out of stock or already in the cart)</small></CFormLabel>
                  </div>
                </div>
              )}
            </>
          )}
        </>
      )}
    </CCardBody>
  </CCard>
</CTabPane>

        <CTabPane visible={activeTab === 'reviews'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header"><strong>⭐ Product Reviews</strong></CCardHeader>
            <CCardBody>
              <CFormLabel>1. Choose a product</CFormLabel>
              <CFormInput placeholder="Filter products…" value={reviewSearch} onChange={(e) => setReviewSearch(e.target.value)} className="mb-2" />
              <CFormSelect value={reviewProduct ?? ''} onChange={(e) => setReviewProduct(e.target.value ? Number(e.target.value) : null)} className="mb-3">
                <option value="">— Select a product —</option>
                {(productsList || [])
                  .filter(p => !reviewSearch || (p.name || '').toLowerCase().includes(reviewSearch.toLowerCase()))
                  .map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </CFormSelect>

              {reviewProduct && (
                <>
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h6 className="text-uppercase text-primary mb-0">2. Reviews ({reviewsFor(reviewProduct).length})</h6>
                    <CButton color="success" size="sm" onClick={() => addReview(reviewProduct)}><Plus size={14} className="me-1" /> Add Review</CButton>
                  </div>
                  {reviewsFor(reviewProduct).length === 0 && (
                    <CAlert color="info">No reviews yet for this product. Click "Add Review" to create the first one.</CAlert>
                  )}
                  {reviewsFor(reviewProduct).map((r, idx) => (
                    <div key={idx} className="p-3 mb-2 border rounded bg-light">
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <span className="badge bg-secondary">Review {idx + 1}</span>
                        <div className="d-flex gap-1">
                          <CButton color="light" size="sm" disabled={idx === 0} onClick={() => moveReview(reviewProduct, idx, -1)}><ChevronUp size={12} /></CButton>
                          <CButton color="light" size="sm" disabled={idx === reviewsFor(reviewProduct).length - 1} onClick={() => moveReview(reviewProduct, idx, 1)}><ChevronDown size={12} /></CButton>
                          <CButton color="danger" size="sm" variant="ghost" onClick={() => deleteReview(reviewProduct, idx)}><Trash2 size={12} /></CButton>
                        </div>
                      </div>
                      <CRow className="mb-2">
                        <CCol xs={7}>
                          <CFormLabel className="small mb-0">Customer name</CFormLabel>
                          <CFormInput size="sm" value={r.name || ''} onChange={(e) => updateReview(reviewProduct, idx, 'name', e.target.value)} />
                        </CCol>
                        <CCol xs={5}>
                          <CFormLabel className="small mb-0">Rating</CFormLabel>
                          <CFormSelect size="sm" value={r.rating ?? 5} onChange={(e) => updateReview(reviewProduct, idx, 'rating', Number(e.target.value))}>
                            <option value={5}>★★★★★ (5)</option>
                            <option value={4}>★★★★ (4)</option>
                            <option value={3}>★★★ (3)</option>
                            <option value={2}>★★ (2)</option>
                            <option value={1}>★ (1)</option>
                          </CFormSelect>
                        </CCol>
                      </CRow>
                      <CFormLabel className="small mb-0">Review text</CFormLabel>
                      <CFormTextarea size="sm" rows={3} value={r.text || ''} onChange={(e) => updateReview(reviewProduct, idx, 'text', e.target.value)} />
                                              <CFormLabel className="small mb-0 mt-2 d-block">Review date (optional — used for "Most Recent" sorting)</CFormLabel>
                      <CFormInput size="sm" type="date" value={r.date || ''} onChange={(e) => updateReview(reviewProduct, idx, 'date', e.target.value)} style={{ maxWidth: 200 }} />
                      <CFormLabel className="small mb-0 mt-2 d-block">Review photos</CFormLabel>
                      <div className="d-flex gap-2 flex-wrap align-items-center">
                        {(r.images || []).map((img, imgIdx) => (
                          <div key={imgIdx} style={{ position: 'relative', width: 64, height: 64 }}>
                            <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 6 }} />
                            <CButton color="danger" size="sm" style={{ position: 'absolute', top: -6, right: -6, padding: '0 5px', borderRadius: '50%', lineHeight: 1 }} onClick={() => removeReviewImage(reviewProduct, idx, imgIdx)}>×</CButton>
                          </div>
                        ))}
                        <label style={{ width: 64, height: 64, border: '1px dashed #94A3B8', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '0.7rem', color: '#64748B' }}>
                          {reviewImgUploading ? '…' : '+ Photo'}
                          <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => { uploadReviewImage(reviewProduct, idx, e.target.files[0]); e.target.value = '' }} />
                        </label>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'theme'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header"><strong>Global Theme & Branding</strong></CCardHeader>
            <CCardBody>
              <h6 className="text-uppercase text-muted mb-3">Basic Branding</h6>
              <CFormLabel>Brand Name</CFormLabel><CFormInput value={theme.brand_name || ''} onChange={(e) => handleThemeChange('brand_name', e.target.value)} className="mb-3" />
              <CFormLabel>Logo URL</CFormLabel><CFormInput value={theme.logo_url || ''} onChange={(e) => handleThemeChange('logo_url', e.target.value)} className="mb-3" />
              <CRow>
                <CCol xs={6}><CFormLabel>Primary Color</CFormLabel><div className="d-flex align-items-center gap-2 mb-3"><input type="color" value={theme.primary_color || '#666666'} onChange={(e) => handleThemeChange('primary_color', e.target.value)} style={{ width: '40px', height: '40px', border: 'none', background: 'none' }} /><CFormInput value={theme.primary_color || ''} onChange={(e) => handleThemeChange('primary_color', e.target.value)} /></div></CCol>
                <CCol xs={6}><CFormLabel>Dark/Secondary Color</CFormLabel><div className="d-flex align-items-center gap-2 mb-3"><input type="color" value={theme.secondary_color || '#1E293B'} onChange={(e) => handleThemeChange('secondary_color', e.target.value)} style={{ width: '40px', height: '40px', border: 'none', background: 'none' }} /><CFormInput value={theme.secondary_color || ''} onChange={(e) => handleThemeChange('secondary_color', e.target.value)} /></div></CCol>
              </CRow>
              <CFormLabel>Font Family</CFormLabel>
              <CFormSelect value={theme.font_family || 'Inter, sans-serif'} onChange={(e) => handleThemeChange('font_family', e.target.value)} className="mb-4">
                <option value="Inter, sans-serif">Inter (Modern)</option><option value="'Plus Jakarta Sans', sans-serif">Plus Jakarta Sans</option><option value="Poppins, sans-serif">Poppins</option><option value="'Nunito Sans', sans-serif">Nunito Sans</option><option value="'DM Sans', sans-serif">DM Sans</option><option value="Arial, sans-serif">Arial</option><option value="Georgia, serif">Georgia (Serif)</option>
              </CFormSelect>
              <hr className="my-4" /><h6 className="text-uppercase text-muted mb-3">Visual Style</h6>
              <CFormLabel>Border Radius: <strong>{theme.border_radius ?? 12}px</strong></CFormLabel>
              <input type="range" min="0" max="24" value={theme.border_radius ?? 12} onChange={(e) => handleThemeChange('border_radius', parseInt(e.target.value))} style={{ width: '100%', marginBottom: 16, accentColor: theme.primary_color || '#666666' }} />
              <CFormLabel>Shadow Style</CFormLabel><CFormSelect value={theme.shadow_style || 'medium'} onChange={(e) => handleThemeChange('shadow_style', e.target.value)} className="mb-3"><option value="none">None — Flat</option><option value="subtle">Subtle</option><option value="medium">Medium</option><option value="strong">Strong</option></CFormSelect>
              <CFormLabel>Button Style</CFormLabel><CFormSelect value={theme.button_style || 'rounded'} onChange={(e) => handleThemeChange('button_style', e.target.value)} className="mb-3"><option value="rounded">Rounded</option><option value="square">Square</option><option value="pill">Pill</option><option value="outline">Outline</option></CFormSelect>
              <CFormLabel>Card Style</CFormLabel><CFormSelect value={theme.card_style || 'shadowed'} onChange={(e) => handleThemeChange('card_style', e.target.value)} className="mb-3"><option value="flat">Flat</option><option value="bordered">Bordered</option><option value="shadowed">Shadowed</option><option value="glass">Glass</option></CFormSelect>
              <CFormLabel>Hero Section Style</CFormLabel><CFormSelect value={theme.hero_style || 'solid'} onChange={(e) => handleThemeChange('hero_style', e.target.value)} className="mb-3"><option value="solid">Solid Color</option><option value="gradient">Gradient</option><option value="image">Image (Carousel)</option></CFormSelect>
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'nav'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center"><strong>Navigation Links</strong><CButton color="success" size="sm" onClick={() => { const links = [...(navigationConfig?.links || [])]; links.push({ id: 'nav-' + Date.now(), label: 'New Link', url: '/', visible: true, order: links.length + 1, is_custom: true }); setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }}><Plus size={14} className="me-1" /> Add Custom Link</CButton></CCardHeader>
            <CCardBody>
              <div className="p-3 mb-3 border rounded"><CFormLabel>Navbar Style</CFormLabel><CFormSelect value={navigationConfig?.navbar_style || 'solid'} onChange={(e) => setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), navbar_style: e.target.value })} className="mb-3"><option value="solid">Solid</option><option value="transparent">Transparent</option><option value="sticky">Sticky</option></CFormSelect></div>
              {(navigationConfig?.links || []).map((link, index) => (<div key={link.id} className="p-3 mb-2 border rounded bg-light"><div className="d-flex justify-content-between align-items-center mb-2"><span className="badge bg-secondary">{index + 1}</span><div className="d-flex gap-1"><CButton color="light" size="sm" disabled={index === 0} onClick={() => { const links = [...(navigationConfig?.links || [])];[links[index - 1], links[index]] = [links[index], links[index - 1]]; setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }}><ChevronUp size={14} /></CButton><CButton color="light" size="sm" disabled={index === (navigationConfig?.links || []).length - 1} onClick={() => { const links = [...(navigationConfig?.links || [])];[links[index], links[index + 1]] = [links[index + 1], links[index]]; setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }}><ChevronDown size={14} /></CButton>{link.is_custom && <CButton color="danger" size="sm" variant="ghost" onClick={() => { const links = (navigationConfig?.links || []).filter((_, i) => i !== index); setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }}><Trash2 size={14} /></CButton>}</div></div><CRow><CCol xs={4}><CFormLabel>Label</CFormLabel><CFormInput value={link.label} onChange={(e) => { const links = [...(navigationConfig?.links || [])]; links[index] = { ...link, label: e.target.value }; setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }} /></CCol><CCol xs={5}><CFormLabel>URL</CFormLabel><CFormInput value={link.url} onChange={(e) => { const links = [...(navigationConfig?.links || [])]; links[index] = { ...link, url: e.target.value }; setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }} /></CCol><CCol xs={3} className="d-flex align-items-end"><div className="d-flex align-items-center gap-2 pb-2"><CFormSwitch checked={link.visible !== false} onChange={(e) => { const links = [...(navigationConfig?.links || [])]; links[index] = { ...link, visible: e.target.checked }; setNavigationConfig({ ...(navigationConfig || DEFAULT_NAVIGATION), links }); }} /><small>{link.visible !== false ? 'Visible' : 'Hidden'}</small></div></CCol></CRow></div>))}
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'footer'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header"><strong>Footer Builder</strong></CCardHeader>
            <CCardBody>
              <div className="p-3 mb-3 border rounded" style={{ background: "#f8f9fa" }}><h6 className="text-uppercase text-primary mb-3">🎨 Footer Background</h6><CFormLabel className="small mb-1">Background Type</CFormLabel><CFormSelect size="sm" className="mb-3" value={footerConfig?.bg_type || "color"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_type: e.target.value })}><option value="color">Solid Color</option><option value="image">Image Background</option><option value="video">Video Background</option></CFormSelect>{(footerConfig?.bg_type || "color") === "color" && (<div className="p-2 mb-2 bg-white rounded border"><CFormLabel className="small mb-1">Background Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.bg_color || "#1E293B"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_color: e.target.value })} style={{ width: 40, height: 40, border: "none" }} /><CFormInput value={footerConfig?.bg_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_color: e.target.value })} size="sm" /></div></div>)}{footerConfig?.bg_type === "image" && (<div className="p-2 mb-2 bg-white rounded border"><CFormLabel className="small mb-1">Background Image</CFormLabel><div className="d-flex gap-2 align-items-center mb-2">{footerConfig?.bg_image_url ? (<img src={footerConfig.bg_image_url} alt="" style={{ width: 80, height: 50, objectFit: "cover", borderRadius: 4, border: "1px solid #dee2e6" }} onError={(e) => { e.target.style.display = "none" }} />) : (<div style={{ width: 80, height: 50, background: "#e9ecef", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#6c757d" }}>No image</div>)}<div className="flex-grow-1"><input type="file" accept="image/*" id="footer-bg-image-upload" style={{ display: "none" }} onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadFooterMedia(f, "bg_image_url"); e.target.value = "" }} /><CButton color="primary" size="sm" variant="outline" onClick={() => document.getElementById("footer-bg-image-upload").click()} disabled={footerMediaUploading}>{footerMediaUploading ? <CSpinner size="sm" /> : "Upload Image"}</CButton>{footerConfig?.bg_image_url && <CButton color="danger" size="sm" variant="ghost" className="ms-2" onClick={() => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_image_url: "" })}>Clear</CButton>}</div></div><CFormInput value={footerConfig?.bg_image_url || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_image_url: e.target.value })} placeholder="Or paste image URL" size="sm" className="mb-2" /></div>)}{footerConfig?.bg_type === "video" && (<div className="p-2 mb-2 bg-white rounded border"><CFormLabel className="small mb-1">Background Video</CFormLabel><div className="d-flex gap-2 align-items-center mb-2">{footerConfig?.bg_video_url ? (<video src={footerConfig.bg_video_url} muted loop autoPlay style={{ width: 80, height: 50, objectFit: "cover", borderRadius: 4, border: "1px solid #dee2e6" }} onError={(e) => { e.target.style.display = "none" }} />) : (<div style={{ width: 80, height: 50, background: "#e9ecef", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#6c757d" }}>No video</div>)}<div className="flex-grow-1"><input type="file" accept="video/*" id="footer-bg-video-upload" style={{ display: "none" }} onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadFooterMedia(f, "bg_video_url"); e.target.value = "" }} /><CButton color="primary" size="sm" variant="outline" onClick={() => document.getElementById("footer-bg-video-upload").click()} disabled={footerMediaUploading}>{footerMediaUploading ? <CSpinner size="sm" /> : "Upload Video"}</CButton>{footerConfig?.bg_video_url && <CButton color="danger" size="sm" variant="ghost" className="ms-2" onClick={() => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_video_url: "" })}>Clear</CButton>}</div></div><CFormInput value={footerConfig?.bg_video_url || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_video_url: e.target.value })} placeholder="Or paste video URL" size="sm" className="mb-2" /><CFormLabel className="small mb-1">Poster Image (optional — shown before video loads)</CFormLabel><div className="d-flex gap-2 align-items-center mb-2"><input type="file" accept="image/*" id="footer-bg-poster-upload" style={{ display: "none" }} onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadFooterMedia(f, "bg_video_poster"); e.target.value = "" }} /><CButton color="light" size="sm" variant="outline" onClick={() => document.getElementById("footer-bg-poster-upload").click()} disabled={footerMediaUploading}>Upload Poster</CButton>{footerConfig?.bg_video_poster && <CButton color="danger" size="sm" variant="ghost" onClick={() => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_video_poster: "" })}>Clear Poster</CButton>}</div><div className="d-flex gap-3 mt-2"><div className="d-flex align-items-center gap-1"><CFormSwitch checked={footerConfig?.bg_video_loop !== false} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_video_loop: e.target.checked })} /><small>Loop</small></div><div className="d-flex align-items-center gap-1"><CFormSwitch checked={footerConfig?.bg_video_mute !== false} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_video_mute: e.target.checked })} /><small>Mute (required for autoplay)</small></div></div></div>)}{footerConfig?.bg_type !== "color" && (<div className="p-2 mb-2 bg-white rounded border"><CFormLabel className="small mb-1">Overlay Opacity: {Math.round((footerConfig?.bg_overlay ?? 0.75) * 100)}%</CFormLabel><input type="range" min="0" max="1" step="0.05" value={footerConfig?.bg_overlay ?? 0.75} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_overlay: parseFloat(e.target.value) })} style={{ width: "100%" }} /><small className="text-muted">Higher = darker overlay = more readable text. Lower = more media visible.</small><div className="mt-2 d-flex align-items-center gap-2"><span className="small text-muted">Overlay tint:</span><input type="color" value={footerConfig?.bg_color || "#1E293B"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_color: e.target.value })} style={{ width: 30, height: 30, border: "none" }} /><span className="small text-muted">{footerConfig?.bg_color || "#1E293B"}</span></div></div>)}<div className="p-2 mb-2 bg-white rounded border"><h6 className="text-uppercase text-muted mb-2 small">Size &amp; Fit</h6><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Footer Height</CFormLabel><CFormSelect size="sm" value={footerConfig?.bg_height || "auto"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_height: e.target.value })}><option value="auto">Auto (fit content)</option><option value="300px">300px</option><option value="400px">400px</option><option value="500px">500px</option><option value="600px">600px</option></CFormSelect></CCol><CCol xs={6}><CFormLabel className="small mb-1">Object Fit</CFormLabel><CFormSelect size="sm" value={footerConfig?.bg_object_fit || "cover"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_object_fit: e.target.value })}><option value="cover">Cover (crops to fill)</option><option value="contain">Contain (no crop, letterboxed)</option><option value="fill">Fill (stretch, distorts)</option></CFormSelect></CCol></CRow><CFormLabel className="small mb-1">Minimum Height: {footerConfig?.bg_min_height || 0}px</CFormLabel><input type="range" min="0" max="800" step="10" value={footerConfig?.bg_min_height || 0} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_min_height: parseInt(e.target.value) })} style={{ width: "100%" }} /><small className="text-muted">Forces footer to be at least this tall (even if content is short). Useful with Auto height.</small></div></div><div className="p-3 mb-3 border rounded" style={{ background: "#f8f9fa" }}><h6 className="text-uppercase text-primary mb-3">🎨 Colors &amp; Placement</h6><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Heading Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.heading_color || "#FFFFFF"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), heading_color: e.target.value })} style={{ width: 36, height: 36, border: "1px solid #ced4da", borderRadius: 4, padding: 0 }} /><CFormInput value={footerConfig?.heading_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), heading_color: e.target.value })} size="sm" /></div></CCol><CCol xs={6}><CFormLabel className="small mb-1">Body Text Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.text_color || "#94A3B8"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), text_color: e.target.value })} style={{ width: 36, height: 36, border: "1px solid #ced4da", borderRadius: 4, padding: 0 }} /><CFormInput value={footerConfig?.text_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), text_color: e.target.value })} size="sm" /></div></CCol></CRow><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Link Hover Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.link_hover_color || theme.primary_color || "#FF7132"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), link_hover_color: e.target.value })} style={{ width: 36, height: 36, border: "1px solid #ced4da", borderRadius: 4, padding: 0 }} /><CFormInput value={footerConfig?.link_hover_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), link_hover_color: e.target.value })} size="sm" placeholder="Empty = primary color" /></div></CCol><CCol xs={6}><CFormLabel className="small mb-1">Copyright Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.copyright_color || footerConfig?.text_color || "#94A3B8"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), copyright_color: e.target.value })} style={{ width: 36, height: 36, border: "1px solid #ced4da", borderRadius: 4, padding: 0 }} /><CFormInput value={footerConfig?.copyright_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), copyright_color: e.target.value })} size="sm" placeholder="Empty = text color" /></div></CCol></CRow><CRow className="mb-3"><CCol xs={12}><CFormLabel className="small mb-1">Top Border Color</CFormLabel><CFormInput value={footerConfig?.border_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), border_color: e.target.value })} size="sm" placeholder="Empty = rgba(255,255,255,0.15). Accepts hex or rgba." /></CCol></CRow><h6 className="text-uppercase text-muted mb-2 mt-3">Placement</h6><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Text Alignment</CFormLabel><CFormSelect size="sm" value={footerConfig?.text_align || "left"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), text_align: e.target.value })}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol><CCol xs={6}><CFormLabel className="small mb-1">Heading Alignment</CFormLabel><CFormSelect size="sm" value={footerConfig?.heading_align || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), heading_align: e.target.value })}><option value="">Auto (follows text)</option><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol></CRow><CRow className="mb-3"><CCol xs={12}><CFormLabel className="small mb-1">Heading Text Transform</CFormLabel><CFormSelect size="sm" value={footerConfig?.heading_text_transform || "uppercase"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), heading_text_transform: e.target.value })}><option value="uppercase">UPPERCASE</option><option value="none">Normal Case</option><option value="capitalize">Capitalize Each Word</option><option value="lowercase">lowercase</option></CFormSelect></CCol></CRow><h6 className="text-uppercase text-muted mb-2 mt-3">Social Icons</h6><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Icon Background</CFormLabel><CFormInput value={footerConfig?.social_bg_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), social_bg_color: e.target.value })} size="sm" placeholder="Empty = rgba(255,255,255,0.1)" /></CCol><CCol xs={6}><CFormLabel className="small mb-1">Icon Hover BG</CFormLabel><CFormInput value={footerConfig?.social_hover_bg_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), social_hover_bg_color: e.target.value })} size="sm" placeholder="Empty = primary color" /></CCol></CRow><CRow className="mb-2"><CCol xs={6}><CFormLabel className="small mb-1">Icon Text Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.social_icon_color || "#FFFFFF"} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), social_icon_color: e.target.value })} style={{ width: 36, height: 36, border: "1px solid #ced4da", borderRadius: 4, padding: 0 }} /><CFormInput value={footerConfig?.social_icon_color || ""} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), social_icon_color: e.target.value })} size="sm" /></div></CCol></CRow></div><div className="p-3 mb-3 border rounded"><div className="d-flex align-items-center justify-content-between mb-3"><CFormLabel className="mb-0">Footer Enabled</CFormLabel><CFormSwitch checked={footerConfig?.enabled !== false} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), enabled: e.target.checked })} /></div><CRow><CCol xs={6}><CFormLabel>BG Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.bg_color || '#1E293B'} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_color: e.target.value })} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={footerConfig?.bg_color || ''} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), bg_color: e.target.value })} /></div></CCol><CCol xs={6}><CFormLabel>Text Color</CFormLabel><div className="d-flex gap-2"><input type="color" value={footerConfig?.text_color || '#94A3B8'} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), text_color: e.target.value })} style={{ width: 40, height: 40, border: 'none' }} /><CFormInput value={footerConfig?.text_color || ''} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), text_color: e.target.value })} /></div></CCol></CRow></div>
              <div className="d-flex justify-content-between align-items-center mb-2"><h6 className="text-uppercase text-muted mb-0">Footer Columns ({footerConfig?.columns?.length || 0})</h6><CButton color="success" size="sm" onClick={() => { const cols = [...(footerConfig?.columns || [])]; cols.push({ id: 'col-' + Date.now(), title: 'New Column', type: 'text', content: 'Column content...' }); setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }}><Plus size={14} className="me-1" /> Add Column</CButton></div>
              {(footerConfig?.columns || []).map((col, index) => (<div key={col.id} className="p-3 mb-2 border rounded bg-light"><div className="d-flex justify-content-between align-items-center mb-2"><span className="badge bg-secondary">Column {index + 1}</span><CButton color="danger" size="sm" variant="ghost" onClick={() => { const cols = (footerConfig?.columns || []).filter((_, i) => i !== index); setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }}><Trash2 size={14} /></CButton></div><CFormLabel>Title</CFormLabel><CFormInput value={col.title} onChange={(e) => { const cols = [...(footerConfig?.columns || [])]; cols[index] = { ...col, title: e.target.value }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }} className="mb-2" /><CFormLabel>Type</CFormLabel><CFormSelect value={col.type} onChange={(e) => { const cols = [...(footerConfig?.columns || [])]; cols[index] = { ...col, type: e.target.value }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }} className="mb-2"><option value="text">Text</option><option value="links">Links</option><option value="social">Social</option></CFormSelect>{col.type === 'text' && <><CFormLabel>Content</CFormLabel><CFormTextarea value={col.content || ''} onChange={(e) => { const cols = [...(footerConfig?.columns || [])]; cols[index] = { ...col, content: e.target.value }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }} rows={2} /></>}{col.type === 'links' && <>{(col.links || []).map((lnk, li) => (<div key={li} className="d-flex gap-2 mb-1"><CFormInput value={lnk.label} placeholder="Label" onChange={(e) => { const cols = [...(footerConfig?.columns || [])]; const links = [...(col.links || [])]; links[li] = { ...lnk, label: e.target.value }; cols[index] = { ...col, links }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }} /><CFormInput value={lnk.url} placeholder="URL" onChange={(e) => { const cols = [...(footerConfig?.columns || [])]; const links = [...(col.links || [])]; links[li] = { ...lnk, url: e.target.value }; cols[index] = { ...col, links }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }} /><CButton color="danger" size="sm" variant="ghost" onClick={() => { const cols = [...(footerConfig?.columns || [])]; const links = (col.links || []).filter((_, i) => i !== li); cols[index] = { ...col, links }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }}><X size={12} /></CButton></div>))}<CButton color="success" size="sm" variant="outline" onClick={() => { const cols = [...(footerConfig?.columns || [])]; const links = [...(col.links || []), { label: 'New Link', url: '/' }]; cols[index] = { ...col, links }; setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), columns: cols }); }}><Plus size={12} className="me-1" /> Add Link</CButton></>}</div>))}
              <div className="p-3 border rounded"><h6 className="text-uppercase text-muted mb-3">Bottom Bar</h6><CFormLabel>Copyright Text</CFormLabel><CFormInput value={footerConfig?.copyright || ''} onChange={(e) => setFooterConfig({ ...(footerConfig || DEFAULT_FOOTER), copyright: e.target.value })} className="mb-3" /></div>
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'products'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center"><strong>Product Display Settings</strong><CButton color="warning" size="sm" variant="outline" onClick={() => setProductDisplayConfig(null)}>Reset</CButton></CCardHeader>
            <CCardBody>
              <CRow>
                <CCol md={6}><CFormLabel>Default View</CFormLabel><div className="d-flex gap-2 mb-3"><CButton color={pdCfg.default_view === 'grid' ? 'primary' : 'outline-secondary'} size="sm" onClick={() => updateProductDisplay('default_view', 'grid')}>Grid</CButton><CButton color={pdCfg.default_view === 'list' ? 'primary' : 'outline-secondary'} size="sm" onClick={() => updateProductDisplay('default_view', 'list')}>List</CButton></div></CCol>
                <CCol md={6}><CFormLabel>Products Per Row</CFormLabel><CFormSelect value={pdCfg.products_per_row || 4} onChange={(e) => updateProductDisplay('products_per_row', parseInt(e.target.value))} className="mb-3"><option value={2}>2</option><option value={3}>3</option><option value={4}>4</option><option value={5}>5</option></CFormSelect></CCol>
              </CRow>
              <CRow>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Show MRP</strong></span><CFormSwitch checked={pdCfg.show_mrp !== false} onChange={(e) => updateProductDisplay('show_mrp', e.target.checked)} /></div></CCol>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Show Discount</strong></span><CFormSwitch checked={pdCfg.show_discount !== false} onChange={(e) => updateProductDisplay('show_discount', e.target.checked)} /></div></CCol>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Show Rating</strong></span><CFormSwitch checked={pdCfg.show_rating !== false} onChange={(e) => updateProductDisplay('show_rating', e.target.checked)} /></div></CCol>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Show Stock</strong></span><CFormSwitch checked={pdCfg.show_stock !== false} onChange={(e) => updateProductDisplay('show_stock', e.target.checked)} /></div></CCol>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Show Unit</strong></span><CFormSwitch checked={pdCfg.show_unit !== false} onChange={(e) => updateProductDisplay('show_unit', e.target.checked)} /></div></CCol>
                <CCol xs={12} md={6}><div className="d-flex justify-content-between align-items-center p-2 mb-2 bg-light rounded border"><span><strong>Quick View</strong></span><CFormSwitch checked={pdCfg.quick_view !== false} onChange={(e) => updateProductDisplay('quick_view', e.target.checked)} /></div></CCol>
              </CRow>
              <CRow>
                <CCol md={6}><CFormLabel>Default Sort</CFormLabel><CFormSelect value={pdCfg.default_sort || 'name_asc'} onChange={(e) => updateProductDisplay('default_sort', e.target.value)} className="mb-3"><option value="name_asc">Name A→Z</option><option value="name_desc">Name Z→A</option><option value="price_asc">Price Low→High</option><option value="price_desc">Price High→Low</option></CFormSelect></CCol>
                <CCol md={6}><CFormLabel>Out-of-Stock</CFormLabel><CFormSelect value={pdCfg.out_of_stock_behavior || 'dim'} onChange={(e) => updateProductDisplay('out_of_stock_behavior', e.target.value)} className="mb-3"><option value="dim">Dim</option><option value="badge">Badge</option><option value="hide">Hide</option></CFormSelect></CCol>
              </CRow>
            </CCardBody>
          </CCard>
        </CTabPane>

        <CTabPane visible={activeTab === 'pages'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center"><strong>Custom Pages</strong><CButton color="success" size="sm" onClick={() => { const title = prompt('Enter page title:'); if (!title) return; const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); setCustomPages([...customPages, { id: 'page-' + Date.now(), title, slug, seo_title: title + (theme.brand_name ? ' | ' + theme.brand_name : ''), seo_description: '', show_in_navbar: false, sections: [{ id: 'hero', type: 'hero', data: { alignment: 'center', badge: '', title, subtitle: '' } }, { id: 'text-1', type: 'text_block', data: { title: '', content: 'Enter content...', alignment: 'left', bg_color: '#fff' } }] }]); }}><Plus size={14} className="me-1" /> Create New Page</CButton></CCardHeader>
            <CCardBody>
              {customPages.length === 0 && <div className="text-center text-muted py-4"><p>No custom pages yet. Create FAQ, Privacy Policy, etc.</p></div>}
              {customPages.map((page, pageIndex) => (
                <div key={page.id} className="p-3 mb-3 border rounded bg-light">
                  <div className="d-flex justify-content-between align-items-center mb-3"><div><h6 className="mb-0">{page.title}</h6><small className="text-muted">/page/{page.slug}</small></div><div className="d-flex gap-1"><CButton color="light" size="sm" onClick={() => { const newSlug = prompt('Edit URL slug:', page.slug); if (newSlug) { const pages = [...customPages]; pages[pageIndex] = { ...page, slug: newSlug.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') }; setCustomPages(pages); } }}>Edit Slug</CButton><CButton color="danger" size="sm" variant="ghost" onClick={() => { if (confirm('Delete this page?')) { setCustomPages(customPages.filter((_, i) => i !== pageIndex)); } }}><Trash2 size={14} /></CButton></div></div>
                  <div className="p-2 mb-2 bg-white rounded border"><CFormLabel className="mb-1 small">SEO Title</CFormLabel><CFormInput value={page.seo_title || ''} size="sm" className="mb-2" onChange={(e) => { const pages = [...customPages]; pages[pageIndex] = { ...page, seo_title: e.target.value }; setCustomPages(pages); }} /><CFormLabel className="mb-1 small">SEO Description</CFormLabel><CFormInput value={page.seo_description || ''} size="sm" className="mb-2" onChange={(e) => { const pages = [...customPages]; pages[pageIndex] = { ...page, seo_description: e.target.value }; setCustomPages(pages); }} /><div className="d-flex align-items-center gap-2"><CFormSwitch checked={page.show_in_navbar || false} onChange={(e) => { const pages = [...customPages]; pages[pageIndex] = { ...page, show_in_navbar: e.target.checked }; setCustomPages(pages); }} /><small>Show in navbar</small></div></div>
                  <div className="mb-2"><div className="d-flex justify-content-between align-items-center mb-1"><small className="fw-bold text-muted">Sections ({page.sections?.length || 0})</small><CButton color="success" size="sm" variant="outline" onClick={() => { const sectionTypes = [{ type: 'text_block', label: 'Text Block', data: { title: 'New Section', content: 'Enter content...', alignment: 'left', bg_color: '#fff' } }, { type: 'image_block', label: 'Image Block', data: { image_url: [], alt_text: '', bg_color: '#fff' } }, { type: 'spacer', label: 'Spacer', data: { height: 40 } }, { type: 'divider', label: 'Divider', data: { color: '#E2E8F0', thickness: 1 } }, { type: 'html_block', label: 'HTML Block', data: { html: '<p>Custom HTML</p>' } }, { type: 'youtube_video', label: 'YouTube Video', data: { youtube_url: '', title: '', caption: '', autoplay: false, loop: false, start_time: 0, alignment: 'left' }, layout: { width: 'full', content_align: 'center', text_align: 'left' } }, { type: 'media_carousel', label: 'Media Carousel (Images + Videos)', data: { items: [], height: 'medium', object_fit: 'cover', interval_seconds: 5 }, layout: { width: 'full', content_align: 'center', text_align: 'left' } }]; const options = sectionTypes.map((s, i) => `${i + 1}. ${s.label}`).join('\n'); const choice = prompt(`Add section:\n\n${options}\n\nEnter number:`, '1'); const idx = parseInt(choice) - 1; if (idx < 0 || idx >= sectionTypes.length) return; const pages = [...customPages]; const newSection = { id: 'sec-' + Date.now(), ...sectionTypes[idx] }; pages[pageIndex] = { ...page, sections: [...(page.sections || []), newSection] }; setCustomPages(pages); }}><Plus size={12} className="me-1" /> Add Section</CButton></div>
                    {(page.sections || []).map((section, secIndex) => (
                      <div key={section.id || secIndex} className="p-2 mb-1 bg-white rounded border">
                        <div className="d-flex justify-content-between align-items-center mb-1"><span className="badge bg-secondary">{secIndex + 1}. {section.type}</span><div className="d-flex gap-1"><CButton color="light" size="sm" disabled={secIndex === 0} onClick={() => { const pages = [...customPages]; const secs = [...page.sections];[secs[secIndex - 1], secs[secIndex]] = [secs[secIndex], secs[secIndex - 1]]; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><ChevronUp size={12} /></CButton><CButton color="light" size="sm" disabled={secIndex === (page.sections || []).length - 1} onClick={() => { const pages = [...customPages]; const secs = [...page.sections];[secs[secIndex], secs[secIndex + 1]] = [secs[secIndex + 1], secs[secIndex]]; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><ChevronDown size={12} /></CButton><CButton color="danger" size="sm" variant="ghost" onClick={() => { const pages = [...customPages]; pages[pageIndex] = { ...page, sections: page.sections.filter((_, i) => i !== secIndex) }; setCustomPages(pages); }}><Trash2 size={12} /></CButton></div></div>
                        {section.type === 'hero' && (<div><CFormInput value={section.data?.title || ''} placeholder="Hero Title" size="sm" className="mb-1" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, title: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CFormTextarea value={section.data?.subtitle || ''} placeholder="Subtitle" rows={1} size="sm" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, subtitle: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></div>)}
                        {section.type === 'text_block' && (<div><CFormInput value={section.data?.title || ''} placeholder="Section Title" size="sm" className="mb-1" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, title: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CFormTextarea value={section.data?.content || ''} placeholder="Content" rows={3} size="sm" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, content: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></div>)}
                        {section.type === 'image_block' && (<div><CFormLabel className="small">Image URLs (one per line for carousel)</CFormLabel><CFormTextarea value={Array.isArray(section.data?.image_url) ? section.data?.image_url.join('\n') : (section.data?.image_url || '')} placeholder="https://image1.jpg" rows={2} size="sm" onChange={(e) => { const urls = e.target.value.split('\n').filter(Boolean); const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, image_url: urls.length === 1 ? urls[0] : urls } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></div>)}
                        {section.type === 'spacer' && (<CFormInput type="number" value={section.data?.height || 40} placeholder="Height (px)" size="sm" style={{ width: 120 }} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, height: parseInt(e.target.value) } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} />)}
                        {section.type === 'divider' && (<div className="d-flex gap-2"><CFormInput type="color" value={section.data?.color || '#E2E8F0'} size="sm" style={{ width: 60 }} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, color: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CFormInput type="number" value={section.data?.thickness || 1} placeholder="Thickness" size="sm" style={{ width: 100 }} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, thickness: parseInt(e.target.value) } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></div>)}
                        {section.type === 'html_block' && (<CFormTextarea value={section.data?.html || ''} placeholder="HTML code" rows={3} size="sm" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, html: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} />)}
                        {section.type === 'media_carousel' && (<div><small className='text-muted d-block mb-1'>Add images and/or videos. Image slides show text overlay; video slides auto-advance when video ends.</small><div className='d-flex justify-content-between align-items-center mb-1'><small className='fw-bold text-muted'>Items ({(section.data?.items || []).length})</small><CButton color='success' size='sm' variant='outline' onClick={() => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, items: [...(section.data?.items || []), { id: 'item-' + Date.now(), type: 'image', url: '', title: '', subtitle: '', badge: '', btn_text: '', btn_link: '' }] } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><Plus size={12} className='me-1' /> Add Item</CButton></div>{(section.data?.items || []).map((item, itemIdx) => (<div key={itemIdx} className='p-2 mb-1 bg-white rounded border'><div className='d-flex justify-content-between align-items-center mb-1'><span className='badge bg-secondary'>{itemIdx + 1}: {item.type || 'image'}</span><div className='d-flex gap-1'><CButton color='light' size='sm' disabled={itemIdx === 0} onClick={() => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])];[items[itemIdx - 1], items[itemIdx]] = [items[itemIdx], items[itemIdx - 1]]; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><ChevronUp size={10} /></CButton><CButton color='light' size='sm' disabled={itemIdx === (section.data?.items || []).length - 1} onClick={() => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])];[items[itemIdx], items[itemIdx + 1]] = [items[itemIdx + 1], items[itemIdx]]; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><ChevronDown size={10} /></CButton><CButton color='danger' size='sm' variant='ghost' onClick={() => { const pages = [...customPages]; const secs = [...page.sections]; const items = (section.data?.items || []).filter((_, i) => i !== itemIdx); secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><Trash2 size={10} /></CButton></div></div><CRow className='mb-1'><CCol xs={4}><CFormSelect size='sm' value={item.type || 'image'} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, type: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value='image'>Image</option><option value='video'>Video</option></CFormSelect></CCol><CCol xs={8}><CFormInput value={item.url || ""} size='sm' placeholder='URL' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, url: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol></CRow>{item.type === 'image' && (<div><CRow><CCol xs={6}><CFormInput value={item.badge || ""} size='sm' className='mb-1' placeholder='Badge' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, badge: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol><CCol xs={6}><CFormInput value={item.title || ""} size='sm' className='mb-1' placeholder='Title' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, title: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol></CRow><CFormInput value={item.subtitle || ""} size='sm' className='mb-1' placeholder='Subtitle' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, subtitle: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CRow><CCol xs={6}><CFormInput value={item.btn_text || ""} size='sm' placeholder='Button text' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, btn_text: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol><CCol xs={6}><CFormInput value={item.btn_link || ""} size='sm' placeholder='Button link' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, btn_link: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol></CRow></div>)}{item.type === 'video' && (<CFormInput value={item.poster || ""} size='sm' placeholder='Poster image URL (optional)' onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; const items = [...(section.data?.items || [])]; items[itemIdx] = { ...item, poster: e.target.value }; secs[secIndex] = { ...section, data: { ...section.data, items } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} />)}</div>))}<CRow className='mt-1'><CCol xs={4}><CFormSelect size='sm' value={section.data?.height || 'medium'} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, height: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value='small'>Small</option><option value='medium'>Medium</option><option value='large'>Large</option><option value='full'>Full</option></CFormSelect></CCol><CCol xs={4}><CFormSelect size='sm' value={section.data?.object_fit || 'cover'} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, object_fit: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value='cover'>Cover</option><option value='contain'>Contain</option><option value='fill'>Fill</option></CFormSelect></CCol><CCol xs={4}><CFormInput type='number' size='sm' value={section.data?.interval_seconds || 5} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, interval_seconds: parseInt(e.target.value) || 5 } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></CCol></CRow></div>)}
                        {section.type === 'youtube_video' && (<div><CFormLabel className="small">YouTube URL</CFormLabel><CFormInput value={section.data?.youtube_url || ''} placeholder="https://www.youtube.com/watch?v=..." size="sm" className="mb-1" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, youtube_url: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CFormLabel className="small">Title (optional)</CFormLabel><CFormInput value={section.data?.title || ''} placeholder="Video title" size="sm" className="mb-1" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, title: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><CFormLabel className="small">Caption (optional)</CFormLabel><CFormInput value={section.data?.caption || ''} placeholder="Short text below video" size="sm" className="mb-1" onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, caption: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><div className="d-flex gap-3 mt-2"><div className="d-flex align-items-center gap-1"><CFormSwitch checked={section.data?.autoplay || false} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, autoplay: e.target.checked } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><small>Autoplay</small></div><div className="d-flex align-items-center gap-1"><CFormSwitch checked={section.data?.loop || false} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, loop: e.target.checked } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /><small>Loop</small></div><div className="d-flex align-items-center gap-1"><small>Start (s):</small><CFormInput type="number" value={section.data?.start_time || 0} size="sm" style={{ width: 80 }} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, start_time: parseInt(e.target.value) || 0 } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }} /></div></div><div className="p-2 mt-2 border rounded bg-light"><small className="fw-bold text-muted d-block mb-2">🎨 Video Placement</small><CFormLabel className="mb-0 small">Width</CFormLabel><CFormSelect size="sm" className="mb-2" value={section.layout?.width || "full"} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, layout: { ...(section.layout || {}), width: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value="full">Full Width (100%)</option><option value="contained">Contained Block (800px)</option><option value="half">Half Width (50% — side-by-side)</option></CFormSelect><CRow className="mb-2"><CCol xs={6}><CFormLabel className="mb-0 small">Video Position</CFormLabel><CFormSelect size="sm" value={section.layout?.content_align || "center"} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, layout: { ...(section.layout || {}), content_align: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol><CCol xs={6}><CFormLabel className="mb-0 small">Title/Caption Align</CFormLabel><CFormSelect size="sm" value={section.data?.alignment || "left"} onChange={(e) => { const pages = [...customPages]; const secs = [...page.sections]; secs[secIndex] = { ...section, data: { ...section.data, alignment: e.target.value } }; pages[pageIndex] = { ...page, sections: secs }; setCustomPages(pages); }}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></CFormSelect></CCol></CRow><small className="text-muted d-block mt-1">Tip: Set Width=Half + Position=Left to place the video on the left half. Two consecutive Half sections sit side-by-side.</small></div></div>)}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CCardBody>
          </CCard>
        </CTabPane>

        {/* ─────── PREVIEW TAB ─────── */}
        <CTabPane visible={activeTab === 'preview'}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center">
              <strong>Live Website Preview</strong>
              <div className="d-flex align-items-center gap-2">
                <small>Viewing:</small>
                <CFormSelect value={activePage} onChange={(e) => setActivePage(e.target.value)} style={{ width: 'auto' }}>
                  <option value="home">Home Page</option><option value="about">About Page</option><option value="contact">Contact Page</option><option value="profile">Profile Page</option><option value="subscriptions">Subscriptions Page</option><option value="addresses">Addresses Page</option><option value="orders">Orders Page</option><option value="privacy">Privacy Page</option>
                </CFormSelect>
              </div>
            </CCardHeader>
            <CCardBody style={{ padding: 0, background: '#e9ecef' }}>
              {/* Browser Chrome */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 10, background: '#dee2e6', borderBottom: '1px solid #ced4da' }}>
                <div style={{ display: 'flex', gap: 6 }}>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#ff5f56' }}></div>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#ffbd2e' }}></div>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#27c93f' }}></div>
                </div>
                <div style={{ flex: 1, background: '#fff', borderRadius: 4, padding: '4px 12px', fontSize: '12px', color: '#6c757d', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ color: '#20c997' }}>🔒</span>
                  https://{theme.brand_name?.toLowerCase().replace(/\s/g, '')}.localhost:5174/{activePage}
                </div>
              </div>

              {/* Rendered Content Container */}
              <div style={{ height: '75vh', overflowY: 'auto', background: theme.background_pattern === 'dotted' ? 'radial-gradient(circle, #e2e8f0 1px, transparent 1px)' : '#fff', backgroundSize: '20px 20px' }}>

                {/* Fake Web Navbar */}
                <div style={{ background: theme.secondary_color || '#1E293B', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#fff' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    {theme.logo_url && <img src={theme.logo_url} alt="logo" style={{ height: '28px' }} />}
                    <span style={{ fontWeight: 800, fontSize: '16px' }}>{theme.brand_name || 'Brand Name'}</span>
                  </div>
                  <div style={{ display: 'flex', gap: '16px' }}>
                    {(navigationConfig?.links || []).filter(l => l.visible !== false).map((link, i) => (
                      <span key={i} style={{ fontSize: '13px', fontWeight: 500 }}>{link.label}</span>
                    ))}
                  </div>
                </div>

                {/* Render Active Page Content */}
                {activePage === 'home' && (
                  <div>
                    {/* Hero */}
                    <div style={{ position: 'relative', minHeight: '400px', display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: hero.alignment || 'center', background: carouselImages.length > 0 ? '#000' : (theme.primary_color || '#666666') }}>
                      {carouselImages.length > 0 && (
                        <>
                          <img src={carouselImages[0]} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', opacity: 0.6 }} />
                          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, rgba(0,0,0,0.7), rgba(0,0,0,0.4))' }} />
                        </>
                      )}
                      <div style={{ position: 'relative', zIndex: 2, padding: '40px', maxWidth: '800px' }}>
                        {hero.badge && <span style={{ display: 'inline-block', background: 'rgba(255,255,255,0.2)', color: '#fff', padding: '6px 16px', borderRadius: '20px', fontSize: '13px', fontWeight: 700, marginBottom: '16px' }}>{hero.badge}</span>}
                        <h1 style={{ color: '#fff', fontSize: '48px', fontWeight: 900, margin: '0 0 16px' }}>{hero.title}</h1>
                        <p style={{ color: 'rgba(255,255,255,0.9)', fontSize: '18px', marginBottom: '24px' }}>{hero.subtitle}</p>
                        {hero.primary_btn_text && <button style={{ padding: '12px 24px', background: '#fff', color: theme.primary_color, border: 'none', borderRadius: theme.border_radius || 8, fontWeight: 700, fontSize: '15px' }}>{hero.primary_btn_text}</button>}
                      </div>
                    </div>
                    {/* Mission */}
                    <div style={{ padding: '60px 24px', background: '#fff', textAlign: 'center' }}>
                      <h2 style={{ fontSize: '32px', fontWeight: 800, color: theme.secondary_color, marginBottom: '40px' }}>{mission.title}</h2>
                      <div style={{ display: 'flex', gap: '24px', justifyContent: 'center' }}>
                        <div style={{ maxWidth: '400px', padding: '24px', background: '#f8f9fa', borderRadius: '12px' }}>
                          <h3 style={{ color: theme.primary_color, fontWeight: 700, marginBottom: '12px' }}>Mission</h3>
                          <p style={{ color: '#64748b', fontSize: '15px' }}>{mission.mission_text}</p>
                        </div>
                        <div style={{ maxWidth: '400px', padding: '24px', background: '#f8f9fa', borderRadius: '12px' }}>
                          <h3 style={{ color: theme.primary_color, fontWeight: 700, marginBottom: '12px' }}>Vision</h3>
                          <p style={{ color: '#64748b', fontSize: '15px' }}>{mission.vision_text}</p>
                        </div>
                      </div>
                    </div>
                    {/* CTA */}
                    <div style={{ padding: '60px 24px', background: theme.primary_color, textAlign: 'center' }}>
                      <h2 style={{ color: '#fff', fontSize: '32px', fontWeight: 800, marginBottom: '16px' }}>{cta.title}</h2>
                      <button style={{ padding: '12px 24px', background: '#fff', color: theme.primary_color, border: 'none', borderRadius: theme.border_radius || 8, fontWeight: 700, fontSize: '15px' }}>{cta.btn1_text}</button>
                    </div>
                  </div>
                )}

                {activePage === 'about' && (
                  <div style={{ padding: '60px 24px', background: '#fff', maxWidth: '1000px', margin: '0 auto' }}>
                    <div style={{ textAlign: 'center', marginBottom: '40px' }}>
                      {hero.badge && <span style={{ display: 'inline-block', background: theme.primary_color, color: '#fff', padding: '4px 12px', borderRadius: '12px', fontSize: '12px', fontWeight: 700 }}>{hero.badge}</span>}
                      <h1 style={{ fontSize: '40px', fontWeight: 900, color: theme.secondary_color, marginTop: '12px' }}>{hero.title}</h1>
                      <p style={{ fontSize: '18px', color: '#64748b' }}>{hero.subtitle}</p>
                    </div>
                    <div style={{ background: '#f8f9fa', padding: '24px', borderRadius: '12px', marginBottom: '24px' }}>
                      <h2 style={{ fontWeight: 800, color: theme.secondary_color }}>{story.title}</h2>
                      <p style={{ color: '#64748b', lineHeight: 1.6 }}>{story.desc1}</p>
                    </div>
                  </div>
                )}

                {activePage === 'contact' && (
                  <div style={{ padding: '60px 24px', background: '#fff', maxWidth: '800px', margin: '0 auto' }}>
                    <h1 style={{ fontSize: '40px', fontWeight: 900, color: theme.secondary_color, textAlign: 'center' }}>{hero.title}</h1>
                    <p style={{ fontSize: '18px', color: '#64748b', textAlign: 'center', marginBottom: '40px' }}>{hero.subtitle}</p>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                      <div style={{ padding: '24px', border: '1px solid #e2e8f0', borderRadius: '12px' }}>
                        <h3 style={{ color: theme.primary_color, fontWeight: 700, marginBottom: '8px' }}>Address</h3>
                        <p style={{ color: '#64748b' }}>{info.address}</p>
                      </div>
                      <div style={{ padding: '24px', border: '1px solid #e2e8f0', borderRadius: '12px' }}>
                        <h3 style={{ color: theme.primary_color, fontWeight: 700, marginBottom: '8px' }}>Phone</h3>
                        <p style={{ color: '#64748b' }}>{info.phone}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Fake Web Footer */}
                <div style={{ background: footerConfig?.bg_color || '#1E293B', color: footerConfig?.text_color || '#94A3B8', padding: '40px 24px', marginTop: '40px' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '24px', maxWidth: '1200px', margin: '0 auto' }}>
                    {(footerConfig?.columns || []).map((col, i) => (
                      <div key={i}>
                        <h4 style={{ color: '#fff', fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>{col.title}</h4>
                        {col.type === 'text' && <p style={{ fontSize: '14px' }}>{col.content}</p>}
                        {col.type === 'links' && (col.links || []).map((l, li) => <div key={li} style={{ fontSize: '14px', marginBottom: '8px' }}>{l.label}</div>)}
                      </div>
                    ))}
                  </div>
                  <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', marginTop: '32px', paddingTop: '16px', textAlign: 'center', fontSize: '12px' }}>
                    {footerConfig?.copyright || ''}
                  </div>
                </div>

              </div>
            </CCardBody>
          </CCard>
        </CTabPane>
      </CTabContent>
    </>
  )
}

export default WebBuilder