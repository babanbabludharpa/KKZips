import { useEffect, useState, useCallback, useRef } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CBadge,
  CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect, CRow, CCol, CFormSwitch, CFormCheck, CFormTextarea, CInputGroup, CInputGroupText  // ★ added CFormTextarea
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPlus, cilPencil, cilTrash, cilArrowTop, cilArrowBottom, cilCloudUpload,
  cilCopy, cilHistory, cilCheckCircle, cilXCircle, cilPhone
} from '@coreui/icons'
import api from '../../api/api'

// ─────────────────────────────────────────────────────────────────────
// Component type registry — MUST match backend AppLayoutValidator + Flutter
// ─────────────────────────────────────────────────────────────────────
const COMPONENT_TYPES = [
  { value: 'app_settings',        label: 'App Settings (Login BG, etc.)' },
  { value: 'carousel',           label: 'Promotional Carousel' },
  { value: 'dashboard_menu',     label: 'Dashboard Menu Tiles' },
  { value: 'quick_calendar',     label: 'Subscription Calendar' },
  { value: 'popular_products',   label: 'Popular Products (Horizontal)' },
  { value: 'categories_grid',    label: 'Categories Row / Grid' },
  { value: 'all_products',       label: 'All Products Grid' },
  { value: 'subscription_plans', label: 'Subscription Plans' },
]

const ACTION_TYPES = [
  { value: 'none',               label: 'No action' },
  { value: 'product',            label: 'Open product' },
  { value: 'category',           label: 'Open category' },
  { value: 'subscription_plan',  label: 'Open subscription plan' },
  { value: 'url',                label: 'Open external URL' },
  { value: 'route',              label: 'In-app route' },
]

const DASHBOARD_ROUTES = [
  { value: 'profile',       label: 'Profile' },
  { value: 'subscriptions', label: 'Subscriptions' },
  { value: 'products',      label: 'Products' },
  { value: 'orders',        label: 'Orders' },
  { value: 'cart',          label: 'Cart' },
  { value: 'addresses',     label: 'Addresses' },
]

const DASHBOARD_ICONS = [
  'person', 'calendar', 'shopping_bag', 'receipt', 'cart', 'location', 'star', 'settings'
]

const uuid = () => crypto.randomUUID?.() ?? Math.random().toString(36).slice(2)

const blankComponent = (type) => {
  const base = { id: uuid(), type, visible: true, title: '', data: {} }
  switch (type) {
    case 'app_settings':
      return { ...base, data: { login_bg_image: '' } }
    case 'carousel':
      return { ...base, data: { autoplay: true, interval_seconds: 4, aspect_ratio: '16:9', images: [] } }
    case 'dashboard_menu':
      return { ...base, data: { title: 'What would you like to do?', columns: 1, items: [
        { id: uuid(), label: 'My Profile', icon: 'person', color: '#2563EB', route: 'profile' }
      ]}}
    case 'quick_calendar':
      return { ...base, title: "This Week's Deliveries", data: { days_to_show: 7, subscription_plan_id: null, show_only_delivery_days: true, empty_state_text: 'No deliveries scheduled.' } }
    case 'popular_products':
      return { ...base, title: 'Trending Products', data: { source: 'recent', product_ids: [], fallback_strategy: 'recent', limit: 8 } }
    case 'categories_grid':
      return { ...base, title: 'Shop by Category', data: { layout: 'circle', category_ids: [], limit: 10, show_all: true } }
    case 'all_products':
      return { ...base, title: 'All Products', data: { category_id: null, sort_by: 'name_asc', columns: 2, page_size: 20 } }
    case 'subscription_plans':
      return { ...base, title: 'Subscribe & Save', data: { plan_ids: [], show_all: true, limit: 6 } }
    default:
      return base
  }
}

// ═══════════════════════════════════════════════════════════════════
// ★ NEW: Default legal document templates for the customer white-label app.
// Tenants see these as starting content; they can edit/replace/delete.
// Rider app legal docs stay hardcoded in the rider Flutter app — NOT editable here.
// ═══════════════════════════════════════════════════════════════════
const DEFAULT_CUSTOMER_APP_PRIVACY = {
  hero: {
    badge: 'Privacy Policy',
    title: 'How We Protect Your Data',
    subtitle: 'Your trust is important to us. Learn how we collect, use, and safeguard your personal information when you use our app.',
    last_updated: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
  },
  intro: {
    title: 'Our Commitment to Your Privacy',
    content: 'We are committed to maintaining the confidentiality and security of your personal information. This Privacy Policy explains our practices regarding the collection, use, and disclosure of data when you use our mobile application and related services.',
  },
  sections: [
    { id: 'sec1', icon: 'Database', title: '1. Information We Collect', content: 'To provide our services, we collect the following types of information:\n\n• Personal Details: Full name, phone number, and email address when you register.\n• Delivery Data: Exact delivery address, GPS location (with your permission), and delivery instructions.\n• Device Data: Device ID, push notification token, app version, and OS version.\n• Usage Data: Order history, subscription preferences, and interactions with our app.' },
    { id: 'sec2', icon: 'Eye', title: '2. How We Use Your Data', content: 'We use your information primarily to deliver our services:\n\n• To process and deliver your orders and subscriptions.\n• To manage your Wallet and process automated deductions for subscriptions.\n• To send important updates: delivery status, low wallet balance alerts, and OTPs for secure login.\n• To improve our app\'s performance and customer support.' },
    { id: 'sec3', icon: 'Bell', title: '3. Permissions We Request', content: 'Our app requests the following device permissions:\n\n• Location: To show products available in your area and to enable accurate deliveries.\n• Notifications: To send you delivery updates, OTPs, and wallet alerts.\n• Camera (optional): For KYC verification if required.\n• Storage (optional): For saving invoices and order receipts.\n\nYou can revoke any of these permissions anytime from your device settings.' },
    { id: 'sec4', icon: 'CreditCard', title: '4. Data Security & Payments', content: 'Your financial security is our top priority.\n\n• We do not store your Credit/Debit card numbers or UPI PINs on our servers.\n• All online payments and wallet recharges are securely processed through our PCI-DSS compliant payment gateway partner.\n• Your personal data is encrypted and stored on secure cloud servers with restricted access.' },
    { id: 'sec5', icon: 'Users', title: '5. Information Sharing', content: 'We do not sell your personal data to third-party marketers. However, we may share specific information under the following circumstances:\n\n• Delivery Partners: We share your name, phone number, and address with our delivery executives solely for the purpose of fulfilling your order.\n• Legal Compliance: If required by law, court order, or government regulation to protect the rights and safety of our users.' },
    { id: 'sec6', icon: 'UserCog', title: '6. Your Privacy Rights', content: 'You have full control over your personal data:\n\n• Access & Update: You can update your phone number, addresses, and subscription details anytime from your Profile.\n• Account Deletion: You can request account deletion by contacting our support team. Upon deletion, any remaining wallet balance will be refunded, and your personal data will be erased from our active database (subject to legal retention requirements).' },
    { id: 'sec7', icon: 'AlertCircle', title: '7. Policy Updates', content: 'We may update this Privacy Policy periodically to reflect changes in our practices or legal requirements. The updated version will be indicated by an updated "Last Modified" date at the top of this page. We encourage you to review this policy regularly.' },
  ],
  contact: {
    heading: 'Have Privacy Concerns?',
    text: 'If you have any questions about how we handle your data, please reach out to us.',
    email: 'support@example.com',
    btn_text: 'Email Us',
  },
}

const DEFAULT_CUSTOMER_APP_TERMS = {
  hero: {
    badge: 'Terms & Conditions',
    title: 'Terms of Service',
    subtitle: 'By using our app, you agree to the following terms. Please read them carefully before placing an order or subscribing.',
    last_updated: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
  },
  intro: {
    title: 'Agreement to Terms',
    content: 'These Terms & Conditions govern your use of our mobile application and the services we provide. By registering an account, placing an order, or using any feature of the app, you confirm that you have read, understood, and agree to be bound by these terms.',
  },
  sections: [
    { id: 'sec1', icon: 'UserCog', title: '1. Account Registration', content: '• You must register with a valid phone number and verify it via OTP.\n• You must be at least 18 years old to create an account.\n• You are responsible for keeping your account credentials secure and for all activities under your account.\n• You agree to provide accurate and complete information at registration and to keep it updated.' },
    { id: 'sec2', icon: 'Calendar', title: '2. Subscriptions', content: '• Subscriptions auto-renew based on the plan you choose (daily, alternate days, weekly, custom).\n• You can pause, resume, or cancel a subscription anytime from the app with at least 12 hours notice before the next scheduled delivery.\n• Subscription prices may change with prior notice; existing subscriptions continue at the old price until the next renewal cycle.' },
    { id: 'sec3', icon: 'CreditCard', title: '3. Wallet & Payments', content: '• You can recharge your in-app Wallet via UPI, Cards, or Net Banking.\n• Subscription payments are auto-deducted from your Wallet on the delivery date.\n• If your Wallet balance is insufficient, the delivery will be skipped and you will be notified.\n• Refunds for failed deliveries are credited back to your Wallet within 3-5 business days.' },
    { id: 'sec4', icon: 'MapPin', title: '4. Delivery Terms', content: '• We deliver only to addresses within our serviceable zones.\n• Delivery times are estimates and may vary due to traffic, weather, or operational reasons.\n• You must provide an accurate delivery address with a working pin location.\n• If you are unavailable at delivery, the order may be returned and a redelivery fee may apply.' },
    { id: 'sec5', icon: 'Shield', title: '5. Returns & Refunds', content: '• Perishable items (milk, vegetables, tiffin) cannot be returned once delivered.\n• Non-perishable items can be returned within 24 hours if damaged, spoiled, or wrong.\n• Refunds for returned items are credited to your Wallet within 3-5 business days.\n• For any quality complaint, contact support within 12 hours of delivery with photos.' },
    { id: 'sec6', icon: 'AlertCircle', title: '6. Account Suspension', content: 'We reserve the right to suspend or terminate your account if:\n\n• You misuse the wallet or subscription system.\n• You engage in fraudulent orders or payment disputes.\n• You abuse, harass, or threaten our delivery partners or support staff.\n• You violate these Terms in any material way.\n\nPending wallet balances will be refunded to your original payment method upon account closure.' },
    { id: 'sec7', icon: 'Lock', title: '7. Liability Limitations', content: '• We are not liable for indirect or consequential damages arising from the use of our services.\n• Our total liability for any claim is limited to the amount you paid for the specific order giving rise to the claim.\n• We are not liable for delays or failures caused by events beyond our reasonable control (natural disasters, government action, network outages).' },
    { id: 'sec8', icon: 'FileText', title: '8. Changes to These Terms', content: 'We may update these Terms & Conditions periodically. Continued use of the app after changes are published constitutes acceptance of the updated terms. Material changes will be highlighted with a notification in the app.' },
  ],
  contact: {
    heading: 'Questions About These Terms?',
    text: 'If you have any questions or need clarification, our support team is here to help.',
    email: 'support@example.com',
    btn_text: 'Contact Support',
  },
}

// ─────────────────────────────────────────────────────────────────────
const LayoutBuilder = () => {
  const [layouts, setLayouts] = useState([])
  const [activeLayoutId, setActiveLayoutId] = useState(null)
  const [components, setComponents] = useState([])
  const [versionName, setVersionName] = useState('')
  const [layoutId, setLayoutId] = useState(null) // when editing existing row
  const [isDraft, setIsDraft] = useState(false)

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)

  const [modal, setModal] = useState({ open: false, index: null, component: null })
  const [uploadingImage, setUploadingImage] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [showConfirmPublish, setShowConfirmPublish] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  // ★ Mobile theme config (separate from web theme_config)
  const [themeConfig, setThemeConfig] = useState({
    primary_color: '#2563EB',
    accent_color: '#9333EA',
    logo_url: '',
    brand_name: '',
    font_family: 'Inter',
  })
  const [uploadingThemeLogo, setUploadingThemeLogo] = useState(false)

  // ★ NEW: App legal documents — customer app privacy + terms only.
  // Rider app legal docs stay hardcoded in the rider Flutter app (not editable here).
  // Stored inside theme_config JSON column on the backend (no migration needed).
  const [legalDocuments, setLegalDocuments] = useState({
    customer_app_privacy: DEFAULT_CUSTOMER_APP_PRIVACY,
    customer_app_terms: DEFAULT_CUSTOMER_APP_TERMS,
  })
  const [activeLegalTab, setActiveLegalTab] = useState('customer_app_privacy')

  // ── Track unsaved changes (no fetch here — avoids infinite loop) ───
  // Mark dirty whenever the user edits anything. We use a ref so the
  // beforeunload handler always sees the latest value without re-registering.
  const hasUnsavedRef = useRef(false)

  useEffect(() => {
    if (loading) return
    hasUnsavedRef.current = true
    setHasUnsavedChanges(true)
  }, [components, versionName, isDraft, themeConfig, legalDocuments])  // ★ added legalDocuments

  // Fetch ONCE on mount.
  useEffect(() => {
    fetchLayouts()
  }, [])

  // Register beforeunload handler ONCE (not on every state change).
  useEffect(() => {
    const handler = (e) => {
      if (hasUnsavedRef.current) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [])

  const flash = (msg, type = 'success') => {
    if (type === 'error') { setError(msg); setSuccess(null) }
    else { setSuccess(msg); setError(null) }
    setTimeout(() => { setSuccess(null); setError(null) }, 4000)
  }

  const fetchLayouts = async () => {
    try {
      setLoading(true)
      const res = await api.get('appsettings/layouts')
      const data = res.data?.data || []
      setLayouts(data)

      const active = data.find(l => l.is_active) || data[0]
      if (active) {
        // Fetch full components for the selected layout
        const full = await api.get(`appsettings/layouts/${active.id}`)
        const layout = full.data?.data
        if (layout) {
          setLayoutId(layout.id)
          setVersionName(layout.version_name)
          setComponents(layout.components || [])
          setIsDraft(layout.is_draft)
          setActiveLayoutId(layout.id)
          // ★ Load theme_config (mobile-specific, separate from web)
          if (layout.theme_config && typeof layout.theme_config === 'object') {
            setThemeConfig({
              primary_color: layout.theme_config.primary_color || '#2563EB',
              accent_color:  layout.theme_config.accent_color  || '#9333EA',
              logo_url:      layout.theme_config.logo_url      || '',
              brand_name:    layout.theme_config.brand_name    || '',
              font_family:   layout.theme_config.font_family   || 'Inter',
            })
            // ★ NEW: Load legal_documents from theme_config (admin-edited JSON blob)
            if (layout.theme_config.legal_documents) {
              setLegalDocuments({
                customer_app_privacy: { ...DEFAULT_CUSTOMER_APP_PRIVACY, ...(layout.theme_config.legal_documents.customer_app_privacy || {}) },
                customer_app_terms:   { ...DEFAULT_CUSTOMER_APP_TERMS,   ...(layout.theme_config.legal_documents.customer_app_terms   || {}) },
              })
            }
          }
        }
      } else {
        setComponents([])
        setVersionName('Version 1.0')
      }
      setHasUnsavedChanges(false)
      hasUnsavedRef.current = false
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to load layouts.')
    } finally {
      setLoading(false)
    }
  }

  // ── Component ops ──────────────────────────────────────────────────
  const openAddModal = () => setModal({ open: true, index: null, component: blankComponent('carousel') })
  const openEditModal = (index, comp) => setModal({ open: true, index, component: JSON.parse(JSON.stringify(comp)) })
  const closeModal = () => setModal({ open: false, index: null, component: null })

  // ★ Upload logo for the mobile theme (separate from carousel image upload).
  const handleThemeLogoUpload = async (file) => {
    if (!file) return
    setUploadingThemeLogo(true)
    setError(null)
    const formData = new FormData()
    formData.append('image', file)
    try {
      const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      const imageUrl = res.data?.data?.url
      if (imageUrl) {
        setThemeConfig(prev => ({ ...prev, logo_url: imageUrl }))
      } else {
        setError('Upload succeeded but no URL returned.')
      }
    } catch (e) {
      setError(e.response?.data?.message || 'Theme logo upload failed.')
    } finally {
      setUploadingThemeLogo(false)
    }
  }

  const handleSaveComponent = () => {
    if (!modal.component) return
    if (!modal.component.id) modal.component.id = uuid()
    const updated = [...components]
    if (modal.index !== null) updated[modal.index] = modal.component
    else updated.push(modal.component)
    setComponents(updated)
    closeModal()
  }

  const moveItem = (index, direction) => {
    const swapIndex = direction === 'up' ? index - 1 : index + 1
    if (swapIndex < 0 || swapIndex >= components.length) return
    const updated = [...components]
    ;[updated[swapIndex], updated[index]] = [updated[index], updated[swapIndex]]
    setComponents(updated)
  }

  const handleDelete = (index) => {
    if (!confirm(`Remove component #${index + 1}?`)) return
    setComponents(components.filter((_, i) => i !== index))
  }

  const handleDuplicate = (index) => {
    const copy = JSON.parse(JSON.stringify(components[index]))
    copy.id = uuid()
    const updated = [...components]
    updated.splice(index + 1, 0, copy)
    setComponents(updated)
  }

  const handleToggleVisible = (index) => {
    const updated = [...components]
    updated[index] = { ...updated[index], visible: !updated[index].visible }
    setComponents(updated)
  }

  // ── Image upload ───────────────────────────────────────────────────
  const handleImageUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    setUploadingImage(true)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await api.post('appsettings/media/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      const imageUrl = res.data?.data?.url
      if (imageUrl && modal.component) {
        const comp = { ...modal.component }
        if (!comp.data) comp.data = {}
        if (!Array.isArray(comp.data.images)) comp.data.images = []
        comp.data.images.push({
          id: uuid(),
          url: imageUrl,
          alt: file.name,
          action: { type: 'none', value: '' }
        })
        setModal({ ...modal, component: comp })
      }
    } catch (e) {
      setError(e.response?.data?.message || 'Image upload failed.')
    } finally {
      setUploadingImage(false)
      e.target.value = ''
    }
  }

  // ── Save / Publish ─────────────────────────────────────────────────
  const handleSave = async (asDraft) => {
    setSaving(true)
    setError(null)
    try {
      const payload = {
        version_name: versionName,
        components,
        theme_config: {
          ...themeConfig,
          legal_documents: legalDocuments,  // ★ NEW: bundled inside theme_config JSON
        },
        is_draft: asDraft,
        id: layoutId,
      }
      const res = await api.post('appsettings/layouts/save', payload)
      flash(asDraft ? 'Draft saved.' : 'Layout published! Apps will update instantly.')
      setHasUnsavedChanges(false)
      hasUnsavedRef.current = false
      await fetchLayouts()
    } catch (e) {
      const errs = e.response?.data?.errors
      if (errs) {
        const first = Object.values(errs)[0]?.[0] || 'Validation failed.'
        setError(first)
      } else {
        setError(e.response?.data?.message || 'Failed to save layout.')
      }
    } finally {
      setSaving(false)
      setShowConfirmPublish(false)
    }
  }

  const handleActivate = async (id) => {
    if (!confirm('Activate this layout? It will become the live home screen for all customers.')) return
    try {
      await api.patch(`appsettings/layouts/${id}/activate`)
      flash('Layout activated.')
      await fetchLayouts()
    } catch (e) {
      setError(e.response?.data?.message || 'Activation failed.')
    }
  }

  const handleDuplicateLayout = async (id) => {
    try {
      await api.post(`appsettings/layouts/${id}/duplicate`)
      flash('Layout duplicated as draft.')
      await fetchLayouts()
    } catch (e) {
      setError(e.response?.data?.message || 'Duplicate failed.')
    }
  }

  const handleDeleteLayout = async (id) => {
    if (!confirm('Delete this layout? This cannot be undone.')) return
    try {
      await api.delete(`appsettings/layouts/${id}`)
      flash('Layout deleted.')
      await fetchLayouts()
    } catch (e) {
      setError(e.response?.data?.message || 'Delete failed.')
    }
  }

  // ───────────────────────────────────────────────────────────────────
  if (loading) {
    return <div className="text-center py-5"><CSpinner color="primary" /></div>
  }

  return (
    <>
      <div className="admin-page-shell__heading mb-4 p-1">
        <div>
          <h4 className="mb-0">Mobile App Layout Builder</h4>
          <small className="admin-page-note">Design the home screen of your customer app. Changes go live instantly via Pusher.</small>
        </div>
        <div className="d-flex gap-2 flex-wrap">
          <CButton color="secondary" size="sm" variant="outline" onClick={() => setShowHistory(true)}>
            <CIcon icon={cilHistory} className="me-2" />Version History
          </CButton>
          <CButton color="info" size="sm" variant="outline" onClick={() => setShowPreview(true)} disabled={components.length === 0}>
            <CIcon icon={cilPhone} className="me-2" />Preview
          </CButton>
          <CButton color="primary" size="sm" onClick={openAddModal}>
            <CIcon icon={cilPlus} className="me-2" />Add Component
          </CButton>
          <CButton color="warning" size="sm" onClick={() => handleSave(true)} disabled={saving || components.length === 0}>
            {saving ? <CSpinner size="sm" className="me-2" /> : null}
            Save Draft
          </CButton>
          <CButton color="success" size="sm" onClick={() => setShowConfirmPublish(true)} disabled={saving || components.length === 0}>
            <CIcon icon={cilCloudUpload} className="me-2" />Publish Live
          </CButton>
        </div>
      </div>

      {error   && <CAlert color="danger"   dismissible onClose={() => setError(null)}   className="mb-4">{error}</CAlert>}
      {success && <CAlert color="success"  dismissible onClose={() => setSuccess(null)} className="mb-4">{success}</CAlert>}
      {hasUnsavedChanges && (
        <CAlert color="warning" className="mb-4 d-flex align-items-center justify-content-between">
          <span>You have unsaved changes.</span>
          <CButton size="sm" color="warning" onClick={() => handleSave(true)}>Save Draft Now</CButton>
        </CAlert>
      )}

      <CRow className="mb-4">
        <CCol md={6}>
          <CCard className="glass-card admin-page-card">
            <CCardHeader className="glass-card__header"><strong>Version Info</strong></CCardHeader>
            <CCardBody>
              <CFormLabel>Version Name</CFormLabel>
              <CFormInput value={versionName} onChange={(e) => setVersionName(e.target.value)} placeholder="e.g. Summer Update 2025" />
              <div className="mt-3 d-flex align-items-center gap-2">
                <CBadge color={isDraft ? 'warning' : 'success'}>
                  {isDraft ? 'DRAFT' : 'LIVE'}
                </CBadge>
                {layoutId && <small className="text-muted">Layout ID: {layoutId}</small>}
              </div>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>

      {/* ═══ 🎨 MOBILE THEME TAB ═══════════════════════════════════════ */}
      <CCard className="glass-card admin-page-card mb-4">
        <CCardHeader className="glass-card__header">
          <strong>🎨 Mobile Theme</strong>
          <small className="text-muted d-block">Colors, logo, and brand name shown across the mobile app. Separate from the web portal theme.</small>
        </CCardHeader>
        <CCardBody>
          <CRow>
            <CCol md={6}>
              <CFormLabel>Primary Color</CFormLabel>
              <div className="d-flex gap-2 align-items-center mb-3">
                <input type="color" value={themeConfig.primary_color} onChange={(e) => setThemeConfig(prev => ({ ...prev, primary_color: e.target.value }))} style={{ width: 44, height: 38, border: "1px solid #ced4da", borderRadius: 6, padding: 0 }} />
                <CFormInput value={themeConfig.primary_color} onChange={(e) => setThemeConfig(prev => ({ ...prev, primary_color: e.target.value }))} placeholder="#2563EB" style={{ maxWidth: 200 }} />
                <div style={{ width: 36, height: 36, borderRadius: 8, background: themeConfig.primary_color, border: "1px solid #e2e8f0" }} />
              </div>
              <CFormLabel>Accent Color</CFormLabel>
              <div className="d-flex gap-2 align-items-center mb-3">
                <input type="color" value={themeConfig.accent_color} onChange={(e) => setThemeConfig(prev => ({ ...prev, accent_color: e.target.value }))} style={{ width: 44, height: 38, border: "1px solid #ced4da", borderRadius: 6, padding: 0 }} />
                <CFormInput value={themeConfig.accent_color} onChange={(e) => setThemeConfig(prev => ({ ...prev, accent_color: e.target.value }))} placeholder="#9333EA" style={{ maxWidth: 200 }} />
                <div style={{ width: 36, height: 36, borderRadius: 8, background: themeConfig.accent_color, border: "1px solid #e2e8f0" }} />
              </div>
              <CFormLabel>Brand Name</CFormLabel>
              <CFormInput value={themeConfig.brand_name} onChange={(e) => setThemeConfig(prev => ({ ...prev, brand_name: e.target.value }))} placeholder="e.g. Shop Hub (leave empty to use flavor default)" className="mb-3" />
              <CFormLabel>Font Family</CFormLabel>
              <CFormSelect value={themeConfig.font_family} onChange={(e) => setThemeConfig(prev => ({ ...prev, font_family: e.target.value }))}>
                <option value="Inter">Inter (default)</option>
                <option value="Roboto">Roboto</option>
                <option value="Poppins">Poppins</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Lato">Lato</option>
                <option value="OpenSans">Open Sans</option>
                <option value="Nunito">Nunito</option>
                <option value="System">System</option>
              </CFormSelect>
            </CCol>
            <CCol md={6}>
              <CFormLabel>Logo</CFormLabel>
              <div className="p-3 border rounded bg-light mb-2">
                <div className="d-flex gap-3 align-items-center">
                  {themeConfig.logo_url ? (
                    <img src={themeConfig.logo_url} alt="Logo preview" style={{ width: 64, height: 64, objectFit: "contain", background: "#fff", borderRadius: 8, border: "1px solid #e2e8f0" }} onError={(e) => { e.target.style.display = "none" }} />
                  ) : (
                    <div style={{ width: 64, height: 64, background: "#fff", borderRadius: 8, border: "1px dashed #cbd5e1", display: "flex", alignItems: "center", justifyContent: "center", color: "#94a3b8", fontSize: 11 }}>No logo</div>
                  )}
                  <div className="flex-grow-1">
                    <input type="file" accept="image/*" id="theme-logo-upload" style={{ display: "none" }} onChange={(e) => { const f = e.target.files?.[0]; if (f) handleThemeLogoUpload(f); e.target.value = "" }} />
                    <CButton color="primary" size="sm" variant="outline" onClick={() => document.getElementById("theme-logo-upload").click()} disabled={uploadingThemeLogo}>
                      {uploadingThemeLogo ? <CSpinner size="sm" /> : <CIcon icon={cilCloudUpload} className="me-1" />}
                      Upload Logo
                    </CButton>
                    {themeConfig.logo_url && (
                      <CButton color="danger" size="sm" variant="ghost" className="ms-2" onClick={() => setThemeConfig(prev => ({ ...prev, logo_url: "" }))}>Clear</CButton>
                    )}
                    <small className="text-muted d-block mt-1">Or paste a URL below.</small>
                  </div>
                </div>
                <CFormInput value={themeConfig.logo_url} onChange={(e) => setThemeConfig(prev => ({ ...prev, logo_url: e.target.value }))} placeholder="https://..." className="mt-2" size="sm" />
              </div>
              {/* Live preview */}
              <CFormLabel>Live Preview</CFormLabel>
              <div style={{ border: "1px solid #e2e8f0", borderRadius: 12, overflow: "hidden", maxWidth: 280 }}>
                <div style={{ background: `linear-gradient(135deg, ${themeConfig.primary_color}, ${themeConfig.accent_color})`, padding: 16, color: "#fff" }}>
                  <div className="d-flex align-items-center gap-2">
                    {themeConfig.logo_url ? (
                      <img src={themeConfig.logo_url} alt="" style={{ width: 28, height: 28, objectFit: "contain", background: "rgba(255,255,255,0.2)", borderRadius: 6 }} onError={(e) => { e.target.style.display = "none" }} />
                    ) : (
                      <div style={{ width: 28, height: 28, background: "rgba(255,255,255,0.25)", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>{(themeConfig.brand_name || "A")[0]}</div>
                    )}
                    <strong style={{ fontSize: 14 }}>{themeConfig.brand_name || "Your Brand"}</strong>
                  </div>
                </div>
                <div style={{ background: "#fff", padding: 12 }}>
                  <div style={{ background: themeConfig.primary_color, color: "#fff", borderRadius: 8, padding: "8px 14px", fontSize: 12, fontWeight: 700, textAlign: "center", marginBottom: 8 }}>Primary Button</div>
                  <div style={{ background: themeConfig.accent_color, color: "#fff", borderRadius: 8, padding: "8px 14px", fontSize: 12, fontWeight: 700, textAlign: "center" }}>Accent Button</div>
                </div>
              </div>
            </CCol>
          </CRow>
        </CCardBody>
      </CCard>

      {/* ═══ 📜 APP LEGAL DOCUMENTS ═══════════════════════════════════════════════ */}
      <CCard className="glass-card admin-page-card mb-4">
        <CCardHeader className="glass-card__header">
          <strong>📜 App Legal Documents</strong>
          <small className="text-muted d-block">
            Privacy &amp; Terms shown inside the customer white-label app. Independent of the website. Required for app store submission.
            <span className="text-warning d-block mt-1">Rider app legal docs stay hardcoded in the rider Flutter app — not editable here.</span>
          </small>
        </CCardHeader>
        <CCardBody>
          {/* Sub-tab switcher */}
          <div className="d-flex gap-2 mb-3 border-bottom pb-3">
            <CButton
              size="sm"
              color={activeLegalTab === 'customer_app_privacy' ? 'primary' : 'outline-secondary'}
              onClick={() => setActiveLegalTab('customer_app_privacy')}
            >
              🔒 Customer App Privacy
            </CButton>
            <CButton
              size="sm"
              color={activeLegalTab === 'customer_app_terms' ? 'primary' : 'outline-secondary'}
              onClick={() => setActiveLegalTab('customer_app_terms')}
            >
              📋 Customer App Terms
            </CButton>
          </div>

          <LegalDocumentEditor
            doc={legalDocuments[activeLegalTab]}
            onChange={(updated) => setLegalDocuments(prev => ({ ...prev, [activeLegalTab]: updated }))}
          />

          <small className="text-muted d-block mt-3">
            Changes save with the rest of the layout when you click "Save Draft" or "Publish Live" above. Stored inside <code>theme_config.legal_documents</code> in the same row — no separate database table.
          </small>
        </CCardBody>
      </CCard>

      <CCard className="glass-card admin-page-card">
        <CCardHeader className="glass-card__header d-flex justify-content-between align-items-center">
          <div>
            <strong>Active Components ({components.length})</strong>
            <small className="text-muted d-block">Top-to-bottom order is exactly how they appear on the mobile app.</small>
          </div>
        </CCardHeader>
        <CCardBody className="p-0">
          {components.length === 0 ? (
            <div className="text-center text-muted py-5">
              No components added yet. Click "Add Component" to start building.
            </div>
          ) : (
            <div className="p-3 d-flex flex-column gap-3">
              {components.map((comp, index) => (
                <div key={comp.id || index} className={`border rounded p-3 d-flex align-items-center justify-content-between bg-white ${comp.visible === false ? 'opacity-50' : ''}`}>
                  <div>
                    <CBadge color="info" className="me-2">{index + 1}</CBadge>
                    <strong className="text-uppercase">{comp.type.replace('_', ' ')}</strong>
                    {comp.title && <span className="text-muted ms-3">"{comp.title}"</span>}
                    {comp.data?.images?.length > 0 && <span className="text-muted ms-3">🖼 {comp.data.images.length}</span>}
                    {comp.data?.items?.length > 0 && <span className="text-muted ms-3">📋 {comp.data.items.length}</span>}
                    {comp.data?.limit && <span className="text-muted ms-3">limit: {comp.data.limit}</span>}
                    {comp.visible === false && <CBadge color="secondary" className="ms-2">hidden</CBadge>}
                  </div>
                  <div className="d-flex gap-1">
                    <CButton size="sm" color="light" variant="outline" title="Move up" onClick={() => moveItem(index, 'up')} disabled={index === 0}>
                      <CIcon icon={cilArrowTop} />
                    </CButton>
                    <CButton size="sm" color="light" variant="outline" title="Move down" onClick={() => moveItem(index, 'down')} disabled={index === components.length - 1}>
                      <CIcon icon={cilArrowBottom} />
                    </CButton>
                    <CButton size="sm" color="info" variant="outline" title={comp.visible === false ? 'Show' : 'Hide'} onClick={() => handleToggleVisible(index)}>
                      <CIcon icon={comp.visible === false ? cilXCircle : cilCheckCircle} />
                    </CButton>
                    <CButton size="sm" color="light" variant="outline" title="Duplicate" onClick={() => handleDuplicate(index)}>
                      <CIcon icon={cilCopy} />
                    </CButton>
                    <CButton size="sm" color="warning" variant="outline" title="Edit" onClick={() => openEditModal(index, comp)}>
                      <CIcon icon={cilPencil} />
                    </CButton>
                    <CButton size="sm" color="danger" variant="outline" title="Remove" onClick={() => handleDelete(index)}>
                      <CIcon icon={cilTrash} />
                    </CButton>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CCardBody>
      </CCard>

      {/* ── Component Editor Modal ─────────────────────────────────── */}
      <CModal size="lg" visible={modal.open} onClose={closeModal} backdrop="static">
        <CModalHeader className="glass-card__header">
          <CModalTitle>{modal.index !== null ? 'Edit Component' : 'Add Component'}</CModalTitle>
        </CModalHeader>
        <CModalBody>
          {modal.component && <ComponentEditor
            component={modal.component}
            onChange={(c) => setModal({ ...modal, component: c })}
            onUploadImage={handleImageUpload}
            uploadingImage={uploadingImage}
          />}
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={closeModal}>Cancel</CButton>
          <CButton color="primary" onClick={handleSaveComponent}>Save Component</CButton>
        </CModalFooter>
      </CModal>

      {/* ── Publish Confirmation ────────────────────────────────────── */}
      <CModal visible={showConfirmPublish} onClose={() => setShowConfirmPublish(false)}>
        <CModalHeader><CModalTitle>Publish to all apps?</CModalTitle></CModalHeader>
        <CModalBody>
          This will immediately replace the live home screen for <strong>all your customers</strong>.
          They will see the new layout within a few seconds via Pusher.
          <br/><br/>
          <strong>Version:</strong> {versionName}<br/>
          <strong>Components:</strong> {components.length}
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setShowConfirmPublish(false)}>Cancel</CButton>
          <CButton color="success" onClick={() => handleSave(false)} disabled={saving}>
            {saving ? <CSpinner size="sm" className="me-2" /> : null}
            Yes, Publish Now
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ── Version History ────────────────────────────────────────── */}
      <CModal size="lg" visible={showHistory} onClose={() => setShowHistory(false)}>
        <CModalHeader><CModalTitle>Version History</CModalTitle></CModalHeader>
        <CModalBody>
          {layouts.length === 0 ? <p className="text-muted">No saved layouts yet.</p> : (
            <div className="d-flex flex-column gap-2">
              {layouts.map(l => (
                <div key={l.id} className={`border rounded p-3 d-flex justify-content-between align-items-center ${l.is_active ? 'border-success' : ''}`}>
                  <div>
                    <strong>{l.version_name}</strong>
                    {l.is_active && <CBadge color="success" className="ms-2">LIVE</CBadge>}
                    {l.is_draft  && <CBadge color="warning" className="ms-2">DRAFT</CBadge>}
                    <div className="text-muted small">
                      {new Date(l.created_at).toLocaleString()} · ID #{l.id}
                    </div>
                  </div>
                  <div className="d-flex gap-1">
                    <CButton size="sm" color="success"  variant="outline" disabled={l.is_active} onClick={() => handleActivate(l.id)}>Activate</CButton>
                    <CButton size="sm" color="info"     variant="outline" onClick={() => handleDuplicateLayout(l.id)}><CIcon icon={cilCopy} /></CButton>
                    <CButton size="sm" color="danger"   variant="outline" disabled={l.is_active} onClick={() => handleDeleteLayout(l.id)}><CIcon icon={cilTrash} /></CButton>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CModalBody>
        <CModalFooter><CButton color="secondary" onClick={() => setShowHistory(false)}>Close</CButton></CModalFooter>
      </CModal>

      {/* ── Phone Preview ──────────────────────────────────────────── */}
      <CModal size="lg" visible={showPreview} onClose={() => setShowPreview(false)}>
        <CModalHeader><CModalTitle>Mobile Preview</CModalTitle></CModalHeader>
        <CModalBody className="bg-light d-flex justify-content-center">
          <div style={{ width: 320, height: 600, border: '8px solid #222', borderRadius: 32, overflow: 'hidden', background: '#F1F5F9' }}>
            <div className="bg-primary text-white text-center py-2 small">Live Preview</div>
            <div style={{ overflowY: 'auto', height: 'calc(100% - 32px)' }}>
              {components.filter(c => c.visible !== false).map((c, i) => (
                <PreviewBlock key={c.id || i} component={c} />
              ))}
            </div>
          </div>
        </CModalBody>
        <CModalFooter><CButton color="secondary" onClick={() => setShowPreview(false)}>Close</CButton></CModalFooter>
      </CModal>
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Component Editor — renders different forms per type
// ─────────────────────────────────────────────────────────────────────
const ComponentEditor = ({ component, onChange, onUploadImage, uploadingImage }) => {
  const set = (path, value) => {
    const next = JSON.parse(JSON.stringify(component))
    const keys = path.split('.')
    let obj = next
    for (let i = 0; i < keys.length - 1; i++) {
      const k = isNaN(keys[i]) ? keys[i] : parseInt(keys[i])
      obj[k] = obj[k] ?? {}
      obj = obj[k]
    }
    const last = isNaN(keys[keys.length - 1]) ? keys[keys.length - 1] : parseInt(keys[keys.length - 1])
    obj[last] = value
    onChange(next)
  }

  const setData = (key, value) => set(`data.${key}`, value)

  return (
    <div>
      <div className="mb-3">
        <CFormLabel>Section Title (optional)</CFormLabel>
        <CFormInput value={component.title || ''} onChange={(e) => onChange({ ...component, title: e.target.value })} placeholder="Heading shown above the component" />
      </div>

      <div className="mb-3">
        <CFormLabel>Component Type</CFormLabel>
        <CFormSelect value={component.type} onChange={(e) => {
          if (confirm('Changing type will reset this component. Continue?')) {
            onChange(blankComponent(e.target.value))
          }
        }} disabled={false}>
          {COMPONENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
        </CFormSelect>
      </div>

      <CFormSwitch label="Visible" checked={component.visible !== false} onChange={(e) => onChange({ ...component, visible: e.target.checked })} />
      {component.type === 'app_settings' && <AppSettingsEditor component={component} setData={setData} onUploadImage={onUploadImage} uploadingImage={uploadingImage} />}
      {component.type === 'carousel' && <CarouselEditor component={component} setData={setData} onUploadImage={onUploadImage} uploadingImage={uploadingImage} />}
      {component.type === 'dashboard_menu' && <DashboardMenuEditor component={component} setData={setData} />}
      {component.type === 'quick_calendar' && <QuickCalendarEditor component={component} setData={setData} />}
      {component.type === 'popular_products' && <PopularProductsEditor component={component} setData={setData} />}
      {component.type === 'categories_grid' && <CategoriesGridEditor component={component} setData={setData} />}
      {component.type === 'all_products' && <AllProductsEditor component={component} setData={setData} />}
      {component.type === 'subscription_plans' && <SubscriptionPlansEditor component={component} setData={setData} />}
    </div>
  )
}

// ─── Carousel ────────────────────────────────────────────────────────
const CarouselEditor = ({ component, setData, onUploadImage, uploadingImage }) => {
  const d = component.data || {}
  return (
    <div>
      <h6>Banner Images</h6>
      <div className="d-flex flex-wrap gap-2 mb-3">
        {(d.images || []).map((img, i) => (
          <div key={img.id || i} style={{ position: 'relative', width: 140, height: 80 }}>
            <img src={img.url} alt={img.alt} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 6 }} />
            <CButton size="sm" color="danger" style={{ position: 'absolute', top: 2, right: 2, padding: '0 6px' }}
              onClick={() => {
                const imgs = d.images.filter((_, j) => j !== i)
                setData('images', imgs)
              }}>
              <CIcon icon={cilTrash} size="sm" />
            </CButton>
          </div>
        ))}
      </div>
      <CButton color="secondary" variant="outline" size="sm" disabled={uploadingImage} className="position-relative">
        {uploadingImage ? <CSpinner size="sm" /> : <><CIcon icon={cilCloudUpload} className="me-2" />Upload Image</>}
        <input type="file" accept="image/*" style={{ position: 'absolute', opacity: 0, left: 0, top: 0, width: '100%', height: '100%', cursor: 'pointer' }} onChange={onUploadImage} disabled={uploadingImage} />
      </CButton>

      {(d.images || []).length > 0 && (
        <div className="mt-4">
          <strong className="small">Per-slide settings (text overlay & click action):</strong>
          {d.images.map((img, i) => (
            <div key={img.id || i} className="border rounded p-3 my-3">
              <div className="d-flex gap-2 align-items-center mb-3">
                <img src={img.url} style={{ width: 50, height: 30, objectFit: 'cover', borderRadius: 4 }} />
                <strong className="small text-muted">Slide {i + 1}</strong>
              </div>

              <CFormLabel className="small">Overlay Title (optional)</CFormLabel>
              <CFormInput
                placeholder="e.g. 50% OFF Today Only"
                value={img.title || ''}
                onChange={(e) => {
                  const imgs = [...d.images]
                  imgs[i] = { ...img, title: e.target.value }
                  setData('images', imgs)
                }}
                className="mb-2"
              />

              <CFormLabel className="small">Overlay Subtitle (optional)</CFormLabel>
              <CFormInput
                placeholder="e.g. On all fresh dairy products"
                value={img.subtitle || ''}
                onChange={(e) => {
                  const imgs = [...d.images]
                  imgs[i] = { ...img, subtitle: e.target.value }
                  setData('images', imgs)
                }}
                className="mb-3"
              />

              <CFormLabel className="small">Click Action</CFormLabel>
              <div className="d-flex gap-2 align-items-center">
                <CFormSelect style={{ maxWidth: 180 }} value={img.action?.type || 'none'}
                  onChange={(e) => {
                    const imgs = [...d.images]
                    imgs[i] = { ...img, action: { ...img.action, type: e.target.value } }
                    setData('images', imgs)
                  }}>
                  {ACTION_TYPES.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
                </CFormSelect>
                {img.action?.type && img.action.type !== 'none' && (
                  <CFormInput style={{ maxWidth: 200 }} placeholder="ID / URL" value={img.action?.value || ''}
                    onChange={(e) => {
                      const imgs = [...d.images]
                      imgs[i] = { ...img, action: { ...img.action, value: e.target.value } }
                      setData('images', imgs)
                    }} />
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-3 row">
        <div className="col-6">
          <CFormLabel className="small">Autoplay</CFormLabel>
          <CFormSwitch checked={d.autoplay !== false} onChange={(e) => setData('autoplay', e.target.checked)} />
        </div>
        <div className="col-6">
          <CFormLabel className="small">Interval (sec)</CFormLabel>
          <CFormInput type="number" min="1" max="60" value={d.interval_seconds ?? 4} onChange={(e) => setData('interval_seconds', Math.max(1, Math.min(60, parseInt(e.target.value) || 4)))} />
        </div>
      </div>
    </div>
  )
}

// ─── Dashboard Menu ──────────────────────────────────────────────────
const DashboardMenuEditor = ({ component, setData }) => {
  const d = component.data || {}
  const items = d.items || []
  const updateItem = (i, key, value) => {
    const next = [...items]
    next[i] = { ...next[i], [key]: value }
    setData('items', next)
  }
  const addItem = () => setData('items', [...items, { id: uuid(), label: 'New Item', icon: 'person', color: '#2563EB', route: 'profile' }])
  const removeItem = (i) => setData('items', items.filter((_, j) => j !== i))

  return (
    <div>
      <CFormLabel>Section Title</CFormLabel>
      <CFormInput value={d.title || ''} onChange={(e) => setData('title', e.target.value)} />
      <CFormLabel className="mt-3">Columns</CFormLabel>
      <CFormSelect value={d.columns ?? 1} onChange={(e) => setData('columns', parseInt(e.target.value))}>
        {[1,2,3,4].map(n => <option key={n} value={n}>{n}</option>)}
      </CFormSelect>
      <div className="mt-3">
        <div className="d-flex justify-content-between"><strong>Items</strong><CButton size="sm" color="primary" onClick={addItem}><CIcon icon={cilPlus} className="me-1"/>Add</CButton></div>
        {items.map((it, i) => (
          <div key={it.id || i} className="border rounded p-2 my-2 d-flex gap-2 align-items-center flex-wrap">
            <CFormInput placeholder="Label" value={it.label} onChange={(e) => updateItem(i, 'label', e.target.value)} style={{ maxWidth: 140 }} />
            <CFormSelect value={it.route} onChange={(e) => updateItem(i, 'route', e.target.value)} style={{ maxWidth: 160 }}>
              {DASHBOARD_ROUTES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </CFormSelect>
            <CFormSelect value={it.icon} onChange={(e) => updateItem(i, 'icon', e.target.value)} style={{ maxWidth: 140 }}>
              {DASHBOARD_ICONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
            </CFormSelect>
            <CFormInput type="color" value={it.color || '#2563EB'} onChange={(e) => updateItem(i, 'color', e.target.value)} style={{ width: 50, height: 38 }} title="Tile color" />
            <CButton size="sm" color="danger" variant="outline" onClick={() => removeItem(i)}><CIcon icon={cilTrash} /></CButton>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Quick Calendar ──────────────────────────────────────────────────
const QuickCalendarEditor = ({ component, setData }) => {
  const d = component.data || {}
  return (
    <div>
      <CFormLabel>Days to show (1–14)</CFormLabel>
      <CFormInput type="number" min="1" max="14" value={d.days_to_show ?? 7} onChange={(e) => setData('days_to_show', Math.max(1, Math.min(14, parseInt(e.target.value) || 7)))} />
      <CFormLabel className="mt-3">Empty State Text</CFormLabel>
      <CFormInput value={d.empty_state_text || ''} onChange={(e) => setData('empty_state_text', e.target.value)} />
      <CFormSwitch className="mt-2" label="Show only delivery days" checked={d.show_only_delivery_days !== false} onChange={(e) => setData('show_only_delivery_days', e.target.checked)} />
      <small className="text-muted d-block mt-2">Subscription plan ID is optional. Leave empty to show all upcoming deliveries.</small>
    </div>
  )
}

// ─── Popular Products ────────────────────────────────────────────────
const PopularProductsEditor = ({ component, setData }) => {
  const d = component.data || {}
  return (
    <div>
      <CFormLabel>Source</CFormLabel>
      <CFormSelect value={d.source || 'recent'} onChange={(e) => setData('source', e.target.value)}>
        <option value="recent">Recently added</option>
        <option value="top_rated">Top rated</option>
        <option value="discounted">Discounted</option>
        <option value="manual">Manual selection (enter IDs)</option>
      </CFormSelect>
      <CFormLabel className="mt-3">Limit (1–50)</CFormLabel>
      <CFormInput type="number" min="1" max="50" value={d.limit ?? 8} onChange={(e) => setData('limit', Math.max(1, Math.min(50, parseInt(e.target.value) || 8)))} />
      {d.source === 'manual' && (
        <>
          <CFormLabel className="mt-3">Product IDs (comma-separated)</CFormLabel>
          <CFormInput value={(d.product_ids || []).join(',')} onChange={(e) => setData('product_ids', e.target.value.split(',').map(s => s.trim()).filter(Boolean).map(Number))} placeholder="12, 45, 78" />
        </>
      )}
      <small className="text-muted d-block mt-2">If manual source and a product is missing, the fallback strategy kicks in.</small>
    </div>
  )
}

// ─── Categories Grid ─────────────────────────────────────────────────
const CategoriesGridEditor = ({ component, setData }) => {
  const d = component.data || {}
  return (
    <div>
      <CFormLabel>Layout</CFormLabel>
      <CFormSelect value={d.layout || 'circle'} onChange={(e) => setData('layout', e.target.value)}>
        <option value="circle">Circular Avatars (Horizontal Scroll)</option>
        <option value="chips">Horizontal Chips</option>
        <option value="grid_2col">2-column Grid</option>
        <option value="grid_3col">3-column Grid</option>
      </CFormSelect>
      <CFormLabel className="mt-3">Limit (1–50)</CFormLabel>
      <CFormInput type="number" min="1" max="50" value={d.limit ?? 10} onChange={(e) => setData('limit', Math.max(1, Math.min(50, parseInt(e.target.value) || 10)))} />
      <CFormSwitch className="mt-2" label="Show all categories (ignores limit)" checked={d.show_all !== false} onChange={(e) => setData('show_all', e.target.checked)} />
      <CFormLabel className="mt-3">Category IDs (comma-separated, optional)</CFormLabel>
      <CFormInput value={(d.category_ids || []).join(',')} onChange={(e) => setData('category_ids', e.target.value.split(',').map(s => s.trim()).filter(Boolean).map(Number))} placeholder="1, 2, 5" />
    </div>
  )
}

// ─── App Settings ────────────────────────────────────────────────────
const AppSettingsEditor = ({ component, setData, onUploadImage, uploadingImage }) => {
  const d = component.data || {}
  return (
    <div>
      <h6>Login Screen Background Image</h6>
      <small className="text-muted d-block mb-2">Upload an image to be used as the full-screen background on the login screen. Recommended resolution: 1080x1920.</small>

      {d.login_bg_image && (
        <div className="mb-3 position-relative" style={{ width: 150, height: 250 }}>
          <img src={d.login_bg_image} alt="Login BG" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 8 }} />
          <CButton size="sm" color="danger" style={{ position: 'absolute', top: 4, right: 4 }} onClick={() => setData('login_bg_image', '')}>
            <CIcon icon={cilTrash} size="sm" />
          </CButton>
        </div>
      )}

      <CButton color="secondary" variant="outline" size="sm" disabled={uploadingImage} className="position-relative">
        {uploadingImage ? <CSpinner size="sm" /> : <><CIcon icon={cilCloudUpload} className="me-2" />Upload Background</>}
        <input type="file" accept="image/*" style={{ position: 'absolute', opacity: 0, left: 0, top: 0, width: '100%', height: '100%', cursor: 'pointer' }}
          onChange={async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append('image', file);
            try {
              const res = await api.post('appsettings/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
              const imageUrl = res.data?.data?.url;
              if (imageUrl) setData('login_bg_image', imageUrl);
            } catch (err) { alert('Upload failed'); }
          }} disabled={uploadingImage} />
      </CButton>
    </div>
  )
}

// ─── All Products ────────────────────────────────────────────────────
const AllProductsEditor = ({ component, setData }) => {
  const d = component.data || {}
  return (
    <div>
      <CFormLabel>Sort by</CFormLabel>
      <CFormSelect value={d.sort_by || 'name_asc'} onChange={(e) => setData('sort_by', e.target.value)}>
        <option value="name_asc">Name (A→Z)</option>
        <option value="name_desc">Name (Z→A)</option>
        <option value="price_asc">Price (low→high)</option>
        <option value="price_desc">Price (high→low)</option>
        <option value="newest">Newest first</option>
      </CFormSelect>
      <div className="row mt-3">
        <div className="col-6">
          <CFormLabel>Columns</CFormLabel>
          <CFormSelect value={d.columns ?? 2} onChange={(e) => setData('columns', parseInt(e.target.value))}>
            {[2,3,4].map(n => <option key={n} value={n}>{n}</option>)}
          </CFormSelect>
        </div>
        <div className="col-6">
          <CFormLabel>Page size</CFormLabel>
          <CFormInput type="number" min="4" max="100" value={d.page_size ?? 20} onChange={(e) => setData('page_size', Math.max(4, Math.min(100, parseInt(e.target.value) || 20)))} />
        </div>
      </div>
      <CFormLabel className="mt-3">Category ID filter (optional)</CFormLabel>
      <CFormInput type="number" value={d.category_id || ''} onChange={(e) => setData('category_id', e.target.value ? parseInt(e.target.value) : null)} placeholder="All categories" />
    </div>
  )
}

// ─── Subscription Plans ──────────────────────────────────────────────
const SubscriptionPlansEditor = ({ component, setData }) => {
  const d = component.data || {}
  return (
    <div>
      <CFormSwitch label="Show all plans" checked={d.show_all !== false} onChange={(e) => setData('show_all', e.target.checked)} />
      <CFormLabel className="mt-3">Limit (1–50)</CFormLabel>
      <CFormInput type="number" min="1" max="50" value={d.limit ?? 6} onChange={(e) => setData('limit', Math.max(1, Math.min(50, parseInt(e.target.value) || 6)))} />
      <CFormLabel className="mt-3">Plan IDs (comma-separated, optional)</CFormLabel>
      <CFormInput value={(d.plan_ids || []).join(',')} onChange={(e) => setData('plan_ids', e.target.value.split(',').map(s => s.trim()).filter(Boolean).map(Number))} placeholder="1, 2, 3" />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════
// ★ NEW: LegalDocumentEditor — used for both customer_app_privacy and
// customer_app_terms. Reuses the same intro + sections + contact pattern
// as the existing WebBuilder privacy editor.
// ═══════════════════════════════════════════════════════════════════
const LegalDocumentEditor = ({ doc, onChange }) => {
  if (!doc) return null
  const hero = doc.hero || {}
  const intro = doc.intro || {}
  const sections = doc.sections || []
  const contact = doc.contact || {}

  const setHero = (k, v) => onChange({ ...doc, hero: { ...hero, [k]: v } })
  const setIntro = (k, v) => onChange({ ...doc, intro: { ...intro, [k]: v } })
  const setContact = (k, v) => onChange({ ...doc, contact: { ...contact, [k]: v } })

  const addSection = () => {
    const next = [...sections, { id: 'sec-' + Date.now(), icon: 'FileText', title: 'New Section', content: 'Enter content here...' }]
    onChange({ ...doc, sections: next })
  }
  const updateSection = (i, k, v) => {
    const next = [...sections]; next[i] = { ...next[i], [k]: v }
    onChange({ ...doc, sections: next })
  }
  const deleteSection = (i) => {
    if (!confirm('Delete this section?')) return
    onChange({ ...doc, sections: sections.filter((_, idx) => idx !== i) })
  }
  const moveSection = (i, dir) => {
    const next = [...sections]
    const j = i + dir
    if (j < 0 || j >= next.length) return
    ;[next[i], next[j]] = [next[j], next[i]]
    onChange({ ...doc, sections: next })
  }

  return (
    <div>
      {/* Hero */}
      <div className="p-3 mb-3 border rounded bg-light">
        <h6 className="text-uppercase text-muted mb-2">Header (shown at top of the screen)</h6>
        <CRow className="mb-2">
          <CCol xs={6}>
            <CFormLabel className="small mb-0">Badge Text</CFormLabel>
            <CFormInput value={hero.badge || ''} onChange={(e) => setHero('badge', e.target.value)} placeholder="e.g. Privacy Policy" size="sm" />
          </CCol>
          <CCol xs={6}>
            <CFormLabel className="small mb-0">Last Updated Date</CFormLabel>
            <CFormInput value={hero.last_updated || ''} onChange={(e) => setHero('last_updated', e.target.value)} placeholder="e.g. August 26, 2026" size="sm" />
          </CCol>
        </CRow>
        <CFormLabel className="small mb-1 mt-2">Title</CFormLabel>
        <CFormInput value={hero.title || ''} onChange={(e) => setHero('title', e.target.value)} placeholder="How We Protect Your Data" size="sm" className="mb-2" />
        <CFormLabel className="small mb-1">Subtitle</CFormLabel>
        <CFormTextarea value={hero.subtitle || ''} onChange={(e) => setHero('subtitle', e.target.value)} rows={2} size="sm" />
      </div>

      {/* Intro */}
      <div className="p-3 mb-3 border rounded bg-light">
        <h6 className="text-uppercase text-muted mb-2">Intro Section</h6>
        <CFormLabel className="small mb-0">Intro Title</CFormLabel>
        <CFormInput value={intro.title || ''} onChange={(e) => setIntro('title', e.target.value)} size="sm" className="mb-2" />
        <CFormLabel className="small mb-0">Intro Content</CFormLabel>
        <CFormTextarea value={intro.content || ''} onChange={(e) => setIntro('content', e.target.value)} rows={3} size="sm" />
      </div>

      {/* Sections */}
      <div className="p-3 mb-3 border rounded bg-light">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="text-uppercase text-muted mb-0">Policy Sections ({sections.length})</h6>
          <CButton color="success" size="sm" onClick={addSection}>
            <CIcon icon={cilPlus} className="me-1" /> Add Section
          </CButton>
        </div>
        <small className="text-muted d-block mb-2">Each section shows in the app as a card. Use \n for line breaks and • for bullets.</small>
        {sections.map((sec, i) => (
          <div key={sec.id || i} className="p-3 mb-3 border rounded bg-white">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="badge bg-secondary">Section {i + 1}</span>
              <div className="d-flex gap-1">
                <CButton size="sm" color="light" disabled={i === 0} onClick={() => moveSection(i, -1)}><CIcon icon={cilArrowTop} size={12} /></CButton>
                <CButton size="sm" color="light" disabled={i === sections.length - 1} onClick={() => moveSection(i, 1)}><CIcon icon={cilArrowBottom} size={12} /></CButton>
                <CButton size="sm" color="danger" variant="ghost" onClick={() => deleteSection(i)}><CIcon icon={cilTrash} size={12} /></CButton>
              </div>
            </div>
            <CRow className="mb-2">
              <CCol xs={4}>
                <CFormLabel className="small mb-0">Icon</CFormLabel>
                <CFormSelect size="sm" value={sec.icon || 'FileText'} onChange={(e) => updateSection(i, 'icon', e.target.value)}>
                  <option value="Database">Database</option>
                  <option value="Eye">Eye</option>
                  <option value="CreditCard">Credit Card</option>
                  <option value="ShieldCheck">Shield Check</option>
                  <option value="UserCog">User Cog</option>
                  <option value="AlertCircle">Alert Circle</option>
                  <option value="Lock">Lock</option>
                  <option value="FileText">File Text</option>
                  <option value="Users">Users</option>
                  <option value="Bell">Bell</option>
                  <option value="MapPin">Map Pin</option>
                  <option value="Mail">Mail</option>
                  <option value="Phone">Phone</option>
                  <option value="Shield">Shield</option>
                  <option value="Gift">Gift</option>
                </CFormSelect>
              </CCol>
              <CCol xs={8}>
                <CFormLabel className="small mb-0">Section Title</CFormLabel>
                <CFormInput size="sm" value={sec.title || ''} onChange={(e) => updateSection(i, 'title', e.target.value)} />
              </CCol>
            </CRow>
            <CFormLabel className="small mb-0 mt-2">Content</CFormLabel>
            <CFormTextarea rows={5} value={sec.content || ''} onChange={(e) => updateSection(i, 'content', e.target.value)} style={{ fontFamily: 'monospace', fontSize: '0.85rem' }} />
          </div>
        ))}
        {sections.length === 0 && <div className="text-center text-muted py-3"><small>No sections yet. Click "Add Section" to start.</small></div>}
      </div>

      {/* Contact */}
      <div className="p-3 border rounded bg-light">
        <h6 className="text-uppercase text-muted mb-2">Contact Prompt (shown at bottom of the screen)</h6>
        <CFormLabel className="small mb-0">Heading</CFormLabel>
        <CFormInput value={contact.heading || ''} onChange={(e) => setContact('heading', e.target.value)} size="sm" className="mb-2" />
        <CFormLabel className="small mb-0">Text</CFormLabel>
        <CFormTextarea value={contact.text || ''} onChange={(e) => setContact('text', e.target.value)} rows={2} size="sm" className="mb-2" />
        <CRow>
          <CCol xs={6}>
            <CFormLabel className="small mb-0">Email Address</CFormLabel>
            <CFormInput value={contact.email || ''} onChange={(e) => setContact('email', e.target.value)} size="sm" />
          </CCol>
          <CCol xs={6}>
            <CFormLabel className="small mb-0">Button Text</CFormLabel>
            <CFormInput value={contact.btn_text || ''} onChange={(e) => setContact('btn_text', e.target.value)} size="sm" />
          </CCol>
        </CRow>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Preview Block — tiny visual representation per type
// ─────────────────────────────────────────────────────────────────────
const PreviewBlock = ({ component }) => {
  const { type, title, data = {} } = component
  const block = (children, bg = '#fff') => (
    <div style={{ margin: '8px 12px', padding: 12, background: bg, borderRadius: 8 }}>{children}</div>
  )

  if (type === 'carousel') {
    if (!data.images?.length) return block(<div style={{ height: 60, background: 'linear-gradient(135deg,#9333EA,#2563EB)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 11 }}>Banner</div>)
    return block(<img src={data.images[0].url} style={{ width: '100%', height: 80, objectFit: 'cover', borderRadius: 6 }} />)
  }
  if (type === 'dashboard_menu') {
    return block(
      <>
        {title && <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 6 }}>{title}</div>}
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${data.columns || 1}, 1fr)`, gap: 6 }}>
          {(data.items || []).slice(0, 4).map((it, i) => (
            <div key={i} style={{ padding: 6, borderRadius: 6, background: (it.color || '#2563EB') + '15', fontSize: 9 }}>
              <div style={{ color: it.color, fontWeight: 600 }}>{it.label}</div>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (type === 'quick_calendar') {
    return block(
      <>
        {title && <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 6 }}>{title}</div>}
        <div style={{ display: 'flex', gap: 4, justifyContent: 'space-between' }}>
          {Array.from({ length: data.days_to_show || 7 }).map((_, i) => (
            <div key={i} style={{ flex: 1, padding: 4, border: '1px solid #ddd', borderRadius: 4, textAlign: 'center', fontSize: 9 }}>
              <div style={{ color: '#999' }}>D</div>
              <div style={{ fontWeight: 600 }}>{i + 1}</div>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (type === 'popular_products' || type === 'all_products') {
    const cols = type === 'all_products' ? data.columns : 1
    return block(
      <>
        {title && <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 6 }}>{title}</div>}
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 6 }}>
          {Array.from({ length: Math.min(type === 'popular_products' ? 4 : 4, data.limit || 4) }).map((_, i) => (
            <div key={i} style={{ background: '#f4f4f4', borderRadius: 6, padding: 6, fontSize: 9 }}>
              <div style={{ height: 30, background: '#e0e0e0', borderRadius: 4, marginBottom: 4 }} />
              <div>Product</div>
              <div style={{ color: '#16A34A', fontWeight: 600 }}>₹100</div>
            </div>
          ))}
        </div>
      </>
    )
  }
  if (type === 'categories_grid') {
    return block(
      <>
        {title && <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 6 }}>{title}</div>}
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {['Cat1', 'Cat2', 'Cat3', 'Cat4'].map((c, i) => (
            <span key={i} style={{ padding: '2px 8px', background: '#f0f0f0', borderRadius: 12, fontSize: 9 }}>{c}</span>
          ))}
        </div>
      </>
    )
  }
  if (type === 'subscription_plans') {
    return block(
      <>
        {title && <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 6 }}>{title}</div>}
        <div style={{ padding: 8, background: '#9333EA15', borderRadius: 6, fontSize: 9, color: '#9333EA' }}>
          Subscribe & Save 15%
        </div>
      </>
    )
  }
  return block(<small className="text-muted">Unknown type</small>)
}

export default LayoutBuilder