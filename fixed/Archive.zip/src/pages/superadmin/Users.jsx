import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import useAuthStore from '../../store/authStore'
import { formatDateTime } from '../../utils/formatters'

const USERS_API = '/superadmin/users'

const rolesRequiringBranch = ['staff_headoffice', 'staff_stateoffice', 'staff_branch']
const PROFILE_ROLES = ['admin', 'staff_headoffice', 'staff_stateoffice', 'staff_branch']

const MAX_DOC_BYTES = 5 * 1024 * 1024
const ALLOWED_DOC_EXT = ['jpg', 'jpeg', 'png', 'pdf']

const PROFILE_DEFAULTS = {
  adhar_no: '', pan_no: '', emergency_contact_no: '',
  bank_account_holder: '', bank_name: '', bank_account_no: '', bank_ifsc: '', upi_id: '',
}
const emptyDocs = () => ({ adhar_doc: null, pan_doc: null })

const DOC_FIELDS = [
  { key: 'adhar_doc', label: 'Aadhaar Copy', short: 'Aadhaar', flag: 'has_adhar_doc', url: 'adhar_doc_url' },
  { key: 'pan_doc',   label: 'PAN Copy',     short: 'PAN',     flag: 'has_pan_doc',   url: 'pan_doc_url' },
]

const SORT_KEY_MAP = {
  name: 'name', username: 'username', email: 'email',
  mobile_number: 'mobile_number', created_at: 'created_at',
}

const todayISO = () => {
  const d = new Date()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

const dash = (v) => (v === null || v === undefined || v === '' ? '—' : v)

const passwordRules = (base) =>
  base
    .min(8, 'Minimum 8 characters')
    .matches(/[a-z]/, 'Must include a lowercase letter')
    .matches(/[A-Z]/, 'Must include an uppercase letter')
    .matches(/[0-9]/, 'Must include a number')
    .matches(/[^a-zA-Z0-9]/, 'Must include a special character')

const usernameRule = () =>
  yup.string().required('Username is required').min(3, 'Minimum 3 characters').max(30, 'Maximum 30 characters')
    .matches(/^[a-z][a-z0-9_.]*$/, 'Lowercase letters, numbers, underscore, dot only; must start with a letter')

const mobileRule = () =>
  yup.string().required('Mobile number is required').matches(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number')

const profileShape = (adharOnFile) => ({
  adhar_no: adharOnFile
    ? yup.string().matches(/^\d{12}$/, { message: 'Enter a 12-digit Aadhaar number', excludeEmptyString: true })
    : yup.string().required('Aadhaar number is required').matches(/^\d{12}$/, 'Enter a 12-digit Aadhaar number'),
  pan_no: yup.string().matches(/^[A-Z]{5}[0-9]{4}[A-Z]$/, { message: 'Format: ABCDE1234F', excludeEmptyString: true }),
  emergency_contact_no: yup.string().matches(/^[6-9]\d{9}$/, { message: 'Enter a valid 10-digit number', excludeEmptyString: true }),
  bank_account_no: yup.string().matches(/^\d{9,18}$/, { message: '9-18 digits', excludeEmptyString: true }),
  bank_ifsc: yup.string().matches(/^[A-Z]{4}0[A-Z0-9]{6}$/, { message: 'Format: HDFC0001234', excludeEmptyString: true }),
  upi_id: yup.string().matches(/^[\w.-]{2,256}@[a-zA-Z]{2,64}$/, { message: 'Format: name@bank', excludeEmptyString: true }),
  bank_account_holder: yup.string().when('bank_account_no', {
    is: (v) => !!v, then: (s) => s.required('Account holder is required with an account number'),
  }),
})

const createSchema = (requireBranch, needsProfile) => yup.object({
  name:          yup.string().required('Name is required'),
  email:         yup.string().email().required('Email is required'),
  username:      usernameRule(),
  mobile_number: mobileRule(),
  password:      passwordRules(yup.string()).required('Password is required'),
  role:          yup.string().required('Role is required'),
  branch_id: requireBranch ? yup.string().required('Branch is required') : yup.string().nullable().optional(),
  ...(needsProfile ? profileShape(false) : {}),
})

const editSchema = (requireBranch, needsProfile, adharOnFile) => yup.object({
  name:          yup.string().required('Name is required'),
  email:         yup.string().email().required('Email is required'),
  username:      usernameRule(),
  mobile_number: mobileRule(),
  password: yup.string().nullable().transform(v => (v === '' ? null : v)).optional()
    .when('$passwordProvided', { is: true, then: (s) => passwordRules(s) }),
  role:      yup.string().required('Role is required'),
  branch_id: requireBranch ? yup.string().required('Branch is required') : yup.string().nullable().optional(),
  ...(needsProfile ? profileShape(adharOnFile) : {}),
})

const roleBadgeColor = (role) => ({
  superadmin: 'danger', admin: 'primary', staff_headoffice: 'success',
  staff_stateoffice: 'warning', staff_branch: 'info',
}[role] ?? 'secondary')

const roleLabel = (role) => ({
  superadmin: 'Super Admin', admin: 'Admin', staff_headoffice: 'Staff (Head Office)',
  staff_stateoffice: 'Staff (State Office)', staff_branch: 'Staff (Branch)',
}[role] ?? role)

const isKycRole = (user) => PROFILE_ROLES.includes(user.role)
const isKycComplete = (user) => !!user.adhar_no_masked && !!user.has_adhar_doc

const FieldError = ({ error }) =>
  error ? <div className="text-danger small mt-1">{error.message}</div> : null

const Users = () => {
  const [users, setUsers]             = useState([])
  const [roles, setRoles]             = useState([])
  const [branches, setBranches]       = useState([])
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  const [modal, setModal]             = useState({ open: false, user: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, user: null })
  const [search, setSearch]           = useState('')
  const [roleFilter, setRoleFilter]   = useState('')
  const [branchFilter, setBranchFilter] = useState('')
  const [submitting, setSubmitting]   = useState(false)
  const [exporting, setExporting]     = useState(false)
  const [docFiles, setDocFiles]       = useState(emptyDocs())

  const [sortKey, setSortKey]         = useState(null)
  const [sortDir, setSortDir]         = useState('asc')

  const requestSeq = useRef(0)
  const skipFirstEffectRef = useRef(true)
  const authRole = useAuthStore(s => s.role)

  const canFilterByBranch = authRole === 'staff_headoffice'
  const isEdit = !!modal.user

  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const {
    register, handleSubmit, reset, watch,
    setError: setFieldError, clearErrors,
    formState: { errors },
  } = useForm()

  const selectedRole    = watch('role')
  const showBranchField = rolesRequiringBranch.includes(selectedRole)
  const requireBranch   = showBranchField
  const adharOnFile     = !!modal.user?.adhar_no_masked
  const schema = isEdit
    ? editSchema(requireBranch, true, adharOnFile)
    : createSchema(requireBranch, true)

  const fetchRoles = async () => {
    try {
      const res = await api.get('/superadmin/roles')
      let filtered = res.data.data.roles.filter(r => r.name !== 'delivery_boy')
      if (authRole === 'superadmin') {
        filtered = filtered.filter(r => r.name !== 'superadmin')
      } else if (authRole === 'admin') {
        filtered = filtered.filter(r => !['superadmin', 'admin'].includes(r.name))
      }
      setRoles(filtered)
    } catch (_) {}
  }

  const fetchBranches = async () => {
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 100 } })
      setBranches(res.data.data.data ?? [])
    } catch (_) {}
  }

  const buildFilterParams = ({
    sortKeyVal = sortKey, sortDirVal = sortDir, searchVal = search,
    roleVal = roleFilter, branchVal = branchFilter,
  } = {}) => {
    const params = {}
    if (searchVal) params.search = searchVal
    if (roleVal)   params.role   = roleVal
    if (canFilterByBranch && branchVal) params.branch_id = branchVal
    if (sortKeyVal && SORT_KEY_MAP[sortKeyVal]) {
      params.sort_key = SORT_KEY_MAP[sortKeyVal]
      params.sort_dir = sortDirVal
    }
    return params
  }

  const fetchData = async ({
    page = 1, perPageOverride = perPage, sortKeyOverride = sortKey,
    sortDirOverride = sortDir, searchOverride = search,
    roleOverride = roleFilter, branchOverride = branchFilter,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true); setError(null)
    try {
      const params = {
        page, per_page: perPageOverride || 25,
        ...buildFilterParams({
          sortKeyVal: sortKeyOverride, sortDirVal: sortDirOverride,
          searchVal: searchOverride, roleVal: roleOverride, branchVal: branchOverride,
        }),
      }
      const res = await api.get(USERS_API, { params })
      if (mySeq !== requestSeq.current) return
      const list = res.data?.data?.users ?? []
      const m = res.data?.data?.meta ?? {}
      setUsers(list)
      updatePagination({
        current_page: m.current_page ?? 1, last_page: m.last_page ?? 1,
        per_page: m.per_page ?? perPageOverride, total: m.total ?? list.length,
        from: m.from ?? null, to: m.to ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setUsers([])
      setError(err.response?.data?.message ?? 'Failed to load users.')
    } finally {
      if (mySeq === requestSeq.current) { setLoading(false); setPageLoading(false) }
    }
  }

  useEffect(() => {
    fetchRoles(); fetchBranches(); fetchData({ page: 1, perPageOverride: 25 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (skipFirstEffectRef.current) { skipFirstEffectRef.current = false; return }
    const t = setTimeout(() => {
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search, roleOverride: roleFilter, branchOverride: branchFilter })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, roleFilter, branchFilter])

  const handlePageChange = (page) => goToPage(page, fetchData)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key); setSortDir(nextDir); setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleClear = () => {
    const filtersDirty = search || roleFilter || branchFilter
    setSearch(''); setRoleFilter(''); setBranchFilter('')
    const sortDirty = sortKey !== null || sortDir !== 'asc'
    setSortKey(null); setSortDir('asc')
    if (!filtersDirty && sortDirty) {
      setPageLoading(true)
      fetchData({ page: 1, sortKeyOverride: null, sortDirOverride: 'asc' })
    }
  }

  const handleExport = async () => {
    setExporting(true)
    try {
      const res = await api.get(USERS_API, {
        params: { ...buildFilterParams(), export: 'csv' },
        responseType: 'blob',
      })
      const url = URL.createObjectURL(new Blob([res.data], { type: 'text/csv;charset=utf-8' }))
      const a = document.createElement('a')
      a.href = url; a.download = `users_${todayISO()}.csv`; a.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (err) {
      let msg = 'Export failed.'
      try {
        const text = await err.response?.data?.text?.()
        msg = (text && JSON.parse(text).message) || msg
      } catch (_) {}
      setError(msg)
    } finally {
      setExporting(false)
    }
  }

  const openCreate = () => {
    reset({
      name: '', email: '', username: '', mobile_number: '', password: '', role: '', branch_id: '',
      ...PROFILE_DEFAULTS,
    })
    setDocFiles(emptyDocs()); clearErrors(); setError(null)
    setModal({ open: true, user: null })
  }

  const openEdit = (user) => {
    reset({
      name: user.name, email: user.email, username: user.username ?? '',
      mobile_number: user.mobile_number ?? '', password: '', role: user.role,
      branch_id: user.branch_id ? String(user.branch_id) : '',
      ...PROFILE_DEFAULTS,
      emergency_contact_no: user.emergency_contact_no ?? '',
      bank_account_holder: user.bank_account_holder ?? '',
      bank_name: user.bank_name ?? '', bank_ifsc: user.bank_ifsc ?? '',
      upi_id: user.upi_id ?? '',
    })
    setDocFiles(emptyDocs()); clearErrors(); setError(null)
    setModal({ open: true, user })
  }

  const closeModal = () => {
    setModal({ open: false, user: null })
    setDocFiles(emptyDocs()); setError(null)
  }

  const handleDocChange = (key, e) => {
    const file = e.target.files?.[0] || null
    clearErrors(key)
    if (file) {
      const ext = file.name.split('.').pop().toLowerCase()
      if (!ALLOWED_DOC_EXT.includes(ext)) {
        setFieldError(key, { type: 'manual', message: 'Only jpg, png or pdf.' })
        e.target.value = ''; return
      }
      if (file.size > MAX_DOC_BYTES) {
        setFieldError(key, { type: 'manual', message: 'Must be 5 MB or smaller.' })
        e.target.value = ''; return
      }
    }
    setDocFiles(prev => ({ ...prev, [key]: file }))
  }

  const onSubmit = async (formValues) => {
    clearErrors(); setError(null)
    const data = {
      ...formValues,
      adhar_no: (formValues.adhar_no ?? '').replace(/\s+/g, ''),
      pan_no: (formValues.pan_no ?? '').trim().toUpperCase(),
      bank_ifsc: (formValues.bank_ifsc ?? '').trim().toUpperCase(),
      bank_account_no: (formValues.bank_account_no ?? '').replace(/\s+/g, ''),
    }
    let hasErrors = false
    try {
      await schema.validate(data, {
        abortEarly: false,
        context: { passwordProvided: isEdit ? !!data.password : true },
      })
    } catch (validationErr) {
      hasErrors = true
      const byPath = {}
      validationErr.inner.forEach(err => {
        byPath[err.path] = byPath[err.path] ? `${byPath[err.path]}; ${err.message}` : err.message
      })
      Object.entries(byPath).forEach(([path, message]) =>
        setFieldError(path, { type: 'manual', message }))
    }
    if (!docFiles.adhar_doc && !modal.user?.has_adhar_doc) {
      setFieldError('adhar_doc', { type: 'manual', message: 'Aadhaar copy is required' })
      hasErrors = true
    }
    if (hasErrors) return

    setSubmitting(true)
    try {
      const fd = new FormData()
      ;['name', 'email', 'username', 'mobile_number', 'role'].forEach(k => fd.append(k, data[k] ?? ''))
      fd.append('branch_id', data.branch_id ? String(parseInt(data.branch_id)) : '')
      if (data.password) fd.append('password', data.password)
      ;['emergency_contact_no', 'bank_account_holder', 'bank_name', 'bank_ifsc', 'upi_id']
        .forEach(k => fd.append(k, data[k] ?? ''))
      ;['adhar_no', 'pan_no', 'bank_account_no'].forEach(k => { if (data[k]) fd.append(k, data[k]) })
      ;['adhar_doc', 'pan_doc'].forEach(k => { if (docFiles[k]) fd.append(k, docFiles[k]) })

      const config = { headers: { 'Content-Type': 'multipart/form-data' } }
      if (isEdit) {
        fd.append('_method', 'PUT')
        await api.post(`${USERS_API}/${modal.user.id}`, fd, config)
      } else {
        await api.post(USERS_API, fd, config)
      }
      closeModal()
      fetchData({ page: meta.current_page || 1 })
    } catch (e) {
      const serverErrors = e.response?.data?.errors
      if (e.response?.status === 422 && serverErrors) {
        Object.entries(serverErrors).forEach(([field, messages]) => {
          setFieldError(field, {
            type: 'server',
            message: Array.isArray(messages) ? messages.join('; ') : String(messages),
          })
        })
      } else {
        setError(e.response?.data?.message ?? 'Operation failed.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`${USERS_API}/${deleteModal.user.id}`)
      setDeleteModal({ open: false, user: null })
      const lastOnPage = users.length === 1 && meta.current_page > 1
      fetchData({ page: lastOnPage ? meta.current_page - 1 : (meta.current_page || 1) })
    } catch (e) {
      setDeleteModal({ open: false, user: null })
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span className={'sort-icon' + (active ? ' sort-icon--active' : '') + (isDesc ? ' sort-icon--desc' : '')} />
      </CTableHeaderCell>
    )
  }

  const renderDocField = ({ key, label, flag, url }) => {
    const required = key === 'adhar_doc'
    const existing = !!modal.user?.[flag]
    const file = docFiles[key]
    return (
      <div className="col-md-6" key={key}>
        <CFormLabel className="filter-label">
          {label} {required && !existing && <span className="text-danger">*</span>}
        </CFormLabel>
        <CFormInput
          className="filter-input" type="file" size="sm" accept=".jpg,.jpeg,.png,.pdf"
          invalid={!!errors[key]} onChange={e => handleDocChange(key, e)}
        />
        <small className="text-muted d-block mt-1" style={{ fontSize: '0.7rem', lineHeight: 1.2 }}>
          {file ? (<>Selected: <strong>{file.name}</strong></>)
            : existing ? (
              <>On file — <a href={modal.user[url]} target="_blank" rel="noreferrer" className="text-decoration-none">View</a></>
            ) : ('jpg / png / pdf, max 5 MB')}
        </small>
        <FieldError error={errors[key]} />
      </div>
    )
  }

  const sNoBase = ((meta.current_page || 1) - 1) * perPage
  const COLSPAN = 18

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Users</h4>
          <div className="d-flex gap-2">
            <PermissionGate permission="user.view">
              <CButton size="sm" className="report-shell__export" onClick={handleExport} disabled={exporting || !users.length || loading}>
                {exporting ? <CSpinner size="sm" className="me-2" /> : null} Export CSV
              </CButton>
            </PermissionGate>
            <PermissionGate permission="user.create">
              <CButton size="sm" className="report-shell__export" onClick={openCreate}>
                <CIcon icon={cilPlus} className="me-2" />Add User
              </CButton>
            </PermissionGate>
          </div>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput size="sm" className="filter-input" placeholder="Name, email, username, mobile..."
              value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Role</CFormLabel>
            <CFormSelect size="sm" className="filter-input" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
              <option value="">All Roles</option>
              {roles.map(r => <option key={r.id} value={r.name}>{roleLabel(r.name)}</option>)}
            </CFormSelect>
          </div>
          {canFilterByBranch && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">Branch</CFormLabel>
              <CFormSelect size="sm" className="filter-input" value={branchFilter} onChange={(e) => setBranchFilter(e.target.value)}>
                <option value="">All Branches</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name} ({b.type?.replace('_', ' ')})</option>
                ))}
              </CFormSelect>
            </div>
          )}
          <div className="filter-field filter-field--perpage">
            <PerPageSelector value={perPage} onChange={handlePerPageChangeWrapper} label="Per Page" disabled={loading} />
          </div>
          <div className="filter-field filter-field--buttons">
            <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={handleClear} disabled={loading}>Clear</CButton>
          </div>
        </div>

        {error && !modal.open && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner /><div className="report-shell__loading-text">Loading users...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No</CTableHeaderCell>
                    <SortableHeader colKey="name">Name</SortableHeader>
                    <SortableHeader colKey="username">Username</SortableHeader>
                    <SortableHeader colKey="mobile_number">Mobile</SortableHeader>
                    <CTableHeaderCell>Emergency Contact</CTableHeaderCell>
                    <SortableHeader colKey="email">Email</SortableHeader>
                    <CTableHeaderCell>Role</CTableHeaderCell>
                    <CTableHeaderCell>Branch</CTableHeaderCell>
                    <CTableHeaderCell>Aadhaar No</CTableHeaderCell>
                    <CTableHeaderCell>PAN No</CTableHeaderCell>
                    <CTableHeaderCell>Documents</CTableHeaderCell>
                    <CTableHeaderCell>Account Holder</CTableHeaderCell>
                    <CTableHeaderCell>Bank</CTableHeaderCell>
                    <CTableHeaderCell>Account No</CTableHeaderCell>
                    <CTableHeaderCell>IFSC</CTableHeaderCell>
                    <CTableHeaderCell>UPI ID</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Created</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {!error && users.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={COLSPAN} className="text-center text-muted py-4">No users found.</CTableDataCell>
                    </CTableRow>
                  ) : (
                    users.map((user, i) => (
                      <CTableRow key={user.id}>
                        <CTableDataCell>{sNoBase + i + 1}</CTableDataCell>
                        <CTableDataCell>{user.name}</CTableDataCell>
                        <CTableDataCell>{dash(user.username)}</CTableDataCell>
                        <CTableDataCell>{dash(user.mobile_number)}</CTableDataCell>
                        <CTableDataCell>{dash(user.emergency_contact_no)}</CTableDataCell>
                        <CTableDataCell>{user.email}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={roleBadgeColor(user.role)}>{roleLabel(user.role)}</CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{dash(user.branch?.name)}</CTableDataCell>
                        <CTableDataCell>{dash(user.adhar_no_masked)}</CTableDataCell>
                        <CTableDataCell>{dash(user.pan_no_masked)}</CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex flex-wrap gap-1 align-items-center" style={{ minWidth: 130 }}>
                            <PermissionGate permission="user.view">
                              {DOC_FIELDS.filter(d => user[d.flag]).map(d => (
                                <a key={d.key} href={user[d.url]} target="_blank" rel="noreferrer"
                                  className="badge text-bg-light border text-decoration-none" title={`View ${d.label}`}>
                                  {d.short}
                                </a>
                              ))}
                            </PermissionGate>
                            {isKycRole(user)
                              ? (!isKycComplete(user) && <CBadge color="warning">KYC incomplete</CBadge>)
                              : <span className="text-muted">—</span>}
                          </div>
                        </CTableDataCell>
                        <CTableDataCell>{dash(user.bank_account_holder)}</CTableDataCell>
                        <CTableDataCell>{dash(user.bank_name)}</CTableDataCell>
                        <CTableDataCell>{dash(user.bank_account_no_masked)}</CTableDataCell>
                        <CTableDataCell>{dash(user.bank_ifsc)}</CTableDataCell>
                        <CTableDataCell>{dash(user.upi_id)}</CTableDataCell>
                        <CTableDataCell>{formatDateTime(user.created_at)}</CTableDataCell>
                        <CTableDataCell>
                          <div className="admin-action-stack">
                            <PermissionGate permission="user.edit">
                              <CButton size="sm" color="warning" variant="outline" onClick={() => openEdit(user)}>
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="user.delete">
                              <CButton size="sm" color="danger" variant="outline"
                                onClick={() => setDeleteModal({ open: true, user })}
                                disabled={user.role === 'superadmin'}>
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>
              <Pagination meta={meta} onPageChange={handlePageChange} loading={pageLoading}
                variant="bold" showPageJumper={true} showRecordInfo={true} />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* CREATE / EDIT MODAL — structurally identical to DeliveryBoys */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" size="lg">
        <CModalHeader>
          <CModalTitle>{isEdit ? 'Edit User' : 'Add User'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody style={{ maxHeight: '75vh', overflowY: 'auto' }}>
            {error && <CAlert color="danger">{error}</CAlert>}

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Name <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.name} {...register('name')} />
                <FieldError error={errors.name} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Username <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.username} {...register('username')} />
                <div className="text-muted small mt-1">Lowercase letters, numbers, _ and . ; start with a letter.</div>
                <FieldError error={errors.username} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Email <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" type="email" invalid={!!errors.email} {...register('email')} />
                <FieldError error={errors.email} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Mobile <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" type="tel" maxLength={10} invalid={!!errors.mobile_number} {...register('mobile_number')} />
                <FieldError error={errors.mobile_number} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  {isEdit ? 'New Password (optional)' : 'Password'} {!isEdit && <span className="text-danger">*</span>}
                </CFormLabel>
                <CFormInput className="filter-input" type="password" autoComplete="new-password" invalid={!!errors.password} {...register('password')} />
                <div className="text-muted small mt-1">Min 8 chars: upper, lower, number, special.</div>
                <FieldError error={errors.password} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Role <span className="text-danger">*</span></CFormLabel>
                <CFormSelect className="filter-input" invalid={!!errors.role} {...register('role')}>
                  <option value="">Select role...</option>
                  {roles.map(r => <option key={r.id} value={r.name}>{roleLabel(r.name)}</option>)}
                </CFormSelect>
                <FieldError error={errors.role} />
              </div>
              {showBranchField && (
                <div className="col-md-6">
                  <CFormLabel className="filter-label">Branch <span className="text-danger">*</span></CFormLabel>
                  <CFormSelect className="filter-input" invalid={!!errors.branch_id} {...register('branch_id')}>
                    <option value="">Select branch...</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name} ({b.type?.replace('_', ' ')})</option>
                    ))}
                  </CFormSelect>
                  <FieldError error={errors.branch_id} />
                  {branches.length === 0 && (
                    <div className="text-warning small mt-1">No branches found. Create a branch first.</div>
                  )}
                </div>
              )}
            </div>

            {/* Identity & Documents — ALWAYS rendered, exactly like DeliveryBoys */}
            <hr />
            <h6 className="mb-1">Identity &amp; Documents</h6>
            {isEdit && (
              <p className="text-muted small mb-3">
                Saved ID numbers are not shown in full. Leave a number blank to keep the stored value.
              </p>
            )}

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Aadhaar No. {!adharOnFile && <span className="text-danger">*</span>}</CFormLabel>
                <CFormInput className="filter-input" inputMode="numeric" maxLength={14} autoComplete="off"
                  invalid={!!errors.adhar_no}
                  placeholder={adharOnFile ? `${modal.user.adhar_no_masked} (blank = keep)` : '12-digit number'}
                  {...register('adhar_no')} />
                <FieldError error={errors.adhar_no} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">PAN No.</CFormLabel>
                <CFormInput className="filter-input" maxLength={10} autoComplete="off" invalid={!!errors.pan_no}
                  placeholder={modal.user?.pan_no_masked ? `${modal.user.pan_no_masked} (blank = keep)` : 'e.g. ABCDE1234F'}
                  {...register('pan_no')} />
                <FieldError error={errors.pan_no} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Emergency Contact No.</CFormLabel>
                <CFormInput className="filter-input" inputMode="numeric" maxLength={10}
                  invalid={!!errors.emergency_contact_no} placeholder="10-digit mobile"
                  {...register('emergency_contact_no')} />
                <FieldError error={errors.emergency_contact_no} />
              </div>
            </div>

            <div className="row g-3 mb-3">
              {DOC_FIELDS.map(renderDocField)}
            </div>

            <hr />
            <h6 className="mb-3">Bank Details</h6>

            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Account Holder Name</CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.bank_account_holder} {...register('bank_account_holder')} />
                <FieldError error={errors.bank_account_holder} />
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Bank Name</CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.bank_name} {...register('bank_name')} />
                <FieldError error={errors.bank_name} />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Account No.</CFormLabel>
                <CFormInput className="filter-input" inputMode="numeric" maxLength={18} autoComplete="off"
                  invalid={!!errors.bank_account_no}
                  placeholder={modal.user?.bank_account_no_masked ? `${modal.user.bank_account_no_masked} (blank = keep)` : ''}
                  {...register('bank_account_no')} />
                <FieldError error={errors.bank_account_no} />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">IFSC</CFormLabel>
                <CFormInput className="filter-input" maxLength={11} invalid={!!errors.bank_ifsc}
                  placeholder="e.g. HDFC0001234" {...register('bank_ifsc')} />
                <FieldError error={errors.bank_ifsc} />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">UPI ID</CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.upi_id} placeholder="name@bank" {...register('upi_id')} />
                <FieldError error={errors.upi_id} />
              </div>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton type="button" className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>Cancel</CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* DELETE MODAL */}
      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, user: null })}>
        <CModalHeader><CModalTitle>Confirm Delete</CModalTitle></CModalHeader>
        <CModalBody>
          Are you sure you want to delete <strong>{deleteModal.user?.name}</strong>? Their uploaded documents are deleted too. This cannot be undone.
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setDeleteModal({ open: false, user: null })}>Cancel</CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Users