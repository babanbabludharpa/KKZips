import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CAccordion, CAccordionItem, CAccordionHeader, CAccordionBody,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'

const schema = yup.object({
  name: yup
    .string()
    .matches(/^[a-z]+\.[a-z]+$/, 'Format must be module.action (e.g. category.view)')
    .required('Permission name is required'),
})

const Permissions = () => {
  const [grouped, setGrouped]         = useState({})
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  const [modal, setModal]             = useState({ open: false, permission: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, permission: null })
  const [submitting, setSubmitting]   = useState(false)

  const isEdit = !!modal.permission

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  })

  const fetchPermissions = async () => {
    try {
      setLoading(true)
      const res = await api.get('/superadmin/permissions')
      setGrouped(res.data.data.grouped)
    } catch (e) {
      setError('Failed to load permissions.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchPermissions() }, [])

  const openCreate = () => {
    reset({ name: '' })
    setModal({ open: true, permission: null })
  }

  const openEdit = (permission) => {
    reset({ name: permission.name })
    setModal({ open: true, permission })
  }

  const closeModal = () => setModal({ open: false, permission: null })

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (isEdit) {
        await api.put(`/superadmin/permissions/${modal.permission.id}`, data)
      } else {
        await api.post('/superadmin/permissions', data)
      }
      closeModal()
      fetchPermissions()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/superadmin/permissions/${deleteModal.permission.id}`)
      setDeleteModal({ open: false, permission: null })
      fetchPermissions()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const totalCount = Object.values(grouped).reduce((sum, perms) => sum + perms.length, 0)

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">Permissions</h4>
            <small className="admin-page-note">{totalCount} total permissions</small>
          </div>
          <PermissionGate permission="permission.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />Add Permission
            </CButton>
          </PermissionGate>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-3">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading permissions...</div>
            </div>
          ) : (
            <CAccordion alwaysOpen>
              {Object.entries(grouped).map(([group, perms], idx) => (
                <CAccordionItem key={group} itemKey={idx + 1}>
                  <CAccordionHeader>
                    <span className="text-uppercase fw-semibold me-2">{group}</span>
                    <CBadge color="primary" className="ms-1">{perms.length}</CBadge>
                  </CAccordionHeader>
                  <CAccordionBody className="p-0">
                    <CTable hover responsive className="admin-data-table">
                      <CTableHead>
                        <CTableRow>
                          <CTableHeaderCell>Permission</CTableHeaderCell>
                          <CTableHeaderCell>Guard</CTableHeaderCell>
                          <CTableHeaderCell>Created</CTableHeaderCell>
                          <CTableHeaderCell>Actions</CTableHeaderCell>
                        </CTableRow>
                      </CTableHead>
                      <CTableBody>
                        {perms.map(perm => (
                          <CTableRow key={perm.id}>
                            <CTableDataCell>
                              <CBadge color="light" textColor="dark" className="border font-monospace">
                                {perm.name}
                              </CBadge>
                            </CTableDataCell>
                            <CTableDataCell>
                              <CBadge color="info">{perm.guard_name}</CBadge>
                            </CTableDataCell>
                            <CTableDataCell>{perm.created_at?.slice(0, 10)}</CTableDataCell>
                            <CTableDataCell>
                              <PermissionGate permission="permission.edit">
                                <CButton
                                  size="sm" color="warning" variant="outline" className="me-2"
                                  onClick={() => openEdit(perm)}
                                >
                                  <CIcon icon={cilPencil} />
                                </CButton>
                              </PermissionGate>
                              <PermissionGate permission="permission.delete">
                                <CButton
                                  size="sm" color="danger" variant="outline"
                                  onClick={() => setDeleteModal({ open: true, permission: perm })}
                                >
                                  <CIcon icon={cilTrash} />
                                </CButton>
                              </PermissionGate>
                            </CTableDataCell>
                          </CTableRow>
                        ))}
                      </CTableBody>
                    </CTable>
                  </CAccordionBody>
                </CAccordionItem>
              ))}
            </CAccordion>
          )}
        </CCardBody>
      </CCard>

      {/* Create / Edit Modal */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static">
        <CModalHeader className="glass-card__header">
          <CModalTitle>{isEdit ? 'Edit Permission' : 'Add Permission'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody>
            <CFormLabel>
              Permission Name
              <span className="text-muted small ms-2">Format: module.action</span>
            </CFormLabel>
            <CFormInput
              placeholder="e.g. category.export"
              invalid={!!errors.name}
              {...register('name')}
            />
            {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
            <div className="text-muted small mt-2">
              Examples: <code>report.export</code>, <code>stock.adjust</code>, <code>order.cancel</code>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton color="secondary" onClick={closeModal} disabled={submitting}>Cancel</CButton>
            <CButton type="submit" color="primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* Delete Confirm */}
      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, permission: null })}>
        <CModalHeader className="glass-card__header"><CModalTitle>Confirm Delete</CModalTitle></CModalHeader>
        <CModalBody>
          Delete permission <code>{deleteModal.permission?.name}</code>?
          This will remove it from all roles that currently have it.
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setDeleteModal({ open: false, permission: null })}>Cancel</CButton>
          <CButton color="danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Permissions