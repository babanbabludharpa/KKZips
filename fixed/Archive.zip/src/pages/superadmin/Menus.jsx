import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CBadge,
  CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect, CFormCheck, CAccordion, CAccordionItem,
  CAccordionHeader, CAccordionBody, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilArrowTop, cilArrowBottom } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import useMenuStore from '../../store/menuStore'

const schema = yup.object({
  name:       yup.string().required('Name is required'),
  route:      yup.string().nullable().optional(),
  icon:       yup.string().nullable().optional(),
  parent_id:  yup.mixed().nullable().optional(),
  permission: yup.string().nullable().optional(),
  is_active:  yup.boolean(),
})

const Menus = () => {
  const [tree, setTree]               = useState([])
  const [flat, setFlat]               = useState([])
  const [permissions, setPermissions] = useState([])
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  const [modal, setModal]             = useState({ open: false, menu: null, parentId: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, menu: null })
  const [submitting, setSubmitting]   = useState(false)
  const resetMenus = useMenuStore((s) => s.resetMenus)

  const isEdit = !!modal.menu

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { is_active: true },
  })

  const fetchAll = async () => {
    try {
      setLoading(true)
      const [menuRes, permRes] = await Promise.all([
        api.get('/superadmin/menus'),
        api.get('/superadmin/permissions'),
      ])
      setTree(menuRes.data.data.menus)
      setFlat(menuRes.data.data.flat)
      setPermissions(permRes.data.data.permissions ?? [])
    } catch (e) {
      setError('Failed to load menus.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchAll() }, [])

  const openCreate = (parentId = null) => {
    reset({ name: '', route: '', icon: '', parent_id: parentId ?? '', permission: '', is_active: true })
    setModal({ open: true, menu: null, parentId })
  }

  const openEdit = (menu) => {
    reset({
      name:       menu.name,
      route:      menu.route      ?? '',
      icon:       menu.icon       ?? '',
      parent_id:  menu.parent_id  ?? '',
      permission: menu.permission ?? '',
      is_active:  menu.is_active,
    })
    setModal({ open: true, menu, parentId: menu.parent_id })
  }

  const closeModal = () => setModal({ open: false, menu: null, parentId: null })

  const onSubmit = async (data) => {
    setSubmitting(true)
    const payload = {
      ...data,
      route:      data.route      || null,
      icon:       data.icon       || null,
      permission: data.permission || null,
      parent_id:  data.parent_id  || null,
    }
    try {
      if (isEdit) {
        await api.put(`/superadmin/menus/${modal.menu.id}`, payload)
      } else {
        await api.post('/superadmin/menus', payload)
      }
      closeModal()
      resetMenus()
      fetchAll()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/superadmin/menus/${deleteModal.menu.id}`)
      setDeleteModal({ open: false, menu: null })
      resetMenus()
      fetchAll()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const moveItem = async (siblings, index, direction) => {
    const swapIndex = direction === 'up' ? index - 1 : index + 1
    if (swapIndex < 0 || swapIndex >= siblings.length) return
    const payload = [
      { id: siblings[index].id,    sort_order: swapIndex, parent_id: siblings[index].parent_id    ?? null },
      { id: siblings[swapIndex].id, sort_order: index,    parent_id: siblings[swapIndex].parent_id ?? null },
    ]
    try {
      await api.post('/superadmin/menus/reorder', { items: payload })
      resetMenus()
      fetchAll()
    } catch { setError('Reorder failed.') }
  }

  const parentOptions = flat.filter(m => !m.parent_id)

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">Menus</h4>
          </div>
          <PermissionGate permission="menu.create">
            <CButton size="sm" className="report-shell__export" onClick={() => openCreate()}>
              <CIcon icon={cilPlus} className="me-2" />Add Menu
            </CButton>
          </PermissionGate>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-3">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading menus...</div>
            </div>
          ) : tree.length === 0 ? (
            <div className="text-center text-muted py-5">No menus found.</div>
          ) : (
            <CAccordion alwaysOpen>
              {tree.map((parent, pIndex) => (
                <CAccordionItem key={parent.id} itemKey={parent.id}>
                  <CAccordionHeader>
                    <div className="d-flex align-items-center gap-3 w-100 me-3">
                      <span className="fw-semibold">{parent.name}</span>
                      {parent.route && <code className="small text-muted">{parent.route}</code>}
                      {parent.icon  && <CBadge color="light" textColor="dark" className="border small">{parent.icon}</CBadge>}
                      {parent.permission
                        ? <CBadge color="info">{parent.permission}</CBadge>
                        : <CBadge color="success">Public</CBadge>}
                      <CBadge color={parent.is_active ? 'success' : 'secondary'}>
                        {parent.is_active ? 'Active' : 'Inactive'}
                      </CBadge>

                      <div className="ms-auto d-flex gap-1" onClick={e => e.stopPropagation()}>
                        <CButton size="sm" color="light" variant="outline" onClick={() => moveItem(tree, pIndex, 'up')}  disabled={pIndex === 0}><CIcon icon={cilArrowTop} /></CButton>
                        <CButton size="sm" color="light" variant="outline" onClick={() => moveItem(tree, pIndex, 'down')} disabled={pIndex === tree.length - 1}><CIcon icon={cilArrowBottom} /></CButton>
                        <CButton size="sm" color="info"    variant="outline" onClick={() => openCreate(parent.id)}><CIcon icon={cilPlus} /></CButton>
                        <CButton size="sm" color="warning" variant="outline" onClick={() => openEdit(parent)}><CIcon icon={cilPencil} /></CButton>
                        <CButton size="sm" color="danger"  variant="outline" onClick={() => setDeleteModal({ open: true, menu: parent })}><CIcon icon={cilTrash} /></CButton>
                      </div>
                    </div>
                  </CAccordionHeader>

                  <CAccordionBody className="p-0">
                    {(!parent.children || parent.children.length === 0) ? (
                      <div className="text-muted text-center py-3 small">
                        No submenus - <span className="text-primary" style={{ cursor: 'pointer' }} onClick={() => openCreate(parent.id)}>add one</span>
                      </div>
                    ) : (
                      <CTable hover responsive className="admin-data-table">
                        <CTableHead>
                          <CTableRow>
                            <CTableHeaderCell>Name</CTableHeaderCell>
                            <CTableHeaderCell>Route</CTableHeaderCell>
                            <CTableHeaderCell>Icon</CTableHeaderCell>
                            <CTableHeaderCell>Permission</CTableHeaderCell>
                            <CTableHeaderCell>Status</CTableHeaderCell>
                            <CTableHeaderCell>Actions</CTableHeaderCell>
                          </CTableRow>
                        </CTableHead>
                        <CTableBody>
                          {parent.children.map((child, cIndex) => (
                            <CTableRow key={child.id}>
                              <CTableDataCell>
                                <span className="text-muted me-2">-</span>
                                {child.name}
                              </CTableDataCell>
                              <CTableDataCell>
                                {child.route ? <code className="small">{child.route}</code> : <span className="text-muted">-</span>}
                              </CTableDataCell>
                              <CTableDataCell>
                                {child.icon ? <code className="small">{child.icon}</code> : <span className="text-muted">-</span>}
                              </CTableDataCell>
                              <CTableDataCell>
                                {child.permission
                                  ? <CBadge color="light" textColor="dark" className="border">{child.permission}</CBadge>
                                  : <CBadge color="success">Public</CBadge>}
                              </CTableDataCell>
                              <CTableDataCell>
                                <CBadge color={child.is_active ? 'success' : 'secondary'}>
                                  {child.is_active ? 'Active' : 'Inactive'}
                                </CBadge>
                              </CTableDataCell>
                              <CTableDataCell>
                                <div className="d-flex gap-1 justify-content-center">
                                  <CButton size="sm" color="light" variant="outline" onClick={() => moveItem(parent.children, cIndex, 'up')}   disabled={cIndex === 0}><CIcon icon={cilArrowTop} /></CButton>
                                  <CButton size="sm" color="light" variant="outline" onClick={() => moveItem(parent.children, cIndex, 'down')} disabled={cIndex === parent.children.length - 1}><CIcon icon={cilArrowBottom} /></CButton>
                                  <CButton size="sm" color="warning" variant="outline" onClick={() => openEdit(child)}><CIcon icon={cilPencil} /></CButton>
                                  <CButton size="sm" color="danger"  variant="outline" onClick={() => setDeleteModal({ open: true, menu: child })}><CIcon icon={cilTrash} /></CButton>
                                </div>
                              </CTableDataCell>
                            </CTableRow>
                          ))}
                        </CTableBody>
                      </CTable>
                    )}
                  </CAccordionBody>
                </CAccordionItem>
              ))}
            </CAccordion>
          )}
        </CCardBody>
      </CCard>

      {/* Create / Edit Modal */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" scrollable>
        <CModalHeader className="glass-card__header">
          <CModalTitle>{isEdit ? 'Edit Menu' : modal.parentId ? 'Add Submenu' : 'Add Menu'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody>
            <div className="mb-3">
              <CFormLabel>Name <span className="text-danger">*</span></CFormLabel>
              <CFormInput placeholder="e.g. Categories" invalid={!!errors.name} {...register('name')} />
              {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
            </div>
            <div className="mb-3">
              <CFormLabel>Route <span className="text-muted small">(blank for group headers)</span></CFormLabel>
              <CFormInput placeholder="/masters/categories" {...register('route')} />
            </div>
            <div className="mb-3">
              <CFormLabel>
                Icon
                <a href="https://coreui.io/icons/" target="_blank" rel="noreferrer" className="ms-2 small">Browse CoreUI Icons →</a>
              </CFormLabel>
              <CFormInput placeholder="cilLayers" {...register('icon')} />
            </div>
            <div className="mb-3">
              <CFormLabel>Parent Menu <span className="text-muted small">(blank = top level)</span></CFormLabel>
              <CFormSelect {...register('parent_id')}>
                <option value="">Top level</option>
                {parentOptions.map(m => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </CFormSelect>
            </div>
            <div className="mb-3">
              <CFormLabel>Permission <span className="text-muted small">(blank = visible to all)</span></CFormLabel>
              <CFormSelect {...register('permission')}>
                <option value="">No permission required</option>
                {permissions.map(p => (
                  <option key={p.id} value={p.name}>{p.name}</option>
                ))}
              </CFormSelect>
            </div>
            <CFormCheck id="is_active" label="Active" {...register('is_active')} />
          </CModalBody>
          <CModalFooter>
            <CButton color="secondary" onClick={closeModal} disabled={submitting}>Cancel</CButton>
            <CButton type="submit" color="primary" disabled={submitting}>
              {submitting && <CSpinner size="sm" className="me-2" />}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* Delete Confirm */}
      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, menu: null })}>
        <CModalHeader className="glass-card__header">
          <CModalTitle>Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody>
          Delete <strong>{deleteModal.menu?.name}</strong>?
          {deleteModal.menu?.children?.length > 0 && (
            <div className="text-warning mt-2">Submenus will be promoted to top level.</div>
          )}
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setDeleteModal({ open: false, menu: null })}>Cancel</CButton>
          <CButton color="danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Menus