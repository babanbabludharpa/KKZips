import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CCardHeader, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormCheck,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

const SORT_KEY_MAP = {
  name:        'name',
  users_count: 'users_count',
  created_at:  'created_at',
}

const schema = yup.object({
  name: yup
    .string()
    .matches(/^[a-z_]+$/, 'Lowercase letters and underscores only')
    .required('Role name is required'),
})

const actionLabel = (action) => ({
  view: 'View', create: 'Create', edit: 'Edit', delete: 'Delete',
  approve: 'Approve', assign: 'Assign', manage: 'Manage',
}[action] ?? action)

const roleBadgeColor = (name) => ({
  superadmin: 'danger', admin: 'primary', manager: 'warning', staff: 'info',
}[name] ?? 'secondary')

const buildMenuPermissionTree = (menuTree, allPerms) => {
  const permsByModule = allPerms.reduce((acc, p) => {
    const [module] = p.name.split('.')
    if (!acc[module]) acc[module] = []
    acc[module].push(p)
    return acc
  }, {})

  const result   = []
  const assigned = new Set()

  menuTree.forEach(parent => {
    const group = { menuName: parent.name, children: [] }

    if (parent.children && parent.children.length > 0) {
      parent.children.forEach(child => {
        const module = child.name.toLowerCase().replace(/\s+/g, '_')
        const perms = permsByModule[module]
          ?? Object.entries(permsByModule).find(([k]) => k.includes(module) || module.includes(k))?.[1]
          ?? []

        if (perms.length > 0) {
          group.children.push({ label: child.name, module, permissions: perms })
          perms.forEach(p => assigned.add(p.name))
        }
      })

      const parentModule = parent.name.toLowerCase().replace(/\s+/g, '_')
      const parentPerms  = permsByModule[parentModule] ?? []
      const unassigned   = parentPerms.filter(p => !assigned.has(p.name))
      if (unassigned.length > 0) {
        group.children.push({ label: parent.name, module: parentModule, permissions: unassigned })
        unassigned.forEach(p => assigned.add(p.name))
      }

    } else {
      const module = parent.name.toLowerCase().replace(/\s+/g, '_')
      const perms  = permsByModule[module]
        ?? Object.entries(permsByModule).find(([k]) => k.includes(module) || module.includes(k))?.[1]
        ?? []

      if (perms.length > 0) {
        group.children.push({ label: parent.name, module, permissions: perms })
        perms.forEach(p => assigned.add(p.name))
      }
    }

    if (group.children.length > 0) result.push(group)
  })

  const unmatched = allPerms.filter(p => !assigned.has(p.name))
  if (unmatched.length > 0) {
    const systemGroup = { menuName: 'System', children: [] }
    const byModule = unmatched.reduce((acc, p) => {
      const [mod] = p.name.split('.')
      if (!acc[mod]) acc[mod] = []
      acc[mod].push(p)
      return acc
    }, {})
    Object.entries(byModule).forEach(([mod, perms]) => {
      systemGroup.children.push({ label: mod, module: mod, permissions: perms })
    })
    result.push(systemGroup)
  }

  return result
}

const Roles = () => {
  const [roles, setRoles]                 = useState([])
  const [menuTree, setMenuTree]           = useState([])
  const [allPerms, setAllPerms]           = useState([])
  const [permTree, setPermTree]           = useState([])
  const [loading, setLoading]             = useState(false)
  const [error, setError]                 = useState(null)
  const [modal, setModal]                 = useState({ open: false, role: null })
  const [deleteModal, setDeleteModal]     = useState({ open: false, role: null })
  const [selectedPerms, setSelectedPerms] = useState([])
  const [submitting, setSubmitting]       = useState(false)
  const [search, setSearch]               = useState('')
  const [sortKey, setSortKey]             = useState(null)
  const [sortDir, setSortDir]             = useState('asc')

  const requestSeq = useRef(0)

  const isEdit = !!modal.role

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  })

  const fetchLookups = async () => {
    try {
      const [permsRes, menuRes] = await Promise.all([
        api.get('/superadmin/permissions'),
        api.get('/superadmin/menus'),
      ])

      const perms = permsRes.data.data.permissions ?? []
      const menus = menuRes.data.data.menus ?? []

      setAllPerms(perms)
      setMenuTree(menus)
      setPermTree(buildMenuPermissionTree(menus, perms))
    } catch (_) {}
  }

  const buildParams = (perPageVal, sortKeyVal, sortDirVal, searchVal) => {
    const params = { per_page: perPageVal || 25 }
    if (searchVal) params.search = searchVal
    if (sortKeyVal) {
      const backendKey = SORT_KEY_MAP[sortKeyVal]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = sortDirVal
      }
    }
    return params
  }

  const fetchData = async ({
    page = 1,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
    searchOverride  = search,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(perPageOverride, sortKeyOverride, sortDirOverride, searchOverride),
      }

      const res = await api.get('/superadmin/roles', { params })
      if (mySeq !== requestSeq.current) return

      const roles = res.data?.data?.roles ?? []
      const paginationMeta = res.data?.data?.meta ?? {}

      setRoles(roles)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? roles.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRoles([])
      setError(err.response?.data?.message ?? 'Failed to load roles.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchLookups()
    fetchData({ page: 1, perPageOverride: 25 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setPageLoading(true)
      fetchData({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => goToPage(page, fetchData)

  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchData)

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchData({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleClear = () => {
    setSearch('')
    setSortKey(null)
    setSortDir('asc')
    setPageLoading(true)
    fetchData({
      page: 1,
      searchOverride: '',
      sortKeyOverride: null,
      sortDirOverride: 'asc',
    })
  }

  const openCreate = () => {
    reset({ name: '' })
    setSelectedPerms([])
    setModal({ open: true, role: null })
  }

  const openEdit = (role) => {
    reset({ name: role.name })
    setSelectedPerms(role.permissions?.map(p => p.name) ?? [])
    setModal({ open: true, role })
  }

  const closeModal = () => setModal({ open: false, role: null })

  const togglePerm = (name) => {
    setSelectedPerms(prev =>
      prev.includes(name) ? prev.filter(p => p !== name) : [...prev, name]
    )
  }

  const toggleGroup = (perms) => {
    const names = perms.map(p => p.name)
    const allOn = names.every(n => selectedPerms.includes(n))
    setSelectedPerms(prev =>
      allOn ? prev.filter(n => !names.includes(n)) : [...new Set([...prev, ...names])]
    )
  }

  const toggleMenu = (group) => {
    const names = group.children.flatMap(c => c.permissions.map(p => p.name))
    const allOn = names.every(n => selectedPerms.includes(n))
    setSelectedPerms(prev =>
      allOn ? prev.filter(n => !names.includes(n)) : [...new Set([...prev, ...names])]
    )
  }

  const selectAll = () => setSelectedPerms(allPerms.map(p => p.name))
  const clearAll  = () => setSelectedPerms([])

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = { ...data, permissions: selectedPerms }
      if (isEdit) {
        await api.put(`/superadmin/roles/${modal.role.id}`, payload)
      } else {
        await api.post('/superadmin/roles', payload)
      }
      closeModal()
      fetchData({ page: meta.current_page || 1 })
    } catch (e) {
      setError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/superadmin/roles/${deleteModal.role.id}`)
      setDeleteModal({ open: false, role: null })
      fetchData({ page: meta.current_page || 1 })
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  const sNoBase = (meta.current_page - 1) * perPage

  return (
    <>
      <div className="report-page">
        <CCard className="report-shell">
          <div className="report-shell__header">
            <div>
              <h4 className="report-shell__title">Roles</h4>
            </div>
            <PermissionGate permission="role.create">
              <CButton size="sm" className="report-shell__export" onClick={openCreate}>
                <CIcon icon={cilPlus} className="me-2" />Add Role
              </CButton>
            </PermissionGate>
          </div>

          <div className="report-shell__filters">
            <div className="filter-field filter-field--customer">
              <CFormLabel className="filter-label">Search</CFormLabel>
              <CFormInput
                size="sm"
                className="filter-input"
                placeholder="Role name"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="filter-field filter-field--perpage">
              <PerPageSelector
                value={perPage}
                onChange={handlePerPageChangeWrapper}
                label="Per Page"
                disabled={loading}
              />
            </div>

            <div className="filter-field filter-field--buttons">
              <CButton
                size="sm"
                className="filter-btn filter-btn--ghost"
                onClick={handleClear}
                disabled={loading}
              >
                Clear
              </CButton>
            </div>
          </div>

          {error && (
            <div className="report-shell__error">
              <CAlert color="danger" dismissible onClose={() => setError(null)}>
                {error}
              </CAlert>
            </div>
          )}

          <CCardBody className="p-0">
            {loading ? (
              <div className="report-shell__loading">
                <CSpinner />
                <div className="report-shell__loading-text">Loading roles...</div>
              </div>
            ) : (
              <>
                <CTable hover responsive bordered className="admin-data-table">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Sr. No</CTableHeaderCell>
                      <SortableHeader colKey="name">Role</SortableHeader>
                      <CTableHeaderCell>Permissions</CTableHeaderCell>
                      <SortableHeader colKey="users_count">Users</SortableHeader>
                      <CTableHeaderCell>Actions</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {!error && roles.length === 0 ? (
                      <CTableRow>
                        <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                          No roles found.
                        </CTableDataCell>
                      </CTableRow>
                    ) : (
                      roles.map((role, i) => (
                        <CTableRow key={role.id}>
                          <CTableDataCell>{sNoBase + i + 1}</CTableDataCell>
                          <CTableDataCell>
                            <CBadge color={roleBadgeColor(role.name)} className="text-capitalize px-2 py-1">
                              {role.name}
                            </CBadge>
                          </CTableDataCell>
                          <CTableDataCell>
                            <div className="d-flex flex-wrap gap-1">
                              {role.permissions?.slice(0, 6).map(p => (
                                <CBadge key={p.name} color="light" textColor="dark" className="border small">
                                  {p.name}
                                </CBadge>
                              ))}
                              {role.permissions?.length > 6 && (
                                <CBadge color="secondary">+{role.permissions.length - 6} more</CBadge>
                              )}
                            </div>
                          </CTableDataCell>
                          <CTableDataCell>{role.users_count ?? 0}</CTableDataCell>
                          <CTableDataCell>
                            <div className="admin-action-stack">
                              <PermissionGate permission="role.edit">
                                <CButton
                                  size="sm" color="warning" variant="outline"
                                  onClick={() => openEdit(role)}
                                  disabled={role.name === 'superadmin'}
                                >
                                  <CIcon icon={cilPencil} />
                                </CButton>
                              </PermissionGate>
                              <PermissionGate permission="role.delete">
                                <CButton
                                  size="sm" color="danger" variant="outline"
                                  onClick={() => setDeleteModal({ open: true, role })}
                                  disabled={role.name === 'superadmin' || (role.users_count ?? 0) > 0}
                                >
                                  <CIcon icon={cilTrash} />
                                </CButton>
                              </PermissionGate>
                            </div>
                          </CTableDataCell>
                        </CTableRow>
                      ))
                    )}
                  </CTableBody>
                </CTable>

                <Pagination
                  meta={meta}
                  onPageChange={handlePageChange}
                  loading={pageLoading}
                  variant="bold"
                  showPageJumper={true}
                  showRecordInfo={true}
                />
              </>
            )}
          </CCardBody>
        </CCard>
      </div>

      <CModal size="xl" visible={modal.open} onClose={closeModal} backdrop="static">
        <CModalHeader>
          <CModalTitle>{isEdit ? `Edit Role: ${modal.role?.name}` : 'Add Role'}</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody style={{ maxHeight: '70vh', overflowY: 'auto' }}>

            <div className="mb-4">
              <CFormLabel className="fw-semibold">
                Role Name <span className="text-muted small fw-normal">(lowercase, underscores only)</span>
              </CFormLabel>
              <CFormInput
                placeholder="e.g. warehouse_manager"
                invalid={!!errors.name}
                disabled={isEdit && modal.role?.name === 'superadmin'}
                style={{ maxWidth: 300 }}
                {...register('name')}
              />
              {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
            </div>

            {/* ── Permissions Section Header ── */}
            <div className="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
              <div>
                <h6 className="fw-bold text-dark mb-1" style={{ letterSpacing: '0.02em' }}>
                  Permissions
                </h6>
                <span className="text-muted small">
                  {selectedPerms.length} of {allPerms.length} permission(s) selected
                </span>
              </div>
              <div className="d-flex gap-2">
                <CButton size="sm" color="primary"   variant="outline" onClick={selectAll}>Select All</CButton>
                <CButton size="sm" color="secondary" variant="outline" onClick={clearAll}>Clear All</CButton>
              </div>
            </div>

            <div className="d-flex flex-column gap-3">
              {permTree.map(group => {
                const allGroupPerms = group.children.flatMap(c => c.permissions.map(p => p.name))
                const allOn  = allGroupPerms.length > 0 && allGroupPerms.every(n => selectedPerms.includes(n))
                const anyOn  = allGroupPerms.some(n => selectedPerms.includes(n))

                return (
                  <CCard
                    key={group.menuName}
                    className={`glass-card border admin-page-card ${anyOn ? 'border-primary' : ''}`}
                  >
                    <CCardHeader
                      className={`py-2 d-flex align-items-center gap-2 border-bottom ${anyOn ? 'bg-primary bg-opacity-10' : 'bg-light'}`}
                    >
                      <input
                        type="checkbox"
                        id={`menu-${group.menuName}`}
                        checked={allOn}
                        ref={el => { if (el) el.indeterminate = anyOn && !allOn }}
                        onChange={() => toggleMenu(group)}
                        className="form-check-input mb-0"
                      />
                      <label
                        htmlFor={`menu-${group.menuName}`}
                        className="fw-bold text-dark text-uppercase small mb-0"
                        style={{ cursor: 'pointer', letterSpacing: '0.06em' }}
                      >
                        {group.menuName}
                      </label>
                      <span className="ms-auto">
                        {allOn
                          ? <CBadge color="success">All</CBadge>
                          : anyOn
                          ? <CBadge color="primary">Partial</CBadge>
                          : <CBadge color="light" textColor="dark" className="border">None</CBadge>}
                      </span>
                    </CCardHeader>

                    <CCardBody className="py-2 px-3">
                      <div className="d-flex flex-column">
                        {group.children.map((sub, idx) => {
                          const subNames = sub.permissions.map(p => p.name)
                          const subAllOn = subNames.every(n => selectedPerms.includes(n))
                          const subAnyOn = subNames.some(n => selectedPerms.includes(n))

                          return (
                            <div
                              key={sub.label}
                              className={`d-flex align-items-center gap-3 py-2 ${idx !== group.children.length - 1 ? 'border-bottom' : ''}`}
                            >
                              {/* Submenu name + select-all for this row */}
                              <div style={{ minWidth: 160 }} className="d-flex align-items-center gap-2">
                                <CFormCheck
                                  id={`sub-${sub.module}`}
                                  checked={subAllOn}
                                  onChange={() => toggleGroup(sub.permissions)}
                                  className="mb-0"
                                />
                                <label
                                  htmlFor={`sub-${sub.module}`}
                                  className={`small mb-0 fw-semibold ${subAnyOn ? 'text-primary' : 'text-dark'}`}
                                  style={{ cursor: 'pointer' }}
                                >
                                  {sub.label}
                                </label>
                              </div>

                              {/* Action chips */}
                              <div className="d-flex flex-wrap gap-2">
                                {sub.permissions.map(perm => {
                                  const action  = perm.name.split('.')[1]
                                  const checked = selectedPerms.includes(perm.name)
                                  return (
                                    <div
                                      key={perm.name}
                                      onClick={() => togglePerm(perm.name)}
                                      className="d-flex align-items-center gap-1 px-2 py-1 rounded border small fw-medium"
                                      style={{
                                        cursor:      'pointer',
                                        background:  checked ? '#0d6efd15' : '#fff',
                                        borderColor: checked ? '#0d6efd'   : '#cbd5e1',
                                        color:       checked ? '#0d6efd'   : '#475569',
                                        userSelect:  'none',
                                        transition:  'all 0.15s',
                                      }}
                                    >
                                      <CFormCheck
                                        checked={checked}
                                        onChange={() => togglePerm(perm.name)}
                                        onClick={e => e.stopPropagation()}
                                        className="mb-0"
                                        style={{ pointerEvents: 'none' }}
                                      />
                                      {actionLabel(action)}
                                    </div>
                                  )
                                })}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </CCardBody>
                  </CCard>
                )
              })}
            </div>

          </CModalBody>
          <CModalFooter>
            <span className="text-muted small me-auto">{selectedPerms.length} permission(s) selected</span>
            <CButton color="secondary" onClick={closeModal} disabled={submitting}>Cancel</CButton>
            <CButton type="submit" color="primary" disabled={submitting}>
              {submitting && <CSpinner size="sm" className="me-2" />}
              {isEdit ? 'Update Role' : 'Create Role'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      <CModal visible={deleteModal.open} onClose={() => setDeleteModal({ open: false, role: null })}>
        <CModalHeader><CModalTitle>Confirm Delete</CModalTitle></CModalHeader>
        <CModalBody>
          Delete role <strong className="text-capitalize">{deleteModal.role?.name}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setDeleteModal({ open: false, role: null })}>Cancel</CButton>
          <CButton color="danger" onClick={handleDelete}>Delete</CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default Roles