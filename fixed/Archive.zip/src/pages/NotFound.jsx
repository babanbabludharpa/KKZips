import { CButton, CCol, CContainer, CRow } from '@coreui/react'
import { useNavigate } from 'react-router-dom'

const NotFound = () => {
  const navigate = useNavigate()

  return (
    <div className="auth-shell min-vh-100 d-flex flex-row align-items-center">
      <div className="auth-shell__mesh" />
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={6} className="text-center">
            <div className="error-404 glass-panel">404</div>
            <h4 className="mb-3">Page not found</h4>
            <p className="text-body-secondary mb-4">
              The page you're looking for doesn't exist or you don't have permission to access it.
            </p>
            <CButton color="primary" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </CButton>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  )
}

export default NotFound
