import { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CFormSelect, CBreadcrumb, CBreadcrumbItem,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPencil, cilTrash, cilPlus, cilCalendar, cilTag,
  cilImage, cilApps, cilVideo, cilImagePlus,
} from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import VariantMediaSection, {
  IMAGE_LIMIT, VIDEO_LIMIT, IMAGE_TYPES, VIDEO_TYPES, IMAGE_MAX_MB, VIDEO_MAX_MB,
} from './VariantMediaSection'


const schema = yup.object({
  sku:            yup.string().required('SKU / Product Code is required'),
  unit_id:        yup.string().required('Unit is required'),
  hsn_code:       yup.string().nullable().optional(),
  mrp:            yup.number().typeError('MRP must be a number').min(0).required('MRP is required'),
  purchase_price: yup.number().typeError('Must be a number').min(0).nullable().optional(),
  selling_price:  yup.number().typeError('Selling price must be a number').min(0).required('Selling price is required'),
  tax_rate_id:    yup.string().nullable().optional(),
  min_order_qty:  yup.number().typeError('Must be a number').min(1).nullable().optional(),
})

const generateSku = (productName, attributeValues) => {
  const prefix = productName
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 3)
  const parts = attributeValues.map(v =>
    v.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5)
  )
  return [prefix, ...parts].join('-')
}

const cartesian = (arrays) => {
  if (arrays.length === 0) return [[]]
  return arrays.reduce((acc, arr) =>
    acc.flatMap(combo => arr.map(val => [...combo, val])),
    [[]]
  )
}

const ProductVariants = () => {
  const { productId } = useParams()
  const navigate = useNavigate()

  const [product, setProduct]           = useState(null)
  const [units, setUnits]               = useState([])
  const [taxRates, setTaxRates]         = useState([])
  const [attributes, setAttributes]     = useState([])
  const [loading, setLoading]           = useState(true)
  const [error, setError]               = useState(null)
  const [modalError, setModalError]     = useState(null)
  const [modal, setModal]               = useState({ open: false, variant: null })
  const [deleteModal, setDeleteModal]   = useState({ open: false, variant: null })
  const [submitting, setSubmitting]     = useState(false)
  const [selectedAttributeValues, setSelectedAttributeValues] = useState({})
  const [isCouponEligible, setIsCouponEligible] = useState(true)

  // ── Channel flags (single variant) ─────────────────────────────
  const [availableForOrder, setAvailableForOrder]               = useState(true)
  const [availableForSubscription, setAvailableForSubscription] = useState(false)
  // ── ★ NEW: variant media (multi-image + videos) ──────────────
  const [existingMedia, setExistingMedia]         = useState([])   // saved media (edit mode)
  const [stagedFiles, setStagedFiles]             = useState([])   // [{ file, preview, type }] — uploaded on save
  const [removedIds, setRemovedIds]               = useState([])   // saved media marked for deletion
  const [mediaOrderChanged, setMediaOrderChanged] = useState(false)
  const [mediaLoading, setMediaLoading]           = useState(false)
  const [uploadingMedia, setUploadingMedia]       = useState(false)

  const [bulkModal, setBulkModal]           = useState(false)
  const [bulkError, setBulkError]           = useState(null)
  const [bulkSubmitting, setBulkSubmitting] = useState(false)
  const [bulkUnitId, setBulkUnitId]         = useState('')
  const [bulkTaxRateId, setBulkTaxRateId]   = useState('')
  const [bulkHsnCode, setBulkHsnCode]       = useState('')
  const [bulkBaseMrp, setBulkBaseMrp]       = useState('')
  const [bulkBasePurchase, setBulkBasePurchase] = useState('')
  const [bulkBaseSelling, setBulkBaseSelling]   = useState('')
  const [bulkSelectedValues, setBulkSelectedValues] = useState({})
  const [bulkRows, setBulkRows] = useState([])
  const bulkMediaRefs = useRef({})

  // ── Channel flags (bulk) ───────────────────────────────────────
  const [bulkAvailableForOrder, setBulkAvailableForOrder]               = useState(true)
  const [bulkAvailableForSubscription, setBulkAvailableForSubscription] = useState(false)

  const isEdit = !!modal.variant

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      sku: '', unit_id: '', hsn_code: '', mrp: '', purchase_price: '',
      selling_price: '', tax_rate_id: '', min_order_qty: '',
    },
  })

  useEffect(() => {
    fetchProduct()
    fetchUnits()
    fetchTaxRates()
    fetchAttributes()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId])

  const fetchProduct = async () => {
    try {
      setLoading(true)
      const res = await api.get(`/masters/products/${productId}`)
      setProduct(res.data?.data?.product)
    } catch {
      setError('Failed to load product.')
    } finally {
      setLoading(false)
    }
  }

  const fetchUnits = async () => {
    try {
      const res = await api.get('/masters/units', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      setUnits(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchTaxRates = async () => {
    try {
      const res = await api.get('/masters/tax-rates', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      setTaxRates(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchAttributes = async () => {
    try {
      const res = await api.get('/masters/attributes', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      setAttributes(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  // ── ★ NEW: media helpers (component scope — used by modal JSX & openEdit) ──
  const fetchVariantMedia = async (variantId) => {
    try {
      setMediaLoading(true)
      const res = await api.get(`/masters/variants/${variantId}/media`)
      setExistingMedia(res.data?.data?.media ?? [])
    } catch {
      setExistingMedia([])
    } finally {
      setMediaLoading(false)
    }
  }

  const removeExistingMedia = (m) => {
    setRemovedIds(ids => [...ids, m.id])
    setExistingMedia(list => list.filter(x => x.id !== m.id))
  }

  const moveExistingMedia = (m, dir) => {
    setExistingMedia(list => {
      const sameType = list.filter(x => x.type === m.type)
      const idx = sameType.findIndex(x => x.id === m.id)
      const to  = dir === 'left' ? idx - 1 : idx + 1
      if (to < 0 || to >= sameType.length) return list
      const neighbor = sameType[to]
      const a = list.indexOf(m)
      const b = list.indexOf(neighbor)
      const out = [...list]
      const tmp = out[a]
      out[a] = out[b]
      out[b] = tmp
      return out
    })
    setMediaOrderChanged(true)
  }

  const moveStagedMedia = (idx, dir) => {
    setStagedFiles(list => {
      const item = list[idx]
      const sameType = list.filter(x => x.type === item.type)
      const tIdx = sameType.indexOf(item)
      const to  = dir === 'left' ? tIdx - 1 : tIdx + 1
      if (to < 0 || to >= sameType.length) return list
      const neighbor = sameType[to]
      const b = list.indexOf(neighbor)
      const out = [...list]
      const tmp = out[idx]
      out[idx] = out[b]
      out[b] = tmp
      return out
    })
  }

  const buildSelectedFromVariant = (variant) => {
    const map = {}
    ;(variant.attributes ?? []).forEach(a => { map[a.attribute_id] = a.value_id })
    return map
  }

  const openCreate = () => {
    reset({ sku: '', unit_id: '', hsn_code: '', mrp: '', purchase_price: '', selling_price: '', tax_rate_id: '', min_order_qty: '' })
    setSelectedAttributeValues({})
    setIsCouponEligible(true)
    setAvailableForOrder(true)
    setAvailableForSubscription(false)
    setExistingMedia([])
    setStagedFiles([])
    setRemovedIds([])
    setMediaOrderChanged(false)
    setModalError(null)
    setModal({ open: true, variant: null })
  }

  const openEdit = (variant) => {
    reset({
      sku:            variant.sku ?? '',
      unit_id:        String(variant.unit_id ?? ''),
      hsn_code:       variant.hsn_code ?? '',
      mrp:            variant.mrp ?? '',
      purchase_price: variant.purchase_price ?? '',
      selling_price:  variant.selling_price ?? '',
      tax_rate_id:    variant.tax_rate_id ? String(variant.tax_rate_id) : '',
      min_order_qty:  variant.min_order_qty ?? '',
    })
    setSelectedAttributeValues(buildSelectedFromVariant(variant))
    setIsCouponEligible(variant.is_coupon_eligible ?? true)
    setAvailableForOrder(variant.available_for_order ?? true)
    setAvailableForSubscription(variant.available_for_subscription ?? false)
    setExistingMedia([])
    setStagedFiles([])
    setRemovedIds([])
    setMediaOrderChanged(false)
    setModalError(null)
    fetchVariantMedia(variant.id)
    setModal({ open: true, variant })
  }

  const closeModal = () => {
    setModal({ open: false, variant: null })
    setModalError(null)
    setExistingMedia([])
    setStagedFiles([])
    setRemovedIds([])
    setMediaOrderChanged(false)
  }

  const selectAttributeValue = (attributeId, valueId) => {
    setSelectedAttributeValues(prev => ({
      ...prev,
      [attributeId]: prev[attributeId] === valueId ? null : valueId,
    }))
  }

  const onSubmit = async (data) => {
    if (!availableForOrder && !availableForSubscription) {
      setModalError('Variant must be available for at least one of: Order or Subscription.')
      return
    }

    setSubmitting(true)
    try {
      const attributeValueIds = Object.values(selectedAttributeValues).filter(Boolean)
      const payload = {
        ...data,
        tax_rate_id:         data.tax_rate_id || null,
        purchase_price:      data.purchase_price || null,
        min_order_qty:       data.min_order_qty || 1,
        is_coupon_eligible:  isCouponEligible,
        available_for_order: availableForOrder,
        available_for_subscription: availableForSubscription,
        attribute_value_ids: attributeValueIds,
      }

      let variantId
      if (isEdit) {
        await api.put(`/masters/variants/${modal.variant.id}`, payload)
        variantId = modal.variant.id
      } else {
        const res = await api.post(`/masters/products/${productId}/variants`, payload)
        variantId = res.data?.data?.variant?.id
      }
      // ★ NEW — apply media: deletions → uploads (resumable) → image order
      if (variantId) {
        setUploadingMedia(true)
        try {
          for (const id of removedIds) {
            await api.delete(`/masters/variants/${variantId}/media/${id}`).catch(() => {})
          }

          const remaining = [...stagedFiles]
          while (remaining.length > 0) {
            const f = remaining[0]
            const formData = new FormData()
            formData.append('file', f.file)
            formData.append('type', f.type)
            await api.post(`/masters/variants/${variantId}/media`, formData, {
              headers: { 'Content-Type': 'multipart/form-data' },
            })
            remaining.shift()
            setStagedFiles([...remaining])   // tiles vanish as they upload; retry only sends the rest
          }

          if (isEdit && (mediaOrderChanged || removedIds.length > 0)) {
            const imageIds = existingMedia.filter(m => m.type === 'image').map(m => m.id)
            if (imageIds.length > 0) {
              await api.patch(`/masters/variants/${variantId}/media/reorder`, { ids: imageIds })
            }
          }
        } finally {
          setUploadingMedia(false)
        }
      }

      closeModal()
      fetchProduct()
    } catch (e) {
      setUploadingMedia(false)
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/variants/${deleteModal.variant.id}`)
      setDeleteModal({ open: false, variant: null })
      fetchProduct()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (variant) => {
    try {
      await api.patch(`/masters/variants/${variant.id}/toggle`)
      fetchProduct()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const openBulkModal = () => {
    setBulkSelectedValues({})
    setBulkRows([])
    setBulkUnitId('')
    setBulkTaxRateId('')
    setBulkHsnCode('')
    setBulkBaseMrp('')
    setBulkBasePurchase('')
    setBulkBaseSelling('')
    setBulkAvailableForOrder(true)
    setBulkAvailableForSubscription(false)
    setBulkError(null)
    setBulkModal(true)
  }

  const toggleBulkValue = (attributeId, valueId) => {
    setBulkSelectedValues(prev => {
      const current = prev[attributeId] ?? []
      const exists  = current.includes(valueId)
      return {
        ...prev,
        [attributeId]: exists
          ? current.filter(id => id !== valueId)
          : [...current, valueId],
      }
    })
    setBulkRows([])
  }

  const generateCombinations = () => {
    if (!bulkUnitId) { setBulkError('Please select a unit before generating.'); return }
    if (!bulkBaseMrp || !bulkBaseSelling) { setBulkError('Please enter base MRP and selling price.'); return }

    const selectedAxes = attributes
      .map(attr => {
        const selectedIds = bulkSelectedValues[attr.id] ?? []
        const values = (attr.values ?? []).filter(v => selectedIds.includes(v.id) && v.is_active)
        return values.length > 0 ? { attribute: attr, values } : null
      })
      .filter(Boolean)

    if (selectedAxes.length === 0) {
      setBulkError('Select at least one attribute value to generate combinations.')
      return
    }

    const combinations = cartesian(selectedAxes.map(a => a.values))

    const rows = combinations.map(combo => ({
      id:                  Math.random().toString(36).slice(2),
      attribute_value_ids: combo.map(v => v.id),
      attribute_labels:    combo.map(v => ({
        name:  selectedAxes.find(a => a.values.includes(v))?.attribute.name,
        value: v.value,
      })),
      sku:                 generateSku(product?.name ?? 'PRD', combo),
      mrp:                 bulkBaseMrp,
      purchase_price:      bulkBasePurchase,
      selling_price:       bulkBaseSelling,
      is_coupon_eligible:  true,
      mediaFiles: [],
    }))

    bulkMediaRefs.current = {}
    setBulkRows(rows)
    setBulkError(null)
  }

  const updateBulkRow = (id, field, value) => {
    setBulkRows(prev => prev.map(r => r.id === id ? { ...r, [field]: value } : r))
  }

  const removeBulkRow = (id) => {
    setBulkRows(prev => prev.filter(r => r.id !== id))
    delete bulkMediaRefs.current[id]
  }

  const handleBulkMediaChange = (rowId, e) => {
    const picked = [...(e.target.files || [])]
    e.target.value = ''
    if (picked.length === 0) return

    setBulkRows(prev => prev.map(r => {
      if (r.id !== rowId) return r
      const next = [...(r.mediaFiles ?? [])]
      let images = next.filter(f => f.type === 'image').length
      let videos = next.filter(f => f.type === 'video').length

      for (const file of picked) {
        const isImage = IMAGE_TYPES.includes(file.type)
        const isVideo = VIDEO_TYPES.includes(file.type)
        if (!isImage && !isVideo) continue
        if (isImage && (images >= IMAGE_LIMIT || file.size > IMAGE_MAX_MB * 1024 * 1024)) continue
        if (isVideo && (videos >= VIDEO_LIMIT || file.size > VIDEO_MAX_MB * 1024 * 1024)) continue
        next.push({ file, type: isImage ? 'image' : 'video', preview: URL.createObjectURL(file) })
        if (isImage) images += 1
        else videos += 1
      }
      return { ...r, mediaFiles: next }
    }))
  }

  const removeBulkMedia = (rowId, index) => {
    setBulkRows(prev => prev.map(r => r.id === rowId
      ? { ...r, mediaFiles: (r.mediaFiles ?? []).filter((_, i) => i !== index) }
      : r))
  }

  const submitBulk = async () => {
    if (bulkRows.length === 0) { setBulkError('No combinations to save.'); return }
    if (!bulkAvailableForOrder && !bulkAvailableForSubscription) {
      setBulkError('Select at least one channel (Order / Subscription) before saving.')
      return
    }

    setBulkSubmitting(true)
    setBulkError(null)
    try {
      const res = await api.post(`/masters/products/${productId}/variants/bulk`, {
        variants: bulkRows.map(r => ({
          sku:                 r.sku,
          unit_id:             bulkUnitId,
          hsn_code:            bulkHsnCode || null,
          mrp:                 r.mrp,
          purchase_price:      r.purchase_price || null,
          selling_price:       r.selling_price,
          tax_rate_id:         bulkTaxRateId || null,
          min_order_qty:       1,
          is_active:           true,
          is_coupon_eligible:  r.is_coupon_eligible,
          available_for_order:        bulkAvailableForOrder,
          available_for_subscription: bulkAvailableForSubscription,
          attribute_value_ids: r.attribute_value_ids,
        })),
      })

      const createdVariants = res.data?.data?.variants ?? []

      // ★ NEW — upload each generated variant's staged media (images + videos)
      for (let i = 0; i < bulkRows.length; i++) {
        const variant = createdVariants[i]
        if (!variant?.id) continue
        for (const f of bulkRows[i].mediaFiles ?? []) {
          const formData = new FormData()
          formData.append('file', f.file)
          formData.append('type', f.type)
          await api.post(`/masters/variants/${variant.id}/media`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          }).catch(() => { /* keep uploading the rest */ })
        }
      }

      setBulkModal(false)
      fetchProduct()
    } catch (e) {
      setBulkError(e.response?.data?.message ?? 'Bulk create failed.')
    } finally {
      setBulkSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading variants...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  return (
    <div className="report-page">
      <CBreadcrumb className="mb-2">
        <CBreadcrumbItem>
          <Link to="/masters/products">Products</Link>
        </CBreadcrumbItem>
        <CBreadcrumbItem active>{product?.name ?? 'Variants'}</CBreadcrumbItem>
      </CBreadcrumb>

      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">
            {product?.name} — Variants
          </h4>
          <div className="d-flex gap-2">
            <PermissionGate permission="product.create">
              <CButton
                size="sm"
                className="filter-btn filter-btn--ghost"
                onClick={openBulkModal}
              >
                <CIcon icon={cilApps} className="me-2" />
                Bulk Add
              </CButton>
              <CButton
                size="sm"
                className="report-shell__export"
                onClick={openCreate}
              >
                <CIcon icon={cilPlus} className="me-2" />
                Add Variant
              </CButton>
            </PermissionGate>
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          <CTable hover responsive bordered className="admin-data-table">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Image</CTableHeaderCell>
                <CTableHeaderCell>SKU</CTableHeaderCell>
                <CTableHeaderCell>Attributes</CTableHeaderCell>
                <CTableHeaderCell>Unit</CTableHeaderCell>
                <CTableHeaderCell>MRP</CTableHeaderCell>
                <CTableHeaderCell>Selling Price</CTableHeaderCell>
                <CTableHeaderCell>Final Price</CTableHeaderCell>
                <CTableHeaderCell>Tax</CTableHeaderCell>
                <CTableHeaderCell>Coupon</CTableHeaderCell>
                <CTableHeaderCell>Channels</CTableHeaderCell>
                <CTableHeaderCell>Status</CTableHeaderCell>
                <CTableHeaderCell>Actions</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {!product?.variants || product.variants.length === 0 ? (
                <CTableRow>
                  <CTableDataCell colSpan={12} className="text-center text-muted py-4">
                    No variants yet. Add the first one to make this product sellable.
                  </CTableDataCell>
                </CTableRow>
              ) : product.variants.map(variant => (
                <CTableRow key={variant.id}>
                  <CTableDataCell>
                    {variant.image_url ? (
                      <img
                        src={variant.image_url}
                        alt={variant.sku}
                        className="variant-thumb"
                      />
                    ) : (
                      <div className="variant-thumb variant-thumb--empty">
                        <CIcon icon={cilImage} style={{ color: '#aaa' }} />
                      </div>
                    )}
                  </CTableDataCell>
                  <CTableDataCell>
                    <CBadge color="primary" shape="rounded-pill">{variant.sku}</CBadge>
                  </CTableDataCell>
                  <CTableDataCell>
                    {variant.attributes?.length > 0 ? (
                      <div className="d-flex flex-wrap gap-1 justify-content-center">
                        {variant.attributes.map(a => (
                          <CBadge key={a.value_id} color="info" shape="rounded-pill">
                            {a.attribute_name}: {a.value}
                          </CBadge>
                        ))}
                      </div>
                    ) : '—'}
                  </CTableDataCell>
                  <CTableDataCell>{variant.unit_abbreviation ?? '—'}</CTableDataCell>
                  <CTableDataCell>₹{variant.mrp}</CTableDataCell>
                  <CTableDataCell>₹{variant.selling_price}</CTableDataCell>
                  <CTableDataCell>
                    <div className="d-flex flex-column align-items-center gap-1">
                      {variant.is_discount_active ? (
                        <>
                          <CBadge color="success" shape="rounded-pill">₹{variant.final_price}</CBadge>
                          <CBadge color="warning" shape="rounded-pill">
                            {variant.active_discount_percent}% off
                          </CBadge>
                        </>
                      ) : (
                        <span className="text-muted">₹{variant.final_price}</span>
                      )}
                    </div>
                  </CTableDataCell>
                  <CTableDataCell>{variant.tax_label ?? '—'}</CTableDataCell>
                  <CTableDataCell>
                    <CBadge
                      color={variant.is_coupon_eligible ? 'success' : 'secondary'}
                      shape="rounded-pill"
                    >
                      {variant.is_coupon_eligible ? 'Yes' : 'No'}
                    </CBadge>
                  </CTableDataCell>

                  {/* ── Channels column ──────────────────────────── */}
                  <CTableDataCell>
                    <div className="d-flex gap-1 justify-content-center flex-wrap">
                      {variant.available_for_order && (
                        <CBadge color="primary" shape="rounded-pill">Order</CBadge>
                      )}
                      {variant.available_for_subscription && (
                        <CBadge color="success" shape="rounded-pill">Sub</CBadge>
                      )}
                      {!variant.available_for_order && !variant.available_for_subscription && (
                        <CBadge color="secondary" shape="rounded-pill">None</CBadge>
                      )}
                    </div>
                  </CTableDataCell>

                  <CTableDataCell>
                    <CBadge
                      color={variant.is_active ? 'success' : 'secondary'}
                      shape="rounded-pill"
                      style={{ cursor: 'pointer' }}
                      onClick={() => toggleActive(variant)}
                    >
                      {variant.is_active ? 'Active' : 'Inactive'}
                    </CBadge>
                  </CTableDataCell>
                  <CTableDataCell>
                    <div className="d-flex gap-1 justify-content-center">
                      <CButton
                        size="sm"
                        className="table-action-btn"
                        onClick={() => navigate(`/masters/products/${productId}/variants/${variant.id}/schedules`)}
                        title="Price & discount schedules"
                      >
                        <CIcon icon={cilCalendar} />
                      </CButton>
                      <PermissionGate permission="product.edit">
                        <CButton
                          size="sm"
                          className="table-action-btn"
                          onClick={() => openEdit(variant)}
                          title="Edit"
                        >
                          <CIcon icon={cilPencil} />
                        </CButton>
                      </PermissionGate>
                      <PermissionGate permission="product.delete">
                        <CButton
                          size="sm"
                          className="table-action-btn"
                          onClick={() => setDeleteModal({ open: true, variant })}
                          title="Delete"
                        >
                          <CIcon icon={cilTrash} />
                        </CButton>
                      </PermissionGate>
                    </div>
                  </CTableDataCell>
                </CTableRow>
              ))}
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>

      {/* ==================== SINGLE VARIANT MODAL ==================== */}
      <CModal size="lg" visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Variant' : 'Add Variant'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  SKU / Product Code <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  invalid={!!errors.sku}
                  {...register('sku')}
                  placeholder="Your own code"
                />
                {errors.sku && <div className="text-danger small mt-1">{errors.sku.message}</div>}
              </div>

              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Unit <span className="text-danger">*</span>
                </CFormLabel>
                <CFormSelect
                  className="filter-input"
                  invalid={!!errors.unit_id}
                  {...register('unit_id')}
                >
                  <option value="">Select Unit</option>
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.name} ({u.abbreviation})</option>
                  ))}
                </CFormSelect>
                {errors.unit_id && <div className="text-danger small mt-1">{errors.unit_id.message}</div>}
              </div>

              <div className="col-md-6">
                <CFormLabel className="filter-label">HSN Code</CFormLabel>
                <CFormInput className="filter-input" {...register('hsn_code')} />
              </div>

              <div className="col-md-6">
                <CFormLabel className="filter-label">Tax Rate</CFormLabel>
                <CFormSelect className="filter-input" {...register('tax_rate_id')}>
                  <option value="">No Tax</option>
                  {taxRates.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                </CFormSelect>
              </div>

              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  MRP <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.mrp}
                  {...register('mrp')}
                />
                {errors.mrp && <div className="text-danger small mt-1">{errors.mrp.message}</div>}
              </div>

              <div className="col-md-4">
                <CFormLabel className="filter-label">Purchase Price</CFormLabel>
                <CFormInput className="filter-input" type="number" step="0.01" {...register('purchase_price')} />
              </div>

              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  Selling Price <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.selling_price}
                  {...register('selling_price')}
                />
                {errors.selling_price && (
                  <div className="text-danger small mt-1">{errors.selling_price.message}</div>
                )}
              </div>

              <div className="col-md-4">
                <CFormLabel className="filter-label">Min Order Qty</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  {...register('min_order_qty')}
                  placeholder="1"
                />
              </div>

              <div className="col-md-8 d-flex align-items-end">
                <div className="d-flex align-items-center gap-2">
                  <input
                    type="checkbox"
                    id="is_coupon_eligible"
                    checked={isCouponEligible}
                    onChange={e => setIsCouponEligible(e.target.checked)}
                  />
                  <label
                    htmlFor="is_coupon_eligible"
                    style={{ cursor: 'pointer', marginBottom: 0 }}
                  >
                    Eligible for coupon discounts
                  </label>
                </div>
              </div>

              {/* ── Channel availability ─────────────────────────── */}
              <div className="col-12">
                <CFormLabel className="filter-label">Available For</CFormLabel>
                <div className="d-flex flex-wrap gap-4">
                  <div className="d-flex align-items-center gap-2">
                    <input
                      type="checkbox"
                      id="available_for_order"
                      checked={availableForOrder}
                      onChange={e => setAvailableForOrder(e.target.checked)}
                    />
                    <label htmlFor="available_for_order" style={{ cursor: 'pointer', marginBottom: 0 }}>
                      Order
                    </label>
                  </div>
                  <div className="d-flex align-items-center gap-2">
                    <input
                      type="checkbox"
                      id="available_for_subscription"
                      checked={availableForSubscription}
                      onChange={e => setAvailableForSubscription(e.target.checked)}
                    />
                    <label htmlFor="available_for_subscription" style={{ cursor: 'pointer', marginBottom: 0 }}>
                      Subscription
                    </label>
                  </div>
                </div>
                {!availableForOrder && !availableForSubscription && (
                  <div className="text-danger small mt-1">
                    Select at least one channel.
                  </div>
                )}
              </div>

              {/* ── ★ NEW: multi-image + videos ── */}
              <div className="col-12">
                <VariantMediaSection
                  existing={existingMedia}
                  staged={stagedFiles}
                  loading={mediaLoading}
                  disabled={submitting || uploadingMedia}
                  onPick={(files) => setStagedFiles(list => [...list, ...files])}
                  onRemoveExisting={removeExistingMedia}
                  onRemoveStaged={(idx) => setStagedFiles(list => list.filter((_, i) => i !== idx))}
                  onMoveExisting={moveExistingMedia}
                  onMoveStaged={moveStagedMedia}
                />
              </div>

              {attributes.length > 0 && (
                <div className="col-12">
                  <CFormLabel className="filter-label">
                    <CIcon icon={cilTag} className="me-1" />
                    Attributes{' '}
                    <small className="text-muted ms-1">
                      (select one value per attribute)
                    </small>
                  </CFormLabel>
                  {attributes.map(attr => (
                    <div key={attr.id} className="mb-3">
                      <div className="small fw-semibold mb-1">{attr.name}</div>
                      <div className="d-flex flex-wrap gap-2">
                        {(attr.values ?? []).filter(v => v.is_active).map(val => {
                          const isSelected = selectedAttributeValues[attr.id] === val.id
                          return (
                            <button
                              key={val.id}
                              type="button"
                              className={
                                isSelected
                                  ? 'filter-btn filter-btn--primary filter-btn--pill'
                                  : 'filter-btn filter-btn--ghost filter-btn--pill'
                              }
                              onClick={() => selectAttributeValue(attr.id, val.id)}
                            >
                              {val.value}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting || uploadingMedia}
            >
              {(submitting || uploadingMedia) ? <CSpinner size="sm" className="me-2" /> : null}
              {uploadingMedia ? 'Uploading...' : isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== BULK GENERATOR MODAL ==================== */}
      <CModal
        size="xl"
        visible={bulkModal}
        onClose={() => setBulkModal(false)}
        backdrop="static"
        className="wallet-modal"
        scrollable
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Bulk Add Variants</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {bulkError && (
            <CAlert color="danger" dismissible onClose={() => setBulkError(null)}>
              {bulkError}
            </CAlert>
          )}

          <div className="filter-label mb-2">Step 1 — Common fields for all variants</div>
          <div className="row g-2 mb-3">
            <div className="col-md-3">
              <CFormLabel className="filter-label">
                Unit <span className="text-danger">*</span>
              </CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={bulkUnitId}
                onChange={e => { setBulkUnitId(e.target.value); setBulkRows([]) }}
              >
                <option value="">Select Unit</option>
                {units.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.abbreviation})</option>
                ))}
              </CFormSelect>
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">Tax Rate</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={bulkTaxRateId}
                onChange={e => setBulkTaxRateId(e.target.value)}
              >
                <option value="">No Tax</option>
                {taxRates.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
              </CFormSelect>
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">HSN Code</CFormLabel>
              <CFormInput
                size="sm"
                className="filter-input"
                value={bulkHsnCode}
                onChange={e => setBulkHsnCode(e.target.value)}
              />
            </div>
            <div className="col-md-1">
              <CFormLabel className="filter-label">
                MRP <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                size="sm"
                className="filter-input"
                type="number"
                step="0.01"
                value={bulkBaseMrp}
                onChange={e => { setBulkBaseMrp(e.target.value); setBulkRows([]) }}
              />
            </div>
            <div className="col-md-1">
              <CFormLabel className="filter-label">Purchase</CFormLabel>
              <CFormInput
                size="sm"
                className="filter-input"
                type="number"
                step="0.01"
                value={bulkBasePurchase}
                onChange={e => { setBulkBasePurchase(e.target.value); setBulkRows([]) }}
              />
            </div>
            <div className="col-md-1">
              <CFormLabel className="filter-label">
                Selling <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                size="sm"
                className="filter-input"
                type="number"
                step="0.01"
                value={bulkBaseSelling}
                onChange={e => { setBulkBaseSelling(e.target.value); setBulkRows([]) }}
              />
            </div>
          </div>

          {/* ── Channel availability (applies to all) ────────────── */}
          <div className="row g-2 mb-3">
            <div className="col-12">
              <CFormLabel className="filter-label">
                Available For <small className="text-muted">(applies to all generated variants)</small>
              </CFormLabel>
              <div className="d-flex flex-wrap gap-4">
                <div className="d-flex align-items-center gap-2">
                  <input
                    type="checkbox"
                    id="bulk_available_for_order"
                    checked={bulkAvailableForOrder}
                    onChange={e => setBulkAvailableForOrder(e.target.checked)}
                  />
                  <label htmlFor="bulk_available_for_order" style={{ cursor: 'pointer', marginBottom: 0 }}>
                    Order
                  </label>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <input
                    type="checkbox"
                    id="bulk_available_for_subscription"
                    checked={bulkAvailableForSubscription}
                    onChange={e => setBulkAvailableForSubscription(e.target.checked)}
                  />
                  <label htmlFor="bulk_available_for_subscription" style={{ cursor: 'pointer', marginBottom: 0 }}>
                    Subscription
                  </label>
                </div>
              </div>
              {!bulkAvailableForOrder && !bulkAvailableForSubscription && (
                <div className="text-danger small mt-1">
                  Select at least one channel.
                </div>
              )}
            </div>
          </div>

          <div className="filter-label mb-2">Step 2 — Select attribute values to combine</div>
          {attributes.length === 0 ? (
            <div className="text-muted small mb-3">
              No attributes found. Create attributes first.
            </div>
          ) : (
            <div className="mb-3">
              {attributes.map(attr => (
                <div key={attr.id} className="mb-2">
                  <div className="small fw-semibold mb-1">{attr.name}</div>
                  <div className="d-flex flex-wrap gap-2">
                    {(attr.values ?? []).filter(v => v.is_active).map(val => {
                      const isSelected = (bulkSelectedValues[attr.id] ?? []).includes(val.id)
                      return (
                        <button
                          key={val.id}
                          type="button"
                          className={
                            isSelected
                              ? 'filter-btn filter-btn--primary filter-btn--pill'
                              : 'filter-btn filter-btn--ghost filter-btn--pill'
                          }
                          onClick={() => toggleBulkValue(attr.id, val.id)}
                        >
                          {val.value}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
              <CButton
                size="sm"
                className="filter-btn filter-btn--primary mt-2"
                onClick={generateCombinations}
              >
                <CIcon icon={cilApps} className="me-1" />
                Generate Combinations
              </CButton>
            </div>
          )}

          {bulkRows.length > 0 && (
            <>
              <div className="filter-label mb-2">
                Step 3 — Review & edit before saving ({bulkRows.length} variants)
              </div>
              <div className="report-frame report-frame--scroll">
                <CTable bordered size="sm" className="admin-data-table admin-data-table--preview mb-0">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Combination</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-sku">SKU (editable)</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-price">MRP</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-price">Purchase</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-price">Selling</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-coupon">Coupon</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-image">Image</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-action"></CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {bulkRows.map(row => (
                      <CTableRow key={row.id}>
                        <CTableDataCell className="p-1">
                          <div className="d-flex flex-wrap gap-1 justify-content-center">
                            {row.attribute_labels.map((a, i) => (
                              <CBadge key={i} color="info" shape="rounded-pill">
                                {a.name}: {a.value}
                              </CBadge>
                            ))}
                          </div>
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormInput
                            size="sm"
                            className="filter-input"
                            value={row.sku}
                            onChange={e => updateBulkRow(row.id, 'sku', e.target.value)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormInput
                            size="sm"
                            className="filter-input"
                            type="number"
                            step="0.01"
                            value={row.mrp}
                            onChange={e => updateBulkRow(row.id, 'mrp', e.target.value)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormInput
                            size="sm"
                            className="filter-input"
                            type="number"
                            step="0.01"
                            value={row.purchase_price}
                            onChange={e => updateBulkRow(row.id, 'purchase_price', e.target.value)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormInput
                            size="sm"
                            className="filter-input"
                            type="number"
                            step="0.01"
                            value={row.selling_price}
                            onChange={e => updateBulkRow(row.id, 'selling_price', e.target.value)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1 text-center">
                          <input
                            type="checkbox"
                            checked={row.is_coupon_eligible}
                            onChange={e => updateBulkRow(row.id, 'is_coupon_eligible', e.target.checked)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1 text-center">
                          <input
                            type="file"
                            multiple
                            accept={[...IMAGE_TYPES, ...VIDEO_TYPES].join(',')}
                            style={{ display: 'none' }}
                            ref={el => { if (el) bulkMediaRefs.current[row.id] = el }}
                            onChange={e => handleBulkMediaChange(row.id, e)}
                          />
                          <div
                            className="d-flex flex-wrap gap-1 justify-content-center"
                            style={{ maxWidth: 170, margin: '0 auto', cursor: 'pointer' }}
                            onClick={() => bulkMediaRefs.current[row.id]?.click()}
                          >
                            {(row.mediaFiles ?? []).map((f, fi) => (
                              <span key={fi} title={`${f.file.name} (${f.type})`}
                                style={{
                                  position: 'relative', width: 34, height: 34, borderRadius: 6,
                                  overflow: 'visible', flexShrink: 0,
                                }}
                              >
                                <span style={{
                                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                                  width: 34, height: 34, borderRadius: 6, overflow: 'hidden',
                                  border: '1px solid #E2E8F0',
                                  background: f.type === 'video' ? '#0F172A' : '#F8FAFC',
                                }}>
                                  {f.type === 'image'
                                    ? <img src={f.preview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                    : <CIcon icon={cilVideo} style={{ color: '#fff' }} />}
                                </span>
                                <span
                                  onClick={(e) => { e.stopPropagation(); removeBulkMedia(row.id, fi) }}
                                  title="Remove"
                                  style={{
                                    position: 'absolute', top: -6, right: -6, width: 16, height: 16,
                                    borderRadius: '50%', background: '#DC2626', color: '#fff',
                                    fontSize: '0.65rem', lineHeight: '16px', textAlign: 'center',
                                    cursor: 'pointer', fontWeight: 700,
                                  }}
                                >×</span>
                              </span>
                            ))}
                            <span style={{
                              width: 34, height: 34, borderRadius: 6, border: '1px dashed #94A3B8',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              color: '#94A3B8', flexShrink: 0,
                            }}>
                              <CIcon icon={cilImagePlus} />
                            </span>
                          </div>
                        </CTableDataCell>
                        <CTableDataCell className="p-1 text-center">
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => removeBulkRow(row.id)}
                            title="Remove"
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              </div>
              <div className="text-muted small mt-2">
                SKUs are auto-generated — edit any before saving. All variants
                share the same unit, tax rate, HSN code, and channel availability.
              </div>
            </>
          )}
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setBulkModal(false)}
            disabled={bulkSubmitting}
          >
            Cancel
          </CButton>
          {bulkRows.length > 0 && (
            <CButton
              className="filter-btn filter-btn--primary"
              onClick={submitBulk}
              disabled={bulkSubmitting}
            >
              {bulkSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
              Save {bulkRows.length} Variants
            </CButton>
          )}
        </CModalFooter>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, variant: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete variant{' '}
          <strong>{deleteModal.variant?.sku}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, variant: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default ProductVariants
