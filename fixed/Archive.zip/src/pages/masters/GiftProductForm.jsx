import { useEffect, useState } from 'react'
import {
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CButton, CForm, CFormLabel, CFormInput, CFormSelect, CFormTextarea,
  CAlert, CSpinner,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilImagePlus, cilGift, cilX } from '@coreui/icons'
import api from '../../api/api'

// ─────────────────────────────────────────────────────────────────────────
// ★ FREE GIFTS — Gift product create/edit modal.
//
// Gift products are special variants: selling price is locked at ₹0,
// both channel flags OFF, invisible in the customer catalog. They are
// granted ONLY through a gift campaign (GiftService), and their stock
// is inwarded through the normal Stock Inward flow.
//
// Endpoints (Masters GiftController):
//   POST /masters/gifts/products              (multipart create)
//   POST /masters/gifts/products/{id}         (multipart update, _method=PUT spoof)
// ─────────────────────────────────────────────────────────────────────────

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp']
const IMAGE_MAX_MB = 2

// ── Self-contained responsive modal chrome ──────────────────────────
// Guarantees the header AND footer (Create / Cancel) are always visible:
// dialog capped at 90vh, only the body scrolls, footer is pinned below it,
// and on phones (<768px) the modal goes edge-to-edge fullscreen.
// No dependency on portal CSS (wallet-modal etc.) — injected once.
const MODAL_CSS = `
.gifts-modal .modal-dialog{max-width:min(880px,94vw) !important;width:94vw !important;margin:3vh auto !important;}
.gifts-modal--wide .modal-dialog{max-width:min(1140px,96vw) !important;width:96vw !important;}
.gifts-modal .modal-content{max-height:90vh !important;display:flex !important;flex-direction:column !important;overflow:hidden !important;}
.gifts-modal .modal-header,.gifts-modal .modal-footer{flex:0 0 auto !important;}
.gifts-modal .modal-body{flex:1 1 auto !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}
.gifts-modal .modal-footer{border-top:1px solid rgba(0,0,0,.08);flex-wrap:wrap;gap:.5rem;}
.gifts-modal .modal-footer .btn{min-width:130px;}
.gifts-modal .gifts-modal__title{font-size:1rem;font-weight:600;}
@media (max-width:767.98px){
  .gifts-modal .modal-dialog,.gifts-modal--wide .modal-dialog{max-width:100vw !important;width:100vw !important;margin:0 !important;}
  .gifts-modal .modal-content{max-height:100vh !important;min-height:100vh;border-radius:0 !important;}
}
`

const injectModalCss = () => {
  if (!document.getElementById('gifts-modal-style')) {
    const el = document.createElement('style')
    el.id = 'gifts-modal-style'
    el.textContent = MODAL_CSS
    document.head.appendChild(el)
  }
}

const EMPTY_FORM = {
  name: '',
  description: '',
  category_id: '',
  sku: '',
  unit_id: '',
  hsn_code: '',
  mrp: '',
  purchase_price: '',
  tax_rate_id: '',
}

const GiftProductForm = ({ open, product = null, onClose, onSaved }) => {
  const isEdit = !!product

  const [form, setForm]       = useState(EMPTY_FORM)
  const [units, setUnits]     = useState([])
  const [taxRates, setTaxRates] = useState([])
  const [categories, setCategories] = useState([])
  const [imageFile, setImageFile]   = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState({})
  const [alert, setAlert]   = useState(null)

  // Inject the responsive modal CSS once (idempotent, app-wide).
  useEffect(() => { injectModalCss() }, [])

  // ── Load & reset ──────────────────────────────────────────────────
  useEffect(() => {
    if (!open) return

    setErrors({})
    setAlert(null)
    setImageFile(null)
    setImagePreview(null)

    if (product) {
      setForm({
        name: product.name ?? '',
        description: product.description ?? '',
        category_id: '',
        sku: product.sku ?? '',
        unit_id: product.unit_id ?? '',
        hsn_code: product.hsn_code ?? '',
        mrp: product.mrp !== null && product.mrp !== undefined ? String(product.mrp) : '',
        purchase_price: product.purchase_price !== null && product.purchase_price !== undefined ? String(product.purchase_price) : '',
        // API returns the label only — preselect by matching it after load.
        tax_rate_id: '',
      })
      setImagePreview(product.image_url ?? null)
    } else {
      setForm(EMPTY_FORM)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, product])

  useEffect(() => {
    if (!open) return
    fetchUnits()
    fetchTaxRates()
    fetchCategories()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const fetchUnits = async () => {
    try {
      const res = await api.get('/masters/units', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      setUnits(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const fetchTaxRates = async () => {
    try {
      const res = await api.get('/masters/tax-rates', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      const list = Array.isArray(d) ? d : (d?.data ?? [])
      setTaxRates(list)
      // Preselect the tax rate by label (edit mode).
      if (product?.tax_label) {
        const match = list.find(t => t.label === product.tax_label)
        if (match) setForm(prev => ({ ...prev, tax_rate_id: String(match.id) }))
      }
    } catch { /* silent */ }
  }

  const fetchCategories = async () => {
    try {
      const res = await api.get('/masters/categories', { params: { per_page: 200, is_active: true } })
      const d = res.data?.data
      setCategories(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  // ── Handlers ──────────────────────────────────────────────────────
  const setField = (key, value) => setForm(prev => ({ ...prev, [key]: value }))

  const onImageChange = (e) => {
    const file = e.target.files?.[0] ?? null
    setErrors(prev => ({ ...prev, image: undefined }))

    if (!file) {
      setImageFile(null)
      setImagePreview(product?.image_url ?? null)
      return
    }
    if (!IMAGE_TYPES.includes(file.type)) {
      setErrors(prev => ({ ...prev, image: 'Image must be JPG, PNG or WebP.' }))
      e.target.value = ''
      return
    }
    if (file.size > IMAGE_MAX_MB * 1024 * 1024) {
      setErrors(prev => ({ ...prev, image: `Image must be under ${IMAGE_MAX_MB} MB.` }))
      e.target.value = ''
      return
    }
    if (imagePreview?.startsWith('blob:')) URL.revokeObjectURL(imagePreview)
    setImageFile(file)
    setImagePreview(URL.createObjectURL(file))
  }

  const clearImage = () => {
    if (imagePreview?.startsWith('blob:')) URL.revokeObjectURL(imagePreview)
    setImageFile(null)
    setImagePreview(product?.image_url ?? null) // back to the saved image (if any)
  }

  const closeModal = () => {
    if (submitting) return
    if (imagePreview?.startsWith('blob:')) URL.revokeObjectURL(imagePreview)
    onClose()
  }

  const validate = () => {
    const e = {}
    if (!form.name.trim()) e.name = 'Name is required.'
    if (!form.sku.trim()) e.sku = 'SKU is required.'
    if (!form.unit_id) e.unit_id = 'Unit is required.'
    if (form.mrp === '' || isNaN(Number(form.mrp)) || Number(form.mrp) < 0) {
      e.mrp = 'Enter a valid MRP (0 or more).'
    }
    if (form.purchase_price !== '' && (isNaN(Number(form.purchase_price)) || Number(form.purchase_price) < 0)) {
      e.purchase_price = 'Enter a valid cost per unit.'
    }
    return e
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    if (submitting) return

    const errs = validate()
    if (Object.keys(errs).length) {
      setErrors(errs)
      return
    }

    const fd = new FormData()
    fd.append('name', form.name.trim())
    fd.append('description', (form.description ?? '').trim())
    fd.append('sku', form.sku.trim())
    fd.append('unit_id', form.unit_id)
    fd.append('mrp', form.mrp)
    if (form.hsn_code.trim()) fd.append('hsn_code', form.hsn_code.trim())
    if (form.purchase_price !== '') fd.append('purchase_price', form.purchase_price)
    if (form.tax_rate_id) fd.append('tax_rate_id', form.tax_rate_id)
    if (!isEdit && form.category_id) fd.append('category_id', form.category_id)
    if (imageFile) fd.append('image', imageFile)
    if (isEdit) fd.append('_method', 'PUT') // Laravel method spoof — lets PUT carry a file

    setSubmitting(true)
    setAlert(null)
    try {
      const url = isEdit ? `/masters/gifts/products/${product.id}` : '/masters/gifts/products'
      const res = await api.post(url, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      onSaved?.(res.data?.message || (isEdit ? 'Gift product updated.' : 'Gift product created.'))
    } catch (err) {
      const d = err?.response?.data
      if (d?.errors) {
        const fieldErrs = {}
        const other = []
        Object.entries(d.errors).forEach(([key, msgs]) => {
          const msg = Array.isArray(msgs) ? msgs.join(' ') : String(msgs)
          if (['name', 'sku', 'unit_id', 'mrp', 'purchase_price', 'hsn_code', 'category_id', 'tax_rate_id', 'image'].includes(key)) {
            fieldErrs[key] = msg
          } else {
            other.push(msg)
          }
        })
        setErrors(prev => ({ ...prev, ...fieldErrs }))
        if (other.length) setAlert(other.join(' '))
      } else {
        setAlert(d?.message || 'Could not save the gift product. Please try again.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  // ── Render ────────────────────────────────────────────────────────
  return (
    <CModal
      size="lg"
      visible={open}
      onClose={closeModal}
      backdrop="static"
      scrollable
      alignment="center"
      className="gifts-modal"
    >
      <CModalHeader className="gifts-modal__header">
        <CModalTitle className="gifts-modal__title">
          {isEdit ? 'Edit Gift Product' : 'New Gift Product'}
        </CModalTitle>
      </CModalHeader>
      <CForm
        onSubmit={onSubmit}
        className="d-flex flex-column"
        style={{ flex: '1 1 auto', minHeight: 0, overflow: 'hidden' }}
      >
        <CModalBody
          className="gifts-modal__body"
          style={{ flex: '1 1 auto', minHeight: 0, overflowY: 'auto' }}
        >
          {alert && (
            <CAlert color="danger" dismissible onClose={() => setAlert(null)}>{alert}</CAlert>
          )}

          <CAlert color="info" className="d-flex align-items-start gap-2">
            <CIcon icon={cilGift} className="mt-1" />
            <div>
              {isEdit ? (
                <>
                  Gift products are never sold: price stays ₹0 and they stay hidden from the
                  customer catalog. They are only granted through a campaign.
                  {product?.available_stock !== undefined && product?.available_stock !== null && (
                    <> Current available stock: <strong>{product.available_stock}</strong> units —
                    inward more via <strong>Stock Inward</strong>.</>
                  )}
                </>
              ) : (
                <>
                  Gift products are never sold: price is locked at ₹0 and they stay hidden from the
                  customer catalog — they are only granted through a gift campaign. After saving,
                  inward its stock (<strong>Stock Inward</strong>) and attach it to a campaign tier
                  in the <strong>Campaigns</strong> tab.
                </>
              )}
            </div>
          </CAlert>

          <div className="row g-3">
            <div className="col-md-8">
              <CFormLabel className="filter-label">
                Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                value={form.name}
                invalid={!!errors.name}
                onChange={e => setField('name', e.target.value)}
                placeholder="e.g. Festive Pouch"
                disabled={submitting}
              />
              {errors.name && <div className="text-danger small mt-1">{errors.name}</div>}
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">
                SKU <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                value={form.sku}
                invalid={!!errors.sku}
                onChange={e => setField('sku', e.target.value)}
                placeholder="GIFT-001"
                disabled={submitting}
              />
              {errors.sku && <div className="text-danger small mt-1">{errors.sku}</div>}
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">
                Unit <span className="text-danger">*</span>
              </CFormLabel>
              <CFormSelect
                className="filter-input"
                value={form.unit_id}
                invalid={!!errors.unit_id}
                onChange={e => setField('unit_id', e.target.value)}
                disabled={submitting}
              >
                <option value="">Select Unit</option>
                {units.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.abbreviation})</option>
                ))}
              </CFormSelect>
              {errors.unit_id && <div className="text-danger small mt-1">{errors.unit_id}</div>}
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">Tax Rate</CFormLabel>
              <CFormSelect
                className="filter-input"
                value={form.tax_rate_id}
                onChange={e => setField('tax_rate_id', e.target.value)}
                disabled={submitting}
              >
                <option value="">No Tax</option>
                {taxRates.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
              </CFormSelect>
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">Category</CFormLabel>
              {isEdit ? (
                <>
                  <CFormInput className="filter-input" value={product?.category || 'Gifts'} disabled />
                  <div className="text-medium-emphasis small mt-1">Category is fixed after creation.</div>
                </>
              ) : (
                <>
                  <CFormSelect
                    className="filter-input"
                    value={form.category_id}
                    onChange={e => setField('category_id', e.target.value)}
                    disabled={submitting}
                  >
                    <option value="">Auto: “Gifts” category</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </CFormSelect>
                  <div className="text-medium-emphasis small mt-1">
                    Leave empty to use the auto-created “Gifts” category.
                  </div>
                </>
              )}
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">
                MRP <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                step="0.01"
                min="0"
                value={form.mrp}
                invalid={!!errors.mrp}
                onChange={e => setField('mrp', e.target.value)}
                disabled={submitting}
              />
              {errors.mrp && <div className="text-danger small mt-1">{errors.mrp}</div>}
              <div className="text-medium-emphasis small mt-1">Display-only — the customer always pays ₹0.</div>
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">Purchase Price (your cost)</CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                step="0.01"
                min="0"
                value={form.purchase_price}
                invalid={!!errors.purchase_price}
                onChange={e => setField('purchase_price', e.target.value)}
                disabled={submitting}
              />
              {errors.purchase_price && <div className="text-danger small mt-1">{errors.purchase_price}</div>}
              <div className="text-medium-emphasis small mt-1">Used for gift cost / ROI reporting.</div>
            </div>

            <div className="col-md-4">
              <CFormLabel className="filter-label">HSN Code</CFormLabel>
              <CFormInput
                className="filter-input"
                value={form.hsn_code}
                onChange={e => setField('hsn_code', e.target.value)}
                disabled={submitting}
              />
            </div>

            <div className="col-md-12">
              <CFormLabel className="filter-label">Description</CFormLabel>
              <CFormTextarea
                className="filter-input"
                rows={2}
                value={form.description}
                onChange={e => setField('description', e.target.value)}
                disabled={submitting}
                placeholder="Shown on the gift card in the customer's cart (optional)"
              />
            </div>

            <div className="col-md-12">
              <CFormLabel className="filter-label">
                <CIcon icon={cilImagePlus} className="me-1" /> Image (optional)
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={onImageChange}
                disabled={submitting}
              />
              {errors.image && <div className="text-danger small mt-1">{errors.image}</div>}
              <div className="text-medium-emphasis small mt-1">JPG / PNG / WebP, max 2 MB.</div>

              {imagePreview && (
                <div className="d-flex align-items-center gap-2 mt-2">
                  <img
                    src={imagePreview}
                    alt="Gift preview"
                    width={64}
                    height={64}
                    style={{ objectFit: 'cover' }}
                    className="rounded border"
                  />
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={clearImage}
                    disabled={submitting || !imageFile}
                  >
                    <CIcon icon={cilX} className="me-1" />
                    {imageFile ? 'Remove selected image' : 'Using saved image'}
                  </CButton>
                </div>
              )}
            </div>
          </div>
        </CModalBody>

        <CModalFooter className="gifts-modal__footer" style={{ flexShrink: 0 }}>
          <CButton className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
            Cancel
          </CButton>
          <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
            {submitting && <CSpinner size="sm" className="me-2" />}
            {isEdit ? 'Save Changes' : 'Create Gift Product'}
          </CButton>
        </CModalFooter>
      </CForm>
    </CModal>
  )
}

export default GiftProductForm
