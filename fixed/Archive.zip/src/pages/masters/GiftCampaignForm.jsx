import { useEffect, useMemo, useState } from 'react'
import {
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter, CButton,
  CForm, CFormLabel, CFormInput, CFormSelect, CFormSwitch, CAlert, CSpinner,
  CBadge, CCard, CCardBody, CInputGroup, CInputGroupText,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilMinus, cilTrash, cilGift, cilInfo } from '@coreui/icons'
import api from '../../api/api'

// ─────────────────────────────────────────────────────────────────────────
// ★ FREE GIFTS — Campaign create/edit modal with the tier builder.
//
// A campaign = validity window + caps + an ordered list of tiers.
// Each tier = a cart-value threshold + the gift products (and quantities)
// that unlock at that threshold. Tiers are sent wholesale on every save
// (the backend replaces them in one transaction).
//
//   POST /masters/gifts              (create)
//   PUT  /masters/gifts/{id}         (update)
//   GET  /masters/gifts/products     (gift picker options, with stock)
// ─────────────────────────────────────────────────────────────────────────

const useDebounced = (value, delay = 400) => {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])
  return debounced
}

let tierSeq = 0
const newTier = () => ({ id: ++tierSeq, threshold: '', items: [] })

const todayStr = () => {
  const d = new Date()
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
}

const TIER_MODE_HINTS = {
  exact: 'Exact tiers — a cart only gets the gifts of the highest threshold it crosses. You compose every tier completely (e.g. the ₹1000 tier can be X + Y + Z).',
  cumulative: 'Cumulative — the highest crossed tier grants its gifts PLUS everything from the lower tiers. (A gift appearing in several tiers is given once, at its highest quantity.)',
}

const BASIS_HINTS = {
  after_coupon: 'Threshold is checked against the cart value AFTER the coupon discount. Delivery charge never counts.',
  before_coupon: 'Threshold is checked against the cart value BEFORE the coupon discount. Delivery charge never counts.',
}

// ── Self-contained responsive modal chrome (wide variant) ───────────
// Guarantees the header AND footer (Create / Cancel) are always visible:
// dialog capped at 92vh, only the body scrolls, footer pinned below it,
// edge-to-edge fullscreen on phones. No dependency on portal CSS
// (wallet-modal etc.) — injected once, shared with GiftProductForm.
const MODAL_CSS = `
.gifts-modal .modal-dialog{max-width:min(880px,94vw) !important;width:94vw !important;margin:3vh auto !important;}
.gifts-modal--wide .modal-dialog{max-width:min(1140px,96vw) !important;width:96vw !important;}
.gifts-modal .modal-content{max-height:90vh !important;display:flex !important;flex-direction:column !important;overflow:hidden !important;}
.gifts-modal .modal-header,.gifts-modal .modal-footer{flex:0 0 auto !important;}
.gifts-modal .modal-body{flex:1 1 auto !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}
.gifts-modal .modal-footer{border-top:1px solid rgba(0,0,0,.08);flex-wrap:wrap;gap:.5rem;}
.gifts-modal .modal-footer .btn{min-width:130px;}
.gifts-modal .gifts-modal__title{font-size:1rem;font-weight:600;}
.gifts-modal table{table-layout:auto;}
@media (max-width:767.98px){
  .gifts-modal .modal-dialog,.gifts-modal--wide .modal-dialog{max-width:100vw !important;width:100vw !important;margin:0 !important;}
  .gifts-modal .modal-content{max-height:100vh !important;min-height:100vh;border-radius:0 !important;}
}
`

const injectModalCss = () => {
  if (!document.getElementById('gifts-modal-style')) {
    const el = document.createElement('style')
    el.id = 'gifts-modal-style'
    el.textContent = MODAL_CSS
    document.head.appendChild(el)
  }
}

const DEFAULT_FORM = {
  name: '',
  valid_from: todayStr(),
  valid_until: '',
  tier_mode: 'exact',
  threshold_basis: 'after_coupon',
  usage_limit_total: '',
  usage_limit_per_customer: '',
  is_active: false,
}

const GiftCampaignForm = ({ open, campaign = null, onClose, onSaved }) => {
  const isEdit = !!campaign

  const [form, setForm]           = useState(DEFAULT_FORM)
  const [tiers, setTiers]         = useState([newTier()])
  const [giftOptions, setGiftOptions] = useState([])
  const [optionsLoading, setOptionsLoading] = useState(false)
  const [pickerSearchInput, setPickerSearchInput] = useState('')
  const debouncedPickerSearch = useDebounced(pickerSearchInput, 400)
  const [pickerChoice, setPickerChoice] = useState({})   // { [tierId]: variantId }
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState({})
  const [alert, setAlert]   = useState(null)

  // Inject the responsive modal CSS once (idempotent, app-wide).
  useEffect(() => { injectModalCss() }, [])

  // ── Hydrate on open ───────────────────────────────────────────
  useEffect(() => {
    if (!open) return

    setErrors({})
    setAlert(null)
    setPickerSearchInput('')
    setPickerChoice({})

    if (campaign) {
      setForm({
        name: campaign.name ?? '',
        valid_from: campaign.valid_from ?? todayStr(),
        valid_until: campaign.valid_until ?? '',
        tier_mode: campaign.tier_mode ?? 'exact',
        threshold_basis: campaign.threshold_basis ?? 'after_coupon',
        usage_limit_total: campaign.usage_limit_total ?? '',
        usage_limit_per_customer: campaign.usage_limit_per_customer ?? '',
        is_active: !!campaign.is_active,
      })
      const sorted = [...(campaign.tiers ?? [])].sort(
        (a, b) => Number(a.threshold_amount) - Number(b.threshold_amount)
      )
      setTiers(sorted.length
        ? sorted.map(t => ({
            id: ++tierSeq,
            threshold: String(t.threshold_amount ?? ''),
            items: (t.items ?? []).map(i => ({
              product_variant_id: i.product_variant_id,
              quantity: i.quantity ?? 1,
              name: i.product_name,
              sku: i.sku,
              mrp: i.mrp,
              unit_abbr: i.unit_abbr,
              image_url: i.image_url,
              is_active: i.variant_is_active !== false,
              available_stock: null, // backfilled once options load
            })),
          }))
        : [newTier()])
    } else {
      setForm(DEFAULT_FORM)
      setTiers([newTier()])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, campaign])

  // ── Gift picker options (active gift products, with stock) ────────
  useEffect(() => {
    if (!open) return

    let cancelled = false
    const fetchOptions = async () => {
      setOptionsLoading(true)
      try {
        const res = await api.get('/masters/gifts/products', {
          params: { per_page: 100, is_active: 1, search: debouncedPickerSearch || undefined },
        })
        if (!cancelled) setGiftOptions(res.data?.data?.data ?? [])
      } catch {
        if (!cancelled) setGiftOptions([])
      } finally {
        if (!cancelled) setOptionsLoading(false)
      }
    }
    fetchOptions()
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, debouncedPickerSearch])

  // Backfill live stock numbers onto items hydrated from a saved campaign.
  useEffect(() => {
    if (!giftOptions.length) return
    setTiers(prev => prev.map(t => ({
      ...t,
      items: t.items.map(i => {
        const opt = giftOptions.find(o => o.id === i.product_variant_id)
        return opt ? { ...i, available_stock: opt.available_stock } : i
      }),
    })))
  }, [giftOptions])

  // ── Basics ────────────────────────────────────────────────────────
  const setField = (key, value) => setForm(prev => ({ ...prev, [key]: value }))

  // ── Tier builder ──────────────────────────────────────────────────
  const addTier  = () => setTiers(prev => [...prev, newTier()])
  const removeTier = id => setTiers(prev => prev.filter(t => t.id !== id))

  const setThreshold = (id, value) =>
    setTiers(prev => prev.map(t => (t.id === id ? { ...t, threshold: value } : t)))

  const addItem = (tierId) => {
    const variantId = Number(pickerChoice[tierId])
    if (!variantId) return
    const opt = giftOptions.find(o => o.id === variantId)
    if (!opt) return

    setTiers(prev => prev.map(t => {
      if (t.id !== tierId) return t
      if (t.items.some(i => i.product_variant_id === opt.id)) return t
      return {
        ...t,
        items: [...t.items, {
          product_variant_id: opt.id,
          quantity: 1,
          name: opt.name,
          sku: opt.sku,
          mrp: opt.mrp,
          unit_abbr: opt.unit_abbr,
          image_url: opt.image_url,
          available_stock: opt.available_stock,
          is_active: true,
        }],
      }
    }))
    setPickerChoice(prev => ({ ...prev, [tierId]: '' }))
  }

  const removeItem = (tierId, variantId) =>
    setTiers(prev => prev.map(t =>
      t.id === tierId ? { ...t, items: t.items.filter(i => i.product_variant_id !== variantId) } : t
    ))

  const adjustQty = (tierId, variantId, delta) =>
    setTiers(prev => prev.map(t => {
      if (t.id !== tierId) return t
      return {
        ...t,
        items: t.items.map(i =>
          i.product_variant_id === variantId
            ? { ...i, quantity: Math.min(10, Math.max(1, i.quantity + delta)) }
            : i
        ),
      }
    }))

  // ── Validation ────────────────────────────────────────────────────
  const validate = () => {
    const e = {}
    if (!form.name.trim()) e.name = 'Campaign name is required.'
    if (!form.valid_from) e.valid_from = 'Start date is required.'
    if (form.valid_until && form.valid_from && form.valid_until < form.valid_from) {
      e.valid_until = 'End date must be on or after the start date.'
    }
    for (const key of ['usage_limit_total', 'usage_limit_per_customer']) {
      const v = String(form[key] ?? '').trim()
      if (v !== '' && (!/^\d+$/.test(v) || Number(v) < 1)) {
        e[key] = 'Enter a whole number of 1 or more, or leave empty for no limit.'
      }
    }
    if (!tiers.length) e.tiers = 'Add at least one tier.'

    const seen = new Set()
    tiers.forEach(t => {
      const n = Number(t.threshold)
      if (t.threshold === '' || isNaN(n) || n <= 0) {
        e[`tier_${t.id}`] = 'Enter a threshold greater than 0.'
      } else if (seen.has(n.toFixed(2))) {
        e[`tier_${t.id}`] = 'Each tier needs a unique threshold amount.'
      } else {
        seen.add(n.toFixed(2))
      }
      if (!t.items.length) e[`tier_${t.id}_items`] = 'Add at least one gift to this tier.'
    })
    return e
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    if (submitting) return

    const errs = validate()
    if (Object.keys(errs).length) {
      setErrors(errs)
      setAlert(null)
      return
    }

    const payload = {
      name: form.name.trim(),
      tier_mode: form.tier_mode,
      threshold_basis: form.threshold_basis,
      usage_limit_total: form.usage_limit_total === '' ? null : Number(form.usage_limit_total),
      usage_limit_per_customer: form.usage_limit_per_customer === '' ? null : Number(form.usage_limit_per_customer),
      valid_from: form.valid_from,
      valid_until: form.valid_until || null,
      is_active: !!form.is_active,
      tiers: tiers.map(t => ({
        threshold_amount: Number(t.threshold),
        selection_mode: 'all', // choose-one arrives in phase 2
        items: t.items.map(i => ({
          product_variant_id: i.product_variant_id,
          quantity: i.quantity,
        })),
      })),
    }

    setSubmitting(true)
    setAlert(null)
    try {
      const res = isEdit
        ? await api.put(`/masters/gifts/${campaign.id}`, payload)
        : await api.post('/masters/gifts', payload)
      onSaved?.(res.data?.message || (isEdit ? 'Campaign updated.' : 'Campaign created.'))
    } catch (err) {
      const d = err?.response?.data
      if (d?.errors) {
        const fieldErrs = {}
        const other = []
        Object.entries(d.errors).forEach(([key, msgs]) => {
          const msg = Array.isArray(msgs) ? msgs.join(' ') : String(msgs)
          if (['name', 'valid_from', 'valid_until', 'usage_limit_total', 'usage_limit_per_customer'].includes(key)) {
            fieldErrs[key] = msg
          } else {
            other.push(msg) // 'tiers', 'campaign', nested keys…
          }
        })
        setErrors(prev => ({ ...prev, ...fieldErrs }))
        if (other.length) setAlert(other.join(' '))
      } else {
        setAlert(d?.message || 'Could not save the campaign. Please try again.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  const closeModal = () => {
    if (submitting) return
    onClose()
  }

  // ── Preview ───────────────────────────────────────────────────────
  const sortedPreview = useMemo(
    () => [...tiers]
      .filter(t => Number(t.threshold) > 0)
      .sort((a, b) => Number(a.threshold) - Number(b.threshold)),
    [tiers]
  )

  const outOfStockItems = useMemo(
    () => tiers.flatMap(t => t.items).filter(i => i.available_stock === 0),
    [tiers]
  )

  // ── Render ────────────────────────────────────────────────────────
  return (
    <CModal
      size="xl"
      visible={open}
      onClose={closeModal}
      backdrop="static"
      scrollable
      alignment="center"
      className="gifts-modal gifts-modal--wide"
    >
      <CModalHeader className="gifts-modal__header">
        <CModalTitle className="gifts-modal__title">
          {isEdit ? `Edit Campaign — ${campaign.name}` : 'New Gift Campaign'}
        </CModalTitle>
      </CModalHeader>
      <CForm
        onSubmit={onSubmit}
        className="d-flex flex-column"
        style={{ flex: '1 1 auto', minHeight: 0, overflow: 'hidden' }}
      >
        <CModalBody
          className="gifts-modal__body"
          style={{ flex: '1 1 auto', minHeight: 0, overflowY: 'auto' }}
        >
          {alert && (
            <CAlert color="danger" dismissible onClose={() => setAlert(null)}>{alert}</CAlert>
          )}
          {isEdit && campaign.is_active && (
            <CAlert color="warning">This campaign is live — your changes take effect immediately.</CAlert>
          )}

          {/* ── Basics ───────────────────────────────────────────── */}
          <div className="filter-label mb-2">Campaign details</div>
          <div className="row g-3">
            <div className="col-md-6">
              <CFormLabel className="filter-label">
                Campaign Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                value={form.name}
                invalid={!!errors.name}
                onChange={e => setField('name', e.target.value)}
                placeholder="e.g. Festive Gifts"
                disabled={submitting}
              />
              {errors.name && <div className="text-danger small mt-1">{errors.name}</div>}
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">
                Valid From <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={form.valid_from}
                invalid={!!errors.valid_from}
                onChange={e => setField('valid_from', e.target.value)}
                disabled={submitting}
              />
              {errors.valid_from && <div className="text-danger small mt-1">{errors.valid_from}</div>}
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Valid Until</CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                value={form.valid_until}
                invalid={!!errors.valid_until}
                onChange={e => setField('valid_until', e.target.value)}
                disabled={submitting}
              />
              {errors.valid_until && <div className="text-danger small mt-1">{errors.valid_until}</div>}
              <div className="text-medium-emphasis small mt-1">Empty = no end date.</div>
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Tier Mode</CFormLabel>
              <CFormSelect
                className="filter-input"
                value={form.tier_mode}
                onChange={e => setField('tier_mode', e.target.value)}
                disabled={submitting}
              >
                <option value="exact">Exact tiers</option>
                <option value="cumulative">Cumulative</option>
              </CFormSelect>
              <div className="text-medium-emphasis small mt-1">{TIER_MODE_HINTS[form.tier_mode]}</div>
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Threshold Basis</CFormLabel>
              <CFormSelect
                className="filter-input"
                value={form.threshold_basis}
                onChange={e => setField('threshold_basis', e.target.value)}
                disabled={submitting}
              >
                <option value="after_coupon">After coupon</option>
                <option value="before_coupon">Before coupon</option>
              </CFormSelect>
              <div className="text-medium-emphasis small mt-1">{BASIS_HINTS[form.threshold_basis]}</div>
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Total Usage Limit</CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                min="1"
                step="1"
                value={form.usage_limit_total}
                invalid={!!errors.usage_limit_total}
                onChange={e => setField('usage_limit_total', e.target.value)}
                placeholder="Unlimited"
                disabled={submitting}
              />
              {errors.usage_limit_total && <div className="text-danger small mt-1">{errors.usage_limit_total}</div>}
              <div className="text-medium-emphasis small mt-1">Max orders that can earn gifts. Empty = unlimited.</div>
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Per-Customer Limit</CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                min="1"
                step="1"
                value={form.usage_limit_per_customer}
                invalid={!!errors.usage_limit_per_customer}
                onChange={e => setField('usage_limit_per_customer', e.target.value)}
                placeholder="Unlimited"
                disabled={submitting}
              />
              {errors.usage_limit_per_customer && <div className="text-danger small mt-1">{errors.usage_limit_per_customer}</div>}
              <div className="text-medium-emphasis small mt-1">Max times each customer can earn gifts. Empty = unlimited.</div>
            </div>

            <div className="col-md-12">
              <CFormSwitch
                id="gift-campaign-active"
                label="Activate this campaign now"
                checked={form.is_active}
                onChange={e => setField('is_active', e.target.checked)}
                disabled={submitting}
              />
              <div className="text-medium-emphasis small mt-1">
                Only one campaign can be active at a time — activating this one deactivates any
                other. Customers earn gifts only from the active campaign.
              </div>
            </div>
          </div>

          <hr />

          {/* ── Tier builder ─────────────────────────────────────── */}
          <div className="d-flex flex-wrap align-items-center gap-2 mb-2">
            <div className="filter-label mb-0">
              Threshold tiers <span className="text-danger">*</span>
            </div>
            <span className="text-medium-emphasis small">
              Every gift in a tier is granted when the cart crosses its threshold (choose-one arrives in phase 2).
            </span>
          </div>

          <div className="mb-3" style={{ maxWidth: 320 }}>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search gift products (name / SKU)"
              value={pickerSearchInput}
              onChange={e => setPickerSearchInput(e.target.value)}
              disabled={submitting}
            />
          </div>

          {errors.tiers && <div className="text-danger small mb-2">{errors.tiers}</div>}

          {tiers.map((t, idx) => {
            const tierOptionList = giftOptions.filter(
              o => !t.items.some(i => i.product_variant_id === o.id)
            )
            const giftCount = t.items.reduce((s, i) => s + i.quantity, 0)

            return (
              <CCard key={t.id} className="mb-3">
                <CCardBody className="pb-2">
                  <div className="d-flex flex-wrap align-items-center gap-2 mb-2">
                    <CBadge color="dark" shape="rounded-pill">Tier {idx + 1}</CBadge>
                    <div style={{ width: 190 }}>
                      <CInputGroup size="sm">
                        <CInputGroupText>₹</CInputGroupText>
                        <CFormInput
                          className="filter-input"
                          type="number"
                          min="1"
                          step="0.01"
                          value={t.threshold}
                          invalid={!!errors[`tier_${t.id}`]}
                          onChange={e => setThreshold(t.id, e.target.value)}
                          placeholder="300"
                          disabled={submitting}
                        />
                      </CInputGroup>
                    </div>
                    <span className="text-medium-emphasis small">cart value unlocks</span>
                    <CBadge color="info" shape="rounded-pill">{giftCount} gift{giftCount === 1 ? '' : 's'}</CBadge>
                    {tiers.length > 1 && (
                      <CButton
                        size="sm"
                        className="table-action-btn ms-auto"
                        onClick={() => removeTier(t.id)}
                        title="Remove tier"
                        disabled={submitting}
                      >
                        <CIcon icon={cilTrash} />
                      </CButton>
                    )}
                  </div>
                  {errors[`tier_${t.id}`] && (
                    <div className="text-danger small mb-2">{errors[`tier_${t.id}`]}</div>
                  )}
                  {errors[`tier_${t.id}_items`] && (
                    <div className="text-danger small mb-2">{errors[`tier_${t.id}_items`]}</div>
                  )}

                  {/* Chosen gifts */}
                  {t.items.length > 0 && (
                    <div className="mb-2">
                      {t.items.map(it => (
                        <div
                          key={it.product_variant_id}
                          className="d-flex align-items-center gap-2 py-1 border-bottom"
                        >
                          {it.image_url ? (
                            <img
                              src={it.image_url}
                              alt={it.name || 'gift'}
                              width={32}
                              height={32}
                              style={{ objectFit: 'cover' }}
                              className="rounded"
                            />
                          ) : (
                            <div
                              className="d-inline-flex align-items-center justify-content-center rounded bg-light text-medium-emphasis"
                              style={{ width: 32, height: 32 }}
                            >
                              <CIcon icon={cilGift} />
                            </div>
                          )}
                          <div style={{ minWidth: 150, flex: 1 }}>
                            <div className="small fw-semibold">{it.name}</div>
                            <div className="text-medium-emphasis" style={{ fontSize: '.75rem' }}>
                              {it.sku} · MRP ₹{it.mrp ?? 0}{it.unit_abbr ? ` / ${it.unit_abbr}` : ''}
                            </div>
                          </div>
                          {it.is_active === false && (
                            <CBadge color="secondary" shape="rounded-pill">inactive</CBadge>
                          )}
                          {it.available_stock === 0 && (
                            <CBadge color="warning" shape="rounded-pill">no stock yet</CBadge>
                          )}
                          <div className="d-flex align-items-center gap-1">
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => adjustQty(t.id, it.product_variant_id, -1)}
                              disabled={submitting || it.quantity <= 1}
                              title="Decrease quantity"
                            >
                              <CIcon icon={cilMinus} />
                            </CButton>
                            <span className="px-1 small">Qty {it.quantity}</span>
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => adjustQty(t.id, it.product_variant_id, 1)}
                              disabled={submitting || it.quantity >= 10}
                              title="Increase quantity (max 10)"
                            >
                              <CIcon icon={cilPlus} />
                            </CButton>
                          </div>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => removeItem(t.id, it.product_variant_id)}
                            title="Remove gift"
                            disabled={submitting}
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add gift row */}
                  <div className="d-flex flex-wrap gap-2 align-items-end">
                    <div style={{ minWidth: 280, flex: 1 }}>
                      <CFormSelect
                        className="filter-input"
                        size="sm"
                        value={pickerChoice[t.id] ?? ''}
                        onChange={e => setPickerChoice(prev => ({ ...prev, [t.id]: e.target.value }))}
                        disabled={submitting || optionsLoading || !tierOptionList.length}
                      >
                        <option value="">
                          {optionsLoading
                            ? 'Loading gift products…'
                            : tierOptionList.length
                              ? 'Select a gift product'
                              : t.items.length
                                ? 'All gift products added (or none match the search)'
                                : 'No gift products available — create them in the Gift Products tab'}
                        </option>
                        {tierOptionList.map(o => (
                          <option key={o.id} value={o.id}>
                            {o.name} ({o.sku}) · MRP ₹{o.mrp} · {o.available_stock > 0 ? `${o.available_stock} in stock` : 'no stock yet'}
                          </option>
                        ))}
                      </CFormSelect>
                    </div>
                    <CButton
                      size="sm"
                      className="filter-btn filter-btn--primary"
                      onClick={() => addItem(t.id)}
                      disabled={submitting || !pickerChoice[t.id]}
                    >
                      <CIcon icon={cilPlus} className="me-1" />Add Gift
                    </CButton>
                  </div>
                </CCardBody>
              </CCard>
            )
          })}

          <CButton
            size="sm"
            className="filter-btn filter-btn--ghost"
            onClick={addTier}
            disabled={submitting}
          >
            <CIcon icon={cilPlus} className="me-1" />Add Tier
          </CButton>

          {outOfStockItems.length > 0 && (
            <CAlert color="warning" className="mt-3">
              Some selected gifts have no stock yet — they are skipped at checkout (never blocking
              a paid order) until stock is inwarded at the serving branch.
            </CAlert>
          )}

          <hr />

          {/* ── Customer view preview ─────────────────────────────── */}
          <CCard className="bg-light border-0">
            <CCardBody>
              <div className="filter-label mb-2">
                <CIcon icon={cilInfo} className="me-1" />Customer view — what shoppers will see
              </div>
              {sortedPreview.length ? (
                <>
                  <div className="d-flex align-items-center flex-wrap gap-2 mb-2">
                    <CBadge color="secondary" shape="rounded-pill">Cart ₹0</CBadge>
                    {sortedPreview.map(t => {
                      const qty = t.items.reduce((s, i) => s + i.quantity, 0)
                      return (
                        <span key={t.id} className="d-inline-flex align-items-center gap-2">
                          <span className="text-medium-emphasis">→</span>
                          <CBadge color="success" shape="rounded-pill">
                            ₹{Number(t.threshold)} · {qty} gift{qty === 1 ? '' : 's'}
                          </CBadge>
                        </span>
                      )
                    })}
                  </div>
                  <div className="text-medium-emphasis small">
                    {form.tier_mode === 'exact'
                      ? 'Exact tiers: a cart only gets the gifts of the highest threshold it crosses.'
                      : 'Cumulative: a cart gets the highest tier gifts plus everything from the lower tiers.'}
                  </div>
                </>
              ) : (
                <div className="text-medium-emphasis small">
                  Add thresholds and gifts to preview the customer journey.
                </div>
              )}
            </CCardBody>
          </CCard>
        </CModalBody>

        <CModalFooter className="gifts-modal__footer" style={{ flexShrink: 0 }}>
          <CButton className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
            Cancel
          </CButton>
          <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
            {submitting && <CSpinner size="sm" className="me-2" />}
            {isEdit ? 'Save Campaign' : 'Create Campaign'}
          </CButton>
        </CModalFooter>
      </CForm>
    </CModal>
  )
}

export default GiftCampaignForm
