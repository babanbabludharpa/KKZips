import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const schema = yup.object({
  label: yup.string().required('Label is required'),
  percentage: yup
    .number()
    .typeError('Percentage must be a number')
    .min(0, 'Cannot be negative')
    .max(100, 'Cannot exceed 100')
    .required('Percentage is required'),
})

const TaxRates = () => {
  const [taxRates, setTaxRates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, taxRate: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, taxRate: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const requestSeq = useRef(0)

  const isEdit = !!modal.taxRate

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { label: '', percentage: '' },
  })

  const fetchTaxRates = async ({
    page = 1,
    searchOverride = appliedSearch,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = { page, per_page: perPage }
      if (searchOverride) params.search = searchOverride

      const res = await api.get('/masters/tax-rates', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = Array.isArray(responseData?.data)
        ? responseData.data
        : Array.isArray(responseData)
          ? responseData
          : []
      const paginationMeta = responseData?.meta ?? {}

      setTaxRates(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPage,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setTaxRates([])
      setError(err.response?.data?.message ?? 'Failed to load tax rates.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchTaxRates({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchTaxRates({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => {
    goToPage(page, fetchTaxRates)
  }

  const openCreate = () => {
    reset({ label: '', percentage: '' })
    setModalError(null)
    setModal({ open: true, taxRate: null })
  }

  const openEdit = (taxRate) => {
    reset({ label: taxRate.label, percentage: taxRate.percentage })
    setModalError(null)
    setModal({ open: true, taxRate })
  }

  const closeModal = () => {
    setModal({ open: false, taxRate: null })
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (isEdit) {
        await api.put(`/masters/tax-rates/${modal.taxRate.id}`, data)
      } else {
        await api.post('/masters/tax-rates', data)
      }
      closeModal()
      fetchTaxRates()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/tax-rates/${deleteModal.taxRate.id}`)
      setDeleteModal({ open: false, taxRate: null })
      fetchTaxRates()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (taxRate) => {
    try {
      await api.patch(`/masters/tax-rates/${taxRate.id}/toggle`)
      fetchTaxRates()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Tax Rates</h4>
          <PermissionGate permission="taxrate.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Tax Rate
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search tax rates..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading tax rates...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Label</CTableHeaderCell>
                    <CTableHeaderCell>Percentage</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {taxRates.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                        No tax rates found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    taxRates.map((taxRate, i) => (
                      <CTableRow key={taxRate.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{taxRate.label}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill">
                            {taxRate.percentage}%
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={taxRate.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(taxRate)}
                            title="Click to toggle"
                          >
                            {taxRate.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="taxrate.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(taxRate)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="taxrate.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, taxRate })}
                                title="Delete"
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="compact"
                showPageJumper={false}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Tax Rate' : 'Add Tax Rate'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Label <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  invalid={!!errors.label}
                  {...register('label')}
                  placeholder="e.g. GST 18%"
                />
                {errors.label && (
                  <div className="text-danger small mt-1">{errors.label.message}</div>
                )}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Percentage <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.percentage}
                  {...register('percentage')}
                  placeholder="e.g. 18"
                />
                {errors.percentage && (
                  <div className="text-danger small mt-1">{errors.percentage.message}</div>
                )}
              </div>
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, taxRate: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.taxRate?.label}</strong>?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, taxRate: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default TaxRates