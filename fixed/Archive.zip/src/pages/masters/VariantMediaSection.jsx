import { useRef } from 'react'
import { CButton, CFormLabel, CSpinner } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilCaretLeft, cilCaretRight, cilImage, cilImagePlus, cilTrash, cilVideo,
} from '@coreui/icons'

// ── Upload limits — keep in sync with the backend ─────────────────────
// ProductVariantMediaService::MAX_IMAGES / MAX_VIDEOS and the controller
// validation (images: jpeg,jpg,png,webp max 4096 KB ·
// videos: mp4,mov,webm,avi,mkv max 51200 KB).
export const IMAGE_LIMIT = 4
export const VIDEO_LIMIT = 2
export const IMAGE_MAX_MB = 4   // 4096 KB
export const VIDEO_MAX_MB = 50  // 51200 KB

export const IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
export const VIDEO_TYPES = [
  'video/mp4', 'video/quicktime', 'video/webm',
  'video/x-matroska', 'video/avi', 'video/x-msvideo',
]

const TILE = 76

// Small square button used for the move arrows under each tile.
const MoveBtn = ({ icon, title, onClick, disabled }) => (
  <button
    type="button"
    title={title}
    disabled={disabled}
    onClick={onClick}
    style={{
      width: 22, height: 18, lineHeight: 1, padding: 0,
      border: '1px solid #CBD5E1', borderRadius: 4,
      background: '#fff', color: '#475569',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
    }}
  >
    <CIcon icon={icon} size="sm" />
  </button>
)

const VariantMediaSection = ({
  existing = [],
  staged = [],
  loading = false,
  disabled = false,
  onPick,
  onRemoveExisting,
  onRemoveStaged,
  onMoveExisting,
  onMoveStaged,
}) => {
  const inputRef = useRef(null)

  const countOf = (type) =>
    existing.filter((m) => m.type === type).length
    + staged.filter((f) => f.type === type).length

  const handleFiles = (e) => {
    const picked = [...(e.target.files || [])]
    e.target.value = ''
    if (picked.length === 0 || !onPick) return

    const counts = { image: countOf('image'), video: countOf('video') }
    const accepted = []

    for (const file of picked) {
      const isImage = IMAGE_TYPES.includes(file.type)
      const isVideo = VIDEO_TYPES.includes(file.type)
      if (!isImage && !isVideo) continue
      if (isImage && (counts.image >= IMAGE_LIMIT || file.size > IMAGE_MAX_MB * 1024 * 1024)) continue
      if (isVideo && (counts.video >= VIDEO_LIMIT || file.size > VIDEO_MAX_MB * 1024 * 1024)) continue
      accepted.push({ file, type: isImage ? 'image' : 'video', preview: URL.createObjectURL(file) })
      counts[isImage ? 'image' : 'video'] += 1
    }
    if (accepted.length > 0) onPick(accepted)
  }

  const removeBtn = (onClick) => (
    <span
      title="Remove"
      onClick={(e) => { e.stopPropagation(); if (!disabled) onClick() }}
      style={{
        position: 'absolute', top: -7, right: -7, width: 18, height: 18,
        borderRadius: '50%', background: '#DC2626', color: '#fff',
        fontSize: '0.7rem', lineHeight: '18px', textAlign: 'center',
        cursor: disabled ? 'not-allowed' : 'pointer', fontWeight: 700,
        opacity: disabled ? 0.5 : 1,
      }}
    >
      ×
    </span>
  )

  const renderExistingTile = (m, idx, total) => (
    <div key={`ex-${m.id}`} style={{ position: 'relative', width: TILE, flexShrink: 0 }}>
      <div
        title={m.original_name || ''}
        style={{
          width: TILE, height: TILE, borderRadius: 8, overflow: 'hidden',
          border: '1px solid #E2E8F0', background: m.type === 'video' ? '#0F172A' : '#F8FAFC',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        {m.type === 'video' ? (
          <video
            src={m.url}
            muted
            preload="metadata"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : (
          <img
            src={m.url}
            alt={m.original_name || ''}
            loading="lazy"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        )}
      </div>

      {m.type === 'image' && idx === 0 && (
        <span
          title="Main photo (used everywhere the primary image is shown)"
          style={{
            position: 'absolute', top: 4, left: 4, padding: '1px 6px',
            borderRadius: 4, background: '#16A34A', color: '#fff',
            fontSize: '0.6rem', fontWeight: 700, letterSpacing: 0.3,
          }}
        >
          MAIN
        </span>
      )}

      {removeBtn(() => onRemoveExisting?.(m))}

      <div style={{ display: 'flex', justifyContent: 'center', gap: 4, marginTop: 4, height: 18 }}>
        {idx > 0 && (
          <MoveBtn
            icon={cilCaretLeft}
            title="Move left"
            disabled={disabled}
            onClick={() => onMoveExisting?.(m, 'left')}
          />
        )}
        {idx < total - 1 && (
          <MoveBtn
            icon={cilCaretRight}
            title="Move right"
            disabled={disabled}
            onClick={() => onMoveExisting?.(m, 'right')}
          />
        )}
      </div>
    </div>
  )

  const renderStagedTile = (f, stagedIndex, typeIdx, typeTotal) => (
    <div key={`st-${stagedIndex}`} style={{ position: 'relative', width: TILE, flexShrink: 0 }}>
      <div
        title={`${f.file.name} — uploads on save`}
        style={{
          width: TILE, height: TILE, borderRadius: 8, overflow: 'hidden',
          border: '1px dashed #F59E0B', background: f.type === 'video' ? '#0F172A' : '#FFFBEB',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        {f.type === 'video' ? (
          <video
            src={f.preview}
            muted
            preload="metadata"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : (
          <img
            src={f.preview}
            alt={f.file.name || ''}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        )}
      </div>

      <span
        title="New — uploads when you save"
        style={{
          position: 'absolute', top: 4, left: 4, padding: '1px 5px',
          borderRadius: 4, background: '#F59E0B', color: '#fff',
          fontSize: '0.6rem', fontWeight: 700, letterSpacing: 0.3,
        }}
      >
        NEW
      </span>

      {removeBtn(() => onRemoveStaged?.(stagedIndex))}

      <div style={{ display: 'flex', justifyContent: 'center', gap: 4, marginTop: 4, height: 18 }}>
        {typeIdx > 0 && (
          <MoveBtn
            icon={cilCaretLeft}
            title="Move left"
            disabled={disabled}
            onClick={() => onMoveStaged?.(stagedIndex, 'left')}
          />
        )}
        {typeIdx < typeTotal - 1 && (
          <MoveBtn
            icon={cilCaretRight}
            title="Move right"
            disabled={disabled}
            onClick={() => onMoveStaged?.(stagedIndex, 'right')}
          />
        )}
      </div>
    </div>
  )

  const renderGroup = (type) => {
    const exItems = existing.filter((m) => m.type === type)
    const stItems = staged
      .map((f, i) => ({ f, i }))
      .filter((x) => x.f.type === type)

    if (exItems.length === 0 && stItems.length === 0) return null

    return (
      <div className="mt-3" key={type}>
        <div className="small fw-semibold mb-2 d-flex align-items-center">
          <CIcon icon={type === 'image' ? cilImage : cilVideo} className="me-1" />
          {type === 'image' ? 'Images' : 'Videos'}
          <span className="text-muted fw-normal ms-1">
            ({type === 'image'
              ? `${exItems.length + stItems.length}/${IMAGE_LIMIT}`
              : `${exItems.length + stItems.length}/${VIDEO_LIMIT}`})
          </span>
        </div>
        <div className="d-flex flex-wrap gap-3" style={{ marginBottom: 8 }}>
          {exItems.map((m, idx) => renderExistingTile(m, idx, exItems.length))}
          {stItems.map(({ f, i }, tIdx) => renderStagedTile(f, i, tIdx, stItems.length))}
        </div>
      </div>
    )
  }

  return (
    <div>
      <input
        type="file"
        multiple
        accept={[...IMAGE_TYPES, ...VIDEO_TYPES].join(',')}
        style={{ display: 'none' }}
        ref={inputRef}
        onChange={handleFiles}
      />

      <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
        <CFormLabel className="filter-label mb-0 d-flex align-items-center">
          <CIcon icon={cilImage} className="me-1" />
          Media &amp; Preview
          {loading && <CSpinner size="sm" className="ms-2" />}
        </CFormLabel>
        <CButton
          size="sm"
          className="filter-btn filter-btn--primary"
          disabled={disabled}
          onClick={() => inputRef.current?.click()}
        >
          <CIcon icon={cilImagePlus} className="me-1" />
          Add Images / Videos
        </CButton>
      </div>

      <div className="text-muted small mt-1">
        Up to {IMAGE_LIMIT} images ({IMAGE_MAX_MB} MB each) and {VIDEO_LIMIT} videos ({VIDEO_MAX_MB} MB each).
        Use the arrows to reorder — the first image is the main photo.
      </div>

      {renderGroup('image')}
      {renderGroup('video')}

      {existing.length === 0 && staged.length === 0 && !loading && (
        <div className="text-muted small mt-2">
          No media yet — add up to {IMAGE_LIMIT} images and {VIDEO_LIMIT} videos.
        </div>
      )}

      {(countOf('image') >= IMAGE_LIMIT || countOf('video') >= VIDEO_LIMIT) && (
        <div className="small mt-1" style={{ color: '#B45309' }}>
          {countOf('image') >= IMAGE_LIMIT ? `Image limit reached (${IMAGE_LIMIT}). ` : ''}
          {countOf('video') >= VIDEO_LIMIT ? `Video limit reached (${VIDEO_LIMIT}).` : ''}
        </div>
      )}
    </div>
  )
}

export default VariantMediaSection
