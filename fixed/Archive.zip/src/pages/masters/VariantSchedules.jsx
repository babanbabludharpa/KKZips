import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput,
  CBreadcrumb, CBreadcrumbItem, CNav, CNavItem, CNavLink,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilX } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import PermissionGate from '../../components/PermissionGate'
import { formatDate } from '../../utils/formatters'

const priceSchema = yup.object({
  mrp:            yup.number().typeError('Must be a number').min(0).nullable().optional(),
  selling_price:  yup.number().typeError('Must be a number').min(0).nullable().optional(),
  purchase_price: yup.number().typeError('Must be a number').min(0).nullable().optional(),
  effective_from: yup.string().required('Effective date is required'),
})

const discountSchema = yup.object({
  discount_percent: yup.number().typeError('Must be a number').min(0).max(100).required('Discount % is required'),
  starts_on:        yup.string().required('Start date is required'),
  ends_on:          yup.string().nullable().optional(),
})

const STATUS_COLOR = {
  pending:   'warning',
  applied:   'success',
  cancelled: 'secondary',
  active:    'success',
  expired:   'secondary',
}

const VariantSchedules = () => {
  const { productId, variantId } = useParams()
  const [activeTab, setActiveTab] = useState('price')

  const [variant, setVariant] = useState(null)
  const [priceSchedules, setPriceSchedules] = useState([])
  const [discountSchedules, setDiscountSchedules] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [priceModal, setPriceModal] = useState(false)
  const [priceModalError, setPriceModalError] = useState(null)
  const [priceSubmitting, setPriceSubmitting] = useState(false)

  const [discountModal, setDiscountModal] = useState(false)
  const [discountModalError, setDiscountModalError] = useState(null)
  const [discountSubmitting, setDiscountSubmitting] = useState(false)

  const priceForm = useForm({
    resolver: yupResolver(priceSchema),
    defaultValues: { mrp: '', selling_price: '', purchase_price: '', effective_from: '' },
  })

  const discountForm = useForm({
    resolver: yupResolver(discountSchema),
    defaultValues: { discount_percent: '', starts_on: '', ends_on: '' },
  })

  useEffect(() => {
    fetchAll()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [variantId])

  const fetchAll = async () => {
    try {
      setLoading(true)
      const [variantRes, priceRes, discountRes] = await Promise.all([
        api.get(`/masters/variants/${variantId}`),
        api.get(`/masters/variants/${variantId}/price-schedules`),
        api.get(`/masters/variants/${variantId}/discount-schedules`),
      ])
      setVariant(variantRes.data?.data?.variant)

      const pd = priceRes.data?.data
      setPriceSchedules(Array.isArray(pd) ? pd : (pd?.data ?? []))

      const dd = discountRes.data?.data
      setDiscountSchedules(Array.isArray(dd) ? dd : (dd?.data ?? []))
    } catch {
      setError('Failed to load schedules.')
    } finally {
      setLoading(false)
    }
  }

  // ── Price Schedule ──────────────────────────────────────────────
  const openPriceModal = () => {
    priceForm.reset({ mrp: '', selling_price: '', purchase_price: '', effective_from: '' })
    setPriceModalError(null)
    setPriceModal(true)
  }

  const onSubmitPrice = async (data) => {
    setPriceSubmitting(true)
    try {
      const payload = {
        mrp: data.mrp || null,
        selling_price: data.selling_price || null,
        purchase_price: data.purchase_price || null,
        effective_from: data.effective_from,
      }
      await api.post(`/masters/variants/${variantId}/price-schedules`, payload)
      setPriceModal(false)
      fetchAll()
    } catch (e) {
      setPriceModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setPriceSubmitting(false)
    }
  }

  const cancelPriceSchedule = async (id) => {
    try {
      await api.patch(`/masters/price-schedules/${id}/cancel`)
      fetchAll()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Cancel failed.')
    }
  }

  // ── Discount Schedule ───────────────────────────────────────────
  const openDiscountModal = () => {
    discountForm.reset({ discount_percent: '', starts_on: '', ends_on: '' })
    setDiscountModalError(null)
    setDiscountModal(true)
  }

  const onSubmitDiscount = async (data) => {
    setDiscountSubmitting(true)
    try {
      const payload = {
        discount_percent: data.discount_percent,
        starts_on: data.starts_on,
        ends_on: data.ends_on || null,
      }
      await api.post(`/masters/variants/${variantId}/discount-schedules`, payload)
      setDiscountModal(false)
      fetchAll()
    } catch (e) {
      setDiscountModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setDiscountSubmitting(false)
    }
  }

  const cancelDiscountSchedule = async (id) => {
    try {
      await api.patch(`/masters/discount-schedules/${id}/cancel`)
      fetchAll()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Cancel failed.')
    }
  }

  if (loading) {
    return (
      <div className="report-page">
        <CCard className="report-shell">
          <CCardBody className="p-0">
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading schedules...</div>
            </div>
          </CCardBody>
        </CCard>
      </div>
    )
  }

  return (
    <div className="report-page">
      <CBreadcrumb className="mb-2">
        <CBreadcrumbItem>
          <Link to="/masters/products">Products</Link>
        </CBreadcrumbItem>
        <CBreadcrumbItem>
          <Link to={`/masters/products/${productId}/variants`}>Variants</Link>
        </CBreadcrumbItem>
        <CBreadcrumbItem active>{variant?.sku} — Schedules</CBreadcrumbItem>
      </CBreadcrumb>

      <CCard className="report-shell">
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">
              {variant?.product_name} — {variant?.sku}
            </h4>

            <div className="report-shell__price-summary">
              <span>
                <strong>MRP</strong>{' '}
                <span className="value">₹{variant?.mrp}</span>
              </span>
              <span className="sep">·</span>
              <span>
                <strong>Selling</strong>{' '}
                <span className="value">₹{variant?.selling_price}</span>
              </span>
              <span className="sep">·</span>
              <span>
                <strong>Final</strong>{' '}
                <span className="value--primary">₹{variant?.final_price}</span>
              </span>
            </div>
          </div>
        </div>

        <CNav variant="tabs" className="report-shell__tabs">
          <CNavItem>
            <CNavLink
              active={activeTab === 'price'}
              onClick={() => setActiveTab('price')}
              style={{ cursor: 'pointer' }}
            >
              Price Schedules
            </CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink
              active={activeTab === 'discount'}
              onClick={() => setActiveTab('discount')}
              style={{ cursor: 'pointer' }}
            >
              Discount Schedules
            </CNavLink>
          </CNavItem>
        </CNav>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== PRICE TAB ==================== */}
        {activeTab === 'price' && (
          <>
            <div className="report-shell__filters report-shell__filters--spread">
              <span
                className="text-muted"
                style={{ fontSize: '0.85rem', fontWeight: 600 }}
              >
                Future price changes
              </span>
              <PermissionGate permission="product.edit">
                <CButton
                  size="sm"
                  className="report-shell__export"
                  onClick={openPriceModal}
                >
                  <CIcon icon={cilPlus} className="me-2" />
                  Schedule Price Change
                </CButton>
              </PermissionGate>
            </div>

            <CCardBody className="p-0">
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Effective From</CTableHeaderCell>
                    <CTableHeaderCell>MRP</CTableHeaderCell>
                    <CTableHeaderCell>Selling Price</CTableHeaderCell>
                    <CTableHeaderCell>Purchase Price</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {priceSchedules.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                        No price schedules yet.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    priceSchedules.map(s => (
                      <CTableRow key={s.id}>
                        <CTableDataCell>{formatDate(s.effective_from)}</CTableDataCell>
                        <CTableDataCell>{s.mrp ? `₹${s.mrp}` : '—'}</CTableDataCell>
                        <CTableDataCell>{s.selling_price ? `₹${s.selling_price}` : '—'}</CTableDataCell>
                        <CTableDataCell>{s.purchase_price ? `₹${s.purchase_price}` : '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={STATUS_COLOR[s.status] ?? 'secondary'} shape="rounded-pill">
                            {s.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {s.status === 'pending' && (
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => cancelPriceSchedule(s.id)}
                            >
                              <CIcon icon={cilX} className="me-1" />
                              Cancel
                            </CButton>
                          )}
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>
            </CCardBody>
          </>
        )}

        {/* ==================== DISCOUNT TAB ==================== */}
        {activeTab === 'discount' && (
          <>
            <div className="report-shell__filters report-shell__filters--spread">
              <span
                className="text-muted"
                style={{ fontSize: '0.85rem', fontWeight: 600 }}
              >
                Discount windows
              </span>
              <PermissionGate permission="product.edit">
                <CButton
                  size="sm"
                  className="report-shell__export"
                  onClick={openDiscountModal}
                >
                  <CIcon icon={cilPlus} className="me-2" />
                  Schedule Discount
                </CButton>
              </PermissionGate>
            </div>

            <CCardBody className="p-0">
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Discount %</CTableHeaderCell>
                    <CTableHeaderCell>Starts On</CTableHeaderCell>
                    <CTableHeaderCell>Ends On</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {discountSchedules.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                        No discount schedules yet.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    discountSchedules.map(s => (
                      <CTableRow key={s.id}>
                        <CTableDataCell>
                          <CBadge color="info" shape="rounded-pill">
                            {s.discount_percent}%
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{formatDate(s.starts_on)}</CTableDataCell>
                        <CTableDataCell>{s.ends_on ? formatDate(s.ends_on) : 'Open-ended'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color={STATUS_COLOR[s.status] ?? 'secondary'} shape="rounded-pill">
                            {s.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          {['pending', 'active'].includes(s.status) && (
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => cancelDiscountSchedule(s.id)}
                            >
                              <CIcon icon={cilX} className="me-1" />
                              Cancel
                            </CButton>
                          )}
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>
            </CCardBody>
          </>
        )}
      </CCard>

      {/* ==================== PRICE MODAL ==================== */}
      <CModal
        visible={priceModal}
        onClose={() => setPriceModal(false)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Schedule Price Change</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={priceForm.handleSubmit(onSubmitPrice)}>
          <CModalBody className="wallet-modal__body">
            {priceModalError && (
              <CAlert color="danger" dismissible onClose={() => setPriceModalError(null)}>
                {priceModalError}
              </CAlert>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Effective From <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="date"
                invalid={!!priceForm.formState.errors.effective_from}
                {...priceForm.register('effective_from')}
              />
              {priceForm.formState.errors.effective_from && (
                <div className="text-danger small mt-1">
                  {priceForm.formState.errors.effective_from.message}
                </div>
              )}
            </div>

            <div className="row g-3">
              <div className="col-md-4">
                <CFormLabel className="filter-label">New MRP</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  {...priceForm.register('mrp')}
                  placeholder="Leave blank to keep"
                />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">New Selling Price</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  {...priceForm.register('selling_price')}
                  placeholder="Leave blank to keep"
                />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">New Purchase Price</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  {...priceForm.register('purchase_price')}
                  placeholder="Leave blank to keep"
                />
              </div>
            </div>

            <div className="text-muted small mt-2">
              Only fields you fill in will change on the effective date.
              You can queue multiple changes — one per effective date.
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={() => setPriceModal(false)}
              disabled={priceSubmitting}
            >
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={priceSubmitting}>
              {priceSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
              Schedule
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DISCOUNT MODAL ==================== */}
      <CModal
        visible={discountModal}
        onClose={() => setDiscountModal(false)}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Schedule Discount</CModalTitle>
        </CModalHeader>
        <CForm onSubmit={discountForm.handleSubmit(onSubmitDiscount)}>
          <CModalBody className="wallet-modal__body">
            {discountModalError && (
              <CAlert color="danger" dismissible onClose={() => setDiscountModalError(null)}>
                {discountModalError}
              </CAlert>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Discount % <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                type="number"
                step="0.01"
                invalid={!!discountForm.formState.errors.discount_percent}
                {...discountForm.register('discount_percent')}
              />
              {discountForm.formState.errors.discount_percent && (
                <div className="text-danger small mt-1">
                  {discountForm.formState.errors.discount_percent.message}
                </div>
              )}
            </div>

            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Starts On <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="date"
                  invalid={!!discountForm.formState.errors.starts_on}
                  {...discountForm.register('starts_on')}
                />
                {discountForm.formState.errors.starts_on && (
                  <div className="text-danger small mt-1">
                    {discountForm.formState.errors.starts_on.message}
                  </div>
                )}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Ends On</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="date"
                  {...discountForm.register('ends_on')}
                />
                <div className="text-muted small mt-1">
                  Leave blank for an open-ended discount.
                </div>
              </div>
            </div>

            <div className="text-muted small mt-2">
              You can queue multiple discounts — as long as their date
              windows don't overlap.
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={() => setDiscountModal(false)}
              disabled={discountSubmitting}
            >
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={discountSubmitting}>
              {discountSubmitting ? <CSpinner size="sm" className="me-2" /> : null}
              Schedule
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>
    </div>
  )
}

export default VariantSchedules