import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const schema = yup.object({
  name:     yup.string().required('City name is required'),
  state_id: yup.string().required('State is required'),
})

// Header column key -> backend sort key (must match CityService::SORTABLE)
const SORT_KEY_MAP = {
  name:       'name',
  is_active:  'is_active',
  created_at: 'created_at',
}

const Cities = () => {
  const [cities, setCities] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)

  const [modal, setModal] = useState({ open: false, city: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, city: null })

  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  // Filter-row cascading dropdowns (list scope)
  const [filterCountries, setFilterCountries] = useState([])
  const [filterStates, setFilterStates] = useState([])
  const [filterCountryId, setFilterCountryId] = useState('')
  const [filterStateId, setFilterStateId] = useState('')

  // Modal cascading dropdowns
  const [modalCountries, setModalCountries] = useState([])
  const [modalStates, setModalStates] = useState([])
  const [selectedCountryId, setSelectedCountryId] = useState('')

  const [submitting, setSubmitting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('asc')

  const requestSeq = useRef(0)

  const isEdit = !!modal.city

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { name: '', state_id: '' },
  })

  useEffect(() => {
    fetchCountries()
    fetchCities({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchCities({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  // Immediate refetch on status/state filter change
  useEffect(() => {
    setPageLoading(true)
    fetchCities({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter, filterStateId])

  const fetchCountries = async () => {
    try {
      const res = await api.get('/masters/countries')
      const list = res.data && res.data.status
        ? res.data.data.countries || res.data.data || []
        : res.data || []
      setFilterCountries(list)
      setModalCountries(list)
    } catch {
      setError('Failed to load countries.')
    }
  }

  const fetchStatesForCountry = async (countryId) => {
    if (!countryId) return []
    try {
      const res = await api.get(`/masters/states?country_id=${countryId}`)
      return res.data && res.data.status
        ? res.data.data.states || res.data.data || []
        : res.data || []
    } catch {
      return []
    }
  }

  const buildParams = (useSearch, useStateId, useStatusFilter, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useStateId) params.state_id = useStateId
    if (useStatusFilter !== 'all') {
      params.is_active = useStatusFilter === 'active' ? 1 : 0
    }
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, message, data: { cities: [...], meta: {...} } }
  const fetchCities = async ({
    page = 1,
    searchOverride = appliedSearch,
    stateOverride = filterStateId,
    statusOverride = statusFilter,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(
          searchOverride,
          stateOverride,
          statusOverride,
          perPageOverride,
          sortKeyOverride,
          sortDirOverride
        ),
      }
      const res = await api.get('/masters/cities', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.cities ?? []
      const paginationMeta = responseData?.meta ?? {}

      setCities(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setCities([])
      setError(err.response?.data?.message ?? 'Failed to load cities.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const handlePageChange = (page) => {
    goToPage(page, fetchCities)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchCities)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchCities({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  // --- Filter row handlers ---
  const handleFilterCountryChange = async (countryId) => {
    setFilterCountryId(countryId)
    setFilterStateId('')
    setFilterStates(countryId ? await fetchStatesForCountry(countryId) : [])
  }

  // --- Modal handlers ---
  const handleModalCountryChange = async (countryId) => {
    setSelectedCountryId(countryId)
    setValue('state_id', '')
    setModalStates(countryId ? await fetchStatesForCountry(countryId) : [])
  }

  const openCreate = () => {
    reset({ name: '', state_id: '' })
    setSelectedCountryId('')
    setModalStates([])
    setModalError(null)
    setModal({ open: true, city: null })
  }

  const openEdit = async (city) => {
    reset({ name: city.name ?? '', state_id: '' })
    setModalError(null)

    const countryId = city.state?.country_id ?? ''
    setSelectedCountryId(countryId)
    const states = countryId ? await fetchStatesForCountry(countryId) : []
    setModalStates(states)
    setValue('state_id', city.state_id ?? '')

    setModal({ open: true, city })
  }

  const closeModal = () => {
    setModal({ open: false, city: null })
    setSelectedCountryId('')
    setModalStates([])
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = {
        name: data.name.trim(),
        state_id: parseInt(data.state_id, 10),
      }
      if (isEdit) {
        await api.put(`/masters/cities/${modal.city.id}`, payload)
      } else {
        await api.post('/masters/cities', payload)
      }
      closeModal()
      fetchCities()
    } catch (e) {
      if (e.response?.status === 422) {
        setModalError(e.response.data.message || 'City name might already exist in this state.')
      } else {
        setModalError(e.response?.data?.message ?? 'Operation failed.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/cities/${deleteModal.city.id}`)
      setDeleteModal({ open: false, city: null })
      fetchCities()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (city) => {
    try {
      await api.patch(`/masters/cities/${city.id}/toggle`)
      fetchCities()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Master Cities</h4>
          <PermissionGate permission="city.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add City
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search cities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Country</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filterCountryId}
              onChange={(e) => handleFilterCountryChange(e.target.value)}
            >
              <option value="">All Countries</option>
              {filterCountries.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">State</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={filterStateId}
              disabled={!filterCountryId}
              onChange={(e) => setFilterStateId(e.target.value)}
            >
              <option value="">All States</option>
              {filterStates.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive Only</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading cities...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="name">City Name</SortableHeader>
                    <CTableHeaderCell>State</CTableHeaderCell>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {cities.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                        No cities found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    cities.map((city, i) => (
                      <CTableRow key={city.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{city.name}</CTableDataCell>
                        <CTableDataCell className="text-muted small">
                          {city.state ? city.state.name : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={city.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(city)}
                            title="Click to toggle"
                          >
                            {city.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="city.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(city)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="city.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, city })}
                                title="Delete"
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit City' : 'Add City'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Country <span className="text-danger">*</span>
              </CFormLabel>
              <CFormSelect
                className="filter-input"
                value={selectedCountryId}
                onChange={(e) => handleModalCountryChange(e.target.value)}
              >
                <option value="">-- Choose Country --</option>
                {modalCountries.map((c) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
                ))}
              </CFormSelect>
              <div className="small text-muted mt-1">
                Not sent to the server — narrows the state list below.
              </div>
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">
                State <span className="text-danger">*</span>
              </CFormLabel>
              <CFormSelect
                className="filter-input"
                invalid={!!errors.state_id}
                disabled={!selectedCountryId}
                {...register('state_id')}
              >
                <option value="">-- Choose State --</option>
                {modalStates.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </CFormSelect>
              {errors.state_id && (
                <div className="text-danger small mt-1">{errors.state_id.message}</div>
              )}
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">
                City Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                invalid={!!errors.name}
                {...register('name')}
                placeholder="e.g. Pune"
              />
              {errors.name && (
                <div className="text-danger small mt-1">{errors.name.message}</div>
              )}
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, city: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.city?.name}</strong>?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, city: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Cities