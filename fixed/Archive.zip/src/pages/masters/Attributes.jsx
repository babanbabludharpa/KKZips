import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilList } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const attributeSchema = yup.object({
  name: yup.string().required('Name is required'),
})

const valueSchema = yup.object({
  value: yup.string().required('Value is required'),
})

const Attributes = () => {
  const [attributes, setAttributes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, attribute: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, attribute: null })
  const [valuesModal, setValuesModal] = useState({ open: false, attribute: null })
  const [valueModalError, setValueModalError] = useState(null)
  const [editingValue, setEditingValue] = useState(null)
  const [deleteValueModal, setDeleteValueModal] = useState({ open: false, value: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [valueSubmitting, setValueSubmitting] = useState(false)

  const requestSeq = useRef(0)

  const isEdit = !!modal.attribute

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(attributeSchema),
    defaultValues: { name: '' },
  })

  const {
    register: registerValue,
    handleSubmit: handleSubmitValue,
    reset: resetValue,
    formState: { errors: valueErrors },
  } = useForm({
    resolver: yupResolver(valueSchema),
    defaultValues: { value: '' },
  })

  const fetchAttributes = async ({
    page = 1,
    searchOverride = appliedSearch,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = { page, per_page: perPage }
      if (searchOverride) params.search = searchOverride

      const res = await api.get('/masters/attributes', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = Array.isArray(responseData?.data)
        ? responseData.data
        : Array.isArray(responseData)
          ? responseData
          : []
      const paginationMeta = responseData?.meta ?? {}

      setAttributes(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPage,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setAttributes([])
      setError(err.response?.data?.message ?? 'Failed to load attributes.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchAttributes({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchAttributes({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => {
    goToPage(page, fetchAttributes)
  }

  // ── Attribute CRUD ──────────────────────────────────────────────
  const openCreate = () => {
    reset({ name: '' })
    setModalError(null)
    setModal({ open: true, attribute: null })
  }

  const openEdit = (attribute) => {
    reset({ name: attribute.name })
    setModalError(null)
    setModal({ open: true, attribute })
  }

  const closeModal = () => {
    setModal({ open: false, attribute: null })
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (isEdit) {
        await api.put(`/masters/attributes/${modal.attribute.id}`, data)
      } else {
        await api.post('/masters/attributes', data)
      }
      closeModal()
      fetchAttributes()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/attributes/${deleteModal.attribute.id}`)
      setDeleteModal({ open: false, attribute: null })
      fetchAttributes()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (attribute) => {
    try {
      await api.patch(`/masters/attributes/${attribute.id}/toggle`)
      fetchAttributes()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  // ── Attribute Values (nested modal) ─────────────────────────────
  const openValuesModal = (attribute) => {
    setValuesModal({ open: true, attribute })
    setEditingValue(null)
    resetValue({ value: '' })
    setValueModalError(null)
  }

  const closeValuesModal = () => {
    setValuesModal({ open: false, attribute: null })
    setEditingValue(null)
    setValueModalError(null)
  }

  const startEditValue = (value) => {
    setEditingValue(value)
    resetValue({ value: value.value })
    setValueModalError(null)
  }

  const cancelEditValue = () => {
    setEditingValue(null)
    resetValue({ value: '' })
    setValueModalError(null)
  }

  const onSubmitValue = async (data) => {
    setValueSubmitting(true)
    try {
      if (editingValue) {
        await api.put(`/masters/attribute-values/${editingValue.id}`, data)
      } else {
        await api.post(`/masters/attributes/${valuesModal.attribute.id}/values`, data)
      }
      cancelEditValue()
      await fetchAttributes()
      // refresh the attribute reference inside the open modal with latest values
      const res = await api.get(`/masters/attributes/${valuesModal.attribute.id}`)
      setValuesModal({ open: true, attribute: res.data?.data?.attribute })
    } catch (e) {
      setValueModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setValueSubmitting(false)
    }
  }

  const handleDeleteValue = async () => {
    try {
      await api.delete(`/masters/attribute-values/${deleteValueModal.value.id}`)
      setDeleteValueModal({ open: false, value: null })
      await fetchAttributes()
      const res = await api.get(`/masters/attributes/${valuesModal.attribute.id}`)
      setValuesModal({ open: true, attribute: res.data?.data?.attribute })
    } catch (e) {
      setValueModalError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Attributes</h4>
          <PermissionGate permission="attribute.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Attribute
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search attributes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading attributes...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>Values</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {attributes.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={5} className="text-center text-muted py-4">
                        No attributes found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    attributes.map((attribute, i) => (
                      <CTableRow key={attribute.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{attribute.name}</CTableDataCell>
                        <CTableDataCell>
                          {attribute.values?.length > 0 ? (
                            <div className="d-flex flex-wrap gap-1 justify-content-center">
                              {attribute.values.slice(0, 4).map((v) => (
                                <CBadge key={v.id} color="info" shape="rounded-pill">
                                  {v.value}
                                </CBadge>
                              ))}
                              {attribute.values.length > 4 && (
                                <CBadge color="secondary" shape="rounded-pill">
                                  +{attribute.values.length - 4} more
                                </CBadge>
                              )}
                            </div>
                          ) : (
                            <span className="text-muted small">No values yet</span>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={attribute.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(attribute)}
                            title="Click to toggle"
                          >
                            {attribute.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="attribute.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openValuesModal(attribute)}
                                title="Manage values"
                              >
                                <CIcon icon={cilList} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="attribute.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(attribute)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="attribute.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, attribute })}
                                title="Delete"
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="compact"
                showPageJumper={false}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT ATTRIBUTE MODAL ==================== */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Attribute' : 'Add Attribute'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <CFormLabel className="filter-label">
              Name <span className="text-danger">*</span>
            </CFormLabel>
            <CFormInput
              className="filter-input"
              invalid={!!errors.name}
              {...register('name')}
              placeholder="e.g. Size, Color"
            />
            {errors.name && (
              <div className="text-danger small mt-1">{errors.name.message}</div>
            )}
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE ATTRIBUTE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, attribute: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.attribute?.name}</strong> and all its values?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, attribute: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== MANAGE VALUES MODAL ==================== */}
      <CModal visible={valuesModal.open} onClose={closeValuesModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            Manage Values — {valuesModal.attribute?.name}
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {valueModalError && (
            <CAlert color="danger" dismissible onClose={() => setValueModalError(null)}>
              {valueModalError}
            </CAlert>
          )}

          <CForm onSubmit={handleSubmitValue(onSubmitValue)} className="mb-4">
            <CFormLabel className="filter-label">
              {editingValue ? 'Edit Value' : 'Add New Value'}
            </CFormLabel>
            <div className="d-flex gap-2">
              <CFormInput
                className="filter-input"
                invalid={!!valueErrors.value}
                {...registerValue('value')}
                placeholder="e.g. 500ml, Red, M"
              />
              <CButton
                type="submit"
                className="filter-btn filter-btn--primary"
                disabled={valueSubmitting}
              >
                {valueSubmitting ? <CSpinner size="sm" /> : (editingValue ? 'Update' : 'Add')}
              </CButton>
              {editingValue && (
                <CButton
                  className="filter-btn filter-btn--ghost"
                  onClick={cancelEditValue}
                >
                  Cancel
                </CButton>
              )}
            </div>
            {valueErrors.value && (
              <div className="text-danger small mt-1">{valueErrors.value.message}</div>
            )}
          </CForm>

          <CFormLabel className="filter-label">Existing Values</CFormLabel>
          {valuesModal.attribute?.values?.length > 0 ? (
            <div className="report-frame">
              <CTable hover responsive size="sm" className="admin-data-table admin-data-table--preview mb-0">
                <CTableBody>
                  {valuesModal.attribute.values.map((v) => (
                    <CTableRow key={v.id}>
                      <CTableDataCell className="text-start">{v.value}</CTableDataCell>
                      <CTableDataCell>
                        <CBadge
                          color={v.is_active ? 'success' : 'secondary'}
                          shape="rounded-pill"
                        >
                          {v.is_active ? 'Active' : 'Inactive'}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell className="text-end">
                        <div className="d-flex gap-1 justify-content-end">
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => startEditValue(v)}
                            title="Edit"
                          >
                            <CIcon icon={cilPencil} />
                          </CButton>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => setDeleteValueModal({ open: true, value: v })}
                            title="Delete"
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </div>
          ) : (
            <div className="text-muted small">No values added yet.</div>
          )}
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={closeValuesModal}
          >
            Close
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== DELETE VALUE CONFIRM ==================== */}
      <CModal
        visible={deleteValueModal.open}
        onClose={() => setDeleteValueModal({ open: false, value: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Delete value <strong>{deleteValueModal.value?.value}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteValueModal({ open: false, value: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDeleteValue}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Attributes