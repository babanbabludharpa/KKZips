import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormTextarea, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilImage } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const schema = yup.object({
  name: yup.string().required('Name is required'),
  description: yup.string().nullable().optional(),
})

// Header column key -> backend sort key (must match CategoryService::SORTABLE)
const SORT_KEY_MAP = {
  name:       'name',
  is_active:  'is_active',
  created_at: 'created_at',
}

const Categories = () => {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, category: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, category: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [imageFile, setImageFile] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const fileInputRef = useRef(null)

  const requestSeq = useRef(0)

  const isEdit = !!modal.category

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { name: '', description: '' },
  })

  const buildParams = (useSearch, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, message, data: { data: [...rows], meta: {...} } }
  const fetchCategories = async ({
    page = 1,
    searchOverride = appliedSearch,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(searchOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/masters/categories', { params })

      if (mySeq !== requestSeq.current) return

      const paginated = res.data?.data
      const dataArray = Array.isArray(paginated?.data) ? paginated.data : []
      const paginationMeta = paginated?.meta ?? {}

      setCategories(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setCategories([])
      setError(err.response?.data?.message ?? 'Failed to load categories.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCategories({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchCategories({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  // Revoke object URLs so previews don't leak memory across opens.
  useEffect(() => () => { if (imagePreview) URL.revokeObjectURL(imagePreview) }, [imagePreview])

  const handlePageChange = (page) => {
    goToPage(page, fetchCategories)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchCategories)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchCategories({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const resetImageState = () => {
    if (imagePreview) URL.revokeObjectURL(imagePreview)
    setImageFile(null)
    setImagePreview(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const openCreate = () => {
    reset({ name: '', description: '' })
    resetImageState()
    setModalError(null)
    setModal({ open: true, category: null })
  }

  const openEdit = (category) => {
    reset({ name: category.name ?? '', description: category.description ?? '' })
    resetImageState()
    setImagePreview(category.image_url ?? null)
    setModalError(null)
    setModal({ open: true, category })
  }

  const closeModal = () => {
    setModal({ open: false, category: null })
    resetImageState()
    setModalError(null)
  }

  const onImageChange = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (imagePreview) URL.revokeObjectURL(imagePreview)
    setImageFile(file)
    setImagePreview(URL.createObjectURL(file))
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const formData = new FormData()
      formData.append('name', data.name)
      if (data.description) formData.append('description', data.description)
      if (imageFile) formData.append('image', imageFile)

      if (isEdit) {
        // POST + method spoofing — PHP doesn't parse $_FILES on a real PUT.
        formData.append('_method', 'PUT')
        await api.post(`/masters/categories/${modal.category.id}`, formData)
      } else {
        await api.post('/masters/categories', formData)
      }
      closeModal()
      fetchCategories()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/categories/${deleteModal.category.id}`)
      setDeleteModal({ open: false, category: null })
      fetchCategories()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (category) => {
    try {
      await api.patch(`/masters/categories/${category.id}/toggle`)
      fetchCategories()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Categories</h4>
          <PermissionGate permission="category.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Category
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search categories..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading categories...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Image</CTableHeaderCell>
                    <SortableHeader colKey="name">Name</SortableHeader>
                    <CTableHeaderCell>Description</CTableHeaderCell>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {categories.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                        No categories found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    categories.map((category, i) => (
                      <CTableRow key={category.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>
                          {category.image_url ? (
                            <img
                              src={category.image_url}
                              alt={category.name}
                              className="category-thumb"
                            />
                          ) : (
                            <div className="category-thumb category-thumb--empty">
                              <CIcon icon={cilImage} size="sm" className="text-muted" />
                            </div>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>{category.name}</CTableDataCell>
                        <CTableDataCell className="text-muted small">
                          {category.description
                            ? (category.description.length > 60
                                ? category.description.slice(0, 60) + '…'
                                : category.description)
                            : '—'}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={category.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(category)}
                            title="Click to toggle"
                          >
                            {category.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="category.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(category)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="category.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, category })}
                                title="Delete"
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Category' : 'Add Category'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="mb-3 d-flex align-items-center gap-3">
              <div
                className="category-image-picker"
                onClick={() => fileInputRef.current?.click()}
                title="Click to choose an image"
              >
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    alt="Category"
                    className="category-image-picker__img"
                  />
                ) : (
                  <CIcon icon={cilImage} className="text-muted" />
                )}
              </div>
              <div>
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--ghost"
                  onClick={() => fileInputRef.current?.click()}
                  type="button"
                >
                  {imagePreview ? 'Change Image' : 'Upload Image'}
                </CButton>
                <div className="small text-muted mt-1">
                  Round thumbnail, JPG/PNG, max 2MB.
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={onImageChange}
                style={{ display: 'none' }}
              />
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                invalid={!!errors.name}
                {...register('name')}
                placeholder="e.g. Beverages, Dairy"
              />
              {errors.name && (
                <div className="text-danger small mt-1">{errors.name.message}</div>
              )}
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">Description</CFormLabel>
              <CFormTextarea className="filter-input" rows={3} {...register('description')} />
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, category: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.category?.name}</strong>?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, category: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Categories