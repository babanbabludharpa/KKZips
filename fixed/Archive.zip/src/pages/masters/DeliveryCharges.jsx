import { useEffect, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CBadge, CSpinner, CAlert, CModal, CModalHeader, CModalTitle,
  CModalBody, CModalFooter, CForm, CFormLabel, CFormInput, CFormCheck,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilPencil, cilTrash, cilInfo } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'

const emptyToUndefined = (v, o) => (o === '' ? undefined : v)

const schema = yup.object({
  name:                yup.string().required('Name is required'),
  min_order_amount:    yup.number().typeError('Must be a number').min(0).nullable().optional().transform(emptyToUndefined),
  free_delivery_above: yup.number().typeError('Must be a number').min(0).nullable().optional().transform(emptyToUndefined),
  base_charge:         yup.number().typeError('Must be a number').min(0).required('Base charge is required'),
  per_km_charge:       yup.number().typeError('Must be a number').min(0).nullable().optional().transform(emptyToUndefined),
  max_charge:          yup.number().typeError('Must be a number').min(0).nullable().optional().transform(emptyToUndefined)
                          .test('max-gte-base', 'Max charge cannot be lower than base charge', function (value) {
                            const { base_charge } = this.parent
                            if (value == null || base_charge == null) return true
                            return value >= base_charge
                          }),
  max_delivery_km:     yup.number().typeError('Must be a number').min(0).nullable().optional().transform(emptyToUndefined),
  is_active:           yup.boolean().optional(),
})

const DeliveryCharges = () => {
  const [rules, setRules] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modal, setModal] = useState({ open: false, rule: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, rule: null })
  const [modalError, setModalError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const isEdit = !!modal.rule

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      name: 'Standard', min_order_amount: '', free_delivery_above: '',
      base_charge: '', per_km_charge: '', max_charge: '',
      max_delivery_km: '', is_active: true,
    },
  })

  useEffect(() => { fetchRules() }, [])

  const fetchRules = async () => {
    setLoading(true)
    try {
      const res = await api.get('/masters/delivery-charges')
      setRules(res.data?.data ?? [])
    } catch {
      setError('Failed to load delivery charge rules.')
    } finally {
      setLoading(false)
    }
  }

  const openCreate = () => {
    reset({
      name: 'Standard', min_order_amount: '', free_delivery_above: '',
      base_charge: '', per_km_charge: '', max_charge: '',
      max_delivery_km: '', is_active: true,
    })
    setModalError(null)
    setModal({ open: true, rule: null })
  }

  const openEdit = (rule) => {
    reset({
      name: rule.name,
      min_order_amount: rule.min_order_amount ?? '',
      free_delivery_above: rule.free_delivery_above ?? '',
      base_charge: rule.base_charge,
      per_km_charge: rule.per_km_charge ?? '',
      max_charge: rule.max_charge ?? '',
      max_delivery_km: rule.max_delivery_km ?? '',
      is_active: rule.is_active,
    })
    setModalError(null)
    setModal({ open: true, rule })
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = {
        ...data,
        min_order_amount: data.min_order_amount ?? 0,
        free_delivery_above: data.free_delivery_above ?? null,
        per_km_charge: data.per_km_charge ?? 0,
        max_charge: data.max_charge ?? null,
        max_delivery_km: data.max_delivery_km ?? null,
      }
      if (isEdit) {
        await api.put(`/masters/delivery-charges/${modal.rule.id}`, payload)
      } else {
        await api.post('/masters/delivery-charges', payload)
      }
      setModal({ open: false, rule: null })
      fetchRules()
    } catch (e) {
      const apiMessage = e.response?.data?.errors
        ? Object.values(e.response.data.errors).flat().join(' ')
        : e.response?.data?.message
      setModalError(apiMessage ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/delivery-charges/${deleteModal.rule.id}`)
      setDeleteModal({ open: false, rule: null })
      fetchRules()
    } catch (e) {
      const apiMessage = e.response?.data?.errors
        ? Object.values(e.response.data.errors).flat().join(' ')
        : e.response?.data?.message
      setError(apiMessage ?? 'Delete failed.')
      setDeleteModal({ open: false, rule: null })
    }
  }

  const toggleActive = async (rule) => {
    try {
      await api.patch(`/masters/delivery-charges/${rule.id}/toggle`)
      fetchRules()
    } catch (e) {
      const apiMessage = e.response?.data?.errors
        ? Object.values(e.response.data.errors).flat().join(' ')
        : e.response?.data?.message
      setError(apiMessage ?? 'Status update failed.')
    }
  }

  const field = (label, name, opts = {}) => (
    <div className={opts.col ?? 'col-md-4'}>
      <CFormLabel className="filter-label">
        {label}
        {opts.required && <span className="text-danger"> *</span>}
      </CFormLabel>
      <CFormInput
        className="filter-input"
        type="number"
        step="0.01"
        invalid={!!errors[name]}
        {...register(name)}
        placeholder={opts.placeholder ?? ''}
      />
      {errors[name] && <div className="text-danger small mt-1">{errors[name].message}</div>}
      {opts.hint && <div className="text-muted small mt-1">{opts.hint}</div>}
    </div>
  )

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">Delivery Charge Rules</h4>
            <div className="report-shell__subtitle">
              <CIcon icon={cilInfo} />
              <span>Only one rule can be active at a time — activating one deactivates others</span>
            </div>
          </div>
          <CButton size="sm" className="report-shell__export" onClick={openCreate}>
            <CIcon icon={cilPlus} className="me-2" />
            Add Rule
          </CButton>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading delivery rules...</div>
            </div>
          ) : (
            <CTable hover responsive bordered className="admin-data-table">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Name</CTableHeaderCell>
                  <CTableHeaderCell>Min Order</CTableHeaderCell>
                  <CTableHeaderCell>Free Above</CTableHeaderCell>
                  <CTableHeaderCell>Base Charge</CTableHeaderCell>
                  <CTableHeaderCell>Per KM</CTableHeaderCell>
                  <CTableHeaderCell>Max Charge</CTableHeaderCell>
                  <CTableHeaderCell>Max KM</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                  <CTableHeaderCell>Actions</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {rules.length === 0 ? (
                  <CTableRow>
                    <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                      No delivery charge rules yet. Add one to enable ordering.
                    </CTableDataCell>
                  </CTableRow>
                ) : (
                  rules.map((r) => (
                    <CTableRow key={r.id}>
                      <CTableDataCell>
                        <strong>{r.name}</strong>
                        {r.has_inconsistent_cap && (
                          <CBadge
                            color="danger"
                            shape="rounded-pill"
                            className="ms-2"
                            title="max_charge is below base_charge — distance is never factored in"
                          >
                            Broken cap
                          </CBadge>
                        )}
                      </CTableDataCell>
                      <CTableDataCell>{r.min_order_amount > 0 ? `₹${r.min_order_amount}` : '—'}</CTableDataCell>
                      <CTableDataCell>
                        {r.free_delivery_above ? <CBadge color="success" shape="rounded-pill">₹{r.free_delivery_above}</CBadge> : '—'}
                      </CTableDataCell>
                      <CTableDataCell>₹{r.base_charge}</CTableDataCell>
                      <CTableDataCell>{r.per_km_charge > 0 ? `₹${r.per_km_charge}` : '—'}</CTableDataCell>
                      <CTableDataCell>{r.max_charge ? `₹${r.max_charge}` : '—'}</CTableDataCell>
                      <CTableDataCell>{r.max_delivery_km ? `${r.max_delivery_km} km` : '—'}</CTableDataCell>
                      <CTableDataCell>
                        <CBadge
                          color={r.is_active ? 'success' : 'secondary'}
                          shape="rounded-pill"
                          style={{ cursor: 'pointer' }}
                          onClick={() => toggleActive(r)}
                        >
                          {r.is_active ? 'Active' : 'Inactive'}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <div className="d-flex gap-1 justify-content-center">
                          <CButton size="sm" className="table-action-btn" onClick={() => openEdit(r)} title="Edit">
                            <CIcon icon={cilPencil} />
                          </CButton>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => setDeleteModal({ open: true, rule: r })}
                            disabled={r.is_active}
                            title={r.is_active ? 'Deactivate before deleting' : 'Delete'}
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  ))
                )}
              </CTableBody>
            </CTable>
          )}
        </CCardBody>
      </CCard>

      <CModal
        size="lg"
        visible={modal.open}
        onClose={() => setModal({ open: false, rule: null })}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Delivery Rule' : 'Add Delivery Rule'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="row g-3">
              <div className="col-12">
                <CFormLabel className="filter-label">
                  Rule Name <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  invalid={!!errors.name}
                  {...register('name')}
                  placeholder="e.g. Standard Delivery"
                />
                {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
              </div>

              {field('Minimum Order Amount (₹)', 'min_order_amount', { hint: 'Orders below this amount are blocked', placeholder: '0' })}
              {field('Free Delivery Above (₹)', 'free_delivery_above', { hint: 'Leave blank if no free delivery threshold', placeholder: 'e.g. 500' })}
              {field('Base Charge (₹)', 'base_charge', { required: true, hint: 'Flat charge applied to every order', placeholder: 'e.g. 30' })}
              {field('Per KM Charge (₹)', 'per_km_charge', { hint: 'Added per km beyond base, 0 for flat only', placeholder: 'e.g. 5' })}
              {field('Maximum Charge (₹)', 'max_charge', { hint: 'Must be ≥ base charge, or distance stops mattering', placeholder: 'e.g. 100' })}
              {field('Max Delivery Distance (KM)', 'max_delivery_km', { hint: 'Orders beyond this distance are blocked', placeholder: 'e.g. 10' })}

              <div className="col-12">
                <div className="d-flex align-items-center gap-2">
                  <CFormCheck {...register('is_active')} id="rule_active" defaultChecked />
                  <label htmlFor="rule_active" style={{ cursor: 'pointer' }}>
                    Set as active rule
                    <small className="text-muted ms-2">(will deactivate other rules)</small>
                  </label>
                </div>
              </div>

              <div className="col-12">
                <div className="report-help-box">
                  <strong>Formula:</strong> charge = MIN(max_charge, base_charge + distance_km × per_km_charge)
                  <br />
                  If subtotal ≥ free_delivery_above → charge = 0
                  <br />
                  If subtotal &lt; min_order_amount → order blocked
                  <br />
                  If distance &gt; max_delivery_km → order blocked
                </div>
              </div>
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={() => setModal({ open: false, rule: null })}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, rule: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Delete rule <strong>{deleteModal.rule?.name}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, rule: null })}
          >
            Cancel
          </CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default DeliveryCharges