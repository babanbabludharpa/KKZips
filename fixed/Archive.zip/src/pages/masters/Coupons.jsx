import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CFormCheck, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilPencil, cilTrash } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'
import { formatDate } from '../../utils/formatters'

const today = new Date().toISOString().slice(0, 10)

const emptyToUndefined = (v, o) => (o === '' ? undefined : v)

const schema = yup.object({
  code: yup.string().required('Code is required')
    .matches(/^[A-Z0-9_]+$/, 'Only uppercase letters, numbers, underscores'),
  description: yup.string().nullable().optional(),
  type: yup.string().required('Type is required'),
  value: yup.number().typeError('Must be a number').min(0.01).required('Value is required'),
  min_order_amount: yup.number().typeError('Must be a number').min(0).nullable().optional()
    .transform(emptyToUndefined),
  max_discount_amount: yup.number().typeError('Must be a number').min(0).nullable().optional()
    .transform(emptyToUndefined),
  usage_limit_total: yup.number().typeError('Must be a whole number').integer('Must be a whole number').min(1).nullable().optional()
    .transform(emptyToUndefined),
  usage_limit_per_customer: yup.number().typeError('Must be a whole number').integer('Must be a whole number').min(1).nullable().optional()
    .transform(emptyToUndefined)
    .test(
      'per-customer-lte-total',
      'Per-customer limit cannot exceed total usage limit',
      function (value) {
        const { usage_limit_total } = this.parent
        if (value == null || usage_limit_total == null) return true
        return value <= usage_limit_total
      }
    ),
  valid_from: yup.string().required('Valid from is required'),
  valid_until: yup.string().nullable().optional()
    .test(
      'after-valid-from',
      'Valid until must be on or after valid from',
      function (value) {
        const { valid_from } = this.parent
        if (!value || !valid_from) return true
        return value >= valid_from
      }
    ),
  is_first_order_only: yup.boolean().optional(),
  is_active: yup.boolean().optional(),
})

// Header column key -> backend sort key (must match CouponService::SORTABLE)
const SORT_KEY_MAP = {
  code:        'code',
  type:        'type',
  value:       'value',
  valid_from:  'valid_from',
  valid_until: 'valid_until',
  used_count:  'used_count',
  is_active:   'is_active',
  created_at:  'created_at',
}

const Coupons = () => {
  const [coupons, setCoupons] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modal, setModal] = useState({ open: false, coupon: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, coupon: null })
  const [modalError, setModalError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const requestSeq = useRef(0)

  const isEdit = !!modal.coupon

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      code: '', description: '', type: 'flat', value: '',
      min_order_amount: '', max_discount_amount: '',
      usage_limit_total: '', usage_limit_per_customer: '',
      valid_from: '', valid_until: '',
      is_first_order_only: false, is_active: true,
    },
  })

  const watchType = watch('type')

  const buildParams = (useSearch, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, message, data: { data: [...rows], meta: {...} } }
  const fetchCoupons = async ({
    page = 1,
    searchOverride = appliedSearch,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(searchOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/masters/coupons', { params })

      if (mySeq !== requestSeq.current) return

      const responseData = res.data?.data
      const dataArray = responseData?.data ?? []
      const paginationMeta = responseData?.meta ?? {}

      setCoupons(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setCoupons([])
      setError(err.response?.data?.message ?? 'Failed to load coupons.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCoupons({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchCoupons({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => {
    goToPage(page, fetchCoupons)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchCoupons)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchCoupons({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const openCreate = () => {
    reset({
      code: '', description: '', type: 'flat', value: '',
      min_order_amount: '', max_discount_amount: '',
      usage_limit_total: '', usage_limit_per_customer: '',
      valid_from: new Date().toISOString().slice(0, 10),
      valid_until: '', is_first_order_only: false, is_active: true,
    })
    setModalError(null)
    setModal({ open: true, coupon: null })
  }

  const openEdit = (coupon) => {
    reset({
      code: coupon.code,
      description: coupon.description ?? '',
      type: coupon.type,
      value: coupon.value,
      min_order_amount: coupon.min_order_amount ?? '',
      max_discount_amount: coupon.max_discount_amount ?? '',
      usage_limit_total: coupon.usage_limit_total ?? '',
      usage_limit_per_customer: coupon.usage_limit_per_customer ?? '',
      valid_from: coupon.valid_from,
      valid_until: coupon.valid_until ?? '',
      is_first_order_only: coupon.is_first_order_only,
      is_active: coupon.is_active,
    })
    setModalError(null)
    setModal({ open: true, coupon })
  }

  const closeModal = () => {
    setModal({ open: false, coupon: null })
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      // After the yup transform, empty optional numerics arrive as `undefined`.
      // Send explicit `null` for those (not `0`, not an omitted key) so the
      // backend's `nullable|numeric` rules receive a value it can act on.
      const payload = {
        ...data,
        min_order_amount: data.min_order_amount ?? 0,
        max_discount_amount: data.max_discount_amount ?? null,
        usage_limit_total: data.usage_limit_total ?? null,
        usage_limit_per_customer: data.usage_limit_per_customer ?? null,
        valid_until: data.valid_until || null,
      }

      if (isEdit) {
        await api.put(`/masters/coupons/${modal.coupon.id}`, payload)
      } else {
        await api.post('/masters/coupons', payload)
      }
      closeModal()
      fetchCoupons()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/coupons/${deleteModal.coupon.id}`)
      setDeleteModal({ open: false, coupon: null })
      fetchCoupons()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
      setDeleteModal({ open: false, coupon: null })
    }
  }

  const toggleActive = async (coupon) => {
    try {
      await api.patch(`/masters/coupons/${coupon.id}/toggle`)
      fetchCoupons()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const isExpired = (coupon) => {
    if (!coupon.valid_until) return false
    return coupon.valid_until < today
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Coupons</h4>
          <PermissionGate permission="coupon.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Coupon
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search code or description..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading coupons...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <SortableHeader colKey="code">Code</SortableHeader>
                    <SortableHeader colKey="type">Type</SortableHeader>
                    <SortableHeader colKey="value">Value</SortableHeader>
                    <CTableHeaderCell>Min Order</CTableHeaderCell>
                    <SortableHeader colKey="valid_from">Valid From</SortableHeader>
                    <SortableHeader colKey="valid_until">Valid Until</SortableHeader>
                    <SortableHeader colKey="used_count">Used</SortableHeader>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {coupons.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No coupons found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    coupons.map((c) => (
                      <CTableRow key={c.id}>
                        <CTableDataCell>
                          <CBadge color="primary" shape="rounded-pill" className="font-monospace">
                            {c.code}
                          </CBadge>
                          {c.is_first_order_only && (
                            <CBadge color="info" shape="rounded-pill" className="ms-1">
                              1st order
                            </CBadge>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={c.type === 'flat' ? 'secondary' : 'warning'}
                            shape="rounded-pill"
                          >
                            {c.type === 'flat' ? 'Flat ₹' : 'Percent %'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <strong>
                            {c.type === 'flat' ? `₹${c.value}` : `${c.value}%`}
                          </strong>
                          {c.max_discount_amount && (
                            <small className="text-muted ms-1">
                              (max ₹{c.max_discount_amount})
                            </small>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>
                          {c.min_order_amount > 0 ? `₹${c.min_order_amount}` : '—'}
                        </CTableDataCell>
                        <CTableDataCell>{formatDate(c.valid_from)}</CTableDataCell>
                        <CTableDataCell>
                          {c.valid_until
                            ? formatDate(c.valid_until)
                            : <span className="text-muted">No expiry</span>}
                          {isExpired(c) && (
                            <CBadge color="danger" shape="rounded-pill" className="ms-1">
                              Expired
                            </CBadge>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>
                          {c.used_count}
                          {c.usage_limit_total && (
                            <span className="text-muted"> / {c.usage_limit_total}</span>
                          )}
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={c.is_active && !isExpired(c) ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(c)}
                            title="Click to toggle"
                          >
                            {c.is_active && !isExpired(c) ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="coupon.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(c)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="coupon.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, coupon: c })}
                                disabled={c.used_count > 0}
                                title={c.used_count > 0 ? 'Cannot delete a used coupon' : 'Delete'}
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal
        size="lg"
        visible={modal.open}
        onClose={closeModal}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Coupon' : 'Add Coupon'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="row g-3">
              {/* Code */}
              <div className="col-md-6">
                <CFormLabel className="filter-label">
                  Code <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  invalid={!!errors.code}
                  {...register('code')}
                  placeholder="e.g. SAVE20"
                  onChange={(e) =>
                    setValue('code', e.target.value.toUpperCase(), {
                      shouldValidate: true,
                      shouldDirty: true,
                    })
                  }
                  disabled={isEdit}
                  style={{ textTransform: 'uppercase' }}
                />
                {errors.code && (
                  <div className="text-danger small mt-1">{errors.code.message}</div>
                )}
                <div className="text-muted small mt-1">
                  Uppercase letters, numbers, underscores only
                </div>
              </div>

              {/* Description */}
              <div className="col-md-6">
                <CFormLabel className="filter-label">Description</CFormLabel>
                <CFormInput
                  className="filter-input"
                  {...register('description')}
                  placeholder="e.g. 20% off on all orders"
                />
              </div>

              {/* Type */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  Type <span className="text-danger">*</span>
                </CFormLabel>
                <CFormSelect
                  className="filter-input"
                  invalid={!!errors.type}
                  {...register('type')}
                >
                  <option value="flat">Flat Amount (₹)</option>
                  <option value="percent">Percentage (%)</option>
                </CFormSelect>
              </div>

              {/* Value */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  {watchType === 'flat' ? 'Discount Amount (₹)' : 'Discount Percent (%)'}
                  <span className="text-danger"> *</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.value}
                  {...register('value')}
                  placeholder={watchType === 'flat' ? 'e.g. 50' : 'e.g. 20'}
                />
                {errors.value && (
                  <div className="text-danger small mt-1">{errors.value.message}</div>
                )}
                {watchType === 'percent' && !errors.value && (
                  <div className="text-muted small mt-1">Must be 100 or less</div>
                )}
              </div>

              {/* Max discount */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  Max Discount (₹)
                  <small className="text-muted ms-1">
                    {watchType === 'percent' ? '(cap for % coupons)' : '(N/A for flat)'}
                  </small>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.max_discount_amount}
                  {...register('max_discount_amount')}
                  disabled={watchType === 'flat'}
                  placeholder="Leave blank for no cap"
                />
                {errors.max_discount_amount && (
                  <div className="text-danger small mt-1">
                    {errors.max_discount_amount.message}
                  </div>
                )}
              </div>

              {/* Min order */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">Minimum Order Amount (₹)</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  step="0.01"
                  invalid={!!errors.min_order_amount}
                  {...register('min_order_amount')}
                  placeholder="0"
                />
                {errors.min_order_amount && (
                  <div className="text-danger small mt-1">{errors.min_order_amount.message}</div>
                )}
              </div>

              {/* Usage limit total */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">Total Usage Limit</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  invalid={!!errors.usage_limit_total}
                  {...register('usage_limit_total')}
                  placeholder="Leave blank for unlimited"
                />
                {errors.usage_limit_total && (
                  <div className="text-danger small mt-1">
                    {errors.usage_limit_total.message}
                  </div>
                )}
              </div>

              {/* Usage limit per customer */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">Per Customer Limit</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="number"
                  invalid={!!errors.usage_limit_per_customer}
                  {...register('usage_limit_per_customer')}
                  placeholder="Leave blank for unlimited"
                />
                {errors.usage_limit_per_customer && (
                  <div className="text-danger small mt-1">
                    {errors.usage_limit_per_customer.message}
                  </div>
                )}
              </div>

              {/* Valid from */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">
                  Valid From <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="date"
                  min={today}
                  invalid={!!errors.valid_from}
                  {...register('valid_from')}
                />
                {errors.valid_from && (
                  <div className="text-danger small mt-1">{errors.valid_from.message}</div>
                )}
              </div>

              {/* Valid until */}
              <div className="col-md-4">
                <CFormLabel className="filter-label">Valid Until</CFormLabel>
                <CFormInput
                  className="filter-input"
                  type="date"
                  min={today}
                  invalid={!!errors.valid_until}
                  {...register('valid_until')}
                />
                {errors.valid_until ? (
                  <div className="text-danger small mt-1">{errors.valid_until.message}</div>
                ) : (
                  <div className="text-muted small mt-1">Leave blank for no expiry</div>
                )}
              </div>

              {/* Flags */}
              <div className="col-md-4 d-flex align-items-center gap-3 pb-1">
                <div className="d-flex align-items-center gap-2">
                  <CFormCheck {...register('is_first_order_only')} id="first_order" />
                  <label
                    htmlFor="first_order"
                    className="small mb-0"
                    style={{ cursor: 'pointer' }}
                  >
                    First order only
                  </label>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <CFormCheck {...register('is_active')} id="is_active" defaultChecked />
                  <label
                    htmlFor="is_active"
                    className="small mb-0"
                    style={{ cursor: 'pointer' }}
                  >
                    Active
                  </label>
                </div>
              </div>
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, coupon: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Delete coupon <strong>{deleteModal.coupon?.code}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, coupon: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Coupons