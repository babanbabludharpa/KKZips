import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CCard, CCardBody, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CBadge } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus } from '@coreui/icons'
import api from '../../../api/api'
import SubscriptionDrillIn from './SubscriptionDrillIn'
import Pagination from '../../../components/Pagination'

const STATUS_COLORS = {
  active: 'success',
  paused: 'warning',
  cancelled: 'danger',
  expired: 'secondary',
}

export default function SubscriptionsTab({ customer }) {
  const navigate = useNavigate()
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)
  const [selectedSub, setSelectedSub] = useState(null)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/subscriptions`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 d-flex justify-content-between align-items-center border-bottom">
          <h6 className="m-0 fw-bold">Subscriptions</h6>
          <CButton
            size="sm"
            className="filter-btn filter-btn--primary"
            onClick={() => navigate(`/subscriptions/new?customer_id=${customer.id}`)}
          >
            <CIcon icon={cilPlus} className="me-1" size="sm" /> Add Subscription
          </CButton>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Sr No</CTableHeaderCell>
                  <CTableHeaderCell className="text-start">Product</CTableHeaderCell>
                  <CTableHeaderCell>Schedule</CTableHeaderCell>
                  <CTableHeaderCell>Duration</CTableHeaderCell>
                  <CTableHeaderCell>Time</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={6}>No subscriptions found.</CTableDataCell></CTableRow>
                ) : data.map((sub, index) => {
                  const offset = ((meta.current_page || 1) - 1) * (meta.per_page || 25)
                  return (
                    <CTableRow key={sub.id} style={{ cursor: 'pointer' }} onClick={() => setSelectedSub(sub)}>
                      <CTableDataCell>{offset + index + 1}</CTableDataCell>
                      <CTableDataCell className="text-start fw-semibold">{sub.product}</CTableDataCell>
                      <CTableDataCell>{sub.schedule}</CTableDataCell>
                      <CTableDataCell>{sub.duration}</CTableDataCell>
                      <CTableDataCell>{sub.time}</CTableDataCell>
                      <CTableDataCell>
                        <CBadge color={STATUS_COLORS[sub.status] || 'secondary'} shape="rounded-pill">
                          {sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
                        </CBadge>
                      </CTableDataCell>
                    </CTableRow>
                  )
                })}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>

      {selectedSub && (
        <SubscriptionDrillIn
          sub={selectedSub}
          customer={customer}
          onClose={() => setSelectedSub(null)}
          refreshParent={() => load(meta.current_page || 1)}
        />
      )}
    </CCard>
  )
}