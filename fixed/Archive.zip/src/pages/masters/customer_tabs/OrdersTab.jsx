import { useEffect, useState } from 'react'
import { CCard, CCardBody, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CBadge } from '@coreui/react'
import api from '../../../api/api'
import { formatDate } from '../../../utils/formatters'
import Pagination from '../../../components/Pagination'

const PAYMENT_STATUS_BADGE = {
  pending: 'warning',
  paid: 'success',
  failed: 'danger',
  refunded: 'secondary',
}

const ORDER_STATUS_BADGE = {
  pending_payment: 'warning',
  confirmed: 'info',
  preparing: 'info',
  out_for_delivery: 'primary',
  picked_up: 'primary',
  delivered: 'success',
  payment_failed: 'danger',
  expired: 'secondary',
  cancelled: 'danger',
}

const PAYMENT_MODE_LABEL = {
  cod: 'COD',
  online: 'Online',
  wallet: 'Wallet',
}

export default function OrdersTab({ customer }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/orders`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

  const openInNewTab = (orderId) => {
    const base = import.meta.env.PROD ? '/admin' : ''
    window.open(`${base}/orders/${orderId}`, '_blank', 'noopener,noreferrer')
  }

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 border-bottom">
          <h6 className="m-0 fw-bold">Orders</h6>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Order #</CTableHeaderCell>
                  <CTableHeaderCell>Date</CTableHeaderCell>
                  <CTableHeaderCell>Branch</CTableHeaderCell>
                  <CTableHeaderCell>Items</CTableHeaderCell>
                  <CTableHeaderCell>Payment</CTableHeaderCell>
                  <CTableHeaderCell>Total</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                  <CTableHeaderCell style={{ width: 80 }}></CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={8}>No orders found.</CTableDataCell></CTableRow>
                ) : data.map(o => (
                  <CTableRow key={o.id}>
                    <CTableDataCell className="fw-semibold">{o.order_number || `#${o.id}`}</CTableDataCell>
                    <CTableDataCell>{formatDate(o.created_at)}</CTableDataCell>
                    <CTableDataCell>{o.branch_name || '—'}</CTableDataCell>
                    <CTableDataCell>
                      {o.line_count} {o.line_count === 1 ? 'item' : 'items'} ({o.total_qty} qty)
                    </CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={PAYMENT_STATUS_BADGE[o.payment_status] || 'secondary'} shape="rounded-pill" className="me-1">
                        {PAYMENT_MODE_LABEL[o.payment_mode] || o.payment_mode}
                      </CBadge>
                      <CBadge color={PAYMENT_STATUS_BADGE[o.payment_status] || 'secondary'} shape="rounded-pill">
                        {o.payment_status}
                      </CBadge>
                    </CTableDataCell>
                    <CTableDataCell>₹{Number(o.total).toFixed(2)}</CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={ORDER_STATUS_BADGE[o.status] || 'secondary'} shape="rounded-pill">
                        {o.status.replace(/_/g, ' ')}
                      </CBadge>
                    </CTableDataCell>
                    <CTableDataCell>
                      <CButton size="sm" className="table-action-btn" onClick={() => openInNewTab(o.id)}>
                        View
                      </CButton>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>
    </CCard>
  )
}