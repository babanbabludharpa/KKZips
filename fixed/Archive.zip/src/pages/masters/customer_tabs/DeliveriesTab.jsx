import { useEffect, useState } from 'react'
import { CCard, CCardBody, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CBadge } from '@coreui/react'
import api from '../../../api/api'
import { formatDate } from '../../../utils/formatters'
import Pagination from '../../../components/Pagination'

const STATUS_BADGE = {
  delivered: 'success',
  out_for_delivery: 'info',
  not_delivered: 'danger',
  holiday_skipped: 'warning',
  cancelled: 'dark',
}

export default function DeliveriesTab({ customer }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/deliveries`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 border-bottom">
          <h6 className="m-0 fw-bold">Deliveries</h6>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Date</CTableHeaderCell>
                  <CTableHeaderCell className="text-start">Product</CTableHeaderCell>
                  <CTableHeaderCell>Type</CTableHeaderCell>
                  <CTableHeaderCell>Qty</CTableHeaderCell>
                  <CTableHeaderCell>Rate</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={6}>No delivery history found.</CTableDataCell></CTableRow>
                ) : data.map(d => (
                  <CTableRow key={`${d.type}-${d.id}`}>
                    <CTableDataCell>{formatDate(d.delivery_date)}</CTableDataCell>
                    <CTableDataCell className="text-start fw-semibold">{d.product_name}</CTableDataCell>
                    <CTableDataCell>
                      <CBadge color="secondary" shape="rounded-pill">{d.type}</CBadge>
                    </CTableDataCell>
                    <CTableDataCell>{d.qty}</CTableDataCell>
                    <CTableDataCell>₹{Number(d.rate).toFixed(2)}</CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={STATUS_BADGE[d.status] || 'secondary'} shape="rounded-pill">
                        {d.status.replace('_', ' ')}
                      </CBadge>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>
    </CCard>
  )
}