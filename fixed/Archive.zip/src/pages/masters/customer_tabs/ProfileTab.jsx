import { useState } from 'react'
import { CCard, CCardBody, CButton, CRow, CCol, CBadge, CFormSwitch, CModal, CModalHeader, CModalBody, CModalFooter, CForm, CFormInput, CFormLabel, CAlert } from '@coreui/react'
import api from '../../../api/api'
import { formatDate, formatDateTime } from '../../../utils/formatters'
import ManageAddressesModal from './ManageAddressesModal'

const DetailRow = ({ label, value }) => (
  <div className="d-flex border-bottom py-2">
    <div style={{ width: '40%', fontSize: '0.85rem', color: 'var(--text-soft)' }}>{label}</div>
    <div className="fw-semibold" style={{ width: '60%', fontSize: '0.85rem', color: 'var(--rep-title)' }}>{value || '—'}</div>
  </div>
)

export default function ProfileTab({ data, reload }) {
  const { customer: c, balance, last_delivery_date, effective_warning_limit, effective_suspension_limit } = data
  
  const [addrModal, setAddrModal] = useState(false)
  const [editModal, setEditModal] = useState(false)
  
  const [form, setForm] = useState({ name: c.name, email: c.email, warning_limit: effective_warning_limit, suspension_limit: effective_suspension_limit })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)

  const toggleDnd = async (e) => {
    await api.patch(`/masters/customers/${c.id}/settings`, { dnd: e.target.checked })
    reload()
  }

  const openEdit = () => {
    setForm({ name: c.name, email: c.email, warning_limit: effective_warning_limit, suspension_limit: effective_suspension_limit })
    setError(null)
    setEditModal(true)
  }

  const saveProfile = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      await api.put(`/masters/customers/${c.id}/profile`, form)
      setEditModal(false)
      reload()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save changes.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <CRow className="g-3">
      {/* Left Column - Summary */}
      <CCol md={7}>
        <CCard
          className="border-0 h-100"
          style={{
            borderRadius: 'var(--rep-radius)',
            boxShadow: 'var(--shadow-sm)',
            background: 'var(--bg-surface)',
          }}
        >
          <CCardBody className="p-4">
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h6 className="m-0 fw-bold" style={{ color: 'var(--rep-title)' }}>Profile</h6>
              <CButton size="sm" className="filter-btn filter-btn--primary" onClick={openEdit}>Edit</CButton>
            </div>
            
            <DetailRow label="Name" value={c.name} />
            <DetailRow label="Phone" value={c.phone} />
            <DetailRow label="Email" value={c.email} />
            
            <div
              className="d-flex border-bottom py-2 align-items-center px-2 mb-2 rounded"
              style={{ background: 'var(--bg-inset)' }}
            >
              <div style={{ width: '40%', fontSize: '0.85rem', color: 'var(--text-soft)' }}>DND</div>
              <div style={{ width: '60%' }}>
                <CFormSwitch checked={c.dnd} onChange={toggleDnd} />
              </div>
            </div>

            <DetailRow label="Last Delivery Date" value={last_delivery_date ? formatDate(last_delivery_date) : '—'} />
            <DetailRow label="Is Active?" value={c.status === 'active' ? 'YES' : 'NO'} />
            <DetailRow label="Created By" value="Self" />
            <DetailRow label="Registered On" value={formatDate(c.created_at)} />
            <DetailRow label="Warning Limit" value={`₹${effective_warning_limit}`} />
            <DetailRow label="Suspension Limit" value={`₹${effective_suspension_limit}`} />
          </CCardBody>
        </CCard>
      </CCol>

      {/* Right Column - Address */}
      <CCol md={5}>
        <CCard
          className="border-0 h-100"
          style={{
            borderRadius: 'var(--rep-radius)',
            boxShadow: 'var(--shadow-sm)',
            background: 'var(--bg-surface)',
          }}
        >
          <CCardBody className="p-4">
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h6 className="m-0 fw-bold" style={{ color: 'var(--rep-title)' }}>Address</h6>
              <CButton size="sm" className="filter-btn filter-btn--primary" onClick={() => setAddrModal(true)}>
                + Manage Address
              </CButton>
            </div>

            {c.addresses?.find(a => a.is_default) ? (
              (() => {
                const a = c.addresses.find(x => x.is_default);
                return (
                  <div className="p-3 border rounded" style={{ borderColor: 'var(--rep-border)', background: 'var(--bg-inset)' }}>
                    <div className="d-flex justify-content-between mb-2">
                       <strong style={{ color: 'var(--rep-title)' }}>{a.label}</strong>
                       <CBadge color="success" shape="rounded-pill">Default</CBadge>
                    </div>
                    <div className="small mb-1" style={{ color: 'var(--text-soft)' }}>{a.address_line1}, {a.address_line2}</div>
                    <div className="small mb-1" style={{ color: 'var(--text-soft)' }}>PIN: {a.pincode}</div>
                    <div className="small mb-1" style={{ color: 'var(--text-soft)' }}>City: {a.city}</div>
                    <div className="small mb-1" style={{ color: 'var(--text-soft)' }}>State: {a.state}</div>
                    <div className="small" style={{ color: 'var(--text-soft)' }}>Route: {a.zone?.name || '—'}</div>
                  </div>
                )
              })()
            ) : (
              <div className="small text-center py-4" style={{ color: 'var(--text-soft)' }}>No default address set.</div>
            )}
          </CCardBody>
        </CCard>
      </CCol>

      <ManageAddressesModal 
        open={addrModal} 
        onClose={() => setAddrModal(false)} 
        customerId={c.id} 
        addresses={c.addresses}
        reload={reload}
      />

      {/* Notes Card */}
      <CCol xs={12}>
        <CCard
          className="border-0"
          style={{
            borderRadius: 'var(--rep-radius)',
            boxShadow: 'var(--shadow-sm)',
            background: 'var(--bg-surface)',
          }}
        >
          <CCardBody className="p-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="m-0 fw-bold" style={{ color: 'var(--rep-title)' }}>Internal Notes</h6>
            </div>
            {(c.notes || []).length === 0 ? (
              <div className="small" style={{ color: 'var(--text-soft)' }}>No notes yet.</div>
            ) : (
              <div className="d-flex flex-column gap-2">
                {(c.notes || []).map(note => (
                  <div
                    key={note.id}
                    className="p-3 border rounded"
                    style={{
                      background: 'var(--bg-inset)',
                      borderColor: 'var(--rep-border)',
                      borderLeft: '3px solid var(--accent)',
                    }}
                  >
                    <div className="small mb-1" style={{ color: 'var(--rep-title)' }}>{note.note}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-soft)' }}>
                      {note.addedBy?.name || 'System'} · {formatDateTime(note.created_at)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CCardBody>
        </CCard>
      </CCol>

      {/* Edit Profile Modal */}
      <CModal visible={editModal} onClose={() => setEditModal(false)} backdrop="static">
        <CModalHeader>Edit Profile</CModalHeader>
        <CForm onSubmit={saveProfile}>
          <CModalBody>
            {error && <CAlert color="danger">{error}</CAlert>}
            
            <div className="mb-3">
              <CFormLabel className="filter-label">Name</CFormLabel>
              <CFormInput value={form.name} onChange={e => setForm({...form, name: e.target.value})} required />
            </div>
            <div className="mb-3">
              <CFormLabel className="filter-label">Email</CFormLabel>
              <CFormInput type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} required />
            </div>
            <div className="row g-2 mb-3">
              <div className="col-6">
                <CFormLabel className="filter-label">Warning Limit (₹)</CFormLabel>
                <CFormInput type="number" value={form.warning_limit} onChange={e => setForm({...form, warning_limit: e.target.value})} />
              </div>
              <div className="col-6">
                <CFormLabel className="filter-label">Suspension Limit (₹)</CFormLabel>
                <CFormInput type="number" value={form.suspension_limit} onChange={e => setForm({...form, suspension_limit: e.target.value})} />
              </div>
            </div>
          </CModalBody>
          <CModalFooter>
            <CButton className="filter-btn filter-btn--ghost" onClick={() => setEditModal(false)} disabled={saving}>Cancel</CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</CButton>
          </CModalFooter>
        </CForm>
      </CModal>
    </CRow>
  )
}