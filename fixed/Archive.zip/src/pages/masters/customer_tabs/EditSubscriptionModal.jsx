import { useState, useEffect } from 'react'
import { CSpinner, CFormCheck } from '@coreui/react'
import api from '../../../api/api'

export default function EditSubscriptionModal({ sub, customer, onClose, refreshParent }) {
  const [loading, setLoading] = useState(true)
  const [slots, setSlots] = useState([])
  const [instructions, setInstructions] = useState([])
  
  const [form, setForm] = useState({
    slot_id: '',
    auto_renew: true,
    delivery_instruction_id: '', // Changed to ID
    schedule_type: 'alternate',
    first_day: 1,
    second_day: 0
  })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let cancelled = false
    api.get(`/masters/customers/${customer.id}/subscriptions/${sub.id}`)
      .then(res => {
        if (cancelled) return
        const fullSub = res.data.data.subscription;
        const masterData = res.data.data.master_data;
        
        setSlots(masterData.slots || [])
        setInstructions(masterData.instructions || [])
        
        const firstItem = fullSub.items?.[0];
        setForm({
          slot_id: firstItem?.slot_id || '',
          auto_renew: fullSub.auto_renew ?? true,
          delivery_instruction_id: fullSub.delivery_instruction_id || '', // Read ID
          schedule_type: firstItem?.schedule_type || 'alternate',
          first_day: 1,
          second_day: 0
        })
      })
      .catch(err => console.error("Failed to load edit data", err))
      .finally(() => { if (!cancelled) setLoading(false) })
      
    return () => { cancelled = true }
  }, [sub.id, customer.id])

  const save = async () => {
    setSaving(true)
    try {
      await api.put(`/subscriptions/${sub.id}/settings`, {
        auto_renew: form.auto_renew,
        delivery_instruction_id: form.delivery_instruction_id || null, // Send ID
        slot_id: form.slot_id,
        schedule_type: form.schedule_type,
      })
      if (refreshParent) refreshParent()
      onClose()
    } catch (err) {
      console.error(err)
      alert('Failed to save settings.')
    } finally {
      setSaving(false)
    }
  }

  const formatSlot = (s) => {
    const start = s.start_time.slice(0, 5)
    const end = s.end_time.slice(0, 5)
    return `${s.name} (${start} - ${end})`
  }

  if (loading) return <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CSpinner /></div>

  return (
    <div 
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div style={{ background: '#fff', borderRadius: 12, width: '90%', maxWidth: 900, maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 10px 30px rgba(0,0,0,0.2)' }}>
        
        <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
          <h5 className="m-0 fw-bold">Permanent Change</h5>
          <button type="button" className="btn-close" onClick={(e) => { e.preventDefault(); onClose() }}></button>
        </div>

        <div className="p-4 bg-light">
          <div className="row g-4">
            
            {/* Left Column */}
            <div className="col-md-5">
              <div className="bg-white p-3 rounded shadow-sm border mb-3">
                <h6 className="fw-bold mb-3">Delivery Time</h6>
                
                <div className="d-flex flex-wrap gap-2 mb-4">
                  {slots.map(s => {
                    const isSelected = form.slot_id === s.id;
                    return (
                      <div
                        key={s.id}
                        style={{ 
                          cursor: 'pointer', padding: '5px 10px', borderRadius: 6,
                          border: `1px solid ${isSelected ? '#3A5B4A' : '#ccc'}`,
                          backgroundColor: isSelected ? '#3A5B4A' : '#fff',
                          color: isSelected ? '#fff' : '#333',
                          fontSize: '0.75rem'
                        }}
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setForm({...form, slot_id: s.id}) }}
                      >
                        {formatSlot(s)}
                      </div>
                    )
                  })}
                </div>

                <div className="d-flex align-items-center justify-content-between border-top pt-3">
                  <span className="fw-semibold text-muted small">Auto Renew</span>
                  <input 
                    type="checkbox" 
                    checked={form.auto_renew} 
                    onChange={(e) => setForm({...form, auto_renew: e.target.checked})}
                    style={{ width: 18, height: 18, cursor: 'pointer' }}
                  />
                </div>
              </div>

              <div className="bg-white p-3 rounded shadow-sm border">
                <h6 className="fw-bold mb-3">Delivery Instructions</h6>
                {instructions.map(inst => (
                  <CFormCheck
                    key={inst.id}
                    type="radio"
                    name="instructions"
                    id={`inst-${inst.id}`}
                    label={inst.label}
                    checked={form.delivery_instruction_id === inst.id} // Compare IDs
                    onChange={() => setForm({...form, delivery_instruction_id: inst.id})} // Store ID
                    className="mb-2"
                  />
                ))}
              </div>
            </div>

            {/* Right Column */}
            <div className="col-md-7">
              <div className="bg-white p-3 rounded shadow-sm border h-100">
                <h6 className="fw-bold mb-3">Schedule</h6>
                <label className="small text-muted fw-bold d-block mb-2">Type</label>
                
                <div className="d-flex gap-2 mb-4">
                  {['daily', 'alternate', 'weekly', 'Nth Day'].map(t => {
                    const isSelected = form.schedule_type === t;
                    return (
                      <div
                        key={t}
                        style={{ 
                          flex: 1, textAlign: 'center', cursor: 'pointer', padding: '6px 0', borderRadius: 6,
                          border: `1px solid ${isSelected ? '#3A5B4A' : '#ccc'}`,
                          backgroundColor: isSelected ? '#3A5B4A' : '#fff',
                          color: isSelected ? '#fff' : '#333',
                          fontSize: '0.8rem'
                        }}
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setForm({...form, schedule_type: t}) }}
                      >
                        {t.charAt(0).toUpperCase() + t.slice(1)}
                      </div>
                    )
                  })}
                </div>

                {form.schedule_type === 'alternate' && (
                  <div className="d-flex flex-column gap-3">
                    <div className="d-flex align-items-center gap-3">
                      <span className="small fw-semibold text-muted" style={{ width: 80 }}>First Day</span>
                      <div className="d-flex align-items-center">
                        <button type="button" className="btn btn-dark btn-sm" onClick={(e) => { e.preventDefault(); setForm({...form, first_day: Math.max(0, form.first_day - 1)}) }}>-</button>
                        <div style={{ width: 40, textAlign: 'center', fontWeight: 'bold' }}>{form.first_day}</div>
                        <button type="button" className="btn btn-dark btn-sm" onClick={(e) => { e.preventDefault(); setForm({...form, first_day: form.first_day + 1}) }}>+</button>
                      </div>
                    </div>
                    <div className="d-flex align-items-center gap-3">
                      <span className="small fw-semibold text-muted" style={{ width: 80 }}>Second Day</span>
                      <div className="d-flex align-items-center">
                        <button type="button" className="btn btn-dark btn-sm" onClick={(e) => { e.preventDefault(); setForm({...form, second_day: Math.max(0, form.second_day - 1)}) }}>-</button>
                        <div style={{ width: 40, textAlign: 'center', fontWeight: 'bold' }}>{form.second_day}</div>
                        <button type="button" className="btn btn-dark btn-sm" onClick={(e) => { e.preventDefault(); setForm({...form, second_day: form.second_day + 1}) }}>+</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-3 border-top d-flex justify-content-end gap-2">
          <button type="button" className="filter-btn filter-btn--ghost" onClick={(e) => { e.preventDefault(); onClose() }} disabled={saving}>Cancel</button>
          <button type="button" className="filter-btn filter-btn--primary" onClick={(e) => { e.preventDefault(); save() }} disabled={saving} style={{ backgroundColor: '#3A5B4A', color: '#fff' }}>
            {saving ? 'Saving...' : 'Save Permanent Change'}
          </button>
        </div>
      </div>
    </div>
  )
}