import { useEffect, useState } from 'react'
import { CCard, CCardBody, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CBadge, CButton } from '@coreui/react'
import api from '../../../api/api'
import Pagination from '../../../components/Pagination'
import UnbilledDeliveriesModal from './UnbilledDeliveriesModal'

export default function BillsTab({ customer }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)
  const [unbilledOpen, setUnbilledOpen] = useState(false)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/bills`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 border-bottom d-flex justify-content-between align-items-center">
          <h6 className="m-0 fw-bold">Ledger</h6>
          <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setUnbilledOpen(true)}>
            Unbilled
          </CButton>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Month</CTableHeaderCell>
                  <CTableHeaderCell>Opening Balance</CTableHeaderCell>
                  <CTableHeaderCell>Amount</CTableHeaderCell>
                  <CTableHeaderCell>Refund & Cancellation</CTableHeaderCell>
                  <CTableHeaderCell>Payment & Credit</CTableHeaderCell>
                  <CTableHeaderCell>Total Due</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={7}>No bill history found.</CTableDataCell></CTableRow>
                ) : data.map((b) => (
                  <CTableRow key={b.month}>
                    <CTableDataCell className="fw-semibold">{b.month}</CTableDataCell>
                    <CTableDataCell className={b.opening_balance < 0 ? 'text-danger' : ''}>
                      ₹{Math.abs(b.opening_balance).toFixed(2)}
                    </CTableDataCell>
                    <CTableDataCell>₹{Math.abs(b.amount).toFixed(2)}</CTableDataCell>
                    <CTableDataCell>₹{Math.abs(b.refund_cancellation).toFixed(2)}</CTableDataCell>
                    <CTableDataCell>₹{Math.abs(b.payment_credit).toFixed(2)}</CTableDataCell>
                    <CTableDataCell className={b.total_due > 0 ? 'text-danger fw-bold' : 'fw-bold'}>
                      ₹{Math.abs(b.total_due).toFixed(2)}
                    </CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={b.status === 'Paid' ? 'success' : 'warning'} shape="rounded-pill">
                        {b.status}
                      </CBadge>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>

      <UnbilledDeliveriesModal
        open={unbilledOpen}
        onClose={() => setUnbilledOpen(false)}
        customer={customer}
      />
    </CCard>
  )
}