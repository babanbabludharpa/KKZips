import { useState, useEffect } from 'react'
import { CModal, CModalHeader, CModalBody, CModalFooter, CButton, CBadge, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilSettings, cilMediaStop, cilMediaPlay, cilX, cilMediaPause, cilPlus } from '@coreui/icons'
import api from '../../../api/api'
import EditSubscriptionModal from './EditSubscriptionModal'
import AddChangeModal from './AddChangeModal'

export default function SubscriptionDrillIn({ sub, customer, onClose, refreshParent }) {
  const [changes, setChanges] = useState([])
  const [loading, setLoading] = useState(true)
  const [editOpen, setEditOpen] = useState(false)
  const [actioning, setActioning] = useState(false)
  const [changeModal, setChangeModal] = useState(null)

  const [timeline, setTimeline] = useState([])
  const [timelineLoading, setTimelineLoading] = useState(true)

  const isCancelled = sub.status === 'cancelled'

  const loadChanges = () => {
    setLoading(true)
    api.get(`/subscriptions/${sub.id}/temporary-changes`)
      .then(res => setChanges(res.data.data || []))
      .catch(err => console.error(err))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    loadChanges()

    setTimelineLoading(true)
    api.get(`/masters/customers/${customer.id}/subscriptions/${sub.id}`)
      .then(res => {
        setTimeline(res.data?.data?.timeline || [])
      })
      .catch(err => console.error('Timeline fetch failed', err))
      .finally(() => setTimelineLoading(false))
  }, [sub.id, customer.id])

  const handleStop = async () => {
    if (!window.confirm('Pause the entire subscription?')) return
    setActioning(true)
    try {
      await api.post(`/subscriptions/${sub.id}/pause`, { reason: 'Paused by admin' })
      if (refreshParent) refreshParent()
      onClose()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to pause subscription.')
    } finally {
      setActioning(false)
    }
  }

  const handleResume = async () => {
    if (!window.confirm('Resume the entire subscription?')) return
    setActioning(true)
    try {
      await api.post(`/subscriptions/${sub.id}/resume`)
      if (refreshParent) refreshParent()
      onClose()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to resume subscription.')
    } finally {
      setActioning(false)
    }
  }

  const handleTerminate = async () => {
    if (!window.confirm('Terminate this subscription permanently? This cannot be undone.')) return
    setActioning(true)
    try {
      await api.post(`/subscriptions/${sub.id}/cancel`, { reason: 'Terminated by admin' })
      if (refreshParent) refreshParent()
      onClose()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to terminate subscription.')
    } finally {
      setActioning(false)
    }
  }

  const handleDeleteChange = async (change) => {
    if (!window.confirm('Remove this change?')) return
    try {
      const endpoint = change.type === 'pause'
        ? `/subscriptions/pauses/${change.id}`
        : `/subscriptions/qty-overrides/${change.id}`
      await api.delete(endpoint)
      loadChanges()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete change.')
    }
  }

  return (
    <>
      <CModal visible={true} onClose={onClose} size="xl" backdrop="static">
        <CModalHeader className="d-flex justify-content-between align-items-center">
          <div className="fw-bold">Subscription for {sub.product}</div>
          <div className="d-flex gap-2">
            <CButton
              type="button"
              size="sm"
              color="success"
              className="text-white"
              title={isCancelled ? 'Cannot edit a cancelled subscription' : 'Edit Details'}
              onClick={() => setEditOpen(true)}
              disabled={actioning || isCancelled}
            >
              <CIcon icon={cilSettings} />
            </CButton>

            {!isCancelled && sub.status === 'active' && (
              <CButton
                type="button"
                size="sm"
                color="warning"
                className="text-white"
                title="Pause Whole Subscription"
                onClick={handleStop}
                disabled={actioning}
              >
                <CIcon icon={cilMediaStop} />
              </CButton>
            )}

            {!isCancelled && sub.status === 'paused' && (
              <CButton
                type="button"
                size="sm"
                color="info"
                className="text-white"
                title="Resume Subscription"
                onClick={handleResume}
                disabled={actioning}
              >
                <CIcon icon={cilMediaPlay} />
              </CButton>
            )}

            <CButton
              type="button"
              size="sm"
              color="danger"
              className="text-white"
              title={isCancelled ? 'Already cancelled' : 'Terminate'}
              onClick={handleTerminate}
              disabled={actioning || isCancelled || !['active', 'paused'].includes(sub.status)}
            >
              <CIcon icon={cilX} />
            </CButton>
          </div>
        </CModalHeader>

        <CModalBody className="p-4">
          <div className="row g-4">

            {/* Left: Timeline & Details */}
            <div className="col-md-7">
              <h6 className="fw-bold border-left pl-2 mb-3" style={{ borderLeft: '3px solid #3A5B4A' }}>Timeline</h6>

              {timelineLoading ? (
                <div className="text-center p-3 mb-4"><CSpinner size="sm" /></div>
              ) : timeline.length === 0 ? (
                <div className="text-muted small mb-4 border rounded p-3 text-center">
                  No timeline available.
                </div>
              ) : (
                <div className="d-flex text-center border rounded mb-4 overflow-hidden">
                  {timeline.map((day) => (
                    <div
                      key={day.date}
                      className="flex-fill border-end py-2"
                      style={
                        day.status === 'projected'
                          ? { backgroundColor: '#f8f9fa', opacity: 0.85 }
                          : undefined
                      }
                      title={day.status === 'projected' ? 'Projected — not yet generated' : ''}
                    >
                      <div className="text-muted small">{day.day}</div>
                      <div className="fw-bold">{day.day_num}</div>
                      <div className={`mt-1 small fw-bold ${day.is_off ? 'text-danger' : 'text-success'}`}>
                        {day.label}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <h6 className="fw-bold border-left pl-2 mb-3" style={{ borderLeft: '3px solid #3A5B4A' }}>Details</h6>
              <div className="p-3 border rounded bg-light">
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Product</span><strong>{sub.product}</strong>
                </div>
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Duration</span><strong>{sub.duration}</strong>
                </div>
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Delivery Time</span><strong>{sub.time}</strong>
                </div>
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Pattern</span><strong>{sub.schedule}</strong>
                </div>
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Instruction</span><strong>{sub.delivery_instruction || '—'}</strong>
                </div>
                <div className="d-flex justify-content-between py-2 border-bottom">
                  <span className="text-muted">Status</span>
                  <CBadge color={sub.status === 'active' ? 'success' : sub.status === 'paused' ? 'warning' : 'danger'}>
                    {sub.status}
                  </CBadge>
                </div>
              </div>
            </div>

            {/* Right: Temporary Changes */}
            <div className="col-md-5">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h6 className="fw-bold m-0 border-left pl-2" style={{ borderLeft: '3px solid #3A5B4A' }}>Temporary Changes</h6>

                {!isCancelled && (
                  <div className="d-flex gap-2">
                    <button type="button" className="btn btn-sm btn-outline-dark" onClick={() => setChangeModal('pause')}>
                      <CIcon icon={cilMediaPause} /> Pause Dates
                    </button>
                    <button type="button" className="btn btn-sm btn-outline-dark" onClick={() => setChangeModal('qty')}>
                      <CIcon icon={cilPlus} /> Change Qty
                    </button>
                  </div>
                )}
              </div>

              <div className="border rounded p-0 overflow-hidden">
                {loading ? (
                  <div className="text-center p-4"><CSpinner size="sm" /></div>
                ) : (
                  <CTable hover responsive className="mb-0 text-center align-middle">
                    <CTableHead>
                      <CTableRow>
                        <CTableHeaderCell>Duration</CTableHeaderCell>
                        <CTableHeaderCell>Change</CTableHeaderCell>
                        {!isCancelled && <CTableHeaderCell style={{ width: 60 }}></CTableHeaderCell>}
                      </CTableRow>
                    </CTableHead>
                    <CTableBody>
                      {changes.length === 0 ? (
                        <CTableRow>
                          <CTableDataCell colSpan={isCancelled ? 2 : 3} className="text-muted py-3">
                            No temporary changes.
                          </CTableDataCell>
                        </CTableRow>
                      ) : changes.map((c) => (
                        <CTableRow key={`${c.type}-${c.id}`}>
                          <CTableDataCell>{c.duration}</CTableDataCell>
                          <CTableDataCell className="text-danger">{c.change}</CTableDataCell>
                          {!isCancelled && (
                            <CTableDataCell>
                              <button
                                type="button"
                                className="btn btn-sm btn-link text-danger p-0"
                                onClick={() => handleDeleteChange(c)}
                                title="Remove this change"
                              >
                                <CIcon icon={cilX} />
                              </button>
                            </CTableDataCell>
                          )}
                        </CTableRow>
                      ))}
                    </CTableBody>
                  </CTable>
                )}
              </div>
            </div>
          </div>
        </CModalBody>

        <CModalFooter>
          <CButton type="button" className="filter-btn filter-btn--ghost" onClick={onClose} disabled={actioning}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>

      {editOpen && !isCancelled && (
        <EditSubscriptionModal sub={sub} customer={customer} onClose={() => setEditOpen(false)} />
      )}

      {changeModal && !isCancelled && (
        <AddChangeModal
          type={changeModal}
          subId={sub.id}
          onClose={() => setChangeModal(null)}
          onSaved={() => { setChangeModal(null); loadChanges(); if (refreshParent) refreshParent() }}
        />
      )}
    </>
  )
}