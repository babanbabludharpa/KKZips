import { useEffect, useState } from 'react'
import { CModal, CModalHeader, CModalBody, CModalFooter, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CFormInput } from '@coreui/react'
import api from '../../../api/api'
import { formatDate } from '../../../utils/formatters'

export default function UnbilledDeliveriesModal({ open, onClose, customer }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({ count: 0, total: 0 })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/unbilled-deliveries`, {
        params: { date_from: dateFrom || undefined, date_to: dateTo || undefined },
      })
      setData(res.data.data || [])
      setMeta(res.data.meta || { count: 0, total: 0 })
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load unbilled deliveries.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) load()
  }, [open, customer.id])

  return (
    <CModal visible={open} onClose={onClose} size="xl" backdrop="static" scrollable>
      <CModalHeader>Unbilled Deliveries — {customer.name}</CModalHeader>
      <CModalBody>
        <div className="d-flex gap-2 mb-3 align-items-end">
          <div style={{ flex: 1 }}>
            <label className="small text-muted fw-bold d-block mb-1">From</label>
            <CFormInput size="sm" type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
          </div>
          <div style={{ flex: 1 }}>
            <label className="small text-muted fw-bold d-block mb-1">To</label>
            <CFormInput size="sm" type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
          </div>
          <CButton size="sm" className="filter-btn filter-btn--primary" onClick={load} disabled={loading}>
            {loading ? 'Loading…' : 'Search'}
          </CButton>
          <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => { setDateFrom(''); setDateTo(''); setTimeout(load, 0) }}>Reset</CButton>
        </div>

        {error && <div className="alert alert-danger py-2 small">{error}</div>}

        {loading ? (
          <div className="text-center py-5"><CSpinner /></div>
        ) : data.length === 0 ? (
          <div className="text-center text-muted py-5">No unbilled deliveries.</div>
        ) : (
          <CTable hover responsive className="admin-data-table mb-0">
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Date</CTableHeaderCell>
                <CTableHeaderCell className="text-start">Product</CTableHeaderCell>
                <CTableHeaderCell>Slot</CTableHeaderCell>
                <CTableHeaderCell>Qty</CTableHeaderCell>
                <CTableHeaderCell>Rate</CTableHeaderCell>
                <CTableHeaderCell>Line Total</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              {data.map(row => (
                <CTableRow key={row.id}>
                  <CTableDataCell>{formatDate(row.occurrence_date)}</CTableDataCell>
                  <CTableDataCell className="text-start">
                    {row.product_name || '—'}
                    {row.variant_sku && <span className="text-muted small ms-1">({row.variant_sku})</span>}
                  </CTableDataCell>
                  <CTableDataCell>{row.slot_name || '—'}</CTableDataCell>
                  <CTableDataCell>{row.qty}</CTableDataCell>
                  <CTableDataCell>₹{Number(row.rate).toFixed(2)}</CTableDataCell>
                  <CTableDataCell className="fw-bold">₹{Number(row.line_total).toFixed(2)}</CTableDataCell>
                </CTableRow>
              ))}
            </CTableBody>
          </CTable>
        )}
      </CModalBody>
      <CModalFooter className="justify-content-between">
        <div className="text-muted small">
          {meta.count} unbilled deliver{meta.count === 1 ? 'y' : 'ies'} • Total: <strong>₹{Number(meta.total).toFixed(2)}</strong>
        </div>
        <CButton className="filter-btn filter-btn--ghost" onClick={onClose}>Close</CButton>
      </CModalFooter>
    </CModal>
  )
}