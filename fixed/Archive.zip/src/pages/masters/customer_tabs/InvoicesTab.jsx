import { useEffect, useState } from 'react'
import { CCard, CCardBody, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CBadge } from '@coreui/react'
import api from '../../../api/api'
import { formatDate } from '../../../utils/formatters'
import Pagination from '../../../components/Pagination'
import UnbilledDeliveriesModal from './UnbilledDeliveriesModal'

const STATUS_BADGE = {
  draft: 'secondary',
  generated: 'info',
  partially_paid: 'warning',
  paid: 'success',
  overdue: 'danger',
  cancelled: 'dark',
}

export default function InvoicesTab({ customer }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)
  const [unbilledOpen, setUnbilledOpen] = useState(false)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/invoices`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

  const openInNewTab = (invoiceId) => {
    // Preserve the /admin basename in production
    const base = import.meta.env.PROD ? '/admin' : ''
    window.open(`${base}/subscriptions/invoices/${invoiceId}`, '_blank', 'noopener,noreferrer')
  }

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 d-flex justify-content-between align-items-center border-bottom">
          <h6 className="m-0 fw-bold">Invoices</h6>
          <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setUnbilledOpen(true)}>
            Unbilled
          </CButton>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Invoice #</CTableHeaderCell>
                  <CTableHeaderCell>Period</CTableHeaderCell>
                  <CTableHeaderCell>Total</CTableHeaderCell>
                  <CTableHeaderCell>Paid</CTableHeaderCell>
                  <CTableHeaderCell>Due</CTableHeaderCell>
                  <CTableHeaderCell>Status</CTableHeaderCell>
                  <CTableHeaderCell>Generated</CTableHeaderCell>
                  <CTableHeaderCell style={{ width: 80 }}></CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={8}>No invoices found.</CTableDataCell></CTableRow>
                ) : data.map(inv => (
                  <CTableRow key={inv.id}>
                    <CTableDataCell className="fw-semibold">#{inv.id}</CTableDataCell>
                    <CTableDataCell>{formatDate(inv.period_start)} – {formatDate(inv.period_end)}</CTableDataCell>
                    <CTableDataCell>₹{Number(inv.total).toFixed(2)}</CTableDataCell>
                    <CTableDataCell>₹{Number(inv.amount_paid).toFixed(2)}</CTableDataCell>
                    <CTableDataCell className={Number(inv.amount_due) > 0 ? 'text-danger fw-bold' : ''}>
                      ₹{Number(inv.amount_due).toFixed(2)}
                    </CTableDataCell>
                    <CTableDataCell>
                      <CBadge color={STATUS_BADGE[inv.status] || 'secondary'} shape="rounded-pill">
                        {inv.status.replace('_', ' ')}
                      </CBadge>
                    </CTableDataCell>
                    <CTableDataCell>{formatDate(inv.generated_at)}</CTableDataCell>
                    <CTableDataCell>
                      <CButton size="sm" className="table-action-btn" onClick={() => openInNewTab(inv.id)}>
                        View
                      </CButton>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>

      <UnbilledDeliveriesModal
        open={unbilledOpen}
        onClose={() => setUnbilledOpen(false)}
        customer={customer}
      />
    </CCard>
  )
}