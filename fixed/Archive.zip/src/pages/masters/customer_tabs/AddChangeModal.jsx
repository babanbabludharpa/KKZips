import { useState } from 'react'
import { CSpinner } from '@coreui/react'
import api from '../../../api/api'

export default function AddChangeModal({ type, subId, onClose, onSaved }) {
  const [form, setForm] = useState({ date_from: '', date_to: '', qty: 1, reason: '' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)

  const save = async (e) => {
    e.preventDefault()
    if (!form.date_from || !form.date_to) {
      setError('Please select both dates.')
      return
    }
    setSaving(true)
    setError(null)
    try {
      const endpoint = type === 'pause' 
        ? `/subscriptions/${subId}/pauses` 
        : `/subscriptions/${subId}/qty-overrides`
      await api.post(endpoint, {
        date_from: form.date_from,
        date_to: form.date_to,
        qty: type === 'qty' ? Number(form.qty) : undefined,
        reason: form.reason || undefined
      })
      onSaved()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save change.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div 
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div style={{ background: '#fff', borderRadius: 12, width: '90%', maxWidth: 400, padding: 24, boxShadow: '0 10px 30px rgba(0,0,0,0.2)' }}>
        <h5 className="fw-bold mb-3">{type === 'pause' ? 'Pause Dates' : 'Change Quantity'}</h5>
        
        {error && <div className="alert alert-danger p-2 small">{error}</div>}

        <form onSubmit={save}>
          <div className="mb-3">
            <label className="small text-muted fw-bold">From Date</label>
            <input 
              type="date" 
              className="form-control" 
              value={form.date_from} 
              onChange={e => setForm({...form, date_from: e.target.value})} 
              required 
            />
          </div>
          <div className="mb-3">
            <label className="small text-muted fw-bold">To Date</label>
            <input 
              type="date" 
              className="form-control" 
              value={form.date_to} 
              min={form.date_from}
              onChange={e => setForm({...form, date_to: e.target.value})} 
              required 
            />
          </div>

          {type === 'qty' && (
            <div className="mb-3">
              <label className="small text-muted fw-bold">New Quantity</label>
              <input 
                type="number" 
                className="form-control" 
                min={0}
                value={form.qty} 
                onChange={e => setForm({...form, qty: e.target.value})} 
                required 
              />
            </div>
          )}

          <div className="mb-4">
            <label className="small text-muted fw-bold">Reason (optional)</label>
            <input 
              type="text" 
              className="form-control" 
              value={form.reason} 
              onChange={e => setForm({...form, reason: e.target.value})} 
              placeholder="E.g. Customer requested"
            />
          </div>

          <div className="d-flex justify-content-end gap-2">
            <button type="button" className="btn btn-light" onClick={onClose} disabled={saving}>Cancel</button>
            <button type="submit" className="btn" style={{ backgroundColor: '#3A5B4A', color: '#fff' }} disabled={saving}>
              {saving ? <CSpinner size="sm" /> : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}