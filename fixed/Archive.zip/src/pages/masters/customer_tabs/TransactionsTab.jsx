import { useEffect, useState } from 'react'
import { CCard, CCardBody, CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CModal, CModalHeader, CModalBody, CModalFooter, CFormInput, CAlert } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilLink } from '@coreui/icons'
import api from '../../../api/api'
import { formatDateTime } from '../../../utils/formatters'
import WalletModal from '../../../components/WalletModal'
import Pagination from '../../../components/Pagination'

export default function TransactionsTab({ customer, reload }) {
  const [data, setData] = useState([])
  const [meta, setMeta] = useState({})
  const [loading, setLoading] = useState(true)
  const [walletOpen, setWalletOpen] = useState(false)

  // Payment link modal
  const [linkModal, setLinkModal] = useState(false)
  const [linkAmount, setLinkAmount] = useState('')
  const [linkUrl, setLinkUrl] = useState('')
  const [linkError, setLinkError] = useState(null)
  const [linkSaving, setLinkSaving] = useState(false)

  const load = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get(`/masters/customers/${customer.id}/transactions`, { params: { page } })
      setData(res.data.data || [])
      setMeta(res.data.meta || {})
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [customer.id])

    const generateLink = async () => {
    setLinkError(null)
    setLinkSaving(true)
    try {
      const res = await api.post(`/masters/customers/${customer.id}/payment-links`, {
        amount: Number(linkAmount),
      })
      const token = res.data.data.token
      const url = `${window.location.origin}/pay/${token}`
      setLinkUrl(url)
    } catch (err) {
      setLinkError(err.response?.data?.message || 'Failed to generate link.')
    } finally {
      setLinkSaving(false)
    }
  }

  const copyLink = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(linkUrl)
        alert('Link copied to clipboard.')
      } else {
        const input = document.createElement('input')
        input.value = linkUrl
        document.body.appendChild(input)
        input.select()
        document.execCommand('copy')
        document.body.removeChild(input)
        alert('Link copied to clipboard.')
      }
    } catch {
      alert('Copy failed. Please select the text manually.')
    }
  }

  return (
    <CCard className="border-0 shadow-sm" style={{ borderRadius: 12 }}>
      <CCardBody className="p-0">
        <div className="p-3 d-flex justify-content-between align-items-center border-bottom">
          <h6 className="m-0 fw-bold">Transactions</h6>
          <div className="d-flex gap-2">
            <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => { setLinkModal(true); setLinkAmount(''); setLinkUrl(''); setLinkError(null) }}>
              <CIcon icon={cilLink} className="me-1" size="sm" /> Payment Link
            </CButton>
            <CButton size="sm" className="filter-btn filter-btn--primary" onClick={() => setWalletOpen(true)}>
              <CIcon icon={cilPlus} className="me-1" size="sm" /> Add Balance
            </CButton>
          </div>
        </div>

        {loading ? (
          <div className="text-center p-5"><CSpinner /></div>
        ) : (
          <>
            <CTable hover responsive className="admin-data-table mb-0 text-center align-middle">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Date</CTableHeaderCell>
                  <CTableHeaderCell>Type</CTableHeaderCell>
                  <CTableHeaderCell>Amount</CTableHeaderCell>
                  <CTableHeaderCell>Balance</CTableHeaderCell>
                  <CTableHeaderCell className="text-start">Remark</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {data.length === 0 ? (
                  <CTableRow><CTableDataCell colSpan={5}>No transactions found.</CTableDataCell></CTableRow>
                ) : data.map(t => {
                  const isCredit = Number(t.signed_delta) >= 0
                  return (
                    <CTableRow key={t.id}>
                      <CTableDataCell>{formatDateTime(t.created_at)}</CTableDataCell>
                      <CTableDataCell><span className="fw-semibold text-capitalize">{t.type.replace('_', ' ')}</span></CTableDataCell>
                      <CTableDataCell className={isCredit ? 'text-success' : 'text-danger'}>
                        {isCredit ? '+' : '−'}₹{Math.abs(t.signed_delta).toFixed(2)}
                      </CTableDataCell>
                      <CTableDataCell>₹{t.balance_after}</CTableDataCell>
                      <CTableDataCell className="text-start text-muted small">{t.remark || '—'}</CTableDataCell>
                    </CTableRow>
                  )
                })}
              </CTableBody>
            </CTable>
            {data.length > 0 && (
              <Pagination meta={meta} onPageChange={load} loading={loading} variant="bold" showPageJumper showRecordInfo />
            )}
          </>
        )}
      </CCardBody>

      <WalletModal open={walletOpen} customer={{ id: customer.id, name: customer.name }} onClose={() => { setWalletOpen(false); load(meta.current_page || 1); reload() }} />

      <CModal visible={linkModal} onClose={() => setLinkModal(false)}>
        <CModalHeader>Generate Payment Link</CModalHeader>
        <CModalBody>
          {linkError && <CAlert color="danger">{linkError}</CAlert>}
          {linkUrl ? (
            <div className="d-flex flex-column gap-2">
              <div className="text-muted small">Share this URL with the customer:</div>
              <CFormInput value={linkUrl} readOnly onFocus={e => e.target.select()} />
              <CButton size="sm" className="filter-btn filter-btn--primary" onClick={copyLink}>Copy Link</CButton>
            </div>
          ) : (
            <>
              <label className="filter-label">Amount (₹)</label>
              <CFormInput type="number" min="1" value={linkAmount} onChange={e => setLinkAmount(e.target.value)} />
            </>
          )}
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setLinkModal(false)}>Close</CButton>
          {!linkUrl && (
            <CButton className="filter-btn filter-btn--primary" onClick={generateLink} disabled={linkSaving || !linkAmount}>
              {linkSaving ? 'Generating...' : 'Generate'}
            </CButton>
          )}
        </CModalFooter>
      </CModal>
    </CCard>
  )
}