import { useState, useEffect, useCallback, useRef } from 'react'
import {
  CModal, CModalHeader, CModalBody, CModalFooter, CButton, CRow, CCol,
  CForm, CFormLabel, CFormInput, CFormCheck, CAlert, CSpinner,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilLocationPin } from '@coreui/icons'
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet'
import L from 'leaflet'
import api from '../../../api/api'

delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

const INDIA_CENTER = [20.5937, 78.9629]

const MapMover = ({ center }) => {
  const map = useMap()
  useEffect(() => {
    if (center) map.flyTo(center, 15, { duration: 0.8 })
  }, [center, map])
  return null
}

const MapClickHandler = ({ onMapClick }) => {
  useMapEvents({
    click(e) { onMapClick(e.latlng.lat, e.latlng.lng) },
  })
  return null
}

const emptyForm = () => ({
  label: 'Home',
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  pincode: '',
  latitude: '',
  longitude: '',
  is_default: false,
})

const sleep = (ms) => new Promise(r => setTimeout(r, ms))

export default function ManageAddressesModal({ open, onClose, addresses, customerId, reload }) {
  const [isAdding, setIsAdding] = useState(false)
  const [selectedAddrId, setSelectedAddrId] = useState(null)
  const [form, setForm] = useState(emptyForm())
  const [markerPos, setMarkerPos] = useState(null)
  const [flyToPos, setFlyToPos] = useState(null)
  const [geocoding, setGeocoding] = useState(false)
  const [geocodeError, setGeocodeError] = useState(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const mapKeyRef = useRef(0)

  const selectedAddr = addresses?.find(a => a.id === selectedAddrId)

  // When modal opens, select the default (or first) address
  useEffect(() => {
    if (open && addresses?.length > 0 && !selectedAddrId) {
      const def = addresses.find(a => a.is_default) || addresses[0]
      setSelectedAddrId(def.id)
    }
  }, [open, addresses, selectedAddrId])

  // When the selected address changes (and not adding), move the pin to it
  useEffect(() => {
    if (isAdding || !selectedAddr) return
    if (selectedAddr.latitude && selectedAddr.longitude) {
      const pos = [parseFloat(selectedAddr.latitude), parseFloat(selectedAddr.longitude)]
      setMarkerPos(pos)
      setFlyToPos(pos)
    } else {
      setMarkerPos(null)
      setFlyToPos(null)
    }
  }, [selectedAddr, isAdding])

  // When entering "Add" mode, reset the map and form
  useEffect(() => {
    if (!isAdding) return
    mapKeyRef.current += 1
    setForm(emptyForm())
    setMarkerPos(null)
    setFlyToPos(null)
    setGeocodeError(null)
    setError(null)
  }, [isAdding])

  const handleMapClick = useCallback((lat, lng) => {
    const rLat = parseFloat(lat.toFixed(7))
    const rLng = parseFloat(lng.toFixed(7))
    setMarkerPos([rLat, rLng])
    setForm(f => ({ ...f, latitude: rLat, longitude: rLng }))
    setGeocodeError(null)
  }, [])

  const handleMarkerDrag = useCallback((e) => {
    const { lat, lng } = e.target.getLatLng()
    const rLat = parseFloat(lat.toFixed(7))
    const rLng = parseFloat(lng.toFixed(7))
    setMarkerPos([rLat, rLng])
    setForm(f => ({ ...f, latitude: rLat, longitude: rLng }))
    setGeocodeError(null)
  }, [])

  const handleGeocode = async () => {
    const { address_line1: a1, address_line2: a2, city, state, pincode } = form
    if (!city && !pincode) {
      setGeocodeError('Enter at least a city or pincode.')
      return
    }

    // Most specific -> least specific. Building/society/landmark names
    // rarely exist in OSM, so a single long query often returns nothing.
    const attempts = [
      [a1, a2, city, state, pincode],
      [a1, city, state, pincode],
      [a2, city, pincode],
      [city, state, pincode],
      [pincode, city],
    ]
      .map(p => p.filter(Boolean).join(', '))
      .filter((q, i, arr) => q && arr.indexOf(q) === i)

    setGeocoding(true); setGeocodeError(null)
    try {
      for (let i = 0; i < attempts.length; i++) {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q=${encodeURIComponent(attempts[i])}`
        )
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = await res.json()
        if (data.length) {
          const lat = parseFloat(parseFloat(data[0].lat).toFixed(7))
          const lng = parseFloat(parseFloat(data[0].lon).toFixed(7))
          setMarkerPos([lat, lng]); setFlyToPos([lat, lng])
          setForm(f => ({ ...f, latitude: lat, longitude: lng }))
          if (i > 0) {
            setGeocodeError('Approximate location only. Drag the pin to the exact spot.')
          }
          return
        }
        if (i < attempts.length - 1) await sleep(1100) // Nominatim: max 1 req/sec
      }
      setGeocodeError('Location not found. Click the map to place the pin manually.')
    } catch (err) {
      setGeocodeError(`Geocoding failed (${err.message}). Click the map to place the pin manually.`)
    } finally {
      setGeocoding(false)
    }
  }

  const handleSave = async (e) => {
    e.preventDefault()
    if (!form.latitude || !form.longitude) {
      setError('Please place a pin on the map to set the location.')
      return
    }
    setSaving(true); setError(null)
    try {
      await api.post(`/masters/customers/${customerId}/addresses`, {
        ...form,
        latitude: parseFloat(form.latitude),
        longitude: parseFloat(form.longitude),
      })
      setIsAdding(false)
      setSelectedAddrId(null)
      reload()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save address.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <CModal visible={open} onClose={onClose} size="xl" backdrop="static" scrollable>
      <CModalHeader>
        <span className="fw-bold">{isAdding ? 'Add New Address' : 'Manage Addresses'}</span>
      </CModalHeader>

      <CModalBody className="p-4">
        <CRow className="g-4">

          {/* ── Left column: address list OR add form ─────────── */}
          <CCol md={5}>
            {isAdding ? (
              <CForm onSubmit={handleSave}>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h6 className="m-0 fw-bold">New Address</h6>
                  <CButton
                    type="button"
                    size="sm"
                    className="filter-btn filter-btn--ghost"
                    onClick={() => setIsAdding(false)}
                    disabled={saving}
                  >
                    Cancel
                  </CButton>
                </div>

                {error && <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>}

                <div className="mb-2">
                  <CFormLabel className="filter-label">Label</CFormLabel>
                  <CFormInput
                    className="filter-input"
                    value={form.label}
                    onChange={e => setForm({ ...form, label: e.target.value })}
                    placeholder="Home, Work, etc."
                  />
                </div>
                <div className="mb-2">
                  <CFormLabel className="filter-label">Address Line 1</CFormLabel>
                  <CFormInput
                    className="filter-input"
                    value={form.address_line1}
                    onChange={e => setForm({ ...form, address_line1: e.target.value })}
                    placeholder="Building, street"
                  />
                </div>
                <div className="mb-2">
                  <CFormLabel className="filter-label">Address Line 2</CFormLabel>
                  <CFormInput
                    className="filter-input"
                    value={form.address_line2}
                    onChange={e => setForm({ ...form, address_line2: e.target.value })}
                    placeholder="Area, landmark (optional)"
                  />
                </div>
                <div className="row g-2 mb-2">
                  <div className="col-6">
                    <CFormLabel className="filter-label">City</CFormLabel>
                    <CFormInput
                      className="filter-input"
                      value={form.city}
                      onChange={e => setForm({ ...form, city: e.target.value })}
                    />
                  </div>
                  <div className="col-6">
                    <CFormLabel className="filter-label">Pincode</CFormLabel>
                    <CFormInput
                      className="filter-input"
                      value={form.pincode}
                      onChange={e => setForm({ ...form, pincode: e.target.value })}
                    />
                  </div>
                </div>
                <div className="mb-3">
                  <CFormLabel className="filter-label">State</CFormLabel>
                  <CFormInput
                    className="filter-input"
                    value={form.state}
                    onChange={e => setForm({ ...form, state: e.target.value })}
                  />
                </div>
                <div className="mb-3">
                  <CFormCheck
                    label="Set as default address"
                    checked={form.is_default}
                    onChange={e => setForm({ ...form, is_default: e.target.checked })}
                  />
                </div>

                <CButton
                  type="button"
                  className="filter-btn filter-btn--ghost w-100 mb-2"
                  onClick={handleGeocode}
                  disabled={geocoding}
                >
                  {geocoding
                    ? <><CSpinner size="sm" className="me-1" />Searching…</>
                    : <><CIcon icon={cilLocationPin} className="me-1" />Find from Address</>}
                </CButton>
                {geocodeError && <CAlert color="warning" className="py-2 small mb-2">{geocodeError}</CAlert>}

                <div className="row g-2 mb-3">
                  <div className="col-6">
                    <CFormLabel className="filter-label">Latitude</CFormLabel>
                    <CFormInput
                      className="filter-input"
                      type="number"
                      step="any"
                      value={form.latitude}
                      onChange={e => setForm({ ...form, latitude: e.target.value })}
                      placeholder="Auto-filled"
                    />
                  </div>
                  <div className="col-6">
                    <CFormLabel className="filter-label">Longitude</CFormLabel>
                    <CFormInput
                      className="filter-input"
                      type="number"
                      step="any"
                      value={form.longitude}
                      onChange={e => setForm({ ...form, longitude: e.target.value })}
                      placeholder="Auto-filled"
                    />
                  </div>
                </div>

                <CButton type="submit" className="filter-btn filter-btn--primary w-100" disabled={saving}>
                  {saving ? <><CSpinner size="sm" className="me-1" />Saving…</> : 'Save Address'}
                </CButton>
              </CForm>
            ) : (
              <>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h6 className="m-0 fw-bold">Address list</h6>
                  <CButton
                    size="sm"
                    className="filter-btn filter-btn--primary"
                    onClick={() => setIsAdding(true)}
                  >
                    + Add Address
                  </CButton>
                </div>

                {addresses?.length === 0 ? (
                  <div className="text-muted small">No addresses saved yet.</div>
                ) : (
                  <div className="d-flex flex-column gap-2">
                    {addresses?.map(a => {
                      const isSelected = selectedAddrId === a.id
                      return (
                        <div
                          key={a.id}
                          onClick={() => setSelectedAddrId(a.id)}
                          className="p-3 rounded"
                          style={{
                            cursor: 'pointer',
                            border: isSelected ? '1.5px solid var(--accent)' : '1px solid var(--rep-border)',
                            background: isSelected ? 'var(--accent-subtle)' : 'var(--bg-surface)',
                            transition: 'border-color 120ms, background 120ms',
                          }}
                        >
                          <div className="d-flex justify-content-between mb-1">
                            <strong style={{ color: 'var(--rep-title)' }}>{a.label}</strong>
                            {a.is_default && (
                              <span
                                style={{
                                  fontSize: '0.68rem',
                                  fontWeight: 700,
                                  color: 'var(--success)',
                                  background: 'var(--bg-inset)',
                                  padding: '2px 8px',
                                  borderRadius: 6,
                                }}
                              >
                                DEFAULT
                              </span>
                            )}
                          </div>
                          <div className="small" style={{ color: 'var(--text-soft)' }}>
                            {a.address_line1}
                            {a.address_line2 && <>, {a.address_line2}</>}
                            <br />
                            {a.city}, {a.state} {a.pincode}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </>
            )}
          </CCol>

          {/* ── Right column: map ─────────────────────────────── */}
          <CCol md={7}>
            <div
              style={{
                height: 480,
                borderRadius: 8,
                overflow: 'hidden',
                border: '1px solid var(--rep-border)',
              }}
            >
              <MapContainer
                key={`addr-map-${mapKeyRef.current}`}
                center={markerPos ?? INDIA_CENTER}
                zoom={markerPos ? 15 : 5}
                style={{ height: '100%', width: '100%' }}
                scrollWheelZoom={false}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {isAdding && <MapClickHandler onMapClick={handleMapClick} />}
                <MapMover center={flyToPos} />
                {markerPos && (
                  <Marker
                    position={markerPos}
                    draggable={isAdding}
                    eventHandlers={isAdding ? { dragend: handleMarkerDrag } : {}}
                  />
                )}
              </MapContainer>
            </div>
            <small className="text-muted d-block mt-2">
              {isAdding
                ? 'Click anywhere on the map to place the pin, or drag the pin to adjust.'
                : 'Click an address on the left to view it on the map.'}
            </small>
          </CCol>
        </CRow>
      </CModalBody>

      <CModalFooter>
        <CButton className="filter-btn filter-btn--ghost" onClick={onClose}>
          Close
        </CButton>
      </CModalFooter>
    </CModal>
  )
}