import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilX } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const DOC_FIELDS = [
  'registration_doc', 'gst_doc', 'pan_doc',
  'fssai_doc', 'adhar_doc', 'shopact_doc',
]

const DOC_LABELS = {
  registration_doc: 'Registration',
  gst_doc: 'GST',
  pan_doc: 'PAN',
  fssai_doc: 'FSSAI',
  adhar_doc: 'Aadhaar',
  shopact_doc: 'Shop Act',
}

const schema = yup.object({
  name:            yup.string().required('Name is required'),
  contact_person:  yup.string().nullable().optional(),
  phone:           yup.string().required('Phone is required'),
  alternate_phone: yup.string().nullable().optional(),
  email:           yup.string().email('Invalid email').nullable().optional(),
  address:         yup.string().nullable().optional(),
  gst_no:          yup.string().nullable().optional(),
  registration_no: yup.string().nullable().optional(),
  pan_no:          yup.string().nullable().optional(),
  fssai_no:        yup.string().nullable().optional(),
  adhar_no:        yup.string().required('Aadhaar number is required'),
  shopact_no:      yup.string().nullable().optional(),
})

const SORT_KEY_MAP = {
  name: 'name', phone: 'phone', email: 'email',
  gst_no: 'gst_no', is_active: 'is_active', created_at: 'created_at',
}

const emptyValues = {
  name: '', contact_person: '', phone: '', alternate_phone: '',
  email: '', address: '', gst_no: '', registration_no: '', pan_no: '',
  fssai_no: '', adhar_no: '', shopact_no: '',
}

const dash = (v) => (v === null || v === undefined || v === '' ? '—' : v)

const formatDate = (v) => (v ? new Date(v).toLocaleDateString('en-IN') : '—')

// Only revoke URLs created by URL.createObjectURL (blob:), never server URLs
const revokeIfBlob = (url) => {
  if (typeof url === 'string' && url.startsWith('blob:')) URL.revokeObjectURL(url)
}

const DocLinks = ({ supplier }) => {
  const available = DOC_FIELDS.filter((k) => supplier[k])
  if (available.length === 0) return <span className="text-muted">—</span>
  return (
    <div className="d-flex flex-wrap gap-1" style={{ minWidth: 160 }}>
      {available.map((k) => (
        <a
          key={k}
          href={supplier[k]}
          target="_blank"
          rel="noreferrer"
          className="badge text-bg-light border text-decoration-none"
          title={`View ${DOC_LABELS[k]} document`}
        >
          {DOC_LABELS[k]}
        </a>
      ))}
    </div>
  )
}

const DocFileInput = ({ fieldKey, docs, docPreviews, onDocChange, onClear, required }) => {
  const preview = docPreviews[fieldKey]
  const hasFile = !!docs[fieldKey]
  return (
    <>
      <div className="d-flex align-items-center gap-2">
        <CFormInput
          type="file"
          size="sm"
          accept=".jpg,.jpeg,.png,.pdf"
          className="filter-input"
          onChange={(e) => onDocChange(fieldKey, e.target.files?.[0])}
        />
        {preview && (
          <CButton
            size="sm"
            color="light"
            className="table-action-btn flex-shrink-0"
            type="button"
            title="Remove"
            onClick={() => onClear(fieldKey)}
          >
            <CIcon icon={cilX} />
          </CButton>
        )}
      </div>
      {preview ? (
        <small className="text-muted d-block mt-1" style={{ fontSize: '0.7rem', lineHeight: 1.2 }}>
          {hasFile
            ? <>Selected: <strong>{docs[fieldKey]?.name}</strong></>
            : <a href={preview} target="_blank" rel="noreferrer">View existing document</a>}
        </small>
      ) : required ? (
        <small className="text-muted d-block mt-1" style={{ fontSize: '0.7rem', lineHeight: 1.2 }}>
          jpg / png / pdf, max 5 MB
        </small>
      ) : null}
    </>
  )
}

const Suppliers = () => {
  const [suppliers, setSuppliers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, supplier: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, supplier: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [docs, setDocs] = useState({})
  const [docPreviews, setDocPreviews] = useState({})

  const requestSeq = useRef(0)
  const previewsRef = useRef({})
  const isEdit = !!modal.supplier

  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: emptyValues,
  })

  // keep a ref of current previews so cleanup/revoke always sees the latest
  useEffect(() => { previewsRef.current = docPreviews }, [docPreviews])

  // revoke any remaining blob URLs on unmount
  useEffect(() => {
    return () => {
      Object.values(previewsRef.current).forEach(revokeIfBlob)
    }
  }, [])

  const buildParams = (useSearch, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchSuppliers = async ({
    page = 1,
    searchOverride = appliedSearch,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(searchOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/masters/suppliers', { params })

      if (mySeq !== requestSeq.current) return

      const paginated = res.data?.data
      const dataArray = Array.isArray(paginated?.data) ? paginated.data : []
      const paginationMeta = paginated?.meta ?? {}

      setSuppliers(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setSuppliers([])
      setError(err.response?.data?.message ?? 'Failed to load suppliers.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchSuppliers({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchSuppliers({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => goToPage(page, fetchSuppliers)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchSuppliers)

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchSuppliers({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const resetDocs = () => {
    Object.values(previewsRef.current).forEach(revokeIfBlob)
    setDocs({})
    setDocPreviews({})
  }

  const openCreate = () => {
    reset(emptyValues); resetDocs(); setModalError(null)
    setModal({ open: true, supplier: null })
  }

  const openEdit = (supplier) => {
    reset({
      name:            supplier.name ?? '',
      contact_person:  supplier.contact_person ?? '',
      phone:           supplier.phone ?? '',
      alternate_phone: supplier.alternate_phone ?? '',
      email:           supplier.email ?? '',
      address:         supplier.address ?? '',
      gst_no:          supplier.gst_no ?? '',
      registration_no: supplier.registration_no ?? '',
      pan_no:          supplier.pan_no ?? '',
      fssai_no:        supplier.fssai_no ?? '',
      adhar_no:        supplier.adhar_no ?? '',
      shopact_no:      supplier.shopact_no ?? '',
    })
    Object.values(previewsRef.current).forEach(revokeIfBlob)
    setDocs({})
    setDocPreviews(
      DOC_FIELDS.reduce((acc, k) => { acc[k] = supplier[k] ?? null; return acc }, {})
    )
    setModalError(null)
    setModal({ open: true, supplier })
  }

  const closeModal = () => {
    setModal({ open: false, supplier: null })
    setModalError(null)
    resetDocs()
  }

  const handleDocChange = (key, file) => {
    revokeIfBlob(previewsRef.current[key])
    setDocs((prev) => ({ ...prev, [key]: file || null }))
    setDocPreviews((prev) => ({
      ...prev,
      [key]: file ? URL.createObjectURL(file) : (modal.supplier?.[key] ?? null),
    }))
  }

  const clearDoc = (key) => {
    revokeIfBlob(previewsRef.current[key])
    setDocs((prev) => ({ ...prev, [key]: null }))
    setDocPreviews((prev) => ({ ...prev, [key]: null }))
  }

  const onSubmit = async (data) => {
    setSubmitting(true); setModalError(null)
    try {
      const formData = new FormData()
      Object.entries(data).forEach(([k, v]) => {
        if (v !== null && v !== undefined && v !== '') formData.append(k, v)
      })
      Object.entries(docs).forEach(([k, file]) => {
        if (file) formData.append(k, file)
      })

      if (isEdit) {
        formData.append('_method', 'PUT')
        await api.post(`/masters/suppliers/${modal.supplier.id}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        })
      } else {
        await api.post('/masters/suppliers', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        })
      }

      closeModal()
      fetchSuppliers()
    } catch (e) {
      const errData = e.response?.data
      const firstError = errData?.errors
        ? Object.values(errData.errors).flat()[0]
        : null
      setModalError(firstError ?? errData?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/suppliers/${deleteModal.supplier.id}`)
      setDeleteModal({ open: false, supplier: null })
      fetchSuppliers()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (supplier) => {
    try {
      await api.patch(`/masters/suppliers/${supplier.id}/toggle`)
      fetchSuppliers()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span className={'sort-icon' + (active ? ' sort-icon--active' : '') + (isDesc ? ' sort-icon--desc' : '')} />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Suppliers</h4>
          <PermissionGate permission="supplier.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" /> Add Supplier
            </CButton>
          </PermissionGate>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm" className="filter-input" placeholder="Search suppliers..."
              value={search} onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage} onChange={handlePerPageChangeWrapper}
              label="Per Page" disabled={loading}
            />
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading suppliers...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="name">Name</SortableHeader>
                    <CTableHeaderCell>Contact Person</CTableHeaderCell>
                    <SortableHeader colKey="phone">Phone</SortableHeader>
                    <CTableHeaderCell>Alt. Phone</CTableHeaderCell>
                    <SortableHeader colKey="email">Email</SortableHeader>
                    <CTableHeaderCell>Address</CTableHeaderCell>
                    <SortableHeader colKey="gst_no">GST No</SortableHeader>
                    <CTableHeaderCell>Registration No</CTableHeaderCell>
                    <CTableHeaderCell>PAN No</CTableHeaderCell>
                    <CTableHeaderCell>FSSAI No</CTableHeaderCell>
                    <CTableHeaderCell>Aadhaar No</CTableHeaderCell>
                    <CTableHeaderCell>Shop Act No</CTableHeaderCell>
                    <CTableHeaderCell>Documents</CTableHeaderCell>
                    <SortableHeader colKey="created_at">Created At</SortableHeader>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {suppliers.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={17} className="text-center text-muted py-4">
                        No suppliers found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    suppliers.map((supplier, i) => (
                      <CTableRow key={supplier.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{supplier.name}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.contact_person)}</CTableDataCell>
                        <CTableDataCell>{supplier.phone}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.alternate_phone)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.email)}</CTableDataCell>
                        <CTableDataCell style={{ minWidth: 200 }}>{dash(supplier.address)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.gst_no)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.registration_no)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.pan_no)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.fssai_no)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.adhar_no)}</CTableDataCell>
                        <CTableDataCell>{dash(supplier.shopact_no)}</CTableDataCell>
                        <CTableDataCell><DocLinks supplier={supplier} /></CTableDataCell>
                        <CTableDataCell>{formatDate(supplier.created_at)}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={supplier.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill" style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(supplier)} title="Click to toggle"
                          >
                            {supplier.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="supplier.edit">
                              <CButton size="sm" className="table-action-btn" onClick={() => openEdit(supplier)} title="Edit">
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="supplier.delete">
                              <CButton size="sm" className="table-action-btn" onClick={() => setDeleteModal({ open: true, supplier })} title="Delete">
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta} onPageChange={handlePageChange}
                loading={pageLoading} variant="bold"
                showPageJumper={true} showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ===== CREATE / EDIT MODAL — no CForm wrapper, native scroll ===== */}
      <CModal
        size="xl"
        scrollable
        visible={modal.open}
        onClose={closeModal}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Supplier' : 'Add Supplier'}
          </CModalTitle>
        </CModalHeader>

        <CModalBody className="wallet-modal__body">
          {modalError && (
            <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
              {modalError}
            </CAlert>
          )}

          <h6 className="mb-2">Basic Details</h6>
          <div className="row g-2">
            <div className="col-md-4">
              <CFormLabel className="filter-label">Name <span className="text-danger">*</span></CFormLabel>
              <CFormInput size="sm" className="filter-input" invalid={!!errors.name} {...register('name')} />
              {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">Contact Person</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('contact_person')} />
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">Phone <span className="text-danger">*</span></CFormLabel>
              <CFormInput size="sm" className="filter-input" invalid={!!errors.phone} {...register('phone')} />
              {errors.phone && <div className="text-danger small mt-1">{errors.phone.message}</div>}
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">Alternate Phone</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('alternate_phone')} />
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">Email</CFormLabel>
              <CFormInput size="sm" className="filter-input" type="email" invalid={!!errors.email} {...register('email')} />
              {errors.email && <div className="text-danger small mt-1">{errors.email.message}</div>}
            </div>
            <div className="col-md-4">
              <CFormLabel className="filter-label">GST No</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('gst_no')} placeholder="e.g. 27AAPFU0939F1ZV" />
            </div>
            <div className="col-md-6">
              <CFormLabel className="filter-label">GST Doc</CFormLabel>
              <DocFileInput fieldKey="gst_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} />
            </div>
            <div className="col-12">
              <CFormLabel className="filter-label">Address</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('address')} />
            </div>
          </div>

          <h6 className="mb-2 mt-3">Registration &amp; Compliance</h6>
          <div className="row g-2">
            <div className="col-md-3">
              <CFormLabel className="filter-label">Registration No.</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('registration_no')} />
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">Registration Doc</CFormLabel>
              <DocFileInput fieldKey="registration_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} />
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">PAN No.</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('pan_no')} />
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">PAN Doc</CFormLabel>
              <DocFileInput fieldKey="pan_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} />
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">FSSAI No.</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('fssai_no')} />
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">FSSAI Doc</CFormLabel>
              <DocFileInput fieldKey="fssai_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} />
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Aadhaar No. <span className="text-danger">*</span></CFormLabel>
              <CFormInput size="sm" className="filter-input" invalid={!!errors.adhar_no} {...register('adhar_no')} />
              {errors.adhar_no && <div className="text-danger small mt-1">{errors.adhar_no.message}</div>}
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">Aadhaar Doc <span className="text-danger">*</span></CFormLabel>
              <DocFileInput fieldKey="adhar_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} required />
            </div>

            <div className="col-md-3">
              <CFormLabel className="filter-label">Shop Act No.</CFormLabel>
              <CFormInput size="sm" className="filter-input" {...register('shopact_no')} />
            </div>
            <div className="col-md-3">
              <CFormLabel className="filter-label">Shop Act Doc</CFormLabel>
              <DocFileInput fieldKey="shopact_doc" docs={docs} docPreviews={docPreviews}
                onDocChange={handleDocChange} onClear={clearDoc} />
            </div>
          </div>
        </CModalBody>

        <CModalFooter className="wallet-modal__footer">
          <CButton className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
            Cancel
          </CButton>
          <CButton
            type="button"
            className="filter-btn filter-btn--primary"
            onClick={handleSubmit(onSubmit)}
            disabled={submitting}
          >
            {submitting ? <CSpinner size="sm" className="me-2" /> : null}
            {isEdit ? 'Update' : 'Create'}
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ===== DELETE MODAL ===== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, supplier: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.supplier?.name}</strong>? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, supplier: null })}>
            Cancel
          </CButton>
          <CButton className="filter-btn filter-btn--danger" onClick={handleDelete}>
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Suppliers