import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CNav, CNavItem, CNavLink, CSpinner, CBadge,
  CButton, CModal, CModalHeader, CModalBody, CModalFooter, CFormTextarea,
} from '@coreui/react'
import { cilArrowLeft, cilPlus, cilCloudDownload } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import api from '../../api/api'
import { formatDate } from '../../utils/formatters'

import ProfileTab from './customer_tabs/ProfileTab'
import TransactionsTab from './customer_tabs/TransactionsTab'
import DeliveriesTab from './customer_tabs/DeliveriesTab'
import SubscriptionsTab from './customer_tabs/SubscriptionsTab'
import BillsTab from './customer_tabs/BillsTab'
import InvoicesTab from './customer_tabs/InvoicesTab'
import OrdersTab from './customer_tabs/OrdersTab'

const CustomerProfile = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('profile')
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [noteModal, setNoteModal] = useState(false)
  const [noteText, setNoteText] = useState('')
  const [exporting, setExporting] = useState(false)

  const load = async () => {
    try {
      const res = await api.get(`/masters/customers/${id}/profile`)
      setData(res.data.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      try {
        const res = await api.get(`/masters/customers/${id}/profile`)
        if (!cancelled) setData(res.data.data)
      } catch (err) {
        console.error(err)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    run()
    return () => { cancelled = true }
  }, [id])

  const saveNote = async () => {
    if (!noteText.trim()) return
    await api.post(`/masters/customers/${id}/notes`, { note: noteText })
    setNoteText('')
    setNoteModal(false)
    load()
  }

  const exportCsv = async () => {
    setExporting(true)
    try {
      const res = await api.get(`/masters/customers/${id}/export`, { responseType: 'blob' })
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `customer_${id}.csv`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      window.URL.revokeObjectURL(url)
    } catch {
      alert('Export failed.')
    } finally {
      setExporting(false)
    }
  }

  if (loading) return <div className="p-5 text-center"><CSpinner /></div>
  if (!data) return <div className="p-5 text-center">Customer not found.</div>

  const c = data.customer

  return (
    <div className="report-page" style={{ backgroundColor: 'var(--bg)', minHeight: '100vh' }}>
      
      {/* Header Card */}
      <CCard
        className="mb-3 border-0"
        style={{
          borderRadius: 'var(--rep-radius)',
          boxShadow: 'var(--shadow-sm)',
          background: 'var(--bg-surface)',
        }}
      >
        <CCardBody className="py-3 px-4 d-flex justify-content-between align-items-center">
          
          {/* Left: Back + Name */}
          <div className="d-flex align-items-center gap-3">
            <CButton 
              size="sm" 
              color="light" 
              className="rounded-circle p-2 d-flex align-items-center justify-content-center" 
              onClick={() => navigate('/masters/customers')}
            >
              <CIcon icon={cilArrowLeft} size="sm" />
            </CButton>
            <div>
              <h5 className="mb-0 fw-bold d-flex align-items-center gap-2" style={{ color: 'var(--rep-title)' }}>
                {c.name} <span style={{ color: 'var(--text-soft)', fontWeight: 400 }}>#{c.id}</span>
                {c.status !== 'active' && <CBadge color="danger" shape="rounded-pill">{c.status}</CBadge>}
              </h5>
              <div style={{ color: 'var(--text-soft)', fontSize: '0.75rem' }}>
                Joined {formatDate(c.created_at)} • {c.phone}
              </div>
            </div>
          </div>

          {/* Right: Balance + Actions */}
          <div className="d-flex align-items-center gap-3">
            <div className="text-end">
              <h5 className="mb-0 fw-bold" style={{ color: data.balance < 0 ? 'var(--danger)' : 'var(--success)' }}>
                ₹{Math.abs(data.balance).toFixed(2)}
              </h5>
              <small style={{ color: 'var(--text-soft)', fontSize: '0.7rem' }}>BALANCE</small>
            </div>
            <CButton 
              size="sm" 
              className="filter-btn filter-btn--ghost" 
              onClick={exportCsv}
              disabled={exporting}
              title="Export customer data as CSV"
            >
              {exporting ? <CSpinner size="sm" className="me-1" /> : <CIcon icon={cilCloudDownload} className="me-1" size="sm" />}
              Export
            </CButton>
            <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setNoteModal(true)}>
              <CIcon icon={cilPlus} className="me-1" size="sm" /> Note
            </CButton>
          </div>
        </CCardBody>
        
        {/* Compact Tabs — inline underline style, uses accent token */}
        <div className="px-3" style={{ borderTop: '1px solid var(--rep-border)' }}>
          <CNav variant="tabs" className="border-0" style={{ gap: '0.25rem' }}>
             {['profile', 'subscriptions', 'deliveries', 'orders', 'invoices', 'transactions', 'ledger'].map(tab => {
                const active = activeTab === tab
                return (
                  <CNavItem key={tab}>
                    <CNavLink 
                      active={active} 
                      onClick={() => setActiveTab(tab)} 
                      style={{ 
                        cursor: 'pointer', 
                        fontWeight: 600, 
                        fontSize: '0.85rem', 
                        padding: '8px 16px',
                        background: 'transparent',
                        border: 'none',
                        borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
                        borderRadius: 0,
                        color: active ? 'var(--accent-dark)' : 'var(--text-soft)',
                      }}
                    >
                      {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </CNavLink>
                  </CNavItem>
                )
             })}
          </CNav>
        </div>
      </CCard>

      {/* Tab Content */}
      <div style={{ padding: '0 12px' }}>
        {activeTab === 'profile'        && <ProfileTab data={data} reload={load} />}
        {activeTab === 'transactions'   && <TransactionsTab customer={c} reload={load} />}
        {activeTab === 'deliveries'     && <DeliveriesTab customer={c} />}
        {activeTab === 'subscriptions'  && <SubscriptionsTab customer={c} />}
        {activeTab === 'orders'         && <OrdersTab customer={c} />}
        {activeTab === 'invoices'       && <InvoicesTab customer={c} />}
        {activeTab === 'ledger'         && <BillsTab customer={c} />}
      </div>

      {/* Note Modal */}
      <CModal visible={noteModal} onClose={() => setNoteModal(false)}>
        <CModalHeader>Add Internal Note</CModalHeader>
        <CModalBody>
          <CFormTextarea 
            rows={4} 
            value={noteText} 
            onChange={e => setNoteText(e.target.value)} 
            placeholder="Enter note here..." 
          />
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setNoteModal(false)}>Cancel</CButton>
          <CButton className="filter-btn filter-btn--primary" onClick={saveNote}>Save Note</CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}
export default CustomerProfile