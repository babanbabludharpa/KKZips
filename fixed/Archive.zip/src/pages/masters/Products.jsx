import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CFormTextarea, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilTrash, cilPlus, cilLayers } from '@coreui/icons'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const schema = yup.object({
  name: yup.string().required('Name is required'),
  category_id: yup.string().required('Category is required'),
  description: yup.string().nullable().optional(),
})

// Header column key -> backend sort key (must match ProductService::SORTABLE)
const SORT_KEY_MAP = {
  name:       'name',
  category:   'category',
  is_active:  'is_active',
  created_at: 'created_at',
}

const Products = () => {
  const navigate = useNavigate()

  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalError, setModalError] = useState(null)
  const [modal, setModal] = useState({ open: false, product: null })
  const [deleteModal, setDeleteModal] = useState({ open: false, product: null })
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const requestSeq = useRef(0)

  const isEdit = !!modal.product

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { name: '', category_id: '', description: '' },
  })

  // ---------- Categories dropdown ----------
  const fetchCategories = async () => {
    try {
      const res = await api.get('/masters/categories', { params: { per_page: 200, is_active: 1 } })
      const d = res.data?.data
      setCategories(Array.isArray(d) ? d : (d?.data ?? []))
    } catch { /* silent */ }
  }

  const buildParams = (useSearch, useCategory, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSearch) params.search = useSearch
    if (useCategory) params.category_id = useCategory
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  // Response: { status, message, data: { data: [...rows], meta: {...} } }
  const fetchProducts = async ({
    page = 1,
    searchOverride = appliedSearch,
    categoryOverride = categoryFilter,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(searchOverride, categoryOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/masters/products', { params })

      if (mySeq !== requestSeq.current) return

      const paginated = res.data?.data
      const dataArray = Array.isArray(paginated?.data) ? paginated.data : []
      const paginationMeta = paginated?.meta ?? {}

      setProducts(dataArray)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? dataArray.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setProducts([])
      setError(err.response?.data?.message ?? 'Failed to load products.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchCategories()
    fetchProducts({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search + immediate category change
  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchProducts({ page: 1, searchOverride: search, categoryOverride: categoryFilter })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, categoryFilter])

  const handlePageChange = (page) => {
    goToPage(page, fetchProducts)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchProducts)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchProducts({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const openCreate = () => {
    reset({ name: '', category_id: '', description: '' })
    setModalError(null)
    setModal({ open: true, product: null })
  }

  const openEdit = (product) => {
    reset({
      name: product.name ?? '',
      category_id: String(product.category_id ?? ''),
      description: product.description ?? '',
    })
    setModalError(null)
    setModal({ open: true, product })
  }

  const closeModal = () => {
    setModal({ open: false, product: null })
    setModalError(null)
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      let productId = modal.product?.id
      if (isEdit) {
        await api.put(`/masters/products/${productId}`, data)
      } else {
        const res = await api.post('/masters/products', data)
        productId = res.data?.data?.product?.id
      }
      closeModal()
      fetchProducts()
      // New product with zero variants — send straight to variant creation
      if (!isEdit && productId) {
        navigate(`/masters/products/${productId}/variants`)
      }
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    try {
      await api.delete(`/masters/products/${deleteModal.product.id}`)
      setDeleteModal({ open: false, product: null })
      fetchProducts()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Delete failed.')
    }
  }

  const toggleActive = async (product) => {
    try {
      await api.patch(`/masters/products/${product.id}/toggle`)
      fetchProducts()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Status update failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Products</h4>
          <PermissionGate permission="product.create">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Add Product
            </CButton>
          </PermissionGate>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Category</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading products...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="name">Name</SortableHeader>
                    <SortableHeader colKey="category">Category</SortableHeader>
                    <CTableHeaderCell>Variants</CTableHeaderCell>
                    <SortableHeader colKey="is_active">Status</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {products.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={6} className="text-center text-muted py-4">
                        No products found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    products.map((product, i) => (
                      <CTableRow key={product.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{product.name}</CTableDataCell>
                        <CTableDataCell>{product.category_name ?? '—'}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={product.variants?.length ? 'info' : 'secondary'}
                            shape="rounded-pill"
                          >
                            {product.variants?.length ?? 0} variant(s)
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={product.is_active ? 'success' : 'secondary'}
                            shape="rounded-pill"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleActive(product)}
                            title="Click to toggle"
                          >
                            {product.is_active ? 'Active' : 'Inactive'}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <PermissionGate permission="product.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => navigate(`/masters/products/${product.id}/variants`)}
                                title="Manage variants"
                              >
                                <CIcon icon={cilLayers} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="product.edit">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openEdit(product)}
                                title="Edit"
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                            </PermissionGate>
                            <PermissionGate permission="product.delete">
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => setDeleteModal({ open: true, product })}
                                disabled={product.variants?.length > 0}
                                title={product.variants?.length > 0 ? 'Delete all variants first' : 'Delete'}
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                            </PermissionGate>
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE / EDIT MODAL ==================== */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Product' : 'Add Product'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Name <span className="text-danger">*</span>
              </CFormLabel>
              <CFormInput
                className="filter-input"
                invalid={!!errors.name}
                {...register('name')}
                placeholder="e.g. Milk, Cotton T-Shirt"
              />
              {errors.name && (
                <div className="text-danger small mt-1">{errors.name.message}</div>
              )}
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">
                Category <span className="text-danger">*</span>
              </CFormLabel>
              <CFormSelect
                className="filter-input"
                invalid={!!errors.category_id}
                {...register('category_id')}
              >
                <option value="">Select Category</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </CFormSelect>
              {errors.category_id && (
                <div className="text-danger small mt-1">{errors.category_id.message}</div>
              )}
            </div>

            <div className="mb-3">
              <CFormLabel className="filter-label">Description</CFormLabel>
              <CFormTextarea className="filter-input" rows={3} {...register('description')} />
            </div>

            {!isEdit && (
              <div className="text-muted small">
                After creating, you'll be taken to add at least one variant
                (e.g. size, pricing).
              </div>
            )}
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={closeModal}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create & Add Variants'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== DELETE MODAL ==================== */}
      <CModal
        visible={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, product: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Delete</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Are you sure you want to delete <strong>{deleteModal.product?.name}</strong>?
          This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setDeleteModal({ open: false, product: null })}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleDelete}
          >
            Delete
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Products