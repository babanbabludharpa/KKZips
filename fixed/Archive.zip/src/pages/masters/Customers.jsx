import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CSpinner, CAlert,
  CFormInput, CFormSelect, CFormCheck, CNav, CNavItem, CNavLink,
  CModal, CModalHeader, CModalBody, CModalFooter, CBadge,
} from '@coreui/react'
import api from '../../api/api'
import { formatDate } from '../../utils/formatters'
import Pagination from '../../components/Pagination'
import PermissionGate from '../../components/PermissionGate'

const STATUS_OPTIONS = ['active', 'inactive', 'suspended']
const STATUS_COLOR = { active: 'success', inactive: 'secondary', suspended: 'danger' }

const timeAgo = (dateStr) => {
  if (!dateStr) return '—'
  const diff = Math.floor((new Date() - new Date(dateStr)) / 86400000)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Yesterday'
  if (diff < 7) return `${diff} days ago`
  if (diff < 30) return `${Math.floor(diff / 7)} weeks ago`
  return `${Math.floor(diff / 30)} months ago`
}

const Customers = () => {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('all')
  const [rows, setRows] = useState([])
  const [meta, setMeta] = useState({})
  const [perPage] = useState(25)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')

  const [selected, setSelected] = useState(new Set())
  const [savingId, setSavingId] = useState(null)
  const [bulkStatusOpen, setBulkStatusOpen] = useState(false)
  const [bulkWalletOpen, setBulkWalletOpen] = useState(false)
  const [bulkStatus, setBulkStatus] = useState('active')
  const [bulkAmount, setBulkAmount] = useState('')
  const [bulkDirection, setBulkDirection] = useState('credit')
  const [bulkRemark, setBulkRemark] = useState('')
  const [bulkSubmitting, setBulkSubmitting] = useState(false)

  const fetchData = async (page = 1) => {
    setLoading(true)
    try {
      const res = await api.get('/masters/customers', { params: { search, page, per_page: perPage } })
      setRows(res.data?.data?.data ?? [])
      setMeta(res.data?.data?.meta ?? {})
      setSelected(new Set())
    } catch {
      setError('Failed to load customers.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData(1) }, [activeTab])

  const toggleRow = (id) => setSelected(prev => {
    const next = new Set(prev)
    next.has(id) ? next.delete(id) : next.add(id)
    return next
  })

  const toggleAll = () => setSelected(prev => {
    const allOnPage = rows.every(r => prev.has(r.id))
    return allOnPage ? new Set() : new Set(rows.map(r => r.id))
  })

  const allOnPageSelected = rows.length > 0 && rows.every(r => selected.has(r.id))

  // ─── Inline status change ──────────────────────────────────────
  const handleStatusChange = async (customerId, newStatus, previousStatus) => {
    // Optimistic update
    setRows(rs => rs.map(r => r.id === customerId ? { ...r, status: newStatus } : r))
    setSavingId(customerId)
    try {
      await api.patch(`/masters/customers/${customerId}/status`, { status: newStatus })
    } catch (err) {
      // Revert on error
      setRows(rs => rs.map(r => r.id === customerId ? { ...r, status: previousStatus } : r))
      alert(err.response?.data?.message || 'Failed to update status.')
    } finally {
      setSavingId(null)
    }
  }

  const submitBulkStatus = async () => {
    setBulkSubmitting(true)
    try {
      const res = await api.post('/masters/customers/bulk-status', {
        customer_ids: Array.from(selected),
        status: bulkStatus,
      })
      alert(res.data.message)
      setBulkStatusOpen(false)
      fetchData(meta.current_page || 1)
    } catch (err) {
      alert(err.response?.data?.message || 'Bulk update failed.')
    } finally {
      setBulkSubmitting(false)
    }
  }

  const submitBulkWallet = async () => {
    setBulkSubmitting(true)
    try {
      const res = await api.post('/masters/customers/bulk-wallet', {
        customer_ids: Array.from(selected),
        amount: Number(bulkAmount),
        direction: bulkDirection,
        remark: bulkRemark,
      })
      alert(res.data.message)
      setBulkWalletOpen(false)
      setBulkAmount(''); setBulkRemark('')
      fetchData(meta.current_page || 1)
    } catch (err) {
      alert(err.response?.data?.message || 'Bulk wallet adjustment failed.')
    } finally {
      setBulkSubmitting(false)
    }
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header d-flex justify-content-between align-items-center">
          <div className="d-flex align-items-center gap-3">
            <h4 className="report-shell__title m-0">Customers</h4>
            <CNav variant="pills" className="bg-light p-1 rounded">
              <CNavItem>
                <CNavLink active={activeTab === 'all'} onClick={() => setActiveTab('all')} style={{ cursor: 'pointer' }}>All</CNavLink>
              </CNavItem>
              <CNavItem>
                <CNavLink active={activeTab === 'new'} onClick={() => setActiveTab('new')} style={{ cursor: 'pointer' }}>New</CNavLink>
              </CNavItem>
            </CNav>
          </div>
          <div className="d-flex gap-2">
            <CFormInput size="sm" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && fetchData(1)} />
            <CButton size="sm" className="filter-btn filter-btn--primary" onClick={() => fetchData(1)}>Search</CButton>
          </div>
        </div>

        {selected.size > 0 && (
          <div className="p-2 d-flex gap-2 align-items-center" style={{ background: 'var(--accent-subtle)',borderBottom: '1px solid var(--rep-border)', }}>
            <span className="small fw-bold" style={{ color: 'var(--accent-dark)' }}>{selected.size} selected</span>
            <PermissionGate permission="customer.edit">
              <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setBulkStatusOpen(true)}>Change Status</CButton>
              <CButton size="sm" className="filter-btn filter-btn--ghost" onClick={() => setBulkWalletOpen(true)}>Wallet Adjust</CButton>
            </PermissionGate>
            <CButton size="sm" className="filter-btn filter-btn--ghost ms-auto" onClick={() => setSelected(new Set())}>Clear</CButton>
          </div>
        )}

        {error && <CAlert color="danger">{error}</CAlert>}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading"><CSpinner /></div>
          ) : (
            <>
              <CTable hover responsive className="admin-data-table text-center align-middle">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell style={{ width: 36 }}>
                      <CFormCheck checked={allOnPageSelected} onChange={toggleAll} />
                    </CTableHeaderCell>
                    <CTableHeaderCell>ID</CTableHeaderCell>
                    <CTableHeaderCell className="text-start">Name</CTableHeaderCell>
                    <CTableHeaderCell>Phone</CTableHeaderCell>
                    <CTableHeaderCell>Balance</CTableHeaderCell>
                    <CTableHeaderCell>Last Delivery</CTableHeaderCell>
                    <CTableHeaderCell>Registered On</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Action</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {rows.length === 0 ? (
                    <CTableRow><CTableDataCell colSpan={9}>No customers found.</CTableDataCell></CTableRow>
                  ) : rows.map((r) => (
                    <CTableRow key={r.id}>
                      <CTableDataCell>
                        <CFormCheck checked={selected.has(r.id)} onChange={() => toggleRow(r.id)} />
                      </CTableDataCell>
                      <CTableDataCell>{r.id}</CTableDataCell>
                      <CTableDataCell className="text-start">{r.name}</CTableDataCell>
                      <CTableDataCell>{r.phone || '—'}</CTableDataCell>
                      <CTableDataCell className={Number(r.balance) < 0 ? 'text-danger' : ''}>
                        ₹{Math.abs(Number(r.balance ?? 0)).toFixed(2)}
                      </CTableDataCell>
                      <CTableDataCell>{timeAgo(r.last_delivery_date)}</CTableDataCell>
                      <CTableDataCell>{formatDate(r.created_at)}</CTableDataCell>

                      {/* ─── Inline status dropdown ─────────────────── */}
                      <CTableDataCell>
                        <PermissionGate
                          permission="customer.edit"
                          fallback={<CBadge color={STATUS_COLOR[r.status] || 'secondary'} shape="rounded-pill">{r.status}</CBadge>}
                        >
                          <CFormSelect
                            size="sm"
                            className="filter-input filter-input--inline"
                            value={r.status}
                            disabled={savingId === r.id}
                            onChange={(e) => handleStatusChange(r.id, e.target.value, r.status)}
                          >
                            {STATUS_OPTIONS.map((s) => (
                              <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>
                            ))}
                          </CFormSelect>
                        </PermissionGate>
                      </CTableDataCell>

                      <CTableDataCell>
                        <CButton size="sm" className="table-action-btn" onClick={() => navigate(`/masters/customers/${r.id}`)}>View</CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>

              {rows.length > 0 && (
                <Pagination meta={meta} onPageChange={fetchData} loading={loading} variant="bold" showPageJumper showRecordInfo />
              )}
            </>
          )}
        </CCardBody>
      </CCard>

      <CModal visible={bulkStatusOpen} onClose={() => setBulkStatusOpen(false)}>
        <CModalHeader>Change Status for {selected.size} customer(s)</CModalHeader>
        <CModalBody>
          <label className="filter-label">New Status</label>
          <CFormSelect value={bulkStatus} onChange={e => setBulkStatus(e.target.value)}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="suspended">Suspended</option>
          </CFormSelect>
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setBulkStatusOpen(false)} disabled={bulkSubmitting}>Cancel</CButton>
          <CButton className="filter-btn filter-btn--primary" onClick={submitBulkStatus} disabled={bulkSubmitting}>
            {bulkSubmitting ? 'Updating…' : 'Update'}
          </CButton>
        </CModalFooter>
      </CModal>

      <CModal visible={bulkWalletOpen} onClose={() => setBulkWalletOpen(false)}>
        <CModalHeader>Wallet Adjust for {selected.size} customer(s)</CModalHeader>
        <CModalBody>
          <div className="mb-3">
            <label className="filter-label">Direction</label>
            <CFormSelect value={bulkDirection} onChange={e => setBulkDirection(e.target.value)}>
              <option value="credit">Credit</option>
              <option value="debit">Debit</option>
            </CFormSelect>
          </div>
          <div className="mb-3">
            <label className="filter-label">Amount (₹)</label>
            <CFormInput type="number" min="0.01" step="0.01" value={bulkAmount} onChange={e => setBulkAmount(e.target.value)} />
          </div>
          <div className="mb-3">
            <label className="filter-label">Remark (required)</label>
            <CFormInput value={bulkRemark} onChange={e => setBulkRemark(e.target.value)} maxLength={255} />
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton className="filter-btn filter-btn--ghost" onClick={() => setBulkWalletOpen(false)} disabled={bulkSubmitting}>Cancel</CButton>
          <CButton className="filter-btn filter-btn--primary" onClick={submitBulkWallet} disabled={bulkSubmitting || !bulkAmount || !bulkRemark}>
            {bulkSubmitting ? 'Adjusting…' : 'Apply'}
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Customers