import { useEffect, useMemo, useRef, useState } from 'react'
import {
  CCard,
  CCardBody,
  CCardHeader,
  CButton,
  CRow,
  CCol,
  CBadge,
  CSpinner,
  CAlert,
  CForm,
  CFormLabel,
  CFormInput,
  CInputGroup,
  CInputGroupText,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilCamera,
  cilTrash,
  cilLockLocked,
  cilUser,
  cilLowVision,
  cilZoom,
} from '@coreui/icons'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import { formatDateTime } from '../../utils/formatters'

const MAX_AVATAR_MB = 2
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp']

const passwordRules = (base) =>
  base
    .min(8, 'Minimum 8 characters')
    .matches(/[a-z]/, 'Must include a lowercase letter')
    .matches(/[A-Z]/, 'Must include an uppercase letter')
    .matches(/[0-9]/, 'Must include a number')
    .matches(/[^a-zA-Z0-9]/, 'Must include a special character')

const passwordSchema = yup.object({
  current_password: yup.string().required('Current password is required'),
  password: passwordRules(yup.string()).required('New password is required'),
  password_confirmation: yup
    .string()
    .required('Please confirm the new password')
    .oneOf([yup.ref('password')], 'Passwords do not match'),
})

const roleLabel = (role) =>
  ({
    superadmin: 'Super Admin',
    admin: 'Admin',
    staff_headoffice: 'Staff (Head Office)',
    staff_stateoffice: 'Staff (State Office)',
    staff_branch: 'Staff (Branch)',
    delivery_boy: 'Delivery Boy',
  }[role] ?? role ?? '—')

const roleBadgeColor = (role) =>
  ({
    superadmin: 'danger',
    admin: 'primary',
    staff_headoffice: 'success',
    staff_stateoffice: 'warning',
    staff_branch: 'info',
    delivery_boy: 'secondary',
  }[role] ?? 'secondary')

// ── Small reusable component: a password input with an eye toggle ──
const PasswordInput = ({ invalid, registerProps, autoComplete }) => {
  const [visible, setVisible] = useState(false)

  return (
    <CInputGroup>
      <CFormInput
        type={visible ? 'text' : 'password'}
        autoComplete={autoComplete}
        invalid={invalid}
        {...registerProps}
      />
      <CInputGroupText
        role="button"
        onClick={() => setVisible((v) => !v)}
        title={visible ? 'Hide password' : 'Show password'}
        style={{ cursor: 'pointer' }}
      >
        <CIcon icon={visible ? cilLowVision : cilZoom} />
      </CInputGroupText>
    </CInputGroup>
  )
}

const Profile = () => {
  const user = useAuthStore((s) => s.user)
  const updateUser = useAuthStore((s) => s.updateUser)

  // ── Avatar state ──────────────────────────────────────────
  const [avatarPreview, setAvatarPreview] = useState(null)
  const [avatarFile, setAvatarFile] = useState(null)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const [removingAvatar, setRemovingAvatar] = useState(false)
  const [avatarError, setAvatarError] = useState(null)
  const fileInputRef = useRef(null)

  // ── Password form ─────────────────────────────────────────
  const [passwordSuccess, setPasswordSuccess] = useState(null)
  const [passwordError, setPasswordError] = useState(null)
  const [changingPassword, setChangingPassword] = useState(false)

  const {
    register,
    handleSubmit,
    reset: resetPasswordForm,
    setError: setFieldError,
    clearErrors,
    formState: { errors },
  } = useForm()

  useEffect(() => {
    return () => {
      if (avatarPreview) URL.revokeObjectURL(avatarPreview)
    }
  }, [avatarPreview])

  const displayedAvatar = useMemo(
    () => avatarPreview || user?.avatar_url || null,
    [avatarPreview, user?.avatar_url]
  )

  // ── Avatar: pick file ─────────────────────────────────────
  const handlePickAvatar = () => fileInputRef.current?.click()

  const handleAvatarChange = (e) => {
    setAvatarError(null)
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return

    if (!ACCEPTED_TYPES.includes(file.type)) {
      setAvatarError('Only JPG, PNG or WEBP images are allowed.')
      return
    }
    if (file.size > MAX_AVATAR_MB * 1024 * 1024) {
      setAvatarError(`Image must be smaller than ${MAX_AVATAR_MB} MB.`)
      return
    }

    if (avatarPreview) URL.revokeObjectURL(avatarPreview)
    setAvatarPreview(URL.createObjectURL(file))
    setAvatarFile(file)
  }

  // ── Avatar: upload ────────────────────────────────────────
  const handleUploadAvatar = async () => {
    if (!avatarFile) return
    setAvatarError(null)
    setUploadingAvatar(true)
    try {
      const formData = new FormData()
      formData.append('avatar', avatarFile)

      const res = await api.post('/profile/avatar', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const updatedUser = res.data?.data?.user
      if (updatedUser) updateUser(updatedUser)

      if (avatarPreview) URL.revokeObjectURL(avatarPreview)
      setAvatarPreview(null)
      setAvatarFile(null)
    } catch (err) {
      setAvatarError(err.response?.data?.message ?? 'Failed to upload image.')
    } finally {
      setUploadingAvatar(false)
    }
  }

  const handleCancelAvatar = () => {
    if (avatarPreview) URL.revokeObjectURL(avatarPreview)
    setAvatarPreview(null)
    setAvatarFile(null)
    setAvatarError(null)
  }

  // ── Avatar: remove ────────────────────────────────────────
  const handleRemoveAvatar = async () => {
    if (!window.confirm('Remove your profile picture?')) return
    setAvatarError(null)
    setRemovingAvatar(true)
    try {
      const res = await api.delete('/profile/avatar')
      const updatedUser = res.data?.data?.user
      if (updatedUser) updateUser(updatedUser)
    } catch (err) {
      setAvatarError(err.response?.data?.message ?? 'Failed to remove image.')
    } finally {
      setRemovingAvatar(false)
    }
  }

  // ── Password submit ───────────────────────────────────────
  const onSubmitPassword = async (data) => {
    clearErrors()
    setPasswordError(null)
    setPasswordSuccess(null)

    // Client-side validation (catches most issues before hitting the server)
    try {
      await passwordSchema.validate(data, { abortEarly: false })
    } catch (validationErr) {
      validationErr.inner.forEach((err) => {
        setFieldError(err.path, { type: 'manual', message: err.message })
      })
      return
    }

    setChangingPassword(true)
    try {
      // NOTE: field name on the wire is `new_password` (server contract),
      // and confirmation goes as `password_confirmation` (matches the
      // backend's explicit `confirmed:password_confirmation` rule).
      await api.put('/auth/change-password', {
        current_password:      data.current_password,
        new_password:          data.password,
        password_confirmation: data.password_confirmation,
      })
      setPasswordSuccess('Password updated successfully.')
      resetPasswordForm()
    } catch (err) {
      // Surface field-level errors if the backend returned them
      const serverErrors = err.response?.data?.errors
      if (err.response?.status === 422 && serverErrors) {
        Object.entries(serverErrors).forEach(([field, messages]) => {
          // Map backend fields to frontend fields
          let frontendField = field
          if (field === 'new_password') frontendField = 'password'
          if (field === 'password_confirmation') frontendField = 'password_confirmation'

          setFieldError(frontendField, {
            type: 'server',
            message: Array.isArray(messages) ? messages.join('; ') : String(messages),
          })
        })
      }
      setPasswordError(err.response?.data?.message ?? 'Failed to update password.')
    } finally {
      setChangingPassword(false)
    }
  }

  const initial = user?.name?.charAt(0).toUpperCase() ?? 'U'

  return (
    <div className="report-page">
      <CRow className="g-4">
        {/* ── LEFT: Avatar card ───────────────────────────── */}
        <CCol xs={12} lg={4}>
          <CCard className="report-shell h-100">
            <CCardHeader className="glass-card__header">
              <h5 className="mb-0">Profile Picture</h5>
            </CCardHeader>
            <CCardBody className="text-center">
              <div className="profile-avatar-wrap mx-auto mb-3">
                {displayedAvatar ? (
                  <img
                    src={displayedAvatar}
                    alt={user?.name ?? 'Avatar'}
                    className="profile-avatar-img"
                  />
                ) : (
                  <div className="profile-avatar-fallback">{initial}</div>
                )}
              </div>

              <div className="text-muted small mb-3">
                JPG, PNG or WEBP · max {MAX_AVATAR_MB} MB
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPTED_TYPES.join(',')}
                onChange={handleAvatarChange}
                style={{ display: 'none' }}
              />

              {avatarError && (
                <CAlert color="danger" className="py-2 px-3 small mb-3">
                  {avatarError}
                </CAlert>
              )}

              <div className="d-flex flex-wrap gap-2 justify-content-center">
                {!avatarFile ? (
                  <CButton
                    size="sm"
                    color="primary"
                    variant="outline"
                    onClick={handlePickAvatar}
                    disabled={uploadingAvatar || removingAvatar}
                  >
                    <CIcon icon={cilCamera} className="me-2" />
                    {displayedAvatar ? 'Change Picture' : 'Upload Picture'}
                  </CButton>
                ) : (
                  <>
                    <CButton
                      size="sm"
                      color="primary"
                      onClick={handleUploadAvatar}
                      disabled={uploadingAvatar}
                    >
                      {uploadingAvatar ? (
                        <CSpinner size="sm" className="me-2" />
                      ) : null}
                      Save Picture
                    </CButton>
                    <CButton
                      size="sm"
                      color="secondary"
                      variant="outline"
                      onClick={handleCancelAvatar}
                      disabled={uploadingAvatar}
                    >
                      Cancel
                    </CButton>
                  </>
                )}

                {user?.avatar_url && !avatarFile && (
                  <CButton
                    size="sm"
                    color="danger"
                    variant="outline"
                    onClick={handleRemoveAvatar}
                    disabled={removingAvatar || uploadingAvatar}
                  >
                    {removingAvatar ? (
                      <CSpinner size="sm" className="me-2" />
                    ) : (
                      <CIcon icon={cilTrash} className="me-2" />
                    )}
                    Remove
                  </CButton>
                )}
              </div>
            </CCardBody>
          </CCard>
        </CCol>

        {/* ── RIGHT: Info + Password ──────────────────────── */}
        <CCol xs={12} lg={8}>
          {/* Read-only info card */}
          <CCard className="report-shell mb-4">
            <CCardHeader className="glass-card__header">
              <h5 className="mb-0">My Information</h5>
            </CCardHeader>
            <CCardBody>
              <CRow className="g-3">
                <CCol md={6}>
                  <div className="text-muted small">Name</div>
                  <div className="fw-semibold">{user?.name ?? '—'}</div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Username</div>
                  <div className="fw-semibold">{user?.username ?? '—'}</div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Email</div>
                  <div className="fw-semibold">{user?.email ?? '—'}</div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Mobile</div>
                  <div className="fw-semibold">{user?.mobile_number ?? '—'}</div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Role</div>
                  <div>
                    <CBadge color={roleBadgeColor(user?.role)}>
                      {roleLabel(user?.role)}
                    </CBadge>
                  </div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Branch</div>
                  <div className="fw-semibold">{user?.branch?.name ?? '—'}</div>
                </CCol>
                <CCol md={6}>
                  <div className="text-muted small">Created</div>
                  <div className="fw-semibold">
                    {formatDateTime(user?.created_at) || '—'}
                  </div>
                </CCol>
              </CRow>

              <CAlert color="info" className="mt-4 mb-0 small">
                <CIcon icon={cilUser} className="me-2" />
                To change your name, email, mobile or role, please contact your administrator.
              </CAlert>
            </CCardBody>
          </CCard>

          {/* Password card */}
          <CCard className="report-shell">
            <CCardHeader className="glass-card__header">
              <h5 className="mb-0">
                <CIcon icon={cilLockLocked} className="me-2" />
                Change Password
              </h5>
            </CCardHeader>
            <CCardBody>
              {passwordSuccess && (
                <CAlert color="success" dismissible onClose={() => setPasswordSuccess(null)}>
                  {passwordSuccess}
                </CAlert>
              )}
              {passwordError && (
                <CAlert color="danger" dismissible onClose={() => setPasswordError(null)}>
                  {passwordError}
                </CAlert>
              )}

              <CForm onSubmit={handleSubmit(onSubmitPassword)} autoComplete="off">
                <div className="mb-3">
                  <CFormLabel>Current Password</CFormLabel>
                  <PasswordInput
                    invalid={!!errors.current_password}
                    registerProps={register('current_password')}
                    autoComplete="current-password"
                  />
                  {errors.current_password && (
                    <div className="text-danger small mt-1">
                      {errors.current_password.message}
                    </div>
                  )}
                </div>

                <div className="mb-3">
                  <CFormLabel>New Password</CFormLabel>
                  <PasswordInput
                    invalid={!!errors.password}
                    registerProps={register('password')}
                    autoComplete="new-password"
                  />
                  <div className="text-muted small mt-1">
                    Min 8 characters, with uppercase, lowercase, number, and special character.
                  </div>
                  {errors.password && (
                    <div className="text-danger small mt-1">{errors.password.message}</div>
                  )}
                </div>

                <div className="mb-3">
                  <CFormLabel>Confirm New Password</CFormLabel>
                  <PasswordInput
                    invalid={!!errors.password_confirmation}
                    registerProps={register('password_confirmation')}
                    autoComplete="new-password"
                  />
                  {errors.password_confirmation && (
                    <div className="text-danger small mt-1">
                      {errors.password_confirmation.message}
                    </div>
                  )}
                </div>

                <div className="d-flex justify-content-end">
                  <CButton type="submit" color="primary" disabled={changingPassword}>
                    {changingPassword ? <CSpinner size="sm" className="me-2" /> : null}
                    Update Password
                  </CButton>
                </div>
              </CForm>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </div>
  )
}

export default Profile