import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
import { getBaseURL } from '../../api/api'

const RAZORPAY_SCRIPT = 'https://checkout.razorpay.com/v1/checkout.js'

function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true)
    const existing = document.querySelector(`script[src="${RAZORPAY_SCRIPT}"]`)
    if (existing) {
      existing.addEventListener('load', () => resolve(true))
      return
    }
    const s = document.createElement('script')
    s.src = RAZORPAY_SCRIPT
    s.onload = () => resolve(true)
    s.onerror = () => resolve(false)
    document.body.appendChild(s)
  })
}

export default function PublicPayment() {
  const { token } = useParams()
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [paying, setPaying] = useState(false)
  const [paid, setPaid] = useState(false)

  useEffect(() => {
    axios.get(`${getBaseURL()}/pay/${token}`, { headers: { Accept: 'application/json' } })
      .then(res => setData(res.data.data))
      .catch(err => setError(err.response?.data?.message || 'Invalid or expired link.'))
  }, [token])

  const pay = async () => {
    setPaying(true)
    setError(null)
    try {
      const scriptLoaded = await loadRazorpayScript()
      if (!scriptLoaded) {
        throw new Error('Could not load payment gateway. Please check your connection.')
      }

      // 1. Ask the backend to create a Razorpay order
      const initRes = await axios.post(
        `${getBaseURL()}/pay/${token}/initiate`,
        {},
        { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } }
      )
      const init = initRes.data.data

      // 2. Open Razorpay checkout with the order details from the backend
      await new Promise((resolve, reject) => {
        const rzp = new window.Razorpay({
          key: init.key_id,
          amount: init.amount,
          currency: init.currency || 'INR',
          order_id: init.razorpay_order_id,
          name: data.tenant_name,
          description: `Wallet top-up for ${data.customer_name}`,
          prefill: {
            name: data.customer_name,
            contact: data.customer_phone || '',
          },
          theme: { color: '#0ea5e9' },
          handler: async (response) => {
            // 3. Signature was verified by Razorpay — post it back for
            //    server-side signature verification + wallet credit.
            try {
              await axios.post(
                `${getBaseURL()}/pay/${token}/confirm`,
                {
                  razorpay_payment_id: response.razorpay_payment_id,
                  razorpay_signature: response.razorpay_signature,
                },
                { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } }
              )
              resolve(true)
            } catch (err) {
              reject(err)
            }
          },
          modal: {
            ondismiss: () => reject(new Error('Payment cancelled.')),
          },
        })
        rzp.on('payment.failed', (resp) => {
          reject(new Error(resp?.error?.description || 'Payment failed.'))
        })
        rzp.open()
      })

      setPaid(true)
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Payment failed. Please try again.')
    } finally {
      setPaying(false)
    }
  }

  if (error && !data) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f4f6f8', padding: 24 }}>
        <div style={{ background: '#fff', borderRadius: 12, padding: 40, maxWidth: 400, width: '100%', textAlign: 'center', boxShadow: '0 10px 30px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
          <h3 style={{ margin: '0 0 8px', color: '#b91c1c' }}>Link unavailable</h3>
          <p style={{ margin: 0, color: '#6c757d', fontSize: 14 }}>{error}</p>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f4f6f8' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 40, height: 40, border: '4px solid #e9ecef', borderTopColor: '#0ea5e9', borderRadius: '50%', margin: '0 auto 16px', animation: 'spin 0.8s linear infinite' }} />
          <div style={{ color: '#6c757d', fontSize: 14 }}>Loading…</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f4f6f8', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: '#fff', borderRadius: 12, padding: 32, maxWidth: 500, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.08)' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: 0, color: '#3A5B4A', fontSize: 22 }}>{data.tenant_name}</h2>
            {data.tenant_address && (
              <div style={{ fontSize: 12, color: '#6c757d', marginTop: 4 }}>{data.tenant_address}</div>
            )}
          </div>
          <div style={{ textAlign: 'right', fontSize: 12, color: '#495057', minWidth: 160 }}>
            <div style={{ fontWeight: 700, fontSize: 13 }}>{data.customer_name}</div>
            {data.customer_phone && <div style={{ marginTop: 2 }}>{data.customer_phone}</div>}
            {data.customer_address && (
              <div style={{ marginTop: 2, color: '#6c757d', lineHeight: 1.4 }}>{data.customer_address}</div>
            )}
          </div>
        </div>

        <div style={{ borderTop: '1px solid #e9ecef', paddingTop: 16, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: '#6c757d', marginBottom: 8 }}>
            <span>Current balance</span>
            <span>₹{Number(data.balance).toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16, fontWeight: 700 }}>
            <span>Amount to pay</span>
            <span style={{ color: '#0ea5e9' }}>₹{Number(data.amount).toFixed(2)}</span>
          </div>
        </div>

        {error && (
          <div style={{ background: '#fee2e2', color: '#b91c1c', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 13 }}>
            {error}
          </div>
        )}

        {!data.razorpay_ready && (
          <div style={{ background: '#fef3c7', color: '#92400e', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 13 }}>
            Online payment is not yet set up for this store. Please contact the store directly.
          </div>
        )}

        {paid ? (
          <div style={{ background: '#dcfce7', color: '#15803d', padding: 20, borderRadius: 8, textAlign: 'center', fontWeight: 700, fontSize: 15 }}>
            ✓ Payment successful. Wallet credited!
          </div>
        ) : (
          <button
            onClick={pay}
            disabled={paying || !data.razorpay_ready}
            style={{
              width: '100%', padding: 14, border: 'none', borderRadius: 8,
              background: paying || !data.razorpay_ready ? '#94a3b8' : '#0ea5e9',
              color: '#fff', fontWeight: 700, fontSize: 15,
              cursor: paying || !data.razorpay_ready ? 'not-allowed' : 'pointer',
              transition: 'background 150ms',
            }}
          >
            {paying ? 'Opening payment…' : `Pay ₹${Number(data.amount).toFixed(2)}`}
          </button>
        )}

        <div style={{ marginTop: 16, textAlign: 'center', fontSize: 11, color: '#adb5bd' }}>
          Secure payment · Powered by {data.tenant_name}
        </div>
      </div>
    </div>
  )
}