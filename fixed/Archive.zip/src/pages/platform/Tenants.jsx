import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormSelect, CFormLabel,
  CForm, CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPencil, cilPlus, cilBan, cilCheckCircle } from '@coreui/icons'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'
import TenantFormThemeSection from '../../components/TenantFormThemeSection'
import { formatDateTime } from '../../utils/formatters'

const createSchema = yup.object({
  name:      yup.string().required('Name is required'),
  email:     yup.string().email('Invalid email').required('Email is required'),
  plan:      yup.string().required('Plan is required'),
  subdomain: yup.string()
    .required('Subdomain is required')
    .matches(/^[a-z0-9-]+$/, 'Lowercase letters, numbers and hyphens only')
    .max(63, 'Max 63 characters'),
  domain: yup.string()
    .required('Domain is required')
    .matches(/^[a-z0-9.-]+\.[a-z]{2,}$/i, 'Enter a valid domain, e.g. abc.com')
    .max(255, 'Max 255 characters'),
  themeKey: yup.string().default('crimson'),
})

const editSchema = yup.object({
  name:     yup.string().required('Name is required'),
  email:    yup.string().email('Invalid email').required('Email is required'),
  plan:     yup.string().required('Plan is required'),
  status:   yup.string().required('Status is required'),
  themeKey: yup.string().default('crimson'),
})

const PLANS    = ['basic', 'pro', 'enterprise']
const STATUSES = ['active', 'inactive', 'suspended']

const Tenants = () => {
  const [tenants, setTenants]       = useState([])
  const [loading, setLoading]       = useState(true)
  const [error, setError]           = useState(null)
  const [modalError, setModalError] = useState(null)
  const [search, setSearch]         = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [modal, setModal]           = useState({ open: false, tenant: null })
  const [statusModal, setStatusModal] = useState({ open: false, tenant: null, action: null })
  const [submitting, setSubmitting] = useState(false)

  // domains (edit modal only)
  const [domains, setDomains]         = useState([])
  const [newDomain, setNewDomain]     = useState('')
  const [domainBusy, setDomainBusy]   = useState(false)
  const [domainError, setDomainError] = useState(null)

  const requestSeq = useRef(0)
  const isEdit = !!modal.tenant
  const schema = isEdit ? editSchema : createSchema

  const {
    meta, perPage, pageLoading, setPageLoading,
    updatePagination, goToPage, handlePerPageChange,
  } = usePagination(25)

  const {
    register, handleSubmit, reset, control, setValue, watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { themeKey: 'crimson' },
  })

  const fetchTenants = async ({ page = 1, searchOverride = appliedSearch } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const params = { page, per_page: perPage }
      if (searchOverride) params.search = searchOverride
      const res = await api.get('/platform/tenants', { params })
      if (mySeq !== requestSeq.current) return

      const payload = res.data?.data
      const list = Array.isArray(payload) ? payload : (payload?.data ?? [])
      const pg   = payload?.meta ?? res.data?.meta ?? {}

      setTenants(list)
      updatePagination({
        current_page: pg.current_page ?? 1,
        last_page:    pg.last_page    ?? 1,
        per_page:     pg.per_page     ?? perPage,
        total:        pg.total        ?? list.length,
        from:         pg.from         ?? null,
        to:           pg.to           ?? null,
      })
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setError(e.response?.data?.message ?? 'Failed to load tenants.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => { fetchTenants({ page: 1 }) /* eslint-disable-next-line */ }, [])

  useEffect(() => {
    const t = setTimeout(() => {
      setAppliedSearch(search)
      setPageLoading(true)
      fetchTenants({ page: 1, searchOverride: search })
    }, 400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handlePageChange = (page) => goToPage(page, fetchTenants)
  const handlePerPageChangeWrapper = (e) => handlePerPageChange(e, fetchTenants)

  const openCreate = () => {
    reset({ name: '', email: '', plan: '', subdomain: '', domain: '', themeKey: 'crimson' })
    setDomains([]); setDomainError(null); setModalError(null)
    setModal({ open: true, tenant: null })
  }

  const openEdit = (tenant) => {
    reset({
      name:     tenant.name,
      email:    tenant.email,
      plan:     tenant.plan,
      status:   tenant.status,
      themeKey: tenant.theme_key ?? 'crimson',
    })
    setDomains(tenant.domains ?? [])
    setDomainError(null); setModalError(null)
    setModal({ open: true, tenant })
  }

  const closeModal = () => { setModal({ open: false, tenant: null }); setModalError(null) }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = {
        name:      data.name,
        email:     data.email,
        plan:      data.plan,
        theme_key: data.themeKey,
        ...(isEdit
          ? { status: data.status }
          : { subdomain: data.subdomain, domain: data.domain }),
      }
      if (isEdit) await api.put(`/platform/tenants/${modal.tenant.id}`, payload)
      else        await api.post('/platform/tenants', payload)

      closeModal()
      fetchTenants({ page: meta.current_page || 1 })
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleAddDomain = async () => {
    const value = newDomain.trim().toLowerCase()
    if (!value) return
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(value)) {
      setDomainError('Enter a valid domain, e.g. abc.com'); return
    }
    setDomainBusy(true); setDomainError(null)
    try {
      const res = await api.post(`/platform/tenants/${modal.tenant.id}/domains`, { domain: value })
      setDomains(res.data.data.domains ?? []); setNewDomain('')
      fetchTenants({ page: meta.current_page || 1 })
    } catch (e) {
      setDomainError(e.response?.data?.message ?? 'Failed to add domain.')
    } finally { setDomainBusy(false) }
  }

  const handleRemoveDomain = async (domainId) => {
    if (domains.length <= 1) { setDomainError('Cannot remove the last domain for a tenant.'); return }
    setDomainBusy(true); setDomainError(null)
    try {
      const res = await api.delete(`/platform/tenants/${modal.tenant.id}/domains/${domainId}`)
      setDomains(res.data.data.domains ?? [])
      fetchTenants({ page: meta.current_page || 1 })
    } catch (e) {
      setDomainError(e.response?.data?.message ?? 'Failed to remove domain.')
    } finally { setDomainBusy(false) }
  }

  const handleStatusAction = async () => {
    const { tenant, action } = statusModal
    try {
      if (action === 'deactivate') await api.delete(`/platform/tenants/${tenant.id}`)
      else                         await api.patch(`/platform/tenants/${tenant.id}/restore`)
      setStatusModal({ open: false, tenant: null, action: null })
      fetchTenants({ page: meta.current_page || 1 })
    } catch (e) {
      setError(e.response?.data?.message ?? 'Operation failed.')
    }
  }

  const planBadgeColor = (plan) => ({
    basic: 'secondary', pro: 'info', enterprise: 'warning',
  }[plan] ?? 'secondary')

  const statusBadgeColor = (status) => ({
    active: 'success', inactive: 'secondary', suspended: 'danger',
  }[status] ?? 'secondary')

  const sNoBase = (meta.current_page - 1) * perPage

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Tenants</h4>
          <CButton size="sm" className="report-shell__export" onClick={openCreate}>
            <CIcon icon={cilPlus} className="me-2" />Add Tenant
          </CButton>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--customer">
            <CFormLabel className="filter-label">Search</CFormLabel>
            <CFormInput
              size="sm"
              className="filter-input"
              placeholder="Search tenants..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading tenants...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>Email</CTableHeaderCell>
                    <CTableHeaderCell>Domain</CTableHeaderCell>
                    <CTableHeaderCell>Plan</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Theme</CTableHeaderCell>
                    <CTableHeaderCell>Created</CTableHeaderCell>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {tenants.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={9} className="text-center text-muted py-4">
                        No tenants found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : tenants.map((tenant, i) => (
                    <CTableRow key={tenant.id}>
                      <CTableDataCell>{sNoBase + i + 1}</CTableDataCell>
                      <CTableDataCell>{tenant.name}</CTableDataCell>
                      <CTableDataCell>{tenant.email}</CTableDataCell>
                      <CTableDataCell><code>{tenant.domain}</code></CTableDataCell>
                      <CTableDataCell>
                        <CBadge color={planBadgeColor(tenant.plan)} shape="rounded-pill" className="text-capitalize">
                          {tenant.plan}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <CBadge color={statusBadgeColor(tenant.status)} shape="rounded-pill" className="text-capitalize">
                          {tenant.status}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>
                        <CBadge color="primary" shape="rounded-pill">
                          {tenant.theme_key ?? 'crimson'}
                        </CBadge>
                      </CTableDataCell>
                      <CTableDataCell>{formatDateTime(tenant.created_at)}</CTableDataCell>
                      <CTableDataCell>
                        <div className="d-flex gap-1 justify-content-center">
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => openEdit(tenant)}
                            title="Edit"
                          >
                            <CIcon icon={cilPencil} />
                          </CButton>
                          {tenant.status === 'active' || tenant.status === 'suspended' ? (
                            <CButton
                              size="sm"
                              className="table-action-btn table-action-btn--danger"
                              onClick={() => setStatusModal({ open: true, tenant, action: 'deactivate' })}
                              title="Deactivate"
                            >
                              <CIcon icon={cilBan} />
                            </CButton>
                          ) : (
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => setStatusModal({ open: true, tenant, action: 'restore' })}
                              title="Restore"
                            >
                              <CIcon icon={cilCheckCircle} />
                            </CButton>
                          )}
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* Create / Edit Modal */}
      <CModal visible={modal.open} onClose={closeModal} backdrop="static" size="lg" className="wallet-modal">
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {isEdit ? 'Edit Tenant' : 'Add Tenant'}
          </CModalTitle>
        </CModalHeader>
        <CForm onSubmit={handleSubmit(onSubmit)}>
          <CModalBody className="wallet-modal__body">
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}
            <div className="row g-3">
              <div className="col-md-6">
                <CFormLabel className="filter-label">Name <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" invalid={!!errors.name} {...register('name')} />
                {errors.name && <div className="text-danger small mt-1">{errors.name.message}</div>}
              </div>
              <div className="col-md-6">
                <CFormLabel className="filter-label">Email <span className="text-danger">*</span></CFormLabel>
                <CFormInput className="filter-input" type="email" invalid={!!errors.email} {...register('email')} />
                {errors.email && <div className="text-danger small mt-1">{errors.email.message}</div>}
              </div>

              {!isEdit && (
                <>
                  <div className="col-md-6">
                    <CFormLabel className="filter-label">Subdomain <span className="text-danger">*</span></CFormLabel>
                    <CFormInput
                      className="filter-input"
                      placeholder="e.g. shop-hub"
                      invalid={!!errors.subdomain}
                      {...register('subdomain')}
                    />
                    {errors.subdomain && <div className="text-danger small mt-1">{errors.subdomain.message}</div>}
                  </div>
                  <div className="col-md-6">
                    <CFormLabel className="filter-label">Domain <span className="text-danger">*</span></CFormLabel>
                    <CFormInput
                      className="filter-input"
                      placeholder="e.g. abc.com"
                      invalid={!!errors.domain}
                      {...register('domain')}
                    />
                    {errors.domain && <div className="text-danger small mt-1">{errors.domain.message}</div>}
                  </div>
                </>
              )}

              <div className="col-md-6">
                <CFormLabel className="filter-label">Plan <span className="text-danger">*</span></CFormLabel>
                <CFormSelect className="filter-input" invalid={!!errors.plan} {...register('plan')}>
                  <option value="">Select plan...</option>
                  {PLANS.map(p => <option key={p} value={p} className="text-capitalize">{p}</option>)}
                </CFormSelect>
                {errors.plan && <div className="text-danger small mt-1">{errors.plan.message}</div>}
              </div>

              {isEdit && (
                <div className="col-md-6">
                  <CFormLabel className="filter-label">Status <span className="text-danger">*</span></CFormLabel>
                  <CFormSelect className="filter-input" invalid={!!errors.status} {...register('status')}>
                    {STATUSES.map(s => <option key={s} value={s} className="text-capitalize">{s}</option>)}
                  </CFormSelect>
                  {errors.status && <div className="text-danger small mt-1">{errors.status.message}</div>}
                </div>
              )}

              {isEdit && (
                <div className="col-12">
                  <CFormLabel className="filter-label">Domains</CFormLabel>
                  {domainError && <div className="text-danger small mb-2">{domainError}</div>}
                  {domains.length === 0 ? (
                    <div className="text-muted small mb-2">No domains found for this tenant.</div>
                  ) : domains.map((d) => (
                    <div key={d.id} className="d-flex align-items-center justify-content-between mb-1">
                      <code>{d.domain}</code>
                      <CButton
                        size="sm"
                        className="table-action-btn table-action-btn--danger"
                        disabled={domainBusy || domains.length <= 1}
                        onClick={() => handleRemoveDomain(d.id)}
                        title="Remove"
                      >
                        <CIcon icon={cilBan} />
                      </CButton>
                    </div>
                  ))}
                  <div className="input-group mt-2">
                    <CFormInput
                      className="filter-input"
                      placeholder="Add a domain, e.g. abc.com"
                      value={newDomain}
                      onChange={(e) => setNewDomain(e.target.value)}
                      disabled={domainBusy}
                    />
                    <CButton
                      className="filter-btn filter-btn--primary"
                      onClick={handleAddDomain}
                      disabled={domainBusy}
                    >
                      {domainBusy ? <CSpinner size="sm" /> : 'Add'}
                    </CButton>
                  </div>
                </div>
              )}

              <div className="col-12">
                <TenantFormThemeSection
                  control={control}
                  setValue={setValue}
                  watch={watch}
                  tenantId={isEdit ? modal.tenant.id : null}
                />
              </div>
            </div>
          </CModalBody>
          <CModalFooter className="wallet-modal__footer">
            <CButton className="filter-btn filter-btn--ghost" onClick={closeModal} disabled={submitting}>
              Cancel
            </CButton>
            <CButton type="submit" className="filter-btn filter-btn--primary" disabled={submitting}>
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              {isEdit ? 'Update' : 'Create'}
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* Status action modal */}
      <CModal
        visible={statusModal.open}
        onClose={() => setStatusModal({ open: false, tenant: null, action: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            {statusModal.action === 'deactivate' ? 'Deactivate Tenant' : 'Restore Tenant'}
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {statusModal.action === 'deactivate' ? (
            <>Are you sure you want to deactivate <strong>{statusModal.tenant?.name}</strong>? They will not be able to login.</>
          ) : (
            <>Restore <strong>{statusModal.tenant?.name}</strong> and allow them to login again?</>
          )}
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setStatusModal({ open: false, tenant: null, action: null })}
          >
            Cancel
          </CButton>
          <CButton
            className={statusModal.action === 'deactivate'
              ? 'filter-btn filter-btn--danger'
              : 'filter-btn filter-btn--primary'}
            onClick={handleStatusAction}
          >
            {statusModal.action === 'deactivate' ? 'Deactivate' : 'Restore'}
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default Tenants