import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilTrash } from '@coreui/icons'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'
import { formatDate } from '../../utils/formatters'

const emptyItem = () => ({
  id: Math.random().toString(36).slice(2),
  product_variant_id: '',
  quantity: '',
  expiry_date: '',
})

const SORT_KEY_MAP = {
  received_date: 'received_date',
  supplier:      'supplier',
  branch:        'branch',
  created_by:    'created_by',
}

// Robust extraction of an array from any Laravel response shape
const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root

  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data

  return []
}

// ─────────────────────────────────────────────────────────────────────
// ★ Responsive modal chrome — shared with the Free Gifts pages.
// Dialog capped at 90vh, only the body scrolls, the footer
// (Save/Cancel) is always visible, edge-to-edge fullscreen on phones.
// Self-contained: no dependency on wallet-modal or any portal CSS.
// ─────────────────────────────────────────────────────────────────────
const MODAL_CSS = `
.gifts-modal .modal-dialog{max-width:min(880px,94vw) !important;width:94vw !important;margin:3vh auto !important;}
.gifts-modal--wide .modal-dialog{max-width:min(1140px,96vw) !important;width:96vw !important;}
.gifts-modal .modal-content{max-height:90vh !important;display:flex !important;flex-direction:column !important;overflow:hidden !important;}
.gifts-modal .modal-header,.gifts-modal .modal-footer{flex:0 0 auto !important;}
.gifts-modal .modal-body{flex:1 1 auto !important;overflow-y:auto !important;-webkit-overflow-scrolling:touch;}
.gifts-modal .modal-footer{border-top:1px solid rgba(0,0,0,.08);flex-wrap:wrap;gap:.5rem;}
.gifts-modal .modal-footer .btn{min-width:130px;}
.gifts-modal .gifts-modal__title{font-size:1rem;font-weight:600;}
@media (max-width:767.98px){
  .gifts-modal .modal-dialog,.gifts-modal--wide .modal-dialog{max-width:100vw !important;width:100vw !important;margin:0 !important;}
  .gifts-modal .modal-content{max-height:100vh !important;min-height:100vh;border-radius:0 !important;}
}
`

const injectModalCss = () => {
  if (!document.getElementById('gifts-modal-style')) {
    const el = document.createElement('style')
    el.id = 'gifts-modal-style'
    el.textContent = MODAL_CSS
    document.head.appendChild(el)
  }
}

const StockInward = () => {
  const [inwards, setInwards] = useState([])
  const [suppliers, setSuppliers] = useState([])
  const [variants, setVariants] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [modal, setModal] = useState(false)
  const [modalError, setModalError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const [supplierId, setSupplierId] = useState('')
  const [receivedDate, setReceivedDate] = useState(() => new Date().toISOString().slice(0, 10))
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState([emptyItem()])

  const [viewModal, setViewModal] = useState({ open: false, inward: null })

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const buildParams = (usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchInwards = async ({
    page = 1,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/stock/inward', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta =
        res.data?.data?.meta ??
        res.data?.meta ??
        {}

      setInwards(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from        ?? null,
        to:           paginationMeta.to          ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setInwards([])
      setError(err.response?.data?.message ?? 'Failed to load stock inward records.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const fetchSuppliers = async () => {
    try {
      const res = await api.get('/masters/suppliers', {
        params: { per_page: 200, is_active: 1 },
      })

      const list = extractArray(res)
      setSuppliers(list)

      if (list.length === 0) {
        console.warn('[StockInward] Suppliers API returned 0 rows.', res.data)
      }
    } catch (err) {
      console.error('[StockInward] Failed to load suppliers:', err)
      setError('Failed to load suppliers.')
    }
  }

  // ★ FREE GIFTS — include_gifts: true returns a MIXED list:
  // normal products AND gift products (gift ones get a "• GIFT" tag
  // in the dropdown). Normal products are unaffected.
  const fetchVariants = async () => {
    try {
      const res = await api.get('/masters/products', {
        params: { per_page: 500, is_active: 1, include_gifts: 1 },
      })

      const products = extractArray(res)
      const flat = products.flatMap(p =>
        (p.variants ?? []).map(v => ({ ...v, product_name: p.name }))
      )
      setVariants(flat)

      if (flat.length === 0) {
        console.warn('[StockInward] No product variants found.', res.data)
      }
    } catch (err) {
      console.error('[StockInward] Failed to load variants:', err)
    }
  }

  useEffect(() => {
    injectModalCss()
    fetchInwards({ page: 1 })
    fetchSuppliers()
    fetchVariants()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchInwards)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchInwards)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchInwards({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  // ── Create modal ────────────────────────────────────────────────
  const openCreate = () => {
    setSupplierId('')
    setReceivedDate(new Date().toISOString().slice(0, 10))
    setNotes('')
    setItems([emptyItem()])
    setModalError(null)
    setModal(true)
  }

  const addItemRow = () => setItems(prev => [...prev, emptyItem()])

  const removeItemRow = (id) => setItems(prev => prev.filter(i => i.id !== id))

  const updateItem = (id, field, value) =>
    setItems(prev => prev.map(i => i.id === id ? { ...i, [field]: value } : i))

  const selectedVariantIds = items.map(i => i.product_variant_id).filter(Boolean)

  const availableVariantsForRow = (currentId) =>
    variants.filter(v => !selectedVariantIds.includes(String(v.id)) || String(v.id) === currentId)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setModalError(null)

    if (!supplierId || !receivedDate) {
      setModalError('Supplier and received date are required.')
      return
    }
    const validItems = items.filter(i => i.product_variant_id && i.quantity)
    if (validItems.length === 0) {
      setModalError('Add at least one product line item.')
      return
    }

    setSubmitting(true)
    try {
      await api.post('/stock/inward', {
        supplier_id:   supplierId,
        received_date: receivedDate,
        notes:         notes || null,
        items: validItems.map(i => ({
          product_variant_id: i.product_variant_id,
          quantity:           i.quantity,
          expiry_date:        i.expiry_date || null,
        })),
      })
      setModal(false)
      fetchInwards()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const openView = async (inward) => {
    try {
      const res = await api.get(`/stock/inward/${inward.id}`)
      setViewModal({ open: true, inward: res.data?.data?.stock_inward })
    } catch {
      setError('Failed to load record details.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">Inward Stock</h4>
          <PermissionGate permission="stock.inward">
            <CButton size="sm" className="report-shell__export" onClick={openCreate}>
              <CIcon icon={cilPlus} className="me-2" />
              Record Inward
            </CButton>
          </PermissionGate>
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading stock inward records...
              </div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="received_date">Date</SortableHeader>
                    <SortableHeader colKey="supplier">Supplier</SortableHeader>
                    <SortableHeader colKey="branch">Branch</SortableHeader>
                    <CTableHeaderCell>Items</CTableHeaderCell>
                    <SortableHeader colKey="created_by">Recorded By</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {inwards.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No stock inward records yet.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    inwards.map((inward, i) => (
                      <CTableRow key={inward.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{formatDate(inward.received_date)}</CTableDataCell>
                        <CTableDataCell>{inward.supplier_name}</CTableDataCell>
                        <CTableDataCell>{inward.branch_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="info" shape="rounded-pill">
                            {inward.items?.length ?? 0} item(s)
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{inward.created_by}</CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => openView(inward)}
                          >
                            View
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE MODAL ==================== */}
      <CModal
        size="xl"
        visible={modal}
        onClose={() => setModal(false)}
        backdrop="static"
        scrollable
        alignment="center"
        className="gifts-modal gifts-modal--wide"
      >
        <CModalHeader className="gifts-modal__header">
          <CModalTitle className="gifts-modal__title">Record Inward Stock</CModalTitle>
        </CModalHeader>
        <CForm
          onSubmit={handleSubmit}
          style={{ display: 'flex', flexDirection: 'column', flex: '1 1 auto', minHeight: 0, overflow: 'hidden' }}
        >
          <CModalBody
            className="gifts-modal__body"
            style={{ flex: '1 1 auto', minHeight: 0, overflowY: 'auto' }}
          >
            {modalError && (
              <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                {modalError}
              </CAlert>
            )}

            <div className="row g-2 mb-3">
              <div className="col-md-5">
                <CFormLabel className="filter-label">
                  Supplier <span className="text-danger">*</span>
                </CFormLabel>
                <CFormSelect
                  size="sm"
                  className="filter-input"
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                >
                  <option value="">
                    {suppliers.length === 0 ? 'No suppliers found' : 'Select Supplier'}
                  </option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </CFormSelect>
              </div>
              <div className="col-md-3">
                <CFormLabel className="filter-label">
                  Received Date <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  size="sm"
                  className="filter-input"
                  type="date"
                  value={receivedDate}
                  onChange={(e) => setReceivedDate(e.target.value)}
                />
              </div>
              <div className="col-md-4">
                <CFormLabel className="filter-label">Notes</CFormLabel>
                <CFormInput
                  size="sm"
                  className="filter-input"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Optional"
                />
              </div>
            </div>

            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="filter-label mb-0">Line Items</span>
              <CButton
                size="sm"
                className="filter-btn filter-btn--ghost"
                onClick={addItemRow}
                disabled={
                  variants.length === 0 ||
                  selectedVariantIds.filter(Boolean).length >= variants.length
                }
                type="button"
              >
                <CIcon icon={cilPlus} className="me-1" />
                Add Row
              </CButton>
            </div>

            <div className="report-frame report-frame--scroll">
              <CTable bordered size="sm" className="admin-data-table admin-data-table--preview mb-0">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell className="bulk-col-sku">Product / Variant</CTableHeaderCell>
                    <CTableHeaderCell className="bulk-col-price">Qty</CTableHeaderCell>
                    <CTableHeaderCell>Expiry Date</CTableHeaderCell>
                    <CTableHeaderCell className="bulk-col-action"></CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {items.map(item => (
                    <CTableRow key={item.id}>
                      <CTableDataCell className="p-1">
                        <CFormSelect
                          size="sm"
                          className="filter-input"
                          value={item.product_variant_id}
                          onChange={(e) => updateItem(item.id, 'product_variant_id', e.target.value)}
                        >
                          <option value="">
                            {variants.length === 0 ? 'No variants found' : 'Select Product'}
                          </option>
                          {availableVariantsForRow(item.product_variant_id).map(v => (
                            <option key={v.id} value={v.id}>
                              {v.product_name} — {v.sku}{v.is_gift ? ' • GIFT' : ''}
                            </option>
                          ))}
                        </CFormSelect>
                      </CTableDataCell>
                      <CTableDataCell className="p-1">
                        <CFormInput
                          size="sm"
                          className="filter-input"
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(item.id, 'quantity', e.target.value)}
                        />
                      </CTableDataCell>
                      <CTableDataCell className="p-1">
                        <CFormInput
                          size="sm"
                          className="filter-input"
                          type="date"
                          value={item.expiry_date}
                          onChange={(e) => updateItem(item.id, 'expiry_date', e.target.value)}
                        />
                      </CTableDataCell>
                      <CTableDataCell className="p-1 text-center">
                        <CButton
                          size="sm"
                          className="table-action-btn"
                          onClick={() => removeItemRow(item.id)}
                          disabled={items.length === 1}
                          title="Remove"
                        >
                          <CIcon icon={cilTrash} />
                        </CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </div>

            <div className="text-muted small mt-2">
              Stock will be added to the head office branch. This record cannot be edited after saving.
            </div>
          </CModalBody>
          <CModalFooter className="gifts-modal__footer" style={{ flexShrink: 0 }}>
            <CButton
              className="filter-btn filter-btn--ghost"
              onClick={() => setModal(false)}
              disabled={submitting}
            >
              Cancel
            </CButton>
            <CButton
              type="submit"
              className="filter-btn filter-btn--primary"
              disabled={submitting}
            >
              {submitting ? <CSpinner size="sm" className="me-2" /> : null}
              Save Record
            </CButton>
          </CModalFooter>
        </CForm>
      </CModal>

      {/* ==================== VIEW MODAL ==================== */}
      <CModal
        size="lg"
        visible={viewModal.open}
        onClose={() => setViewModal({ open: false, inward: null })}
        scrollable
        alignment="center"
        className="gifts-modal"
      >
        <CModalHeader className="gifts-modal__header">
          <CModalTitle className="gifts-modal__title">Stock Inward Details</CModalTitle>
        </CModalHeader>
        <CModalBody className="gifts-modal__body">
          {viewModal.inward && (
            <>
              <div className="row g-2 mb-3 small">
                <div className="col-md-4">
                  <strong>Supplier:</strong> {viewModal.inward.supplier_name}
                </div>
                <div className="col-md-4">
                  <strong>Branch:</strong> {viewModal.inward.branch_name}
                </div>
                <div className="col-md-4">
                  <strong>Date:</strong> {viewModal.inward.received_date}
                </div>
                <div className="col-md-4">
                  <strong>Recorded By:</strong> {viewModal.inward.created_by}
                </div>
                {viewModal.inward.notes && (
                  <div className="col-12">
                    <strong>Notes:</strong> {viewModal.inward.notes}
                  </div>
                )}
              </div>

              <div className="report-frame">
                <CTable bordered responsive size="sm" className="admin-data-table admin-data-table--preview mb-0">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>Product</CTableHeaderCell>
                      <CTableHeaderCell>SKU</CTableHeaderCell>
                      <CTableHeaderCell>Quantity</CTableHeaderCell>
                      <CTableHeaderCell>Expiry</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {viewModal.inward.items?.map(item => (
                      <CTableRow key={item.id}>
                        <CTableDataCell>{item.product_name}</CTableDataCell>
                        <CTableDataCell>{item.sku}</CTableDataCell>
                        <CTableDataCell>{item.quantity}</CTableDataCell>
                        <CTableDataCell>{item.expiry_date ?? '—'}</CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              </div>
            </>
          )}
        </CModalBody>
        <CModalFooter className="gifts-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setViewModal({ open: false, inward: null })}
          >
            Close
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default StockInward
