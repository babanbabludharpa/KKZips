import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilTrash } from '@coreui/icons'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import PermissionGate from '../../components/PermissionGate'
import { usePagination } from '../../hooks/usePagination'

const emptyItem = () => ({
  id: Math.random().toString(36).slice(2),
  product_variant_id: '',
  quantity_requested: '',
})

const STATUS_COLOR = {
  pending: 'warning',
  approved: 'info',
  fulfilled: 'success',
  cancelled: 'secondary',
}

const SORT_KEY_MAP = {
  from_branch:  'from_branch',
  to_branch:    'to_branch',
  status:       'status',
  requested_by: 'requested_by',
  created_at:   'created_at',
}

const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

// ★ HO roles — all three see all requests + the branch filter dropdown.
const ADMIN_ROLES = ['staff_headoffice', 'admin', 'superadmin']

const StockRequests = () => {
  const authRole = useAuthStore((s) => s.role)

  // ★ HO users see all requests + a Branch dropdown to filter by
  //   from_branch_id. Non-HO users see only their own slice.
  const isHeadOffice = ADMIN_ROLES.includes(authRole)
  const canCreate    = !isHeadOffice  // branch-bound users raise requests

  const [requests, setRequests] = useState([])
  const [toBranches, setToBranches] = useState([])
  const [fromBranches, setFromBranches] = useState([])   // for HO branch filter
  const [variants, setVariants] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [statusFilter, setStatusFilter] = useState('')
  const [appliedStatus, setAppliedStatus] = useState('')
  const [fromBranchFilter, setFromBranchFilter] = useState('')
  const [appliedFromBranch, setAppliedFromBranch] = useState('')

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [modal, setModal] = useState(false)
  const [modalError, setModalError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const [toBranchId, setToBranchId] = useState('')
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState([emptyItem()])

  const [viewModal, setViewModal] = useState({ open: false, request: null })
  const [cancelModal, setCancelModal] = useState({ open: false, request: null })

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const buildParams = (useStatus, usePerPage, useSortKey, useSortDir, useFromBranch) => {
    const params = { per_page: usePerPage }
    if (useStatus) params.status = useStatus
    // ★ Only HO users send from_branch_id. Non-HO users' scope is
    //   forced by the backend regardless.
    if (isHeadOffice && useFromBranch) params.from_branch_id = useFromBranch
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchRequests = async ({
    page = 1,
    statusOverride = appliedStatus,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
    fromBranchOverride = appliedFromBranch,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(
          statusOverride,
          perPageOverride,
          sortKeyOverride,
          sortDirOverride,
          fromBranchOverride,
        ),
      }
      const res = await api.get('/stock/requests', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta =
        res.data?.data?.meta ??
        res.data?.meta ??
        {}

      setRequests(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRequests([])
      setError(err.response?.data?.message ?? 'Failed to load stock requests.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  const fetchToBranches = async () => {
    try {
      const res = await api.get('/settings/branches', { params: { per_page: 200 } })
      const all = extractArray(res)
      // ★ Destination — Head Office + State Office only
      setToBranches(all.filter(b => b.type === 'head_office' || b.type === 'state_office'))
      // ★ From filter (HO only) — all branches
      setFromBranches(all)
    } catch { /* silent */ }
  }

  const fetchVariants = async () => {
    try {
      const res = await api.get('/masters/products', { params: { per_page: 100, is_active: 1 } })
      const products = extractArray(res)
      const flat = products.flatMap(p =>
        (p.variants ?? []).map(v => ({ ...v, product_name: p.name }))
      )
      setVariants(flat)
    } catch (err) {
      console.error('[StockRequests] Failed to load variants:', err)
    }
  }

  useEffect(() => {
    fetchRequests({ page: 1 })
    fetchToBranches()
    if (canCreate) fetchVariants()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchRequests)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchRequests)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchRequests({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleStatusChange = (value) => {
    setStatusFilter(value)
    setAppliedStatus(value)
    setPageLoading(true)
    fetchRequests({ page: 1, statusOverride: value })
  }

  const handleFromBranchChange = (value) => {
    setFromBranchFilter(value)
    setAppliedFromBranch(value)
    setPageLoading(true)
    fetchRequests({ page: 1, fromBranchOverride: value })
  }

  // ── Create modal ────────────────────────────────────────────────
  const openCreate = () => {
    setToBranchId('')
    setNotes('')
    setItems([emptyItem()])
    setModalError(null)
    setModal(true)
  }

  const selectedVariantIds = items.map(i => i.product_variant_id).filter(Boolean)

  const availableVariantsForRow = (currentId) =>
    variants.filter(v => !selectedVariantIds.includes(String(v.id)) || String(v.id) === currentId)

  const addItemRow = () => setItems(prev => [...prev, emptyItem()])
  const removeItemRow = (id) => setItems(prev => prev.filter(i => i.id !== id))
  const updateItem = (id, field, value) =>
    setItems(prev => prev.map(i => i.id === id ? { ...i, [field]: value } : i))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setModalError(null)

    if (!toBranchId) {
      setModalError('Please select a supplying branch.')
      return
    }
    const validItems = items.filter(i => i.product_variant_id && i.quantity_requested)
    if (validItems.length === 0) {
      setModalError('Add at least one product line item.')
      return
    }

    setSubmitting(true)
    try {
      await api.post('/stock/requests', {
        to_branch_id: toBranchId,
        notes: notes || null,
        items: validItems.map(i => ({
          product_variant_id: i.product_variant_id,
          quantity_requested: i.quantity_requested,
        })),
      })
      setModal(false)
      fetchRequests()
    } catch (e) {
      setModalError(e.response?.data?.message ?? 'Operation failed.')
    } finally {
      setSubmitting(false)
    }
  }

  const openView = async (request) => {
    try {
      const res = await api.get(`/stock/requests/${request.id}`)
      setViewModal({ open: true, request: res.data?.data?.stock_request })
    } catch {
      setError('Failed to load request details.')
    }
  }

  const handleCancel = async () => {
    try {
      await api.patch(`/stock/requests/${cancelModal.request.id}/cancel`)
      setCancelModal({ open: false, request: null })
      fetchRequests()
    } catch (e) {
      setError(e.response?.data?.message ?? 'Cancel failed.')
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        <div className="report-shell__header">
          <h4 className="report-shell__title">
            Stock Requests
            {!isHeadOffice && (
              <small className="text-muted ms-2" style={{ fontSize: '0.75rem', fontWeight: 400 }}>
                ({authRole === 'staff_stateoffice' ? 'Requests to your office' : 'Your branch only'})
              </small>
            )}
          </h4>
          {canCreate && (
            <PermissionGate permission="stock.request">
              <CButton size="sm" className="report-shell__export" onClick={openCreate}>
                <CIcon icon={cilPlus} className="me-2" />
                New Request
              </CButton>
            </PermissionGate>
          )}
        </div>

        <div className="report-shell__filters">
          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={statusFilter}
              onChange={(e) => handleStatusChange(e.target.value)}
            >
              <option value="">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="fulfilled">Fulfilled</option>
              <option value="cancelled">Cancelled</option>
            </CFormSelect>
          </div>

          {/* ★ From Branch filter — HO only. Filters by the branch that raised the request. */}
          {isHeadOffice && (
            <div className="filter-field filter-field--type">
              <CFormLabel className="filter-label">From Branch</CFormLabel>
              <CFormSelect
                size="sm"
                className="filter-input"
                value={fromBranchFilter}
                onChange={(e) => handleFromBranchChange(e.target.value)}
              >
                <option value="">All Branches</option>
                {fromBranches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </CFormSelect>
            </div>
          )}

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading stock requests...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="from_branch">From</SortableHeader>
                    <SortableHeader colKey="to_branch">To</SortableHeader>
                    <CTableHeaderCell>Items</CTableHeaderCell>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="requested_by">Requested By</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {requests.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No stock requests found.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    requests.map((req, i) => (
                      <CTableRow key={req.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{req.from_branch_name}</CTableDataCell>
                        <CTableDataCell>{req.to_branch_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="info" shape="rounded-pill">
                            {req.items?.length ?? 0} item(s)
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLOR[req.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {req.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{req.requested_by}</CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            <CButton
                              size="sm"
                              className="table-action-btn"
                              onClick={() => openView(req)}
                            >
                              View
                            </CButton>
                            {/* ★ Cancel only for the branch that raised it (non-HO) */}
                            {canCreate && ['pending', 'approved'].includes(req.status) && (
                              <PermissionGate permission="stock.request">
                                <CButton
                                  size="sm"
                                  className="table-action-btn"
                                  onClick={() => setCancelModal({ open: true, request: req })}
                                  title="Cancel"
                                >
                                  <CIcon icon={cilTrash} />
                                </CButton>
                              </PermissionGate>
                            )}
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== CREATE MODAL ==================== */}
      {canCreate && (
        <CModal
          size="xl"
          visible={modal}
          onClose={() => setModal(false)}
          backdrop="static"
          className="wallet-modal"
          scrollable
        >
          <CModalHeader className="wallet-modal__header">
            <CModalTitle className="wallet-modal__title">New Stock Request</CModalTitle>
          </CModalHeader>
          <CForm onSubmit={handleSubmit}>
            <CModalBody className="wallet-modal__body">
              {modalError && (
                <CAlert color="danger" dismissible onClose={() => setModalError(null)}>
                  {modalError}
                </CAlert>
              )}

              <div className="row g-2 mb-3">
                <div className="col-md-6">
                  <CFormLabel className="filter-label">
                    Request To <span className="text-danger">*</span>
                  </CFormLabel>
                  <CFormSelect
                    size="sm"
                    className="filter-input"
                    value={toBranchId}
                    onChange={(e) => setToBranchId(e.target.value)}
                  >
                    <option value="">Select Head / State Office</option>
                    {toBranches.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.type === 'head_office' ? 'Head Office' : 'State Office'})
                      </option>
                    ))}
                  </CFormSelect>
                </div>
                <div className="col-md-6">
                  <CFormLabel className="filter-label">Notes</CFormLabel>
                  <CFormInput
                    size="sm"
                    className="filter-input"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Optional"
                  />
                </div>
              </div>

              <div className="d-flex justify-content-between align-items-center mb-2">
                <span className="filter-label mb-0">Line Items</span>
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--ghost"
                  onClick={addItemRow}
                  disabled={
                    variants.length === 0 ||
                    selectedVariantIds.filter(Boolean).length >= variants.length
                  }
                  type="button"
                >
                  <CIcon icon={cilPlus} className="me-1" />
                  Add Row
                </CButton>
              </div>

              <div className="report-frame report-frame--scroll">
                <CTable bordered size="sm" className="admin-data-table admin-data-table--preview mb-0">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell className="bulk-col-action">#</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-sku">Product / Variant</CTableHeaderCell>
                      <CTableHeaderCell>Qty Requested</CTableHeaderCell>
                      <CTableHeaderCell className="bulk-col-action"></CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {items.map((item, index) => (
                      <CTableRow key={item.id}>
                        <CTableDataCell className="p-1 text-center text-muted">
                          {index + 1}
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormSelect
                            size="sm"
                            className="filter-input"
                            value={item.product_variant_id}
                            onChange={(e) => updateItem(item.id, 'product_variant_id', e.target.value)}
                          >
                            <option value="">
                              {variants.length === 0 ? 'No variants found' : 'Select Product'}
                            </option>
                            {availableVariantsForRow(item.product_variant_id).map(v => (
                              <option key={v.id} value={v.id}>
                                {v.product_name} — {v.sku}
                              </option>
                            ))}
                          </CFormSelect>
                        </CTableDataCell>
                        <CTableDataCell className="p-1">
                          <CFormInput
                            size="sm"
                            className="filter-input"
                            type="number"
                            min="1"
                            value={item.quantity_requested}
                            onChange={(e) => updateItem(item.id, 'quantity_requested', e.target.value)}
                          />
                        </CTableDataCell>
                        <CTableDataCell className="p-1 text-center">
                          <CButton
                            size="sm"
                            className="table-action-btn"
                            onClick={() => removeItemRow(item.id)}
                            disabled={items.length === 1}
                            title="Remove"
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              </div>

              <div className="text-muted small mt-2">
                Your branch will be automatically set as the requesting branch.
              </div>
            </CModalBody>
            <CModalFooter className="wallet-modal__footer">
              <CButton
                className="filter-btn filter-btn--ghost"
                onClick={() => setModal(false)}
                disabled={submitting}
              >
                Cancel
              </CButton>
              <CButton
                type="submit"
                className="filter-btn filter-btn--primary"
                disabled={submitting}
              >
                {submitting ? <CSpinner size="sm" className="me-2" /> : null}
                Submit Request
              </CButton>
            </CModalFooter>
          </CForm>
        </CModal>
      )}

      {/* ==================== VIEW MODAL ==================== */}
      <CModal
        size="lg"
        visible={viewModal.open}
        onClose={() => setViewModal({ open: false, request: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Stock Request Details</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {viewModal.request && (
            <>
              <div className="row g-2 mb-3 small">
                <div className="col-md-4">
                  <strong>From:</strong> {viewModal.request.from_branch_name}
                </div>
                <div className="col-md-4">
                  <strong>To:</strong> {viewModal.request.to_branch_name}
                </div>
                <div className="col-md-4">
                  <strong>Status:</strong>{' '}
                  <CBadge
                    color={STATUS_COLOR[viewModal.request.status] ?? 'secondary'}
                    shape="rounded-pill"
                  >
                    {viewModal.request.status}
                  </CBadge>
                </div>
                <div className="col-md-4">
                  <strong>Requested By:</strong> {viewModal.request.requested_by}
                </div>
                {viewModal.request.actioned_by && (
                  <div className="col-md-4">
                    <strong>Actioned By:</strong> {viewModal.request.actioned_by}
                  </div>
                )}
                {viewModal.request.notes && (
                  <div className="col-12">
                    <strong>Notes:</strong> {viewModal.request.notes}
                  </div>
                )}
              </div>

              <div className="report-frame">
                <CTable bordered responsive size="sm" className="admin-data-table admin-data-table--preview mb-0">
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell>#</CTableHeaderCell>
                      <CTableHeaderCell>Product</CTableHeaderCell>
                      <CTableHeaderCell>Requested</CTableHeaderCell>
                      <CTableHeaderCell>Approved</CTableHeaderCell>
                      <CTableHeaderCell>Fulfilled</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {viewModal.request.items?.map((item, index) => (
                      <CTableRow key={item.id}>
                        <CTableDataCell>{index + 1}</CTableDataCell>
                        <CTableDataCell>
                          {item.product_name} ({item.sku})
                        </CTableDataCell>
                        <CTableDataCell>{item.quantity_requested}</CTableDataCell>
                        <CTableDataCell>{item.quantity_approved ?? '—'}</CTableDataCell>
                        <CTableDataCell>{item.quantity_fulfilled ?? '—'}</CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              </div>
            </>
          )}
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setViewModal({ open: false, request: null })}
          >
            Close
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== CANCEL MODAL ==================== */}
      <CModal
        visible={cancelModal.open}
        onClose={() => setCancelModal({ open: false, request: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">Confirm Cancel</CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          Cancel this stock request? This cannot be undone.
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setCancelModal({ open: false, request: null })}
          >
            Back
          </CButton>
          <CButton
            className="filter-btn filter-btn--danger"
            onClick={handleCancel}
          >
            Cancel Request
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default StockRequests