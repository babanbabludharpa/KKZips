import { useEffect, useRef, useState } from 'react'
import {
  CCard, CCardBody, CButton, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell, CBadge,
  CSpinner, CAlert, CFormInput, CFormLabel, CFormSelect, CForm,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilCheckCircle, cilTruck } from '@coreui/icons'
import api from '../../api/api'
import Pagination from '../../components/Pagination'
import PerPageSelector from '../../components/PerPageSelector'
import { usePagination } from '../../hooks/usePagination'

const STATUS_COLOR = {
  pending: 'warning',
  approved: 'info',
  fulfilled: 'success',
  cancelled: 'secondary',
}

// Header column key -> backend sort key (must match StockRequestService::SORTABLE)
const SORT_KEY_MAP = {
  from_branch:  'from_branch',
  to_branch:    'to_branch',
  status:       'status',
  requested_by: 'requested_by',
  created_at:   'created_at',
}

// Robust extraction of an array from any Laravel response shape
const extractArray = (res) => {
  const root = res?.data
  if (Array.isArray(root)) return root
  const inner = root?.data
  if (Array.isArray(inner)) return inner
  if (Array.isArray(inner?.data)) return inner.data
  if (Array.isArray(inner?.data?.data)) return inner.data.data
  return []
}

const AcceptStockRequests = () => {
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [statusFilter, setStatusFilter] = useState('pending')
  const [appliedStatus, setAppliedStatus] = useState('pending')

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('desc')

  const [approveModal, setApproveModal] = useState({ open: false, request: null })
  const [approvals, setApprovals] = useState({})
  const [approveError, setApproveError] = useState(null)
  const [approving, setApproving] = useState(false)

  const [fulfillModal, setFulfillModal] = useState({ open: false, request: null })
  const [fulfilling, setFulfilling] = useState(false)
  const [fulfillError, setFulfillError] = useState(null)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(25)

  const buildParams = (useStatus, usePerPage, useSortKey, useSortDir) => {
    const params = { per_page: usePerPage }
    if (useStatus) params.status = useStatus
    if (useSortKey) {
      const backendKey = SORT_KEY_MAP[useSortKey]
      if (backendKey) {
        params.sort_key = backendKey
        params.sort_dir = useSortDir
      }
    }
    return params
  }

  const fetchRequests = async ({
    page = 1,
    statusOverride = appliedStatus,
    perPageOverride = perPage,
    sortKeyOverride = sortKey,
    sortDirOverride = sortDir,
  } = {}) => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)

    try {
      const params = {
        page,
        ...buildParams(statusOverride, perPageOverride, sortKeyOverride, sortDirOverride),
      }
      const res = await api.get('/stock/requests', { params })

      if (mySeq !== requestSeq.current) return

      const list = extractArray(res)
      const paginationMeta =
        res.data?.data?.meta ??
        res.data?.meta ??
        {}

      setRequests(list)
      updatePagination({
        current_page: paginationMeta.current_page ?? 1,
        last_page:    paginationMeta.last_page    ?? 1,
        per_page:     paginationMeta.per_page     ?? perPageOverride,
        total:        paginationMeta.total        ?? list.length,
        from:         paginationMeta.from         ?? null,
        to:           paginationMeta.to           ?? null,
      })
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setRequests([])
      setError(err.response?.data?.message ?? 'Failed to load stock requests.')
    } finally {
      if (mySeq === requestSeq.current) {
        setLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchRequests({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handlePageChange = (page) => {
    goToPage(page, fetchRequests)
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, fetchRequests)
  }

  const handleSort = (key) => {
    if (!SORT_KEY_MAP[key]) return
    const nextDir = (sortKey === key && sortDir === 'asc') ? 'desc' : 'asc'
    setSortKey(key)
    setSortDir(nextDir)
    setPageLoading(true)
    fetchRequests({ page: 1, sortKeyOverride: key, sortDirOverride: nextDir })
  }

  const handleStatusChange = (value) => {
    setStatusFilter(value)
    setAppliedStatus(value)
    setPageLoading(true)
    fetchRequests({ page: 1, statusOverride: value })
  }

  // ── Approve ──────────────────────────────────────────────────
  const openApprove = async (request) => {
    try {
      const res = await api.get(`/stock/requests/${request.id}`)
      const full = res.data?.data?.stock_request
      const initial = {}
      full.items.forEach(item => { initial[item.id] = item.quantity_requested })
      setApprovals(initial)
      setApproveError(null)
      setApproveModal({ open: true, request: full })
    } catch {
      setError('Failed to load request details.')
    }
  }

  const updateApproval = (itemId, value) => {
    setApprovals(prev => ({ ...prev, [itemId]: value }))
  }

  const submitApproval = async () => {
    setApproveError(null)
    setApproving(true)
    try {
      const payload = {
        approvals: Object.entries(approvals).map(([itemId, qty]) => ({
          item_id: itemId,
          quantity_approved: qty,
        })),
      }
      await api.patch(`/stock/requests/${approveModal.request.id}/approve`, payload)
      setApproveModal({ open: false, request: null })
      fetchRequests()
    } catch (e) {
      setApproveError(e.response?.data?.message ?? 'Approval failed.')
    } finally {
      setApproving(false)
    }
  }

  // ── Fulfill ──────────────────────────────────────────────────
  const openFulfill = async (request) => {
    try {
      const res = await api.get(`/stock/requests/${request.id}`)
      setFulfillError(null)
      setFulfillModal({ open: true, request: res.data?.data?.stock_request })
    } catch {
      setError('Failed to load request details.')
    }
  }

  const submitFulfill = async () => {
    setFulfillError(null)
    setFulfilling(true)
    try {
      await api.patch(`/stock/requests/${fulfillModal.request.id}/fulfill`)
      setFulfillModal({ open: false, request: null })
      fetchRequests()
    } catch (e) {
      setFulfillError(e.response?.data?.message ?? 'Fulfillment failed.')
    } finally {
      setFulfilling(false)
    }
  }

  const SortableHeader = ({ colKey, children }) => {
    const active = sortKey === colKey
    const isDesc = active && sortDir === 'desc'
    return (
      <CTableHeaderCell
        role="button"
        aria-sort={active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
        onClick={() => handleSort(colKey)}
      >
        {children}{' '}
        <span
          className={
            'sort-icon' +
            (active ? ' sort-icon--active' : '') +
            (isDesc ? ' sort-icon--desc' : '')
          }
        />
      </CTableHeaderCell>
    )
  }

  return (
    <div className="report-page">
      <CCard className="report-shell">
        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <h4 className="report-shell__title">Accept Stock Requests</h4>
        </div>

        {/* ==================== FILTERS ==================== */}
        <div className="report-shell__filters">
          <div className="filter-field filter-field--type">
            <CFormLabel className="filter-label">Status</CFormLabel>
            <CFormSelect
              size="sm"
              className="filter-input"
              value={statusFilter}
              onChange={(e) => handleStatusChange(e.target.value)}
            >
              <option value="pending">Pending</option>
              <option value="approved">Approved (awaiting fulfillment)</option>
              <option value="fulfilled">Fulfilled</option>
              <option value="">All</option>
            </CFormSelect>
          </div>

          <div className="filter-field filter-field--perpage">
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label="Per Page"
              disabled={loading}
            />
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== TABLE ==================== */}
        <CCardBody className="p-0">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading stock requests...</div>
            </div>
          ) : (
            <>
              <CTable hover responsive bordered className="admin-data-table">
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                    <SortableHeader colKey="from_branch">From Branch</SortableHeader>
                    <SortableHeader colKey="to_branch">To Branch</SortableHeader>
                    <CTableHeaderCell>Items</CTableHeaderCell>
                    <SortableHeader colKey="status">Status</SortableHeader>
                    <SortableHeader colKey="requested_by">Requested By</SortableHeader>
                    <CTableHeaderCell>Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {requests.length === 0 ? (
                    <CTableRow>
                      <CTableDataCell colSpan={7} className="text-center text-muted py-4">
                        No requests found for this filter.
                      </CTableDataCell>
                    </CTableRow>
                  ) : (
                    requests.map((req, i) => (
                      <CTableRow key={req.id}>
                        <CTableDataCell>
                          {(meta.current_page - 1) * perPage + i + 1}
                        </CTableDataCell>
                        <CTableDataCell>{req.from_branch_name}</CTableDataCell>
                        <CTableDataCell>{req.to_branch_name}</CTableDataCell>
                        <CTableDataCell>
                          <CBadge color="info" shape="rounded-pill">
                            {req.items?.length ?? 0} item(s)
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>
                          <CBadge
                            color={STATUS_COLOR[req.status] ?? 'secondary'}
                            shape="rounded-pill"
                          >
                            {req.status}
                          </CBadge>
                        </CTableDataCell>
                        <CTableDataCell>{req.requested_by}</CTableDataCell>
                        <CTableDataCell>
                          <div className="d-flex gap-1 justify-content-center">
                            {req.status === 'pending' && (
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openApprove(req)}
                              >
                                <CIcon icon={cilCheckCircle} className="me-1" />
                                Approve
                              </CButton>
                            )}
                            {req.status === 'approved' && (
                              <CButton
                                size="sm"
                                className="table-action-btn"
                                onClick={() => openFulfill(req)}
                              >
                                <CIcon icon={cilTruck} className="me-1" />
                                Fulfill
                              </CButton>
                            )}
                          </div>
                        </CTableDataCell>
                      </CTableRow>
                    ))
                  )}
                </CTableBody>
              </CTable>

              <Pagination
                meta={meta}
                onPageChange={handlePageChange}
                loading={pageLoading}
                variant="bold"
                showPageJumper={true}
                showRecordInfo={true}
              />
            </>
          )}
        </CCardBody>
      </CCard>

      {/* ==================== APPROVE MODAL ==================== */}
      <CModal
        size="lg"
        visible={approveModal.open}
        onClose={() => setApproveModal({ open: false, request: null })}
        backdrop="static"
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            Approve Stock Request
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {approveError && (
            <CAlert color="danger" dismissible onClose={() => setApproveError(null)}>
              {approveError}
            </CAlert>
          )}
          <div className="mb-3">
            <strong>From:</strong> {approveModal.request?.from_branch_name} →{' '}
            <strong>To:</strong> {approveModal.request?.to_branch_name}
          </div>
          <div className="text-muted small mb-2">
            Adjust quantity approved per item if less stock is available than requested.
          </div>

          <div className="report-frame">
            <CTable bordered responsive size="sm" className="admin-data-table admin-data-table--preview mb-0">
              <CTableHead>
                <CTableRow>
                  <CTableHeaderCell>Product</CTableHeaderCell>
                  <CTableHeaderCell>Requested</CTableHeaderCell>
                  <CTableHeaderCell>Approve Quantity</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {approveModal.request?.items?.map(item => (
                  <CTableRow key={item.id}>
                    <CTableDataCell className="text-start">
                      {item.product_name} ({item.sku})
                    </CTableDataCell>
                    <CTableDataCell>{item.quantity_requested}</CTableDataCell>
                    <CTableDataCell>
                      <CFormInput
                        className="filter-input"
                        type="number"
                        min="0"
                        value={approvals[item.id] ?? ''}
                        onChange={(e) => updateApproval(item.id, e.target.value)}
                      />
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          </div>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setApproveModal({ open: false, request: null })}
            disabled={approving}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitApproval}
            disabled={approving}
          >
            {approving ? <CSpinner size="sm" className="me-2" /> : null}
            Approve Request
          </CButton>
        </CModalFooter>
      </CModal>

      {/* ==================== FULFILL MODAL ==================== */}
      <CModal
        visible={fulfillModal.open}
        onClose={() => setFulfillModal({ open: false, request: null })}
        className="wallet-modal"
      >
        <CModalHeader className="wallet-modal__header">
          <CModalTitle className="wallet-modal__title">
            Fulfill Stock Request
          </CModalTitle>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {fulfillError && (
            <CAlert color="danger" dismissible onClose={() => setFulfillError(null)}>
              {fulfillError}
            </CAlert>
          )}
          <p>
            This will move stock from <strong>{fulfillModal.request?.from_branch_name}</strong>{' '}
            to <strong>{fulfillModal.request?.to_branch_name}</strong> for the approved
            quantities below.
          </p>
          <ul className="small">
            {fulfillModal.request?.items?.map(item => (
              <li key={item.id}>
                {item.product_name} ({item.sku}) — {item.quantity_approved ?? 0} units
              </li>
            ))}
          </ul>
          <div className="text-muted small">
            If stock has changed since approval, this may fail — re-approve with a corrected
            quantity if so.
          </div>
        </CModalBody>
        <CModalFooter className="wallet-modal__footer">
          <CButton
            className="filter-btn filter-btn--ghost"
            onClick={() => setFulfillModal({ open: false, request: null })}
            disabled={fulfilling}
          >
            Cancel
          </CButton>
          <CButton
            className="filter-btn filter-btn--primary"
            onClick={submitFulfill}
            disabled={fulfilling}
          >
            {fulfilling ? <CSpinner size="sm" className="me-2" /> : null}
            Confirm Fulfillment
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  )
}

export default AcceptStockRequests