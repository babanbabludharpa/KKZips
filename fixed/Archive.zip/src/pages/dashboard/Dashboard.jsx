import { useEffect, useState, useRef, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CCard, CCardBody, CTable, CTableHead, CTableRow,
  CTableHeaderCell, CTableBody, CTableDataCell,
  CSpinner, CAlert, CBadge, CCol, CRow, CButton,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilChartLine, cilCheckCircle, cilXCircle,
  cilArrowTop, cilArrowBottom, cilBasket, cilTruck,
} from '@coreui/icons'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts'
import api from '../../api/api'
import useAuthStore from '../../store/authStore'
import useUiStore from '../../store/uiStore'
import { formatDateTime } from '../../utils/formatters'

const fmtINR = (v) =>
  `₹${Number(v ?? 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`

const fmtINR2 = (v) =>
  `₹${Number(v ?? 0).toFixed(2)}`

const shortDate = (iso) => {
  const d = new Date(iso)
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

const fmtRef = (type, id) => {
  if (!type && !id) return '—'
  if (!id) return type?.replace(/_/g, ' ') ?? '—'
  return `${type?.replace(/_/g, ' ') ?? 'ref'} #${id}`
}

const normalizeType = (t) =>
  String(t ?? '').trim().toLowerCase().replace(/\s+/g, '_')

const prettyType = (t) =>
  normalizeType(t).replace(/_/g, ' ') || '—'

const TYPE_BADGE_COLOR = {
  deposit:           'success',
  invoice_payment:   'primary',
  refund:            'danger',
  manual_adjustment: 'warning',
  adjustment:        'warning',
}

const getTypeBadge = (type) =>
  TYPE_BADGE_COLOR[normalizeType(type)] || 'secondary'

const isCredit = (signedDelta) => Number(signedDelta) >= 0

const STATUS_COLORS = {
  delivered:         'success',
  not_delivered:     'danger',
  cancelled:         'secondary',
  pending_payment:   'warning',
  confirmed:         'info',
  preparing:         'info',
  out_for_delivery:  'warning',
  picked_up:         'warning',
  payment_failed:    'danger',
  expired:           'secondary',
}

const PAYMENT_STATUS_COLORS = {
  paid:     'success',
  pending:  'warning',
  failed:   'danger',
  refunded: 'secondary',
}

// Reads CSS variables from <html> so charts follow theme + template.
// Recomputes whenever theme or template changes.
function useChartStyle() {
  const theme    = useUiStore(s => s.theme)
  const template = useUiStore(s => s.template)

  return useMemo(() => {
    if (typeof window === 'undefined') return {}
    const css = getComputedStyle(document.documentElement)
    const read = (name, fallback = '#000') =>
      css.getPropertyValue(name).trim() || fallback

    return {
      contentStyle: {
        background:   read('--bg-surface',   '#ffffff'),
        border:       `1px solid ${read('--border', '#e2e8f0')}`,
        borderRadius: 8,
        color:        read('--text-strong',  '#0f172a'),
        fontSize:     12,
      },
      labelStyle: { color: read('--text', '#475569') },
      cursor:     { fill: 'rgba(0,0,0,0.04)' },
      gridColor:  read('--border',     '#e2e8f0'),
      axisColor:  read('--text-muted', '#94a3b8'),
      primary:    read('--accent',     '#dc2626'),
      success:    read('--success',    '#059669'),
      danger:     read('--danger',     '#dc2626'),
      warning:    read('--warning',    '#d97706'),
      info:       read('--info',       '#0284c7'),
    }
  }, [theme, template])
}

const Dashboard = () => {
  const user = useAuthStore((s) => s.user)
  const navigate = useNavigate()
  const hasPermission = useAuthStore((s) => s.hasPermission)
  const canApproveStock    = hasPermission('stock.approve')
  const canViewStockLevels = hasPermission('report.stock_levels')
  const canViewWalletTxns  = hasPermission('report.wallet_transactions')
  const canViewOrders      = hasPermission('order.view')

  const chartStyle = useChartStyle()

  const [data, setData]       = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState(null)

  const requestSeq = useRef(0)

  const fetchDashboard = async () => {
    const mySeq = ++requestSeq.current
    setLoading(true)
    setError(null)
    try {
      const res = await api.get('/dashboard')
      if (mySeq !== requestSeq.current) return
      setData(res.data?.data ?? null)
    } catch (e) {
      if (mySeq !== requestSeq.current) return
      setError(e.response?.data?.message ?? 'Failed to load dashboard.')
      setData(null)
    } finally {
      if (mySeq === requestSeq.current) setLoading(false)
    }
  }

  useEffect(() => { fetchDashboard() }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const { modules, role_scope, orders, subscriptions, wallet, shared } = data ?? {}
  const isSuperadmin = role_scope === 'superadmin'

  const totalRevenueToday =
    (modules?.orders        ? Number(orders?.kpis?.revenue_today       ?? 0) : 0) +
    (modules?.subscriptions ? Number(subscriptions?.kpis?.revenue_today ?? 0) : 0)

  return (
    <div className="report-page">
      <CCard className="report-shell">

        {/* ==================== HEADER ==================== */}
        <div className="report-shell__header">
          <div>
            <h4 className="report-shell__title">Dashboard</h4>
          </div>
        </div>

        {/* ==================== ERROR ==================== */}
        {error && (
          <div className="report-shell__error">
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          </div>
        )}

        {/* ==================== BODY ==================== */}
        <CCardBody className="p-0">
          {loading && !data ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">Loading dashboard...</div>
            </div>
          ) : !data ? null : (
            <div className="dash-body">

              {/* ═════════════════ TODAY ═════════════════ */}
              <div className="dash-group">
                <h5 className="dash-group__title">Today</h5>

                <CRow className="g-2">
                  {(modules.orders || modules.subscriptions) && (
                    <CCol xs={6} md={6} xl={3}>
                      <KpiCard
                        icon={cilChartLine}
                        tone="primary"
                        label="Revenue Today"
                        value={fmtINR(totalRevenueToday)}
                      />
                    </CCol>
                  )}

                  {modules.orders && orders && (
                    <CCol xs={6} md={6} xl={3}>
                      <KpiCard
                        icon={cilBasket}
                        tone="info"
                        label="Orders Placed"
                        value={orders.kpis.placed_today}
                      />
                    </CCol>
                  )}
                </CRow>
              </div>

              {/* ═════════════════ ORDERS ═════════════════ */}
              {modules.orders && orders && (
                <div className="dash-group">
                  <h5 className="dash-group__title">Orders</h5>

                  <div className="dash-card mb-2">
                    <div className="dash-card__head">
                      <span className="dash-card__title">Order Revenue · Last 7 days</span>
                      <CBadge className="report-pagination__page-badge">
                        Paid orders only
                      </CBadge>
                    </div>
                    <div className="dash-card__body">
                      <ResponsiveContainer width="100%" height={180}>
                        <BarChart data={orders.charts.trend} barGap={4}>
                          <CartesianGrid stroke={chartStyle.gridColor} strokeDasharray="3 3" vertical={false} />
                          <XAxis
                            dataKey="date"
                            tickFormatter={shortDate}
                            tick={{ fill: chartStyle.axisColor, fontSize: 11 }}
                            axisLine={false}
                            tickLine={false}
                          />
                          <YAxis
                            tick={{ fill: chartStyle.axisColor, fontSize: 11 }}
                            axisLine={false}
                            tickLine={false}
                            tickFormatter={(v) =>
                              v >= 1000 ? `₹${(v / 1000).toFixed(0)}k` : `₹${v}`
                            }
                          />
                          <Tooltip
                            {...chartStyle}
                            labelFormatter={shortDate}
                            formatter={(value) => [fmtINR(value), 'Revenue']}
                          />
                          <Bar
                            dataKey="revenue"
                            name="Revenue"
                            fill={chartStyle.primary}
                            radius={[4, 4, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="dash-card">
                    <div className="dash-card__head">
                      <span className="dash-card__title">Recent Orders</span>
                      <div className="d-flex align-items-center gap-2">
                        <CBadge className="report-pagination__page-badge">
                          Last {orders.tables.recent_orders.length}
                        </CBadge>
                        {canViewOrders && (
                          <CButton
                            size="sm"
                            color="primary"
                            variant="ghost"
                            onClick={() => navigate('/orders')}
                          >
                            View all →
                          </CButton>
                        )}
                      </div>
                    </div>
                    <div className="dash-card__body p-0">
                      <CTable hover responsive bordered className="admin-data-table dash-table">
                        <CTableHead>
                          <CTableRow>
                            <CTableHeaderCell>Order</CTableHeaderCell>
                            <CTableHeaderCell>Customer</CTableHeaderCell>
                            <CTableHeaderCell>Branch</CTableHeaderCell>
                            <CTableHeaderCell>Status</CTableHeaderCell>
                            <CTableHeaderCell>Payment</CTableHeaderCell>
                            <CTableHeaderCell>Mode</CTableHeaderCell>
                            <CTableHeaderCell>Total</CTableHeaderCell>
                            <CTableHeaderCell>Placed</CTableHeaderCell>
                          </CTableRow>
                        </CTableHead>
                        <CTableBody>
                          {orders.tables.recent_orders.length === 0 ? (
                            <CTableRow>
                              <CTableDataCell colSpan={8} className="text-center text-muted py-3">
                                No orders yet.
                              </CTableDataCell>
                            </CTableRow>
                          ) : orders.tables.recent_orders.map((r) => (
                            <CTableRow key={r.id}>
                              <CTableDataCell>{r.order_number ?? `#${r.id}`}</CTableDataCell>
                              <CTableDataCell>{r.customer_name ?? '—'}</CTableDataCell>
                              <CTableDataCell>{r.branch_name ?? '—'}</CTableDataCell>
                              <CTableDataCell>
                                <CBadge color={STATUS_COLORS[r.status] ?? 'secondary'} shape="rounded-pill">
                                  {r.status?.replace(/_/g, ' ')}
                                </CBadge>
                              </CTableDataCell>
                              <CTableDataCell>
                                <CBadge
                                  color={PAYMENT_STATUS_COLORS[r.payment_status] ?? 'secondary'}
                                  shape="rounded-pill"
                                >
                                  {r.payment_status?.replace(/_/g, ' ') ?? '—'}
                                </CBadge>
                              </CTableDataCell>
                              <CTableDataCell>
                                {r.payment_mode?.replace(/_/g, ' ') ?? '—'}
                              </CTableDataCell>
                              <CTableDataCell>{fmtINR(r.total)}</CTableDataCell>
                              <CTableDataCell>{formatDateTime(r.created_at)}</CTableDataCell>
                            </CTableRow>
                          ))}
                        </CTableBody>
                      </CTable>
                    </div>
                  </div>
                </div>
              )}

              {/* ═════════════════ SUBSCRIPTIONS ═════════════════ */}
              {modules.subscriptions && subscriptions && (
                <div className="dash-group">
                  <h5 className="dash-group__title">Subscriptions</h5>

                  <CRow className="g-2 mb-2">
                    <CCol xs={6} md={3}>
                      <KpiCard
                        icon={cilTruck}
                        tone="success"
                        label="Sub Deliveries"
                        value={subscriptions.kpis.delivered}
                      />
                    </CCol>
                    <CCol xs={6} md={3}>
                      <KpiCard
                        icon={cilCheckCircle}
                        tone="success"
                        label="Delivered Today"
                        value={subscriptions.kpis.delivered}
                      />
                    </CCol>
                    <CCol xs={6} md={3}>
                      <KpiCard
                        icon={cilXCircle}
                        tone="danger"
                        label="Missed Today"
                        value={subscriptions.kpis.missed}
                      />
                    </CCol>
                  </CRow>

                  <div className="dash-card mb-2">
                    <div className="dash-card__head">
                      <span className="dash-card__title">Delivery Trend · Last 7 days</span>
                    </div>
                    <div className="dash-card__body">
                      <ResponsiveContainer width="100%" height={170}>
                        <BarChart data={subscriptions.charts.delivery_trend} barGap={4}>
                          <CartesianGrid stroke={chartStyle.gridColor} strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="date" tickFormatter={shortDate} tick={{ fill: chartStyle.axisColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                          <YAxis tick={{ fill: chartStyle.axisColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                          <Tooltip {...chartStyle} labelFormatter={shortDate} />
                          <Bar dataKey="delivered" name="Delivered" fill={chartStyle.success} radius={[4,4,0,0]} />
                          <Bar dataKey="missed"    name="Missed"    fill={chartStyle.danger}  radius={[4,4,0,0]} />
                          <Legend wrapperStyle={{ paddingTop: 6, fontSize: 11, color: chartStyle.labelStyle.color }} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {isSuperadmin && subscriptions.tables.deliveries_by_branch.length > 0 && (
                    <div className="dash-card">
                      <div className="dash-card__head">
                        <span className="dash-card__title">Today's Deliveries by Branch</span>
                      </div>
                      <div className="dash-card__body p-0">
                        <CTable hover responsive bordered className="admin-data-table dash-table">
                          <CTableHead>
                            <CTableRow>
                              <CTableHeaderCell>Branch</CTableHeaderCell>
                              <CTableHeaderCell>Total</CTableHeaderCell>
                              <CTableHeaderCell>Delivered</CTableHeaderCell>
                              <CTableHeaderCell>Pending</CTableHeaderCell>
                              <CTableHeaderCell>Missed</CTableHeaderCell>
                            </CTableRow>
                          </CTableHead>
                          <CTableBody>
                            {subscriptions.tables.deliveries_by_branch.map((r) => (
                              <CTableRow key={r.branch_id}>
                                <CTableDataCell>{r.branch_name}</CTableDataCell>
                                <CTableDataCell>{r.total}</CTableDataCell>
                                <CTableDataCell>{r.delivered}</CTableDataCell>
                                <CTableDataCell>{r.pending}</CTableDataCell>
                                <CTableDataCell>{r.missed}</CTableDataCell>
                              </CTableRow>
                            ))}
                          </CTableBody>
                        </CTable>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ═════════════════ WALLET ═════════════════ */}
              {modules.wallet && wallet && (
                <div className="dash-group">
                  <h5 className="dash-group__title">Wallet</h5>

                  <CRow className="g-2 mb-2">
                    <CCol xs={6} md={3}>
                      <KpiCard
                        icon={cilArrowTop}
                        tone="success"
                        label="Credits Today"
                        value={fmtINR(wallet.kpis.credits_today)}
                      />
                    </CCol>
                    <CCol xs={6} md={3}>
                      <KpiCard
                        icon={cilArrowBottom}
                        tone="warning"
                        label="Debits Today"
                        value={fmtINR(wallet.kpis.debits_today)}
                      />
                    </CCol>
                  </CRow>

                  <div className="dash-card">
                    <div className="dash-card__head">
                      <span className="dash-card__title">Recent Wallet Activity</span>
                      {canViewWalletTxns && (
                        <CButton
                          size="sm"
                          color="primary"
                          variant="ghost"
                          onClick={() => navigate('/reports/wallet-transactions')}
                        >
                          View all →
                        </CButton>
                      )}
                    </div>
                    <div className="dash-card__body p-0">
                      <CTable hover responsive bordered className="admin-data-table dash-table">
                        <CTableHead>
                          <CTableRow>
                            <CTableHeaderCell>Sr. No.</CTableHeaderCell>
                            <CTableHeaderCell>Date</CTableHeaderCell>
                            <CTableHeaderCell>Customer</CTableHeaderCell>
                            <CTableHeaderCell>Type</CTableHeaderCell>
                            <CTableHeaderCell>Amount</CTableHeaderCell>
                            <CTableHeaderCell>Balance After</CTableHeaderCell>
                            <CTableHeaderCell>Reference</CTableHeaderCell>
                            <CTableHeaderCell>Remark</CTableHeaderCell>
                          </CTableRow>
                        </CTableHead>
                        <CTableBody>
                          {wallet.tables.recent_activity.length === 0 ? (
                            <CTableRow>
                              <CTableDataCell colSpan={8} className="text-center text-muted py-3">
                                No recent activity.
                              </CTableDataCell>
                            </CTableRow>
                          ) : wallet.tables.recent_activity.map((r, i) => (
                            <CTableRow key={r.id}>
                              <CTableDataCell>{i + 1}</CTableDataCell>
                              <CTableDataCell>{formatDateTime(r.created_at)}</CTableDataCell>
                              <CTableDataCell>{r.customer_name}</CTableDataCell>
                              <CTableDataCell>
                                <CBadge
                                  color={getTypeBadge(r.type)}
                                  shape="rounded-pill"
                                >
                                  {prettyType(r.type)}
                                </CBadge>
                              </CTableDataCell>
                              <CTableDataCell
                                className={isCredit(r.signed_delta) ? 'text-success' : 'text-danger'}
                              >
                                {isCredit(r.signed_delta) ? '+' : ''}{fmtINR2(r.signed_delta)}
                              </CTableDataCell>
                              <CTableDataCell>{fmtINR2(r.balance_after)}</CTableDataCell>
                              <CTableDataCell>{fmtRef(r.reference_type, r.reference_id)}</CTableDataCell>
                              <CTableDataCell>{r.remark ?? '—'}</CTableDataCell>
                            </CTableRow>
                          ))}
                        </CTableBody>
                      </CTable>
                    </div>
                  </div>
                </div>
              )}

              {/* ═════════════════ STOCK ═════════════════ */}
              {shared && (
                <div className="dash-group">
                  <h5 className="dash-group__title">Stock</h5>

                  <CRow className="g-2">
                    <CCol lg={6}>
                      <div className="dash-card h-100">
                        <div className="dash-card__head">
                          <span className="dash-card__title">Low Stock Alerts</span>
                          {canViewStockLevels && (
                            <CButton
                              size="sm"
                              color="primary"
                              variant="ghost"
                              onClick={() => navigate('/reports/stock-levels')}
                            >
                              View all →
                            </CButton>
                          )}
                        </div>
                        <div className="dash-card__body p-0">
                          <CTable hover responsive bordered className="admin-data-table dash-table">
                            <CTableHead>
                              <CTableRow>
                                <CTableHeaderCell>Product</CTableHeaderCell>
                                <CTableHeaderCell>Branch</CTableHeaderCell>
                                <CTableHeaderCell>Qty</CTableHeaderCell>
                                <CTableHeaderCell>Min</CTableHeaderCell>
                              </CTableRow>
                            </CTableHead>
                            <CTableBody>
                              {shared.low_stock_items.length === 0 ? (
                                <CTableRow>
                                  <CTableDataCell colSpan={4} className="text-center text-muted py-3">
                                    No low-stock items.
                                  </CTableDataCell>
                                </CTableRow>
                              ) : shared.low_stock_items.map((r, i) => (
                                <CTableRow key={i}>
                                  <CTableDataCell>{r.product_name} ({r.sku})</CTableDataCell>
                                  <CTableDataCell>{r.branch_name}</CTableDataCell>
                                  <CTableDataCell>{r.quantity}</CTableDataCell>
                                  <CTableDataCell>{r.min_order_qty}</CTableDataCell>
                                </CTableRow>
                              ))}
                            </CTableBody>
                          </CTable>
                        </div>
                      </div>
                    </CCol>
                    <CCol lg={6}>
                      <div className="dash-card h-100">
                        <div className="dash-card__head">
                          <span className="dash-card__title">Pending Stock Requests</span>
                          {canApproveStock && (
                            <CButton
                              size="sm"
                              color="primary"
                              variant="ghost"
                              onClick={() => navigate('/stock/requests/approve')}
                            >
                              Approve →
                            </CButton>
                          )}
                        </div>
                        <div className="dash-card__body p-0">
                          <CTable hover responsive bordered className="admin-data-table dash-table">
                            <CTableHead>
                              <CTableRow>
                                <CTableHeaderCell>From</CTableHeaderCell>
                                <CTableHeaderCell>To</CTableHeaderCell>
                                <CTableHeaderCell>Items</CTableHeaderCell>
                                <CTableHeaderCell>Age</CTableHeaderCell>
                              </CTableRow>
                            </CTableHead>
                            <CTableBody>
                              {shared.pending_stock_requests.length === 0 ? (
                                <CTableRow>
                                  <CTableDataCell colSpan={4} className="text-center text-muted py-3">
                                    No pending requests.
                                  </CTableDataCell>
                                </CTableRow>
                              ) : shared.pending_stock_requests.map((r) => (
                                <CTableRow key={r.id}>
                                  <CTableDataCell>{r.from_branch}</CTableDataCell>
                                  <CTableDataCell>{r.to_branch}</CTableDataCell>
                                  <CTableDataCell>{r.item_count}</CTableDataCell>
                                  <CTableDataCell>{r.age_hours}h</CTableDataCell>
                                </CTableRow>
                              ))}
                            </CTableBody>
                          </CTable>
                        </div>
                      </div>
                    </CCol>
                  </CRow>
                </div>
              )}

            </div>
          )}
        </CCardBody>
      </CCard>
    </div>
  )
}

// ─── KpiCard ────────────────────────────────────────────────────
function KpiCard({ icon, tone = 'primary', label, value }) {
  return (
    <div className={`dash-kpi dash-kpi--${tone}`}>
      <div className="dash-kpi__icon">
        <CIcon icon={icon} width={20} height={20} />
      </div>
      <div className="dash-kpi__body">
        <div className="dash-kpi__label">{label}</div>
        <div className="dash-kpi__value">{value}</div>
      </div>
    </div>
  )
}

export default Dashboard