import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Suspense, lazy, useEffect } from 'react'
import { CSpinner } from '@coreui/react'

import DefaultLayout from './layouts/DefaultLayout'
import AuthLayout    from './layouts/AuthLayout'
import ProtectedRoute from './components/ProtectedRoute'
import useAuthStore  from './store/authStore'
import useUiStore from './store/uiStore'

// Pages — lazy loaded
const Login       = lazy(() => import('./pages/auth/Login'))
const Dashboard   = lazy(() => import('./pages/dashboard/Dashboard'))
const Profile     = lazy(() => import('./pages/profile/Profile'))
const Users       = lazy(() => import('./pages/superadmin/Users'))
const Roles       = lazy(() => import('./pages/superadmin/Roles'))
const Permissions = lazy(() => import('./pages/superadmin/Permissions'))
const Menus       = lazy(() => import('./pages/superadmin/Menus'))
const NotFound    = lazy(() => import('./pages/NotFound'))
const Tenants = lazy(() => import('./pages/platform/Tenants'))
const Units = lazy(() => import('./pages/masters/Units'))
const Cities = lazy(() => import('./pages/masters/Cities'))
const Categories = lazy(() => import('./pages/masters/Categories'))
const Products = lazy(() => import('./pages/masters/Products'))
const TaxRates = lazy(() => import('./pages/masters/TaxRates'))
const Attributes = lazy(() => import('./pages/masters/Attributes'))
const Suppliers = lazy(() => import('./pages/masters/Suppliers'))
const StockInward = lazy(() => import('./pages/stock/StockInward'))
const StockRequests = lazy(() => import('./pages/stock/StockRequests'))
const AcceptStockRequests = lazy(() => import('./pages/stock/AcceptStockRequests'))
const ProductVariants     = lazy(() => import('./pages/masters/ProductVariants'))
const VariantSchedules    = lazy(() => import('./pages/masters/VariantSchedules'))
const BranchZones = lazy(() => import('./pages/settings/BranchZones'))
const StockLevels       = lazy(() => import('./pages/reports/StockLevels'))
const StockMovements    = lazy(() => import('./pages/reports/StockMovements'))
const StockRequestsReport = lazy(() => import('./pages/reports/StockRequests'))
const PriceHistory      = lazy(() => import('./pages/reports/PriceHistory'))
const DiscountHistory   = lazy(() => import('./pages/reports/DiscountHistory'))
const StockRequestDetail = lazy(() => import('./pages/reports/StockRequestDetail'))
const LayoutBuilder = lazy(() => import('./pages/appsettings/LayoutBuilder'))
const Coupons = lazy(() => import('./pages/masters/Coupons'))
const DeliveryCharges = lazy(() => import('./pages/masters/DeliveryCharges'))
const WebBuilder = lazy(() => import('./pages/appsettings/WebBuilder'))
const DeliveryBoys  = lazy(() => import('./pages/settings/DeliveryBoys'))

// added on 2026-06-15
const TenantProfile = lazy(() => import('./pages/settings/TenantProfile'))
const Warehouses    = lazy(() => import('./pages/settings/Warehouses'))
const Branches      = lazy(() => import('./pages/settings/Branches'))

const OrdersList      = lazy(() => import('./pages/orders/OrdersList'))
const OrderDetail     = lazy(() => import('./pages/orders/OrderDetail'))
const DeliveryQueue   = lazy(() => import('./pages/orders/DeliveryQueue'))
const CancelledOrders = lazy(() => import('./pages/orders/CancelledOrders'))
const DeliveredOrders = lazy(() => import('./pages/reports/DeliveredOrders'))
const DeliveredOrdersProductWise = lazy(() => import('./pages/reports/DeliveredOrdersProductWise'))
const Customers = lazy(() => import('./pages/masters/Customers'))
const CustomerProfile = lazy(() => import('./pages/masters/CustomerProfile'))
const CustomerAddressReport = lazy(() => import('./pages/reports/CustomerAddressReport'))

// added on 2026-07-23 (subscription module)
const SubscriptionsList       = lazy(() => import('./pages/subscriptions/SubscriptionsList'))
const SubscriptionForm        = lazy(() => import('./pages/subscriptions/SubscriptionForm'))
const SubscriptionDetail      = lazy(() => import('./pages/subscriptions/SubscriptionDetail'))
const DeliveryAssignmentBoard = lazy(() => import('./pages/subscriptions/DeliveryAssignmentBoard'))
const InvoicesList            = lazy(() => import('./pages/subscriptions/InvoicesList'))
const InvoiceDetail           = lazy(() => import('./pages/subscriptions/InvoiceDetail'))

const SubscriptionDeliveryReport = lazy(() => import('./pages/subscriptions/SubscriptionDeliveryReport'))
const SubscriptionDemandReport   = lazy(() => import('./pages/subscriptions/SubscriptionDemandReport'))
const SubscriptionActivityReport   = lazy(() => import('./pages/subscriptions/SubscriptionActivityReport'))
const WalletBalanceReport     = lazy(() => import('./pages/reports/WalletBalanceReport'))
const WalletTransactionReport = lazy(() => import('./pages/reports/WalletTransactionReport'))
const CouponConsumption = lazy(() => import('./pages/reports/CouponConsumption'))
const FaqManagement = lazy(() => import('./pages/settings/faq/FaqManagement'))
const SupportReport = lazy(() => import('./pages/reports/SupportReport'))
const TenantLeaves  = lazy(() => import('./pages/settings/TenantLeaves'))
const PublicPayment = lazy(() => import('./pages/public/PublicPayment'))
const FreeGifts = lazy(() => import('./pages/masters/FreeGifts'))


// Placeholder for modules coming next
const ComingSoon = ({ name }) => (
  <div className="text-center py-5 text-muted">
    <h5>{name}</h5>
    <p>Coming soon.</p>
  </div>
)

const GuestRoute = ({ children }) => {
const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
return isAuthenticated ? <Navigate to="/dashboard" replace /> : children
}

const ThemeBridge = () => {
  const rehydrateTheme = useAuthStore(s => s.rehydrateTheme)

  useEffect(() => {
    if (typeof rehydrateTheme === 'function') rehydrateTheme()
  }, [rehydrateTheme])

  return null
}

const App = () => {
  return (
    <BrowserRouter basename={import.meta.env.PROD ? '/admin' : '/'}>
      <ThemeBridge />
      <Suspense fallback={
        <div className="min-vh-100 d-flex align-items-center justify-content-center">
          <CSpinner color="primary" />
        </div>
      }>
        <Routes>

          <Route path="/pay/:token" element={<PublicPayment />} />

          {/* ── Public ─────────────────────────────────────────────── */}
          <Route path="/login" element={
            <GuestRoute>
              <AuthLayout><Login /></AuthLayout>
            </GuestRoute>
          } />

          {/* ── 404 ────────────────────────────────────────────────── */}
          <Route path="/404" element={<NotFound />} />

          {/* ── Protected (requires auth) ───────────────────────────── */}
          <Route path="/" element={
            <ProtectedRoute>
              <DefaultLayout />
            </ProtectedRoute>
          }>
            {/* Default redirect */}
            <Route index element={<Navigate to="/dashboard" replace />} />

            {/* Dashboard — all authenticated users */}
            <Route path="dashboard" element={<Dashboard />} />

            {/* Profile — all authenticated users can view/edit their own */}
            <Route path="profile" element={<Profile />} />

            {/* Masters */}
            <Route path="masters/categories" element={
              <ProtectedRoute permission="category.view">
                <Categories />
              </ProtectedRoute>
            } />
            <Route path="masters/units" element={
              <ProtectedRoute permission="unit.view">
                <Units />
              </ProtectedRoute>
            } />
            <Route path="masters/tax-rates" element={
              <ProtectedRoute permission="taxrate.view">
                <TaxRates />
              </ProtectedRoute>
            } />
            <Route path="masters/attributes" element={
              <ProtectedRoute permission="attribute.view">
                <Attributes />
              </ProtectedRoute>
            } />
            <Route path="masters/suppliers" element={
              <ProtectedRoute permission="supplier.view">
                <Suppliers />
              </ProtectedRoute>
            } />
            <Route path="masters/customers" element={
              <ProtectedRoute permission="customer.view">
                <Customers />
              </ProtectedRoute>
            } />
            <Route path="masters/customers/:id" element={
              <ProtectedRoute permission="customer.view">
                <CustomerProfile />
              </ProtectedRoute>
            } />
            <Route path="masters/products" element={
              <ProtectedRoute permission="product.view">
                <Products />
              </ProtectedRoute>
            } />
            <Route path="masters/cities" element={
              <ProtectedRoute permission="city.view">
                <Cities />
              </ProtectedRoute>
            } />

            <Route path="masters/products/:productId/variants" element={
              <ProtectedRoute permission="product.view">
                <ProductVariants />
              </ProtectedRoute>
            } />
            <Route path="masters/products/:productId/variants/:variantId/schedules" element={
              <ProtectedRoute permission="product.edit">
                <VariantSchedules />
              </ProtectedRoute>
            } />

            <Route path="masters/coupons" element={
              <ProtectedRoute permission="coupon.view">
                <Coupons />
              </ProtectedRoute>
            } />

            <Route path="masters/delivery-charges" element={
              <ProtectedRoute permission="delivery.view">
                <DeliveryCharges />
              </ProtectedRoute>
            } />

              <Route
            path="/masters/gifts"
            element={
              <Suspense fallback={<div className="p-5 text-center"><CSpinner /></div>}>
                <FreeGifts />
              </Suspense>
            }
          />

            {/* Stock */}
            <Route path="stock" element={
              <ProtectedRoute permission="stock.request">
                <ComingSoon name="Stock" />
              </ProtectedRoute>
            } />

            <Route path="stock/inward" element={
              <ProtectedRoute permission="stock.inward">
                <StockInward />
              </ProtectedRoute>
            } />

            <Route path="stock/requests" element={
              <ProtectedRoute permission="stock.request">
                <StockRequests />
              </ProtectedRoute>
            } />

            <Route path="stock/requests/approve" element={
              <ProtectedRoute permission="stock.approve">
                <AcceptStockRequests />
              </ProtectedRoute>
            } />

            {/* Orders */}
            <Route path="orders" element={
              <ProtectedRoute permission="order.view">
                <OrdersList />
              </ProtectedRoute>
            } />
            <Route path="orders/delivery-queue" element={
              <ProtectedRoute permission="order.assign_delivery">
                <DeliveryQueue />
              </ProtectedRoute>
            } />
            <Route path="orders/cancelled" element={
              <ProtectedRoute permission="order.view_cancelled">
                <CancelledOrders />
              </ProtectedRoute>
            } />
            <Route path="orders/:id" element={
              <ProtectedRoute permission="order.view">
                <OrderDetail />
              </ProtectedRoute>
            } />

            {/* Subscriptions */}
            <Route path="subscriptions" element={
              <ProtectedRoute permission="subscription.view">
                <SubscriptionsList />
              </ProtectedRoute>
            } />
            <Route path="subscriptions/new" element={
              <ProtectedRoute permission="subscription.create">
                <SubscriptionForm />
              </ProtectedRoute>
            } />
            <Route path="subscriptions/delivery-assignment" element={
              <ProtectedRoute permission="subscription.assign_delivery">
                <DeliveryAssignmentBoard />
              </ProtectedRoute>
            } />
            <Route path="subscriptions/invoices" element={
              <ProtectedRoute permission="invoice.view">
                <InvoicesList />
              </ProtectedRoute>
            } />
            <Route path="subscriptions/invoices/:id" element={
              <ProtectedRoute permission="invoice.view">
                <InvoiceDetail />
              </ProtectedRoute>
            } />
            <Route path="subscriptions/:id" element={
              <ProtectedRoute permission="subscription.view">
                <SubscriptionDetail />
              </ProtectedRoute>
            } />

            {/* APP SETTINGS */}
            <Route path="appsettings/layout" element={
              <ProtectedRoute permission="appsettings.view">
                <LayoutBuilder />
              </ProtectedRoute>
            } />

            <Route path="appsettings/web-builder" element={
              <ProtectedRoute permission="appsettings.view">
                <WebBuilder />
              </ProtectedRoute>
            } />

            {/* Reports */}
            <Route path="reports" element={
              <ProtectedRoute permission="report.view">
                <ComingSoon name="Reports" />
              </ProtectedRoute>
            } />
            <Route path="reports/stock-levels" element={
              <ProtectedRoute permission="report.stock_levels">
                <StockLevels />
              </ProtectedRoute>
            } />
            <Route path="reports/stock-movements" element={
              <ProtectedRoute permission="report.stock_movements">
                <StockMovements />
              </ProtectedRoute>
            } />
            <Route path="reports/stock-requests" element={
              <ProtectedRoute permission="report.stock_requests">
                <StockRequestsReport />
              </ProtectedRoute>
            } />
            <Route path="reports/stock-request-detail" element={
              <ProtectedRoute permission="report.stock_request_detail">
                <StockRequestDetail />
              </ProtectedRoute>
            } />
            <Route path="reports/price-history" element={
              <ProtectedRoute permission="report.price_history">
                <PriceHistory />
              </ProtectedRoute>
            } />
            <Route path="reports/discount-history" element={
              <ProtectedRoute permission="report.discount_history">
                <DiscountHistory />
              </ProtectedRoute>
            } />
            <Route path="reports/delivered-orders" element={
              <ProtectedRoute permission="report.delivered_orders">
                <DeliveredOrders />
              </ProtectedRoute>
            } />
            <Route path="reports/delivered-orders-product-wise" element={
              <ProtectedRoute permission="report.delivered_orders_product_wise">
                <DeliveredOrdersProductWise />
              </ProtectedRoute>
            } />
            <Route path="reports/customer-addresses" element={
              <ProtectedRoute permission="report.customer_addresses">
                <CustomerAddressReport />
              </ProtectedRoute>
            } />

            <Route path="reports/wallet-balances" element={
              <ProtectedRoute permission="report.wallet_balances">
                <WalletBalanceReport />
              </ProtectedRoute>
            } />
            <Route path="reports/wallet-transactions" element={
              <ProtectedRoute permission="report.wallet_transactions">
                <WalletTransactionReport />
              </ProtectedRoute>
            } />

            <Route path="reports/coupon-consumption" element={
              <ProtectedRoute permission="report.coupon_consumption">
                <CouponConsumption />
              </ProtectedRoute>
            } />

            <Route path="reports/subscription-delivery" element={
              <ProtectedRoute permission="report.subscription_delivery">
                <SubscriptionDeliveryReport />
              </ProtectedRoute>
            } />
            <Route path="reports/subscription-demand" element={
              <ProtectedRoute permission="report.subscription_demand">
                <SubscriptionDemandReport />
              </ProtectedRoute>
            } />
            
            <Route path="reports/subscription-activity" element={
              <ProtectedRoute permission="report.subscription_activity">
                <SubscriptionActivityReport />
              </ProtectedRoute>
            } />

            <Route path="reports/support" element={
              <ProtectedRoute permission="report.support">
                <SupportReport />
              </ProtectedRoute>
            } />

            {/* Settings */}
            <Route path="settings/profile" element={
              <ProtectedRoute permission="profile.view">
                <TenantProfile />
              </ProtectedRoute>
            } />
            <Route path="settings/leaves" element={
              <ProtectedRoute permission="profile.leaves_edit">
                <TenantLeaves />
              </ProtectedRoute>
            } />
            <Route path="settings/warehouses" element={
              <ProtectedRoute permission="warehouse.view">
                <Warehouses />
              </ProtectedRoute>
            } /> 
            <Route path="settings/branches" element={
              <ProtectedRoute permission="branch.view">
                <Branches />
              </ProtectedRoute>
            } />
            <Route path="settings/faq" element={
              <ProtectedRoute permission="faq.manage">
                <FaqManagement />
              </ProtectedRoute>
            } />

            <Route path="settings/branches/:branchId/zones" element={
              <ProtectedRoute permission="branch.view">
                <BranchZones />
              </ProtectedRoute>
            } />

            <Route path="settings/delivery-boys" element={
              <ProtectedRoute permission="delivery_boy.view">
                <DeliveryBoys />
              </ProtectedRoute>
            } />

            {/* Superadmin */}
            <Route path="superadmin/users" element={
              <ProtectedRoute permission="user.view">
                <Users />
              </ProtectedRoute>
            } />
            <Route path="superadmin/roles" element={
              <ProtectedRoute permission="role.view">
                <Roles />
              </ProtectedRoute>
            } />
            <Route path="superadmin/permissions" element={
              <ProtectedRoute permission="permission.assign">
                <Permissions />
              </ProtectedRoute>
            } />
            <Route path="superadmin/menus" element={
              <ProtectedRoute permission="permission.assign">
                <Menus />
              </ProtectedRoute>
            } />

            {/* Platform Admin */}
            <Route path="platform/tenants" element={
              <ProtectedRoute connection="central">
                <Tenants />
              </ProtectedRoute>
            } />
          </Route>

          {/* ── Catch-all → 404 ────────────────────────────────────── */}
          <Route path="*" element={<Navigate to="/404" replace />} />

        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}

export default App