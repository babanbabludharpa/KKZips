import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import useUiStore from './uiStore'

const REMEMBER_FLAG_KEY = 'auth-remember-mode'

const currentEngine = () => {
  const mode = localStorage.getItem(REMEMBER_FLAG_KEY)
  return mode === 'session' ? sessionStorage : localStorage
}

const dynamicStorage = {
  getItem: (name) => currentEngine().getItem(name),
  setItem: (name, value) => currentEngine().setItem(name, value),
  removeItem: (name) => {
    localStorage.removeItem(name)
    sessionStorage.removeItem(name)
  },
}

// ── Extract theme info from a user object ─────────────────────
// Handles both shapes:
//   A) user.themeKey / user.themeMode              (flat)
//   B) user.tenant.theme_key / user.tenant.theme_mode  (nested)
// Falls back to defaults if nothing is set.
function extractTheme(user) {
  if (!user) return { template: 'crimson', mode: 'light' }

  const tenant = user.tenant ?? user

  const template =
    tenant.theme_key   ??
    tenant.themeKey    ??
    user.theme_key     ??
    user.themeKey      ??
    'crimson'

  const mode =
    tenant.theme_mode  ??
    tenant.themeMode   ??
    user.theme_mode    ??
    user.themeMode     ??
    'light'

  return { template, mode }
}

const useAuthStore = create(
  persist(
    (set, get) => ({
      token:       null,
      user:        null,
      role:        null,
      permissions: [],
      connection:  null,

      // ── setAuth ─────────────────────────────────────────────
      setAuth: (token, user, connection, options = {}) => {
        const remember = options.remember !== false
        localStorage.setItem(REMEMBER_FLAG_KEY, remember ? 'local' : 'session')

        set({
          token,
          user,
          role:        user.role        ?? null,
          permissions: user.permissions ?? [],
          connection:  connection        ?? null,
        })

        // ← CHANGED: use setThemeAndTemplate (new uiStore API)
        const { template, mode } = extractTheme(user)
        useUiStore.getState().setThemeAndTemplate({
          theme:    mode,
          template,
        })
      },

      // ── updateUser ──────────────────────────────────────────
      updateUser: (user) => {
        set({
          user,
          role:        user.role        ?? null,
          permissions: user.permissions ?? [],
        })

        // ← CHANGED
        const { template, mode } = extractTheme(user)
        useUiStore.getState().setThemeAndTemplate({
          theme:    mode,
          template,
        })
      },

      // ── clearAuth ───────────────────────────────────────────
      clearAuth: () => {
        localStorage.removeItem(REMEMBER_FLAG_KEY)
        set({
          token: null, user: null, role: null, permissions: [], connection: null,
        })

        // ← CHANGED: reset to defaults on logout
        useUiStore.getState().setThemeAndTemplate({
          theme:    'light',
          template: 'crimson',
        })
      },

      // ── rehydrateTheme ──────────────────────────────────────
      // Called on app boot by <ThemeBridge /> in App.jsx
      // Reads the persisted user's theme info and reapplies it.
      // (uiStore itself also persists theme/template in localStorage,
      //  so on a fresh load the store already has the right values —
      //  this just makes sure a server-side change is picked up.)
      rehydrateTheme: () => {
        const { user } = get()
        if (!user) return

        const { template, mode } = extractTheme(user)
        useUiStore.getState().setThemeAndTemplate({
          theme:    mode,
          template,
        })
      },

      // ── helpers (unchanged) ─────────────────────────────────
      isAuthenticated: () => !!get().token,
      hasPermission: (permission) => {
        if (!permission) return true
        return get().permissions.includes(permission)
      },
      hasRole: (role) => get().role === role,
      hasAnyPermission: (permissionList = []) =>
        permissionList.some((p) => get().permissions.includes(p)),
    }),
    {
      name: 'auth-storage',
      storage: {
        getItem: (name) => {
          const value = dynamicStorage.getItem(name)
          return value ? JSON.parse(value) : null
        },
        setItem: (name, value) => dynamicStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => dynamicStorage.removeItem(name),
      },
    }
  )
)

export default useAuthStore