import { create } from 'zustand'
import api from '../api/api'
import { PLATFORM_MENUS } from '../constants/platformMenus'

const useMenuStore = create((set, get) => ({
  menus:   [],
  loading: false,
  fetched: false,

  fetchMenus: async (connection) => {
    if (get().fetched) return

    if (connection === 'central') {
      set({ menus: PLATFORM_MENUS, fetched: true, loading: false })
      return
    }

    set({ loading: true })
    try {
      const res = await api.get('/menus/sidebar')
      set({ menus: res.data.data.menus, fetched: true })
    } catch (_) {
      set({ menus: [] })
    } finally {
      set({ loading: false })
    }
  },

  resetMenus: () => set({ menus: [], fetched: false }),
}))

export default useMenuStore