import { create } from 'zustand'
import { persist } from 'zustand/middleware'

const DEFAULT_THEME    = 'light'
const DEFAULT_TEMPLATE = 'crimson'

function applyToHtml(theme, template) {
  if (typeof document === 'undefined') return
  const root = document.documentElement
  root.dataset.theme    = theme
  root.dataset.template = template
}

const useUiStore = create(
  persist(
    (set, get) => ({
      theme: DEFAULT_THEME,
      setTheme: (theme) => {
        set({ theme })
        applyToHtml(theme, get().template)
      },
      toggleTheme: () => {
        const next = get().theme === 'dark' ? 'light' : 'dark'
        get().setTheme(next)
      },

      template: DEFAULT_TEMPLATE,
      setTemplate: (template) => {
        const safe = (typeof template === 'string' && template.length > 0)
          ? template
          : DEFAULT_TEMPLATE
        set({ template: safe })
        applyToHtml(get().theme, safe)
      },

      setThemeAndTemplate: ({ theme, template } = {}) => {
        const nextTheme = theme === 'dark' ? 'dark' : 'light'
        const nextTemplate = (typeof template === 'string' && template.length > 0)
          ? template
          : DEFAULT_TEMPLATE
        set({ theme: nextTheme, template: nextTemplate })
        applyToHtml(nextTheme, nextTemplate)
      },

      sidebarVisible:
        typeof window !== 'undefined' ? window.innerWidth >= 992 : true,
      setSidebarVisible: (val) => set({ sidebarVisible: val }),

      sidebarUnfoldable: false,
      setSidebarUnfoldable: (val) => set({ sidebarUnfoldable: val }),
    }),
    {
      name: 'ui-store',
      partialize: (state) => ({
        theme:    state.theme,
        template: state.template,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) applyToHtml(state.theme, state.template)
      },
    }
  )
)

export default useUiStore