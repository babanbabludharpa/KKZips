import { create } from 'zustand'

let idCounter = 0

export const useToastStore = create((set, get) => ({
  toasts: [],
  addToast: (type, message, autohide = 4000) => {
    const id = ++idCounter
    set({ toasts: [{ id, type, message }] })
    if (autohide) setTimeout(() => get().removeToast(id), autohide)
  },
  removeToast: (id) => set(state => ({ toasts: state.toasts.filter(t => t.id !== id) })),
}))

// Plain function export
export const toast = {
  success: (msg, t) => useToastStore.getState().addToast('success', msg, t),
  error: (msg, t) => useToastStore.getState().addToast('error', msg, t),
  warning: (msg, t) => useToastStore.getState().addToast('warning', msg, t),
  info: (msg, t) => useToastStore.getState().addToast('info', msg, t),
}