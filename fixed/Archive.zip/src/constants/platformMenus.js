export const PLATFORM_MENUS = [
  {
    id: 'p1',
    name: 'Dashboard',
    route: '/dashboard',
    icon: 'cilSpeedometer',
    children: [],
  },
  {
    id: 'p2',
    name: 'Tenants',
    route: '/platform/tenants',
    icon: 'cilPeople',
    children: [],
  },
  {
    id: 'p3',
    name: 'Plans',
    route: '/platform/plans',
    icon: 'cilList',
    children: [],
  },
  { 
    id: 'p2', 
    name: 'Tenants', 
    route: '/platform/tenants', 
    icon: 'cilPeople', 
    children: [] 
  },
]