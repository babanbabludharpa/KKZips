// import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@coreui/coreui/dist/css/coreui.min.css'

import './styles/index.css'
import './styles/coreui-overrides.css'
import './styles/themes/header-theme.css'
import './styles/themes/sidebar-theme.css'
import './styles/themes/report-theme.css'
import './styles/templates.css'

import App from './App'
import L from 'leaflet'
import iconUrl from 'leaflet/dist/images/marker-icon.png'
import iconShadow from 'leaflet/dist/images/marker-shadow.png'

L.Marker.prototype.options.icon = L.icon({
  iconUrl,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
})

createRoot(document.getElementById('root')).render(<App />)