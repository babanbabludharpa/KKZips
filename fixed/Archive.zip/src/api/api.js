import axios from 'axios'

export const getBaseURL = () => {
  const port = import.meta.env.VITE_API_PORT
  const portStr = port ? `:${port}` : ''
  return `${window.location.protocol}//${window.location.hostname}${portStr}/api/v1`
}

const api = axios.create({
  baseURL: getBaseURL(),
  headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
})

const REMEMBER_FLAG_KEY = 'auth-remember-mode'

const attachToken = (config) => {
  // Must match authStore's engine selection exactly, or the token silently
  // stops attaching after the first reload post-login with remember=false.
  const mode = localStorage.getItem(REMEMBER_FLAG_KEY)
  const engine = mode === 'session' ? sessionStorage : localStorage
  const raw = engine.getItem('auth-storage')

  if (raw) {
    try {
      const { state } = JSON.parse(raw)
      if (state?.token) config.headers.Authorization = `Bearer ${state.token}`
    } catch (_) {}
  }

  if (config.data instanceof FormData) {
    delete config.headers['Content-Type']
  }

  return config
}

const AUTH_FLOW_ENDPOINTS = ['/auth/login', '/auth/register', '/auth/forgot-password']
const isAuthFlowRequest = (config) => {
  const url = config?.url || ''
  return AUTH_FLOW_ENDPOINTS.some((endpoint) => url.includes(endpoint))
}

api.interceptors.request.use(attachToken)
api.interceptors.response.use(
  (res) => res,
  (error) => {
    const shouldForceRedirect = error.response?.status === 401 && !isAuthFlowRequest(error.config)
    if (shouldForceRedirect) {
      localStorage.removeItem('auth-storage')
      sessionStorage.removeItem('auth-storage')
      localStorage.removeItem(REMEMBER_FLAG_KEY)
      window.location.href = import.meta.env.PROD ? '/admin/login' : '/login'
    }
    return Promise.reject(error)
  }
)

export default api