// This file goes to: src/api/subscriptionApi.js
import api from './api'

const BASE = '/subscriptions'

export const subscriptionApi = {
  list: (params) => api.get(BASE, { params }),
  show: (id) => api.get(`${BASE}/${id}`),
  create: (payload) => api.post(BASE, payload),
  cancel: (id, reason) => api.post(`${BASE}/${id}/cancel`, { reason }),

  pause: (id, reason) => api.post(`${BASE}/${id}/pause`, { reason }),
  resume: (id) => api.post(`${BASE}/${id}/resume`),

  createPause: (itemId, payload) => api.post(`${BASE}/items/${itemId}/pauses`, payload),
  deletePause: (pauseId) => api.delete(`${BASE}/pauses/${pauseId}`),

  createQtyOverride: (itemId, payload) => api.post(`${BASE}/items/${itemId}/qty-overrides`, payload),

  // Board is always branch-scoped by the authenticated user's own
  // branch_id on the server. No branch param is accepted or sent.
  occurrencesForDate: (date) => api.get(`${BASE}/occurrences`, { params: { date, status: 'scheduled' } }),

  // ── New occurrence board (OccurrenceQueryController + OccurrenceAssignmentController) ──
  occurrencesReport: (params) => api.get(`${BASE}/occurrences-report`, { params }),
  reassignOccurrence: (id, payload) => api.post(`${BASE}/occurrences/${id}/reassign`, payload),
  bulkReassignOccurrences: (payload) => api.post(`${BASE}/occurrences/bulk-reassign`, payload),

  // ★ NEW — blocked dates for a branch (from tenant leaves)
  blockedDates: (params) => api.get(`${BASE}/blocked-dates`, { params }),
}

export const deliveryAssignmentApi = {
  assign: (payload) => api.post('/delivery-assignments', payload),
  mine: (date) => api.get('/delivery-assignments/mine', { params: { date } }),
}

export const deliveryConfirmationApi = {
  submit: (results) => api.post('/delivery-confirmations', { results }),
}

export const invoiceApi = {
  list: (params) => api.get('/invoices', { params }),
  show: (id) => api.get(`/invoices/${id}`),
  generate: (customerId, payload) => api.post(`/invoices/generate/${customerId}`, payload),
  cancel: (id, reason) => api.post(`/invoices/${id}/cancel`, { reason }),
  recordPayment: (id, payload) => api.post(`/invoices/${id}/payments`, payload),
}
