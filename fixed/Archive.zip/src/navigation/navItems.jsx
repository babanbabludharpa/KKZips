import CIcon from '@coreui/icons-react'
import {
  cilSpeedometer,
  cilLayers,
  cilStorage,
  cilCart,
  cilChartLine,
  cilPeople,
  cilShieldAlt,
  cilLockLocked,
} from '@coreui/icons'

// permission: null  → visible to all authenticated users
// permission: 'x'   → visible only if user has that permission
const navItems = [
  {
    component: 'CNavTitle',
    name: 'Main',
  },
  {
    component: 'CNavItem',
    name: 'Dashboard',
    to: '/dashboard',
    icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
    permission: null,
  },

  // Masters
  {
    component: 'CNavTitle',
    name: 'Masters',
    permission: 'category.view', // hide title if user can't see any masters
  },
  {
    component: 'CNavGroup',
    name: 'Masters',
    icon: <CIcon icon={cilLayers} customClassName="nav-icon" />,
    permission: 'category.view',
    items: [
      { component: 'CNavItem', name: 'Categories', to: '/masters/categories', permission: 'category.view' },
      { component: 'CNavItem', name: 'Units',      to: '/masters/units',      permission: 'unit.view' },
      { component: 'CNavItem', name: 'Suppliers',  to: '/masters/suppliers',  permission: 'supplier.view' },
      { component: 'CNavItem', name: 'Customers',  to: '/masters/customers',  permission: 'customer.view' },
      { component: 'CNavItem', name: 'Products',   to: '/masters/products',   permission: 'product.view' },
    ],
  },

  // Stock
  {
    component: 'CNavTitle',
    name: 'Inventory',
    permission: 'stock.view',
  },
  {
    component: 'CNavItem',
    name: 'Stock',
    to: '/stock',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,
    permission: 'stock.view',
  },

  // Orders
  {
    component: 'CNavTitle',
    name: 'Orders',
    permission: 'order.view',
  },
  {
    component: 'CNavItem',
    name: 'Orders',
    to: '/orders',
    icon: <CIcon icon={cilCart} customClassName="nav-icon" />,
    permission: 'order.view',
  },

  // Reports
  {
    component: 'CNavTitle',
    name: 'Analytics',
    permission: 'report.view',
  },
  {
    component: 'CNavItem',
    name: 'Reports',
    to: '/reports',
    icon: <CIcon icon={cilChartLine} customClassName="nav-icon" />,
    permission: 'report.view',
  },

  // Superadmin
  {
    component: 'CNavTitle',
    name: 'System',
    permission: 'user.view',
  },
  {
    component: 'CNavGroup',
    name: 'Administration',
    icon: <CIcon icon={cilShieldAlt} customClassName="nav-icon" />,
    permission: 'user.view',
    items: [
      { component: 'CNavItem', name: 'Users',       to: '/superadmin/users',       permission: 'user.view' },
      { component: 'CNavItem', name: 'Roles',       to: '/superadmin/roles',       permission: 'role.view' },
      { component: 'CNavItem', name: 'Permissions', to: '/superadmin/permissions', permission: 'permission.assign' },
    ],
  },
]

export default navItems
