import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Suspense, lazy, useEffect } from 'react'
import { CSpinner } from '@coreui/react'

import DefaultLayout from './layouts/DefaultLayout'
import AuthLayout    from './layouts/AuthLayout'
import ProtectedRoute from './components/ProtectedRoute'
import useAuthStore  from './store/authStore'
import useUiStore, { accentThemes } from './store/uiStore'

// Pages — lazy loaded
const Login       = lazy(() => import('./pages/auth/Login'))
const Dashboard   = lazy(() => import('./pages/dashboard/Dashboard'))
const Settings    = lazy(() => import('./pages/settings/Settings'))
const Users       = lazy(() => import('./pages/superadmin/Users'))
const Roles       = lazy(() => import('./pages/superadmin/Roles'))
const Permissions = lazy(() => import('./pages/superadmin/Permissions'))
const Menus       = lazy(() => import('./pages/superadmin/Menus'))
const NotFound    = lazy(() => import('./pages/NotFound'))
const Tenants = lazy(() => import('./pages/platform/Tenants'))
const Units = lazy(() => import('./pages/masters/Units'))
const Cities = lazy(() => import('./pages/masters/Cities'))
const Categories = lazy(() => import('./pages/masters/Categories'))
const Products = lazy(() => import('./pages/masters/Products'))
const TaxRates = lazy(() => import('./pages/masters/TaxRates'))
const Attributes = lazy(() => import('./pages/masters/Attributes'))
const Suppliers = lazy(() => import('./pages/masters/Suppliers'))
//const StockInward = lazy(() => import('./pages/stock/StockInward'))
//const StockRequests = lazy(() => import('./pages/stock/StockRequests'))


// added on 2026-06-15
const TenantProfile = lazy(() => import('./pages/settings/TenantProfile'))
const Warehouses    = lazy(() => import('./pages/settings/Warehouses'))
const Branches      = lazy(() => import('./pages/settings/Branches'))

// Placeholder for modules coming next
const ComingSoon = ({ name }) => (
  <div className="text-center py-5 text-muted">
    <h5>{name}</h5>
    <p>Coming soon.</p>
  </div>
)

const GuestRoute = ({ children }) => {
const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
return isAuthenticated ? <Navigate to="/dashboard" replace /> : children
}

const ThemeBridge = () => {
  const { theme, accent } = useUiStore()

  useEffect(() => {
    const root = document.documentElement
    root.dataset.theme = theme
    root.dataset.accent = accent
    root.dataset.coreuiTheme = theme
    root.style.setProperty('--accent', accentThemes[accent])

    const rgbMap = {
      indigo: '99, 102, 241',
      rose: '244, 63, 94',
      emerald: '16, 185, 129',
      amber: '245, 158, 11',
      cyan: '6, 182, 212',
    }

    root.style.setProperty('--accent-rgb', rgbMap[accent])
  }, [theme, accent])

  return null
}

const App = () => {
  return (
    <BrowserRouter>
      <ThemeBridge />
      <Suspense fallback={
        <div className="min-vh-100 d-flex align-items-center justify-content-center">
          <CSpinner color="primary" />
        </div>
      }>
        <Routes>

          {/* ── Public ─────────────────────────────────────────────── */}
          <Route path="/login" element={
            <GuestRoute>
              <AuthLayout><Login /></AuthLayout>
            </GuestRoute>
          } />

          {/* ── 404 ────────────────────────────────────────────────── */}
          <Route path="/404" element={<NotFound />} />

          {/* ── Protected (requires auth) ───────────────────────────── */}
          <Route path="/" element={
            <ProtectedRoute>
              <DefaultLayout />
            </ProtectedRoute>
          }>
            {/* Default redirect */}
            <Route index element={<Navigate to="/dashboard" replace />} />

            {/* Dashboard — all authenticated users */}
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="settings" element={<Settings />} />

            {/* Masters */}
            <Route path="masters/categories" element={
              <ProtectedRoute permission="category.view">
                <Categories />
              </ProtectedRoute>
            } />
            <Route path="masters/units" element={
              <ProtectedRoute permission="unit.view">
                <Units />
              </ProtectedRoute>
            } />
            <Route path="masters/tax-rates" element={
              <ProtectedRoute permission="taxrate.view">
                <TaxRates />
              </ProtectedRoute>
            } />
            <Route path="masters/attributes" element={
              <ProtectedRoute permission="attribute.view">
                <Attributes />
              </ProtectedRoute>
            } />
            <Route path="masters/suppliers" element={
              <ProtectedRoute permission="supplier.view">
                <Suppliers />
              </ProtectedRoute>
            } />
            <Route path="masters/customers" element={
              <ProtectedRoute permission="customer.view">
                <ComingSoon name="Customers" />
              </ProtectedRoute>
            } />
            <Route path="masters/products" element={
              <ProtectedRoute permission="product.view">
                <Products />
              </ProtectedRoute>
            } />
            <Route path="masters/cities" element={
              <ProtectedRoute permission="city.view">
                <Cities />
              </ProtectedRoute>
            } />

            {/* Stock */}
            <Route path="stock" element={
              <ProtectedRoute permission="stock.view">
                <ComingSoon name="Stock" />
              </ProtectedRoute>
            } />

            {/* <Route path="stock/inward" element={
              <ProtectedRoute permission="stock.view">
                <StockInward />
              </ProtectedRoute>
            } />

            <Route path="stock/requests" element={
              <ProtectedRoute permission="stock.view">
                <StockRequests />
              </ProtectedRoute>
            } /> */}

            {/* Orders */}
            <Route path="orders" element={
              <ProtectedRoute permission="order.view">
                <ComingSoon name="Orders" />
              </ProtectedRoute>
            } />

            {/* Reports */}
            <Route path="reports" element={
              <ProtectedRoute permission="report.view">
                <ComingSoon name="Reports" />
              </ProtectedRoute>
            } />

            {/* Settings */}
            <Route path="settings/profile" element={
              <ProtectedRoute permission="profile.view">
                <TenantProfile />
              </ProtectedRoute>
            } />
            <Route path="settings/warehouses" element={
              <ProtectedRoute permission="warehouse.view">
                <Warehouses />
              </ProtectedRoute>
            } /> 
            <Route path="settings/branches" element={
              <ProtectedRoute permission="branch.view">
                <Branches />
              </ProtectedRoute>
            } />

            {/* Superadmin */}
            <Route path="superadmin/users" element={
              <ProtectedRoute permission="user.view">
                <Users />
              </ProtectedRoute>
            } />
            <Route path="superadmin/roles" element={
              <ProtectedRoute permission="role.view">
                <Roles />
              </ProtectedRoute>
            } />
            <Route path="superadmin/permissions" element={
              <ProtectedRoute permission="permission.assign">
                <Permissions />
              </ProtectedRoute>
            } />
            <Route path="superadmin/menus" element={
              <ProtectedRoute permission="permission.assign">
                <Menus />
              </ProtectedRoute>
            } />

            {/* Platform Admin */}
            <Route path="platform/tenants" element={
              <ProtectedRoute connection="central">
                <Tenants />
              </ProtectedRoute>
            } />
          </Route>

          {/* ── Catch-all → 404 ────────────────────────────────────── */}
          <Route path="*" element={<Navigate to="/404" replace />} />

        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}

export default App
