import { useEffect, useState } from 'react'
import { fetchThemes } from '../config/themeTokens'
import useUiStore from '../store/uiStore'

export default function ThemePicker({
  value,
  onChange,
  previewLive = true,
  disabled    = false,
}) {
  const setTemplate = useUiStore((s) => s.setTemplate)
  const [themes,  setThemes]  = useState([])
  const [loading, setLoading] = useState(true)
  const [hovered, setHovered] = useState(null)

  useEffect(() => {
    let cancelled = false
    fetchThemes()
      .then((list) => { if (!cancelled) setThemes(list) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  const handleMouseEnter = (key) => {
    if (disabled || !previewLive) return
    setHovered(key)
    setTemplate(key)
  }

  const handleMouseLeave = () => {
    if (disabled || !previewLive) return
    setHovered(null)
    setTemplate(value || 'crimson')
  }

  const handleSelect = (key) => {
    if (disabled) return
    onChange(key)
    setTemplate(key)
  }

  if (loading) {
    return (
      <div className="text-center text-muted py-4">
        Loading themes…
      </div>
    )
  }

  return (
    <div style={{ width: '100%' }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 16,
        }}
      >
        <div>
          <div className="filter-label" style={{ marginBottom: 2 }}>Color Schema</div>
          <div className="text-muted small">
            {previewLive ? 'Hover to preview · Click to select' : 'Click a schema to select'}
          </div>
        </div>
        {value && (
          <div
            className="d-flex align-items-center gap-2 px-3 py-1"
            style={{
              background: 'var(--bg-inset)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)',
            }}
          >
            <div
              style={{
                width: 10,
                height: 10,
                borderRadius: '50%',
                background: themes.find((t) => t.key === value)?.preview ?? 'var(--accent)',
              }}
            />
            <span className="text-muted small">
              {themes.find((t) => t.key === value)?.label ?? value}
            </span>
          </div>
        )}
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: 12,
        }}
      >
        {themes.map((theme) => {
          const isSelected = value === theme.key
          const isHovered  = hovered === theme.key

          return (
            <div
              key={theme.key}
              onClick={() => handleSelect(theme.key)}
              onMouseEnter={() => handleMouseEnter(theme.key)}
              onMouseLeave={handleMouseLeave}
              style={{
                background:    'var(--bg-surface)',
                border:        `1px solid ${isSelected ? theme.preview : 'var(--border)'}`,
                borderRadius:  'var(--radius-lg)',
                padding:       14,
                cursor:        disabled ? 'not-allowed' : 'pointer',
                opacity:       disabled ? 0.5 : 1,
                outline:       isSelected ? `2px solid ${theme.preview}` : '2px solid transparent',
                outlineOffset: 2,
                transition:    'outline 0.15s, transform 0.15s, border-color 0.15s',
                transform:     isHovered && !disabled ? 'translateY(-2px)' : 'none',
                position:      'relative',
              }}
            >
              {isSelected && (
                <div
                  style={{
                    position: 'absolute',
                    top: 10,
                    right: 10,
                    width: 20,
                    height: 20,
                    borderRadius: '50%',
                    background: theme.preview,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 11,
                    color: '#fff',
                    fontWeight: 700,
                  }}
                >
                  ✓
                </div>
              )}

              <div
                style={{
                  height: 40,
                  background: theme.preview,
                  borderRadius: 8,
                  marginBottom: 12,
                  border: '1px solid rgba(0,0,0,0.08)',
                }}
              />

              <div
                style={{
                  color: 'var(--text-strong)',
                  fontSize: 13,
                  fontWeight: 700,
                  marginBottom: 4,
                }}
              >
                {theme.label}
              </div>
              <div style={{ color: 'var(--text-soft)', fontSize: 11, lineHeight: 1.4 }}>
                {theme.description}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}