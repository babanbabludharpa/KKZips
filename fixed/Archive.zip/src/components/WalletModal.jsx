import { useState, useEffect, useRef } from 'react'
import {
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CButton, CTable, CTableHead, CTableRow, CTableHeaderCell, CTableBody,
  CTableDataCell, CSpinner, CAlert, CFormInput, CFormLabel, CForm,
  CButtonGroup, CBadge,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWallet } from '@coreui/icons'
import api from '../api/api'
import PermissionGate from './PermissionGate'
import Pagination from './Pagination'
import PerPageSelector from './PerPageSelector'
import { usePagination } from '../hooks/usePagination'

const TX_TYPE_LABEL = {
  deposit: 'Top-up',
  invoice_payment: 'Invoice payment',
  refund: 'Refund',
  manual_adjustment: 'Manual adjustment',
}

const TX_TYPE_BADGE = {
  deposit: 'success',
  invoice_payment: 'primary',
  refund: 'danger',
  manual_adjustment: 'warning',
}

const getTypeBadge = (type) =>
  TX_TYPE_BADGE[String(type ?? '').toLowerCase()] || 'secondary'

const formatDate = (d) => (d ? d.slice(0, 16).replace('T', ' ') : '—')

// Renders the absolute value only — sign is decided by the caller.
const fmtINR2 = (v) => `₹${Math.abs(Number(v ?? 0)).toFixed(2)}`

const AMOUNT_TONE = {
  credit: { sign: '+', className: 'text-success' },
  debit:  { sign: '−', className: 'text-danger'  },
}

// signed_delta is computed server-side (LAG over balance_after) and is the
// single source of truth for credit vs debit. Positive = credit, negative
// = debit.
function resolveIsCredit(t) {
  return Number(t.signed_delta ?? 0) >= 0
}

// ─── Extracted class-name helpers (no nested ternaries) ───
function directionButtonClass(activeDirection, buttonDirection, tone) {
  if (activeDirection !== buttonDirection) {
    return 'wallet-dir-btn'
  }
  return `wallet-dir-btn wallet-dir-btn--active-${tone}`
}

function balanceValueClass(balance) {
  if (Number(balance) < 0) {
    return 'wallet-modal__balance-value wallet-modal__balance-value--negative'
  }
  return 'wallet-modal__balance-value'
}

const emptyWalletForm = { amount: '', direction: 'credit', remark: '' }

export default function WalletModal({ open, customer, onClose }) {
  const [balance, setBalance] = useState(0)
  const [tx, setTx] = useState([])
  const [txLoading, setTxLoading] = useState(false)
  const [form, setForm] = useState(emptyWalletForm)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)

  const requestSeq = useRef(0)

  const {
    meta,
    perPage,
    pageLoading,
    setPageLoading,
    updatePagination,
    goToPage,
    handlePerPageChange,
  } = usePagination(10)

  const fetchTx = async ({ page = 1, perPageOverride = perPage } = {}) => {
    if (!customer) return

    const mySeq = ++requestSeq.current
    setTxLoading(true)
    setError(null)

    try {
      const res = await api.get(
        `/masters/customers/${customer.id}/wallet/transactions`,
        { params: { page, per_page: perPageOverride } }
      )

      if (mySeq !== requestSeq.current) return

      const d = res.data?.data
      setBalance(d?.balance ?? 0)

      const txNode = d?.transactions
      const list = Array.isArray(txNode) ? txNode : (txNode?.data ?? [])
      const hasMeta = !Array.isArray(txNode) && !!txNode?.current_page

      setTx(list)
      updatePagination(
        hasMeta
          ? txNode
          : {
              current_page: 1,
              last_page: 1,
              total: list.length,
              per_page: perPageOverride,
            }
      )
    } catch (err) {
      if (mySeq !== requestSeq.current) return
      setTx([])
      setError(err.response?.data?.message ?? 'Failed to load wallet history.')
    } finally {
      if (mySeq === requestSeq.current) {
        setTxLoading(false)
        setPageLoading(false)
      }
    }
  }

  useEffect(() => {
    if (!open || !customer) return
    fetchTx({ page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, customer?.id])

  const handlePageChange = (page) => {
    goToPage(page, (p) => fetchTx(p))
  }

  const handlePerPageChangeWrapper = (e) => {
    handlePerPageChange(e, (perPageOverride) =>
      fetchTx({ page: 1, perPageOverride })
    )
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)

    // Number() + Number.isFinite() rejects empty string, 'abc', '12abc',
    // Infinity in one check, and avoids SonarQube S7773.
    const amountNum = Number(form.amount)
    if (!Number.isFinite(amountNum) || amountNum <= 0) {
      setError('Enter an amount greater than zero.')
      return
    }

    if (!form.remark.trim()) {
      setError('A remark is required.')
      return
    }

    setSubmitting(true)
    try {
      await api.post(`/masters/customers/${customer.id}/wallet/adjust`, {
        amount: amountNum,
        direction: form.direction,
        remark: form.remark.trim(),
      })
      setForm(emptyWalletForm)
      await fetchTx({ page: 1 })
    } catch (err) {
      setError(err.response?.data?.message ?? 'Wallet update failed.')
    } finally {
      setSubmitting(false)
    }
  }

  // ─── Amount renderer ───
  const renderAmount = (t) => {
    const signed = Number(t.signed_delta ?? 0)
    const toneKey = resolveIsCredit(t) ? 'credit' : 'debit'
    const { sign, className } = AMOUNT_TONE[toneKey]

    return (
      <span className={className}>
        {sign}{fmtINR2(signed)}
      </span>
    )
  }

  // ─── Balance renderer ───
  const renderBalance = (value) => {
    const num = Number(value ?? 0)
    const prefix = num < 0 ? '−' : ''

    return `${prefix}${fmtINR2(num)}`
  }

  // ─── Transaction body renderer (extracted from JSX ternary chain) ───
  const renderTxBody = () => {
    if (txLoading) {
      return (
        <div className="wallet-tx__loading">
          <CSpinner size="sm" />
        </div>
      )
    }

    if (tx.length === 0) {
      return <div className="wallet-tx__empty">No wallet activity yet.</div>
    }

    return (
      <>
        <CTable
          hover
          responsive
          bordered
          className="admin-data-table admin-data-table--preview wallet-tx__table"
        >
          <CTableHead>
            <CTableRow>
              <CTableHeaderCell>#</CTableHeaderCell>
              <CTableHeaderCell>Date</CTableHeaderCell>
              <CTableHeaderCell>Type</CTableHeaderCell>
              <CTableHeaderCell>Amount</CTableHeaderCell>
              <CTableHeaderCell>Balance</CTableHeaderCell>
              <CTableHeaderCell>Remark</CTableHeaderCell>
            </CTableRow>
          </CTableHead>
          <CTableBody>
            {tx.map((t, i) => (
              <CTableRow key={t.id}>
                <CTableDataCell>
                  {(meta.current_page - 1) * perPage + i + 1}
                </CTableDataCell>
                <CTableDataCell className="text-nowrap">
                  {formatDate(t.created_at)}
                </CTableDataCell>
                <CTableDataCell>
                  <CBadge color={getTypeBadge(t.type)} shape="rounded-pill">
                    {TX_TYPE_LABEL[t.type] ?? t.type}
                  </CBadge>
                </CTableDataCell>
                <CTableDataCell>{renderAmount(t)}</CTableDataCell>
                <CTableDataCell>{renderBalance(t.balance_after)}</CTableDataCell>
                <CTableDataCell className="wallet-tx__remark">
                  {t.remark ?? '—'}
                </CTableDataCell>
              </CTableRow>
            ))}
          </CTableBody>
        </CTable>

        <Pagination
          meta={meta}
          onPageChange={handlePageChange}
          loading={pageLoading}
          variant="compact"
          showPageJumper={false}
          showRecordInfo={true}
        />
      </>
    )
  }

  return (
    <CModal
      visible={open}
      onClose={onClose}
      backdrop="static"
      size="lg"
      className="wallet-modal"
      scrollable
    >
      <CModalHeader className="wallet-modal__header">
        <div className="wallet-modal__header-left">
          <div className="wallet-modal__icon">
            <CIcon icon={cilWallet} />
          </div>
          <CModalTitle className="wallet-modal__title">
            Wallet — {customer?.name ?? ''}
          </CModalTitle>
        </div>

        <div className="wallet-modal__balance">
          <span className="wallet-modal__balance-label">Balance</span>
          <span className={balanceValueClass(balance)}>
            {renderBalance(balance)}
          </span>
        </div>
      </CModalHeader>

      <CModalBody className="wallet-modal__body">
        {error && (
          <CAlert
            color="danger"
            dismissible
            onClose={() => setError(null)}
            className="wallet-modal__alert"
          >
            {error}
          </CAlert>
        )}

        <PermissionGate permission="customer.wallet_adjust">
          <CForm onSubmit={handleSubmit} className="wallet-adjust">
            <div className="wallet-adjust__row">
              <div className="wallet-adjust__field wallet-adjust__field--dir">
                <CFormLabel className="filter-label">Direction</CFormLabel>
                <CButtonGroup className="d-flex" role="group">
                  <CButton
                    size="sm"
                    className={directionButtonClass(form.direction, 'credit', 'credit')}
                    onClick={() => setForm((f) => ({ ...f, direction: 'credit' }))}
                    type="button"
                  >
                    Credit
                  </CButton>
                  <CButton
                    size="sm"
                    className={directionButtonClass(form.direction, 'debit', 'debit')}
                    onClick={() => setForm((f) => ({ ...f, direction: 'debit' }))}
                    type="button"
                  >
                    Debit
                  </CButton>
                </CButtonGroup>
              </div>

              <div className="wallet-adjust__field wallet-adjust__field--amt">
                <CFormLabel className="filter-label">Amount (₹)</CFormLabel>
                <CFormInput
                  size="sm"
                  className="filter-input"
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={form.amount}
                  onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
                  placeholder="0.00"
                />
              </div>

              <div className="wallet-adjust__field wallet-adjust__field--remark">
                <CFormLabel className="filter-label">
                  Remark <span className="text-danger">*</span>
                </CFormLabel>
                <CFormInput
                  size="sm"
                  className="filter-input"
                  maxLength={255}
                  value={form.remark}
                  onChange={(e) => setForm((f) => ({ ...f, remark: e.target.value }))}
                  placeholder="e.g. Cash received, cheque no. 004521"
                />
              </div>

              <div className="wallet-adjust__field wallet-adjust__field--apply">
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--primary w-100"
                  type="submit"
                  disabled={submitting}
                >
                  {submitting ? <CSpinner size="sm" /> : 'Apply'}
                </CButton>
              </div>
            </div>
          </CForm>
        </PermissionGate>

        <div className="wallet-tx">
          <div className="wallet-tx__head">
            <span className="wallet-tx__title">Recent transactions</span>
            <PerPageSelector
              value={perPage}
              onChange={handlePerPageChangeWrapper}
              label=""
              disabled={txLoading}
            />
          </div>

          {renderTxBody()}
        </div>
      </CModalBody>

      <CModalFooter className="wallet-modal__footer">
        <CButton className="filter-btn filter-btn--ghost" onClick={onClose}>
          Close
        </CButton>
      </CModalFooter>
    </CModal>
  )
}