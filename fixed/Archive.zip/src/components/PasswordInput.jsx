import { forwardRef, useState } from 'react'
import { CFormInput, CInputGroup, CInputGroupText } from '@coreui/react'

const EyeIcon = ({ open }) => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {open ? (
      <>
        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20C5 20 1 12 1 12a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22" />
        <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" />
      </>
    ) : (
      <>
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
        <circle cx="12" cy="12" r="3" />
      </>
    )}
  </svg>
)

const PasswordInput = forwardRef(function PasswordInput(
  { invalid, className = 'filter-input', ...rest },
  ref
) {
  const [visible, setVisible] = useState(false)

  return (
    <CInputGroup className="password-input-group">
      <CFormInput
        {...rest}
        ref={ref}
        invalid={invalid}
        type={visible ? 'text' : 'password'}
        className={className}
        autoComplete={rest.autoComplete ?? 'new-password'}
      />
      <CInputGroupText
        as="button"
        type="button"
        className="password-input-group__toggle"
        onClick={() => setVisible((v) => !v)}
        tabIndex={-1}
        aria-label={visible ? 'Hide password' : 'Show password'}
        title={visible ? 'Hide password' : 'Show password'}
      >
        <EyeIcon open={visible} />
      </CInputGroupText>
    </CInputGroup>
  )
})

export default PasswordInput