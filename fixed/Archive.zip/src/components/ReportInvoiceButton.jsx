import { useRef, useState } from 'react'
import {
  CButton,
  CModal,
  CModalBody,
  CModalHeader,
  CSpinner,
  CAlert,
} from '@coreui/react'
import api from '../api/api'
import { generateInvoiceHtml } from '../utils/invoiceHtml'

// Fetches the full order on click and renders it through the same
// generateInvoiceHtml() used on the Order Detail page, so both places
// stay in sync from one source of truth.
const ReportInvoiceButton = ({ orderId, size = 'sm' }) => {
  const [visible, setVisible] = useState(false)
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const iframeRef = useRef(null)

  const handleOpen = async () => {
    setVisible(true)
    setLoading(true)
    setError(null)
    try {
      const res = await api.get(`/orders/${orderId}`)
      setOrder(res.data?.data ?? null)
    } catch (e) {
      setError(e.response?.data?.message ?? 'Failed to load order for printing.')
    } finally {
      setLoading(false)
    }
  }

  const handlePrint = () => {
    const win = iframeRef.current?.contentWindow
    if (!win) return
    win.focus()
    win.print()
  }

  return (
    <>
      <CButton
        size={size}
        className="report-invoice-btn"
        onClick={(e) => { e.stopPropagation(); handleOpen() }}
      >
        Print
      </CButton>

      <CModal
        visible={visible}
        onClose={() => setVisible(false)}
        alignment="center"
        size="lg"
        className="wallet-modal"
        scrollable
      >
        <CModalHeader className="wallet-modal__header">
          <span className="wallet-modal__title">
            Invoice Preview — {order?.order_number ?? `Order #${orderId}`}
          </span>
        </CModalHeader>

        <CModalBody className="wallet-modal__body">
          {loading ? (
            <div className="report-shell__loading">
              <CSpinner />
              <div className="report-shell__loading-text">
                Loading invoice...
              </div>
            </div>
          ) : error ? (
            <CAlert color="danger" dismissible onClose={() => setError(null)}>
              {error}
            </CAlert>
          ) : (
            <>
              <div className="report-frame">
                <iframe
                  ref={iframeRef}
                  title="invoice-preview"
                  srcDoc={generateInvoiceHtml(order)}
                  className="report-frame__iframe"
                />
              </div>
              <div className="report-modal-actions">
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--primary"
                  onClick={handlePrint}
                >
                  Print
                </CButton>
              </div>
            </>
          )}
        </CModalBody>
      </CModal>
    </>
  )
}

export default ReportInvoiceButton