import { Navigate } from 'react-router-dom'
import useAuthStore from '../store/authStore'

const ProtectedRoute = ({ permission = null, role = null, connection = null, children }) => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const hasPermission   = useAuthStore((s) => s.hasPermission)
  const hasRole         = useAuthStore((s) => s.hasRole)
  const userConnection  = useAuthStore((s) => s.connection)

  if (!isAuthenticated) return <Navigate to="/login" replace />

  if (connection && userConnection !== connection) return <Navigate to="/404" replace />
  if (permission && !hasPermission(permission))    return <Navigate to="/404" replace />
  if (role && !hasRole(role))                      return <Navigate to="/404" replace />

  return children
}

export default ProtectedRoute