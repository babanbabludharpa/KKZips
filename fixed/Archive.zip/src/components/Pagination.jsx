import { CButton, CFormInput, CSpinner, CBadge } from '@coreui/react'
import { useMemo, useState } from 'react'

const getPageList = (current, last, maxVisible = 5) => {
  if (last <= 1) return [1]

  const half = Math.floor(maxVisible / 2)
  let start = Math.max(1, current - half)
  let end = Math.min(last, current + half)

  if (end - start + 1 < maxVisible) {
    if (start === 1) end = Math.min(last, start + maxVisible - 1)
    else if (end === last) start = Math.max(1, end - maxVisible + 1)
  }

  const range = []
  for (let i = start; i <= end; i++) range.push(i)

  const withDots = []
  if (range[0] > 1) {
    withDots.push(1)
    if (range[0] > 2) withDots.push('…')
  }
  for (const i of range) withDots.push(i)
  if (range[range.length - 1] < last) {
    if (last - range[range.length - 1] > 1) withDots.push('…')
    withDots.push(last)
  }

  return withDots
}

const Pagination = ({
  meta,
  onPageChange,
  loading = false,
  showPageJumper = true,
  showRecordInfo = true,
  variant = 'default', // 'default' | 'compact' | 'bold'
}) => {
  const [pageInput, setPageInput] = useState('')

  const { current_page, last_page, total, per_page, from, to } = meta

  const rangeStart = useMemo(() => {
    return total === 0 ? 0 : (from || (current_page - 1) * per_page + 1)
  }, [total, from, current_page, per_page])

  const rangeEnd = useMemo(() => {
    return total === 0 ? 0 : (to || Math.min(current_page * per_page, total))
  }, [total, to, current_page, per_page])

  const pageList = useMemo(() => {
    return getPageList(current_page, last_page)
  }, [current_page, last_page])

  const goToPage = (p) => {
    if (p === current_page || p < 1 || p > last_page) return
    onPageChange(p)
  }

  const goToPageInput = () => {
    const pageNum = parseInt(pageInput)
    if (pageNum >= 1 && pageNum <= last_page) {
      goToPage(pageNum)
      setPageInput('')
    }
  }

  if (total === 0) return null

  return (
    <div className={`report-pagination report-pagination--${variant}`}>
      {/* Left: Record info */}
      {showRecordInfo && (
        <div className="report-pagination__info">
          <span className="report-pagination__info-text">
            Showing <span className="report-pagination__num">{rangeStart}</span> –{' '}
            <span className="report-pagination__num">{rangeEnd}</span> of{' '}
            <span className="report-pagination__total">{total}</span> records
          </span>
          <CBadge className="report-pagination__page-badge">
            Page {current_page} of {last_page}
          </CBadge>
          {loading && <CSpinner size="sm" className="report-pagination__spinner" />}
        </div>
      )}

      {/* Right: Pagination controls */}
      {last_page > 1 && (
        <div className="report-pagination__controls">
          {/* First */}
          <CButton
            size="sm"
            className="report-pagination__nav-btn"
            disabled={current_page === 1 || loading}
            onClick={() => goToPage(1)}
          >
            «
          </CButton>

          {/* Previous */}
          <CButton
            size="sm"
            className="report-pagination__nav-btn"
            disabled={current_page === 1 || loading}
            onClick={() => goToPage(current_page - 1)}
          >
            ‹
          </CButton>

          {/* Page numbers */}
          <div className="report-pagination__pages">
            {pageList.map((p, idx) =>
              p === '…' ? (
                <span key={`dots-${idx}`} className="report-pagination__dots">
                  …
                </span>
              ) : (
                <CButton
                  key={p}
                  size="sm"
                  className={
                    p === current_page
                      ? 'report-pagination__page-btn report-pagination__page-btn--active'
                      : 'report-pagination__page-btn'
                  }
                  onClick={() => goToPage(p)}
                  disabled={p === current_page || loading}
                >
                  {p}
                </CButton>
              )
            )}
          </div>

          {/* Next */}
          <CButton
            size="sm"
            className="report-pagination__nav-btn"
            disabled={current_page === last_page || loading}
            onClick={() => goToPage(current_page + 1)}
          >
            ›
          </CButton>

          {/* Last */}
          <CButton
            size="sm"
            className="report-pagination__nav-btn"
            disabled={current_page === last_page || loading}
            onClick={() => goToPage(last_page)}
          >
            »
          </CButton>

          {/* Page Jumper */}
          {showPageJumper && (
            <div className="report-pagination__jumper">
              <span className="report-pagination__jumper-label">Jump to</span>
              <CFormInput
                size="sm"
                type="number"
                className="report-pagination__jumper-input"
                min={1}
                max={last_page}
                value={pageInput}
                onChange={(e) => setPageInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && goToPageInput()}
                disabled={loading}
              />
              <CButton
                size="sm"
                className="report-pagination__go-btn"
                onClick={goToPageInput}
                disabled={!pageInput || loading}
              >
                Go
              </CButton>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default Pagination