import { Component } from 'react'
import { CAlert, CCard, CCardBody } from '@coreui/react'

class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null, info: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    console.error('[ErrorBoundary]', error, info?.componentStack)
    this.setState({ info })
  }

  render() {
    if (this.state.error) {
      return (
        <div className="report-page">
          <CCard className="report-shell">
            <CCardBody>
              <CAlert color="danger" className="mb-0">
                <strong>Something crashed while rendering this page.</strong>
                <pre
                  style={{
                    whiteSpace: 'pre-wrap',
                    marginTop: '0.75rem',
                    marginBottom: 0,
                    fontSize: '0.8rem',
                  }}
                >
                  {this.state.error.toString()}
                  {this.state.info?.componentStack}
                </pre>
              </CAlert>
            </CCardBody>
          </CCard>
        </div>
      )
    }
    return this.props.children
  }
}

export default ErrorBoundary