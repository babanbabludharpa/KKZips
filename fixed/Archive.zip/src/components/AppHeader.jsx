import {
  CAvatar,
  CButton,
  CFormInput,
  CHeader,
  CHeaderNav,
  CDropdown,
  CDropdownDivider,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilBell,
  cilFullscreen,
  cilMenu,
  cilSearch,
  cilSettings,
  cilSun,
  cilMoon,
  cilAccountLogout,
  cilUser,
} from '@coreui/icons'
import { useNavigate, useLocation } from 'react-router-dom'
import { useMemo } from 'react'
import useAuthStore from '../store/authStore'
import useMenuStore from '../store/menuStore'
import useUiStore from '../store/uiStore'
import api from '../api/api'

const getGreeting = () => {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good morning'
  if (hour < 17) return 'Good afternoon'
  return 'Good evening'
}

const getTodayLabel = () => {
  return new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}

const AppHeader = () => {
  const navigate  = useNavigate()
  const location  = useLocation()
  const { user, clearAuth } = useAuthStore()
  const resetMenus = useMenuStore((s) => s.resetMenus)

  const sidebarVisible  = useUiStore(s => s.sidebarVisible)
  const setSidebarVisible = useUiStore(s => s.setSidebarVisible)

  const theme       = useUiStore(s => s.theme)
  const toggleTheme = useUiStore(s => s.toggleTheme)
  const isDark      = theme === 'dark'

  const greeting = useMemo(() => getGreeting(), [])
  const todayLabel = useMemo(() => getTodayLabel(), [])
  const firstName = user?.name?.split(' ')[0] ?? 'there'

  const handleLogout = async () => {
    try {
      await api.post('/auth/logout')
    } catch (_) { /* silent */ }
    finally {
      clearAuth()
      localStorage.removeItem('branding-cache')

      // Reset theme + template
      useUiStore.getState().setThemeAndTemplate({
        theme: 'light',
        template: 'crimson',
      })

      resetMenus()

      requestAnimationFrame(() => {
        navigate('/login', { replace: true })
      })
    }
  }

  const toggleFullscreen = async () => {
    const root = document.documentElement
    if (!document.fullscreenElement) {
      await root.requestFullscreen?.()
    } else {
      await document.exitFullscreen?.()
    }
  }

  const handleSidebarToggle = () => {
    setSidebarVisible(!sidebarVisible)
  }

  return (
    <CHeader position="sticky" className="app-header">
      <div className="app-header__left">
        <CButton
          color="light"
          className="glass-button app-header__mobile-toggle"
          onClick={handleSidebarToggle}
          title="Toggle Navigation"
        >
          <CIcon icon={cilMenu} />
        </CButton>

        <div className="app-header__greeting">
          <div className="app-header__greeting-line">
            <span className="app-header__greeting-text">{greeting},</span>{' '}
            <span className="app-header__greeting-name">{firstName}</span>
          </div>
          <div className="app-header__date">{todayLabel}</div>
        </div>
      </div>

      <CHeaderNav className="app-header__actions">
        <CButton
          color="light"
          className="glass-button"
          title="Toggle theme"
          onClick={toggleTheme}
        >
          <CIcon icon={isDark ? cilSun : cilMoon} />
        </CButton>

        <CButton color="light" className="glass-button notification-button" title="Notifications">
          <CIcon icon={cilBell} />
          <span className="notification-dot" />
        </CButton>

        <CButton color="light" className="glass-button" onClick={toggleFullscreen} title="Fullscreen">
          <CIcon icon={cilFullscreen} />
        </CButton>

        <CDropdown variant="nav-item">
          <CDropdownToggle placement="bottom-end" className="py-0 pe-0" caret={false}>
            <CAvatar
              color="primary"
              textColor="white"
              size="md"
              src={user?.avatar_url || undefined}
            >
              {!user?.avatar_url && (user?.name?.charAt(0).toUpperCase() ?? 'U')}
            </CAvatar>
          </CDropdownToggle>
          <CDropdownMenu className="app-dropdown">
            <div className="dropdown-user">
              <CAvatar
                color="primary"
                textColor="white"
                src={user?.avatar_url || undefined}
              >
                {!user?.avatar_url && (user?.name?.charAt(0).toUpperCase() ?? 'U')}
              </CAvatar>
              <div>
                <div className="fw-semibold">{user?.name ?? 'User'}</div>
                <div className="text-body-secondary small">{user?.email ?? ''}</div>
              </div>
            </div>
            <CDropdownDivider />
            <CDropdownItem onClick={() => navigate('/profile')} style={{ cursor: 'pointer' }}>
              <CIcon icon={cilUser} className="me-2" />Profile
            </CDropdownItem>
            <CDropdownDivider />
            <CDropdownItem onClick={handleLogout} className="text-danger" style={{ cursor: 'pointer' }}>
              <CIcon icon={cilAccountLogout} className="me-2" />Logout
            </CDropdownItem>
          </CDropdownMenu>
        </CDropdown>
      </CHeaderNav>
    </CHeader>
  )
}

export default AppHeader