import Pagination from './Pagination'
import PerPageSelector from './PerPageSelector'
import { CCard, CCardBody } from '@coreui/react'

const PaginatedTableWrapper = ({
  children,
  meta,
  perPage,
  onPageChange,
  onPerPageChange,
  loading = false,
  pageLoading = false,
  showPerPage = true,
  paginationVariant = 'bold',
  ...props
}) => {
  return (
    <CCard className="glass-card admin-page-card">
      <CCardBody className="p-0">
        {children}
        
        <div className="d-flex flex-wrap justify-content-between align-items-center p-3 border-top">
          <div className="d-flex align-items-center gap-3">
            {showPerPage && (
              <PerPageSelector 
                value={perPage}
                onChange={onPerPageChange}
                disabled={loading}
              />
            )}
          </div>
          
          <Pagination 
            meta={meta}
            onPageChange={onPageChange}
            loading={pageLoading}
            variant={paginationVariant}
          />
        </div>
      </CCardBody>
    </CCard>
  )
}

export default PaginatedTableWrapper