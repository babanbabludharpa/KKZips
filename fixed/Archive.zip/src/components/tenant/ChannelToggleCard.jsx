import { CCard, CCardBody, CFormSwitch, CBadge } from '@coreui/react'
import CIcon from '@coreui/icons-react'

export const ChannelToggleCard = ({
  id, icon, title, description, enabled, onChange,
  configured = true, requiredHint, disabled = false,
}) => (
  <CCard
    className={`channel-card ${enabled ? 'channel-card--on' : ''}`}
    style={{ cursor: disabled ? 'not-allowed' : 'default' }}
  >
    <CCardBody className="d-flex align-items-start gap-3">
      <div className={`channel-card__icon ${enabled ? 'is-on' : ''}`}>
        <CIcon icon={icon} width={20} height={20} />
      </div>
      <div className="flex-grow-1">
        <div className="d-flex align-items-center gap-2 mb-1">
          <span className="channel-card__title">{title}</span>
          {!configured && <CBadge color="warning" shape="rounded-pill">Not configured</CBadge>}
        </div>
        <div className="channel-card__desc">{description}</div>
        {enabled && !configured && requiredHint && (
          <div className="text-danger small mt-2">{requiredHint}</div>
        )}
      </div>
      <CFormSwitch
        id={id}
        checked={enabled}
        disabled={disabled}
        onChange={(e) => onChange(e.target.checked)}
        className="channel-card__switch"
      />
    </CCardBody>
  </CCard>
)