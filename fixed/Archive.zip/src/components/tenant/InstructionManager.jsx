import { useEffect, useState } from 'react'
import { CButton, CFormInput, CSpinner, CAlert, CBadge } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus, cilCheck, cilX } from '@coreui/icons'
import api from '../../api/api'

export const InstructionManager = ({ canEdit }) => {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [label, setLabel] = useState('')
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  const load = async () => {
    try {
      setLoading(true)
      const res = await api.get('/settings/profile/instructions')
      setItems(res.data?.data || [])
    } catch (err) {
      setError(err.response?.data?.message ?? 'Could not load delivery instructions.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const add = async () => {
    if (!label.trim() || busy) return
    setBusy(true); setError(null)
    try {
      await api.post('/settings/profile/instructions', { label: label.trim() })
      setLabel('')
      await load()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Failed to add instruction.')
    } finally {
      setBusy(false)
    }
  }

  const toggle = async (item) => {
    try {
      await api.patch(`/settings/profile/instructions/${item.id}/toggle`)
      await load()
    } catch (err) {
      setError(err.response?.data?.message ?? 'Failed to toggle.')
    }
  }

  if (loading) return <div className="py-4 text-center"><CSpinner /></div>

  return (
    <div>
      {error && <CAlert color="danger" dismissible onClose={() => setError(null)}>{error}</CAlert>}

      {canEdit && (
        <div className="d-flex gap-2 mb-3">
          <CFormInput
            className="filter-input"
            placeholder="e.g. Leave with security"
            value={label}
            maxLength={120}
            onChange={(e) => setLabel(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add() } }}
          />
          <CButton
            type="button"
            className="filter-btn filter-btn--primary"
            disabled={busy || !label.trim()}
            onClick={add}
          >
            {busy ? <CSpinner size="sm" className="me-2" /> : <CIcon icon={cilPlus} className="me-2" />}
            Add
          </CButton>
        </div>
      )}

      <div className="d-flex flex-wrap gap-2">
        {items.length === 0 && <span className="text-muted">No instructions yet.</span>}
        {items.map(item => (
          <CBadge
            key={item.id}
            color={item.is_active ? 'success' : 'secondary'}
            shape="rounded-pill"
            className="px-3 py-2"
            style={{ cursor: canEdit ? 'pointer' : 'default', fontSize: '0.85rem' }}
            onClick={() => canEdit && toggle(item)}
            title={canEdit ? 'Click to toggle' : ''}
          >
            <CIcon icon={item.is_active ? cilCheck : cilX} className="me-1" width={12} />
            {item.label}
          </CBadge>
        ))}
      </div>
      <p className="tenant-note mt-3 mb-0">
        Active instructions appear on customer checkout. Inactive ones stay referenced by past orders.
      </p>
    </div>
  )
}