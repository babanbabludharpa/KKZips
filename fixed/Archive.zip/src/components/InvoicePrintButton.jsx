import { useRef, useState } from 'react'
import { CButton, CModal, CModalBody, CModalHeader } from '@coreui/react'
import { generateInvoiceHtml } from '../utils/invoiceHtml'

const InvoicePrintButton = ({ order }) => {
  const [visible, setVisible] = useState(false)
  const iframeRef = useRef(null)

  const handlePrint = () => {
    const win = iframeRef.current?.contentWindow
    if (!win) return
    win.focus()
    win.print()
  }

  const safeHtml = () => {
    try {
      return generateInvoiceHtml(order)
    } catch (err) {
      console.error('[InvoicePrintButton] generateInvoiceHtml failed:', err)
      return `
        <html>
          <body style="font-family:sans-serif;padding:20px;color:#b91c1c;">
            <p><strong>Invoice preview unavailable.</strong></p>
            <p style="font-size:0.85rem;">${err?.message ?? 'Unknown error'}</p>
          </body>
        </html>
      `
    }
  }

  return (
    <>
      <CButton
        size="sm"
        className="filter-btn filter-btn--ghost"
        onClick={() => setVisible(true)}
      >
        Print Invoice
      </CButton>

      <CModal
        visible={visible}
        onClose={() => setVisible(false)}
        alignment="center"
        size="lg"
        className="wallet-modal"
        scrollable
      >
        <CModalHeader className="wallet-modal__header">
          <strong className="wallet-modal__title">Invoice Preview</strong>
        </CModalHeader>
        <CModalBody className="wallet-modal__body">
          {visible && (
            <>
              <div className="report-frame">
                <iframe
                  ref={iframeRef}
                  title="invoice-preview"
                  srcDoc={safeHtml()}
                  className="report-frame__iframe"
                />
              </div>
              <div className="report-modal-actions">
                <CButton
                  size="sm"
                  className="filter-btn filter-btn--primary"
                  onClick={handlePrint}
                >
                  Print
                </CButton>
              </div>
            </>
          )}
        </CModalBody>
      </CModal>
    </>
  )
}

export default InvoicePrintButton