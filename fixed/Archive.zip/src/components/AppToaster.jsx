import { CToaster, CToast, CToastBody } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilCheckCircle, cilWarning, cilXCircle, cilBell } from '@coreui/icons'
import { useToastStore } from '../store/toastStore'

const iconMap = {
  success: cilCheckCircle,
  error: cilXCircle,
  warning: cilWarning,
  info: cilBell,
}

const AppToaster = () => {
  const toasts = useToastStore(state => state.toasts)
  const removeToast = useToastStore(state => state.removeToast)

  return (
    <CToaster placement="top-end">
      {toasts.map(t => (
        <CToast
          key={t.id}
          visible
          autohide={false}
          className={`app-toast app-toast--${t.type}`}
        >
          <div className="app-toast__inner">
            <CIcon icon={iconMap[t.type]} className="app-toast__icon" />
            <CToastBody>{t.message}</CToastBody>
            <button
              type="button"
              className="app-toast__close"
              onClick={() => removeToast(t.id)}
              aria-label="Close"
            >
              ✕
            </button>
          </div>
        </CToast>
      ))}
    </CToaster>
  )
}

export default AppToaster