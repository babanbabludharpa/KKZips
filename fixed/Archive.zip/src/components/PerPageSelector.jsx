import { CFormSelect, CFormLabel } from '@coreui/react'

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100]

const PerPageSelector = ({ 
  value, 
  onChange, 
  label = 'Per Page',
  options = PAGE_SIZE_OPTIONS,
  size = 'sm',
  disabled = false
}) => {
  return (
    <div>
      <CFormLabel className="small mb-1">{label}</CFormLabel>
      <CFormSelect 
        size={size}
        style={{ width: 90 }}
        value={value}
        onChange={onChange}
        disabled={disabled}
      >
        {options.map(n => (
          <option key={n} value={n}>{n}</option>
        ))}
      </CFormSelect>
    </div>
  )
}

export default PerPageSelector