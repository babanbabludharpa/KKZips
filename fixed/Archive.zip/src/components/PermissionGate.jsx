import useAuthStore from '../store/authStore'

const PermissionGate = ({ permission = null, role = null, fallback = null, children }) => {
  const hasPermission = useAuthStore((s) => s.hasPermission)
  const hasRole       = useAuthStore((s) => s.hasRole)

  if (permission && !hasPermission(permission)) return fallback
  if (role && !hasRole(role))                   return fallback

  return children
}

export default PermissionGate