import { useEffect, useMemo, useState } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import {
  CBadge,
  CButton,
  CNavGroup,
  CNavItem,
  CSidebar,
  CSidebarBrand,
  CSidebarNav,
  CSpinner,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import * as icons from '@coreui/icons'
import { cilAccountLogout, cilSettings } from '@coreui/icons'
import useMenuStore from '../store/menuStore'
import useAuthStore from '../store/authStore'
import useUiStore from '../store/uiStore'
import api from '../api/api'
import useIsMobile from '../hooks/useIsMobile'
import kutumbkartLogo from '../assets/images/kutumbkart_logo.png'

const resolveIcon = (iconName) => {
  if (!iconName) return null
  const camelCaseIconName = iconName.replace(/-([a-z])/g, (_, letter) =>
    letter.toUpperCase()
  )
  const icon = icons[camelCaseIconName]
  return icon ? <CIcon icon={icon} className="nav-icon" /> : null
}

const badgeMap = {
  Dashboard: '', 
  Users: '4',
  Roles: '2',
  Permissions: '8',
  Menus: '5',
  Orders: '9',
  Reports: '3',
  Stock: '14',
}

const AppSidebar = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const { menus, loading, fetchMenus } = useMenuStore()
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const connection = useAuthStore((s) => s.connection)
  const clearAuth = useAuthStore((s) => s.clearAuth)

  const sidebarVisible = useUiStore(s => s.sidebarVisible)
  const setSidebarVisible = useUiStore(s => s.setSidebarVisible)
  const [companyLogo, setCompanyLogo] = useState(null)
  const [companyName, setCompanyName] = useState(null)

  const isMobile = useIsMobile()

  // Whenever the mobile/desktop breakpoint is actually crossed,
  // reset to the correct default: closed drawer on mobile,
  // expanded sidebar on desktop. Fixes the "sometimes open,
  // sometimes closed, sometimes full blur" glitch when resizing.
  useEffect(() => {
    setSidebarVisible(!isMobile)
  }, [isMobile, setSidebarVisible])

  const sidebarClass = useMemo(() => {
    if (isMobile) {
      return `app-sidebar ${sidebarVisible ? 'is-open' : ''}`
    }
    return `app-sidebar ${sidebarVisible ? '' : 'is-collapsed'}`
  }, [isMobile, sidebarVisible])

  // Sync --sidebar-width CSS var when collapsed/expanded on desktop
  useEffect(() => {
    if (!isMobile) {
      document.documentElement.style.setProperty(
        '--sidebar-width',
        sidebarVisible ? '280px' : '80px'
      )
    }
  }, [sidebarVisible, isMobile])

  useEffect(() => {
    if (isAuthenticated) fetchMenus(connection)
  }, [isAuthenticated, connection, fetchMenus])

  useEffect(() => {
    api.get('/branding')
      .then((res) => {
        const data = res?.data?.data || {}
        
        setCompanyLogo(data.logo_url || null)
        setCompanyName(data.brand_name || null)
      })
      .catch(() => {
        setCompanyLogo(null)
        setCompanyName(null)
      })
  }, [])

  const handleLogout = async () => {
    const logoutUrl = connection === 'central' ? '/platform/auth/logout' : '/auth/logout'
    try {
      await api.post(logoutUrl)
    } catch (_) { /* silent */ }
    finally {
      clearAuth()
      localStorage.removeItem('branding-cache')

      useUiStore.getState().setThemeAndTemplate({
        theme: 'light',
        template: 'crimson',
      })

      useMenuStore.getState().resetMenus()

      requestAnimationFrame(() => {
        navigate('/login', { replace: true })
      })
    }
  }

   const handleNavLinkClick = () => {
    if (isMobile) {
      setSidebarVisible(false)
    }
  }

  const renderMenu = (menu) => {
    const hasChildren = menu.children && menu.children.length > 0

    if (hasChildren) {
      const hasActiveChild = menu.children.some(
        (child) => child.route && location.pathname.startsWith(child.route)
      )

      return (
        <CNavGroup
          key={menu.id}
          visible={hasActiveChild}
          toggler={
            <>
              {resolveIcon(menu.icon)}
              <span>{menu.name}</span>
            </>
          }
        >
          {menu.children.map((child) => (
            <CNavItem key={child.id} className="sidebar-nav-item">
              <NavLink
                to={child.route ?? '#'}
                end
                className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}
                onClick={handleNavLinkClick}
              >
                {resolveIcon(child.icon)}
                <span>{child.name}</span>

                {badgeMap[child.name] ? (
                  <CBadge
                    color="light"
                    textColor="dark"
                    className="sidebar-badge"
                  >
                    {badgeMap[child.name]}
                  </CBadge>
                ) : null}
              </NavLink>
            </CNavItem>
          ))}
        </CNavGroup>
      )
    }

    return (
      <CNavItem key={menu.id} className="sidebar-nav-item">
        <NavLink
          to={menu.route ?? '#'}
          end
          className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}
          onClick={handleNavLinkClick}
        >
          {resolveIcon(menu.icon)}
          <span>{menu.name}</span>
          {badgeMap[menu.name] ? (
            <CBadge color="light" textColor="dark" className="sidebar-badge">
              {badgeMap[menu.name]}
            </CBadge>
          ) : null}
        </NavLink>
      </CNavItem>
    )
  }

  return (
    <>
      <div
        className={`app-sidebar-backdrop ${sidebarVisible && isMobile ? 'is-visible' : ''}`}
        onClick={() => setSidebarVisible(false)}
      />
      <CSidebar
        className={sidebarClass}
        position="fixed"
        unfoldable={false}
        visible={isMobile ? sidebarVisible : true}
      >
        <CSidebarBrand
          className={`app-sidebar__brand ${sidebarVisible ? 'is-expanded' : 'is-collapsed'}`}>
          {companyLogo && (
            <div className="app-brand-logo-wrapper">
              <img
                src={companyLogo}
                // src={kutumbkartLogo}
                alt={companyName || 'Company logo'}
                className="app-brand-logo"
                onError={(e) => {
                  e.currentTarget.style.display = 'none'
                }}
              />

              {sidebarVisible && companyName && (
                <span className="app-brand-name">
                  {companyName}
                  {/* K-MART Collection Pvt. Ltd. Pune */}
                </span>
              )}
            </div>
          )}
        </CSidebarBrand>

        <CSidebarNav className="app-sidebar__nav">
          {loading ? (
            <div className="text-center py-4">
              <CSpinner size="sm" />
            </div>
          ) : (
            menus.map((menu) => renderMenu(menu))
          )}

          {/* <CNavItem className="sidebar-nav-item">
            <NavLink
              to="/settings"
              className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}
              onClick={handleNavLinkClick}
            >
              <CIcon icon={cilSettings} className="nav-icon" />
              <span>Settings</span>
            </NavLink>
          </CNavItem> */}
        </CSidebarNav>

        <div className="app-sidebar__footer">
          <CButton
            color="light"
            className="glass-button sidebar-logout"
            onClick={handleLogout}
          >
            <CIcon icon={cilAccountLogout} />
            <span>Logout</span>
          </CButton>
        </div>
      </CSidebar>
    </>
  )
}

export default AppSidebar