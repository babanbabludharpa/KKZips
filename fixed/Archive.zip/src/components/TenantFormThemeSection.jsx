/**
 * TenantFormThemeSection.jsx
 * Theme picker block, embedded inside the Tenants create/edit modal.
 */

import { useState } from 'react'
import { CCard, CCardBody, CCardHeader, CButton, CSpinner, CBadge } from '@coreui/react'
import { useController } from 'react-hook-form'
import ThemePicker from './ThemePicker'
import api from '../api/api'

export default function TenantFormThemeSection({ control, setValue, watch, tenantId = null }) {
  const [saving, setSaving] = useState(false)
  const [saved,  setSaved]  = useState(false)
  const [error,  setError]  = useState(null)

  // Register themeKey field with react-hook-form
  const { field } = useController({
    name:         'themeKey',
    control,
    defaultValue: 'crimson',
  })

  const handleChange = (key) => {
    field.onChange(key)
    setSaved(false)
    setError(null)
  }

  // Save immediately (only shown in edit mode when tenantId exists)
  const handleSaveNow = async () => {
    if (!tenantId) return
    setSaving(true)
    setError(null)
    try {
      await api.patch(`/platform/tenants/${tenantId}/theme`, {
        theme_key: field.value,
      })
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (err) {
      setError(err?.response?.data?.message ?? 'Failed to save theme.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <CCard className="report-shell" style={{ marginTop: 24 }}>
      <CCardHeader className="report-shell__header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div className="report-shell__title" style={{ fontSize: '1rem', margin: 0 }}>
            Tenant Color Schema
          </div>
          <div className="text-muted small" style={{ marginTop: 2 }}>
            Platform admin — all schemas available · Hover cards to preview live
          </div>
        </div>
        <div className="d-flex align-items-center gap-2">
          {error && (
            <span className="text-danger small">{error}</span>
          )}
          {saved && (
            <CBadge className="report-pagination__page-badge">✓ Saved</CBadge>
          )}
          {tenantId && (
            <CButton
              size="sm"
              className="filter-btn filter-btn--primary"
              disabled={saving}
              onClick={handleSaveNow}
            >
              {saving ? <CSpinner size="sm" /> : 'Save Theme'}
            </CButton>
          )}
        </div>
      </CCardHeader>

      <CCardBody>
        <ThemePicker
          value={field.value}
          onChange={handleChange}
          previewLive={true}
        />
      </CCardBody>
    </CCard>
  )
}