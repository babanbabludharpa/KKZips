import * as yup from 'yup'

const CUTOFF_TIME_OPTIONS = [
  '19:00','19:30','20:00','20:30','21:00',
  '21:30','22:00','22:30','23:00','23:30',
]

export const schema = yup.object({
  company_name: yup.string().required('Company name is required'),
  pan_no: yup.string().nullable().optional()
    .transform(v => v === '' ? null : v)
    .matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, { message: 'Invalid PAN format (e.g. ABCDE1234F)', excludeEmptyString: true }),

  support_phone: yup.string().nullable().optional().max(20),
  support_email: yup.string().nullable().optional()
    .transform(v => v === '' ? null : v)
    .email('Enter a valid email'),
  support_hours: yup.string().nullable().optional().max(100),

  has_orders: yup.boolean(),
  use_order_slots: yup.boolean(),
  has_subscriptions: yup.boolean(),
  has_wallet: yup.boolean(),

  order_start_policy: yup.string().oneOf(['next_day_only', 'same_day_slot_wise']).required(),
  order_same_day_lead_time_minutes: yup.number()
    .typeError('Must be a number').integer().min(30).max(720).required(),

  slot_wise_cutoff_enabled: yup.boolean(),
  slot_cutoff_offset_minutes: yup.number()
    .typeError('Must be a number').integer().min(15).max(720).required(),

  cod_enabled: yup.boolean(),
  online_payment_enabled: yup.boolean(),
  razorpay_key_id: yup.string().nullable().transform(v => v === '' ? null : v)
    .matches(/^rzp_(test|live)_/, { message: 'Key ID must start with rzp_test_ or rzp_live_', excludeEmptyString: true }),
  razorpay_key_secret: yup.string().nullable().transform(v => v === '' ? null : v),
  razorpay_webhook_secret: yup.string().nullable().transform(v => v === '' ? null : v),
  razorpay_is_live: yup.boolean(),

  pusher_app_id: yup.string().nullable().transform(v => v === '' ? null : v),
  pusher_key: yup.string().nullable().transform(v => v === '' ? null : v),
  pusher_secret: yup.string().nullable().transform(v => v === '' ? null : v),
  pusher_cluster: yup.string().nullable().transform(v => v === '' ? null : v),

  subscription_cutoff_time: yup.string().nullable()
    .transform(v => v === '' ? null : v)
    .oneOf([...CUTOFF_TIME_OPTIONS, null], 'Invalid cutoff time'),
  subscription_cutoff_restrict_admin: yup.boolean(),
  subscription_start_policy: yup.string()
    .oneOf(['next_day_only', 'same_day_slot_wise']).required(),
  same_day_lead_time_minutes: yup.number()
    .typeError('Must be a number').integer().min(30).max(720).required(),
  rider_assignment_time: yup.string()
    .matches(/^([01]\d|2[0-3]):[0-5]\d$/, 'Use HH:MM (24-hour)').required(),
  order_stock_check_enabled: yup.boolean(),
  subscription_stock_check_enabled: yup.boolean(),

  sms_username: yup.string().nullable().transform(v => v === '' ? null : v),
  sms_password: yup.string().nullable().transform(v => v === '' ? null : v),
  sms_sender_id: yup.string().nullable().transform(v => v === '' ? null : v)
    .matches(/^[A-Z0-9]{6}$/, { message: 'Sender ID is usually 6 characters (e.g. KUTMBK)', excludeEmptyString: true }),
  sms_enabled: yup.boolean(),
  sms_channel_enabled: yup.boolean(),

  notification_channel_enabled: yup.boolean(),
  whatsapp_channel_enabled: yup.boolean(),
  whatsapp_api_key: yup.string().nullable().transform(v => v === '' ? null : v),
  whatsapp_phone_number: yup.string().nullable().transform(v => v === '' ? null : v)
    .matches(/^\+?[0-9]{10,15}$/, { message: 'Use digits only (10–15), optional leading +', excludeEmptyString: true }),
  email_channel_enabled: yup.boolean(),

  wallet_warning_limit: yup.number().typeError('Must be a number').max(0).required(),
  wallet_suspension_limit: yup.number().typeError('Must be a number').max(0).required()
    .test('more-negative', 'Suspension limit must be more negative than warning', function (value) {
      const warning = this.parent.wallet_warning_limit
      if (value == null || warning == null) return true
      return value < warning
    }),

  delivery_note_min_days: yup.number().integer().min(0).max(60).required(),
  delivery_note_max_days: yup.number().integer().min(0).max(90).required()
    .test('gte-min', 'Max must be ≥ min', function (v) {
      const min = this.parent.delivery_note_min_days
      return v == null || min == null || v >= min
    }),
  delivery_note_text: yup.string().nullable().max(255),
})